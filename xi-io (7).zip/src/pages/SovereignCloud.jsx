import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Button } from "@/components/ui/button";
import { Check, ArrowRight, Shield, Cpu, Zap, Server } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

export default function SovereignCloud() {
    return (
        <PublicLayout theme="purple-500">
            
            {/* HERO */}
            <section className="pt-32 pb-20 px-6 relative">
                <div className="max-w-7xl mx-auto text-center relative z-10">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-[10px] font-mono uppercase tracking-widest mb-8 backdrop-blur-md">
                        <Shield className="w-3 h-3" />
                        <span>Infrastructure Product</span>
                    </div>
                    
                    <h1 className="text-5xl md:text-7xl font-serif font-light text-white mb-6 drop-shadow-2xl">
                        Sovereign <span className="italic text-purple-400">Cloud</span>
                    </h1>
                    
                    <p className="text-xl text-neutral-300 max-w-2xl mx-auto leading-relaxed mb-12 font-light">
                        Deploy a fully autonomous cloud region on your own hardware. 
                        Zero-knowledge encryption, edge-native AI, and total data residency.
                    </p>

                    <div className="flex flex-col md:flex-row items-center justify-center gap-4">
                        <Button 
                            className="h-12 px-8 bg-purple-500 text-white hover:bg-purple-600 rounded-full font-bold shadow-[0_0_20px_-5px_rgba(168,85,247,0.5)]"
                            onClick={() => {
                                import('sonner').then(({ toast }) => toast.success("Deployment sequence initiated. Check Scheduler Agent."));
                            }}
                        >
                            Deploy Region
                        </Button>
                        <Button 
                            variant="outline" 
                            className="h-12 px-8 border-white/10 text-white hover:bg-white/5 rounded-full backdrop-blur-sm"
                            onClick={() => {
                                window.open('/Docs', '_blank');
                            }}
                        >
                            Read Documentation
                        </Button>
                    </div>
                </div>
            </section>

            {/* VISUAL BREAKDOWN */}
            <section className="py-24 px-6">
                <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
                    <div className="relative aspect-square bg-black/40 rounded-2xl border border-white/10 overflow-hidden group backdrop-blur-xl shadow-2xl">
                        {/* Abstract Visual of a Server Node */}
                        <div className="absolute inset-0 flex items-center justify-center">
                            <Server className="w-32 h-32 text-neutral-700 group-hover:text-purple-500 transition-colors duration-500" />
                        </div>
                        <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 to-transparent">
                            <div className="font-mono text-xs text-purple-400 mb-2">STATUS: ONLINE</div>
                            <div className="h-1 w-full bg-neutral-800 rounded-full overflow-hidden">
                                <div className="h-full bg-purple-500 w-[99%]" />
                            </div>
                        </div>
                    </div>
                    
                    <div className="space-y-8 p-8 rounded-2xl bg-black/20 backdrop-blur-md border border-white/5">
                        <h2 className="text-3xl font-light text-white">
                            Your Metal. <br />
                            Your Rules.
                        </h2>
                        <p className="text-neutral-300 text-lg leading-relaxed font-light">
                            Stop renting your existence from tech giants. The Sovereign Cloud stack installs directly onto bare metal servers, transforming them into a unified private cloud.
                        </p>
                        
                        <div className="space-y-4">
                            <FeatureRow title="Zero-Trust Networking" desc="Peer-to-peer encrypted mesh automatically establishes secure tunnels between your nodes." />
                            <FeatureRow title="Edge Inference" desc="Run open-source LLMs locally for privacy-preserving intelligence." />
                            <FeatureRow title="Universal Storage" desc="S3-compatible object storage that syncs across your fleet." />
                        </div>
                    </div>
                </div>
            </section>

            {/* SPECS */}
            <section className="py-24 px-6">
                <div className="max-w-4xl mx-auto">
                    <h2 className="text-2xl font-light text-white mb-12 text-center">Technical Specifications</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/10 border border-white/10 rounded-xl overflow-hidden backdrop-blur-md">
                        <SpecBox label="Supported OS" value="Linux (Debian/Ubuntu), macOS" />
                        <SpecBox label="Min Requirements" value="2 vCPU, 4GB RAM, 50GB SSD" />
                        <SpecBox label="Consensus" value="Raft + Gossip Protocol" />
                        <SpecBox label="Encryption" value="AES-256-GCM (At Rest & Transit)" />
                        <SpecBox label="Orchestration" value="WASM / Docker Containers" />
                        <SpecBox label="License" value="MIT / Enterprise Dual" />
                    </div>
                </div>
            </section>

        </PublicLayout>
    );
}

function FeatureRow({ title, desc }) {
    return (
        <div className="flex gap-4">
            <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0 mt-1">
                <Check className="w-3 h-3 text-purple-400" />
            </div>
            <div>
                <h3 className="text-white font-medium">{title}</h3>
                <p className="text-sm text-neutral-500 mt-1">{desc}</p>
            </div>
        </div>
    );
}

function SpecBox({ label, value }) {
    return (
        <div className="bg-transparent p-6 flex flex-col justify-center">
            <span className="text-xs font-mono uppercase tracking-widest text-neutral-500 mb-2">{label}</span>
            <span className="text-lg text-white font-medium">{value}</span>
        </div>
    );
}