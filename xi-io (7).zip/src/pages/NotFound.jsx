import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle, Home, Search, ArrowLeft } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { OrientingText, IntentText } from '@/components/ui/design-system/System';

export default function NotFound() {
    return (
        <div className="min-h-screen bg-black flex items-center justify-center p-6 relative overflow-hidden">
            {/* Background Noise */}
            <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://grainy-gradients.vercel.app/noise.svg')] mix-blend-overlay"></div>
            
            <div className="relative z-10 max-w-lg w-full text-center space-y-8">
                <div className="flex justify-center mb-8">
                    <div className="w-24 h-24 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center animate-pulse">
                        <AlertTriangle className="w-10 h-10 text-neutral-500" />
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="flex items-center justify-center gap-3">
                         <span className="px-2 py-1 rounded bg-rose-500/10 border border-rose-500/20 text-rose-500 text-[10px] font-mono tracking-widest uppercase">
                            Error 404
                         </span>
                         <span className="px-2 py-1 rounded bg-neutral-900 border border-white/10 text-neutral-500 text-[10px] font-mono tracking-widest uppercase">
                            Signal Lost
                         </span>
                    </div>
                    
                    <IntentText className="text-5xl md:text-7xl font-light text-white tracking-tighter">
                        Void Sector
                    </IntentText>
                    
                    <OrientingText className="text-lg text-neutral-400 max-w-md mx-auto leading-relaxed">
                        The requested coordinates do not map to any known system sector. You may have drifted off-course.
                    </OrientingText>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8 border-t border-white/5">
                    <Button 
                        onClick={() => window.history.back()}
                        variant="ghost" 
                        className="w-full sm:w-auto text-neutral-400 hover:text-white"
                    >
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Go Back
                    </Button>
                    <Link to="/">
                        <Button className="w-full sm:w-auto bg-white text-black hover:bg-neutral-200 min-w-[140px]">
                            <Home className="w-4 h-4 mr-2" />
                            Return Home
                        </Button>
                    </Link>
                    <Link to="/SearchResults">
                        <Button variant="outline" className="w-full sm:w-auto border-white/10 text-neutral-300 hover:text-white">
                            <Search className="w-4 h-4 mr-2" />
                            Search
                        </Button>
                    </Link>
                </div>

                <div className="mt-12 text-[10px] font-mono text-neutral-600">
                    ERR_ADDR_INVALID • XI-CONTROL SYSTEM
                </div>
            </div>
        </div>
    );
}