import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { CheckCircle2, Crown, Zap, Shield, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PaymentModal from '@/components/commerce/PaymentModal';

export default function Pricing() {
    const [selectedPlan, setSelectedPlan] = useState(null);
    const [isPaymentOpen, setIsPaymentOpen] = useState(false);

    const plans = [
        {
            name: "Starter",
            price: "$0",
            description: "Essential tools for solo founders.",
            features: [
                "Basic CRM (100 Contacts)",
                "Task Management",
                "Community Support",
                "1 Project"
            ],
            cta: "Start Free",
            highlight: false
        },
        {
            name: "Pro",
            price: "$29",
            period: "/month",
            description: "Power tools for growing teams.",
            features: [
                "Advanced CRM (Unlimited)",
                "Full Finance Suite",
                "AI Strategy Engine",
                "Priority Support",
                "Unlimited Projects"
            ],
            cta: "Get Started",
            highlight: true
        },
        {
            name: "Enterprise",
            price: "$99",
            period: "/month",
            description: "Total sovereignty for organizations.",
            features: [
                "Everything in Pro",
                "Dedicated Server Node",
                "Custom Integrations",
                "Concierge Onboarding",
                "SLA Guarantee"
            ],
            cta: "Contact Sales",
            highlight: false
        }
    ];

    const handleSelectPlan = (plan) => {
        if (plan.price === "$0") {
            base44.auth.redirectToLogin();
            return;
        }
        
        // For paid plans, check auth then open payment
        base44.auth.isAuthenticated().then(isAuth => {
            if (isAuth) {
                setSelectedPlan(plan);
                setIsPaymentOpen(true);
            } else {
                // Store intent and redirect to login
                sessionStorage.setItem('intended_plan', JSON.stringify(plan));
                base44.auth.redirectToLogin(window.location.pathname);
            }
        });
    };

    return (
        <div className="min-h-screen bg-black text-white font-sans selection:bg-[hsl(var(--color-intent))] selection:text-black">
            {/* Header */}
            <div className="pt-32 pb-20 px-6 text-center max-w-4xl mx-auto">
                <h1 className="text-5xl md:text-6xl font-serif font-light mb-6">
                    Invest in Your <span className="text-[hsl(var(--color-intent))] italic">Sovereignty</span>
                </h1>
                <p className="text-xl text-neutral-400 leading-relaxed max-w-2xl mx-auto">
                    Choose the power level that fits your ambition. Transparent pricing, no hidden fees, cancel anytime.
                </p>
            </div>

            {/* Pricing Grid */}
            <div className="max-w-7xl mx-auto px-6 pb-32">
                <div className="grid md:grid-cols-3 gap-8">
                    {plans.map((plan, idx) => (
                        <div 
                            key={idx}
                            className={`relative p-8 rounded-2xl border transition-all duration-300 flex flex-col ${
                                plan.highlight 
                                    ? 'bg-neutral-900/50 border-[hsl(var(--color-intent))] shadow-[0_0_40px_-10px_hsl(var(--color-intent))/20] scale-105 z-10' 
                                    : 'bg-neutral-900/20 border-white/10 hover:border-white/20'
                            }`}
                        >
                            {plan.highlight && (
                                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-[hsl(var(--color-intent))] text-black text-xs font-bold uppercase tracking-widest rounded-full flex items-center gap-2">
                                    <Crown className="w-3 h-3" /> Most Popular
                                </div>
                            )}

                            <div className="mb-8">
                                <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                                <div className="flex items-baseline gap-1 mb-4">
                                    <span className="text-4xl font-light">{plan.price}</span>
                                    {plan.period && <span className="text-neutral-500 text-sm">{plan.period}</span>}
                                </div>
                                <p className="text-neutral-400 text-sm">{plan.description}</p>
                            </div>

                            <div className="space-y-4 mb-8 flex-1">
                                {plan.features.map((feat, i) => (
                                    <div key={i} className="flex items-start gap-3 text-sm text-neutral-300">
                                        <CheckCircle2 className={`w-4 h-4 shrink-0 ${plan.highlight ? 'text-[hsl(var(--color-intent))]' : 'text-neutral-600'}`} />
                                        <span>{feat}</span>
                                    </div>
                                ))}
                            </div>

                            <Button 
                                onClick={() => handleSelectPlan(plan)}
                                className={`w-full h-12 font-bold tracking-wide ${
                                    plan.highlight 
                                        ? 'bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90' 
                                        : 'bg-white/5 text-white hover:bg-white/10 border border-white/10'
                                }`}
                            >
                                {plan.cta} {plan.highlight && <ArrowRight className="w-4 h-4 ml-2" />}
                            </Button>
                        </div>
                    ))}
                </div>
            </div>

            {/* Feature Comparison / Trust */}
            <div className="border-t border-white/5 bg-neutral-900/30 py-24 px-6">
                <div className="max-w-5xl mx-auto text-center">
                    <h2 className="text-2xl font-light mb-12">Trusted by builders at</h2>
                    <div className="flex flex-wrap justify-center gap-12 opacity-40 grayscale">
                        {/* Placeholder logos */}
                        <div className="text-xl font-bold font-serif">ACME Corp</div>
                        <div className="text-xl font-bold font-mono">Globex</div>
                        <div className="text-xl font-bold font-sans">Soylent</div>
                        <div className="text-xl font-bold italic">Initech</div>
                    </div>
                </div>
            </div>

            {/* Payment Modal */}
            {selectedPlan && (
                <PaymentModal 
                    open={isPaymentOpen} 
                    onOpenChange={setIsPaymentOpen}
                    item={selectedPlan}
                />
            )}
        </div>
    );
}