import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Button } from "@/components/ui/button";
import { Scroll, FileText, Scale, ShieldCheck } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Manifesto() {
    return (
        <PublicLayout theme="slate-500">
            {/* HERO */}
            <section className="pt-32 pb-12 px-6">
                <div className="max-w-4xl mx-auto text-center relative z-10">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-neutral-400 text-[10px] font-mono uppercase tracking-widest mb-8 backdrop-blur-md">
                        <Scroll className="w-3 h-3" />
                        <span>The Code</span>
                    </div>
                    
                    <h1 className="text-5xl md:text-7xl font-serif font-light text-white mb-6 drop-shadow-2xl">
                        The <span className="text-[hsl(var(--color-intent))]">Liberator</span> Manifesto
                    </h1>
                </div>
            </section>

            <section className="py-12 px-6">
                <div className="max-w-4xl mx-auto space-y-8">
                    
                    {/* Manifesto - Glassmorphic Document */}
                    <div className="relative p-8 md:p-12 rounded-2xl bg-black/40 border border-white/10 backdrop-blur-xl shadow-2xl overflow-hidden group">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                            <ShieldCheck className="w-32 h-32 text-white" />
                        </div>

                        <div className="relative z-10 prose prose-invert max-w-none">
                            <h2 className="text-3xl font-light text-white mb-8 border-b border-white/10 pb-4">The Antidote to Vendor Lock-In</h2>
                            
                            <p className="text-lg text-neutral-300 leading-relaxed font-light">
                                The current landscape of workflow automation is predatory. Obscured exit fees, proprietary binary formats, and black-box integrations are designed to trap you, not empower you.
                            </p>
                            
                            <p className="text-lg text-neutral-300 leading-relaxed font-light">
                                We are not just a competitor; we are the liberation. Valhalla is built on three non-negotiable principles of sovereignty:
                            </p>
                            
                            <ul className="space-y-6 my-10">
                                <Principle 
                                    number="01" 
                                    title="Zero Exit Fees" 
                                    desc="Your data is yours. We offer free, one-click migration tools. Leave whenever you want, for any reason, at no cost. We compete on value, not by locking the door." 
                                />
                                <Principle 
                                    number="02" 
                                    title="Sovereign Key Infrastructure" 
                                    desc="You hold the keys. API tokens are cryptographically secured on a permissioned blockchain (ChainLedger). No one—not even us—can revoke your access without your consent." 
                                />
                                <Principle 
                                    number="03" 
                                    title="Radical Transparency" 
                                    desc="OpenAPI-First. Every connector has a published schema. We don't hide our logic in a black box; we publish it for you to audit, test, and extend." 
                                />
                            </ul>
                            
                            <div className="flex items-center gap-4 mt-12 pt-8 border-t border-white/10">
                                <div className="h-12 w-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center font-serif italic text-2xl">V</div>
                                <div>
                                    <div className="text-sm font-bold text-white uppercase tracking-wider">Valhalla Protocol</div>
                                    <div className="text-xs text-neutral-500 font-mono">STATUS: LIBERATED</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Terms & Privacy Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <DocCard 
                            icon={FileText}
                            title="Terms of Service"
                            desc="The legal framework governing your use of the XI-IO protocol and associated services."
                        />
                        <DocCard 
                            icon={Scale}
                            title="Privacy Policy"
                            desc="How we (don't) handle your data. Spoiler: we collect almost nothing."
                        />
                    </div>

                </div>
            </section>
        </PublicLayout>
    );
}

function Principle({ number, title, desc }) {
    return (
        <li className="flex gap-6 items-start p-4 rounded-lg hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
            <span className="font-mono text-xl text-white/30 font-bold">{number}.</span>
            <div>
                <strong className="block text-white text-lg mb-1 font-normal">{title}</strong>
                <span className="text-neutral-400 font-light leading-relaxed">{desc}</span>
            </div>
        </li>
    );
}

function DocCard({ icon: Icon, title, desc }) {
    return (
        <div className="p-8 rounded-xl border border-white/10 bg-black/40 backdrop-blur-md hover:bg-white/5 hover:border-white/20 transition-all cursor-pointer group shadow-lg">
            <div className="w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Icon className="w-6 h-6 text-neutral-400 group-hover:text-white transition-colors" />
            </div>
            <h3 className="text-xl font-light text-white mb-2">{title}</h3>
            <p className="text-sm text-neutral-400 leading-relaxed">{desc}</p>
        </div>
    );
}