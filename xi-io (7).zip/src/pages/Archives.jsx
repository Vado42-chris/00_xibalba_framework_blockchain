import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Folder, File, Upload, HardDrive, 
    MoreVertical, Download, Trash2, 
    Grid, List, Search, Plus, Film, 
    Image as ImageIcon, FileText, Music, Code,
    FolderPlus
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
    DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer 
} from '@/components/ui/design-system/SystemDesign';
import { SystemNav } from '@/components/ui/design-system/SystemComponents';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { useSiteContext } from '@/components/identity/SiteContext';
import { AddonGate } from '@/components/integrations/AddonGate';
import StrataBrowser from '@/components/addons/official/StrataBrowser';
import ResearchDeck from '@/components/addons/official/ResearchDeck';

export default function Archives() {
    const { domainData } = useSiteContext();
    const queryClient = useQueryClient();
    const [currentPath, setCurrentPath] = useState('/');
    const [viewMode, setViewMode] = useState('grid');
    const [filter, setFilter] = useState('');
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = React.useRef(null);

    // Fetch Files
    const { data: files = [] } = useQuery({
        queryKey: ['files', currentPath],
        queryFn: async () => {
            const allFiles = await base44.entities.FileRecord.list();
            return allFiles.filter(f => f.path === currentPath);
        },
        initialData: []
    });

    // Create File Mutation (Simulation of upload completion)
    const createFileMutation = useMutation({
        mutationFn: (fileData) => base44.entities.FileRecord.create(fileData),
        onSuccess: () => {
            queryClient.invalidateQueries(['files']);
            toast.success("Asset archived successfully");
        }
    });

    const handleUpload = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setIsUploading(true);
        try {
            // Real upload to base44 storage
            const { file_url } = await base44.integrations.Core.UploadFile({ file });
            
            // Determine category
            let category = 'other';
            if (file.type.startsWith('image/')) category = 'image';
            else if (file.type.startsWith('video/')) category = 'video';
            else if (file.type.startsWith('audio/')) category = 'audio';
            else if (file.type.startsWith('text/') || file.type.includes('json') || file.type.includes('javascript')) category = 'code';
            else if (file.type.includes('pdf') || file.type.includes('document')) category = 'document';

            // Create record
            await createFileMutation.mutateAsync({
                name: file.name,
                path: currentPath,
                url: file_url,
                size: file.size,
                mime_type: file.type,
                category,
                is_private: false,
                tags: []
            });

        } catch (error) {
            console.error(error);
            toast.error("Upload failed: " + error.message);
        } finally {
            setIsUploading(false);
            if (fileInputRef.current) fileInputRef.current.value = '';
        }
    };

    const getIcon = (category) => {
        const iconProps = { className: "w-8 h-8 transition-transform group-hover:scale-110" };
        switch(category) {
            case 'image': return <ImageIcon {...iconProps} className={`${iconProps.className} text-[hsl(var(--color-intent))]`} />;
            case 'video': return <Film {...iconProps} className={`${iconProps.className} text-[hsl(var(--color-review))]`} />;
            case 'audio': return <Music {...iconProps} className={`${iconProps.className} text-[hsl(var(--color-warning))]`} />;
            case 'code': return <Code {...iconProps} className={`${iconProps.className} text-[hsl(var(--color-execution))]`} />;
            case 'document': return <FileText {...iconProps} className={`${iconProps.className} text-[hsl(var(--color-system))]`} />;
            default: return <File {...iconProps} className={`${iconProps.className} text-neutral-500`} />;
        }
    };

    // Derived Folder Structure (Virtual)
    const folders = ['Project Alpha', 'Assets', 'Contracts', 'Logs'];

    // Check for Research Deck Addon
    const { data: researchDeckInstalled } = useQuery({
        queryKey: ['check_research_deck'],
        queryFn: async () => {
            const installs = await base44.entities.InstalledAddon.list();
            const items = await base44.entities.MarketplaceItem.list();
            const deckItem = items.find(i => i.name === 'Research Deck');
            return deckItem && installs.some(ins => ins.addon_id === deckItem.id);
        }
    });

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <HumorousLoader delay={1000} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <HardDrive className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">ARCHIVES</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">
                                        {domainData.family === 'Xibalba' ? 'Asset Vault' : 'System Storage'}
                                    </IntentText>
                                </div>
                            </div>
                            
                            <input 
                                type="file" 
                                ref={fileInputRef} 
                                className="hidden" 
                                onChange={handleUpload} 
                            />
                            
                            <Button 
                                onClick={() => fileInputRef.current?.click()} 
                                disabled={isUploading}
                                className="w-full bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black"
                            >
                                {isUploading ? (
                                    <span className="animate-pulse">UPLOADING...</span>
                                ) : (
                                    <><Upload className="w-4 h-4 mr-2" /> UPLOAD ASSET</>
                                )}
                            </Button>

                            <div className="mt-6 space-y-2">
                                <Layer level="orientation" className="p-3 flex justify-between items-center">
                                    <StateText>Storage Used</StateText>
                                    <StateText className="font-mono text-[hsl(var(--color-execution))]">42%</StateText>
                                </Layer>
                                <div className="h-1 w-full bg-neutral-900 rounded-full overflow-hidden">
                                    <div className="h-full bg-[hsl(var(--color-execution))] w-[42%]" />
                                </div>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none flex flex-col">
                            <OrientingText className="mb-4">DIRECTORY STRUCTURE</OrientingText>
                            <SystemNav 
                                items={[
                                    { id: '/', label: 'Root', icon: HardDrive, type: 'settled' },
                                    ...folders.map(f => ({ id: `/${f}`, label: f, icon: Folder, type: 'settled' }))
                                ]}
                                activeId={currentPath}
                                onSelect={setCurrentPath}
                            />
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
                right={
                    <HumorousLoader delay={1600} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="p-0 flex flex-col h-full overflow-hidden">
                            {/* We split the view: Top is Strata Knowledge OR Research Deck */}
                            <div className="h-1/2 border-b border-white/5 flex flex-col">
                                {researchDeckInstalled ? (
                                    <ResearchDeck />
                                ) : (
                                    <AddonGate
                                        addonName="Strata Knowledge"
                                        integrationType="notion"
                                        title="External Memory"
                                        icon={HardDrive}
                                    >
                                        <StrataBrowser />
                                    </AddonGate>
                                )}
                            </div>

                            <div className="h-1/2 flex flex-col">
                                {/* Local Toolbar */}
                                <div className="h-10 border-b border-white/5 flex items-center justify-between px-4 bg-neutral-900/50">
                                    <div className="flex items-center gap-2 text-xs text-neutral-400">
                                        <HardDrive className="w-3 h-3" />
                                        <span className="font-mono">LOCAL STORAGE</span>
                                        <span className="font-mono text-[hsl(var(--color-execution))]">{currentPath}</span>
                                    </div>
                                    {/* View controls */}
                                    <div className="flex items-center gap-1">
                                         <Button 
                                            size="icon" 
                                            variant="ghost" 
                                            className="h-6 w-6"
                                            onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
                                        >
                                            {viewMode === 'grid' ? <List className="w-3 h-3" /> : <Grid className="w-3 h-3" />}
                                        </Button>
                                    </div>
                                </div>

                                {/* File Grid/List (Local) */}
                                <div className="flex-1 overflow-y-auto p-4">
                                    {files.length === 0 ? (
                                        <div className="h-full flex flex-col items-center justify-center opacity-30 border-2 border-dashed border-white/5 rounded-xl">
                                            <Upload className="w-8 h-8 mb-2" />
                                            <OrientingText className="text-xs">Local Assets</OrientingText>
                                        </div>
                                    ) : (
                                        <div className={cn(
                                            viewMode === 'grid' ? "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4" : "space-y-2"
                                        )}>
                                            {files
                                                .filter(f => (f.name || '').toLowerCase().includes(filter.toLowerCase()))
                                                .map(file => (
                                                <div 
                                                    key={file.id} 
                                                    className={cn(
                                                        "group relative border border-white/5 bg-neutral-900/50 hover:bg-neutral-900 transition-all cursor-pointer overflow-hidden",
                                                        viewMode === 'grid' ? "rounded-lg aspect-square flex flex-col items-center justify-center p-2 text-center" : "rounded p-2 flex items-center gap-4"
                                                    )}
                                                >
                                                    <div className={cn("min-w-0", viewMode === 'grid' ? "w-full" : "flex-1")}>
                                                        {getIcon(file.category)}
                                                        <IntentText className="truncate font-medium text-xs mt-2 group-hover:text-[hsl(var(--color-execution))] transition-colors">
                                                            {file.name}
                                                        </IntentText>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
            />
        </div>
    );
}