import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Button } from "@/components/ui/button";
import { Globe, Wifi } from 'lucide-react';

export default function NetworkLanding() {
    return (
        <PublicLayout theme="blue-500">
            
            {/* HERO */}
            <section className="pt-32 pb-20 px-6 relative">
                <div className="max-w-7xl mx-auto text-center relative z-10">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-mono uppercase tracking-widest mb-8 backdrop-blur-md">
                        <Globe className="w-3 h-3" />
                        <span>Global Mesh</span>
                    </div>
                    
                    <h1 className="text-5xl md:text-7xl font-serif font-light text-white mb-6 drop-shadow-2xl">
                        The <span className="italic text-blue-400">Network</span> State
                    </h1>
                    
                    <p className="text-xl text-neutral-300 max-w-2xl mx-auto leading-relaxed mb-12 font-light">
                        A decentralized physical infrastructure network (DePIN) owned by its users.
                        Connect your node. Earn credits. Secure the mesh.
                    </p>

                    <div className="flex flex-col md:flex-row items-center justify-center gap-4">
                        <Button className="h-12 px-8 bg-blue-500 text-white hover:bg-blue-600 rounded-full font-bold shadow-[0_0_20px_-5px_rgba(59,130,246,0.5)]">
                            View Network Map
                        </Button>
                        <Button variant="outline" className="h-12 px-8 border-white/10 text-white hover:bg-white/5 rounded-full backdrop-blur-sm">
                            Run a Relay Node
                        </Button>
                    </div>
                </div>
            </section>

            {/* LIVE MAP PLACEHOLDER */}
            <section className="w-full h-[600px] bg-black/50 border-y border-white/5 relative overflow-hidden group backdrop-blur-sm">
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop')] bg-cover bg-center opacity-30 grayscale mix-blend-screen" />
                
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center space-y-4">
                        <div className="w-20 h-20 mx-auto rounded-full border border-blue-500/30 flex items-center justify-center animate-[pulse_3s_infinite] bg-black/40 backdrop-blur-md">
                            <Wifi className="w-8 h-8 text-blue-500" />
                        </div>
                        <div className="text-blue-400 font-mono text-sm tracking-widest">LIVE FEED ESTABLISHED</div>
                        <div className="text-4xl font-bold text-white drop-shadow-lg">102,491 ACTIVE NODES</div>
                    </div>
                </div>

                {/* HUD Elements */}
                <div className="absolute top-8 left-8 flex flex-col gap-2 p-4 rounded-lg bg-black/40 backdrop-blur-md border border-white/5">
                    <div className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">Regions</div>
                    <div className="text-white font-bold">NA-EAST, EU-WEST, APAC-SG</div>
                </div>
                <div className="absolute bottom-8 right-8 flex flex-col gap-2 text-right p-4 rounded-lg bg-black/40 backdrop-blur-md border border-white/5">
                    <div className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest">Total Bandwidth</div>
                    <div className="text-white font-bold">45.2 TB/s</div>
                </div>
            </section>

        </PublicLayout>
    );
}