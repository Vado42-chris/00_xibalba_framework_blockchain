import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useSiteContext } from '@/components/identity/SiteContext';
import XiIoDashboard from '@/components/dashboards/XiIoDashboard';
import ProjectDashboard from '@/components/projects/ProjectDashboard';
import XibalbaDashboard from '@/components/dashboards/XibalbaDashboard';
import VeilriftDashboard from '@/components/dashboards/VeilriftDashboard';
import NumericalDashboard from '@/components/dashboards/NumericalDashboard';
import ObserverDashboard from '@/components/dashboards/ObserverDashboard';
import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import { base44 } from '@/api/base44Client';
import UserGreeting from '@/components/identity/UserGreeting';
import SystemStatusWidget from '@/components/dashboards/widgets/SystemStatusWidget';
import SystemStatusSimple from '@/components/dashboards/widgets/SystemStatusSimple';
import ConciergeDashboard from '@/components/dashboards/ConciergeDashboard';
import { InsightEngineModule } from '@/components/intelligence/InsightEngineModule';
import BusinessHealthWidget from '@/components/dashboards/widgets/BusinessHealthWidget';
import PlainInsightEngine from '@/components/intelligence/PlainInsightEngine';
import { LayoutGrid } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

// Force rebuild
export default function Dashboard() {
    const { domainData } = useSiteContext();
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const isDemo = searchParams.get('demo') === 'true';
    const isConcierge = searchParams.get('concierge') === 'true';
    const [userRole, setUserRole] = useState(null);

    useEffect(() => {
        base44.auth.me()
            .then(u => setUserRole(u.role)) // Assuming role is on user object or we derive it
            .catch(() => setUserRole('guest'));
    }, []);

    // Force Observer Dashboard for Demo or Guests/Observers
    // We assume 'user' role is Observer for now, 'admin' is Sovereign
    // Or we rely on explicit demo flag
    const showObserverView = isDemo || userRole === 'guest' || (userRole === 'user' && domainData.family === 'XI-IO'); 

    if (isConcierge) {
        return (
            <div className="h-full w-full overflow-hidden bg-transparent">
                <ConciergeDashboard />
            </div>
        );
    }

    if (showObserverView) {
        return (
            <div className="h-full w-full overflow-hidden bg-transparent">
                <ObserverDashboard />
                <TutorialOverlay 
                    tutorialId="observer_intro"
                    steps={[
                        { title: "Command Center", content: "This is your tech demo dashboard. Explore the tools to build your own platform.", position: "center" },
                        { title: "The Workshop", content: "Access the Studio, Builder, and Forge to create your white-label product.", position: "right" },
                        { title: "Simulation", content: "Experience the 'Hard Fork' to sovereignty.", position: "bottom-right" }
                    ]}
                />
            </div>
        );
    }

    return (
        <div className="h-full w-full overflow-hidden bg-transparent flex flex-col">
            <div className="px-6 pt-6 shrink-0">
                <UserGreeting />
            </div>
            
            <div className="flex-1 overflow-hidden">
                {domainData.family === 'Xibalba' && <XibalbaDashboard />}
                {domainData.family === 'Veilrift' && <VeilriftDashboard />}
                {domainData.family === 'XI-IO' && (
                    <div className="h-full flex flex-col">
                        <div className="flex-1 overflow-y-auto">
                            {/* SMART VIEW LINK */}
                            <div className="px-6 py-2 flex justify-end">
                                <Button 
                                    onClick={() => window.location.href = '/SmartStart'}
                                    variant="outline"
                                    className="border-white/10 hover:bg-white/5 text-xs"
                                >
                                    <LayoutGrid className="w-3 h-3 mr-2" />
                                    Open Smart View
                                </Button>
                            </div>

                            {/* ENHANCED WIDGETS */}
                            <div className="px-6 pb-2">
                                <BusinessHealthWidget />
                            </div>

                            {/* SEED001 EXECUTION PROTOCOL WIDGET */}
                            <div className="px-6 pb-2">
                                <div className="p-4 rounded-lg border border-emerald-500/20 bg-emerald-500/5 flex items-center justify-between">
                                    <div>
                                        <h3 className="text-emerald-400 font-bold flex items-center gap-2">
                                            <span className="animate-pulse w-2 h-2 rounded-full bg-emerald-500"></span>
                                            PROTOCOL ACTIVE: SEED001
                                        </h3>
                                        <p className="text-sm text-neutral-400 mt-1">
                                            You are authorized to execute the final validation journey.
                                        </p>
                                    </div>
                                    <button 
                                        onClick={() => window.location.href = '/SeedJourney'}
                                        className="bg-emerald-500 text-black font-bold px-4 py-2 rounded hover:bg-emerald-400 transition-colors uppercase text-xs tracking-wider"
                                    >
                                        Execute Sequence
                                    </button>
                                </div>
                            </div>

                            {/* AI INSIGHT ENGINE */}
                            <div className="px-6 pb-4">
                                <PlainInsightEngine />
                            </div>
                            <ProjectDashboard />
                            <div className="p-6 border-t border-white/10 opacity-50 grayscale hover:opacity-100 hover:grayscale-0 transition-all duration-500">
                                <h3 className="text-xs font-bold text-neutral-500 mb-4 uppercase tracking-widest">Global Metrics</h3>
                                <XiIoDashboard />
                            </div>
                        </div>
                    </div>
                )}
                {domainData.family === 'Numerical' && <NumericalDashboard />}
            </div>

            <TutorialOverlay 
                tutorialId="dashboard_intro"
                steps={[
                    { title: "System Overview", content: "Welcome to your command center. This dashboard aggregates all vital system data.", position: "center" },
                    { title: "Navigation", content: "Use the sidebar to access specialized modules like Creator Studio and Server Control.", position: "top-left" },
                    { title: "Status", content: "Monitor global system health and alerts at a glance.", position: "top-right" }
                ]}
            />
        </div>
    );
}