import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { ShieldAlert, AlertCircle, CheckCircle2, Info, Activity, Clock, Search, ArrowRight, Layout, Link, Workflow, Database, Layers } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant, IntentText, StateText, SemanticDot, Layer, AtomicParagraph, OrientingText } from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { SystemLog } from '@/components/ui/design-system/SystemContent';
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import BrandComplianceWargame from "@/components/audit/BrandComplianceWargame";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { GuideBox } from '@/components/ui/GuideBox';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';

const UXAuditTab = () => {
    const navigate = useNavigate();
    
    // Map of the core application flow
    const coreFlows = [
        {
            id: 'search',
            name: 'Search / Discovery',
            path: 'SearchResults',
            status: 'dead_end',
            description: 'User finds information but has no direct way to act on it.',
            missing_actions: ['Add to Project', 'Edit in Studio', 'Share Result'],
            fractal_score: 40
        },
        {
            id: 'marketplace',
            name: 'Marketplace',
            path: 'Marketplace',
            status: 'partial',
            description: 'User installs items but configuration happens elsewhere.',
            missing_actions: ['Configure Immediately', 'View Documentation', 'Test Run'],
            fractal_score: 60
        },
        {
            id: 'studio',
            name: 'Design Studio',
            path: 'Studio',
            status: 'functional',
            description: 'Good interactivity, but save actions are generic.',
            missing_actions: ['Save as Template', 'Apply to Multiple Pages'],
            fractal_score: 80
        },
        {
            id: 'content',
            name: 'Content Manager',
            path: 'ContentManager',
            status: 'dead_end',
            description: 'Pages are created but linking them requires manual navigation.',
            missing_actions: ['View Live', 'Add to Navigation', 'SEO Check'],
            fractal_score: 50
        }
    ];

    return (
        <div className="h-full flex flex-col p-6 space-y-4 overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {coreFlows.map((flow) => (
                    <SystemCard
                        key={flow.id}
                        title={flow.name}
                        subtitle={`Path: /${flow.path}`}
                        icon={Layout}
                        status={flow.status === 'functional' ? 'active' : flow.status === 'partial' ? 'warning' : 'error'}
                        metric={`${flow.fractal_score}%`}
                        // Demonstrate the FIX using the new SystemCard capabilities
                        primaryAction={{
                            label: "Fix Flow",
                            onClick: () => navigate(createPageUrl(flow.path)),
                            icon: Workflow
                        }}
                        secondaryActions={[
                            { label: "View Specs", onClick: () => {} },
                            { label: "Log Ticket", onClick: () => {} }
                        ]}
                    >
                        <div className="space-y-4">
                            <p className="text-xs text-neutral-400 leading-relaxed">
                                {flow.description}
                            </p>
                            
                            <div className="bg-neutral-950/50 rounded p-3 border border-white/5">
                                <div className="text-[10px] font-bold text-red-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                                    <AlertCircle className="w-3 h-3" /> Missing Actionables
                                </div>
                                <div className="space-y-1">
                                    {flow.missing_actions.map(action => (
                                        <div key={action} className="flex items-center gap-2 text-xs text-neutral-500">
                                            <div className="w-1 h-1 rounded-full bg-red-500/50" />
                                            {action}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </SystemCard>
                ))}
            </div>
        </div>
    );
};

export default function Audit() {
    const [activeTab, setActiveTab] = useState('ux');
    const [selectedLog, setSelectedLog] = useState(null);
    const [filter, setFilter] = useState('');

    const logState = { selectedLog, setSelectedLog, filter, setFilter };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            {activeTab === 'ux' && (
                <FluidGrid
                    left={
                        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                            <Quadrant type="orientation" step="1" title="Flow Audit" className="border-b">
                                <div className="flex justify-between items-end mb-6">
                                    <div>
                                        <div className="flex items-center gap-2 mb-2">
                                            <ShieldAlert className="w-4 h-4 text-orange-500" />
                                            <OrientingText className="tracking-widest font-bold text-orange-500">UX AUDITOR</OrientingText>
                                        </div>
                                        <IntentText className="text-2xl font-light">Flow Continuity</IntentText>
                                    </div>
                                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                                        <TabsList className="bg-neutral-900 border border-white/10">
                                            <TabsTrigger value="ux">UX</TabsTrigger>
                                            <TabsTrigger value="logs">Logs</TabsTrigger>
                                            <TabsTrigger value="compliance">Compliance</TabsTrigger>
                                        </TabsList>
                                    </Tabs>
                                </div>
                                <GuideBox title="Dead End Detection">
                                    <p className="mb-2">Analysis of user flows that terminate without actionable next steps.</p>
                                </GuideBox>
                            </Quadrant>
                            <Quadrant type="state" step="3" title="Metrics" className="border-t-0 rounded-t-none">
                                <SystemCard
                                    title="Flow Score"
                                    metric="57%"
                                    status="warning"
                                    icon={Activity}
                                    subtitle="Continuity Index"
                                />
                            </Quadrant>
                        </QuadrantGrid>
                    }
                    right={
                        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                            <Quadrant type="intent" step="2" title="Analysis" dominance="dominant" className="p-0 flex flex-col border-b">
                                <UXAuditTab />
                            </Quadrant>
                            <Quadrant type="intent" step="4" title="Outcome" dominance="supporting" className="border-t-0 rounded-t-none">
                                 <div className="p-4 rounded bg-neutral-900/50 border border-white/5">
                                    <StateText className="mb-2">RECOMMENDATION</StateText>
                                    <p className="text-xs text-neutral-400">Implement ActionDock on 4 pages to increase continuity score.</p>
                                </div>
                            </Quadrant>
                        </QuadrantGrid>
                    }
                />
            )}

            {activeTab === 'logs' && (
                <FluidGrid
                    left={
                        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                            <Quadrant type="orientation" step="1" title="Stream" className="border-b">
                                <div className="flex justify-between items-end mb-6">
                                    <div>
                                        <div className="flex items-center gap-2 mb-2">
                                            <Activity className="w-4 h-4 text-blue-500" />
                                            <OrientingText className="tracking-widest font-bold text-blue-500">SYSTEM LOGS</OrientingText>
                                        </div>
                                        <IntentText className="text-2xl font-light">Event Stream</IntentText>
                                    </div>
                                    <Tabs value={activeTab} onValueChange={setActiveTab}>
                                        <TabsList className="bg-neutral-900 border border-white/10">
                                            <TabsTrigger value="ux">UX</TabsTrigger>
                                            <TabsTrigger value="logs">Logs</TabsTrigger>
                                            <TabsTrigger value="compliance">Compliance</TabsTrigger>
                                        </TabsList>
                                    </Tabs>
                                </div>
                                <SystemLogsTab mode="orientation" state={logState} />
                            </Quadrant>
                            <Quadrant type="state" step="3" title="Events" className="border-t-0 rounded-t-none p-0 flex flex-col">
                                <SystemLogsTab mode="list" state={logState} />
                            </Quadrant>
                        </QuadrantGrid>
                    }
                    right={
                        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                            <Quadrant type="intent" step="2" title="Analysis" dominance="dominant" className="p-0 flex flex-col border-b">
                                <SystemLogsTab mode="detail" state={logState} />
                            </Quadrant>
                            <Quadrant type="intent" step="4" title="Readiness" dominance="supporting" className="border-t-0 rounded-t-none">
                                <SystemLogsTab mode="summary" state={logState} />
                            </Quadrant>
                        </QuadrantGrid>
                    }
                />
            )}
            
            {activeTab === 'compliance' && (
                <div className="h-full relative flex flex-col">
                     <div className="absolute top-4 right-4 z-50">
                        <Tabs value={activeTab} onValueChange={setActiveTab}>
                            <TabsList className="bg-neutral-900 border border-white/10">
                                <TabsTrigger value="ux">UX</TabsTrigger>
                                <TabsTrigger value="logs">Logs</TabsTrigger>
                                <TabsTrigger value="compliance">Compliance</TabsTrigger>
                            </TabsList>
                        </Tabs>
                    </div>
                    <BrandComplianceWargame />
                </div>
            )}
        </div>
    );
}

function SystemLogsTab({ mode, state }) {
    const { selectedLog, setSelectedLog, filter, setFilter } = state || {};

    const { data: logs = [] } = useQuery({
        queryKey: ['logs'],
        queryFn: () => base44.entities.Log.list('-timestamp'),
        initialData: []
    });

    const filtered = logs.filter(l => 
        (l.content || '').toLowerCase().includes((filter || '').toLowerCase()) || 
        (l.type || '').toLowerCase().includes((filter || '').toLowerCase())
    );
    
    const securityEvents = logs.filter(l => l.type === 'security').length;

    // --- SYSTEM ANALYSIS (For Summary/Readiness) ---
    const { data: customers = [] } = useQuery({ queryKey: ['audit_cust'], queryFn: () => base44.entities.Customer.list(), initialData: [] });
    const { data: assets = [] } = useQuery({ queryKey: ['audit_asset'], queryFn: () => base44.entities.Asset.list(), initialData: [] });
    const { data: orders = [] } = useQuery({ queryKey: ['audit_order'], queryFn: () => base44.entities.Order.list(), initialData: [] });
    const { data: agents = [] } = useQuery({ queryKey: ['audit_agent'], queryFn: () => base44.entities.Agent.list(), initialData: [] });

    const analysis = [
        { area: 'CRM', status: 'Functional', entity: 'Customer', count: customers.length, note: 'Live database connection' },
        { area: 'Finance', status: 'Functional', entity: 'Asset', count: assets.length, note: 'Real-time valuation active' },
        { area: 'Commerce', status: 'Functional', entity: 'Order', count: orders.length, note: 'Order processing live' },
        { area: 'DistroFactory', status: 'Operational', entity: 'MarketplaceItem', count: 'Seed 001', note: 'White Label Engine Ready' },
        { area: 'Intelligence', status: 'Functional', entity: 'Agent', count: agents.length, note: 'Agents standing by' },
    ];

    const getIcon = (type) => {
        switch(type) {
            case 'security': return ShieldAlert;
            case 'system': return Activity;
            case 'error': return AlertCircle;
            default: return Info;
        }
    };

    if (mode === 'orientation') {
        return (
            <div className="space-y-4">
                <div className="relative">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                    <Input 
                        placeholder="Search logs..." 
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                        className="pl-8 bg-neutral-900 border-white/10 h-8 text-xs"
                    />
                </div>
                <div className="flex gap-2">
                    <Badge variant="outline" className="border-green-500/20 text-green-500 bg-green-500/10 font-mono w-full justify-center">LIVE</Badge>
                    <Badge variant="outline" className="border-red-500/20 text-red-500 bg-red-500/10 w-full justify-center">{securityEvents} ALERTS</Badge>
                </div>
            </div>
        );
    }

    if (mode === 'list') {
        return (
            <SystemLog 
                logs={filtered}
                selectedId={selectedLog?.id}
                onSelect={setSelectedLog}
            />
        );
    }

    if (mode === 'detail') {
        if (!selectedLog) {
            return (
                <div className="flex flex-col h-full">
                    <div className="p-8 border-b border-white/5 bg-neutral-900/30">
                        <div className="flex items-center gap-2 mb-4">
                            <Activity className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                            <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">SYSTEM ANALYSIS</OrientingText>
                        </div>
                        <IntentText className="text-xl font-light mb-2">Launch Readiness Report</IntentText>
                        <StateText className="text-xs opacity-60">Automated diagnostic of system functionality and data integrity.</StateText>
                    </div>
                    <div className="p-8 space-y-4 overflow-y-auto">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {analysis.map((item, i) => (
                                <SystemCard
                                    key={i}
                                    title={item.area}
                                    subtitle={item.note}
                                    status={item.status === 'Functional' ? 'active' : 'error'}
                                    metric={item.count !== '-' ? item.count : ''}
                                    icon={item.status === 'Functional' ? CheckCircle2 : AlertCircle}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            );
        }
        return (
            <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300">
                <SystemDetailHeader
                    title={selectedLog.content}
                    subtitle={new Date(selectedLog.timestamp).toLocaleString()}
                    category={`${selectedLog.type} EVENT`}
                    icon={getIcon(selectedLog.type)}
                />
                <div className="p-8 space-y-6 overflow-y-auto flex-1">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                            <StateText className="mb-1">Origin</StateText>
                            <div className="font-mono text-xs text-white">{selectedLog.remote_identity || "System"}</div>
                        </div>
                        <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                            <StateText className="mb-1">Status</StateText>
                            <div className="font-mono text-xs text-white uppercase">{selectedLog.status || "LOGGED"}</div>
                        </div>
                    </div>
                    <Layer level="state">
                        <OrientingText className="mb-2">RAW PAYLOAD</OrientingText>
                        <pre className="font-mono text-[10px] text-neutral-400 whitespace-pre-wrap bg-black/30 p-4 rounded border border-white/5 overflow-x-auto">
                            {JSON.stringify(selectedLog, null, 2)}
                        </pre>
                    </Layer>
                </div>
            </div>
        );
    }

    if (mode === 'summary') {
        return (
            <div className="bg-neutral-900/50 rounded p-3 border border-white/5">
                <OrientingText className="mb-2 text-[hsl(var(--color-intent))]">HEALTH CHECK</OrientingText>
                <div className="space-y-2">
                    {analysis.slice(0, 5).map((item, i) => (
                        <div key={i} className="flex items-center justify-between text-[10px]">
                            <span className="text-neutral-400">{item.area}</span>
                            <div className="flex items-center gap-2">
                                <span className={item.status === 'Functional' ? 'text-green-500' : 'text-orange-500'}>{item.status}</span>
                                {item.status !== 'Functional' && <AlertCircle className="w-3 h-3 text-orange-500" />}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    return null;
}