import React, { useState } from 'react';
import { 
    Shield, Target, Activity, AlertTriangle, 
    Grid, Map, Cpu, Network, Globe, Users, 
    DollarSign, Layout
} from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer, 
    AtomicParagraph
} from '@/components/ui/design-system/System';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { cn } from '@/lib/utils';
import { Play, CheckCircle2 } from 'lucide-react';

/* -------------------------------------------------------------------------- */
/*                                DATA & MODELS                               */
/* -------------------------------------------------------------------------- */

const BODIES = [
    { id: 'nodes', name: 'Infrastructure', icon: ServerIcon, status: 'stable', health: 100, drift: 0 },
    { id: 'network', name: 'Network Topology', icon: Network, status: 'stable', health: 100, drift: 0 },
    { id: 'comms', name: 'Communications', icon: MessageIcon, status: 'stable', health: 100, drift: 0 },
    { id: 'finance', name: 'Treasury', icon: DollarSign, status: 'stable', health: 100, drift: 0 },
    { id: 'crm', name: 'Client Relations', icon: Users, status: 'stable', health: 100, drift: 0 },
    { id: 'content', name: 'Content Engine', icon: Layout, status: 'stable', health: 100, drift: 0 },
    { id: 'agents', name: 'Agent Swarm', icon: Cpu, status: 'stable', health: 100, drift: 0 },
    { id: 'reaper', name: 'Security (Reaper)', icon: Shield, status: 'stable', health: 100, drift: 0 },
    { id: 'market', name: 'Marketplace', icon: Globe, status: 'stable', health: 100, drift: 0 },
    { id: 'strategy', name: 'Business Logic', icon: Target, status: 'warning', health: 60, drift: 20, note: "Goals disconnected from real metrics" },
];

const AUDIT_LOG = [
    { id: 8, type: 'success', location: 'Settings', issue: 'Quadrant Grid Implementation', severity: 'low', fix: 'Resolved' },
    { id: 9, type: 'success', location: 'Legal', issue: 'Semantic Tokens', severity: 'low', fix: 'Resolved' },
    { id: 10, type: 'success', location: 'UserProfile', issue: 'Layout Standardization', severity: 'low', fix: 'Resolved' },
    { id: 6, type: 'success', location: 'ReaperSpace', issue: 'FluidGrid Integration', severity: 'low', fix: 'Resolved' },
    { id: 7, type: 'success', location: 'ControlPanel', issue: 'Color Token Standardization', severity: 'low', fix: 'Resolved' },
];

function ServerIcon(props) { return <Cpu {...props} />; }
function MessageIcon(props) { return <Activity {...props} />; }

/* -------------------------------------------------------------------------- */
/*                                COMPONENTS                                  */
/* -------------------------------------------------------------------------- */

const HealthMatrix = ({ bodies }) => (
    <div className="grid grid-cols-2 gap-4">
        {bodies.map(b => (
            <div key={b.id} className="p-3 bg-neutral-900/50 border border-white/5 rounded flex items-center justify-between group hover:border-[hsl(var(--color-intent))] transition-colors">
                <div className="flex items-center gap-3">
                    <div className={cn("w-8 h-8 rounded flex items-center justify-center border border-white/5", 
                        b.status === 'critical' ? "bg-[hsl(var(--color-error))]/10 text-[hsl(var(--color-error))]" : 
                        b.status === 'warning' ? "bg-[hsl(var(--color-warning))]/10 text-[hsl(var(--color-warning))]" : 
                        "bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))]"
                    )}>
                        <b.icon className="w-4 h-4" />
                    </div>
                    <div>
                        <IntentText className="text-sm font-bold">{b.name}</IntentText>
                        <StateText className="text-[10px] opacity-50">Drift: {b.drift}%</StateText>
                    </div>
                </div>
                <div className="text-right">
                    <div className="font-mono text-sm font-bold text-white">{b.health}%</div>
                    <SemanticDot type={b.status === 'critical' ? 'error' : b.status === 'warning' ? 'warning' : 'active'} />
                </div>
            </div>
        ))}
    </div>
);

const RoadmapTimeline = () => (
    <div className="space-y-6 relative border-l border-white/10 ml-3 pl-6 py-2">
        <div className="relative">
            <div className="absolute -left-[29px] top-1 w-3 h-3 rounded-full bg-[hsl(var(--color-execution))] border-2 border-neutral-950" />
            <IntentText className="text-[hsl(var(--color-execution))] mb-1">PHASE 1: UNIFICATION (COMPLETED)</IntentText>
            <AtomicParagraph className="text-neutral-400 text-xs">
                Standardize all 10 distinct operational domains (Bodies) onto the "FluidGrid" and "Quadrant" physics engine. 
                Eliminate legacy layouts ("MasterDetail"). Enforce "Semantic 7" color theory.
            </AtomicParagraph>
        </div>
        <div className="relative">
            <div className="absolute -left-[29px] top-1 w-3 h-3 rounded-full bg-neutral-700 border-2 border-neutral-950 animate-pulse" />
            <IntentText className="mb-1 text-white">PHASE 2: THE 1-BODY SOLUTION (IN PROGRESS)</IntentText>
            <AtomicParagraph className="text-neutral-500 text-xs">
                Deploy the "Omni-Dashboard" (Meta-Consciousness). A single surface that ingests telemetry from all 10 bodies 
                and provides a unified command line (CLI) and visual HUD for cross-domain orchestration.
            </AtomicParagraph>
        </div>
        <div className="relative opacity-40">
            <div className="absolute -left-[29px] top-1 w-3 h-3 rounded-full bg-neutral-800 border-2 border-neutral-950" />
            <IntentText className="mb-1">PHASE 3: AUTONOMOUS GOVERNANCE</IntentText>
            <AtomicParagraph className="text-neutral-600 text-xs">
                Hand over operational control of Tier-2 systems (Logistics, Content) to the "Agent Swarm". 
                Human operator moves to "Observer" status, intervening only on "Critical" alerts.
            </AtomicParagraph>
        </div>
    </div>
);

/* -------------------------------------------------------------------------- */
/*                                MAIN VIEW                                   */
/* -------------------------------------------------------------------------- */

export default function StrategicAudit() {
    const [activeTab, setActiveTab] = useState('report');

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Shield className="w-4 h-4 text-[hsl(var(--color-warning))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-warning))]">STRATEGIC AUDIT</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">System Integrity Report</IntentText>
                                </div>
                                <div className="flex items-center gap-2">
                                     <Badge variant="outline" className="border-[hsl(var(--color-warning))]/20 text-[hsl(var(--color-warning))] bg-[hsl(var(--color-warning))]/10">
                                         WARGAME ACTIVE
                                     </Badge>
                                </div>
                            </div>
                            
                            <Layer level="orientation" className="p-4 flex items-center justify-between">
                                <div>
                                    <StateText>System Health</StateText>
                                    <div className="text-2xl font-light text-white">99<span className="text-sm text-neutral-500">/100</span></div>
                                </div>
                                <div className="text-right">
                                    <StateText>Drift Detected</StateText>
                                    <div className="text-2xl font-light text-[hsl(var(--color-execution))]">0<span className="text-sm text-neutral-500">%</span></div>
                                </div>
                            </Layer>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">THE 10 BODIES</OrientingText>
                            <div className="h-full overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                <HealthMatrix bodies={BODIES} />
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col">
                            <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
                                <div className="px-6 pt-4 border-b border-white/5 bg-neutral-900/50">
                                    <TabsList className="bg-transparent h-10 p-0 gap-6">
                                        <TabsTrigger value="report" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-warning))] data-[state=active]:text-[hsl(var(--color-warning))] text-xs uppercase tracking-wider">
                                            Audit Findings
                                        </TabsTrigger>
                                        <TabsTrigger value="wargame" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-error))] data-[state=active]:text-[hsl(var(--color-error))] text-xs uppercase tracking-wider">
                                            Wargame Sim
                                        </TabsTrigger>
                                        <TabsTrigger value="roadmap" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-execution))] data-[state=active]:text-[hsl(var(--color-execution))] text-xs uppercase tracking-wider">
                                            The 1-Body Solution
                                        </TabsTrigger>
                                    </TabsList>
                                </div>

                                <div className="flex-1 overflow-y-auto p-8 bg-neutral-950">
                                    <TabsContent value="report" className="mt-0 space-y-8 animate-in fade-in slide-in-from-right-4">
                                        <div className="space-y-4">
                                            <div className="flex items-center gap-2 text-[hsl(var(--color-execution))]">
                                                <CheckCircle2 className="w-5 h-5" />
                                                <IntentText className="text-xl">Executive Summary</IntentText>
                                            </div>
                                            <AtomicParagraph className="text-lg leading-relaxed text-neutral-300">
                                                All 10 operational bodies have been successfully unified under the "FluidGrid" standard. 
                                                System integrity is nominal. Cross-domain interoperability is now enabled via the shared physics engine.
                                                The "Content Engine" and "Communications" modules have been fully remediated.
                                            </AtomicParagraph>
                                        </div>

                                        <div className="space-y-4">
                                            <OrientingText>VIOLATION LOG</OrientingText>
                                            <div className="border border-white/5 rounded-lg divide-y divide-white/5 bg-neutral-900/30">
                                                {AUDIT_LOG.map(log => (
                                                    <div key={log.id} className="p-4 flex items-start gap-4">
                                                        <div className={cn("mt-1 w-2 h-2 rounded-full", 
                                                            log.type === 'violation' ? "bg-[hsl(var(--color-error))]" : 
                                                            log.type === 'warning' ? "bg-[hsl(var(--color-warning))]" : "bg-[hsl(var(--color-execution))]"
                                                        )} />
                                                        <div className="flex-1">
                                                            <div className="flex justify-between">
                                                                <IntentText className="font-bold text-sm">{log.issue}</IntentText>
                                                                <Badge variant="outline" className="text-[10px] border-white/10">{log.location}</Badge>
                                                            </div>
                                                            <StateText className="text-xs mt-1 opacity-60">Status: {log.fix}</StateText>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </TabsContent>

                                    <TabsContent value="wargame" className="mt-0 space-y-8 animate-in fade-in slide-in-from-right-4">
                                        <div className="p-6 border border-[hsl(var(--color-error))]/20 bg-[hsl(var(--color-error))]/5 rounded-lg">
                                            <div className="flex items-center gap-3 mb-4">
                                                <Target className="w-6 h-6 text-[hsl(var(--color-error))]" />
                                                <IntentText className="text-xl font-bold text-[hsl(var(--color-error))]">SCENARIO: CASCADING FAILURE</IntentText>
                                            </div>
                                            <AtomicParagraph className="mb-6">
                                                Simulating a 40% node failure in the "Network" body while sustaining peak traffic in "Commerce". 
                                                Objective: Verify if "Agents" can autonomously reroute traffic without human intervention.
                                            </AtomicParagraph>
                                            
                                            <div className="space-y-4">
                                                <div className="flex justify-between text-xs uppercase tracking-wider text-neutral-500">
                                                    <span>Node Integrity</span>
                                                    <span>60%</span>
                                                </div>
                                                <div className="h-2 bg-neutral-900 rounded-full overflow-hidden">
                                                    <div className="h-full bg-[hsl(var(--color-error))] w-[60%]" />
                                                </div>
                                                
                                                <div className="flex justify-between text-xs uppercase tracking-wider text-neutral-500">
                                                    <span>Agent Response Latency</span>
                                                    <span>142ms</span>
                                                </div>
                                                <div className="h-2 bg-neutral-900 rounded-full overflow-hidden">
                                                    <div className="h-full bg-[hsl(var(--color-execution))] w-[85%]" />
                                                </div>
                                            </div>

                                            <div className="mt-6 flex justify-end">
                                                <Button className="bg-[hsl(var(--color-error))] hover:bg-[hsl(var(--color-error))]/90 text-white">
                                                    <Play className="w-4 h-4 mr-2" /> RUN SIMULATION
                                                </Button>
                                            </div>
                                        </div>
                                    </TabsContent>

                                    <TabsContent value="roadmap" className="mt-0 space-y-8 animate-in fade-in slide-in-from-right-4">
                                        <div className="flex items-center gap-4 mb-6">
                                            <Map className="w-8 h-8 text-[hsl(var(--color-execution))]" />
                                            <div>
                                                <IntentText className="text-2xl font-light">The 1-Body Solution</IntentText>
                                                <StateText>Architectural Unification Roadmap</StateText>
                                            </div>
                                        </div>
                                        <RoadmapTimeline />
                                    </TabsContent>
                                </div>
                            </Tabs>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}