import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/SystemDesign';
import { SystemNav } from '@/components/ui/design-system/SystemComponents';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
    Scale, FileText, Shield, Gavel, 
    Search, AlertTriangle, CheckCircle2, 
    Plus, FolderOpen 
} from 'lucide-react';

import IPScannerModal from '@/components/legal/IPScannerModal';
import DocGeneratorModal from '@/components/legal/DocGeneratorModal';

export default function Legal() {
    const [view, setView] = useState('docs'); // docs, ip, compliance
    const [isScannerOpen, setIsScannerOpen] = useState(false);
    const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState('business');

    // Fetch Legal Docs
    const { data: legalDocs = [] } = useQuery({
        queryKey: ['legal_docs'],
        queryFn: () => base44.entities.LegalDoc.list(),
        initialData: []
    });

    // Fetch IP Assets
    const { data: ipAssets = [] } = useQuery({
        queryKey: ['ip_assets'],
        queryFn: () => base44.entities.IPAsset.list(),
        initialData: []
    });

    const activeDocs = legalDocs.filter(d => d.status !== 'archived');

    return (
        <div className="h-full w-full bg-transparent overflow-hidden flex flex-col">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Scale className="w-4 h-4 text-neutral-400" />
                                        <OrientingText className="tracking-widest font-bold">SAM LAW</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Legal Engineering</IntentText>
                                </div>
                            </div>

                            <SystemStats 
                                className="grid-cols-1 gap-2"
                                stats={[
                                    { label: "Active Contracts", value: activeDocs.length || "0", icon: FileText },
                                    { label: "IP Assets", value: ipAssets.length || "0", icon: Shield },
                                    { label: "Compliance Score", value: "98%", icon: CheckCircle2, color: "text-[hsl(var(--color-execution))]" }
                                ]}
                            />
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none flex flex-col">
                            <OrientingText className="mb-2 px-4 pt-4">MODULES</OrientingText>
                            <SystemNav
                                items={[
                                    { id: 'docs', label: 'Document Vault', icon: FolderOpen, type: 'active' },
                                    { id: 'ip', label: 'IP Registry', icon: Shield, type: 'active' },
                                    { id: 'compliance', label: 'Compliance Audit', icon: Gavel, type: 'active' }
                                ]}
                                activeId={view}
                                onSelect={setView}
                                className="px-2"
                            />
                            
                            <div className="mt-auto p-4 border-t border-white/5 space-y-2">
                                <Button 
                                    className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90"
                                    onClick={() => setIsGeneratorOpen(true)}
                                >
                                    <Plus className="w-4 h-4 mr-2" /> Draft New Doc
                                </Button>
                                <Button 
                                    variant="outline" 
                                    className="w-full border-white/10 hover:bg-white/5"
                                    onClick={() => setIsScannerOpen(true)}
                                >
                                    <Search className="w-4 h-4 mr-2" /> IP Scan
                                </Button>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col bg-transparent border-none">
                            {view === 'docs' && (
                                <div className="flex flex-col h-full">
                                    <div className="p-4 border-b border-white/5 bg-neutral-900/50 flex justify-between items-center">
                                        <div className="flex gap-4">
                                            {['business', 'home', 'nonprofit'].map(cat => (
                                                <button
                                                    key={cat}
                                                    onClick={() => setSelectedCategory(cat)}
                                                    className={`text-xs uppercase tracking-wider font-bold px-2 py-1 rounded transition-colors ${
                                                        selectedCategory === cat 
                                                            ? 'text-[hsl(var(--color-intent))] bg-[hsl(var(--color-intent))]/10' 
                                                            : 'text-neutral-500 hover:text-white'
                                                    }`}
                                                >
                                                    {cat}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-4 grid grid-cols-1 lg:grid-cols-2 gap-4 content-start">
                                        {legalDocs.filter(d => d.category === selectedCategory).map(doc => (
                                            <div key={doc.id} className="p-4 rounded-lg bg-neutral-900/40 border border-white/10 hover:border-white/20 transition-all group">
                                                <div className="flex justify-between items-start mb-2">
                                                    <div className="flex items-center gap-2">
                                                        <FileText className="w-4 h-4 text-neutral-400" />
                                                        <span className="font-bold text-sm text-white">{doc.title}</span>
                                                    </div>
                                                    <Badge variant="outline" className="text-[10px] border-white/10">{doc.status.toUpperCase()}</Badge>
                                                </div>
                                                <div className="text-xs text-neutral-500 font-mono mb-4">TYPE: {doc.type.toUpperCase()}</div>
                                                <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                    <Button size="sm" variant="ghost" className="h-6 text-[10px]">Edit</Button>
                                                    <Button size="sm" variant="outline" className="h-6 text-[10px] border-white/10">Export PDF</Button>
                                                </div>
                                            </div>
                                        ))}
                                        {legalDocs.length === 0 && (
                                            <div className="col-span-full flex flex-col items-center justify-center py-20 opacity-50">
                                                <FileText className="w-12 h-12 mb-4" />
                                                <p>No documents found.</p>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}

                            {view === 'ip' && (
                                <div className="flex flex-col h-full p-4">
                                    <div className="grid grid-cols-1 gap-4">
                                        {ipAssets.map(asset => (
                                            <div key={asset.id} className="p-4 rounded-lg bg-neutral-900/40 border border-white/10 flex items-center justify-between">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-10 h-10 rounded bg-white/5 flex items-center justify-center">
                                                        <Shield className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                                                    </div>
                                                    <div>
                                                        <div className="font-bold text-white">{asset.title}</div>
                                                        <div className="text-xs text-neutral-500 font-mono">{asset.type.toUpperCase()} • {Math.round(asset.likelihood_score * 100)}% DETECTED</div>
                                                    </div>
                                                </div>
                                                <Badge className="bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/30">
                                                    PROTECTED
                                                </Badge>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {view === 'compliance' && (
                                <div className="flex flex-col items-center justify-center h-full text-neutral-500">
                                    <Shield className="w-12 h-12 mb-4 opacity-50" />
                                    <p>Compliance Audit Module Loaded</p>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                }
            />

            <IPScannerModal open={isScannerOpen} onOpenChange={setIsScannerOpen} />
            <DocGeneratorModal 
                open={isGeneratorOpen} 
                onOpenChange={setIsGeneratorOpen} 
                category={selectedCategory}
            />
        </div>
    );
}