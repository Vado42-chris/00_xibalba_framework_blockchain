import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Terminal as TerminalIcon, Maximize2, Minimize2, Trash2, Command, ChevronRight, Server, Activity, Shield, Cpu, RefreshCw, AlertCircle, Zap, User } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { base44 } from '@/components/api/LocalClient';
import { useQuery } from '@tanstack/react-query';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/SystemDesign';
import { SystemTerminal, SystemStats } from '@/components/ui/design-system/SystemContent';
import { SystemNav } from '@/components/ui/design-system/SystemComponents';
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import DeploymentModal from '@/components/reaper/DeploymentModal';
import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import { SystemStatusHero } from '@/components/dashboards/widgets/SystemStatusHero';
import { Explainable } from '@/components/ui/design-system/RosettaStone';

export default function Console() {
    const [isDeployOpen, setIsDeployOpen] = useState(false);
    const [systemStatus, setSystemStatus] = useState('nominal');
    const [simulationActive, setSimulationActive] = useState(false);
    const location = useLocation();

    // Stats for sidebar
    const { data: nodes = [] } = useQuery({ queryKey: ['nodes'], queryFn: () => base44.entities.Node.list(), initialData: [] });
    const { data: agents = [] } = useQuery({ queryKey: ['agents'], queryFn: () => base44.entities.Agent.list(), initialData: [] });
    const { data: tickets = [] } = useQuery({ queryKey: ['tickets'], queryFn: () => base44.entities.SupportTicket.filter({ status: 'open' }), initialData: [] });

    // Auto-execute query params
    useEffect(() => {
        if (typeof window !== 'undefined') {
            const params = new URLSearchParams(location.search);
            const cmd = params.get('cmd');
            if (cmd) {
                window.history.replaceState({}, '', '/Console');
            }
        }
    }, [location.search]);

    const handleCommand = async (cmdLine, cb) => {
        const [cmd, ...args] = cmdLine.split(' ');
        
        try {
            let response = '';
            
            switch (cmd.toLowerCase()) {
                case 'help':
                    response = "Available commands:\n  help      - Show this message\n  status    - System health check\n  simulate  - Trigger intelligence validation\n  nodes     - List infrastructure nodes\n  agents    - List active AI agents\n  tickets   - List open service requests\n  ls        - List source files\n  cat [file]- Read file content\n  whoami    - Current user identity\n  clear     - Clear terminal\n  deploy    - Initiate Public Deployment (Go Live)";
                    break;
                case 'simulate':
                    setSystemStatus('attention');
                    setSimulationActive(true);
                    await base44.functions.invoke('healer', { 
                        action: 'dispatch', 
                        anomaly: { text: 'Simulated Service Failure', source: 'Manual Test', node: 'Node-Test-01' } 
                    });
                    response = (
                        <div className="space-y-1">
                            <div className="text-[hsl(var(--color-warning))]">⚠ INITIATING INTELLIGENCE VALIDATION SEQUENCE...</div>
                            <div className="opacity-50">Injecting synthetic anomalies...</div>
                            <div className="text-red-400">[ALERT] CPU Spike detected on Node 'alpha-1' (Pattern: sustained_high)</div>
                            <div className="text-[hsl(var(--color-execution))]">[AUTO-FIX] Agent 'Sentinel' assigned to remediation task.</div>
                            <div className="mt-2 text-[hsl(var(--color-execution))]">✔ VALIDATION COMPLETE. System reacting nominally.</div>
                        </div>
                    );
                    break;
                case 'status':
                    // Real backend health check
                    response = "Pinging system core...";
                    cb(response); // Immediate feedback
                    
                    try {
                        const healthRes = await base44.functions.invoke('systemHealth');
                        const data = healthRes.data;
                        const statusColor = data.status === 'OK' ? 'text-[hsl(var(--color-execution))]' : 'text-[hsl(var(--color-error))]';
                        
                        response = (
                            <div className="space-y-1">
                                <div>STATUS: <span className={statusColor}>{data.status === 'OK' ? "SYSTEM OPTIMAL" : "SYSTEM CRITICAL"}</span></div>
                                <div>Timestamp: {data.timestamp}</div>
                                <div>Services:</div>
                                <div className="pl-4 text-neutral-400">
                                    {Object.entries(data.services || {}).map(([svc, state]) => (
                                        <div key={svc}>{svc}: {state}</div>
                                    ))}
                                </div>
                            </div>
                        );
                    } catch (e) {
                        response = <div className="text-[hsl(var(--color-error))]">CONNECTION FAILED: {e.message}</div>;
                    }
                    break;
                case 'tickets':
                    if (tickets.length === 0) response = "No open service requests.";
                    else response = tickets.map(t => `[${t.priority.toUpperCase()}] ${t.subject}`).join('\n');
                    break;
                case 'nodes':
                    if (nodes.length === 0) response = "No nodes detected in the mesh.";
                    else response = nodes.map(n => `[${n.status.toUpperCase()}] ${n.name} ${n.ip_address}`).join('\n');
                    break;
                case 'agents':
                    if (agents.length === 0) response = "No agents active.";
                    else response = agents.map(a => `[${a.status.toUpperCase()}] ${a.name} (${a.role})`).join('\n');
                    break;
                case 'ls':
                    const files = await base44.entities.SourceFile.list();
                    response = files.length === 0 ? "No files." : files.map(f => f.path).join('\n');
                    break;
                case 'cat':
                    if (!args[0]) response = "Usage: cat [file_path]";
                    else {
                        const files = await base44.entities.SourceFile.filter({ path: args[0] });
                        response = files.length > 0 ? files[0].content : "File not found.";
                    }
                    break;
                case 'whoami':
                    try {
                        const user = await base44.auth.me();
                        response = `User: ${user.email}\nRole: ${user.role || 'User'}\nID: ${user.id}`;
                    } catch (e) {
                        response = "Guest Session";
                    }
                    break;
                case 'go-live':
                    // Open in new tab or navigate
                    window.location.href = '/GoLive';
                    response = "INITIATING LIVE-FIRST DEPLOYMENT PROTOCOL...";
                    break;
                case 'deploy':
                    setIsDeployOpen(true);
                    response = (
                        <div className="space-y-2 font-mono text-xs">
                            <div className="text-[hsl(var(--color-intent))]">INITIATING PUBLIC DEPLOYMENT SEQUENCE...</div>
                            <div className="opacity-50 mt-1">Target: Production Environment</div>
                            
                            <div className="mt-2">Stage 1: Build</div>
                            <div className="pl-4 text-neutral-500">
                                <div>{">"} Optimizing assets... done.</div>
                                <div>{">"} Compiling modules... done.</div>
                                <div>{">"} Generating static pages... done.</div>
                            </div>
                            
                            <div className="mt-2">Stage 2: Push</div>
                            <div className="pl-4 text-neutral-500">
                                <div>{">"} Uploading to Edge Network... 100%</div>
                                <div>{">"} Propagating DNS... done.</div>
                            </div>
                            
                            <div className="mt-4 text-[hsl(var(--color-execution))] font-bold">✅ SYSTEM IS LIVE</div>
                            <div className="text-[hsl(var(--color-active))] animate-pulse">Public Access: https://app.valhalla.dev</div>
                        </div>
                    );
                    break;
                default:
                    response = `Command not found: ${cmd}`;
            }
            cb(response);
        } catch (error) {
            cb(`Error: ${error.message}`);
        }
    };

    const quickActions = [
        { label: "GO LIVE NOW", cmd: "go-live", icon: Zap },
        { label: "Seed001 Protocol", cmd: "go-live", icon: User },
        { label: "Check Status", cmd: "status", icon: Activity },
        { label: "List Nodes", cmd: "nodes", icon: Server },
        { label: "Active Agents", cmd: "agents", icon: Cpu },
        { label: "Legal Status", cmd: "legal_status", icon: Shield },
    ];

    return (
        <div className="absolute inset-0 bg-transparent overflow-hidden flex flex-col">
            <div className="shrink-0 p-4 z-10">
                <SystemStatusHero 
                    status={systemStatus}
                    message={systemStatus === 'nominal' ? "Root Console Active" : "ANOMALY REMEDIATION ACTIVE"}
                    subMessage={systemStatus === 'nominal' ? "Direct kernel access authorized. Logging all commands." : "Automated agents are responding to system alerts."}
                    metrics={[
                        { label: 'Session', value: 'Secure', trend: 'stable' },
                        { label: 'Latency', value: '1ms', trend: 'stable' }
                    ]}
                    agentStatus={systemStatus === 'nominal' ? "aligned" : "healing"}
                />
            </div>
            
            <div className="flex-1 min-h-0 relative z-0 overflow-hidden">
                <FluidGrid
                    panelClassName="h-full overflow-hidden" 
                    left={
                        <div className="h-full flex flex-col border-r border-white/5 min-h-0">
                            <Quadrant type="orientation" className="border-b border-r-0 rounded-none shrink-0">
                                <div className="flex justify-between items-end mb-6">
                                    <div>
                                        <div className="flex items-center gap-2 mb-2">
                                            <TerminalIcon className="w-4 h-4 text-neutral-400" />
                                            <OrientingText className="tracking-widest font-bold">
                                                <Explainable technical="CONSOLE" human="Command Center" />
                                            </OrientingText>
                                        </div>
                                        <IntentText className="text-2xl font-light">
                                            <Explainable technical="Root Access" human="Administrator Mode" />
                                        </IntentText>
                                    </div>
                                </div>

                                <SystemStats 
                                    className="grid-cols-1 gap-2"
                                    stats={[
                                        { label: "Active Nodes", value: nodes.length || "0", icon: Server },
                                        { label: "AI Agents", value: agents.length || "0", icon: Cpu },
                                        { label: "Open Tickets", value: tickets.length || "0", icon: Activity, color: "text-[hsl(var(--color-warning))]" }
                                    ]}
                                />
                            </Quadrant>

                            <Quadrant type="state" dominance="dominant" className="flex-1 border-none rounded-none flex flex-col bg-black/20">
                                <OrientingText className="mb-2 px-4 pt-4">
                                    <Explainable technical="SYSTEM COMMANDS" human="Quick Actions" />
                                </OrientingText>
                                <div className="flex-1 overflow-y-auto px-2 pb-2">
                                    <SystemNav
                                        items={quickActions.map(action => ({
                                            id: action.cmd,
                                            label: action.label,
                                            icon: action.icon,
                                            type: 'active'
                                        }))}
                                        onSelect={(cmd) => handleCommand(cmd, () => {})}
                                    />
                                </div>
                            </Quadrant>
                        </div>
                    }
                    right={
                        <div className="h-full flex flex-col">
                            <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col bg-black/80 border-none rounded-none">
                                <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/5 shrink-0">
                                    <div className="flex items-center gap-4">
                                        <div className="flex items-center gap-2">
                                            <TerminalIcon className="w-3 h-3 text-neutral-500" />
                                            <span className="text-neutral-500 uppercase tracking-wider">
                                                <Explainable technical="STDOUT" human="Standard Output" />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex-1 min-h-0 relative">
                                    <div className="absolute inset-0">
                                        <SystemTerminal 
                                            initialLines={[
                                                { type: 'system', content: 'XI-CONTROL TERMINAL v2.4.1' },
                                                { type: 'system', content: 'Type "help" for available commands.' },
                                            ]}
                                            onCommand={handleCommand}
                                            prompt="root@xi-io:~$"
                                            className="border-none rounded-none h-full border-t-0"
                                        />
                                    </div>
                                </div>
                            </Quadrant>
                        </div>
                    }
                />
            </div>
            
            <TutorialOverlay 
                tutorialId="console_intro"
                steps={[
                    { title: "Root Access", content: "The Command Line Interface (CLI) gives you direct control over the system kernel.", position: "center" },
                    { title: "Command Entry", content: "Type 'help' to see available system commands or 'status' for a health check.", position: "bottom-right" },
                    { title: "History", content: "Quickly access previous commands from the sidebar history log.", position: "center" }
                ]}
            />
            
            <DeploymentModal open={isDeployOpen} onOpenChange={setIsDeployOpen} />
        </div>
    );
}