import React from 'react';
import ForgeHub from '@/components/forge/ForgeHub';

export default function PromptForge() {
    return <ForgeHub />;
}