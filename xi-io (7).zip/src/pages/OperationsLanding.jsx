import React from 'react';
import { motion } from 'framer-motion';
import { Activity, Zap, Cpu, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { GlassPanel } from '@/components/ui/GlassPanel';

export default function OperationsLanding() {
    return (
        <div className="min-h-screen bg-black text-white overflow-hidden relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(34,197,94,0.1),transparent_50%)]" />
            
            <div className="relative z-10 max-w-7xl mx-auto px-6 py-24">
                <div className="text-center mb-24">
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-xs font-mono tracking-widest uppercase mb-6"
                    >
                        <Cpu className="w-3 h-3" />
                        <span>Overseer Module</span>
                    </motion.div>
                    
                    <motion.h1 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-5xl md:text-7xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/50"
                    >
                        Orchestrate <br />
                        <span className="text-green-500">Reality.</span>
                    </motion.h1>
                    
                    <motion.p 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-xl text-neutral-400 max-w-2xl mx-auto mb-10"
                    >
                        Command your digital infrastructure. Manage projects, deployments, and resources from a single pane of glass.
                    </motion.p>
                    
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                        className="flex flex-col sm:flex-row gap-4 justify-center"
                    >
                        <Link to={createPageUrl('Pricing')}>
                            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white min-w-[200px]">
                                Start Free Trial <ArrowRight className="ml-2 w-4 h-4" />
                            </Button>
                        </Link>
                         <Link to={createPageUrl('GatewayLanding')}>
                            <Button size="lg" variant="outline" className="border-white/10 hover:bg-white/5 text-white min-w-[200px]">
                                Live Demo
                            </Button>
                        </Link>
                    </motion.div>
                </div>

                <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 }}
                    className="relative mx-auto max-w-5xl"
                >
                    <div className="absolute -inset-1 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl opacity-20 blur" />
                    <GlassPanel className="relative aspect-video bg-neutral-900/80 backdrop-blur-xl border-white/10 rounded-xl overflow-hidden flex flex-col">
                        <div className="p-4 border-b border-white/5 flex items-center justify-between">
                            <div className="flex gap-2">
                                <div className="w-3 h-3 rounded-full bg-red-500/20" />
                                <div className="w-3 h-3 rounded-full bg-yellow-500/20" />
                                <div className="w-3 h-3 rounded-full bg-green-500/20" />
                            </div>
                            <div className="text-xs font-mono text-neutral-500">OVERSEER_OPS_V1</div>
                        </div>
                        <div className="flex-1 p-8 flex items-center justify-center bg-[url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=2670')] bg-cover bg-center opacity-50 grayscale hover:grayscale-0 transition-all duration-700">
                             <div className="bg-black/80 backdrop-blur-md p-8 rounded-2xl border border-white/10 text-center max-w-md">
                                <Activity className="w-12 h-12 text-green-500 mx-auto mb-4" />
                                <h3 className="text-2xl font-bold mb-2">Operations Center</h3>
                                <p className="text-neutral-400 mb-6">Visualize system health, deployment status, and active workflows.</p>
                                <Button variant="outline" className="border-green-500/50 text-green-400 hover:bg-green-500/10">
                                    Initiate Protocol
                                </Button>
                             </div>
                        </div>
                    </GlassPanel>
                </motion.div>

                 <div className="grid md:grid-cols-3 gap-8 mt-24">
                    {[
                        { title: "Project Topology", desc: "Visualize task dependencies as a living network graph." },
                        { title: "Auto-Delegation", desc: "AI agents pick up tasks based on skill requirements." },
                        { title: "Resource Optimization", desc: "Track compute, storage, and human capital in real-time." }
                    ].map((feature, i) => (
                        <div key={i} className="p-6 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-colors">
                            <CheckCircle2 className="w-8 h-8 text-green-500 mb-4" />
                            <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                            <p className="text-neutral-400">{feature.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}