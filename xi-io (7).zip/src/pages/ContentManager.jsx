import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { LayoutTemplate, File, Plus, Image as ImageIcon, Search, Globe, Code, FileCode, PlayCircle, BookOpen, PenTool, Eye } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, SemanticDot, Layer } from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import VisualEditor from '@/components/content/VisualEditor';
import BlogEditor from '@/components/content/BlogEditor';
import { toast } from "sonner";
import NewPageModal from '@/components/content/NewPageModal';
import { WargameSimulation } from '@/components/reaper/WargameSimulation';
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import DeploymentModal from '@/components/reaper/DeploymentModal';
import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import ToolPreview from '@/components/previews/ToolPreview';
import { ActionDock } from '@/components/ui/design-system/ActionDock'; 
import { BrowserWindow } from '@/components/ui/BrowserWindow';
import { useSiteContext } from '@/components/identity/SiteContext';

export default function ContentManager() {
    const { systemStage } = useSiteContext();
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    React.useEffect(() => {
        base44.auth.me().then(setUser).catch(() => setUser(null)).finally(() => setLoading(false));
    }, []);

    const [selectedPage, setSelectedPage] = useState(null);
    const [previewItem, setPreviewItem] = useState(null);
    const [mode, setMode] = useState('pages'); // 'pages' | 'articles'
    const [isNewPageOpen, setIsNewPageOpen] = useState(false);
    const [isDeployOpen, setIsDeployOpen] = useState(false);
    const [search, setSearch] = useState('');
    const [showWargame, setShowWargame] = useState(false);
    const queryClient = useQueryClient();

    const { data: pages = [] } = useQuery({
        queryKey: ['content_pages'],
        queryFn: () => base44.entities.ContentPage.list(),
        initialData: [],
        enabled: !!user
    });

    const { data: articles = [] } = useQuery({
        queryKey: ['articles'],
        queryFn: () => base44.entities.Article.list(),
        initialData: [],
        enabled: !!user
    });

    // Assets fetched internally by AssetPicker


    const savePageMutation = useMutation({
        mutationFn: (pageData) => {
            if (pageData.id) {
                return base44.entities.ContentPage.update(pageData.id, pageData);
            }
            return base44.entities.ContentPage.create(pageData);
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['content_pages']);
            toast.success("Page content saved");
        }
    });

    if (loading) return null;

    if (!user) {
        return (
            <ToolPreview 
                title="Content Engine"
                subtitle="CMS & Site Builder"
                description="A powerful Headless CMS and Visual Builder. Manage your public presence, blog posts, and marketing pages."
                features={[
                    "Visual Page Builder",
                    "Markdown Blog Editor",
                    "AI Content Generation",
                    "Multi-Channel Publishing"
                ]}
                demoComponent={
                    <BrowserWindow 
                        isOpen={true} 
                        viewState="static" 
                        title="Live Preview"
                        defaultUrl="http://localhost:3000/home"
                        showUrlBar={true}
                    >
                        <div className="w-full h-full bg-neutral-100 p-8 flex flex-col gap-4 overflow-hidden relative">
                            {/* Mock Website Content */}
                            <div className="absolute top-0 left-0 w-full h-64 bg-gradient-to-r from-blue-500 to-purple-600 opacity-10" />
                            <div className="relative z-10">
                                <div className="h-12 w-1/3 bg-neutral-200 rounded animate-pulse mb-6" />
                                <div className="space-y-3">
                                    <div className="h-4 w-full bg-neutral-200 rounded" />
                                    <div className="h-4 w-full bg-neutral-200 rounded" />
                                    <div className="h-4 w-2/3 bg-neutral-200 rounded" />
                                </div>
                                <div className="grid grid-cols-2 gap-4 mt-8">
                                    <div className="aspect-video bg-white rounded shadow-sm border border-neutral-200 p-4">
                                        <div className="h-full w-full bg-neutral-100 rounded" />
                                    </div>
                                    <div className="aspect-video bg-white rounded shadow-sm border border-neutral-200 p-4">
                                        <div className="h-full w-full bg-neutral-100 rounded" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </BrowserWindow>
                }
            />
        );
    }

    const filteredItems = (mode === 'pages' ? pages : articles).filter(p => (p.title || '').toLowerCase().includes(search.toLowerCase()));

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <div className="flex flex-col h-full bg-neutral-950 border-r border-white/10">
                        {/* Matrix Header (Fixed) */}
                        <Quadrant type="orientation" step="1" title="Matrix" className="shrink-0 border-b">
                            <div className="mb-6">
                                <SystemDetailHeader 
                                    title={mode === 'pages' ? 'Page Matrix' : 'Blog Engine'}
                                    subtitle="SITE BUILDER" 
                                    icon={LayoutTemplate}
                                    addonContext="cms"
                                    className="p-0 border-b-0 bg-transparent mb-0"
                                >
                                    <Button
                                        variant="outline"
                                        className="h-8 text-xs border-[hsl(var(--color-execution))]/30 text-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/10 ml-2"
                                        onClick={() => setIsDeployOpen(true)}
                                    >
                                        <Globe className="w-3 h-3 mr-2" /> Publish Site
                                    </Button>
                                </SystemDetailHeader>
                            </div>

                            <GuideBox title="Content Strategy">
                                <p className="mb-2">
                                    {mode === 'pages' 
                                        ? "Construct the visual head for your Headless Node. These pages form your main site structure."
                                        : "Publish recurring content to your community. Articles are automatically fed to RSS and social channels."}
                                </p>
                            </GuideBox>

                            <div className="flex p-1 bg-neutral-900 border border-white/10 rounded-lg my-4">
                                <button 
                                    onClick={() => { setMode('pages'); setSelectedPage(null); }}
                                    className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-md transition-all ${mode === 'pages' ? 'bg-[hsl(var(--color-intent))] text-black' : 'text-neutral-500 hover:text-white'}`}
                                >
                                    <LayoutTemplate className="w-3 h-3" /> PAGES
                                </button>
                                <button 
                                    onClick={() => { setMode('articles'); setSelectedPage(null); }}
                                    className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-md transition-all ${mode === 'articles' ? 'bg-[hsl(var(--color-intent))] text-black' : 'text-neutral-500 hover:text-white'}`}
                                >
                                    <BookOpen className="w-3 h-3" /> ARTICLES
                                </button>
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                                <Button
                                    onClick={() => mode === 'pages' ? setIsNewPageOpen(true) : toast.info("New Article creation coming in v2.6")}
                                    className="w-full bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black font-bold h-10 text-xs tracking-widest"
                                >
                                    <Plus className="w-3 h-3 mr-2" /> NEW {mode === 'pages' ? 'PAGE' : 'POST'}
                                </Button>
                                <Button
                                    variant="outline"
                                    onClick={() => toast.success("Template Exported")}
                                    className="w-full h-10 border-white/10 text-neutral-400 hover:text-white justify-center text-xs"
                                >
                                    <FileCode className="w-3 h-3 mr-2" /> EXPORT
                                </Button>
                            </div>

                            {/* Added ActionDock for context tools */}
                            <ActionDock 
                                className="mt-4"
                                primaryAction={{
                                    label: "SEO Check",
                                    icon: Search,
                                    onClick: () => toast.info("SEO Analysis running...")
                                }}
                                secondaryActions={[
                                    { label: "Preview", icon: Eye, onClick: () => toast.info("Preview generated") }
                                ]} 
                            />

                            <div className="relative mt-4">
                                <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                                <Input
                                    placeholder={`Search ${mode}...`}
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                    className="pl-8 bg-neutral-900 border-white/10 h-8 text-xs"
                                />
                            </div>
                        </Quadrant>

                        {/* Index List (Scrollable) */}
                        <Quadrant type="state" step="3" title="Index" className="flex-1 min-h-0 flex flex-col border-t-0 rounded-t-none" scrollable={false}>
                            <div className="flex-1 overflow-y-auto space-y-1 pr-1 xi-scroll">
                                {filteredItems.map(item => (
                                    <SystemCard
                                        key={item.id}
                                        title={item.title}
                                        subtitle={item.slug || '/untitled'}
                                        status={item.status === 'published' || item.published ? 'execution' : 'settled'}
                                        metric={mode === 'pages' ? `v${item.version || '1.0'}` : 'BLOG'}
                                        active={selectedPage?.id === item.id}
                                        onClick={() => setSelectedPage(item)}
                                        icon={mode === 'pages' ? FileCode : PenTool}
                                    >
                                        <ActionDock 
                                            primaryAction={{
                                                label: "Edit",
                                                icon: PenTool,
                                                onClick: (e) => {
                                                    e.stopPropagation();
                                                    setSelectedPage(item);
                                                }
                                            }}
                                            secondaryActions={[
                                                { 
                                                    label: "Preview", 
                                                    icon: Eye, 
                                                    onClick: (e) => {
                                                        e.stopPropagation();
                                                        setPreviewItem(item);
                                                    } 
                                                },
                                                {
                                                    label: "Deploy",
                                                    icon: Globe,
                                                    onClick: (e) => {
                                                        e.stopPropagation();
                                                        setIsDeployOpen(true);
                                                    }
                                                }
                                            ]}
                                        />
                                    </SystemCard>
                                ))}
                            </div>
                        </Quadrant>
                    </div>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" step="2" title="Visual Forge" dominance="dominant" className="flex flex-col h-full overflow-hidden bg-neutral-950 border-l border-white/10">
                            {selectedPage ? (
                                mode === 'pages' ? (
                                    <VisualEditor
                                        key={selectedPage.id} // Force reset on change
                                        page={selectedPage}
                                        onSave={(updatedPage) => savePageMutation.mutate(updatedPage)}
                                        isSaving={savePageMutation.isPending}
                                    />
                                ) : (
                                    <BlogEditor
                                        key={selectedPage.id}
                                        article={selectedPage}
                                        onSave={(updatedArticle) => savePageMutation.mutate(updatedArticle)}
                                        isSaving={savePageMutation.isPending}
                                    />
                                )
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center opacity-30">
                                    <Globe className="w-24 h-24 mb-6 stroke-1 text-neutral-800" />
                                    <OrientingText className="text-lg">Select a page from the Matrix to begin editing</OrientingText>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                }
            />

            <NewPageModal
                open={isNewPageOpen}
                onOpenChange={setIsNewPageOpen}
                onCreated={(page) => {
                    setIsNewPageOpen(false);
                    setSelectedPage(page);
                }}
            />

            <Dialog open={showWargame} onOpenChange={setShowWargame}>
                <DialogContent className="max-w-6xl h-[90vh] p-0 bg-neutral-950 border-white/10">
                    <WargameSimulation
                        localConnected={false}
                        initialTopic="Optimize Content Distribution Pipeline for maximum engagement and automated publishing across all channels"
                    />
                </DialogContent>
            </Dialog>

            {previewItem && (
                <BrowserWindow
                    isOpen={!!previewItem}
                    onClose={() => setPreviewItem(null)}
                    title={previewItem.title || 'Preview'}
                    defaultUrl={`http://localhost:3000/${previewItem.slug || ''}`}
                    viewState="windowed"
                    initialStage={systemStage}
                >
                    <div className="w-full h-full bg-[#050505] relative overflow-hidden">
                        {/* Simulation of a live site rendering */}
                        <iframe 
                            srcDoc={`
                                <html>
                                    <head>
                                        <style>
                                            body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background: #050505; color: #e5e5e5; }
                                            .hero { height: 50vh; background: linear-gradient(to bottom, #111, #050505); display: flex; align-items: center; justify-content: center; text-align: center; padding: 20px; border-bottom: 1px solid #222; }
                                            h1 { font-size: 3.5rem; margin-bottom: 1rem; color: #fff; letter-spacing: -0.02em; }
                                            p { color: #888; font-size: 1.25rem; max-width: 600px; margin: 0 auto; line-height: 1.6; }
                                            .container { max-width: 800px; margin: 0 auto; padding: 60px 20px; }
                                            .content { font-size: 1.125rem; line-height: 1.8; color: #d4d4d4; }
                                            .content h2 { font-size: 2rem; margin-top: 3rem; margin-bottom: 1rem; color: #fff; }
                                            .content p { margin-bottom: 1.5rem; }
                                            .content img { max-width: 100%; border-radius: 8px; margin: 2rem 0; border: 1px solid #333; }
                                            .content blockquote { border-left: 4px solid #3b82f6; padding-left: 1rem; margin: 2rem 0; font-style: italic; color: #9ca3af; }
                                            .meta { margin-top: 2rem; padding-top: 2rem; border-top: 1px solid #222; color: #666; font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.05em; }
                                        </style>
                                    </head>
                                    <body>
                                        <div class="hero">
                                            <div>
                                                <h1>${previewItem.title}</h1>
                                                <p>${previewItem.seo_description || previewItem.description || previewItem.excerpt || 'A digital experience.'}</p>
                                            </div>
                                        </div>
                                        <div class="container">
                                            <div class="content">
                                                ${previewItem.content || '<p>No content available for preview.</p>'}
                                            </div>
                                            <div class="meta">
                                                Published • ${new Date().toLocaleDateString()} • /${previewItem.slug || 'untitled'}
                                            </div>
                                        </div>
                                    </body>
                                </html>
                            `}
                            className="w-full h-full border-none"
                            title="Preview"
                        />
                    </div>
                </BrowserWindow>
            )}

            <DeploymentModal 
                open={isDeployOpen} 
                onOpenChange={setIsDeployOpen} 
                mode="smart_ship"
            />

            <TutorialOverlay 
                tutorialId="site_builder_intro"
                steps={[
                    { title: "Site Builder", content: "Construct the visual head for your Headless Node. This WYSIWYG editor manages your public-facing content.", position: "top-left" },
                    { title: "Page Matrix", content: "Manage your route structure and content pages here.", position: "top-left" },
                    { title: "Visual Editor", content: "The visual editor allows rich content creation without touching raw HTML.", position: "center" },
                    { title: "Publish", content: "When ready, deploy your site to the edge network instantly.", position: "top-right" }
                ]}
            />
        </div>
    );
}