import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Shield, Smartphone, Box, Layers, Cpu, Zap, ShoppingBag, ArrowUpRight, Search, Filter, Lock, 
    PlayCircle, Fingerprint, MessageSquare, HardDrive, Users, GitBranch, FileText, Video, Plug, Code
} from 'lucide-react';

// Icon mapping for manifest strings
const IconMap = {
    MessageSquare, HardDrive, Users, GitBranch, FileText, Video, Plug,
    Smartphone, Box, Layers, Zap, ShoppingBag
};
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { cn } from "@/components/ui/utils";
import { BrowserWindow } from '@/components/ui/BrowserWindow';
import { QuadrantGrid, Quadrant } from '@/components/ui/design-system/SystemDesign';
import { toast } from 'sonner';

export default function IntegrationsPage() {
    const [activeCategory, setActiveCategory] = useState('all');
    const [browserOpen, setBrowserOpen] = useState(false);
    const [selectedSlot, setSelectedSlot] = useState(null);

    // Fetch Connectors from Backend API
    const { data: connectors = [], isLoading, refetch } = useQuery({
        queryKey: ['valhalla_connectors'],
        queryFn: async () => {
            // Updated to match the router logic in functions/connectors.js
            const res = await base44.functions.invoke('connectors', { 
                method: 'GET', 
                url: '/api/v1/connectors' 
            });
            return res.data?.data || [];
        }
    });

    const handlePreview = (slot) => {
        setSelectedSlot(slot);
        setBrowserOpen(true);
    };

    const handleUpgrade = async (connectorId) => {
        toast.info("Initiating Valhalla Protocol Upgrade...", {
            description: "Provisioning ChainLedger & Neural Link..."
        });

        try {
            // Call Backend to Toggle Modes
            const res = await base44.functions.invoke('connectors', { 
                method: 'POST',
                url: `/api/v1/connectors/${connectorId}/modes`,
                data: {
                    aiInsight: true,
                    blockchainAudit: true
                }
            });

            if (res.data?.ok) {
                toast.success("Upgrade Complete", {
                    description: "Connector is now running in Sovereign Mode."
                });
                refetch(); // Update UI
                setBrowserOpen(false);
            } else {
                throw new Error("Upgrade failed");
            }
        } catch (e) {
            console.error(e);
            toast.error("Upgrade Failed", { description: "Could not establish secure link." });
        }
    };

    const filteredSlots = activeCategory === 'all' 
        ? connectors 
        : connectors.filter(s => s.category === activeCategory);

    return (
        <div className="h-full flex flex-col bg-transparent relative z-10">
            {/* Header */}
            <div className="h-20 border-b border-white/5 flex items-center px-8 justify-between shrink-0 bg-black/20 backdrop-blur-md sticky top-0 z-10">
                <div>
                    <div className="flex items-center gap-3">
                        <h1 className="text-2xl font-light tracking-tight text-white">API Connectors</h1>
                        <Badge variant="outline" className="border-emerald-500/30 text-emerald-500 bg-emerald-500/10">
                             PROTOCOL: ONLINE
                        </Badge>
                    </div>
                    <p className="text-sm text-neutral-500">Sovereign Connector Inventory • {connectors.length} Modules Available</p>
                </div>
                <div className="flex gap-4 items-center">
                     <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                        <Input className="pl-9 w-64 bg-white/5 border-white/10" placeholder="Search modules..." />
                     </div>
                     <Button 
                        asChild 
                        variant="outline" 
                        className="bg-white/5 border-white/10 hover:bg-white/10"
                     >
                         <a href="/ConnectorBuilder">
                            <Code className="w-4 h-4 mr-2" />
                            Build Custom
                         </a>
                     </Button>
                </div>
            </div>

            {/* Main Grid Layout */}
            <QuadrantGrid className="flex-1 p-6">
                
                {/* Quadrant 1: Active Matrix */}
                <Quadrant type="orientation" step="1" title="Connector Inventory" dominance="dominant">
                    <div className="h-full flex flex-col">
                        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-none">
                            {['all', 'productivity', 'communication', 'crm', 'marketing'].map(cat => (
                                <button
                                    key={cat}
                                    onClick={() => setActiveCategory(cat)}
                                    className={cn(
                                        "px-4 py-1.5 rounded-full text-xs font-medium border transition-all uppercase tracking-wider",
                                        activeCategory === cat 
                                            ? "bg-white text-black border-white" 
                                            : "bg-white/5 text-neutral-400 border-white/10 hover:border-white/30"
                                    )}
                                >
                                    {cat}
                                </button>
                            ))}
                        </div>

                        {isLoading ? (
                            <div className="flex items-center justify-center h-40 text-neutral-500 text-xs animate-pulse">
                                SCANNING NETWORK TOPOLOGY...
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 overflow-y-auto pr-2">
                                {filteredSlots.map((slot, idx) => {
                                    const isActive = slot.instance?.status === 'active';
                                    const isUpgraded = slot.instance?.modes?.ai_insight;

                                    return (
                                        <div 
                                            key={idx}
                                            onClick={() => handlePreview(slot)}
                                            className={cn(
                                                "group relative p-5 rounded-xl border transition-all cursor-pointer hover:border-[hsl(var(--color-intent))]/50",
                                                isActive ? "bg-white/[0.05] border-white/10" : "bg-white/[0.02] border-white/5"
                                            )}
                                        >
                                            <div className="flex justify-between items-start mb-4">
                                                <div className="p-2.5 rounded-lg bg-white/5 group-hover:bg-white/10 transition-colors text-white">
                                                    {(() => {
                                                        // Use icon from manifest or fallback based on category
                                                        const Icon = IconMap[slot.icon] || (
                                                            slot.category === 'productivity' ? Box :
                                                            slot.category === 'communication' ? Smartphone :
                                                            slot.category === 'crm' ? Layers :
                                                            slot.category === 'marketing' ? Zap : Box
                                                        );
                                                        return <Icon className="w-5 h-5" />;
                                                    })()}
                                                </div>
                                                <div className={cn(
                                                    "w-2 h-2 rounded-full",
                                                    isActive ? "bg-emerald-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]" : "bg-neutral-600"
                                                )} />
                                            </div>
                                            <div>
                                                <h3 className="font-medium text-neutral-200 mb-1">{slot.display_name}</h3>
                                                <p className="text-xs text-neutral-500 uppercase tracking-wide truncate">{slot.description}</p>
                                            </div>
                                            <div className="mt-3 flex gap-2">
                                                <Badge variant="outline" className="text-[9px] border-white/10 text-neutral-500">
                                                    {slot.tier || 'Standard'}
                                                </Badge>
                                                {isUpgraded && (
                                                    <Badge variant="default" className="text-[9px] bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]">
                                                        VALHALLA MODE
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </div>
                </Quadrant>

                {/* Quadrant 2: Stats */}
                <Quadrant type="state" step="2" title="Valhalla Protocol Status" dominance="recessive" className="flex flex-col gap-4">
                    <div className="flex-1 p-4 rounded-lg bg-black/20 border border-white/5 font-mono text-xs text-neutral-400 overflow-hidden relative">
                         <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[hsl(var(--color-execution))] to-transparent opacity-20" />
                         <div className="space-y-4">
                             <div className="flex justify-between">
                                 <span>Active Nodes</span>
                                 <span className="text-white">{connectors.filter(c => c.instance?.status === 'active').length}</span>
                             </div>
                             <div className="flex justify-between">
                                 <span>Upgraded Links</span>
                                 <span className="text-[hsl(var(--color-intent))]">{connectors.filter(c => c.instance?.modes?.ai_insight).length}</span>
                             </div>
                             <div className="flex justify-between border-t border-white/10 pt-2">
                                 <span>Network Health</span>
                                 <span className="text-emerald-500">NOMINAL</span>
                             </div>
                         </div>
                    </div>
                    
                    <div className="p-4 rounded-lg bg-[hsl(var(--color-intent))]/5 border border-[hsl(var(--color-intent))]/20">
                         <div className="flex items-center gap-2 mb-2 text-[hsl(var(--color-intent))]">
                            <Shield className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase">Upgrade Available</span>
                         </div>
                         <p className="text-xs text-neutral-400 leading-relaxed">
                            Wrap these raw APIs with our Insight Engine to enable real-time analysis and blockchain auditing.
                         </p>
                    </div>
                </Quadrant>

                {/* Quadrant 3 & 4: Stacked Info */}
                <QuadrantGrid stacked className="h-full">
                    <Quadrant type="analysis" step="3" title="ChainLedger Audit" dominance="supporting" className="border-b-0 rounded-b-none">
                        <div className="h-full flex items-center justify-center text-neutral-600">
                             <div className="text-center">
                                <Fingerprint className="w-8 h-8 mx-auto mb-2 opacity-50" />
                                <span className="text-xs uppercase tracking-widest">
                                    {connectors.some(c => c.instance?.modes?.blockchain_audit) ? "Ledger Active" : "Waiting for Upgrade"}
                                </span>
                             </div>
                        </div>
                    </Quadrant>
                    
                    <Quadrant type="intent" step="4" title="AI Insight" dominance="supporting" className="border-t-0 rounded-t-none">
                         <div className="h-full flex items-center justify-center text-neutral-600">
                             <div className="text-center">
                                <Cpu className="w-8 h-8 mx-auto mb-2 opacity-50" />
                                <span className="text-xs uppercase tracking-widest">
                                    {connectors.some(c => c.instance?.modes?.ai_insight) ? "Neural Link Active" : "Neural Link Offline"}
                                </span>
                             </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            </QuadrantGrid>

            {/* INTEGRATION PREVIEW BROWSER */}
            {browserOpen && selectedSlot && (
                <BrowserWindow
                    isOpen={browserOpen}
                    onClose={() => setBrowserOpen(false)}
                    title={`Valhalla Connector: ${selectedSlot.display_name}`}
                    defaultUrl={`https://api.valhalla.dev/v1/connectors/${selectedSlot.id}`}
                    viewState="windowed"
                    variant="browser"
                >
                    <div className="h-full w-full bg-[#050505] text-white p-8 flex flex-col items-center justify-center text-center relative overflow-hidden">
                        {/* Ambient Background */}
                        <div className="absolute inset-0 bg-gradient-to-br from-neutral-900 to-black pointer-events-none" />
                        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-[hsl(var(--color-intent))]/10 blur-[100px] rounded-full pointer-events-none" />
                        
                        <div className="relative z-10 max-w-2xl space-y-8">
                            <div className="w-24 h-24 bg-white/5 rounded-3xl mx-auto flex items-center justify-center border border-white/10 shadow-2xl">
                                <div className="text-3xl font-bold">{selectedSlot.display_name[0]}</div>
                            </div>
                            
                            <div>
                                <h1 className="text-4xl font-light tracking-tight mb-2">Configure <span className="font-bold">{selectedSlot.display_name}</span></h1>
                                <p className="text-sm text-neutral-500 uppercase tracking-widest">
                                    {selectedSlot.provider} • {selectedSlot.instance?.status === 'active' ? 'Active' : 'Inactive'}
                                </p>
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-left bg-white/5 p-6 rounded-2xl border border-white/10 backdrop-blur-md">
                                <div className="space-y-4">
                                    <div>
                                        <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-neutral-500">Raw API Capability</h4>
                                        <p className="text-sm text-neutral-300">{selectedSlot.description}</p>
                                    </div>
                                    <div className="pt-4 border-t border-white/5 space-y-2">
                                        <Button 
                                            size="sm" 
                                            variant="outline" 
                                            className="w-full border-white/10 hover:bg-white/5"
                                            onClick={() => {
                                                base44.auth.requestOAuthAuthorization({
                                                    integration_type: selectedSlot.provider,
                                                    reason: "Connect to Valhalla",
                                                    scopes: ["read", "chat:write"] // Added scopes for Slack demo
                                                });
                                            }}
                                        >
                                            <Lock className="w-3 h-3 mr-2" />
                                            {selectedSlot.instance?.status === 'active' ? 'Re-Authorize' : 'Authorize Standard'}
                                        </Button>

                                        {selectedSlot.instance?.status === 'active' && selectedSlot.provider === 'slack' && (
                                            <Button 
                                                size="sm" 
                                                className="w-full bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/50"
                                                onClick={async () => {
                                                    const toastId = toast.loading("Testing Slack Connection...");
                                                    try {
                                                        const res = await base44.functions.invoke('slack', { action: 'list_channels' });
                                                        if (res.data?.ok) {
                                                            const count = res.data.channels?.length || 0;
                                                            toast.success("Connection Verified", { 
                                                                id: toastId,
                                                                description: `Found ${count} channels. API Link established.` 
                                                            });
                                                        } else {
                                                            throw new Error(res.data?.error || "Unknown error");
                                                        }
                                                    } catch (e) {
                                                        toast.error("Connection Test Failed", { 
                                                            id: toastId, 
                                                            description: e.message 
                                                        });
                                                    }
                                                }}
                                            >
                                                <Plug className="w-3 h-3 mr-2" />
                                                Test Connection
                                            </Button>
                                        )}
                                    </div>
                                </div>
                                <div className="border-l border-white/10 pl-6 flex flex-col justify-center bg-[hsl(var(--color-intent))]/5 -my-6 py-6 -mr-6 pr-6 rounded-r-2xl border-r border-y border-[hsl(var(--color-intent))]/20">
                                    <h4 className="font-bold mb-2 text-xs uppercase tracking-widest text-[hsl(var(--color-intent))]">Valhalla Upgrade</h4>
                                    <ul className="space-y-3 mb-6">
                                        <li className="flex items-start gap-2 text-xs text-neutral-300">
                                            <Cpu className="w-3 h-3 text-[hsl(var(--color-intent))] mt-0.5" />
                                            {selectedSlot.valhalla_ai_desc || "AI Analysis"}
                                        </li>
                                        <li className="flex items-start gap-2 text-xs text-neutral-300">
                                            <Shield className="w-3 h-3 text-[hsl(var(--color-intent))] mt-0.5" />
                                            {selectedSlot.valhalla_chain_desc || "ChainLedger Audit"}
                                        </li>
                                    </ul>
                                    {selectedSlot.instance?.modes?.ai_insight ? (
                                        <div className="text-center p-2 rounded bg-emerald-500/20 text-emerald-500 text-xs font-bold border border-emerald-500/50">
                                            PROTOCOL ACTIVE
                                        </div>
                                    ) : (
                                        <Button 
                                            className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold tracking-wide shadow-[0_0_15px_hsl(var(--color-intent))/20]"
                                            onClick={() => handleUpgrade(selectedSlot.id)}
                                        >
                                            <Zap className="w-3 h-3 mr-2" />
                                            ACTIVATE PROTOCOL
                                        </Button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </BrowserWindow>
            )}
        </div>
    );
}