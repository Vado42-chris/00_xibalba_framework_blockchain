import React from 'react';
import { User, CreditCard, Bell, Shield, HardDrive } from 'lucide-react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText 
} from '@/components/ui/design-system/System';

export default function UserDomain() {
  return (
    <div className="h-full w-full bg-transparent overflow-hidden">
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="orientation" className="border-b">
                        <div className="flex justify-between items-end mb-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <User className="w-4 h-4 text-[hsl(var(--color-orientation))]" />
                                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-orientation))]">USER DOMAIN</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Preferences & Context</IntentText>
                            </div>
                        </div>
                        <StateText className="text-[hsl(var(--fg-orientation))] text-sm font-mono mt-4">
                            "Personal settings apply regardless of your active authority role."
                        </StateText>
                    </Quadrant>

                    <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                        <OrientingText className="mb-4">IDENTITY & AUTHORITY</OrientingText>
                        <div className="space-y-4">
                            <div className="p-4 rounded bg-neutral-950 border border-white/5 flex items-start justify-between">
                            <div>
                                <div className="text-sm font-bold text-[hsl(var(--color-orientation))]">Personal Profile (You)</div>
                                <div className="text-xs text-neutral-500 mt-1">xi-io/user-01 • Verified</div>
                            </div>
                            <div className="px-2 py-1 rounded bg-neutral-900 border border-white/5 text-[10px] text-neutral-500 font-mono">
                                PERMANENT
                            </div>
                            </div>
                            
                            <div className="flex justify-center">
                                <div className="h-4 w-px bg-white/5" />
                            </div>

                            <div className="p-4 rounded bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/30 flex items-start justify-between">
                                <div>
                                    <div className="text-sm font-bold text-[hsl(var(--color-execution))]">Active Role (Context)</div>
                                    <div className="text-xs text-[hsl(var(--color-execution))] mt-1">ROOT_ADMIN • Full System Access</div>
                                </div>
                                <div className="px-2 py-1 rounded bg-[hsl(var(--color-execution))]/30 border border-[hsl(var(--color-execution))]/50 text-[10px] text-[hsl(var(--color-execution))] font-mono animate-pulse">
                                    EPHEMERAL
                                </div>
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                        <div className="p-8 space-y-8">
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {/* Billing Stub */}
                                <Card className="p-6 bg-neutral-900/50 border border-white/5 flex flex-col justify-between">
                                    <div>
                                        <h3 className="flex items-center gap-2 text-sm font-bold text-[hsl(var(--fg-state))] mb-4">
                                        <CreditCard className="w-4 h-4" /> Billing & Usage
                                        </h3>
                                        <div className="space-y-6">
                                        <div>
                                            <div className="flex justify-between text-xs mb-2">
                                            <span className="text-[hsl(var(--fg-orientation))]">Monthly Cap</span>
                                            <span className="text-[hsl(var(--fg-intent))] font-mono">45%</span>
                                            </div>
                                            <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                                            <div className="h-full bg-[hsl(var(--color-execution))] w-[45%]" />
                                            </div>
                                        </div>
                                        <div className="space-y-2">
                                            <div className="flex justify-between text-xs">
                                            <span className="text-[hsl(var(--fg-orientation))]">Plan</span>
                                            <span className="text-[hsl(var(--fg-intent))]">Pro Node</span>
                                            </div>
                                            <div className="flex justify-between text-xs">
                                            <span className="text-[hsl(var(--fg-orientation))]">Next Invoice</span>
                                            <span className="text-[hsl(var(--fg-intent))]">$24.00</span>
                                            </div>
                                        </div>
                                        </div>
                                    </div>
                                    <Button variant="outline" className="w-full mt-6 border-white/5 hover:bg-neutral-900 text-xs">
                                        Manage Subscription
                                    </Button>
                                </Card>

                                <div className="space-y-6">
                                    <Card className="p-6 bg-neutral-900/50 border border-white/5">
                                        <h3 className="flex items-center gap-2 text-sm font-bold text-[hsl(var(--fg-state))] mb-4">
                                            <Bell className="w-4 h-4" /> Notifications
                                        </h3>
                                        <div className="space-y-4">
                                            <div className="flex items-center justify-between p-3 rounded hover:bg-neutral-900 transition-colors">
                                            <span className="text-sm text-[hsl(var(--fg-state))]">Security Alerts</span>
                                            <span className="text-xs font-mono text-[hsl(var(--color-execution))]">CRITICAL ONLY</span>
                                            </div>
                                            <div className="flex items-center justify-between p-3 rounded hover:bg-neutral-900 transition-colors">
                                            <span className="text-sm text-[hsl(var(--fg-state))]">System Digest</span>
                                            <span className="text-xs font-mono text-[hsl(var(--fg-orientation))]">WEEKLY</span>
                                            </div>
                                            <div className="flex items-center justify-between p-3 rounded hover:bg-neutral-900 transition-colors">
                                            <span className="text-sm text-[hsl(var(--fg-state))]">Marketing</span>
                                            <span className="text-xs font-mono text-[hsl(var(--fg-orientation))]">DISABLED</span>
                                            </div>
                                        </div>
                                    </Card>

                                    <Card className="p-6 bg-neutral-900/50 border border-white/5">
                                        <h3 className="flex items-center gap-2 text-sm font-bold text-[hsl(var(--fg-state))] mb-4">
                                            <HardDrive className="w-4 h-4" /> Local Preferences
                                        </h3>
                                        <div className="space-y-4">
                                            <div className="flex items-center justify-between p-3 rounded hover:bg-neutral-900 transition-colors">
                                            <span className="text-sm text-[hsl(var(--fg-state))]">Editor Theme</span>
                                            <span className="text-xs font-mono text-[hsl(var(--fg-intent))]">VOID DARK</span>
                                            </div>
                                            <div className="flex items-center justify-between p-3 rounded hover:bg-neutral-900 transition-colors">
                                            <span className="text-sm text-[hsl(var(--fg-state))]">Keybinding</span>
                                            <span className="text-xs font-mono text-[hsl(var(--fg-intent))]">VIM</span>
                                            </div>
                                            <div className="flex items-center justify-between p-3 rounded hover:bg-neutral-900 transition-colors">
                                            <span className="text-sm text-[hsl(var(--fg-state))]">Font</span>
                                            <span className="text-xs font-mono text-[hsl(var(--fg-intent))]">JETBRAINS MONO</span>
                                            </div>
                                        </div>
                                    </Card>
                                </div>
                            </div>

                            <div className="p-4 bg-neutral-900/30 border border-white/5 rounded text-center">
                                <p className="text-[hsl(var(--fg-orientation))] text-xs font-mono">
                                Changes here affect YOUR VIEW, not the SYSTEM CONFIGURATION.
                                </p>
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    </div>
  );
}