import React, { useState } from 'react';
import { 
    Book, Shield, FileText, Globe, 
    Search, Server, Cpu, Database, 
    Zap, Lock, Users, Terminal,
    ChevronRight, ArrowUpRight
} from 'lucide-react';
import { BrowserWindow } from '@/components/ui/BrowserWindow';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useSiteContext } from "@/components/identity/SiteContext";

// Knowledge Base Article Content
const ARTICLES = {
    'seed001-protocol': {
        title: "START HERE: Seed001 Execution Protocol",
        content: (
            <div className="space-y-8 font-mono text-sm">
                <div className="p-6 rounded-xl bg-purple-500/10 border border-purple-500/20">
                    <h2 className="text-xl font-bold text-white mb-2">STATUS: LOCKED (v3.0.0-RC1)</h2>
                    <p className="text-neutral-300 italic mb-4">
                        "THE EXECUTION PROTOCOL IS ABSOLUTE. THERE ARE NO MORE REPORTS. THERE IS ONLY ACTION."
                    </p>
                    <Badge variant="outline" className="border-purple-500 text-purple-400">DIRECTIVE: IMMEDIATE EXECUTION</Badge>
                </div>

                <div className="space-y-6">
                    <h3 className="text-emerald-400 font-bold text-lg border-b border-white/10 pb-2">PHASE ALPHA: DEPLOY & CONNECT (15 MIN)</h3>
                    <ul className="space-y-4 text-neutral-400">
                        <li className="flex gap-4">
                            <span className="bg-neutral-800 text-white px-2 py-0.5 h-6 rounded text-xs">1</span>
                            <div>
                                <strong className="text-white block">Backend Deployment</strong>
                                Deploy code to Railway/Render/VPS. Verify health.
                            </div>
                        </li>
                        <li className="flex gap-4">
                            <span className="bg-neutral-800 text-white px-2 py-0.5 h-6 rounded text-xs">2</span>
                            <div>
                                <strong className="text-white block">Frontend Deployment</strong>
                                Deploy to Vercel/Netlify. Set <code>VITE_API_URL</code>. Verify load.
                            </div>
                        </li>
                    </ul>
                </div>

                <div className="space-y-6">
                    <h3 className="text-blue-400 font-bold text-lg border-b border-white/10 pb-2">PHASE BRAVO: EXECUTE THE JOURNEY (15 MIN)</h3>
                    <div className="grid gap-4">
                        <div className="p-4 bg-neutral-900 rounded-lg border border-white/5">
                            <h4 className="text-white font-bold mb-1">1. ARRIVE</h4>
                            <p className="text-xs text-neutral-500">Log in at <code>/SeedJourney</code>. Confirm you are inside.</p>
                        </div>
                        <div className="p-4 bg-neutral-900 rounded-lg border border-white/5">
                            <h4 className="text-white font-bold mb-1">2. EXPLORE COMMAND CENTER</h4>
                            <p className="text-xs text-neutral-500">
                                Go to <code>/Dashboard</code> and <code>/SmartStart</code>. <br/>
                                Activate: Business Health, AI Insights, Migration Tool, Onboarding Assistant.
                            </p>
                        </div>
                        <div className="p-4 bg-neutral-900 rounded-lg border border-white/5">
                            <h4 className="text-white font-bold mb-1">3. CONNECT & VALIDATE</h4>
                            <p className="text-xs text-neutral-500">
                                Link Slack at <code>/Integrations</code>. <br/>
                                Test Payment at <code>/Commerce</code>.
                            </p>
                        </div>
                    </div>
                </div>

                <div className="space-y-6">
                    <h3 className="text-orange-400 font-bold text-lg border-b border-white/10 pb-2">PHASE CHARLIE: DOCUMENT EXPERIENCE (15 MIN)</h3>
                    <div className="p-4 bg-neutral-900 rounded-lg border border-white/5">
                        <ul className="list-disc list-inside space-y-2 text-neutral-400">
                            <li>How did the AI tools perform?</li>
                            <li>Was the onboarding intuitive?</li>
                            <li>What needs immediate attention?</li>
                        </ul>
                    </div>
                </div>

                <div className="pt-6 border-t border-white/10">
                    <p className="text-center text-xl font-bold text-white mb-6">"WE ARE GOING HOME."</p>
                    <div className="flex gap-4">
                         <Button onClick={() => window.location.href = '/SeedJourney'} className="flex-1 bg-white text-black hover:bg-neutral-200">
                            Start Phase Bravo
                        </Button>
                        <Button onClick={() => window.location.href = '/GoLive'} variant="outline" className="flex-1">
                            View GoLive Checklist
                        </Button>
                    </div>
                </div>
            </div>
        )
    },
    'getting-started': {
        title: "Welcome to Sovereign Web",
        content: (
            <div className="space-y-6">
                <p className="text-xl text-neutral-400 font-light leading-relaxed">
                    You have taken the first step towards digital independence. This system provides you with the tools to build, deploy, and manage your own sovereign infrastructure.
                </p>
                <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                        <h3 className="text-white font-bold mb-2">The Mission</h3>
                        <p className="text-sm text-neutral-400">To decentralize the web, one node at a time.</p>
                    </div>
                    <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                        <h3 className="text-white font-bold mb-2">Your Role</h3>
                        <p className="text-sm text-neutral-400">Operator. Architect. Builder.</p>
                    </div>
                </div>
            </div>
        )
    },
    'terms': {
        title: "Terms of Service",
        content: (
            <div className="space-y-4 text-sm text-neutral-400 font-mono">
                <p>AGREEMENT PROTOCOL V1.0</p>
                <p>1. YOU OWN YOUR KEYS. WE CANNOT RECOVER THEM.</p>
                <p>2. ALL DATA IS ENCRYPTED CLIENT-SIDE.</p>
                <p>3. DEPLOYMENTS ARE IMMUTABLE ONCE CONFIRMED.</p>
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded text-red-400">
                    WARNING: With great power comes great responsibility. You are the sole custodian of your digital identity.
                </div>
            </div>
        )
    },
    'ai-workflows': {
        title: "AI Workflows & Automation",
        content: (
            <div className="space-y-6 text-sm text-neutral-400">
                <p>The platform exposes a powerful generative AI API for accelerating development workflows.</p>
                
                <div className="space-y-4">
                    <h3 className="text-white font-bold">Supported Intents</h3>
                    <ul className="list-disc list-inside space-y-2 font-mono text-xs">
                        <li><span className="text-[hsl(var(--color-execution))]">generate_ui_code</span>: Creates React/Vue components based on natural language.</li>
                        <li><span className="text-[hsl(var(--color-execution))]">generate_unit_tests</span>: Writes comprehensive test suites (Jest/Vitest) for existing code.</li>
                        <li><span className="text-[hsl(var(--color-execution))]">refactor_code</span>: Optimizes code structure, readability, and performance.</li>
                        <li><span className="text-[hsl(var(--color-execution))]">analyze_project_risks</span>: Scans project data to predict timelines and bottlenecks.</li>
                    </ul>
                </div>

                <div className="p-4 bg-white/5 border border-white/10 rounded-lg">
                    <h4 className="text-white font-bold mb-2">Usage Example (SDK)</h4>
                    <pre className="font-mono text-xs text-neutral-500 overflow-x-auto">
                        {`await base44.functions.invoke('aiGenerate', {
    intent: 'generate_unit_tests',
    input: myCodeString,
    context: { framework: 'Jest' }
});`}
                    </pre>
                </div>
            </div>
        )
    },
    'deployment': {
        title: "Advanced Deployment Strategies",
        content: (
            <div className="space-y-6 text-sm text-neutral-400">
                <p>Our deployment engine supports enterprise-grade release strategies to ensure zero-downtime and high reliability.</p>

                <div className="grid grid-cols-1 gap-4">
                    <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                        <h4 className="text-blue-400 font-bold mb-1">Blue/Green</h4>
                        <p className="text-xs">Deploys to an inactive slot. Traffic is only switched after health checks pass.</p>
                    </div>
                    <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                        <h4 className="text-yellow-400 font-bold mb-1">Canary</h4>
                        <p className="text-xs">Gradually shifts traffic (e.g., 10% → 50% → 100%) to the new version. Automatically rolls back if error rates spike.</p>
                    </div>
                </div>

                <h3 className="text-white font-bold pt-4">Safety Mechanisms</h3>
                <ul className="list-disc list-inside space-y-2">
                    <li><strong>Health Checks:</strong> Probes specific endpoints (e.g., /health) before completing deployment.</li>
                    <li><strong>Rollback Triggers:</strong> Monitors metrics like error rate and latency. Triggers auto-reversion if thresholds are exceeded.</li>
                </ul>
            </div>
        )
    },
    'collaboration': {
        title: "Real-Time Collaboration",
        content: (
            <div className="space-y-6 text-sm text-neutral-400">
                <p>Work together in real-time with your team. The collaboration engine synchronizes state across all connected clients.</p>

                <div className="space-y-4">
                    <h3 className="text-white font-bold">Features</h3>
                    <ul className="list-disc list-inside space-y-2">
                        <li><strong>Live Cursors:</strong> See where your teammates are editing in the Code Editor.</li>
                        <li><strong>Presence:</strong> Real-time online/offline status indicators.</li>
                        <li><strong>Asset Sync:</strong> File uploads and deletions are instantly reflected for all users.</li>
                        <li><strong>Contextual Comments:</strong> Discuss code directly inline.</li>
                    </ul>
                </div>

                <div className="p-4 bg-neutral-900 border border-white/10 rounded-lg">
                    <h4 className="text-white font-bold mb-2">Architecture</h4>
                    <p className="text-xs">
                        Powered by the <span className="font-mono text-[hsl(var(--color-intent))]">collabSync</span> function, which handles event broadcasting and persistence. 
                        Ephemeral events (like cursors) are handled in-memory for low latency, while critical events (comments, assets) are persisted to the database.
                    </p>
                </div>
            </div>
        )
    }
};

export default function Docs() {
    const { systemStage } = useSiteContext();
    const [isOpen, setIsOpen] = useState(false);
    const [activeDoc, setActiveDoc] = useState('seed001-protocol');
    const [search, setSearch] = useState('');

    // Placeholder icon alias
    const Scale = Shield;

    const categories = [
        { name: "Execution Protocol", icon: Shield, items: [
            { id: 'seed001-protocol', label: "START HERE: Seed001" },
            { id: 'go-live', label: "Go Live Checklist" }
        ]},
        { name: "Orientation", icon: Globe, items: [
            { id: 'getting-started', label: "Getting Started" },
            { id: 'philosophy', label: "Philosophy" }
        ]},
        { name: "Legal", icon: Scale, items: [ // Scale isn't imported, swapping to Shield
            { id: 'terms', label: "Terms of Service" },
            { id: 'privacy', label: "Privacy Protocol" }
        ]},
        { name: "Systems", icon: Cpu, items: [
            { id: 'nodes', label: "Node Management" },
            { id: 'identity', label: "Identity Provider" }
        ]},
        { name: "Developer Tools", icon: Terminal, items: [
            { id: 'ai-workflows', label: "AI & Automation" },
            { id: 'deployment', label: "Deployment Strategies" },
            { id: 'collaboration', label: "Real-Time Collaboration" }
        ]}
    ];

    return (
        <div className="h-full w-full flex items-center justify-center bg-transparent">
            {/* Launch Button in case it's closed */}
            {!isOpen && (
                <div className="text-center">
                    <Book className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
                    <h2 className="text-2xl font-bold text-neutral-400 mb-4">Knowledge Base</h2>
                    <Button onClick={() => setIsOpen(true)}>Open Manual</Button>
                </div>
            )}

            <BrowserWindow
                isOpen={isOpen}
                onClose={() => setIsOpen(false)}
                title="System Manual"
                defaultUrl="docs.base44.io"
                viewState="windowed"
                variant="browser"
                onViewStateChange={() => {}} 
            >
                <div className="w-full h-full bg-[#050505] text-white flex overflow-hidden">
                    {/* Sidebar */}
                    <div className="w-64 border-r border-white/5 bg-black/20 flex flex-col">
                        <div className="p-4">
                            <div className="relative">
                                <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search docs..." 
                                    className="pl-9 bg-white/5 border-white/10"
                                    value={search}
                                    onChange={(e) => setSearch(e.target.value)}
                                />
                            </div>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-4 space-y-6">
                            {categories.map((cat, i) => (
                                <div key={i}>
                                    <div className="text-xs font-bold text-neutral-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                                        <cat.icon className="w-3 h-3" /> {cat.name}
                                    </div>
                                    <div className="space-y-1">
                                        {cat.items.map(item => (
                                            <button
                                                key={item.id}
                                                onClick={() => setActiveDoc(item.id)}
                                                className={cn(
                                                    "w-full text-left px-3 py-2 rounded-lg text-sm transition-colors flex items-center justify-between group",
                                                    activeDoc === item.id 
                                                        ? "bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))]" 
                                                        : "text-neutral-400 hover:text-white hover:bg-white/5"
                                                )}
                                            >
                                                {item.label}
                                                {activeDoc === item.id && <ChevronRight className="w-3 h-3" />}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="p-4 border-t border-white/5">
                            <div className="text-xs text-neutral-500 font-mono text-center">
                                DOCS V2.4.1 • OFFLINE CACHED
                            </div>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 overflow-y-auto bg-gradient-to-br from-[#0A0A0A] to-black relative">
                        {/* Hero Header */}
                        <div className="h-64 relative flex items-end p-8 border-b border-white/5 overflow-hidden">
                            <div className="absolute inset-0 bg-[hsl(var(--color-intent))]/5" />
                            <div className="absolute top-0 right-0 p-8 opacity-20">
                                <Book className="w-64 h-64 text-white transform rotate-12 translate-x-10 -translate-y-10" />
                            </div>
                            <div className="relative z-10">
                                <div className="flex items-center gap-2 text-[hsl(var(--color-intent))] mb-2">
                                    <span className="text-xs font-bold uppercase tracking-widest">Documentation</span>
                                    <ChevronRight className="w-3 h-3" />
                                    <span className="text-xs font-bold uppercase tracking-widest">
                                        {categories.flatMap(c => c.items).find(i => i.id === activeDoc)?.label}
                                    </span>
                                </div>
                                <h1 className="text-4xl font-bold text-white tracking-tight">
                                    {ARTICLES[activeDoc]?.title || "Article Not Found"}
                                </h1>
                            </div>
                        </div>

                        {/* Article Body */}
                        <div className="p-8 max-w-3xl">
                            {ARTICLES[activeDoc]?.content || (
                                <div className="text-neutral-500 italic">
                                    Content currently syncing from the mesh network...
                                </div>
                            )}

                            {/* Feedback */}
                            <div className="mt-16 pt-8 border-t border-white/5 flex items-center justify-between">
                                <span className="text-sm text-neutral-500">Was this protocol helpful?</span>
                                <div className="flex gap-2">
                                    <Button size="sm" variant="outline" className="border-white/10 hover:bg-white/5">Yes</Button>
                                    <Button size="sm" variant="outline" className="border-white/10 hover:bg-white/5">No</Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </BrowserWindow>
        </div>
    );
}