import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Home, CheckCircle2, Circle, 
    Wifi, Lock, ShoppingCart, DollarSign
} from 'lucide-react';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer
} from '@/components/ui/design-system/System';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import moment from 'moment';

// Functional Widgets
import BudgetWidget from '@/components/lifestyle/BudgetWidget';
import GroceryList from '@/components/lifestyle/GroceryList';
import SmartHomeControls from '@/components/lifestyle/SmartHomeControls';

export default function Household() {
    const queryClient = useQueryClient();
    
    const { data: tasks = [] } = useQuery({
        queryKey: ['household_tasks'],
        queryFn: () => base44.entities.HouseholdTask.list('-created_date', 50),
        initialData: []
    });

    const pendingTasks = tasks.filter(t => t.status === 'todo');
    const completedTasks = tasks.filter(t => t.status === 'done');

    // XP Logic for completion
    const completeTaskMutation = useMutation({
        mutationFn: async (task) => {
            // Update task status
            await base44.entities.HouseholdTask.update(task.id, { status: 'done' });
            
            // Award XP (if we want to replicate DailyDeck logic here, ideally this logic is centralized)
            // For now just update task.
            // A better way would be to have a useUserXP hook or service.
            // Since we are moving fast, I'll just update status.
            
            // To be consistent with "Gamification", I will add the XP update here too if requested, 
            // but the prompt was "populate the task list". I'll keep it simple: Status update.
            return task;
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['household_tasks']);
        }
    });

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Home className="w-4 h-4 text-emerald-500" />
                                        <OrientingText className="tracking-widest font-bold text-emerald-500">SANCTUARY OS</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Home Management</IntentText>
                                </div>
                                <Badge variant="outline" className="border-emerald-500/20 text-emerald-500 bg-emerald-500/10">
                                    SYSTEMS NOMINAL
                                </Badge>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2">
                                <Layer level="orientation" className="p-2 flex items-center justify-between">
                                    <div className="flex items-center gap-2 text-neutral-400"><Wifi className="w-3 h-3" /> <StateText>Network</StateText></div>
                                    <StateText className="text-emerald-500">Online</StateText>
                                </Layer>
                                <Layer level="orientation" className="p-2 flex items-center justify-between">
                                    <div className="flex items-center gap-2 text-neutral-400"><Lock className="w-3 h-3" /> <StateText>Security</StateText></div>
                                    <StateText className="text-emerald-500">Armed</StateText>
                                </Layer>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <div className="flex justify-between items-center mb-4">
                                <OrientingText>CHORE BOARD</OrientingText>
                                <Badge variant="secondary" className="text-[10px]">{pendingTasks.length} PENDING</Badge>
                            </div>
                            
                            <div className="space-y-2 overflow-y-auto max-h-[400px] pr-2">
                                {pendingTasks.length === 0 && <div className="text-center py-8 text-neutral-500 text-xs italic">All chores complete. Sanctuary is clean.</div>}
                                {pendingTasks.map(task => (
                                    <div 
                                        key={task.id} 
                                        onClick={() => completeTaskMutation.mutate(task)}
                                        className="p-3 bg-neutral-900/50 border border-white/5 rounded flex items-center gap-3 cursor-pointer hover:border-emerald-500/50 hover:bg-neutral-900 transition-all group"
                                    >
                                        <div className="text-neutral-500 group-hover:text-emerald-500 transition-colors">
                                            <Circle className="w-4 h-4" />
                                        </div>
                                        <div className="flex-1">
                                            <div className="text-sm font-medium text-neutral-200 group-hover:text-white decoration-emerald-500/50 group-hover:line-through transition-all">{task.title}</div>
                                            <div className="flex gap-2 text-[10px] text-neutral-500">
                                                <span>{task.room}</span>
                                                {task.assignee && <span>• @{task.assignee}</span>}
                                                {task.due_date && <span>• Due {moment(task.due_date).fromNow()}</span>}
                                            </div>
                                        </div>
                                        <Badge variant="outline" className="text-[9px] border-amber-500/20 text-amber-500">
                                            +{task.xp_reward || 10} XP
                                        </Badge>
                                    </div>
                                ))}

                                {completedTasks.length > 0 && (
                                    <>
                                        <div className="my-4 border-t border-white/5" />
                                        <StateText className="mb-2 opacity-50 text-[10px]">RECENTLY COMPLETED</StateText>
                                        {completedTasks.slice(0, 3).map(task => (
                                            <div key={task.id} className="p-2 opacity-50 flex items-center gap-3">
                                                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                                                <div className="text-xs line-through text-neutral-500">{task.title}</div>
                                            </div>
                                        ))}
                                    </>
                                )}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_1fr]">
                        <Quadrant type="intent" dominance="dominant" className="border-b">
                            <SmartHomeControls />
                        </Quadrant>
                        
                        <Quadrant type="state" className="flex flex-col border-t-0 rounded-t-none p-0 overflow-hidden">
                            <div className="h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-white/5">
                                <div className="flex-1 p-4 min-w-0">
                                    <div className="flex items-center gap-2 mb-4 text-emerald-500">
                                        <DollarSign className="w-4 h-4" />
                                        <OrientingText>HOUSEHOLD BUDGET</OrientingText>
                                    </div>
                                    <BudgetWidget />
                                </div>
                                <div className="flex-1 p-4 min-w-0">
                                    <div className="flex items-center gap-2 mb-4 text-orange-400">
                                        <ShoppingCart className="w-4 h-4" />
                                        <OrientingText>PROVISIONS</OrientingText>
                                    </div>
                                    <GroceryList />
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}