import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation, Link } from 'react-router-dom'; // Added useLocation, Link
import { base44 } from '@/api/base44Client';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, Layer, SemanticDot 
} from '@/components/ui/design-system/SystemDesign';
import { createPageUrl } from '@/utils'; // Added createPageUrl
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { SystemForm, SystemField, SystemLog } from '@/components/ui/design-system/SystemContent';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
    Sparkles, Target, Layers, ArrowRight,
    Milestone, Calendar, FileText, ArrowLeft, Globe
} from 'lucide-react';
import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import { toast } from "sonner";
import ProcessCompletion from '@/components/ui/design-system/ProcessCompletion';
import { SystemConfirmation } from '@/components/ui/design-system/SystemDialogs';
import { Dialog, DialogContent } from "@/components/ui/dialog";

export default function RoadmapPage() {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const initialContext = searchParams.get('context') || "";

    const [prompt, setPrompt] = useState(initialContext);
    const [showCompletion, setShowCompletion] = useState(false);
    const [showResetConfirm, setShowResetConfirm] = useState(false);
    
    // Auto-trigger simulation if context is present
    useEffect(() => {
        if (initialContext) {
            toast.info("Context Loaded", {
                description: `Strategic intent initialized from: "${initialContext}"`
            });
        }
    }, [initialContext]);
    
    // Mock Roadmaps/Milestones
    const { data: milestones = [], refetch } = useQuery({
        queryKey: ['milestones'],
        queryFn: async () => {
            return [
                { id: 1, title: 'Phase 1: Foundation', status: 'completed', date: '2024-01-15' },
                { id: 2, title: 'Phase 2: Alpha Release', status: 'active', date: '2024-03-01' },
                { id: 3, title: 'Phase 3: Beta Testing', status: 'pending', date: '2024-05-01' },
                { id: 4, title: 'Phase 4: Public Launch', status: 'pending', date: '2024-07-01' }
            ];
        },
        initialData: []
    });

    const handleGenerate = () => {
        if (!prompt) return;
        toast.info("Generating roadmap strategy...", {
            description: "AI is analyzing requirements and resource allocation."
        });
        setTimeout(() => {
            setShowCompletion(true);
        }, 1500);
    };

    const handleReset = () => {
        setPrompt("");
        toast.success("Strategy reset.");
        setShowResetConfirm(false);
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Sparkles className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">DREAMCATCHER</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Roadmap Builder</IntentText>
                                </div>
                                <div className="flex gap-2">
                                    <Link to={createPageUrl('SearchResults') + `?q=${encodeURIComponent(initialContext || '')}&scope=web`}>
                                        <Button variant="outline" size="sm" className="h-8 text-xs border-white/10 hover:bg-white/5">
                                            <Globe className="w-3 h-3 mr-2" />
                                            Web Scan
                                        </Button>
                                    </Link>
                                    <Link to={createPageUrl('SearchResults') + `?q=${encodeURIComponent(initialContext || '')}&scope=local`}>
                                        <Button variant="outline" size="sm" className="h-8 text-xs border-white/10 hover:bg-white/5">
                                            <ArrowLeft className="w-3 h-3 mr-2" />
                                            Back to Stack
                                        </Button>
                                    </Link>
                                </div>
                            </div>
                            
                            <div className="space-y-4">
                                <div className="p-4 rounded bg-neutral-900/50 border border-white/5">
                                    <div className="flex items-center gap-2 mb-2">
                                        <Target className="w-4 h-4 text-cyan-400" />
                                        <StateText className="font-bold">Active Goals</StateText>
                                    </div>
                                    <div className="text-2xl font-mono text-white">4</div>
                                </div>
                                <div className="p-4 rounded bg-neutral-900/50 border border-white/5">
                                    <div className="flex items-center gap-2 mb-2">
                                        <Calendar className="w-4 h-4 text-violet-400" />
                                        <StateText className="font-bold">Next Milestone</StateText>
                                    </div>
                                    <div className="text-sm font-mono text-white">Alpha Release (14d)</div>
                                </div>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">EXECUTION LOG</OrientingText>
                            <SystemLog 
                                className="h-full"
                                logs={milestones.map(m => ({
                                    type: 'PHASE',
                                    content: m.title,
                                    status: m.status === 'completed' ? 'settled' : m.status === 'active' ? 'active' : 'pending',
                                    timestamp: m.date
                                }))}
                            />
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-8 flex flex-col overflow-y-auto">
                            <div className="max-w-2xl mx-auto w-full space-y-8">
                                <div className="space-y-2 text-center">
                                    <h1 className="text-3xl font-light text-white">Strategic Planning</h1>
                                    <p className="text-neutral-500">Transform semantic signals into actionable strategy.</p>
                                </div>

                                <SystemForm
                                    title="Initialize Sequence"
                                    description="Enter a project scope to generate a comprehensive execution plan."
                                >
                                    <SystemField label="Project Intent">
                                        <div className="flex gap-2">
                                            <Input 
                                                value={prompt}
                                                onChange={(e) => setPrompt(e.target.value)}
                                                placeholder="e.g., Launch a new marketing campaign for Q3..."
                                                className="bg-neutral-950 border-white/10"
                                            />
                                            <Button 
                                                onClick={handleGenerate}
                                                className="bg-[hsl(var(--color-intent))] text-white"
                                            >
                                                Generate <ArrowRight className="w-4 h-4 ml-2" />
                                            </Button>
                                        </div>
                                        {milestones.length > 0 && (
                                            <div className="mt-2">
                                                <Button 
                                                    variant="ghost" 
                                                    onClick={() => setShowResetConfirm(true)}
                                                    className="text-xs text-neutral-500 hover:text-red-500 hover:bg-red-500/10"
                                                >
                                                    Reset Strategy
                                                </Button>
                                            </div>
                                        )}
                                    </SystemField>
                                </SystemForm>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <SystemCard 
                                        title="Milestones" 
                                        subtitle="Automatic phasing" 
                                        icon={Milestone}
                                        status="active"
                                    />
                                    <SystemCard 
                                        title="Resources" 
                                        subtitle="Asset allocation" 
                                        icon={Layers}
                                        status="settled"
                                    />
                                    <SystemCard 
                                        title="Strategy" 
                                        subtitle="AI optimization" 
                                        icon={FileText}
                                        status="active"
                                    />
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
            
            <TutorialOverlay 
                tutorialId="roadmap_intro"
                steps={[
                    { title: "Strategic Planning", content: "Use AI to generate comprehensive roadmaps from simple intents.", position: "center" },
                    { title: "Milestone Tracking", content: "Monitor your progress against generated phases in the sidebar.", position: "left" }
                ]}
            />

            <Dialog open={showCompletion} onOpenChange={setShowCompletion}>
                <DialogContent className="bg-transparent border-none shadow-none max-w-2xl">
                    <ProcessCompletion 
                        title="Strategy Generated"
                        subtitle="Your roadmap has been synthesized from the provided intent."
                        artifacts={[
                            { name: "Executive_Summary.pdf", type: "Document", size: "1.2 MB" },
                            { name: "Gantt_Chart.xml", type: "Data", size: "45 KB" }
                        ]}
                        actions={[
                            { label: "View Roadmap", icon: Layers, onClick: () => setShowCompletion(false), primary: true },
                            { label: "Export", icon: FileText, onClick: () => toast.success("Export started") }
                        ]}
                        onClose={() => setShowCompletion(false)}
                    />
                </DialogContent>
            </Dialog>

            <SystemConfirmation 
                open={showResetConfirm}
                onOpenChange={setShowResetConfirm}
                title="Reset Strategy?"
                description="This will clear your current roadmap and prompt. This action cannot be undone."
                onConfirm={handleReset}
                variant="destructive"
                confirmText="Reset"
            />
        </div>
    );
}