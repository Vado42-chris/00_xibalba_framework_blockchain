import React, { useState } from 'react';
import { 
    Users, MessageCircle, Heart, Share2, 
    Trophy, Star, Hash, ArrowLeft, Send
} from 'lucide-react';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer 
} from '@/components/ui/design-system/System';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

const MOCK_POSTS = [
    { id: 1, user: "Neon", title: "Optimizing Node Latency for Edge Compute", content: "I've been experimenting with the new kernel configurations...", tags: ["Infrastructure", "Network"], replies: 24, likes: 12 },
    { id: 2, user: "Viper", title: "Visual Forge Custom Components Guide", content: "Here is a breakdown of how to create reusable UI elements...", tags: ["Studio", "Design"], replies: 8, likes: 45 },
    { id: 3, user: "Echo", title: "Security Protocols for v2.5 RFC", content: "Requesting comments on the proposed auth handshake...", tags: ["Security", "RFC"], replies: 156, likes: 89 },
    { id: 4, user: "Ghost", title: "Help with Agent Swarm Configuration", content: "My agents keep deadlocking on shared resources...", tags: ["Agents", "Help"], replies: 3, likes: 1 }
];

export default function Community() {
    const [selectedThread, setSelectedThread] = useState(null);
    const [filter, setFilter] = useState('all');

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Hive Mind" className="border-b">
                            <div className="flex items-center gap-2 mb-4">
                                <Users className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                                <OrientingText className="text-xl font-bold tracking-widest text-[hsl(var(--color-execution))]">COMMUNITY</OrientingText>
                            </div>
                            <IntentText className="text-sm opacity-70 max-w-md">
                                Connect with other architects, share your blueprints, and collaborate on the future of the network.
                            </IntentText>
                            <div className="flex gap-2 mt-4">
                                <Badge variant="outline" className="bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))] border-[hsl(var(--color-execution))]/20">
                                    342 ONLINE
                                </Badge>
                                <Badge variant="outline" className="border-white/10 text-neutral-400">
                                    GLOBAL
                                </Badge>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Trending" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">TRENDING TOPICS</OrientingText>
                            <div className="flex flex-wrap gap-2 mb-6">
                                {['#AI_Ethics', '#React_Patterns', '#System_Design', '#Rust_Lang', '#Cyberpunk_UI', '#Performance', '#Open_Source'].map(tag => (
                                    <Badge 
                                        key={tag} 
                                        variant="secondary" 
                                        className="cursor-pointer hover:bg-white/20 transition-colors"
                                        onClick={() => setFilter(tag)}
                                    >
                                        {tag}
                                    </Badge>
                                ))}
                            </div>
                            
                            <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                                <StateText className="mb-2">Your Stats</StateText>
                                <div className="flex justify-between items-center mb-1">
                                    <span className="text-xs text-neutral-500">Reputation</span>
                                    <span className="text-xs font-mono text-[hsl(var(--color-execution))]">Level 4</span>
                                </div>
                                <div className="w-full bg-white/10 h-1 rounded overflow-hidden">
                                    <div className="h-full bg-[hsl(var(--color-execution))]" style={{width: '65%'}} />
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Feed" dominance="dominant" className="p-0 flex flex-col border-b" scrollable={false}>
                            {selectedThread ? (
                                <div className="flex flex-col h-full animate-in slide-in-from-right-4">
                                    <div className="p-4 border-b border-white/5 bg-neutral-900/30 flex items-center gap-4">
                                        <Button variant="ghost" size="icon" onClick={() => setSelectedThread(null)}>
                                            <ArrowLeft className="w-4 h-4" />
                                        </Button>
                                        <OrientingText>THREAD VIEW</OrientingText>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-8 scrollbar-thin">
                                        <div className="mb-6">
                                            <div className="flex items-center gap-3 mb-4">
                                                <div className="w-10 h-10 rounded-full bg-[hsl(var(--color-intent))] flex items-center justify-center text-black font-bold">
                                                    {selectedThread.user[0]}
                                                </div>
                                                <div>
                                                    <div className="font-bold text-white">{selectedThread.title}</div>
                                                    <div className="text-xs text-neutral-500">Posted by {selectedThread.user} • 2h ago</div>
                                                </div>
                                            </div>
                                            <p className="text-neutral-300 leading-relaxed mb-6">
                                                {selectedThread.content}
                                                <br/><br/>
                                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                            </p>
                                            <div className="flex gap-4">
                                                <Button size="sm" variant="ghost" className="gap-2 text-neutral-400 hover:text-white">
                                                    <Heart className="w-4 h-4" /> {selectedThread.likes}
                                                </Button>
                                                <Button size="sm" variant="ghost" className="gap-2 text-neutral-400 hover:text-white">
                                                    <MessageCircle className="w-4 h-4" /> {selectedThread.replies}
                                                </Button>
                                                <Button size="sm" variant="ghost" className="gap-2 text-neutral-400 hover:text-white">
                                                    <Share2 className="w-4 h-4" /> Share
                                                </Button>
                                            </div>
                                        </div>
                                        
                                        <div className="border-t border-white/5 pt-6 space-y-6">
                                            <StateText>Replies</StateText>
                                            {[1, 2, 3].map((i) => (
                                                <div key={i} className="flex gap-4">
                                                    <div className="w-8 h-8 rounded-full bg-neutral-800 flex-shrink-0" />
                                                    <div className="space-y-2">
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-xs font-bold text-neutral-400">User_{99+i}</span>
                                                            <span className="text-[10px] text-neutral-600">1h ago</span>
                                                        </div>
                                                        <p className="text-sm text-neutral-400">This is a really interesting perspective. Have you considered the implications on latency?</p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    <div className="p-4 border-t border-white/5 bg-neutral-900/50">
                                        <div className="relative">
                                            <Input placeholder="Write a reply..." className="pr-12 bg-black border-white/10" />
                                            <Button size="icon" className="absolute right-1 top-1 h-7 w-7 bg-[hsl(var(--color-intent))] text-black">
                                                <Send className="w-3 h-3" />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <>
                                    <div className="p-4 border-b border-white/5 bg-neutral-900/30 flex justify-between items-center">
                                        <OrientingText>LATEST DISCUSSIONS</OrientingText>
                                        <Button size="sm" className="h-7 text-xs bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90">
                                            New Topic
                                        </Button>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
                                        {MOCK_POSTS.map((post) => (
                                            <SystemCard
                                                key={post.id}
                                                title={post.title}
                                                subtitle={`by ${post.user}`}
                                                metric={`${post.likes} likes`}
                                                status="active"
                                                icon={MessageCircle}
                                                onClick={() => setSelectedThread(post)}
                                                className="hover:border-[hsl(var(--color-intent))]"
                                            >
                                                <div className="flex gap-2 mt-2">
                                                    {post.tags.map(tag => (
                                                        <Badge key={tag} variant="outline" className="text-[9px] h-4 px-1 border-white/5 bg-white/5 text-neutral-400">
                                                            {tag}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </SystemCard>
                                        ))}
                                    </div>
                                </>
                            )}
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Leaders" dominance="supporting" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">TOP CONTRIBUTORS</OrientingText>
                            <div className="space-y-3">
                                {[
                                    { name: "Zero", rank: 1, xp: "450k", role: "Architect" },
                                    { name: "Cipher", rank: 2, xp: "420k", role: "Security" },
                                    { name: "Pixel", rank: 3, xp: "380k", role: "Designer" },
                                ].map((user) => (
                                    <SystemCard
                                        key={user.name}
                                        title={user.name}
                                        subtitle={user.role}
                                        metric={`${user.xp} XP`}
                                        status="execution"
                                        icon={() => (
                                            <div className="w-6 h-6 rounded-full bg-[hsl(var(--color-execution))] text-black flex items-center justify-center text-xs font-bold">
                                                {user.rank}
                                            </div>
                                        )}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}