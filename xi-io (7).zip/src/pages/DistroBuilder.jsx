import React, { useState } from 'react';
import { Disc, Settings, Cpu, Package, Layers, Download, Play, Terminal, Plus, Trash2, Globe, FileCode } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText } from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BuildMonitor } from '@/components/distro/BuildMonitor';
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';

export default function DistroBuilder() {
    const [activeTab, setActiveTab] = useState('os');
    const [config, setConfig] = useState({
        name: 'MyCustomOS',
        base: 'debian-12',
        kernel: '5.15-lts',
        packages: ['xi-core', 'docker', 'nginx', 'python3'],
        branding: 'default'
    });
    
    // Site Export Config
    const [siteConfig, setSiteConfig] = useState({
        customDomain: 'myapp.local',
        analyticsId: '',
        envVars: { 'VITE_API_URL': 'https://api.myapp.com' }
    });

    const [isBuilding, setIsBuilding] = useState(false);
    const [newPackage, setNewPackage] = useState('');

    const handleBuild = () => {
        setIsBuilding(true);
        toast.success("Build Pipeline Initiated", { description: "Compiling kernel modules..." });
    };

    const handleExportSite = async () => {
        const toastId = toast.loading("Packaging Site for Docker...");
        try {
            // Find the landing page or first page
            const pages = await base44.entities.ContentPage.list({ slug: 'home' });
            const pageId = pages[0]?.id; // If no home, backend handles error or fallback

            const response = await base44.functions.invoke('exportSite', { 
                pageId, 
                config: siteConfig 
            });

            // Handle file download
            const blob = new Blob([response.data], { type: 'application/zip' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${config.name.toLowerCase()}-export.zip`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            
            toast.success("Site Exported Successfully", { id: toastId });
        } catch (error) {
            toast.error("Export Failed: " + error.message, { id: toastId });
        }
    };

    const addPackage = (e) => {
        e.preventDefault();
        if (newPackage && !config.packages.includes(newPackage)) {
            setConfig(prev => ({ ...prev, packages: [...prev.packages, newPackage] }));
            setNewPackage('');
        }
    };

    const removePackage = (pkg) => {
        setConfig(prev => ({ ...prev, packages: prev.packages.filter(p => p !== pkg) }));
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Blueprint" className="border-b">
                            <div className="mb-6">
                                <div className="flex items-center gap-2 mb-2">
                                    <Disc className="w-4 h-4 text-neutral-500" />
                                    <OrientingText className="tracking-widest font-bold text-neutral-500">DISTRO FORGE</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Custom ISO Builder</IntentText>
                                <p className="text-sm text-neutral-400 mt-2">
                                    Architect a minimal Linux distribution tailored for your node hardware.
                                </p>
                            </div>

                            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full h-full flex flex-col">
                                <TabsList className="grid w-full grid-cols-2 bg-white/5 p-1 mb-4">
                                    <TabsTrigger value="os">OS Distro</TabsTrigger>
                                    <TabsTrigger value="site">Site Container</TabsTrigger>
                                    <TabsTrigger value="test">Simulation</TabsTrigger>
                                </TabsList>

                                <TabsContent value="os" className="space-y-4 mt-0">
                                    <div className="space-y-1">
                                        <StateText className="text-xs">Distro Name</StateText>
                                        <Input 
                                            value={config.name}
                                            onChange={(e) => setConfig({...config, name: e.target.value})}
                                            className="bg-neutral-950 border-white/10"
                                        />
                                    </div>
                                    <div className="space-y-1">
                                        <StateText className="text-xs">Base Image</StateText>
                                        <div className="grid grid-cols-2 gap-2">
                                            {['debian-12', 'alpine-3', 'arch-linux', 'xi-minimal'].map(base => (
                                                <button
                                                    key={base}
                                                    onClick={() => setConfig({...config, base})}
                                                    className={cn(
                                                        "px-3 py-2 rounded text-xs border transition-all text-left",
                                                        config.base === base 
                                                            ? "bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))] text-white" 
                                                            : "bg-white/5 border-white/10 text-neutral-400 hover:border-white/20"
                                                    )}
                                                >
                                                    {base}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                </TabsContent>

                                <TabsContent value="site" className="space-y-4 mt-0">
                                    <div className="p-3 bg-blue-900/10 border border-blue-500/20 rounded mb-4">
                                        <h4 className="text-blue-400 text-xs font-bold mb-1 flex items-center gap-2">
                                            <FileCode className="w-3 h-3" /> Docker Export
                                        </h4>
                                        <p className="text-[10px] text-blue-200/60">
                                            Package your current site as a deployable Docker container with Nginx.
                                        </p>
                                    </div>
                                    <div className="space-y-1">
                                        <StateText className="text-xs">Custom Domain (VIRTUAL_HOST)</StateText>
                                        <Input 
                                            value={siteConfig.customDomain}
                                            onChange={(e) => setSiteConfig({...siteConfig, customDomain: e.target.value})}
                                            className="bg-neutral-950 border-white/10 font-mono text-xs"
                                        />
                                    </div>
                                    <div className="space-y-1">
                                        <StateText className="text-xs">Google Analytics ID</StateText>
                                        <Input 
                                            value={siteConfig.analyticsId}
                                            onChange={(e) => setSiteConfig({...siteConfig, analyticsId: e.target.value})}
                                            placeholder="G-XXXXXXXX"
                                            className="bg-neutral-950 border-white/10 font-mono text-xs"
                                        />
                                    </div>
                                </TabsContent>

                                <TabsContent value="test" className="space-y-4 mt-0 h-full">
                                    <div className="h-full bg-black rounded border border-white/10 p-4 font-mono text-[10px] text-green-500 overflow-y-auto relative">
                                        <div className="absolute top-2 right-2 flex gap-2">
                                            <Button size="sm" variant="outline" className="h-6 text-[10px] bg-white/5 border-white/10">Reboot</Button>
                                            <Button size="sm" variant="outline" className="h-6 text-[10px] bg-red-500/10 border-red-500/30 text-red-500">Power Off</Button>
                                        </div>
                                        <div className="opacity-50 select-none">
                                            [    0.000000] Linux version 6.1.0-18-amd64 (debian-kernel@lists.debian.org)<br/>
                                            [    0.000000] Command line: BOOT_IMAGE=/boot/vmlinuz-6.1.0-18-amd64 root=UUID=...<br/>
                                            [    0.012345] x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'<br/>
                                            [    0.150000] systemd[1]: Detected architecture x86-64.<br/>
                                            [    0.180000] systemd[1]: Set hostname to &lt;{config.name}&gt;.<br/>
                                            [    1.200000] xi-init[44]: Initializing Xibalba Node Protocol...<br/>
                                            [    1.450000] xi-init[44]: Connecting to Mesh... [OK]<br/>
                                            <span className="animate-pulse">_</span>
                                        </div>
                                    </div>
                                </TabsContent>
                            </Tabs>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Configuration" className="flex flex-col border-t-0 rounded-t-none" scrollable={false}>
                            {activeTab === 'os' ? (
                                <div className="p-4 space-y-4 h-full flex flex-col">
                                    <div className="space-y-1 shrink-0">
                                        <StateText className="text-xs">System Packages</StateText>
                                        <form onSubmit={addPackage} className="flex gap-2">
                                            <Input 
                                                value={newPackage}
                                                onChange={(e) => setNewPackage(e.target.value)}
                                                placeholder="apt install..."
                                                className="bg-neutral-950 border-white/10 h-8 text-xs"
                                            />
                                            <Button type="submit" size="sm" className="h-8 bg-white/10 hover:bg-white/20"><Plus className="w-3 h-3" /></Button>
                                        </form>
                                    </div>

                                    <div className="flex-1 overflow-y-auto space-y-1 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                        {config.packages.map(pkg => (
                                            <div key={pkg} className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5 group">
                                                <div className="flex items-center gap-2">
                                                    <Package className="w-3 h-3 text-neutral-500" />
                                                    <span className="text-xs font-mono text-neutral-300">{pkg}</span>
                                                </div>
                                                <button onClick={() => removePackage(pkg)} className="opacity-0 group-hover:opacity-100 text-red-400 hover:bg-red-400/10 p-1 rounded transition-all">
                                                    <Trash2 className="w-3 h-3" />
                                                </button>
                                            </div>
                                        ))}
                                    </div>

                                    <Button 
                                        className="w-full bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 font-bold shrink-0"
                                        onClick={handleBuild}
                                        disabled={isBuilding}
                                    >
                                        <Play className="w-4 h-4 mr-2" />
                                        {isBuilding ? 'BUILDING...' : 'COMPILE ISO'}
                                    </Button>
                                </div>
                            ) : (
                                <div className="p-4 space-y-4 h-full flex flex-col justify-end">
                                    <div className="bg-neutral-900 rounded p-4 border border-white/5 flex-1">
                                        <StateText className="text-xs mb-2">Generated Artifacts</StateText>
                                        <ul className="text-xs text-neutral-400 space-y-1 font-mono">
                                            <li className="flex items-center gap-2"><FileCode className="w-3 h-3" /> Dockerfile</li>
                                            <li className="flex items-center gap-2"><Settings className="w-3 h-3" /> docker-compose.yml</li>
                                            <li className="flex items-center gap-2"><Globe className="w-3 h-3" /> nginx.conf</li>
                                            <li className="flex items-center gap-2"><Layers className="w-3 h-3" /> /src content</li>
                                        </ul>
                                    </div>
                                    <Button 
                                        className="w-full bg-blue-500 text-white hover:bg-blue-400 font-bold shrink-0"
                                        onClick={handleExportSite}
                                    >
                                        <Download className="w-4 h-4 mr-2" />
                                        EXPORT DOCKER ZIP
                                    </Button>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Compiler" dominance="dominant" className="p-0 flex flex-col h-full overflow-hidden border-b bg-black relative">
                            {isBuilding ? (
                                <BuildMonitor 
                                    config={config} 
                                    onComplete={() => {
                                        setIsBuilding(false);
                                        toast.success("ISO Generated Successfully");
                                    }} 
                                />
                            ) : (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                    <Layers className="w-16 h-16 text-neutral-500 stroke-1" />
                                    <div>
                                        <IntentText className="text-xl font-light">Compiler Ready</IntentText>
                                        <StateText className="max-w-xs mx-auto mt-2">Configure your manifest on the left to initialize the build pipeline.</StateText>
                                    </div>
                                </div>
                            )}
                        </Quadrant>

                        <Quadrant type="state" step="4" title="Kernel Config" dominance="supporting" className="border-t-0 rounded-t-none">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-3 rounded bg-white/5 border border-white/5">
                                    <div className="flex items-center gap-2 mb-1 text-xs text-neutral-400">
                                        <Cpu className="w-3 h-3" /> Kernel Version
                                    </div>
                                    <div className="text-sm font-mono text-white">{config.kernel}</div>
                                </div>
                                <div className="p-3 rounded bg-white/5 border border-white/5">
                                    <div className="flex items-center gap-2 mb-1 text-xs text-neutral-400">
                                        <Settings className="w-3 h-3" /> Init System
                                    </div>
                                    <div className="text-sm font-mono text-white">systemd</div>
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}