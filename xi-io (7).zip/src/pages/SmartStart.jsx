import React from 'react';
import BusinessHealthWidget from '@/components/dashboards/widgets/BusinessHealthWidget';
import PlainInsightEngine from '@/components/intelligence/PlainInsightEngine';
import EasyMigrator from '@/components/tools/EasyMigrator';
import LiveUserActivity from '@/components/analytics/LiveUserActivity';
import DataArchiving from '@/components/settings/DataArchiving';
import MarketingGenerator from '@/components/tools/MarketingGenerator';
import PredictiveAlerts from '@/components/dashboards/widgets/PredictiveAlerts';
import SupportChatbot from '@/components/support/SupportChatbot';
import { Button } from "@/components/ui/button";
import { Book } from 'lucide-react';

export default function SmartStart() {
    return (
        <div className="min-h-screen bg-black text-white p-6 md:p-12 overflow-y-auto relative">
            <SupportChatbot />
            <div className="max-w-7xl mx-auto space-y-8">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="space-y-2">
                        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Welcome, CEO.</h1>
                        <p className="text-lg text-neutral-400">Here is your high-level overview and tools to get moving.</p>
                    </div>
                    <Button 
                        onClick={() => window.location.href = '/ApiDocs'}
                        className="bg-white/10 hover:bg-white/20 text-white border border-white/10"
                    >
                        <Book className="w-4 h-4 mr-2" />
                        Developer API Docs
                    </Button>
                </div>

                {/* 1. Enhanced Dashboard Widgets */}
                <section>
                    <h2 className="text-xl font-semibold mb-4 text-neutral-300">Business Health</h2>
                    <BusinessHealthWidget />
                </section>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-auto">
                    {/* 2. AI Insight Engine */}
                    <section className="h-full">
                         <h2 className="text-xl font-semibold mb-4 text-neutral-300">Strategic Intelligence</h2>
                         <PlainInsightEngine />
                    </section>

                    {/* 3. Migration Tool */}
                    <section className="h-full">
                        <h2 className="text-xl font-semibold mb-4 text-neutral-300">Data Import</h2>
                        <EasyMigrator />
                    </section>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-auto">
                    {/* 4. Live Activity */}
                    <section className="h-full">
                        <h2 className="text-xl font-semibold mb-4 text-neutral-300">User Activity</h2>
                        <LiveUserActivity />
                    </section>

                    {/* 5. Predictive Alerts (New) */}
                    <section className="h-full">
                        <h2 className="text-xl font-semibold mb-4 text-neutral-300">Predictive Sentinel</h2>
                        <PredictiveAlerts />
                    </section>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-auto">
                     {/* 6. Marketing Generator (New) */}
                     <section className="h-full">
                        <h2 className="text-xl font-semibold mb-4 text-neutral-300">Growth Engine</h2>
                        <MarketingGenerator />
                    </section>

                    {/* 7. Archiving */}
                    <section className="h-full">
                        <h2 className="text-xl font-semibold mb-4 text-neutral-300">Data Governance</h2>
                        <DataArchiving />
                    </section>
                </div>
            </div>
        </div>
    );
}