import React from 'react';
import { 
    ShoppingBag, Package, Star, Download, 
    Zap, Code, Shield, Users, ArrowRight
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import DepthBackground from '@/components/ui/design-system/DepthBackground';
import { SiteHeader } from '@/components/site/SiteHeader';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function MarketplaceLanding() {
    return (
        <div className="min-h-screen bg-transparent text-neutral-200 font-sans selection:bg-rose-500/30 overflow-hidden relative">
            <DepthBackground theme="rose-500" />
            <SiteHeader mode="nav" />

            <div className="relative z-10 pt-32 pb-20 px-6 max-w-[1400px] mx-auto">
                
                {/* Hero */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-32">
                    <div className="space-y-8">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-mono">
                            <ShoppingBag className="w-3 h-3" />
                            <span>ALGORITHM ECONOMY</span>
                        </div>
                        <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight leading-tight">
                            The Module <br />
                            <span className="text-rose-500">Marketplace</span>
                        </h1>
                        <p className="text-xl text-neutral-400 leading-relaxed">
                            Discover, buy, and sell autonomous agents, intelligence models, and system extensions. 
                            The first decentralized exchange for sovereign code.
                        </p>
                        <div className="flex gap-4">
                            <Link to={createPageUrl('Marketplace')}>
                                <Button className="bg-rose-600 text-white hover:bg-rose-500 font-bold h-12 px-8 rounded-full">
                                    Browse Catalog
                                </Button>
                            </Link>
                            <Link to={createPageUrl('Marketplace') + '?action=create'}>
                                <Button variant="outline" className="h-12 px-8 rounded-full border-white/10 text-neutral-300 hover:bg-white/5">
                                    Become a Creator
                                </Button>
                            </Link>
                        </div>
                    </div>

                    {/* Showcase Graphic */}
                    <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-tr from-rose-500/20 to-purple-500/20 blur-3xl rounded-full" />
                        <div className="relative bg-neutral-900/80 border border-white/10 rounded-2xl p-6 grid grid-cols-2 gap-4">
                            <ItemCard title="Security Sentinel" type="Agent" price="$49/mo" />
                            <ItemCard title="Deep Search v4" type="Model" price="$120" />
                            <ItemCard title="CRM Connector" type="Integration" price="Free" />
                            <ItemCard title="React Architect" type="Agent" price="$299" />
                        </div>
                    </div>
                </div>

                {/* Categories */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-32">
                    <CategoryCard icon={Users} title="Agents" count="120+" />
                    <CategoryCard icon={Code} title="Modules" count="450+" />
                    <CategoryCard icon={Zap} title="Integrations" count="85+" />
                    <CategoryCard icon={Package} title="Datasets" count="30+" />
                </div>

                {/* CTA */}
                <div className="bg-gradient-to-r from-rose-900/20 to-neutral-900 border border-rose-500/20 rounded-3xl p-12 text-center space-y-6">
                    <h2 className="text-3xl font-bold text-white">Ready to upgrade your system?</h2>
                    <p className="text-neutral-400 max-w-xl mx-auto">
                        Log in to the platform to purchase, install, and manage your marketplace assets directly from the console.
                    </p>
                    <Link to={createPageUrl('Marketplace')}>
                        <Button className="bg-white text-black hover:bg-neutral-200 font-bold h-12 px-10 rounded-full">
                            Enter Marketplace <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </Link>
                </div>

            </div>
        </div>
    );
}

function ItemCard({ title, type, price }) {
    return (
        <div className="bg-neutral-800/50 p-4 rounded-xl border border-white/5 flex flex-col gap-2">
            <div className="w-10 h-10 rounded bg-white/5 mb-2" />
            <div className="text-sm font-bold text-white">{title}</div>
            <div className="flex justify-between items-center text-xs">
                <span className="text-neutral-500">{type}</span>
                <span className="text-rose-400 font-mono">{price}</span>
            </div>
        </div>
    );
}

function CategoryCard({ icon: Icon, title, count }) {
    return (
        <div className="p-6 rounded-xl bg-white/5 border border-white/5 flex items-center gap-4 hover:bg-white/10 transition-colors cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-neutral-900 flex items-center justify-center">
                <Icon className="w-5 h-5 text-neutral-400" />
            </div>
            <div>
                <div className="font-bold text-white">{title}</div>
                <div className="text-xs text-neutral-500 font-mono">{count} Items</div>
            </div>
        </div>
    );
}