import React from 'react';
import { ConnectorWizard } from '@/components/connectors/ConnectorWizard';

export default function ConnectorBuilder() {
    return (
        <div className="min-h-screen bg-black/90">
            <ConnectorWizard />
        </div>
    );
}