import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Fingerprint, User, Shield, Lock, Key, CheckCircle2, Search, ExternalLink } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    IntentText, StateText, Layer, 
    OrientingText, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { BrowserWindow } from '@/components/ui/BrowserWindow';
import { Button } from '@/components/ui/button';
import { useSiteContext } from '@/components/identity/SiteContext';

export default function Identity() {
    const { systemStage } = useSiteContext();
    const [selectedUser, setSelectedUser] = useState(null);
    const [filter, setFilter] = useState('');
    const [previewOpen, setPreviewOpen] = useState(false);

    const { data: users = [] } = useQuery({
        queryKey: ['users'],
        queryFn: () => base44.entities.User.list(),
        initialData: []
    });

    const filtered = users.filter(u => u.email.toLowerCase().includes(filter.toLowerCase()));
    const adminCount = users.filter(u => u.role === 'admin').length;
    
    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Stats" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Fingerprint className="w-4 h-4 text-[hsl(var(--color-orientation))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-orientation))]">IDENTITY PROVIDER</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Access Control</IntentText>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">Identities</StateText>
                                    <IntentText className="text-xl">{users.length}</IntentText>
                                </div>
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">Admins</StateText>
                                    <IntentText className="text-xl text-[hsl(var(--color-error))]">{adminCount}</IntentText>
                                </div>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Directory" className="border-t-0 rounded-t-none flex flex-col">
                            <div className="mb-4 relative shrink-0">
                                <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search users..." 
                                    className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs"
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-2 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {filtered.map((user) => (
                                    <SystemCard
                                        key={user.id}
                                        title={user.full_name || user.email.split('@')[0]}
                                        subtitle={user.role}
                                        status={user.role === 'admin' ? 'warning' : 'active'}
                                        metric={user.email[0].toUpperCase()}
                                        active={selectedUser?.id === user.id}
                                        onClick={() => setSelectedUser(user)}
                                        icon={User}
                                    >
                                        <ActionDock 
                                            primaryAction={{
                                                label: "Inspect",
                                                icon: Search,
                                                onClick: (e) => {
                                                    e.stopPropagation();
                                                    setSelectedUser(user);
                                                }
                                            }}
                                        />
                                    </SystemCard>
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Permission" dominance="dominant" className="p-0 flex flex-col overflow-hidden border-b">
                            {selectedUser ? (
                                <div className="flex flex-col h-full animate-in fade-in duration-300">
                                    <SystemDetailHeader
                                        title={selectedUser.full_name || "Unknown User"}
                                        subtitle={selectedUser.email}
                                        category={`${selectedUser.role} ACCESS`}
                                        icon={Fingerprint}
                                    />
                                    
                                    <div className="px-8 mt-4 flex gap-4">
                                        <Button 
                                            variant="outline" 
                                            className="gap-2"
                                            onClick={() => setPreviewOpen(true)}
                                        >
                                            <ExternalLink className="w-4 h-4" /> View Public Profile
                                        </Button>
                                    </div>

                                    <div className="p-8 space-y-6 overflow-y-auto bg-transparent flex-1">
                                        <div className="grid grid-cols-2 gap-4">
                                             <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                                                <StateText className="mb-2">AUTH METHOD</StateText>
                                                <div className="flex items-center gap-2">
                                                    <Key className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                                    <IntentText>SSO (Google)</IntentText>
                                                </div>
                                             </div>
                                             <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                                                <StateText className="mb-2">SESSION</StateText>
                                                <div className="flex items-center gap-2">
                                                    <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))] animate-pulse" />
                                                    <IntentText>Active Now</IntentText>
                                                </div>
                                             </div>
                                        </div>

                                        <Layer level="state">
                                            <OrientingText className="mb-4">PERMISSIONS SCOPE</OrientingText>
                                            <div className="space-y-2">
                                                {['read:dashboard', 'read:reports', selectedUser.role === 'admin' ? 'write:settings' : null, selectedUser.role === 'admin' ? 'delete:users' : null].filter(Boolean).map(perm => (
                                                    <div key={perm} className="flex items-center gap-3 p-2 bg-neutral-900 rounded border border-white/5">
                                                        <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                                        <StateText className="font-mono">{perm}</StateText>
                                                    </div>
                                                ))}
                                            </div>
                                        </Layer>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                    <User className="w-16 h-16 text-neutral-500 stroke-1" />
                                    <div>
                                        <IntentText className="text-xl font-light">User Profile</IntentText>
                                        <StateText>Select an identity to manage permissions and access.</StateText>
                                    </div>
                                </div>
                            )}
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Security" dominance="supporting" className="border-t-0 rounded-t-none">
                             <div className="p-4 bg-[hsl(var(--color-execution))]/10 rounded border border-[hsl(var(--color-execution))]/20">
                                <div className="flex items-center gap-2 mb-2">
                                    <Shield className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                    <OrientingText className="text-[hsl(var(--color-execution))]">PROVIDER STATUS</OrientingText>
                                </div>
                                <StateText className="text-xs">
                                    Base44 Identity service is operating normally. 2FA enforcement is active for Admin roles.
                                </StateText>
                             </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />

            {/* Public Profile Browser Preview */}
            {selectedUser && (
                <BrowserWindow
                    isOpen={previewOpen}
                    onClose={() => setPreviewOpen(false)}
                    title={`${selectedUser.full_name}'s Profile`}
                    defaultUrl={`http://users.base44.io/${selectedUser.id}`}
                    viewState="windowed"
                    variant="preview"
                    initialStage={systemStage}
                    onViewStateChange={() => {}} // Placeholder
                >
                    <div className="w-full h-full bg-[#050505] flex flex-col items-center justify-center relative overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/10 to-transparent pointer-events-none" />
                        
                        <div className="relative z-10 text-center space-y-6">
                            <div className="w-32 h-32 rounded-full border-4 border-white/5 bg-white/5 flex items-center justify-center mx-auto shadow-2xl">
                                <span className="text-4xl font-light text-white">{selectedUser.email[0].toUpperCase()}</span>
                            </div>
                            <div>
                                <h1 className="text-4xl font-bold text-white mb-2">{selectedUser.full_name || "User"}</h1>
                                <p className="text-neutral-400">{selectedUser.email}</p>
                            </div>
                            <div className="flex justify-center gap-4">
                                <div className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm">
                                    {selectedUser.role.toUpperCase()}
                                </div>
                                <div className="px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                                    VERIFIED
                                </div>
                            </div>
                        </div>
                    </div>
                </BrowserWindow>
            )}
        </div>
    );
}