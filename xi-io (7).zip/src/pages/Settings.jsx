import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer 
} from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemNav } from '@/components/ui/design-system/SystemComponents';
import { Settings as SettingsIcon, Cpu, Shield, Globe, Database, Package } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { GuideBox } from '@/components/ui/GuideBox';

import GeneralSettings from '@/components/settings/GeneralSettings';
import SecuritySettings from '@/components/settings/SecuritySettings';
import IntelligenceSettings from '@/components/settings/IntelligenceSettings';
import DatabaseSettings from '@/components/settings/DatabaseSettings';
import AddonManager from '@/components/marketplace/AddonManager';
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { toast } from 'sonner';
import ThemeManager from '@/components/identity/ThemeManager';
import { Palette } from 'lucide-react';

export default function Settings() {
    const [activeTab, setActiveTab] = useState("personalization");

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Config" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <SettingsIcon className="w-4 h-4 text-neutral-400" />
                                        <OrientingText className="tracking-widest font-bold">SYSTEM CONFIG</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">
                                        Global Settings
                                    </IntentText>
                                </div>
                            </div>
                            
                            <GuideBox title="Configuration Guide">
                                <p className="mb-2">
                                    Control the fundamental behavior of your Base44 OS.
                                </p>
                                <ul className="list-disc list-inside space-y-1 opacity-80">
                                    <li><strong>Intelligence</strong>: Connect AI models (GPT-4, Claude) to power your agents.</li>
                                    <li><strong>Security</strong>: Manage access keys and permissions.</li>
                                </ul>
                            </GuideBox>
                            
                            <ActionDock 
                                className="mt-4"
                                actions={[
                                    { label: "Export Config", icon: Database, onClick: () => toast.success("Configuration exported") },
                                    { label: "Reset Defaults", icon: Shield, onClick: () => toast.info("Resetting to defaults...") }
                                ]}
                            />
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Modules" className="border-t-0 rounded-t-none">
                            <SystemNav
                                activeId={activeTab}
                                onSelect={setActiveTab}
                                items={[
                                    { id: 'personalization', label: 'Personalization', icon: Palette, type: 'active' },
                                    { id: 'general', label: 'General', icon: Globe, type: 'settled' },
                                    { id: 'intelligence', label: 'Intelligence', icon: Cpu, type: 'settled' },
                                    { id: 'security', label: 'Security', icon: Shield, type: 'warning' },
                                    { id: 'database', label: 'Database', icon: Database, type: 'settled' },
                                    { id: 'addons', label: 'Extensions', icon: Package, type: 'settled' }
                                ]}
                            />
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Parameters" dominance="dominant" className="p-8 h-full overflow-y-auto border-b">
                            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                                <TabsContent value="personalization" className="mt-0 h-full">
                                    <ThemeManager />
                                </TabsContent>

                                <TabsContent value="general" className="mt-0">
                                    <GeneralSettings className="bg-transparent" />
                                </TabsContent>
                                
                                <TabsContent value="intelligence" className="mt-0">
                                    <IntelligenceSettings className="bg-transparent" />
                                </TabsContent>

                                <TabsContent value="security" className="mt-0">
                                    <SecuritySettings className="bg-transparent" />
                                </TabsContent>

                                <TabsContent value="database" className="mt-0">
                                    <DatabaseSettings className="bg-transparent" />
                                </TabsContent>

                                <TabsContent value="addons" className="mt-0 h-full">
                                    <AddonManager />
                                </TabsContent>
                            </Tabs>
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Summary" dominance="supporting" className="border-t-0 rounded-t-none">
                             <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                                <OrientingText className="mb-2">ACTIVE CONFIGURATION</OrientingText>
                                <div className="space-y-2">
                                    <div className="flex justify-between text-xs">
                                        <span className="text-neutral-500">Environment</span>
                                        <span className="text-white font-mono">PRODUCTION</span>
                                    </div>
                                    <div className="flex justify-between text-xs">
                                        <span className="text-neutral-500">Version</span>
                                        <span className="text-white font-mono">v2.4.1</span>
                                    </div>
                                    <div className="flex justify-between text-xs">
                                        <span className="text-neutral-500">Last Sync</span>
                                        <span className="text-green-400 font-mono">Just now</span>
                                    </div>
                                </div>
                             </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}