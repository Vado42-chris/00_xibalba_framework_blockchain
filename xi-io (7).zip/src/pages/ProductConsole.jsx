import React from 'react';
import { 
    Cpu, Zap, GitBranch, Code, Globe, 
    Terminal, Command, ChevronRight, Sparkles,
    Layout, CheckCircle2, ArrowRight
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import DepthBackground from '@/components/ui/design-system/DepthBackground';
import { SiteHeader } from '@/components/site/SiteHeader';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion } from 'framer-motion';

export default function ProductConsole() {
    return (
        <div className="min-h-screen bg-black text-neutral-200 font-sans selection:bg-purple-500/30 overflow-hidden relative">
            <DepthBackground theme="violet-500" />
            <SiteHeader mode="nav" />

            <div className="relative z-10 pt-32 pb-20 px-6 max-w-[1400px] mx-auto">
                {/* Hero */}
                <div className="text-center space-y-8 mb-24 relative">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-purple-500/20 blur-[120px] rounded-full -z-10" />
                    
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-mono mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
                        <Sparkles className="w-3 h-3" />
                        <span>PUBLIC BETA LIVE</span>
                    </div>
                    
                    <h1 className="text-6xl md:text-8xl font-bold text-white tracking-tight leading-tight animate-in fade-in slide-in-from-bottom-8 duration-700 delay-100">
                        Code at the <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-indigo-500">Speed of Thought</span>
                    </h1>
                    
                    <p className="text-xl text-neutral-400 max-w-2xl mx-auto leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
                        The world's first AI-Native editor combining the speed of Zed, the intelligence of Cherry Studio, and the flexibility of Cursor.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row justify-center gap-4 pt-8 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
                        <Link to={createPageUrl('Studio') + '?mode=architect'}>
                            <Button className="bg-white text-black hover:bg-neutral-200 font-bold h-14 px-8 rounded-full text-lg shadow-[0_0_20px_-5px_rgba(255,255,255,0.3)] transition-all hover:scale-105">
                                Launch Editor <ArrowRight className="w-5 h-5 ml-2" />
                            </Button>
                        </Link>
                        <Link to={createPageUrl('Docs')}>
                            <Button variant="outline" className="h-14 px-8 rounded-full border-white/10 text-neutral-300 hover:bg-white/5 text-lg">
                                View Documentation
                            </Button>
                        </Link>
                    </div>
                </div>

                {/* Editor Preview */}
                <div className="relative rounded-xl border border-white/10 bg-[#09090b] shadow-2xl mb-32 overflow-hidden group animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-500">
                    <div className="absolute top-0 left-0 w-full h-10 bg-[#0c0c0e] border-b border-white/5 flex items-center px-4 justify-between">
                        <div className="flex gap-2">
                            <div className="w-3 h-3 rounded-full bg-red-500/20" />
                            <div className="w-3 h-3 rounded-full bg-yellow-500/20" />
                            <div className="w-3 h-3 rounded-full bg-green-500/20" />
                        </div>
                        <div className="text-xs font-mono text-neutral-500">Code Architect.app</div>
                    </div>
                    
                    <div className="grid grid-cols-12 h-[600px] pt-10">
                        {/* Fake Sidebar */}
                        <div className="col-span-2 border-r border-white/5 p-4 space-y-4 hidden md:block">
                            <div className="space-y-2">
                                <div className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Explorer</div>
                                <div className="space-y-1">
                                    <div className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white cursor-pointer"><ChevronRight className="w-3 h-3" /> src</div>
                                    <div className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white cursor-pointer pl-4"><Code className="w-3 h-3 text-blue-400" /> App.js</div>
                                    <div className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white cursor-pointer pl-4"><Layout className="w-3 h-3 text-yellow-400" /> styles.css</div>
                                </div>
                            </div>
                        </div>
                        
                        {/* Fake Code Area */}
                        <div className="col-span-12 md:col-span-7 p-6 font-mono text-sm relative">
                            <div className="absolute top-6 right-6 flex gap-2">
                                <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20"><Zap className="w-3 h-3 mr-1" /> AI Connected</Badge>
                            </div>
                            <div className="text-purple-400">import</div> <span className="text-white">React</span> <div className="text-purple-400 inline">from</div> <span className="text-green-400">'react'</span>;
                            <br /><br />
                            <div className="text-blue-400">export default function</div> <span className="text-yellow-300">CodeArchitect</span>() {'{'}
                            <br />
                            &nbsp;&nbsp;<div className="text-gray-500 inline">// AI: Analyzing component structure...</div>
                            <br />
                            &nbsp;&nbsp;<div className="text-purple-400 inline">return</div> (
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">div</span> <span className="text-yellow-300">className</span>=<span className="text-green-400">"future-of-coding"</span>&gt;
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">h1</span>&gt;Built for Speed&lt;/<span className="text-red-400">h1</span>&gt;
                            <br />
                            &nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-red-400">div</span>&gt;
                            <br />
                            &nbsp;&nbsp;);
                            <br />
                            {'}'}
                            
                            {/* AI Chat Overlay */}
                            <div className="absolute bottom-6 right-6 w-80 bg-[#18181b] border border-purple-500/30 rounded-xl p-4 shadow-2xl backdrop-blur-xl">
                                <div className="flex gap-3 mb-3">
                                    <div className="w-6 h-6 rounded bg-purple-600 flex items-center justify-center"><Sparkles className="w-3 h-3 text-white" /></div>
                                    <div className="text-xs text-neutral-300">I've optimized the rendering loop. Want to apply changes?</div>
                                </div>
                                <div className="flex gap-2">
                                    <Button size="sm" className="h-7 text-xs bg-purple-600 hover:bg-purple-500 w-full">Apply Fix</Button>
                                    <Button size="sm" variant="outline" className="h-7 text-xs border-white/10 w-full">Explain</Button>
                                </div>
                            </div>
                        </div>
                        
                        {/* Fake Preview */}
                        <div className="col-span-3 border-l border-white/5 bg-white flex items-center justify-center hidden md:flex">
                            <div className="text-center">
                                <h1 className="text-4xl font-bold text-black mb-4">Built for Speed</h1>
                                <button className="px-6 py-2 bg-black text-white rounded-full">Interactive Preview</button>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Features Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
                    <FeatureCard 
                        icon={Zap}
                        title="Zed-Core Performance"
                        description="Built on a Rust-based architecture for instant startup times and lag-free typing, even in massive codebases."
                        color="text-yellow-400"
                    />
                    <FeatureCard 
                        icon={Cpu}
                        title="Cherry Studio AI"
                        description="Access the world's best models (GPT-4, Claude 3, Llama 3) directly in your editor with full context awareness."
                        color="text-purple-400"
                    />
                    <FeatureCard 
                        icon={Layout}
                        title="Cursor Flexibility"
                        description="Familiar VS Code keybindings and extensions, enhanced with AI-native features like Composer and Diff View."
                        color="text-blue-400"
                    />
                </div>
            </div>
        </div>
    );
}

function FeatureCard({ icon: Icon, title, description, color }) {
    return (
        <div className="p-8 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all group hover:-translate-y-1">
            <div className={`w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-6 group-hover:bg-white/10 transition-colors`}>
                <Icon className={`w-6 h-6 ${color}`} />
            </div>
            <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
            <p className="text-neutral-400 leading-relaxed text-sm">{description}</p>
        </div>
    );
}