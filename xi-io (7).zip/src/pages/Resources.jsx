import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { 
    Book, Shield, MessageSquare, Search, FileText, 
    ChevronRight, ExternalLink, HelpCircle, ArrowLeft,
    CheckCircle2
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/System';
import { FluidGrid } from '@/components/ui/FluidGrid';
import ReactMarkdown from 'react-markdown';
import { cn } from "@/lib/utils";

export default function ResourcesPage() {
    const [searchParams] = useSearchParams();
    const initialTab = searchParams.get('tab') || 'docs';
    const contextId = searchParams.get('context'); 

    const [activeTab, setActiveTab] = useState(initialTab); 
    const [selectedArticle, setSelectedArticle] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');

    const { data: articles = [] } = useQuery({
        queryKey: ['knowledge_articles'],
        queryFn: () => base44.entities.KnowledgeArticle.list(),
        initialData: []
    });

    const { data: tickets = [] } = useQuery({
        queryKey: ['support_tickets'],
        queryFn: () => base44.entities.SupportTicket.list(),
        initialData: []
    });

    const filteredArticles = articles.filter(article => {
        const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesContext = contextId ? article.integration_id === contextId : true;
        return matchesSearch && matchesContext;
    });

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Book className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">KNOWLEDGE BASE</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">System Resources</IntentText>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-1 gap-2">
                                <Button 
                                    variant={activeTab === 'docs' ? 'secondary' : 'ghost'} 
                                    onClick={() => { setActiveTab('docs'); setSelectedArticle(null); }}
                                    className="justify-start text-xs h-8"
                                >
                                    <Book className="w-3 h-3 mr-2" /> Documentation
                                </Button>
                                <Button 
                                    variant={activeTab === 'privacy' ? 'secondary' : 'ghost'} 
                                    onClick={() => setActiveTab('privacy')}
                                    className="justify-start text-xs h-8"
                                >
                                    <Shield className="w-3 h-3 mr-2" /> Privacy & Legal
                                </Button>
                                <Button 
                                    variant={activeTab === 'forum' ? 'secondary' : 'ghost'} 
                                    onClick={() => setActiveTab('forum')}
                                    className="justify-start text-xs h-8"
                                >
                                    <MessageSquare className="w-3 h-3 mr-2" /> Community Forum
                                </Button>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none flex flex-col">
                            {activeTab === 'docs' && (
                                <>
                                    <div className="mb-4 relative shrink-0">
                                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                                        <Input 
                                            placeholder="Search articles..." 
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs"
                                        />
                                    </div>
                                    <div className="flex-1 overflow-y-auto space-y-2 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                        {filteredArticles.length === 0 && (
                                            <div className="text-center py-8 opacity-30 border border-dashed border-white/5 rounded">
                                                <FileText className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                                                <StateText>No articles found</StateText>
                                            </div>
                                        )}
                                        {filteredArticles.map(article => (
                                            <div 
                                                key={article.id} 
                                                onClick={() => setSelectedArticle(article)}
                                                className={cn(
                                                    "p-3 rounded border cursor-pointer transition-all group",
                                                    selectedArticle?.id === article.id 
                                                        ? 'bg-neutral-900 border-[hsl(var(--color-intent))]' 
                                                        : 'bg-neutral-950 border-white/5 hover:border-white/20'
                                                )}
                                            >
                                                <IntentText className="text-sm font-medium mb-1 group-hover:text-[hsl(var(--color-intent))] transition-colors">
                                                    {article.title}
                                                </IntentText>
                                                <StateText className="text-[10px] opacity-50 line-clamp-2">
                                                    {article.content.substring(0, 80)}...
                                                </StateText>
                                            </div>
                                        ))}
                                    </div>
                                </>
                            )}
                            
                            {activeTab === 'forum' && (
                                <div className="space-y-2 overflow-y-auto h-full pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                    {tickets.map(ticket => (
                                        <div key={ticket.id} className="p-3 rounded bg-neutral-950 border border-white/5 flex flex-col gap-1 hover:border-white/20">
                                            <div className="flex justify-between items-start">
                                                <IntentText className="text-xs font-bold text-neutral-300">{ticket.subject}</IntentText>
                                                <Badge variant="secondary" className="text-[9px] h-4">{ticket.status}</Badge>
                                            </div>
                                            <StateText className="text-[9px] opacity-50">{ticket.user_email}</StateText>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                            {activeTab === 'docs' && selectedArticle && (
                                <div className="p-8">
                                    <div className="mb-6 pb-6 border-b border-white/5">
                                        <Badge variant="outline" className="mb-4 border-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]">
                                            DOCS
                                        </Badge>
                                        <h1 className="text-3xl font-light text-white mb-2">{selectedArticle.title}</h1>
                                        <div className="flex gap-2">
                                            {selectedArticle.tags?.map(tag => (
                                                <Badge key={tag} variant="secondary" className="text-[10px] bg-neutral-900 text-neutral-500">#{tag}</Badge>
                                            ))}
                                        </div>
                                    </div>
                                    <div className="prose prose-invert prose-sm max-w-none text-neutral-300">
                                        <ReactMarkdown>{selectedArticle.content}</ReactMarkdown>
                                    </div>
                                </div>
                            )}

                            {activeTab === 'docs' && !selectedArticle && (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                    <Book className="w-16 h-16 text-neutral-500 stroke-1" />
                                    <div>
                                        <IntentText className="text-xl font-light">Documentation</IntentText>
                                        <StateText>Select an article to read.</StateText>
                                    </div>
                                </div>
                            )}

                            {activeTab === 'privacy' && (
                                <div className="p-8 space-y-8">
                                    <OrientingText className="text-xl mb-4">PRIVACY PROTOCOLS</OrientingText>
                                    
                                    <Layer level="state" className="p-6 space-y-4">
                                        <div className="flex items-start gap-4">
                                            <Shield className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                                            <div>
                                                <IntentText className="font-bold mb-1">Zero-Knowledge Credentials</IntentText>
                                                <p className="text-sm text-neutral-400 leading-relaxed">
                                                    API keys are encrypted client-side before transmission. We use AES-256-GCM. 
                                                    Keys are only decrypted in volatile memory during active agent execution.
                                                </p>
                                            </div>
                                        </div>
                                    </Layer>

                                    <Layer level="state" className="p-6 space-y-4">
                                        <div className="flex items-start gap-4">
                                            <CheckCircle2 className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                                            <div>
                                                <IntentText className="font-bold mb-1">Data Sovereignty</IntentText>
                                                <p className="text-sm text-neutral-400 leading-relaxed">
                                                    You own your graph. Export your entire entity database as a JSON snapshot at any time via the Control Panel.
                                                </p>
                                            </div>
                                        </div>
                                    </Layer>
                                </div>
                            )}

                            {activeTab === 'forum' && (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                    <MessageSquare className="w-16 h-16 text-neutral-500 stroke-1" />
                                    <div>
                                        <IntentText className="text-xl font-light">Community Uplink</IntentText>
                                        <StateText>Connect to the global developer mesh.</StateText>
                                    </div>
                                    <Button variant="outline">
                                        <ExternalLink className="w-4 h-4 mr-2" /> Open Discord
                                    </Button>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}