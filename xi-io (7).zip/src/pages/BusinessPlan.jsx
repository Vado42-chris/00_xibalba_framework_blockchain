import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Target, TrendingUp, Flag, CheckCircle2, AlertTriangle, Circle, Plus, Search } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    IntentText, StateText, SemanticDot, Layer, 
    AtomicParagraph, OrientingText, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export default function BusinessPlan() {
    const [selectedGoal, setSelectedGoal] = useState(null);
    const [filter, setFilter] = useState('');

    const { data: goals = [] } = useQuery({
        queryKey: ['business_goals'],
        queryFn: () => base44.entities.BusinessGoal.list(),
        initialData: []
    });

    const filteredGoals = goals.filter(g => (g.title || '').toLowerCase().includes(filter.toLowerCase()));
    
    // Stats
    const onTrack = goals.filter(g => g.status === 'on_track').length;
    const atRisk = goals.filter(g => g.status === 'at_risk').length;

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <HumorousLoader delay={1150} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Target className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">STRATEGY CORE</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Business Modeling</IntentText>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-2">
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">Objectives</StateText>
                                    <IntentText className="text-xl">{goals.length}</IntentText>
                                </div>
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">On Track</StateText>
                                    <IntentText className="text-xl text-[hsl(var(--color-execution))]">{onTrack}</IntentText>
                                </div>
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">At Risk</StateText>
                                    <IntentText className="text-xl text-[hsl(var(--color-error))]">{atRisk}</IntentText>
                                </div>
                            </div>

                            <div className="mt-6 pt-6 border-t border-white/10">
                                <div className="flex items-center gap-2 mb-2">
                                    <TrendingUp className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">ECONOMY</OrientingText>
                                </div>
                                <div className="p-3 bg-neutral-900/50 rounded border border-white/5 space-y-2">
                                    <div className="flex justify-between items-center">
                                        <StateText className="text-xs">Projected ARR</StateText>
                                        <IntentText className="text-sm font-mono">$0.00</IntentText>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <StateText className="text-xs">Upstream Royalties</StateText>
                                        <IntentText className="text-sm font-mono text-neutral-500">$0.00</IntentText>
                                    </div>
                                    <div className="h-px bg-white/5" />
                                    <div className="text-[10px] text-neutral-500 text-center">
                                        Smart Contracts Active
                                    </div>
                                </div>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none flex flex-col">
                            <div className="mb-4 relative shrink-0">
                                <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search goals..." 
                                    className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs"
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-2 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {filteredGoals.map((goal) => (
                                    <SystemCard
                                        key={goal.id}
                                        title={goal.title}
                                        subtitle={goal.strategy_pillar?.toUpperCase()}
                                        status={goal.status === 'on_track' ? 'active' : 'warning'}
                                        metric={`${goal.progress}%`}
                                        active={selectedGoal?.id === goal.id}
                                        onClick={() => setSelectedGoal(goal)}
                                        icon={Target}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
                right={
                    <HumorousLoader delay={1750} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col">
                            {selectedGoal ? (
                                <div className="flex flex-col h-full animate-in fade-in duration-300">
                                    <SystemDetailHeader
                                        title={selectedGoal.title}
                                        subtitle={`Target: ${selectedGoal.target_date}`}
                                        category={selectedGoal.strategy_pillar?.toUpperCase()}
                                        icon={Target}
                                    >
                                        <div className="flex items-center gap-2">
                                            <StateText className="text-xs">Progress</StateText>
                                            <Badge variant="outline" className="font-mono">{selectedGoal.progress}%</Badge>
                                        </div>
                                    </SystemDetailHeader>
                                    
                                    <div className="p-8 space-y-8 overflow-y-auto bg-transparent flex-1">
                                        <Layer level="intent">
                                            <OrientingText className="mb-2">EXECUTION STATUS</OrientingText>
                                            <AtomicParagraph className="text-lg">
                                                Current status is <span className={selectedGoal.status === 'on_track' ? 'text-[hsl(var(--color-execution))]' : 'text-[hsl(var(--color-error))]'}>{selectedGoal.status?.replace('_', ' ').toUpperCase()}</span>.
                                            </AtomicParagraph>
                                        </Layer>
                                        
                                        <div className="grid grid-cols-2 gap-6">
                                            <div className="p-4 border border-white/5 rounded bg-neutral-900/50">
                                                <StateText>KPI Metric</StateText>
                                                <IntentText className="text-xl">{selectedGoal.kpi_metric || "N/A"}</IntentText>
                                            </div>
                                            <div className="p-4 border border-white/5 rounded bg-neutral-900/50">
                                                <StateText>Current Value</StateText>
                                                <IntentText className="text-xl font-mono">{selectedGoal.kpi_value || "0"}</IntentText>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                    <Target className="w-16 h-16 text-neutral-500 stroke-1" />
                                    <div>
                                        <IntentText className="text-xl font-light">Strategic Vision</IntentText>
                                        <StateText>Select a goal to view operational details and KPIs.</StateText>
                                    </div>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
            />
        </div>
    );
}