import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useSiteContext } from '@/components/identity/SiteContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from '@/components/api/service';
import { 
  Rocket, Sparkles, MessageSquare, Briefcase, ShoppingBag, RotateCcw, Brain,
  Timer, Flag, Swords, Map, Calendar, HelpCircle
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import CodeAssistant from '@/components/assistants/CodeAssistant';
import { 
  Layer, OrientingText, IntentText, StateText, 
  SemanticDot, AtomicParagraph, QuadrantGrid, Quadrant
} from '@/components/ui/design-system/SystemDesign';
import CodeEditor from '@/components/editor/CodeEditor';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { SystemTerminal } from '@/components/ui/design-system/SystemContent';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { cn } from '@/lib/utils';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import DeploymentModal from '@/components/reaper/DeploymentModal';
import { SystemConfirmation } from '@/components/ui/design-system/SystemDialogs';
import { toast } from "sonner";
import { BrowserWindow } from '@/components/ui/BrowserWindow';
import { SystemStatusHero } from '@/components/dashboards/widgets/SystemStatusHero';
import { Explainable } from '@/components/ui/design-system/RosettaStone';
import ToolPreview from '@/components/previews/ToolPreview';
import { Progress } from "@/components/ui/progress";
import { format, differenceInDays } from 'date-fns';
import { Badge } from "@/components/ui/badge";

const TerminalView = () => {
    const [lines, setLines] = useState([
        { content: "> initializing dev environment...", color: "text-blue-400" },
        { content: "> loading modules...", color: "text-neutral-400" }
    ]);

    useEffect(() => {
        const interval = setInterval(() => {
            const msgs = [
                { content: "> compiling assets...", color: "text-neutral-500" },
                { content: "✓ optimized images", color: "text-green-500" },
                { content: "> hmr update", color: "text-blue-400" },
                { content: "• waiting for changes...", color: "text-neutral-600" }
            ];
            const msg = msgs[Math.floor(Math.random() * msgs.length)];
            setLines(prev => [...prev.slice(-8), msg]);
        }, 2500);
        return () => clearInterval(interval);
    }, []);

    return (
        <SystemTerminal 
            initialLines={lines}
            onCommand={(cmd, cb) => {
                setTimeout(() => cb(`Executed: ${cmd}`), 500);
            }}
            className="border-none bg-transparent"
        />
    );
};

export default function WorkRoom() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  const projectId = new URLSearchParams(location.search).get('projectId');

  useEffect(() => {
      api.getSystemInit().then(({ user }) => setUser(user)).catch(() => setUser(null)).finally(() => setLoading(false));
  }, []);

  // Fetch Project Details if projectId is present
  const { data: activeProject } = useQuery({
      queryKey: ['project', projectId],
      queryFn: async () => {
          if (!projectId || projectId === 'current') return null;
          const projects = await base44.entities.Project.list({ filter: { id: projectId } });
          return projects[0];
      },
      enabled: !!projectId
  });

  // Fetch installed addons for dynamic UI - Placeholder until service has specific endpoint
  const { data: installations = [] } = useQuery({
      queryKey: ['installed_addons'],
      queryFn: () => api.searchMarketplace(''), // Temporary: Get all items as installs for now or implement getInstalls in service
      initialData: []
  });

  // Fetch Active Sprint via Service
  const { data: activeSprint } = useQuery({
      queryKey: ['active_sprint'],
      queryFn: async () => {
          const sprint = await api.getActiveSprint();
          return sprint || {
              name: 'Quest: Genesis Protocol',
              goal: 'Establish baseline functionality',
              start_date: new Date().toISOString(),
              end_date: new Date(Date.now() + 86400000 * 7).toISOString(),
              status: 'active',
              xp_reward: 5000,
              type: 'MAIN_QUEST'
          };
      }
  });

  // Helper to check if an addon is active
  const hasAddon = (name) => {
      return installations.some(i => i.addon_id === name || (user?.role === 'ROOT_ADMIN')); 
  };
  
  const { data: marketplaceItems = [] } = useQuery({
        queryKey: ['marketplace_items_lite'],
        queryFn: () => api.searchMarketplace(''),
        initialData: []
  });

  const isAddonActive = (name) => {
      if (user?.role === 'ROOT_ADMIN') return true; 
      const item = marketplaceItems.find(i => i.name === name);
      if (!item) return false;
      return installations.some(i => i.addon_id === item.id);
  };

  const [isDeployOpen, setIsDeployOpen] = useState(false);
  const [isResetOpen, setIsResetOpen] = useState(false);
  const [activeFile, setActiveFile] = useState('src/App.js');
  
  // Browser State
  const [browserState, setBrowserState] = useState('docked'); // docked | windowed | maximized | minimized
  const [isBrowserOpen, setIsBrowserOpen] = useState(false);

  const handleBrowserStateChange = (newState) => {
      setBrowserState(newState);
      if (newState === 'minimized') {
          // Keep it open logically, but visual state is handled
      }
  };

  const handleReset = () => {
      toast.success("Environment reset to clean state");
      setIsResetOpen(false);
  };

  // Calculate Sprint Progress
  const calculateSprintProgress = () => {
      if (!activeSprint) return 0;
      const start = new Date(activeSprint.start_date).getTime();
      const end = new Date(activeSprint.end_date).getTime();
      const now = Date.now();
      const total = end - start;
      const elapsed = now - start;
      return Math.min(100, Math.max(0, (elapsed / total) * 100));
  };

  if (loading) return null;

  if (!user) {
      return (
          <ToolPreview 
              title="Creator Studio"
              subtitle="The WorkRoom"
              description="A specialized environment for rapid prototyping and deployment. This tool combines a code editor, terminal, and live preview into a single interface."
              features={[
                  "AI-Assisted Code Generation",
                  "Hot Module Replacement",
                  "One-Click Deployment to Edge",
                  "Integrated Terminal"
              ]}
              demoComponent={
                  <div className="w-full h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden flex flex-col">
                      <div className="h-8 bg-neutral-800 border-b border-white/5 flex items-center px-4 gap-2">
                          <div className="w-2 h-2 rounded-full bg-red-500" />
                          <div className="w-2 h-2 rounded-full bg-yellow-500" />
                          <div className="w-2 h-2 rounded-full bg-green-500" />
                      </div>
                      <div className="flex-1 flex">
                          <div className="w-48 border-r border-white/5 bg-black/20 p-2 space-y-2">
                              <div className="h-2 w-20 bg-white/10 rounded" />
                              <div className="h-2 w-16 bg-white/10 rounded" />
                              <div className="h-2 w-24 bg-white/10 rounded" />
                          </div>
                          <div className="flex-1 bg-[#1e1e1e] p-4 font-mono text-xs text-blue-300">
                              import React from 'react';
                              <br />
                              <br />
                              export default function App() {'{'}
                              <br />
                              &nbsp;&nbsp;return &lt;h1&gt;Hello World&lt;/h1&gt;;
                              <br />
                              {'}'}
                          </div>
                      </div>
                  </div>
              }
          />
      );
  }

  return (
    <div className="h-full w-full bg-transparent overflow-hidden relative flex flex-col">
        {/* Top Navigation / Toolbar */}
        <div className="h-12 border-b border-white/5 bg-neutral-900 flex items-center justify-between px-4 shrink-0 relative z-30 shadow-sm">
             <div className="flex items-center gap-4">
                 <OrientingText className="font-bold tracking-widest text-neutral-500">
                    <Explainable technical="WORKROOM" human="Creator Studio" />
                 </OrientingText>
                 <div className="h-4 w-px bg-white/10" />
                 <div className="flex gap-2">
                     <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setIsResetOpen(true)}
                        className="h-7 text-xs text-neutral-400 hover:text-white bg-white/5 border border-white/5"
                     >
                         <RotateCcw className="w-3 h-3 mr-2 text-[hsl(var(--color-warning))]" /> 
                         <Explainable technical="Reset" human="Reset Env" />
                     </Button>
                 </div>
             </div>

             <div className="flex items-center gap-2">
                 <Button 
                     size="sm" 
                     onClick={() => setIsDeployOpen(true)}
                     className="h-7 text-xs bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 border-0 gap-2 px-4 font-bold shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                 >
                     <Rocket className="w-3 h-3" /> 
                     <Explainable technical="DEPLOY" human="Go Live" genZ="Ship It" />
                 </Button>
             </div>
        </div>

        {/* Invariant #3: Hero must be present. We place it in the preview context or above. 
            For WorkRoom, placing it above the split makes sense for status. */}
        <div className="shrink-0 px-4 pt-4">
            <SystemStatusHero 
                status="nominal"
                message="Dev Environment Active"
                subMessage="Hot module replacement enabled. Latency < 20ms."
                metrics={[
                    { label: 'Build', value: 'Passing', trend: 'up' },
                    { label: 'Errors', value: '0', trend: 'stable' }
                ]}
            />
        </div>

        <div className="flex-1 flex overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Context" className="border-b">
                            <div className="space-y-4">
                {/* QUEST BOARD (Gamified Sprint) */}
                <div className="space-y-2">
                    <div className="flex items-center justify-between px-1">
                        <div className="flex items-center gap-2 text-[hsl(var(--color-intent))]">
                            <Swords className="w-4 h-4" />
                            <span className="text-xs font-bold uppercase tracking-widest">Quest Board</span>
                        </div>
                        <Badge variant="outline" className="text-[9px] border-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))]">
                            SEASON 1
                        </Badge>
                    </div>

                    {activeSprint && (
                        <div className="p-1 bg-gradient-to-br from-neutral-900 to-black rounded-xl border border-white/10 relative overflow-hidden group shadow-2xl">
                            {/* Main Quest Card */}
                            <div className="bg-[url('https://images.unsplash.com/photo-1614726365723-49cfa0950ec4?q=80&w=2574&auto=format&fit=crop')] bg-cover bg-center rounded-lg p-4 relative min-h-[200px] flex flex-col justify-between">
                                <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />

                                <div className="relative z-10 flex justify-between items-start">
                                    <div className="bg-black/50 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 flex items-center gap-2">
                                        <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))] animate-pulse" />
                                        <span className="text-[10px] font-bold text-white tracking-widest uppercase">Active Main Quest</span>
                                    </div>
                                    <div className="bg-yellow-500/20 px-2 py-1 rounded border border-yellow-500/30 text-yellow-400 text-[10px] font-bold">
                                        {activeSprint.xp_reward || 5000} XP
                                    </div>
                                </div>

                                <div className="relative z-10 mt-4">
                                    <h3 className="text-2xl font-black text-white tracking-tight mb-1 drop-shadow-lg">
                                        {activeSprint.name}
                                    </h3>
                                    <p className="text-sm text-neutral-300 italic mb-4 max-w-[90%]">
                                        "{activeSprint.goal}"
                                    </p>

                                    <div className="bg-black/60 backdrop-blur-md rounded-lg p-3 border border-white/10">
                                        <div className="flex justify-between text-[10px] text-neutral-400 font-mono uppercase tracking-wider mb-2">
                                            <span>Completion Status</span>
                                            <span className="text-[hsl(var(--color-execution))]">{Math.round(calculateSprintProgress())}%</span>
                                        </div>
                                        <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
                                            <div 
                                                className="h-full bg-gradient-to-r from-[hsl(var(--color-execution))] to-emerald-400 shadow-[0_0_10px_hsl(var(--color-execution))]" 
                                                style={{ width: `${calculateSprintProgress()}%` }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Side Quests / Future Sprints */}
                    <div className="grid grid-cols-2 gap-2 mt-2">
                        <div className="p-3 bg-neutral-900/50 border border-dashed border-white/10 rounded-lg hover:bg-neutral-900 transition-colors cursor-pointer group">
                            <div className="text-[10px] text-neutral-500 uppercase tracking-wider mb-1 group-hover:text-white">Side Quest</div>
                            <div className="text-xs font-bold text-neutral-400 group-hover:text-[hsl(var(--color-intent))]">Marketplace Integration</div>
                            <div className="mt-2 text-[9px] text-yellow-600">+2500 XP</div>
                        </div>
                        <div className="p-3 bg-neutral-900/50 border border-dashed border-white/10 rounded-lg hover:bg-neutral-900 transition-colors cursor-pointer group">
                            <div className="text-[10px] text-neutral-500 uppercase tracking-wider mb-1 group-hover:text-white">Daily Comm</div>
                            <div className="text-xs font-bold text-neutral-400 group-hover:text-[hsl(var(--color-intent))]">Fix 3 Bugs</div>
                            <div className="mt-2 text-[9px] text-yellow-600">+500 XP</div>
                        </div>
                    </div>
                </div>

                                <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                                    <OrientingText className="mb-2">
                                        <Explainable technical="ACTIVE PROJECT" human="Current Campaign" />
                                    </OrientingText>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Briefcase className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <IntentText>{activeProject ? activeProject.name : "Portfolio Site v2"}</IntentText>
                                    </div>
                                    <div className="flex items-center gap-2 mt-2 p-2 bg-black/20 rounded border border-white/5">
                                        <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-intent))]" />
                                        <StateText className="text-xs font-mono text-[hsl(var(--color-intent))] truncate">{activeFile}</StateText>
                                    </div>
                                    
                                    <Button 
                                        variant="outline" 
                                        size="sm" 
                                        onClick={() => setIsResetOpen(true)}
                                        className="w-full mt-4 h-8 text-xs"
                                    >
                                        <RotateCcw className="w-3 h-3 mr-2" /> Reset Environment
                                    </Button>
                                </div>

                                {/* ADDON: Neuro-Link Analytics */}
                                {isAddonActive('Neuro-Link Analytics') && (
                                    <div className="p-4 bg-[hsl(var(--color-execution))]/5 rounded border border-[hsl(var(--color-execution))]/20 relative overflow-hidden group">
                                         <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,150,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,150,0.03)_1px,transparent_1px)] bg-[size:10px_10px] opacity-0 group-hover:opacity-100 transition-opacity" />
                                         <div className="flex justify-between items-center mb-2 relative z-10">
                                             <div className="flex items-center gap-2">
                                                 <Brain className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                                                 <OrientingText className="text-[hsl(var(--color-execution))]">NEURO-LINK</OrientingText>
                                             </div>
                                             <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))] animate-pulse" />
                                         </div>
                                         <div className="space-y-1 relative z-10">
                                             <div className="flex justify-between text-[10px] text-neutral-400">
                                                 <span>Cognitive Load</span>
                                                 <span className="text-white font-mono">14%</span>
                                             </div>
                                             <div className="h-1 bg-neutral-800 rounded-full overflow-hidden">
                                                 <div className="h-full bg-[hsl(var(--color-execution))]" style={{ width: '14%' }} />
                                             </div>
                                         </div>
                                    </div>
                                )}
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Files" className="flex flex-col border-t-0 rounded-t-none h-64" scrollable={false}>
                            <div className="flex-1 flex flex-col min-h-0">
                                <div className="p-2 border-b border-white/5 text-[10px] text-neutral-500 font-mono">
                                    PROJECT EXPLORER
                                </div>
                                <div className="space-y-1 flex-1 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/5 p-2">
                                    {['src/App.js', 'src/components/Header.js', 'src/styles/main.css', 'package.json'].map((file, i) => (
                                        <div 
                                            key={i} 
                                            onClick={() => setActiveFile(file)}
                                            className={cn(
                                                "flex items-center gap-2 p-2 rounded cursor-pointer text-xs font-mono transition-colors",
                                                activeFile === file ? "bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))]" : "text-neutral-400 hover:bg-white/5"
                                            )}
                                        >
                                            <div className={cn("w-1.5 h-1.5 rounded-full", activeFile === file ? "bg-[hsl(var(--color-execution))]" : "bg-neutral-700")} />
                                            {file}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </Quadrant>
                        <Quadrant type="intent" step="2" title="Editor" dominance="dominant" className="p-0 border-t border-white/10 flex-1">
                            <CodeEditor 
                                projectId={projectId} 
                                initialCode={`// ${activeFile}\n\nexport default function Component() {\n  return <div>Hello World</div>\n}`} 
                                language={activeFile.endsWith('.css') ? 'css' : 'javascript'}
                            />
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <div className="w-full h-full flex flex-col min-w-0 bg-black/20 rounded-lg overflow-hidden relative">
                         {/* If Browser is docked, it lives here */}
                         {isBrowserOpen && browserState === 'docked' ? (
                            <BrowserWindow 
                                isOpen={true}
                                viewState="docked"
                                onViewStateChange={handleBrowserStateChange}
                                onClose={() => setIsBrowserOpen(false)}
                                title="Localhost:3000"
                            >
                                <PreviewContent />
                            </BrowserWindow>
                         ) : (
                            /* Fallback content when browser is popped out or closed */
                            <div className="w-full h-full flex flex-col">
                                <Quadrant type="intent" step="2" title="Instruction" dominance="dominant" className="p-0 border-none bg-transparent flex flex-col h-full">
                                     <div className="flex-1 overflow-hidden relative">
                                        {/* Show Assistant here only if browser is closed/floating? 
                                            Actually, if Browser is floating, it HAS the assistant inside it.
                                            So here we might show a placeholder or "Preview Active in Window" message.
                                        */}
                                        <div className="absolute inset-0 flex flex-col items-center justify-center text-neutral-500 gap-4">
                                            {isBrowserOpen ? (
                                                <>
                                                    <div className="w-16 h-16 rounded-2xl bg-[hsl(var(--color-execution))]/10 flex items-center justify-center border border-[hsl(var(--color-execution))]/20 animate-pulse">
                                                        <Rocket className="w-8 h-8 text-[hsl(var(--color-execution))]" />
                                                    </div>
                                                    <div className="text-center">
                                                        <p className="font-medium text-white">Preview Active</p>
                                                        <p className="text-xs opacity-50">Window is undocked</p>
                                                    </div>
                                                    <Button variant="outline" size="sm" onClick={() => setBrowserState('docked')}>
                                                        Dock Window
                                                    </Button>
                                                </>
                                            ) : (
                                                <>
                                                    <div className="w-16 h-16 rounded-2xl bg-neutral-800 flex items-center justify-center border border-white/5">
                                                        <RotateCcw className="w-8 h-8 opacity-50" />
                                                    </div>
                                                    <div className="text-center">
                                                        <p className="font-medium text-neutral-400">Preview Paused</p>
                                                        <p className="text-xs opacity-50">Launch environment to continue</p>
                                                    </div>
                                                    <Button 
                                                        onClick={() => {
                                                            setIsBrowserOpen(true);
                                                            setBrowserState('docked');
                                                        }}
                                                        className="gap-2 bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                                                    >
                                                        <Rocket className="w-4 h-4" /> Launch Preview
                                                    </Button>
                                                </>
                                            )}
                                        </div>
                                     </div>
                                </Quadrant>
                            </div>
                         )}
                    </div>
                }
            />
        </div>

        {/* Floating / Maximized Browser Instance */}
        {isBrowserOpen && browserState !== 'docked' && browserState !== 'minimized' && (
            <BrowserWindow 
                isOpen={true}
                viewState={browserState}
                onViewStateChange={handleBrowserStateChange}
                onClose={() => setIsBrowserOpen(false)}
                title="Localhost:3000"
            >
                <PreviewContent />
            </BrowserWindow>
        )}

        {/* Minimized Dock Item (Bottom Right) */}
        {isBrowserOpen && browserState === 'minimized' && (
            <div className="fixed bottom-6 right-6 z-[60] flex flex-col items-end gap-2 animate-in slide-in-from-bottom-4">
                <div className="bg-[#0a0a0a]/90 backdrop-blur-xl border border-white/10 p-1.5 rounded-2xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.5)] flex items-center gap-3 pr-4 pl-2 ring-1 ring-white/5">
                     <div className="relative">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[hsl(var(--color-execution))] to-emerald-600 flex items-center justify-center shadow-lg text-black">
                            <Rocket className="w-5 h-5" />
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-black flex items-center justify-center border border-white/10">
                            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        </div>
                     </div>
                     
                     <div className="flex flex-col">
                        <span className="text-xs font-bold text-white tracking-wide">Preview Active</span>
                        <span className="text-[10px] text-neutral-500 font-mono">localhost:3000</span>
                     </div>

                     <div className="h-8 w-px bg-white/10 mx-1" />

                     <div className="flex items-center gap-1">
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0 rounded-lg hover:bg-white/10 hover:text-white text-neutral-400" onClick={() => setBrowserState('windowed')} title="Restore">
                            <Maximize2 className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 w-8 p-0 rounded-lg hover:bg-red-500/20 hover:text-red-400 text-neutral-400" onClick={() => setIsBrowserOpen(false)} title="Close">
                            <X className="w-4 h-4" />
                        </Button>
                     </div>
                </div>
            </div>
        )}

        <DeploymentModal 
            open={isDeployOpen} 
            onOpenChange={setIsDeployOpen} 
            mode="smart_ship"
            projectId={projectId}
        />

        <SystemConfirmation 
            open={isResetOpen}
            onOpenChange={setIsResetOpen}
            title="Reset Workspace?"
            description="This will clear your current session and revert to the default template. Unsaved changes will be lost."
            onConfirm={handleReset}
            variant="destructive"
            confirmText="Reset Everything"
        />

        <TutorialOverlay 
            tutorialId="workroom_intro"
            steps={[
                { title: "Creator Studio", content: "This is your rapid prototyping environment. Just describe what you want.", position: "top-left" },
                { title: "Omni Assistant", content: "Chat with the AI here. It can generate code, install packages, and fix bugs.", position: "center" },
                { title: "Live Preview", content: "See your changes instantly as the AI writes code.", position: "bottom-right" },
                { title: "Deployment", content: "One-click deploy to your production node when you're happy with the result.", position: "top-right" }
            ]}
        />
    </div>
  );
}

const PreviewContent = () => (
    <iframe 
        srcDoc={`
            <html>
                <head>
                    <script src="https://cdn.tailwindcss.com"></script>
                </head>
                <body class="bg-transparent min-h-screen flex items-center justify-center">
                    <div class="text-center space-y-4 animate-bounce">
                        <div class="w-20 h-20 bg-blue-500 rounded-2xl mx-auto shadow-xl flex items-center justify-center text-white text-4xl font-bold">
                            🚀
                        </div>
                        <h1 class="text-2xl font-bold text-slate-800">App Running</h1>
                        <p class="text-slate-500">Preview active on port 3000</p>
                    </div>
                </body>
            </html>
        `}
        className="w-full h-full border-none bg-white" 
        title="Preview"
    />
);