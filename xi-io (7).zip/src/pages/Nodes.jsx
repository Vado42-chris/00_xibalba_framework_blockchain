import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Activity, Globe, Server, Terminal, Cpu, Shield, Wifi, Search, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { QuadrantGrid, Quadrant, IntentText, StateText, SemanticDot, Layer, AtomicParagraph, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { SystemStats, SystemLog } from '@/components/ui/design-system/SystemContent';
import { Badge } from "@/components/ui/badge";
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Button } from "@/components/ui/button";
import SystemMap from '@/components/network/SystemMap';
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import ProvisionNodeModal from '@/components/nodes/ProvisionNodeModal';
import TerminalWidget from '@/components/nodes/TerminalWidget';
import { useNodeStats } from '@/components/nodes/useNodeStats';
import { SystemStatusHero } from '@/components/dashboards/widgets/SystemStatusHero';
import { Explainable } from '@/components/ui/design-system/RosettaStone';
import ToolPreview from '@/components/previews/ToolPreview';

export default function Nodes() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    React.useEffect(() => {
        base44.auth.me().then(setUser).catch(() => setUser(null)).finally(() => setLoading(false));
    }, []);

    const [selectedNode, setSelectedNode] = useState(null);
    const [showTerminal, setShowTerminal] = useState(false);
    const stats = useNodeStats(!!selectedNode && selectedNode.status === 'connected');
    const [isProvisionOpen, setIsProvisionOpen] = useState(false);
    const [filter, setFilter] = useState('');

    const { data: nodes = [] } = useQuery({
        queryKey: ['nodes'],
        queryFn: () => base44.entities.Node.list(),
        initialData: [],
        enabled: !!user
    });

    if (loading) return null;

    if (!user) {
        return (
            <ToolPreview 
                title="Infrastructure Control"
                subtitle="Node Fleet Management"
                description="Visualize and control your distributed computing infrastructure. Manage satellites, core nodes, and relays from a unified dashboard."
                features={[
                    "Real-time Telemetry & Logs",
                    "SSH Terminal Access",
                    "Automated Provisioning",
                    "Global Topology Map"
                ]}
                demoComponent={
                    <div className="w-full h-full relative bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
                        <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 gap-px opacity-20">
                            {[...Array(36)].map((_, i) => <div key={i} className="bg-white/5" />)}
                        </div>
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-[hsl(var(--color-system))]/20 rounded-full blur-xl animate-pulse" />
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                            <Activity className="w-16 h-16 text-[hsl(var(--color-system))]" />
                        </div>
                    </div>
                }
            />
        );
    }

    const filtered = nodes.filter(n => (n.name || '').toLowerCase().includes(filter.toLowerCase()));
    
    // Stats
    const onlineCount = nodes.filter(n => n.status === 'connected').length;
    
    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Fleet" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Activity className="w-4 h-4 text-[hsl(var(--color-system))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-system))]">
                                            <Explainable technical="COMPUTE NODES" human="Servers" />
                                        </OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">
                                        <Explainable technical="Infrastructure Grid" human="Network Map" />
                                    </IntentText>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Link to={createPageUrl('Marketplace') + '?category=infrastructure'}>
                                        <Button variant="ghost" size="sm" className="h-6 text-[10px] text-neutral-500 hover:text-white px-2">
                                            <Plus className="w-3 h-3 mr-1" /> Addon
                                        </Button>
                                    </Link>
                                        <Badge variant="outline" className="border-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10">
                                            {onlineCount} <Explainable technical="ONLINE" human="Connected" />
                                        </Badge>
                                </div>
                            </div>

                            <Button 
                                className="w-full mb-4 bg-[hsl(var(--color-system))] text-black hover:bg-[hsl(var(--color-system))]/90 font-bold tracking-wide"
                                onClick={() => setIsProvisionOpen(true)}
                            >
                                <Plus className="w-4 h-4 mr-2" /> <Explainable technical="ADD NODE" human="Connect Server" />
                            </Button>

                            <GuideBox title="Infrastructure Guide">
                                <p className="mb-2">
                                    <Explainable 
                                        technical="Monitor your Compute Nodes and network status in real-time." 
                                        human="Keep track of your connected servers and check their health." 
                                    />
                                </p>
                                <ul className="list-disc list-inside space-y-1 opacity-80">
                                    <li><Explainable technical="Satellites are edge nodes for fast, local processing." human="Satellites handle quick tasks nearby." /></li>
                                    <li><Explainable technical="Core nodes handle heavy AI model training." human="Core nodes do the heavy lifting." /></li>
                                </ul>
                            </GuideBox>
                            
                                <div className="relative">
                                <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search nodes..." 
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                    className="pl-8 bg-neutral-900/50 border-white/10 h-8 text-xs"
                                />
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Inventory" className="flex flex-col border-t-0 rounded-t-none" scrollable={false}>
                            <OrientingText className="mb-4">
                                <Explainable technical="FLEET INVENTORY" human="Server List" />
                            </OrientingText>
                            <div className="space-y-2 overflow-y-auto max-h-[500px] pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {filtered.map((node) => (
                                    <SystemCard
                                        key={node.id}
                                        title={node.name}
                                        subtitle={node.ip_address}
                                        status={node.status === 'connected' ? 'execution' : 'settled'}
                                        active={selectedNode?.id === node.id}
                                        onClick={() => setSelectedNode(node)}
                                        icon={Server}
                                        metric={node.type.toUpperCase()}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Telemetry" dominance="dominant" className="p-0 flex flex-col h-auto min-h-[500px] overflow-hidden border-b">
                            <ProvisionNodeModal open={isProvisionOpen} onOpenChange={setIsProvisionOpen} />
                            {selectedNode ? (
                            <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300">
                                {/* Invariant #3: Hero must be present */}
                                <div className="p-6 pb-0">
                                    <SystemStatusHero 
                                        status={selectedNode.status === 'connected' ? 'nominal' : 'warning'}
                                        message={selectedNode.name}
                                        subMessage={`IP: ${selectedNode.ip_address} • Last Seen: ${new Date(selectedNode.last_seen).toLocaleString()}`}
                                        metrics={[
                                            { label: 'Uptime', value: '99.9%', trend: 'stable' },
                                            { label: 'Load', value: `${stats.cpu}%`, trend: 'up' }
                                        ]}
                                    />
                                </div>
                                
                                <div className="p-8 space-y-6 overflow-y-auto bg-transparent flex-1">
                                    <ActionDock 
                                        primaryAction={{
                                            label: showTerminal ? "Close Terminal" : "SSH Access",
                                            icon: Terminal,
                                            onClick: () => setShowTerminal(!showTerminal)
                                        }}
                                        secondaryActions={[
                                            { label: "Reboot", icon: Activity, onClick: () => toast.success("Reboot signal sent to node") },
                                            { label: "Logs", icon: Search, onClick: () => toast.info("Fetching system logs...") }
                                        ]}
                                    />

                                    {showTerminal && (
                                        <div className="mt-4">
                                            <TerminalWidget node={selectedNode} onClose={() => setShowTerminal(false)} />
                                        </div>
                                    )}

                                    <SystemStats 
                                        className="grid-cols-2"
                                        stats={[
                                            { label: "CPU Load", value: `${stats.cpu}%`, icon: Cpu, progress: stats.cpu, color: stats.cpu > 80 ? "text-red-500 bg-red-500" : "text-[hsl(var(--color-system))] bg-[hsl(var(--color-system))]" },
                                            { label: "Memory", value: `${stats.memory}%`, icon: Server, progress: stats.memory, color: "text-blue-500 bg-blue-500" },
                                            { label: "Network TX", value: `${stats.network_out}KB/s`, icon: Wifi, color: "text-white" },
                                            { label: "Network RX", value: `${stats.network_in}KB/s`, icon: Activity, color: "text-white" }
                                        ]}
                                    />

                                    <Layer level="orientation">
                                        <OrientingText className="mb-2">SYSTEM LOGS</OrientingText>
                                        <SystemLog 
                                            className="h-32"
                                            logs={[
                                                { type: 'SYSTEM', content: `Connection established at ${new Date(selectedNode.last_seen).toLocaleTimeString()}`, status: 'nominal', timestamp: new Date().toISOString() },
                                                { type: 'KERNEL', content: 'Boot sequence completed in 1.4s', status: 'nominal', timestamp: new Date().toISOString() },
                                                { type: 'NETWORK', content: `Interface eth0 up, IP ${selectedNode.ip_address}`, status: 'nominal', timestamp: new Date().toISOString() },
                                                { type: 'WARN', content: 'High memory usage detected on process 4211', status: 'warning', timestamp: new Date().toISOString() },
                                                { type: 'SYSTEM', content: 'Heartbeat signal sent...', status: 'nominal', timestamp: new Date().toISOString() }
                                            ]}
                                        />
                                    </Layer>
                                </div>
                            </div>
                            ) : (
                            <div className="h-full flex flex-col p-6">
                                <SystemStatusHero 
                                    status="nominal"
                                    message="Fleet Command"
                                    subMessage="Select a node to view telemetry, logs, and perform administrative actions."
                                    metrics={[
                                        { label: 'Total Nodes', value: nodes.length.toString(), trend: 'stable' },
                                        { label: 'Online', value: onlineCount.toString(), trend: 'up' }
                                    ]}
                                />
                                <div className="flex-1 flex items-center justify-center opacity-30">
                                    <div className="text-center">
                                        <Activity className="w-12 h-12 mx-auto mb-4" />
                                        <div className="text-sm font-mono">WAITING FOR SELECTION...</div>
                                    </div>
                                </div>
                            </div>
                            )}
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Map Context" dominance="supporting" className="p-0 relative overflow-hidden border-t-0 rounded-t-none min-h-[300px]">
                             {/* Mini Map Context */}
                            <div className="absolute inset-0 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all">
                                    <SystemMap nodes={selectedNode ? [selectedNode] : nodes} />
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}