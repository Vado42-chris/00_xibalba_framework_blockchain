import React, { useState, useEffect } from 'react';
import { api } from '@/components/control-panel/api';
import { setToken, isAuthenticated, clearToken } from '@/components/control-panel/auth';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant, IntentText, StateText, OrientingText } from '@/components/ui/design-system/System';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { SystemLog } from '@/components/ui/design-system/SystemContent';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Server, Key, Layout, Play, RefreshCw, LogOut, Plus, FileCode, Folder, Terminal } from 'lucide-react';
import { cn } from "@/lib/utils";
import { GuideBox, TermHelper } from "@/components/ui/GuideBox";

/* -------------------------------------------------------------------------- */
/*                                SUB-COMPONENTS                              */
/* -------------------------------------------------------------------------- */

const DispatchModal = ({ task, open, onOpenChange, onDispatch }) => {
    const [agentType, setAgentType] = useState('coder');
    const [target, setTarget] = useState('zed');
    const [loading, setLoading] = useState(false);

    const handleDispatch = async () => {
        setLoading(true);
        await onDispatch(task.id, agentType, target);
        setLoading(false);
        onOpenChange(false);
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border border-white/10 text-white sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Dispatch Agent</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                        <Label>Agent Specialist</Label>
                        <Select value={agentType} onValueChange={setAgentType}>
                            <SelectTrigger className="bg-neutral-950 border-white/10">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-neutral-900 border-white/10">
                                <SelectItem value="coder">Coder (Implementation)</SelectItem>
                                <SelectItem value="reviewer">Reviewer (QA & Audit)</SelectItem>
                                <SelectItem value="planner">Planner (Architecture)</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="grid gap-2">
                        <Label>Execution Environment</Label>
                        <Select value={target} onValueChange={setTarget}>
                            <SelectTrigger className="bg-neutral-950 border-white/10">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-neutral-900 border-white/10">
                                <SelectItem value="zed">Zed Editor (Local/MCP)</SelectItem>
                                <SelectItem value="web">Web Runtime (Cloud)</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>
                <DialogFooter>
                    <Button onClick={handleDispatch} disabled={loading} className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90">
                        {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                        Initialize Sequence
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

const CreateTaskModal = ({ sprintId, open, onOpenChange, onCreate }) => {
    const [title, setTitle] = useState('');
    const [desc, setDesc] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        await onCreate(sprintId, title, desc);
        setLoading(false);
        onOpenChange(false);
        setTitle('');
        setDesc('');
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border border-white/10 text-white">
                <DialogHeader>
                    <DialogTitle>New Task Protocol</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 mt-4">
                    <div className="space-y-2">
                        <Label>Directive</Label>
                        <Input 
                            value={title} 
                            onChange={e => setTitle(e.target.value)} 
                            placeholder="e.g., Implement authentication middleware"
                            className="bg-neutral-950 border-white/10"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label>Context (Optional)</Label>
                        <Input 
                            value={desc} 
                            onChange={e => setDesc(e.target.value)} 
                            placeholder="Additional requirements..."
                            className="bg-neutral-950 border-white/10"
                        />
                    </div>
                    <DialogFooter>
                        <Button type="submit" disabled={loading || !title} className="bg-[hsl(var(--color-intent))] text-white">
                            Create Task
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

const SystemStatsOverview = () => {
    // Dynamic stats fetching
    const [stats, setStats] = useState({ components: 0, templates: 0, docs: 0 });
    
    useEffect(() => {
        const fetchStats = async () => {
            // In a real scenario, we'd query specific entities or a meta-endpoint
            // For now, we simulate dynamic fetching from the entity graph
            try {
                // Mocking queries - we can't count files directly from frontend securely without an index
                const docsCount = (await base44.entities.ContentPage.list()).length + 9; // +9 hardcoded guides
                const templatesCount = 12; // Placeholder until Template entity exists
                const componentsCount = 142; // Placeholder
                
                setStats({ components: componentsCount, templates: templatesCount, docs: docsCount });
            } catch (e) {
                console.error("Stats fetch error", e);
            }
        };
        fetchStats();
    }, []);

    return (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded">
                <StateText className="text-[10px] uppercase opacity-50 mb-1">Components</StateText>
                <IntentText className="text-xl">{stats.components}</IntentText>
            </div>
            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded">
                <StateText className="text-[10px] uppercase opacity-50 mb-1">Templates</StateText>
                <IntentText className="text-xl">{stats.templates}</IntentText>
            </div>
            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded">
                <StateText className="text-[10px] uppercase opacity-50 mb-1">Docs</StateText>
                <IntentText className="text-xl">{stats.docs}</IntentText>
            </div>
            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded">
                <StateText className="text-[10px] uppercase opacity-50 mb-1">Coverage</StateText>
                <IntentText className="text-xl text-[hsl(var(--color-execution))]">89%</IntentText>
            </div>
        </div>
    );
};

const LoginView = ({ onLogin }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const res = await api.login(username, password);
            setToken(res.token);
            toast.success(`Welcome back, ${res.user?.username || username}`);
            onLogin(true); // Normal login
        } catch (err) {
            toast.error(err.message || "Login failed");
        } finally {
            setLoading(false);
        }
    };

    const handleDemoLogin = () => {
        setLoading(true);
        setTimeout(() => {
            setToken('DEMO_TOKEN');
            toast.success("Welcome to Educational Mode");
            onLogin('demo'); // Demo login
            setLoading(false);
        }, 800);
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-[50vh] max-w-sm mx-auto p-6">
            <div className="mb-8 text-center">
                <div className="w-16 h-16 bg-neutral-900 rounded-2xl border border-white/10 flex items-center justify-center mx-auto mb-4">
                    <Server className="w-8 h-8 text-[hsl(var(--color-execution))]" />
                </div>
                <IntentText className="text-2xl font-light">MVP CONTROL</IntentText>
                <StateText className="opacity-50">Authenticate with External Node</StateText>
            </div>
            <div className="mb-6 w-full">
                <GuideBox title="About Control Panel">
                    <p className="mb-2">
                        This is the <TermHelper term="Command Gateway">Secure entry point</TermHelper> for system administrators.
                    </p>
                    <p>
                        Use this interface to manage <TermHelper term="Nodes">External servers running application logic</TermHelper>, dispatch AI agents, and control system security.
                    </p>
                </GuideBox>
            </div>
            <form onSubmit={handleSubmit} className="w-full space-y-4">
                <Input 
                    placeholder="Username" 
                    value={username} 
                    onChange={e => setUsername(e.target.value)}
                    className="bg-neutral-900 border-white/10"
                />
                <Input 
                    type="password" 
                    placeholder="Password" 
                    value={password} 
                    onChange={e => setPassword(e.target.value)}
                    className="bg-neutral-900 border-white/10"
                />
                <Button type="submit" className="w-full bg-white text-black hover:bg-neutral-200 font-bold transition-all" disabled={loading}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Connect to Node"}
                </Button>
                <p className="text-[10px] text-neutral-500 text-center mt-2">
                    Authenticating will decrypt your session and load the administrative command interface.
                </p>
                
                <div className="relative py-2">
                    <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t border-white/10" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-neutral-950 px-2 text-neutral-500">Educational Access</span>
                    </div>
                </div>

                <Button 
                    type="button" 
                    variant="outline"
                    onClick={handleDemoLogin}
                    className="w-full border-blue-500/30 text-blue-400 hover:bg-blue-500/10 hover:text-blue-300" 
                    disabled={loading}
                >
                    <Terminal className="w-4 h-4 mr-2" />
                    Initialize Demo Node
                </Button>
                <div className="mt-4 text-center">
                    <p className="text-[10px] text-neutral-600">
                        Default: admin / admin
                    </p>
                </div>
            </form>
            <div className="mt-4 text-center">
                <StateText className="text-xs opacity-30">Target: https://xi-io.com</StateText>
            </div>
        </div>
    );
};

const ProjectDetail = ({ project, onBack }) => {
    const [structure, setStructure] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const load = async () => {
            try {
                const data = await api.getProjectStructure(project.id);
                setStructure(data.structure);
            } catch (e) {
                // toast.error("Could not load structure");
            } finally {
                setLoading(false);
            }
        };
        load();
    }, [project]);

    return (
        <div className="h-full flex flex-col">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon" onClick={onBack} className="h-8 w-8">
                        <Layout className="w-4 h-4 rotate-90" />
                    </Button>
                    <div>
                        <IntentText className="font-bold">{project.name}</IntentText>
                        <StateText className="text-[10px] font-mono opacity-50">{project.uuid}</StateText>
                    </div>
                </div>
                <Badge variant="outline" className="border-white/10 text-neutral-500">READ ONLY</Badge>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4">
                {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin text-neutral-500 mx-auto mt-10" />
                ) : (
                    <div className="space-y-2">
                        <SystemStatsOverview />

                        <OrientingText className="mb-2">FILE SYSTEM INDEX</OrientingText>
                        <div className="font-mono text-xs text-neutral-400 space-y-1 bg-black/20 p-4 rounded border border-white/5">
                            <div className="flex items-center gap-2 text-[hsl(var(--color-warning))]"><Folder className="w-3 h-3" /> /root</div>
                            <div className="pl-4 flex items-center gap-2"><Folder className="w-3 h-3 text-[hsl(var(--color-intent))]" /> src</div>
                            <div className="pl-8 flex items-center gap-2"><FileCode className="w-3 h-3" /> main.py</div>
                            <div className="pl-8 flex items-center gap-2"><FileCode className="w-3 h-3" /> utils.py</div>
                            <div className="pl-4 flex items-center gap-2"><FileCode className="w-3 h-3" /> requirements.txt</div>
                            <div className="pl-4 flex items-center gap-2"><FileCode className="w-3 h-3" /> README.md</div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

const ProjectList = ({ isDemo }) => {
    const [projects, setProjects] = useState([]);
    const [selected, setSelected] = useState(null);
    const [loading, setLoading] = useState(true);

    const load = async () => {
        if (isDemo) {
            setProjects([
                { id: 'proj-1', name: 'base44-core', uuid: 'b44-core-v2-stable', description: 'Core framework repository.' },
                { id: 'proj-2', name: 'neural-engine', uuid: 'ne-v5-alpha', description: 'AI inference module.' },
                { id: 'proj-3', name: 'client-dashboard', uuid: 'cd-react-frontend', description: 'User facing interface.' }
            ]);
            setLoading(false);
            return;
        }

        try {
            const data = await api.getProjects();
            setProjects(data.projects || []);
        } catch (e) {
            toast.error("Failed to load projects");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { load(); }, []);

    if (selected) {
        return <ProjectDetail project={selected} onBack={() => setSelected(null)} />;
    }

    if (loading) return <div className="p-4"><Loader2 className="w-5 h-5 animate-spin text-neutral-500" /></div>;

    return (
        <div className="space-y-2 p-2">
            <div className="flex justify-between items-center px-2 py-2">
                <OrientingText>AVAILABLE REPOSITORIES</OrientingText>
                <Button size="sm" variant="ghost" onClick={load}><RefreshCw className="w-3 h-3" /></Button>
            </div>
            {projects.map(p => (
                <SystemCard
                    key={p.id}
                    title={p.name}
                    subtitle={p.uuid}
                    status="active"
                    metric={`ID: ${p.id}`}
                    icon={Server}
                    onClick={() => setSelected(p)}
                    active={selected?.id === p.id}
                />
            ))}
            {projects.length === 0 && <StateText className="p-4 text-center opacity-50">No projects found.</StateText>}
        </div>
    );
};

const TaskBoard = ({ isDemo }) => {
    const [tasks, setTasks] = useState([]);
    const [sprints, setSprints] = useState([]);
    const [selectedSprint, setSelectedSprint] = useState('all');
    const [loading, setLoading] = useState(true);
    
    // Modals
    const [dispatchTask, setDispatchTask] = useState(null);
    const [createTaskOpen, setCreateTaskOpen] = useState(false);

    const load = async () => {
        if (isDemo) {
            // Dummy Data for Educational Mode
            setTasks([
                { id: 'demo-1', title: 'Optimize Neural Net', description: 'Reduce inference latency on edge nodes.', status: 'in_progress', assigned_agent: 'Optimizer-Alpha', sprint_name: 'Core Upgrades' },
                { id: 'demo-2', title: 'Audit Security Logs', description: 'Review unauthorized access attempts.', status: 'completed', assigned_agent: 'Sentry-01', sprint_name: 'Security Sweep' },
                { id: 'demo-3', title: 'Deploy Microservices', description: 'Scale out the new auth service.', status: 'pending', assigned_agent: null, sprint_name: 'Infra Expansion' }
            ]);
            setSprints([
                { id: 'sprint-1', name: 'Core Upgrades', status: 'active' },
                { id: 'sprint-2', name: 'Security Sweep', status: 'active' },
                { id: 'sprint-3', name: 'Infra Expansion', status: 'planning' }
            ]);
            setLoading(false);
            return;
        }

        try {
            const [tData, sData] = await Promise.all([
                api.getAllTasks(),
                api.getSprints()
            ]);
            setTasks(tData.tasks || []);
            setSprints(sData.sprints || []);
        } catch (e) {
            // silent
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
        const interval = setInterval(load, 5000);
        return () => clearInterval(interval);
    }, []);

    const handleDispatch = async (taskId, agentType, target) => {
        if (isDemo) {
            toast.success(`Simulation: Agent (${agentType}) dispatched to ${target}`);
            setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: 'in_progress', assigned_agent: `${agentType.charAt(0).toUpperCase() + agentType.slice(1)}-Sim` } : t));
            return;
        }

        try {
            await api.dispatchAgent(taskId, agentType, target);
            toast.success(`Agent (${agentType}) dispatched to ${target}`);
            load();
        } catch (e) {
            toast.error("Dispatch sequence failed");
        }
    };

    const handleCreateTask = async (sprintId, title, desc) => {
        if (isDemo) {
            toast.success("Simulation: Task protocol created successfully!");
            // Add a fake task to the list for effect
            const newTask = { 
                id: `demo-${Date.now()}`, 
                title, 
                description: desc, 
                status: 'pending', 
                assigned_agent: null, 
                sprint_name: sprints.find(s => s.id === sprintId)?.name || 'Backlog' 
            };
            setTasks(prev => [newTask, ...prev]);
            return;
        }

        try {
            // If no sprint selected/all, pick the first active one or user must select
            // Ideally UI forces selection, for now auto-pick first if 'all'
            const targetSprint = sprintId === 'all' ? sprints[0]?.id : sprintId;
            if (!targetSprint) {
                toast.error("No sprints available");
                return;
            }
            await api.createTask(targetSprint, title, desc);
            toast.success("Task protocol created");
            load();
        } catch (e) {
            toast.error("Failed to create task");
        }
    };

    const filteredTasks = selectedSprint === 'all' 
        ? tasks 
        : tasks.filter(t => t.sprint_id === selectedSprint);

    if (loading && tasks.length === 0) return <div className="p-8"><Loader2 className="w-6 h-6 animate-spin mx-auto text-neutral-500" /></div>;

    return (
        <div className="flex flex-col h-full">
            {isDemo && (
                <div className="p-4 border-b border-white/5">
                    <GuideBox title="Task Protocol Interface">
                        <p className="mb-2">
                            This board visualizes <TermHelper term="Protocols">Assigned units of work</TermHelper> for your autonomous fleet.
                        </p>
                        <p>
                            Try creating a new task or dispatching an agent to see how the system orchestrates execution.
                        </p>
                    </GuideBox>
                </div>
            )}
            {/* Toolbar */}
            <div className="p-4 border-b border-white/5 flex gap-4 bg-neutral-900/30">
                <Select value={selectedSprint} onValueChange={setSelectedSprint}>
                    <SelectTrigger className="w-[200px] bg-neutral-950 border-white/10">
                        <SelectValue placeholder="Select Sprint" />
                    </SelectTrigger>
                    <SelectContent className="bg-neutral-900 border-white/10">
                        <SelectItem value="all">All Sprints</SelectItem>
                        {sprints.map(s => (
                            <SelectItem key={s.id} value={s.id}>{s.name} ({s.status})</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                <Button onClick={() => setCreateTaskOpen(true)} className="bg-neutral-800 hover:bg-neutral-700 text-white gap-2">
                    <Plus className="w-4 h-4" /> New Task
                </Button>
            </div>

            {/* Grid */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {filteredTasks.map(task => (
                    <SystemCard
                        key={task.id}
                        title={task.title}
                        subtitle={task.description || "No parameters defined."}
                        status={task.status === 'completed' ? 'settled' : task.status === 'in_progress' ? 'active' : 'pending'}
                        metric={(task.status || 'pending').toUpperCase()}
                        icon={Terminal}
                    >
                        <div className="mt-2 pt-2 border-t border-white/5 flex justify-between items-center">
                            <div className="flex items-center gap-2 text-xs font-mono text-neutral-600">
                                {task.sprint_name && <span>{task.sprint_name}</span>}
                                {task.assigned_agent && (
                                    <Badge variant="outline" className="border-[hsl(var(--color-intent))]/30 text-[hsl(var(--color-intent))] bg-[hsl(var(--color-intent))]/5">
                                        <Terminal className="w-3 h-3 mr-1" />
                                        {task.assigned_agent}
                                    </Badge>
                                )}
                            </div>
                            <Button 
                                size="sm" 
                                onClick={(e) => { e.stopPropagation(); setDispatchTask(task); }}
                                className="h-7 text-xs bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                            >
                                <Play className="w-3 h-3 mr-1" /> Dispatch
                            </Button>
                        </div>
                    </SystemCard>
                ))}
                {filteredTasks.length === 0 && <div className="text-center p-8 text-neutral-500">No active tasks in this sector.</div>}
            </div>

            {/* Dialogs */}
            {dispatchTask && (
                <DispatchModal 
                    task={dispatchTask} 
                    open={!!dispatchTask} 
                    onOpenChange={(open) => !open && setDispatchTask(null)}
                    onDispatch={handleDispatch}
                />
            )}
            
            <CreateTaskModal 
                sprintId={selectedSprint}
                open={createTaskOpen}
                onOpenChange={setCreateTaskOpen}
                onCreate={handleCreateTask}
            />
        </div>
    );
};

const ApiKeyManager = ({ isDemo }) => {
    const [keys, setKeys] = useState([]);
    const [newKey, setNewKey] = useState(null);

    const load = async () => {
        if (isDemo) {
            setKeys([
                { id: 'key-1', name: 'Production Access', key_preview: 'sk_live_9f8...', created_at: new Date().toISOString() },
                { id: 'key-2', name: 'Dev Environment', key_preview: 'sk_test_7d2...', created_at: new Date(Date.now() - 86400000).toISOString() }
            ]);
            return;
        }

        try {
            const data = await api.getApiKeys();
            setKeys(data.keys || []);
        } catch (e) {
            toast.error("Failed to load keys");
        }
    };

    useEffect(() => { load(); }, []);

    const generate = async () => {
        if (isDemo) {
            const mockKey = `sk_demo_${Math.random().toString(36).substring(7)}`;
            setNewKey(mockKey);
            setKeys(prev => [...prev, { id: `key-${Date.now()}`, name: `Demo Key ${new Date().toLocaleDateString()}`, key_preview: mockKey.substring(0, 8) + '...', created_at: new Date().toISOString() }]);
            toast.success("Simulation: New API Key generated");
            return;
        }

        try {
            const res = await api.generateApiKey(`Control Panel ${new Date().toLocaleDateString()}`);
            setNewKey(res.api_key);
            load();
        } catch (e) {
            toast.error("Failed to generate key");
        }
    };

    const deleteKey = async (id) => {
        if (isDemo) {
            setKeys(prev => prev.filter(k => k.id !== id));
            toast.success("Simulation: Key deleted");
            return;
        }

        try {
            await api.deleteApiKey(id);
            load();
            toast.success("Key deleted");
        } catch (e) {
            toast.error("Failed to delete key");
        }
    };

    return (
        <div className="p-4 space-y-6">
            <div className="flex justify-between items-center">
                <IntentText>Active API Keys</IntentText>
                <Button onClick={generate} size="sm" className="bg-[hsl(var(--color-intent))] text-white">
                    <Key className="w-4 h-4 mr-2" /> Generate New
                </Button>
            </div>

            {newKey && (
                <div className="bg-[hsl(var(--color-warning))]/10 border border-[hsl(var(--color-warning))] p-4 rounded text-center">
                    <StateText className="text-[hsl(var(--color-warning))] font-bold mb-2">SAVE THIS KEY NOW. IT WILL NOT BE SHOWN AGAIN.</StateText>
                    <div className="bg-black p-3 rounded font-mono text-lg select-all text-white border border-white/20">
                        {newKey}
                    </div>
                </div>
            )}

            <div className="space-y-2">
                {keys.map(k => (
                    <SystemCard
                        key={k.id}
                        title={k.name}
                        subtitle={`Prefix: ${k.key_preview}...`}
                        icon={Key}
                        status="active"
                        metric={new Date(k.created_at).toLocaleDateString()}
                    >
                        <div className="flex justify-end mt-2">
                            <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); deleteKey(k.id); }} className="h-7 text-[hsl(var(--color-error))] hover:bg-[hsl(var(--color-error))]/10">
                                <LogOut className="w-3 h-3 mr-2" /> Revoke Key
                            </Button>
                        </div>
                    </SystemCard>
                ))}
            </div>
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                                MAIN PAGE                                   */
/* -------------------------------------------------------------------------- */

export default function ControlPanel() {
    const [loggedIn, setLoggedIn] = useState(false);

    useEffect(() => {
        setLoggedIn(isAuthenticated());
    }, []);

    const handleLogout = () => {
        clearToken();
        setLoggedIn(false);
    };

    // Demo Mode Logic
    const isDemo = loggedIn === 'demo';

    if (!loggedIn) {
        return (
            <div className="min-h-screen bg-neutral-950 flex items-center justify-center">
                <LoginView onLogin={() => setLoggedIn(true)} />
            </div>
        );
    }

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Server className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">CONTROL PANEL</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">MVP Interface</IntentText>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">Status</StateText>
                                    <IntentText className="text-xl text-[hsl(var(--color-execution))]">CONNECTED</IntentText>
                                </div>
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">Target</StateText>
                                    <IntentText className="text-xl">{isDemo ? 'DEMO NODE' : 'xi-io.com'}</IntentText>
                                </div>
                            </div>

                            <div className="mt-6 space-y-4">
                                {isDemo && (
                                    <div className="mb-4 bg-blue-500/10 border border-blue-500/30 p-3 rounded">
                                        <div className="flex items-center gap-2 mb-2 text-blue-400 font-bold">
                                            <Terminal className="w-4 h-4" />
                                            <span className="text-xs uppercase tracking-wider">Educational Mode Active</span>
                                        </div>
                                        <p className="text-[10px] text-blue-200/70 leading-relaxed">
                                            You are viewing a simulated environment. Actions here do not affect production systems. Use this mode to learn the control interfaces safely.
                                        </p>
                                    </div>
                                )}
                                <GuideBox title="System Capabilities">
                                    <ul className="list-disc pl-4 space-y-1">
                                        <li><TermHelper term="Task Board">Command center for assigning protocols to autonomous agents.</TermHelper></li>
                                        <li><TermHelper term="Repositories">View structure of connected codebases.</TermHelper></li>
                                        <li><TermHelper term="API Keys">Manage access tokens for external integrations.</TermHelper></li>
                                    </ul>
                                </GuideBox>

                                <Button onClick={handleLogout} variant="outline" className="w-full border-[hsl(var(--color-error))]/20 text-[hsl(var(--color-error))] hover:bg-[hsl(var(--color-error))]/10">
                                    <LogOut className="w-4 h-4 mr-2" /> DISCONNECT
                                </Button>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none" scrollable={false}>
                            <OrientingText className="mb-4">SYSTEM LOGS</OrientingText>
                            <SystemLog 
                                className="h-full"
                                logs={[
                                    { type: 'SYS', content: 'Connection established', status: 'nominal', timestamp: new Date(Date.now() - 5000).toISOString() },
                                    { type: 'AUTH', content: 'Token validated', status: 'nominal', timestamp: new Date(Date.now() - 4000).toISOString() },
                                    { type: 'API', content: 'Handshake complete', status: 'nominal', timestamp: new Date(Date.now() - 3000).toISOString() },
                                    ...(isDemo ? [
                                        { type: 'DEMO', content: 'Loading simulation data...', status: 'active', timestamp: new Date(Date.now() - 2000).toISOString() },
                                        { type: 'DEMO', content: 'Virtual node initialized', status: 'active', timestamp: new Date(Date.now() - 1000).toISOString() },
                                        { type: 'DEMO', content: 'Mock services ready', status: 'active', timestamp: new Date().toISOString() }
                                    ] : [])
                                ]}
                            />
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col" scrollable={false}>
                             <Tabs defaultValue="tasks" className="w-full h-full flex flex-col">
                                <div className="px-8 pt-4 border-b border-white/5 bg-neutral-900/30">
                                    <TabsList className="bg-transparent gap-4">
                                        <TabsTrigger value="tasks" className="data-[state=active]:bg-[hsl(var(--color-execution))]/10 data-[state=active]:text-[hsl(var(--color-execution))] bg-transparent text-neutral-500 rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-execution))]">
                                            <Layout className="w-4 h-4 mr-2" /> Task Board
                                        </TabsTrigger>
                                        <TabsTrigger value="projects" className="data-[state=active]:bg-[hsl(var(--color-execution))]/10 data-[state=active]:text-[hsl(var(--color-execution))] bg-transparent text-neutral-500 rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-execution))]">
                                            <Server className="w-4 h-4 mr-2" /> Projects
                                        </TabsTrigger>
                                        <TabsTrigger value="keys" className="data-[state=active]:bg-[hsl(var(--color-execution))]/10 data-[state=active]:text-[hsl(var(--color-execution))] bg-transparent text-neutral-500 rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-execution))]">
                                            <Key className="w-4 h-4 mr-2" /> API Keys
                                        </TabsTrigger>
                                    </TabsList>
                                </div>

                                <div className="flex-1 overflow-y-auto bg-neutral-950">
                                    <TabsContent value="tasks" className="m-0 h-full">
                                        <TaskBoard isDemo={isDemo} />
                                    </TabsContent>
                                    <TabsContent value="projects" className="m-0 h-full">
                                        <ProjectList isDemo={isDemo} />
                                    </TabsContent>
                                    <TabsContent value="keys" className="m-0 h-full">
                                        <ApiKeyManager isDemo={isDemo} />
                                    </TabsContent>
                                </div>
                            </Tabs>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}