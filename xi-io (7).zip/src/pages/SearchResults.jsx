import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Search, FileText, ShoppingBag, Users, Zap, 
    Database, ArrowRight, Tag, Filter, Globe,
    Layout as LayoutIcon, Box, X, Activity, Shield,
    Layers, List, Clock, BrainCircuit, Save, Trash2
    } from 'lucide-react';
import { cn } from '@/lib/utils';
import { createPageUrl } from '@/utils';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant, IntentText, StateText, OrientingText, SemanticDot } from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { MagazineResult } from '@/components/search/MagazineResult';
import { SemanticStackView } from '@/components/search/SemanticStackView';
import { BSMeter } from '@/components/search/SearchWidgets';
import { NullResult } from '@/components/search/NullResult';
import { SearchContextSidebar } from '@/components/search/SearchContextSidebar';

export default function SearchResults() {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const initialQuery = searchParams.get('q') || '';
    const initialScope = searchParams.get('scope') || 'web';
    const initialEngine = searchParams.get('engine') || 'google';
    
    const [query, setQuery] = useState(initialQuery);
    const [activeTab, setActiveTab] = useState('all');
    const [searchScope, setSearchScope] = useState(initialScope);
    const [engine, setEngine] = useState(initialEngine);
    const [isSemanticMode, setIsSemanticMode] = useState(false);
    const [searchHistory, setSearchHistory] = useState([]);
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [page, setPage] = useState(0);
    const PAGE_SIZE = 6;

    // --- EFFECT: History ---
    useEffect(() => {
        if (query && !searchHistory.includes(query)) {
             setSearchHistory(prev => [...prev, query]);
        }
    }, [query]);

    // --- EFFECT: Sync URL ---
    useEffect(() => {
        setQuery(searchParams.get('q') || '');
    }, [location.search]);

    // --- QUERY: Search ---
    const { data: results, isLoading } = useQuery({
        queryKey: ['global_search', query, searchScope, engine, isSemanticMode, activeTab],
        queryFn: async () => {
            if (!query) return { all: [], byType: {} };

            // WEB SEARCH (Mocked for Structure)
            if (searchScope === 'web') {
                 const result = await base44.integrations.Core.InvokeLLM({
                    prompt: `Search for "${query}". Return structured JSON results.`,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            results: {
                                type: "array",
                                items: {
                                    type: "object",
                                    properties: {
                                        title: { type: "string" },
                                        description: { type: "string" },
                                        url: { type: "string" },
                                        source: { type: "string" },
                                        quality_score: { type: "integer" }
                                    }
                                }
                            }
                        }
                    }
                });
                const webResults = result.results || [];
                const formatted = webResults.map((r, i) => ({
                    id: `web-${i}`,
                    name: r.title,
                    description: r.description,
                    type: 'external_signal',
                    icon: Globe,
                    url: r.url,
                    tags: [r.source],
                    quality_score: r.quality_score,
                    isExternal: true
                }));
                return { all: formatted, byType: { external_signal: formatted } };
            }

            // LOCAL SEARCH
            const [marketplaceItems, pages, customers] = await Promise.all([
                base44.entities.MarketplaceItem.list(),
                base44.entities.ContentPage.list(),
                base44.entities.Customer.list()
            ]);

            // Simple Filter Logic
            const searchTerms = [query.toLowerCase()];
            const searchIn = (item, fields) => fields.some(f => searchTerms.some(term => (item[f] || '').toLowerCase().includes(term)));

            const matches = [
                ...marketplaceItems.filter(i => searchIn(i, ['name', 'description'])).map(i => ({ 
                    ...i, type: 'marketplace', icon: ShoppingBag, url: createPageUrl('Marketplace') + `?item=${i.id}` 
                })),
                ...pages.filter(p => searchIn(p, ['title'])).map(p => ({ 
                    ...p, type: 'content', icon: FileText, url: createPageUrl('ContentManager') + `?page=${p.id}` 
                })),
                ...customers.filter(c => searchIn(c, ['name', 'email'])).map(c => ({ 
                    ...c, type: 'crm', icon: Users, url: createPageUrl('CRM') + `?id=${c.id}` 
                }))
            ];

            return {
                all: matches,
                byType: {
                    marketplace: matches.filter(m => m.type === 'marketplace'),
                    content: matches.filter(m => m.type === 'content'),
                    crm: matches.filter(m => m.type === 'crm')
                }
            };
        }
    });

    const displayResults = results ? (activeTab === 'all' ? results.all : (results.byType[activeTab] || [])) : [];

    // --- HANDLERS ---
    const handleToggleSelect = (id) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    };

    return (
        <div className="h-full w-full bg-transparent text-[hsl(var(--fg-intent))] flex flex-col overflow-hidden">
             <div className="flex-1 overflow-hidden">
                <FluidGrid
                    left={
                        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                            <Quadrant type="orientation" step="1" title="Context" className="border-b">
                                <div className="p-4 border-b border-white/5 bg-neutral-900/30">
                                    <OrientingText className="mb-2">SEARCH QUERY</OrientingText>
                                    <Input 
                                        placeholder="Search..." 
                                        value={query} 
                                        onChange={(e) => setQuery(e.target.value)}
                                        className="bg-black/50 border-white/10"
                                    />
                                </div>
                                <SearchContextSidebar query={query} results={results} />
                                
                                <div className="mt-6 pt-6 border-t border-white/5">
                                    <OrientingText className="text-[hsl(var(--color-intent))] mb-2">SESSION HISTORY</OrientingText>
                                    <div className="space-y-1">
                                        {searchHistory.map((h, i) => (
                                            <div key={i} className="flex items-center gap-2 text-xs text-neutral-500 hover:text-white cursor-pointer" onClick={() => setQuery(h)}>
                                                <Clock className="w-3 h-3" />
                                                <span>{h}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </Quadrant>

                            <Quadrant type="state" step="3" title="BS Meter" className="border-t-0 rounded-t-none">
                                <BSMeter query={query} results={displayResults} />
                            </Quadrant>
                        </QuadrantGrid>
                    }
                    right={
                        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                            <Quadrant type="intent" dominance="dominant" step="2" title="Signals" className="p-0 flex flex-col border-b">
                                <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/30">
                                    <div className="flex items-center gap-2">
                                        <SemanticDot type="active" />
                                        <StateText className="font-mono text-xs">{displayResults.length} Signals Found</StateText>
                                    </div>
                                    <div className="flex gap-2">
                                        {selectedIds.size > 0 && (
                                            <Badge className="bg-[hsl(var(--color-intent))] text-black">{selectedIds.size} Selected</Badge>
                                        )}
                                    </div>
                                </div>

                                <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin scrollbar-thumb-white/10">
                                    {isLoading ? (
                                        <div className="flex items-center justify-center h-full opacity-50">
                                            <Activity className="w-8 h-8 animate-pulse text-[hsl(var(--color-intent))]" />
                                        </div>
                                    ) : displayResults.length === 0 ? (
                                        <NullResult query={query} scope={searchScope} onExpandSearch={() => setSearchScope('web')} />
                                    ) : (
                                        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                                            {displayResults.map((item, idx) => (
                                                <SystemCard
                                                    key={item.id}
                                                    title={item.name}
                                                    subtitle={item.description}
                                                    icon={item.icon}
                                                    status={item.type === 'external_signal' ? 'unknown' : 'active'}
                                                    metric={item.quality_score ? `${item.quality_score}%` : null}
                                                    active={selectedIds.has(item.id)}
                                                    onClick={() => handleToggleSelect(item.id)}
                                                >
                                                    <div className="flex flex-wrap gap-1 mt-2 mb-4">
                                                        {item.tags?.map((tag, i) => (
                                                            <Badge key={i} variant="outline" className="text-[9px] h-4 px-1 border-white/5 text-neutral-500">{tag}</Badge>
                                                        ))}
                                                    </div>
                                                    
                                                    {/* ActionDock Injection - Standardized Verb Layer */}
                                                    <ActionDock 
                                                        primaryAction={{
                                                            label: "Open",
                                                            icon: ArrowRight,
                                                            onClick: (e) => {
                                                                e.stopPropagation();
                                                                window.open(item.url, '_blank');
                                                            }
                                                        }}
                                                        secondaryActions={[
                                                            { 
                                                                label: "Add to Project", 
                                                                icon: Box,
                                                                onClick: (e) => {
                                                                    e.stopPropagation();
                                                                    // In a real app, this would open a project picker
                                                                    base44.entities.Task.create({
                                                                        title: `Review ${item.name}`,
                                                                        description: `Analyze resource found in search: ${item.url}`,
                                                                        status: 'todo',
                                                                        project_id: 'default'
                                                                    });
                                                                    toast.success(`Added "${item.name}" to project tasks`);
                                                                }
                                                            },
                                                            {
                                                                label: "Share", 
                                                                icon: Users,
                                                                onClick: (e) => {
                                                                    e.stopPropagation();
                                                                    navigator.clipboard.writeText(item.url);
                                                                    toast.success("Link copied to clipboard");
                                                                }
                                                            }
                                                        ]}
                                                    />
                                                </SystemCard>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </Quadrant>

                            <Quadrant type="execution" step="4" title="Research Stack" dominance="supporting" className="border-t-0 rounded-t-none flex flex-col h-full overflow-hidden">
                                <div className="p-4 bg-black/40 flex-1 overflow-y-auto space-y-2">
                                    {selectedIds.size === 0 ? (
                                        <div className="h-full flex flex-col items-center justify-center text-neutral-500 gap-2 opacity-50">
                                            <Layers className="w-8 h-8" />
                                            <span className="text-[10px] uppercase tracking-widest text-center">Select signals to build<br/>Research Stack</span>
                                        </div>
                                    ) : (
                                        <>
                                            <div className="flex justify-between items-center mb-2">
                                                <span className="text-[10px] font-mono text-neutral-400">{selectedIds.size} ITEMS STACKED</span>
                                                <button onClick={() => setSelectedIds(new Set())} className="text-[10px] text-red-400 hover:text-red-300 flex items-center gap-1">
                                                    <Trash2 className="w-3 h-3" /> Clear
                                                </button>
                                            </div>
                                            {displayResults.filter(r => selectedIds.has(r.id)).map(item => (
                                                <div key={item.id} className="flex items-center gap-2 p-2 rounded bg-white/5 border border-white/5 group">
                                                    <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-intent))]" />
                                                    <span className="text-xs truncate flex-1 text-neutral-300">{item.name}</span>
                                                    <button onClick={() => handleToggleSelect(item.id)} className="opacity-0 group-hover:opacity-100 text-neutral-500 hover:text-white transition-opacity">
                                                        <X className="w-3 h-3" />
                                                    </button>
                                                </div>
                                            ))}
                                        </>
                                    )}
                                </div>
                                
                                <div className="p-4 border-t border-white/10 space-y-2 bg-neutral-900/50">
                                    <Button 
                                        className="w-full bg-[hsl(var(--color-intent))] text-black font-bold hover:bg-[hsl(var(--color-intent))]/90 shadow-[0_0_15px_-5px_hsl(var(--color-intent))]" 
                                        disabled={selectedIds.size === 0}
                                        onClick={() => {
                                            const stack = displayResults.filter(r => selectedIds.has(r.id));
                                            window.dispatchEvent(new CustomEvent('omni-open-council', { 
                                                detail: { stack, query } 
                                            }));
                                        }}
                                    >
                                        <BrainCircuit className="w-4 h-4 mr-2" />
                                        Analyze with Council
                                    </Button>
                                    <div className="grid grid-cols-2 gap-2">
                                        <Button variant="outline" className="w-full border-white/10 hover:bg-white/5" disabled={selectedIds.size === 0}>
                                            <Save className="w-3 h-3 mr-2" />
                                            Save to Plan
                                        </Button>
                                        <Button variant="outline" className="w-full border-white/10 hover:bg-white/5">
                                            Export
                                        </Button>
                                    </div>
                                </div>
                            </Quadrant>
                        </QuadrantGrid>
                    }
                />
             </div>
        </div>
    );
}