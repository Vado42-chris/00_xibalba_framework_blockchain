import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import Dashboard from './Dashboard';
import GatewayLanding from '@/components/home/GatewayLanding';

export default function Home() {
    const { data: user, isLoading } = useQuery({
        queryKey: ['me'],
        queryFn: () => base44.auth.me().catch(() => null),
        retry: false
    });

    if (isLoading) return null;

    if (!user) {
        return <GatewayLanding />;
    }

    return <Dashboard />;
}