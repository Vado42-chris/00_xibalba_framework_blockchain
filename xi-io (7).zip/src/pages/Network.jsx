import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { QuadrantGrid, Quadrant, OrientingText, IntentText } from '@/components/ui/design-system/System';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Globe, Server, Activity, Wifi, Shield, Lock } from 'lucide-react';
import SystemMap from '@/components/network/SystemMap';
import TunnelTopology from '@/components/network/TunnelTopology';
import { PolicyMonitor } from '@/components/network/PolicyMonitor';
import { AddonGate } from '@/components/integrations/AddonGate';
import SentinelAegis from '@/components/addons/official/SentinelAegis';

import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Network() {
    const { data: nodes = [] } = useQuery({ queryKey: ['nodes'], queryFn: () => base44.entities.Node.list(), initialData: [] });
    const { data: agents = [] } = useQuery({ queryKey: ['agents'], queryFn: () => base44.entities.Agent.list(), initialData: [] });
    const { data: rules = [] } = useQuery({ queryKey: ['network_rules'], queryFn: () => base44.entities.NetworkRule.list(), initialData: [] });

    const activeVpn = rules.find(r => r.policy === 'vpn_required' || r.ssid.includes('BlackHole'));

    return (
        <div className="h-full w-full bg-transparent overflow-hidden flex flex-col">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Operations" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Globe className="w-4 h-4 text-neutral-400" />
                                        <OrientingText className="tracking-widest font-bold">NETWORK OPERATIONS</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Global Mesh Control</IntentText>
                                </div>
                            </div>

                            <SystemStats 
                                className="grid-cols-1 gap-2"
                                stats={[
                                    { label: "Active Nodes", value: nodes.length || "0", icon: Server },
                                    { label: "Mesh Status", value: "HEALTHY", icon: Wifi, color: "text-[hsl(var(--color-execution))]" },
                                    { label: "Latency", value: "42ms", icon: Activity }
                                ]}
                            />
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Policies" className="flex flex-col p-0 border-t-0 border-b overflow-hidden" scrollable={false}>
                            <PolicyMonitor />
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Nodes" className="flex flex-col p-4 border-t-0 rounded-t-none" scrollable={false}>
                            <div className="text-xs font-mono text-neutral-500 mb-2">ACTIVE NODES</div>
                            <div className="space-y-2 overflow-y-auto pr-2">
                                {nodes.map((node, i) => (
                                    <Link key={i} to={createPageUrl('Nodes')}>
                                        <div className="flex justify-between items-center p-2 rounded bg-white/5 text-xs hover:bg-white/10 cursor-pointer transition-colors mb-2">
                                            <div className="flex items-center gap-3">
                                                <span className={node.status === 'connected' ? 'text-green-500' : 'text-red-500'}>●</span>
                                                <span className="font-mono text-white">{node.name}</span>
                                            </div>
                                            <span className="text-neutral-500 font-mono">{node.ip_address}</span>
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Topology" dominance="dominant" className="p-0 bg-neutral-900/50 border-none relative overflow-hidden border-b">
                            <div className="absolute inset-0">
                                <AddonGate
                                    addonName="Sentinel Aegis"
                                    title="Network Security"
                                    icon={Shield}
                                    fallback={
                                        <SystemMap nodes={nodes} agents={agents} vpnActive={false} />
                                    }
                                >
                                    <SentinelAegis nodes={nodes} active={true} />
                                </AddonGate>
                            </div>
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Traffic" dominance="supporting" className="border-t-0 rounded-t-none">
                             <div className="space-y-2">
                                <div className="flex justify-between text-[10px] text-neutral-500 border-b border-white/5 pb-1">
                                    <span>REGION</span>
                                    <span>LOAD</span>
                                </div>
                                {['US-EAST', 'EU-WEST', 'ASIA-PAC'].map((region, i) => (
                                    <div key={i} className="flex justify-between items-center text-xs">
                                        <span className="text-white">{region}</span>
                                        <div className="w-24 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                            <div className="h-full bg-[hsl(var(--color-execution))]" style={{width: `${Math.random() * 80 + 10}%`}} />
                                        </div>
                                    </div>
                                ))}
                             </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}