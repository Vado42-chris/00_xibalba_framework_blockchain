import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Shield, Lock, Eye, Briefcase, Plus, Trash2, 
    Save, RefreshCw, CheckCircle2, AlertTriangle 
} from 'lucide-react';
import { cn } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { GuideBox } from '@/components/ui/GuideBox';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/System';
import { FluidGrid } from '@/components/ui/FluidGrid';

const DEFAULT_SETTINGS = {
    show_online_status: true,
    allow_incoming_messages: true,
    share_usage_analytics: false,
    visible_in_directory: true,
    encrypt_logs: false,
    record_activity: true,
    allow_location_tracking: false
};

const MODE_CONFIG = {
    public: {
        icon: Eye,
        color: "text-green-500",
        description: "Settings for when you are visible to the entire network."
    },
    private: {
        icon: Lock,
        color: "text-red-500",
        description: "Settings for your secure, local-only environment."
    },
    work: {
        icon: Briefcase,
        color: "text-blue-500",
        description: "Settings applicable during professional workflows."
    }
};

const SETTING_LABELS = {
    show_online_status: "Show Online Status",
    allow_incoming_messages: "Allow Incoming Messages",
    share_usage_analytics: "Share Usage Analytics",
    visible_in_directory: "Visible in Global Directory",
    encrypt_logs: "Encrypt Activity Logs",
    record_activity: "Record Session Activity",
    allow_location_tracking: "Allow Location Services"
};

export default function PrivacyPreferences() {
    const queryClient = useQueryClient();
    const [newModeName, setNewModeName] = useState("");
    const [isCreating, setIsCreating] = useState(null); 
    const [activeTab, setActiveTab] = useState("public");

    const { data: subModes = [] } = useQuery({
        queryKey: ['privacy_sub_modes'],
        queryFn: () => base44.entities.PrivacySubMode.list(),
        initialData: []
    });

    const createModeMutation = useMutation({
        mutationFn: (data) => base44.entities.PrivacySubMode.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries(['privacy_sub_modes']);
            setNewModeName("");
            setIsCreating(null);
            toast.success("New privacy profile created");
        }
    });

    const updateModeMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.PrivacySubMode.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries(['privacy_sub_modes']);
            toast.success("Privacy settings updated");
        }
    });

    const deleteModeMutation = useMutation({
        mutationFn: (id) => base44.entities.PrivacySubMode.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries(['privacy_sub_modes']);
            toast.success("Profile deleted");
        }
    });

    const handleCreate = (parentMode) => {
        if (!newModeName.trim()) return;
        createModeMutation.mutate({
            name: newModeName,
            parent_mode: parentMode,
            settings: { ...DEFAULT_SETTINGS }
        });
    };

    const handleSettingChange = (mode, key, value) => {
        const newSettings = { ...mode.settings, [key]: value };
        updateModeMutation.mutate({ id: mode.id, data: { settings: newSettings } });
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Shield className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">PRIVACY MATRIX</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Security Contexts</IntentText>
                                </div>
                            </div>
                            
                            <div className="space-y-2">
                                {Object.keys(MODE_CONFIG).map(key => (
                                    <Button 
                                        key={key}
                                        variant={activeTab === key ? 'secondary' : 'ghost'} 
                                        onClick={() => setActiveTab(key)}
                                        className="w-full justify-start text-xs h-9 capitalize"
                                    >
                                        <span className={`w-2 h-2 rounded-full mr-3 ${key === 'public' ? 'bg-green-500' : key === 'private' ? 'bg-red-500' : 'bg-blue-500'}`} />
                                        {key}
                                    </Button>
                                ))}
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">TRUTH LAYER</OrientingText>
                            <div className="space-y-4">
                                <Layer level="state" className="p-4 border-l-2 border-[hsl(var(--color-execution))]">
                                    <div className="flex flex-col gap-1">
                                        <StateText className="text-lg font-bold text-white tracking-tight">PRIVACY MATRIX NOMINAL</StateText>
                                        <div className="flex items-center gap-2 text-[10px] text-neutral-500 uppercase tracking-wider font-mono">
                                            <span>Synced {new Date().toLocaleTimeString()}</span>
                                            <span className="w-1 h-1 rounded-full bg-neutral-600" />
                                            <span>3 Contexts Enforcing</span>
                                        </div>
                                    </div>
                                </Layer>

                                <Layer level="orientation" className="p-3">
                                    <div className="flex justify-between text-xs mb-2">
                                        <span className="text-neutral-500">Encryption Standard</span>
                                        <span className="text-[hsl(var(--color-execution))] font-mono">AES-256-GCM</span>
                                    </div>
                                    <div className="flex justify-between text-xs mb-2">
                                        <span className="text-neutral-500">Data Retention</span>
                                        <span className="text-white font-mono">30 DAYS / ROLLING</span>
                                    </div>
                                    <div className="flex justify-between text-xs">
                                        <span className="text-neutral-500">Network Visibility</span>
                                        <span className={cn(
                                            "font-mono font-bold",
                                            activeTab === 'public' ? "text-green-500" : "text-red-500"
                                        )}>
                                            {activeTab === 'public' ? 'BROADCASTING' : 'CLOAKED'}
                                        </span>
                                    </div>
                                </Layer>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                            <div className="p-8">
                                <div className="flex items-start gap-4 mb-8">
                                    <div className={`p-3 rounded-full bg-neutral-900 border border-white/10 ${MODE_CONFIG[activeTab].color}`}>
                                        {React.createElement(MODE_CONFIG[activeTab].icon, { className: "w-6 h-6" })}
                                    </div>
                                    <div>
                                        <IntentText className="text-2xl font-light capitalize">{activeTab} Context</IntentText>
                                        <StateText className="text-sm opacity-60 max-w-lg mt-1">{MODE_CONFIG[activeTab].description}</StateText>
                                    </div>
                                </div>

                                <div className="space-y-8">
                                    <div>
                                        <div className="flex items-center justify-between mb-4">
                                            <OrientingText>CUSTOM SUB-MODES</OrientingText>
                                            <Button 
                                                variant="outline" 
                                                size="sm" 
                                                className="h-7 text-[10px]"
                                                onClick={() => setIsCreating(activeTab)}
                                            >
                                                <Plus className="w-3 h-3 mr-2" /> New Profile
                                            </Button>
                                        </div>

                                        {isCreating === activeTab && (
                                            <div className="p-4 rounded border border-dashed border-[hsl(var(--color-intent))] bg-neutral-900/30 mb-4 flex gap-2">
                                                <Input 
                                                    placeholder="Profile Name..." 
                                                    value={newModeName}
                                                    onChange={(e) => setNewModeName(e.target.value)}
                                                    className="bg-neutral-950 border-white/10 h-8 text-xs"
                                                    autoFocus
                                                />
                                                <Button size="sm" onClick={() => handleCreate(activeTab)} className="h-8 bg-[hsl(var(--color-intent))] text-white">Save</Button>
                                                <Button size="sm" variant="ghost" onClick={() => setIsCreating(null)} className="h-8">Cancel</Button>
                                            </div>
                                        )}

                                        <div className="space-y-4">
                                            {subModes.filter(m => m.parent_mode === activeTab).map(mode => (
                                                <div key={mode.id} className="rounded-lg border border-white/5 bg-neutral-900/30 overflow-hidden">
                                                    <div className="p-3 border-b border-white/5 bg-neutral-900/50 flex justify-between items-center">
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-sm font-bold text-white">{mode.name}</span>
                                                            {mode.is_active && <Badge variant="outline" className="text-[9px] text-green-500 border-green-900 bg-green-950/30">ACTIVE</Badge>}
                                                        </div>
                                                        <Button variant="ghost" size="icon" className="h-6 w-6 text-neutral-500 hover:text-red-500" onClick={() => deleteModeMutation.mutate(mode.id)}>
                                                            <Trash2 className="w-3 h-3" />
                                                        </Button>
                                                    </div>
                                                    <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                                                        {Object.entries(mode.settings || DEFAULT_SETTINGS).map(([key, value]) => (
                                                            <div key={key} className="flex items-center justify-between gap-4">
                                                                <Label htmlFor={`${mode.id}-${key}`} className="text-xs text-neutral-400 font-normal cursor-pointer flex-1">{SETTING_LABELS[key] || key}</Label>
                                                                <Switch 
                                                                    id={`${mode.id}-${key}`} 
                                                                    checked={value}
                                                                    onCheckedChange={(checked) => handleSettingChange(mode, key, checked)}
                                                                    className="scale-75 data-[state=checked]:bg-[hsl(var(--color-execution))]"
                                                                />
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            ))}
                                            {subModes.filter(m => m.parent_mode === activeTab).length === 0 && (
                                                <div className="text-center py-8 border border-dashed border-white/5 rounded opacity-50">
                                                    <Shield className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                                                    <StateText>No custom profiles defined.</StateText>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}