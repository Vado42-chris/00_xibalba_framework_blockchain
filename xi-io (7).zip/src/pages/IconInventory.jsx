import React, { useState } from 'react';
import { 
    SYSTEM_ICONS, SystemIcon 
} from '@/components/ui/design-system/Iconography';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, Layer 
} from '@/components/ui/design-system/System';
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Copy, Component } from 'lucide-react';

export default function IconInventory() {
    const [searchTerm, setSearchTerm] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("ALL");

    const categories = ["ALL", ...Object.keys(SYSTEM_ICONS)];

    const handleCopy = (name) => {
        navigator.clipboard.writeText(name);
        toast.success(`Copied "${name}" to clipboard`);
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Component className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">SYSTEM RESOURCES</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Iconography Matrix</IntentText>
                                </div>
                            </div>
                            <StateText className="opacity-70 leading-relaxed mb-4">
                                Centralized index of semantic glyphs. Click to copy semantic keys.
                            </StateText>
                            <div className="relative">
                                <StateText className="mb-2">Filter Registry</StateText>
                                <Input 
                                    placeholder="Search icons..." 
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="bg-neutral-900 border-white/10"
                                />
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">CATEGORIES</OrientingText>
                            <div className="space-y-1 overflow-y-auto pr-2">
                                {categories.map(cat => (
                                    <button
                                        key={cat}
                                        onClick={() => setSelectedCategory(cat)}
                                        className={`w-full text-left px-3 py-2 text-xs font-mono rounded transition-colors flex justify-between items-center ${selectedCategory === cat ? 'bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))] border border-[hsl(var(--color-intent))]/30' : 'text-neutral-500 hover:text-white hover:bg-white/5 border border-transparent'}`}
                                    >
                                        <span>{cat}</span>
                                        {cat !== "ALL" && <span className="opacity-50 text-[9px]">{Object.keys(SYSTEM_ICONS[cat] || {}).length}</span>}
                                    </button>
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                            <div className="p-8">
                                {Object.entries(SYSTEM_ICONS).map(([category, icons]) => {
                                    if (selectedCategory !== "ALL" && selectedCategory !== category) return null;
                                    
                                    const filteredIcons = Object.entries(icons).filter(([name]) => 
                                        name.toLowerCase().includes(searchTerm.toLowerCase())
                                    );

                                    if (filteredIcons.length === 0) return null;

                                    return (
                                        <div key={category} className="mb-12">
                                            <div className="flex items-center gap-2 mb-6 border-b border-white/5 pb-2">
                                                <OrientingText>{category}</OrientingText>
                                                <span className="text-[9px] text-neutral-600 font-mono">({filteredIcons.length})</span>
                                            </div>
                                            
                                            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
                                                {filteredIcons.map(([name, Icon]) => (
                                                    <div 
                                                        key={name}
                                                        className="group flex flex-col items-center justify-center p-4 rounded border border-white/5 bg-neutral-900/30 hover:bg-neutral-800 hover:border-[hsl(var(--color-intent))] transition-all cursor-pointer relative aspect-square"
                                                        onClick={() => handleCopy(name)}
                                                    >
                                                        <div className="mb-3 text-neutral-400 group-hover:text-white transition-colors">
                                                            <Icon className="w-6 h-6" />
                                                        </div>
                                                        <div className="text-[10px] font-mono text-neutral-500 group-hover:text-[hsl(var(--color-intent))] text-center truncate w-full px-2">
                                                            {name}
                                                        </div>
                                                        
                                                        {/* Hover Overlay */}
                                                        <div className="absolute inset-0 bg-[hsl(var(--color-intent))]/5 opacity-0 group-hover:opacity-100 transition-opacity rounded" />
                                                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                            <Copy className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}