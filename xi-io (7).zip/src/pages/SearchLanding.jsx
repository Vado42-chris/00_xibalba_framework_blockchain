import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Search, FileText, ShoppingBag, Users, Zap, 
    Database, ArrowRight, Tag, Filter, Globe,
    Layout as LayoutIcon, Box, X, Activity, Shield,
    List, Layers, Eye, Terminal, CheckCircle2
    } from 'lucide-react';
import { useGamification } from '@/components/features/GamificationSystem';
import { cn } from '@/lib/utils';
import { createPageUrl } from '@/utils';
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { BSMeter, QuoraIntegration, SearchChat } from '@/components/search/SearchWidgets';
import { MagazineResult } from '@/components/search/MagazineResult';
import { SemanticStackView } from '@/components/search/SemanticStackView';
import { SearchEngineSelector, ZipperTrigger, SEARCH_ENGINES } from '@/components/search/SearchEngineSelector';
import { SearchContextSidebar } from '@/components/search/SearchContextSidebar';
import { NullResult } from '@/components/search/NullResult';
import { SearchBackground } from '@/components/search/SearchBackground';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/System';
import { FluidGrid } from '@/components/ui/FluidGrid';

export default function SearchLanding() {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const initialQuery = searchParams.get('q') || '';
    const initialScope = searchParams.get('scope') || 'web';
    const initialEngine = searchParams.get('engine') || 'google';
    
    const [query, setQuery] = useState(initialQuery);
    const [activeTab, setActiveTab] = useState('all');
    const [searchScope, setSearchScope] = useState(initialScope);
    const [engine, setEngine] = useState(initialEngine);
    const [isSemanticMode, setIsSemanticMode] = useState(false);
    const [searchHistory, setSearchHistory] = useState([]);
    const [dismissedIds, setDismissedIds] = useState(new Set());
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [page, setPage] = useState(0);
    const PAGE_SIZE = 6;
    
    const { awardXP } = useGamification();

    useEffect(() => {
        const handleKeyDown = (e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                const input = document.getElementById('hero-search-input');
                if (input) input.focus();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    useEffect(() => {
        setActiveTab('all');
        setDismissedIds(new Set());
        setSelectedIds(new Set());
        setPage(0);
    }, [searchScope]);

    useEffect(() => {
        setDismissedIds(new Set());
        setSelectedIds(new Set());
        setPage(0);
    }, [query]);

    useEffect(() => {
        if (query && !searchHistory.includes(query)) {
             setSearchHistory(prev => [...prev, query]);
        }
    }, [query]);

    useEffect(() => {
        setQuery(searchParams.get('q') || '');
    }, [location.search]);

    const semanticExpansionMutation = useMutation({
        mutationFn: async (searchQuery) => {
            try {
                const response = await base44.integrations.Core.InvokeLLM({
                    prompt: `Analyze search query: "${searchQuery}". Return JSON with {keywords: [], intent: "", targetTypes: []}`,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            keywords: { type: "array", items: { type: "string" } },
                            intent: { type: "string" },
                            targetTypes: { type: "array", items: { type: "string" } }
                        }
                    }
                });
                return response;
            } catch (e) {
                console.error("Semantic expansion failed", e);
                return { keywords: [searchQuery], intent: "Direct search", targetTypes: [] };
            }
        }
    });

    const { data: results, isLoading } = useQuery({
        queryKey: ['global_search', query, searchScope, engine, isSemanticMode, activeTab],
        queryFn: async () => {
            if (!query) return { all: [], byType: {} };

            if (searchScope === 'web') {
                const result = await base44.integrations.Core.InvokeLLM({
                    prompt: `Search web for: "${query}". Category: ${activeTab}. Engine: ${engine}. Return JSON results.`,
                    add_context_from_internet: true,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            results: {
                                type: "array",
                                items: {
                                    type: "object",
                                    properties: {
                                        title: { type: "string" },
                                        description: { type: "string" },
                                        url: { type: "string" },
                                        source: { type: "string" },
                                        content_origin: { type: "string", enum: ["HUMAN", "AI", "BOT", "MARKETING", "HYBRID"] },
                                        quality_score: { type: "integer" },
                                        hidden_intent: { type: "string" }
                                    }
                                }
                            }
                        }
                    }
                });

                const webResults = result.results || [];
                const formatted = webResults.map((r, i) => ({
                    id: `web-${i}`,
                    name: r.title,
                    description: r.description,
                    type: 'external_signal',
                    icon: Globe,
                    url: r.url,
                    tags: [r.source, r.content_origin, `Score: ${r.quality_score}`],
                    content_origin: r.content_origin,
                    quality_score: r.quality_score,
                    hidden_intent: r.hidden_intent,
                    isExternal: true
                }));
                return {
                    all: formatted,
                    byType: {
                        external_signal: formatted,
                        content: formatted
                    }
                };
            }

            let searchTerms = [query.toLowerCase()];
            let intent = null;

            if (isSemanticMode) {
                try {
                    const expanded = await semanticExpansionMutation.mutateAsync(query);
                    if (expanded.keywords) {
                        searchTerms = [...searchTerms, ...expanded.keywords.map(k => k.toLowerCase())];
                    }
                    intent = expanded.intent;
                } catch (e) {
                    console.warn("Semantic expansion skipped", e);
                }
            }

            const [marketplaceItems, pages, customers, integrations, agents] = await Promise.all([
                base44.entities.MarketplaceItem.list(),
                base44.entities.ContentPage.list(),
                base44.entities.Customer.list(),
                base44.entities.Integration.list(),
                base44.entities.Agent.list()
            ]);

            const searchIn = (item, fields) => {
                return fields.some(f => {
                    const val = (item[f] || '').toLowerCase();
                    return searchTerms.some(term => val.includes(term));
                });
            };

            const matches = [
                ...marketplaceItems.filter(i => searchIn(i, ['name', 'description', 'category'])).map(i => ({ 
                    ...i, type: 'marketplace', icon: ShoppingBag, url: createPageUrl('Marketplace') + `?item=${i.id}`, tags: [i.category], image: null
                })),
                ...pages.filter(p => searchIn(p, ['title', 'slug', 'seo_description'])).map(p => ({ 
                    ...p, name: p.title, description: p.seo_description, type: 'content', icon: FileText, url: createPageUrl('ContentManager') + `?page=${p.id}`, tags: p.tags || [], image: p.featured_image
                })),
                ...customers.filter(c => searchIn(c, ['name', 'email', 'company'])).map(c => ({ 
                    ...c, type: 'crm', icon: Users, url: createPageUrl('CRM') + `?id=${c.id}`, tags: [c.status], image: c.avatar_url
                })),
                ...integrations.filter(i => searchIn(i, ['name', 'provider', 'category'])).map(i => ({ 
                    ...i, type: 'integration', icon: Zap, url: createPageUrl('Integrations'), tags: [i.category], image: i.icon_url
                })),
                ...agents.filter(a => searchIn(a, ['name', 'role', 'description'])).map(a => ({ 
                    ...a, type: 'agent', icon: Box, url: createPageUrl('Agents') + `?id=${a.id}`, tags: [a.role]
                }))
            ];

            return {
                all: matches,
                byType: {
                    marketplace: matches.filter(m => m.type === 'marketplace'),
                    content: matches.filter(m => m.type === 'content'),
                    crm: matches.filter(m => m.type === 'crm'),
                    integration: matches.filter(m => m.type === 'integration'),
                    agent: matches.filter(m => m.type === 'agent'),
                },
                intent
            };
        },
        enabled: !!query
    });

    const getFilteredResults = () => {
        if (!results) return [];
        const baseResults = activeTab === 'all' ? results.all : (results.byType[activeTab] || []);
        return baseResults.filter(item => !dismissedIds.has(item.id));
    };

    const filteredQueue = getFilteredResults();
    const totalPages = Math.ceil(filteredQueue.length / PAGE_SIZE);
    const displayResults = filteredQueue.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

    const handleDismiss = (id) => {
        setDismissedIds(prev => new Set([...prev, id]));
        if (displayResults.length === 1 && page > 0) setPage(p => p - 1);
    };

    const handleToggleSelect = (id) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id); else next.add(id);
            return next;
        });
    };

    const handleOpenSelected = () => {
        const selectedItems = filteredQueue.filter(i => selectedIds.has(i.id));
        selectedItems.forEach(item => {
            if (item.url) window.open(item.url, '_blank');
        });
        awardXP(10 * selectedItems.length, 'Batch Processed Search Results');
        setSelectedIds(new Set());
    };

    return (
        <div className="h-full w-full bg-transparent text-[hsl(var(--fg-intent))] flex flex-col overflow-hidden relative font-sans selection:bg-[hsl(var(--color-intent))]/30 transition-colors duration-500 transform-gpu">
             <SearchBackground />

             <div className="flex-1 overflow-hidden relative z-10 w-full">
                 <FluidGrid 
                    left={
                        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                            <Quadrant type="orientation" step="1" title="Context" className="border-b">
                                <div className="p-4 border-b border-white/5 bg-neutral-900/30">
                                    <OrientingText className="mb-2">SEARCH QUERY</OrientingText>
                                    <Input 
                                        id="hero-search-input"
                                        placeholder="Search..." 
                                        value={query} 
                                        onChange={(e) => setQuery(e.target.value)}
                                        className="bg-black/50 border-white/10"
                                    />
                                    <div className="flex gap-2 mt-2">
                                        <SearchEngineSelector engine={engine} setEngine={setEngine} />
                                        <ZipperTrigger active={isSemanticMode} onToggle={() => setIsSemanticMode(!isSemanticMode)} />
                                    </div>
                                </div>
                                <SearchContextSidebar query={query} results={results} compact={true} />
                            </Quadrant>
                            <Quadrant type="state" step="3" title="Metrics" className="border-t-0 rounded-t-none">
                                <div className="space-y-4">
                                     <div className="flex items-center gap-2 text-xs font-bold text-[hsl(var(--fg-orientation))] uppercase tracking-widest">
                                         <Activity className="w-4 h-4" />
                                         <span>Live Analysis</span>
                                     </div>
                                     <BSMeter query={query} results={displayResults} />
                                 </div>
                            </Quadrant>
                        </QuadrantGrid>
                    }
                    right={
                        <QuadrantGrid className="p-0 h-full gap-0">
                            <Quadrant type="intent" dominance="dominant" step="2" title="Feed" className="h-full flex flex-col border-none bg-transparent">
                                <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-[hsl(var(--color-intent))]/20 p-6 pb-32">
                                    {/* Search Refinement Widget */}
                                    {searchHistory.length >= 5 && (
                                         <div className="mb-8 p-6 rounded-xl bg-gradient-to-r from-[hsl(var(--color-intent))]/10 to-transparent border border-[hsl(var(--color-intent))]/20 animate-in slide-in-from-top-4">
                                            <div className="flex items-center justify-between">
                                                <div className="space-y-1">
                                                    <h3 className="text-lg font-medium text-[hsl(var(--color-intent))]">Search Session Saturation Reached</h3>
                                                    <p className="text-sm text-neutral-400">You've performed {searchHistory.length} refined searches. The system has enough signal to construct a strategy.</p>
                                                </div>
                                                <Link to={createPageUrl('Roadmap') + `?context=${encodeURIComponent(searchHistory.join(', '))}`}>
                                                    <Button className="bg-[hsl(var(--color-intent))] text-black font-bold">
                                                        <Layers className="w-4 h-4 mr-2" />
                                                        Synthesize Roadmap
                                                    </Button>
                                                </Link>
                                            </div>
                                         </div>
                                    )}

                                    {query && displayResults.length === 0 && !isLoading ? (
                                            <NullResult 
                                                query={query} 
                                                scope={searchScope} 
                                                onExpandSearch={() => setSearchScope('web')} 
                                            />
                                        ) : (
                                            <div className="animate-in fade-in slide-in-from-bottom-8 duration-700 space-y-8">
                                                <div className="flex flex-wrap items-center gap-4 md:gap-8 text-[10px] font-mono text-neutral-500 border-b border-white/5 pb-4 mb-8 select-none uppercase tracking-wider">
                                                    <div className="flex items-center gap-2 text-emerald-500/80"><Shield className="w-3 h-3" /><span>Bot Filters: Active</span></div>
                                                    <div className="flex items-center gap-2 text-blue-500/80"><Zap className="w-3 h-3" /><span>AI Analysis: Deep</span></div>
                                                    <div className="hidden md:flex ml-auto opacity-50 items-center gap-2"><Activity className="w-3 h-3" /><span>Latency: {(Math.random() * 0.5).toFixed(3)}ms</span></div>
                                                </div>

                                                {isSemanticMode ? (
                                                    <SemanticStackView results={displayResults} query={query} type={activeTab} />
                                                ) : (
                                                    <>
                                                        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 relative">
                                                            {displayResults.map((item, idx) => (
                                                                <MagazineResult 
                                                                    key={item.id} 
                                                                    item={{...item, selected: selectedIds.has(item.id), onSelect: handleToggleSelect, onDismiss: handleDismiss}} 
                                                                    index={(page * PAGE_SIZE) + idx} 
                                                                />
                                                            ))}
                                                        </div>

                                                        {filteredQueue.length > 0 && (
                                                            <div className="sticky bottom-6 z-40 mt-8">
                                                                <div className="bg-neutral-900/90 backdrop-blur-md border border-white/10 rounded-2xl p-4 shadow-2xl flex items-center justify-between gap-6 max-w-2xl mx-auto">
                                                                    {selectedIds.size > 0 ? (
                                                                        <div className="flex items-center gap-4 animate-in fade-in slide-in-from-bottom-2">
                                                                            <span className="text-xs font-mono font-bold text-[hsl(var(--color-intent))]">{selectedIds.size} SELECTED</span>
                                                                            <div className="h-4 w-px bg-white/10" />
                                                                            <Button size="sm" onClick={handleOpenSelected} className="h-8 bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90">Open Selected</Button>
                                                                            <Button size="sm" variant="ghost" onClick={() => setSelectedIds(new Set())} className="h-8 text-neutral-400 hover:text-white">Clear</Button>
                                                                        </div>
                                                                    ) : (
                                                                        <div className="flex items-center gap-2 text-xs text-neutral-500 font-mono">
                                                                            <span>STACK: {page + 1} / {Math.max(1, totalPages)}</span>
                                                                            <span className="opacity-30">•</span>
                                                                            <span>{filteredQueue.length} ITEMS QUEUED</span>
                                                                        </div>
                                                                    )}

                                                                    <div className="flex items-center gap-2 ml-auto">
                                                                        <Button variant="ghost" size="icon" onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="h-8 w-8 rounded-full"><ArrowRight className="w-4 h-4 rotate-180" /></Button>
                                                                        <div className="flex gap-1">
                                                                            {Array.from({ length: Math.min(5, totalPages) }).map((_, i) => (
                                                                                <button key={i} onClick={() => setPage(i)} className={cn("w-2 h-2 rounded-full transition-all", page === i ? "bg-[hsl(var(--color-intent))] scale-125" : "bg-white/10 hover:bg-white/30")} />
                                                                            ))}
                                                                        </div>
                                                                        <Button variant="ghost" size="icon" onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={page >= totalPages - 1} className="h-8 w-8 rounded-full"><ArrowRight className="w-4 h-4" /></Button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )}
                                                    </>
                                                )}
                                            </div>
                                        )
                                    }
                                </div>
                            </Quadrant>
                        </QuadrantGrid>
                    }
                 />
             </div>
       </div>
    );
}