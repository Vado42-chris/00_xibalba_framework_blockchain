import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    User, Settings, Bell, Shield, Activity, 
    Award, Clock, Brain, Check, BarChart3,
    Sparkles
} from 'lucide-react';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, 
    SemanticDot, AtomicParagraph, Layer 
} from '@/components/ui/design-system/System';
import { InsightTip } from '@/components/ui/design-system/Curiosity';
import ThemeManager from '@/components/identity/ThemeManager';
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { FluidGrid } from '@/components/ui/FluidGrid';

export default function UserProfile() {
  const [notifications, setNotifications] = useState({
    email: true,
    push: false,
    system: true
  });

  const { data: rewards } = useQuery({
    queryKey: ['rewards'],
    queryFn: () => base44.entities.Reward.list(),
    initialData: []
  });

  const { data: events } = useQuery({
    queryKey: ['user_activity'],
    queryFn: () => base44.entities.TimelineEvent.list(),
    initialData: []
  });

  return (
    <div className="h-full bg-transparent overflow-hidden">
       <FluidGrid
          left={
             <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                {/* Q1: ORIENTATION (Top-Left) */}
                <Quadrant type="orientation" className="border-b">
                   <div className="flex justify-between items-end mb-6">
                      <div>
                         <div className="flex items-center gap-2 mb-2">
                            <User className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                            <OrientingText className="tracking-widest font-bold">USER PROFILE</OrientingText>
                         </div>
                         <IntentText className="text-2xl font-light">Preferences & Context</IntentText>
                      </div>
                   </div>

                   <div className="flex items-center gap-4 mb-6">
                      <div className="w-12 h-12 rounded-full bg-neutral-900 border border-white/5 flex items-center justify-center text-lg font-bold text-[hsl(var(--color-active))] shadow-[0_0_15px_rgba(0,0,0,0.5)]">
                         U1
                      </div>
                      <div>
                         <IntentText className="text-lg font-bold">User-01</IntentText>
                         <StateText className="opacity-70">admin@xi-io.net</StateText>
                         <div className="flex items-center gap-2 mt-1">
                            <SemanticDot type="active" />
                            <StateText className="text-[10px]">ACTIVE SESSION</StateText>
                         </div>
                      </div>
                   </div>

                   <div className="space-y-4">
                      <div className="p-3 rounded bg-neutral-900/30 border border-white/5">
                         <OrientingText className="mb-1">TRUST SCORE</OrientingText>
                         <div className="flex items-end gap-2">
                            <span className="text-2xl font-mono font-bold text-[hsl(var(--color-execution))]">98.4</span>
                            <span className="text-xs text-neutral-500 mb-1">/ 100</span>
                         </div>
                      </div>
                      
                      <Link to={createPageUrl('Setup')} className="block">
                          <Button size="sm" variant="outline" className="w-full text-xs h-8 border-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/10">
                              <Sparkles className="w-3 h-3 mr-2" />
                              Launch Setup Wizard
                          </Button>
                      </Link>
                   </div>
                </Quadrant>

                {/* Q3: ACTIVITY LOGS (Bottom-Left) */}
                <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                   <div className="flex items-center justify-between mb-4">
                      <OrientingText>RECENT TRACES</OrientingText>
                      <Link to={createPageUrl('Audit')}>
                         <Button variant="ghost" size="sm" className="h-6 text-[10px] text-neutral-500 hover:text-white">VIEW ALL</Button>
                      </Link>
                   </div>

                   <div className="space-y-2 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/5 h-full">
                      {events.length > 0 ? events.slice(0, 10).map((event, i) => (
                         <div key={i} className="flex gap-3 items-start p-2 hover:bg-neutral-900/50 rounded transition-colors text-xs border-l-2 border-transparent hover:border-[hsl(var(--color-intent))]">
                            <StateText className="font-mono text-[10px] opacity-50 w-20 shrink-0">
                               {new Date(event.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </StateText>
                            <div className="flex-1">
                               <StateText className="text-white">{event.text}</StateText>
                            </div>
                         </div>
                      )) : (
                         <div className="text-center py-8 opacity-30">
                            <Activity className="w-8 h-8 mx-auto mb-2" />
                            <StateText>No traces found in this timeline.</StateText>
                         </div>
                      )}
                   </div>
                </Quadrant>
             </QuadrantGrid>
          }
          right={
             <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[2fr_1fr]">
                {/* Q2: PREFERENCES (Top-Right - Dominant) */}
                <Quadrant type="intent" dominance="dominant" className="border-b overflow-y-auto">
                   <div className="flex items-center gap-2 mb-6">
                      <Settings className="w-4 h-4 text-neutral-500" />
                      <OrientingText>SYSTEM CONFIGURATION</OrientingText>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Theme Section */}
                      <div className="space-y-4">
                         <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                            <Shield className="w-3 h-3" />
                            <StateText className="font-bold">VISUAL MATRIX</StateText>
                         </div>
                         <ThemeManager />
                      </div>

                      {/* Notifications Section */}
                      <div className="space-y-6">
                         <div className="flex items-center gap-2 pb-2 border-b border-white/5">
                            <Bell className="w-3 h-3" />
                            <StateText className="font-bold">SIGNALS & INTERRUPTS</StateText>
                         </div>
                         
                         <div className="space-y-4">
                            {[
                               { id: 'email', label: 'Email Digest', desc: 'Daily summary of system entropy.' },
                               { id: 'push', label: 'Push Interrupts', desc: 'Real-time alerts. High cognitive load.' },
                               { id: 'system', label: 'System Pings', desc: 'Subtle audio cues for background tasks.' }
                            ].map(setting => (
                               <div key={setting.id} className="flex items-start justify-between">
                                  <div className="space-y-0.5">
                                     <StateText className="text-sm font-medium">{setting.label}</StateText>
                                     <StateText className="text-[10px] opacity-50">{setting.desc}</StateText>
                                  </div>
                                  <Switch 
                                     checked={notifications[setting.id]}
                                     onCheckedChange={(c) => setNotifications(prev => ({...prev, [setting.id]: c}))}
                                  />
                               </div>
                            ))}
                         </div>
                      </div>
                   </div>
                </Quadrant>

                {/* Q4: REWARDS (Bottom-Right) */}
                <Quadrant type="state" className="border-t-0 rounded-t-none">
                   <div className="flex items-center gap-2 mb-4">
                      <Award className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                      <OrientingText>PATIENCE & LEARNING</OrientingText>
                   </div>

                   <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="p-3 bg-neutral-900/30 rounded border border-white/5 text-center">
                         <Clock className="w-4 h-4 mx-auto mb-2 text-[hsl(var(--color-execution))]" />
                         <StateText className="text-2xl font-bold">4.2m</StateText>
                         <OrientingText className="text-[9px]">TIME SAVED</OrientingText>
                      </div>
                      <div className="p-3 bg-neutral-900/30 rounded border border-white/5 text-center">
                         <Brain className="w-4 h-4 mx-auto mb-2 text-[hsl(var(--color-intent))]" />
                         <StateText className="text-2xl font-bold">{rewards.length}</StateText>
                         <OrientingText className="text-[9px]">INSIGHTS GAINED</OrientingText>
                      </div>
                   </div>

                   <div className="space-y-2 overflow-y-auto max-h-[120px] pr-2 scrollbar-thin scrollbar-thumb-white/5">
                      {rewards.map((reward, i) => (
                         <div key={i} className="flex items-center gap-3 p-2 bg-neutral-900 border border-white/5 rounded">
                            <Check className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                            <div>
                               <StateText className="font-bold text-xs">{reward.title}</StateText>
                               <OrientingText className="text-[9px] opacity-70">{reward.description}</OrientingText>
                            </div>
                         </div>
                      ))}
                      {rewards.length === 0 && (
                          <div className="p-4 text-center opacity-40 text-xs text-neutral-500">
                              Interact with the system to earn rewards.
                          </div>
                      )}
                   </div>
                </Quadrant>
             </QuadrantGrid>
          }
       />
    </div>
  );
}