import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, ArrowRight, Download, Mail } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { OrientingText, IntentText } from '@/components/ui/design-system/SystemDesign';

export default function PaymentConfirmation() {
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session_id');

    // In a real implementation, we would verify the session ID with the backend
    // to confirm the payment was successful and get the customer details.
    // For now, we'll assume success if they land here.

    return (
        <div className="min-h-screen bg-black text-white flex items-center justify-center p-6 relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(79,70,229,0.1),transparent_70%)]" />
            
            <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative z-10 max-w-lg w-full bg-neutral-900/50 backdrop-blur-xl border border-white/10 rounded-2xl p-8 text-center"
            >
                <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-10 h-10 text-green-500" />
                </div>
                
                <OrientingText className="mb-2 text-green-400">PAYMENT SUCCESSFUL</OrientingText>
                <h1 className="text-3xl font-bold mb-4">Welcome to Xibalba</h1>
                <p className="text-neutral-400 mb-8">
                    Your subscription has been activated. You now have full access to the Command Center.
                    A receipt has been sent to your email.
                </p>
                
                <div className="bg-white/5 rounded-lg p-4 mb-8 text-left">
                    <div className="flex items-center gap-3 mb-2">
                        <Mail className="w-4 h-4 text-neutral-500" />
                        <span className="text-sm text-neutral-300">Check your inbox for onboarding instructions</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <Download className="w-4 h-4 text-neutral-500" />
                        <span className="text-sm text-neutral-300">Download the Desktop App (Optional)</span>
                    </div>
                </div>
                
                <div className="space-y-3">
                    <Link to={createPageUrl('Dashboard')}>
                        <Button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white h-12 text-base">
                            Enter Command Center <ArrowRight className="ml-2 w-4 h-4" />
                        </Button>
                    </Link>
                    <Link to={createPageUrl('Home')}>
                        <Button variant="ghost" className="w-full text-neutral-400 hover:text-white">
                            Return to Home
                        </Button>
                    </Link>
                </div>
            </motion.div>
        </div>
    );
}