import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Terminal, Activity, Wifi } from 'lucide-react';
import ProductIcon from '@/components/brand/ProductIcon';

// Editors
import ChatInterface from '@/components/studio/editors/code/ChatInterface';
import WYSIWYGPreview from '@/components/studio/editors/code/WYSIWYGPreview';
import AgentOrchestrator from '@/components/studio/editors/code/AgentOrchestrator';
import CodeArchitect from '@/components/studio/editors/CodeArchitect';
import ThreeDEditor from '@/components/studio/editors/ThreeDEditor';
import VideoEditor from '@/components/studio/editors/VideoEditor';
import DocumentEditor from '@/components/studio/editors/DocumentEditor';
import MobileAppEditor from '@/components/studio/editors/MobileAppEditor';
import SoundEditor from '@/components/studio/editors/SoundEditor';
import MagazineEditor from '@/components/studio/editors/MagazineEditor';
import SpreadsheetEditor from '@/components/studio/editors/SpreadsheetEditor';
import StoreEditor from '@/components/studio/editors/StoreEditor';
import BlogEditor from '@/components/studio/editors/BlogEditor';
import BrowserEditor from '@/components/studio/editors/BrowserEditor';
import DatabaseEditor from '@/components/studio/editors/DatabaseEditor';
import EmailDesigner from '@/components/studio/editors/EmailClient';
import UnifiedCanvas from '@/components/studio/UnifiedCanvas'; // Web Architect fallback

// Satellite shell for popped-out windows
export default function SatellitePage() {
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const type = params.get('type');
    const [connected, setConnected] = useState(false);
    const [syncedData, setSyncedData] = useState(null);

    useEffect(() => {
        // Listen for sync events from the WindowManager
        const handleUpdate = (e) => {
            setSyncedData(e.detail);
            setConnected(true);
        };

        window.addEventListener('satellite-update', handleUpdate);
        
        // Initial handshake visual delay
        setTimeout(() => setConnected(true), 1500);

        return () => window.removeEventListener('satellite-update', handleUpdate);
    }, []);

    const renderContent = () => {
        // Default file prop for editors
        const activeFile = syncedData?.file || { name: 'Untitled', type: type };

        switch (type) {
            // --- CORE PANELS ---
            case 'chat':
                return <ChatInterface selectedModel={syncedData?.model} activeFile={activeFile} windowed />;
            case 'preview':
                return <WYSIWYGPreview activeFile={activeFile} isDark={true} windowed />;
            case 'agents':
                return <AgentOrchestrator windowed />;
            case 'terminal':
                return (
                    <div className="h-full bg-black text-green-400 font-mono p-4 text-xs">
                        <div className="mb-4 text-neutral-500 border-b border-neutral-800 pb-2">
                            REMOTE TERMINAL SESSION // {params.get('id')}
                        </div>
                        <div>&gt; _</div>
                    </div>
                );

            // --- FULL PRODUCT SUITES ---
            case 'architect':
                return <CodeArchitect file={activeFile} windowed />;
            case 'web':
                // Web Architect usually needs UnifiedCanvas + Palette. 
                // For satellite, we'll render Canvas for now or a simplified shell.
                return <UnifiedCanvas items={[]} activeTool="select" scale={1} viewportWidth="100%" />;
            case 'mobile':
                return <MobileAppEditor file={activeFile} />;
            case 'document':
            case 'os': // Office Suite code
                return <DocumentEditor file={activeFile} />;
            case 'sheet':
            case 'og': // Office Grid code
                return <SpreadsheetEditor file={activeFile} />;
            case 'layout':
            case 'mp': // Magazine Pro code
                return <MagazineEditor file={activeFile} />;
            case 'sound':
            case 'al': // Audio Lab code
                return <SoundEditor file={activeFile} />;
            case 'video':
            case 'cn': // Cinema Node code
                return <VideoEditor file={activeFile} />;
            case '3d':
            case 'vf': // Voxel Forge code
                return <ThreeDEditor file={activeFile} />;
            case 'store':
            case 'sb':
                return <StoreEditor file={activeFile} />;
            case 'blog':
            case 'bs':
                return <BlogEditor file={activeFile} />;
            case 'browser':
            case 'bf':
                return <BrowserEditor file={activeFile} />;
            case 'database':
            case 'da':
                return <DatabaseEditor file={activeFile} />;
            case 'mail':
            case 'ms':
                return <EmailDesigner file={activeFile} />;
            
            // --- FALLBACK ---
            default:
                return (
                    <div className="flex-1 flex flex-col items-center justify-center p-8 text-neutral-500">
                        <ProductIcon id={type} size="xl" className="mb-4 opacity-50 grayscale" />
                        <h3 className="text-lg font-medium text-neutral-300">Desktop View Not Configured</h3>
                        <p className="text-xs mt-2">The module '{type}' does not have a dedicated satellite interface yet.</p>
                    </div>
                );
        }
    };

    const getIconId = () => {
        if (type === 'chat') return 'chat';
        if (type === 'preview') return 'web';
        if (type === 'agents') return 'agents';
        return type; // Usually matches product ID
    }

    return (
        <div className="h-screen w-screen bg-[#09090b] text-[#e4e4e7] overflow-hidden flex flex-col">
            {/* Satellite Header - Draggable Area */}
            <div className="h-10 bg-[#0c0c0e] border-b border-[#27272a] flex items-center justify-between px-3 select-none draggable app-region-drag">
                <div className="flex items-center gap-3">
                    <ProductIcon id={getIconId()} size="xs" />
                    <span className="text-[10px] font-bold uppercase tracking-wider text-[#71717a]">
                        Satellite Link: {type}
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-[9px] text-[#52525b] font-mono hidden sm:inline-block">
                        {connected ? 'LINK ESTABLISHED' : 'SEARCHING FOR CARRIER...'}
                    </span>
                    <Wifi className={`w-3 h-3 ${connected ? 'text-green-500' : 'text-red-500 animate-pulse'}`} />
                </div>
            </div>

            {/* Content Content */}
            <div className="flex-1 overflow-hidden relative">
                {!connected && (
                    <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 backdrop-blur-sm transition-opacity duration-500 pointer-events-none">
                        <div className="flex flex-col items-center gap-4">
                            <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                            <span className="text-xs text-blue-400 font-mono">Syncing State...</span>
                        </div>
                    </div>
                )}
                {renderContent()}
            </div>
        </div>
    );
}