import React, { useState } from 'react';
import { 
  Monitor, Sidebar, Brain, Terminal, History, 
  Play, CheckCircle, Coffee, Moon, Sun, Clock
} from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText 
} from '@/components/ui/design-system/System';

export default function DesktopExperience() {
  const [phase, setPhase] = useState(0);

  const timeline = [
    {
      id: "morning",
      time: "09:00",
      label: "Morning: Re-entry",
      icon: Sun,
      desc: "User opens the lid. The room persisted. Same files, same state. Trust is established immediately.",
      active: ["structure", "work"],
      focus: "work",
      quote: "The room persisted without you."
    },
    {
      id: "mid-morning",
      time: "10:30",
      label: "Mid-Morning: Focused Work",
      icon: Coffee,
      desc: "Deep work in the Editor. Structure is referenced, Intelligence is dormant. The system feels inert.",
      active: ["structure", "work"],
      focus: "work",
      quote: "AI is not helping. AI is waiting."
    },
    {
      id: "noon",
      time: "12:00",
      label: "Noon: Intentional AI",
      icon: Brain,
      desc: "Explicit invocation. Intelligence Room opens. System slows down. Proposal, preview, no execution yet.",
      active: ["work", "intelligence"],
      focus: "intelligence",
      quote: "AI is visible but powerless."
    },
    {
      id: "afternoon",
      time: "14:00",
      label: "Early Afternoon: Execution",
      icon: Play,
      desc: "User confirms. Execution Room opens. Logs appear. Editor remains usable. 'Busy, but under control.'",
      active: ["work", "intelligence", "execution"],
      focus: "execution",
      quote: "Time becomes visible."
    },
    {
      id: "review",
      time: "16:00",
      label: "Late Afternoon: Review",
      icon: CheckCircle,
      desc: "Execution completes. Intelligence quiets. Work room resumes dominance. No dopamine, just continuity.",
      active: ["work", "history"],
      focus: "work",
      quote: "No celebration. No nags."
    },
    {
      id: "night",
      time: "18:00",
      label: "End of Day: Exit",
      icon: Moon,
      desc: "User closes laptop. No save dialogs. No summary. The room never closes.",
      active: ["work", "structure"],
      focus: "work",
      quote: "I always knew where I was."
    }
  ];

  const currentPhase = timeline[phase];

  const getRoomStyle = (room) => {
    const isActive = currentPhase.active.includes(room);
    const isFocus = currentPhase.focus === room;
    
    if (isFocus) return "border-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))] shadow-[0_0_15px_hsl(var(--color-execution))_30]";
    if (isActive) return "border-white/5 bg-neutral-900 text-[hsl(var(--color-intent))]";
    return "border-white/5 bg-neutral-900/50 text-neutral-500 opacity-50";
  };

  return (
    <div className="h-full w-full bg-transparent overflow-hidden">
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="orientation" className="border-b">
                        <div className="flex justify-between items-end mb-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <Clock className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">TEMPORAL FLOW</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Experience Timeline</IntentText>
                            </div>
                        </div>
                    </Quadrant>

                    <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                        <OrientingText className="mb-4">CHRONOLOGY</OrientingText>
                        <div className="space-y-2">
                            {timeline.map((step, idx) => (
                                <button
                                    key={step.id}
                                    onClick={() => setPhase(idx)}
                                    className={`w-full flex items-center gap-3 p-2 rounded border transition-all text-left ${
                                        phase === idx 
                                        ? 'bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))]' 
                                        : 'bg-neutral-900/30 border-white/5 text-neutral-500 hover:text-white'
                                    }`}
                                >
                                    <step.icon className="w-4 h-4 shrink-0" />
                                    <div className="flex-1 min-w-0">
                                        <StateText className="font-bold text-xs truncate">{step.label}</StateText>
                                    </div>
                                    {phase === idx && <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))]" />}
                                </button>
                            ))}
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                        <div className="p-8">
                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                                
                                {/* The Desktop Simulation */}
                                <div className="lg:col-span-2 aspect-video bg-neutral-950 rounded-xl border border-white/5 p-4 relative flex flex-col gap-2 shadow-2xl">
                                    <div className="absolute top-2 left-4 text-[10px] font-mono text-neutral-500 uppercase tracking-widest">
                                        Simulated Viewport
                                    </div>
                                    
                                    <div className="flex-1 flex gap-2 min-h-0 pt-6">
                                        {/* Structure Room (Left) */}
                                        <div className={`w-1/4 rounded border p-3 flex flex-col gap-2 transition-all duration-500 ${getRoomStyle('structure')}`}>
                                        <div className="flex items-center gap-2 mb-2">
                                            <Sidebar className="w-4 h-4" />
                                            <span className="text-xs font-bold uppercase tracking-wider">Structure</span>
                                        </div>
                                        <div className="space-y-1.5 opacity-50">
                                            <div className="h-1.5 w-1/2 bg-current rounded-full" />
                                            <div className="h-1.5 w-3/4 bg-current rounded-full" />
                                            <div className="h-1.5 w-2/3 bg-current rounded-full" />
                                        </div>
                                        </div>

                                        {/* Work Room (Center - Dominant) */}
                                        <div className={`flex-1 rounded border p-4 flex flex-col relative transition-all duration-500 ${getRoomStyle('work')}`}>
                                        <div className="flex items-center gap-2 mb-4">
                                            <Monitor className="w-4 h-4" />
                                            <span className="text-xs font-bold uppercase tracking-wider">Work Room</span>
                                        </div>
                                        <div className="space-y-3 opacity-70 font-mono text-xs">
                                            <div className="flex gap-2">
                                            <span className="text-[hsl(var(--color-execution))]/50">const</span>
                                            <span>room = new Room();</span>
                                            </div>
                                            <div className="flex gap-2">
                                            <span className="text-[hsl(var(--color-execution))]/50">await</span>
                                            <span>room.initialize();</span>
                                            </div>
                                            <div className="h-3 w-1 bg-[hsl(var(--color-execution))]/50 animate-pulse" />
                                        </div>

                                        {/* History Lens Overlay */}
                                        {currentPhase.active.includes('history') && (
                                            <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-[2px] flex items-center justify-center border border-white/5 m-2 rounded">
                                            <div className="flex flex-col items-center gap-2 text-neutral-500">
                                                <History className="w-8 h-8" />
                                                <span className="text-xs font-mono uppercase tracking-widest">Temporal Lens Active</span>
                                            </div>
                                            </div>
                                        )}
                                        </div>

                                        {/* Intelligence Room (Right) */}
                                        <div className={`w-1/3 rounded border p-3 flex flex-col gap-2 transition-all duration-500 ${getRoomStyle('intelligence')}`}>
                                        <div className="flex items-center gap-2 mb-2">
                                            <Brain className="w-4 h-4" />
                                            <span className="text-xs font-bold uppercase tracking-wider">Intelligence</span>
                                        </div>
                                        {currentPhase.active.includes('intelligence') ? (
                                            <div className="space-y-2">
                                            <div className="p-2 bg-black/20 rounded border border-white/5 text-[10px] font-mono leading-relaxed">
                                                Proposal: Refactor auth module to use strict Types.
                                            </div>
                                            <div className="h-1.5 w-1/2 bg-[hsl(var(--color-intent))]/50 rounded-full" />
                                            </div>
                                        ) : (
                                            <div className="flex-1 flex items-center justify-center opacity-30">
                                            <div className="w-1 h-1 bg-current rounded-full" />
                                            </div>
                                        )}
                                        </div>
                                    </div>

                                    {/* Execution Room (Bottom) */}
                                    <div className={`h-1/4 rounded border p-3 flex flex-col gap-2 transition-all duration-500 ${getRoomStyle('execution')}`}>
                                        <div className="flex items-center gap-2">
                                            <Terminal className="w-3 h-3" />
                                            <span className="text-[10px] font-bold uppercase tracking-wider">Execution</span>
                                        </div>
                                        {currentPhase.active.includes('execution') && (
                                        <div className="font-mono text-[10px] space-y-1 opacity-70">
                                            <div>&gt; Compiling modules...</div>
                                            <div>&gt; Verifying signatures... OK</div>
                                        </div>
                                        )}
                                    </div>
                                </div>

                                {/* Narrative Panel */}
                                <div className="flex flex-col justify-center space-y-6">
                                    <div className="space-y-2">
                                        <div className="flex items-center gap-3 text-[hsl(var(--color-execution))]">
                                        <currentPhase.icon className="w-6 h-6" />
                                        <span className="font-mono text-sm">{currentPhase.time}</span>
                                        </div>
                                        <h2 className="text-xl font-bold text-[hsl(var(--fg-intent))]">{currentPhase.label}</h2>
                                    </div>

                                    <p className="text-[hsl(var(--fg-state))] leading-relaxed border-l-2 border-white/5 pl-4">
                                        {currentPhase.desc}
                                    </p>

                                    <div className="p-4 bg-neutral-900/50 rounded-lg border border-white/5 mt-4">
                                        <p className="text-[hsl(var(--color-execution))] font-mono text-xs italic">
                                        "{currentPhase.quote}"
                                        </p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    </div>
  );
}