import React from 'react';
import { 
  Monitor, Cpu, Brain, History, Shield, 
  Layout, Terminal, GitBranch 
} from 'lucide-react';
import { Card } from "@/components/ui/card";
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText 
} from '@/components/ui/design-system/System';

export default function DesktopRooms() {
  const rooms = [
    {
      id: "work",
      name: "The Work Room",
      role: "Inhabit & Create",
      icon: Monitor,
      desc: "The primary environment. Wide, quiet, stable.",
      contents: ["Editor Surface", "File Structure", "Context Dock"],
      behavior: "Nothing moves unless acted upon.",
      color: "text-[hsl(var(--color-intent))]",
      border: "border-[hsl(var(--color-orientation))]"
    },
    {
      id: "intelligence",
      name: "The Intelligence Room",
      role: "Reason & Propose",
      icon: Brain,
      desc: "Analysis and proposal generation. The 'Air Gap'.",
      contents: ["Agent Config", "Diff Previews", "Impact Summaries"],
      behavior: "Visibly constrained. Slower by design.",
      color: "text-[hsl(var(--color-intent))]",
      border: "border-[hsl(var(--color-intent))]/30"
    },
    {
      id: "execution",
      name: "The Execution Room",
      role: "Process & Automation",
      icon: Cpu,
      desc: "Where the system works without you.",
      contents: ["Running Tasks", "Queued Jobs", "Background Processes"],
      behavior: "Visible or it doesn't happen. No silent failures.",
      color: "text-[hsl(var(--color-execution))]",
      border: "border-[hsl(var(--color-execution))]/30"
    },
    {
      id: "history",
      name: "The History Room",
      role: "Audit & Time",
      icon: History,
      desc: "The timeline of truth. Removes fear.",
      contents: ["Action Timeline", "Undo Scopes", "Rollback Points"],
      behavior: "Read-only. Chronological. Boring.",
      color: "text-[hsl(var(--color-orientation))]",
      border: "border-[hsl(var(--color-orientation))]"
    },
    {
      id: "identity",
      name: "The Identity Room",
      role: "Trust & Policy",
      icon: Shield,
      desc: "The foundation of authority.",
      contents: ["Dotfile Identity", "Device Bindings", "Network Policy"],
      behavior: "Heavy. Serious. Explicit entry only.",
      color: "text-[hsl(var(--color-orientation))]",
      border: "border-[hsl(var(--color-orientation))]/30"
    }
  ];

  return (
    <div className="h-full w-full bg-transparent overflow-hidden">
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="orientation" className="border-b">
                        <div className="flex justify-between items-end mb-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <Monitor className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">TOPOLOGY</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Desktop Rooms</IntentText>
                            </div>
                        </div>
                        <StateText className="text-[hsl(var(--fg-orientation))] text-sm font-mono mt-4">
                            "Five distinct rooms, one coherent environment."
                        </StateText>
                    </Quadrant>

                    <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                        <OrientingText className="mb-4">ROOM INDEX</OrientingText>
                        <div className="space-y-2">
                            {rooms.map((room) => (
                                <div key={room.id} className="flex items-center gap-3 p-2 rounded bg-neutral-900/30 border border-white/5">
                                    <room.icon className={`w-4 h-4 ${room.color}`} />
                                    <div>
                                        <StateText className="font-bold">{room.name}</StateText>
                                        <OrientingText className="text-[9px]">{room.role}</OrientingText>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                        <div className="p-8">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                                {/* Work Room - Spans 2 cols on large screens to emphasize primacy */}
                                <Card className={`col-span-1 md:col-span-2 p-6 bg-neutral-900/50 border border-white/5 relative group overflow-hidden rounded-xl`}>
                                    <div className="absolute top-0 right-0 p-32 bg-white/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
                                    <div className="relative z-10">
                                        <div className="flex items-center gap-3 mb-4">
                                        <div className="p-2 rounded-md bg-neutral-950 border border-white/5 text-[hsl(var(--fg-intent))]">
                                            <Monitor className="w-5 h-5" />
                                        </div>
                                        <h3 className="text-lg font-bold text-[hsl(var(--fg-intent))]">The Work Room</h3>
                                        <span className="text-xs font-mono text-[hsl(var(--color-execution))] border border-[hsl(var(--color-execution))]/30 bg-[hsl(var(--color-execution))]/10 px-2 py-0.5 rounded-sm">PRIMARY</span>
                                        </div>
                                        
                                        <p className="text-[hsl(var(--fg-state))] mb-6 max-w-lg">
                                        The primary environment. Wide, quiet, stable. This is where creation happens. 
                                        Nothing moves unless acted upon.
                                        </p>

                                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                        <div className="p-3 rounded-md bg-neutral-950/50 border border-white/5">
                                            <div className="flex items-center gap-2 text-[hsl(var(--fg-intent))] mb-1 text-sm font-mono">
                                            <Layout className="w-4 h-4" /> Editor
                                            </div>
                                            <div className="text-xs text-[hsl(var(--fg-orientation))]">Dominant Surface</div>
                                        </div>
                                        <div className="p-3 rounded-md bg-neutral-950/50 border border-white/5">
                                            <div className="flex items-center gap-2 text-[hsl(var(--fg-intent))] mb-1 text-sm font-mono">
                                            <Terminal className="w-4 h-4" /> Structure
                                            </div>
                                            <div className="text-xs text-[hsl(var(--fg-orientation))]">File/Tree Context</div>
                                        </div>
                                        <div className="p-3 rounded-md bg-neutral-950/50 border border-white/5">
                                            <div className="flex items-center gap-2 text-[hsl(var(--fg-intent))] mb-1 text-sm font-mono">
                                            <GitBranch className="w-4 h-4" /> Context
                                            </div>
                                            <div className="text-xs text-[hsl(var(--fg-orientation))]">Automation Dock</div>
                                        </div>
                                        </div>
                                    </div>
                                </Card>

                                {/* Other Rooms */}
                                {rooms.slice(1).map((room) => (
                                <Card key={room.id} className={`p-6 bg-neutral-900/50 border ${room.border} hover:bg-neutral-900 transition-colors flex flex-col rounded-xl`}>
                                    <div className="flex items-center gap-3 mb-4">
                                    <div className={`p-2 rounded-md bg-neutral-950 border border-white/5 ${room.color}`}>
                                        <room.icon className="w-5 h-5" />
                                    </div>
                                    <h3 className={`text-sm font-bold ${room.color}`}>{room.name}</h3>
                                    </div>
                                    
                                    <p className="text-sm text-[hsl(var(--fg-state))] mb-4 flex-1">
                                    {room.desc}
                                    </p>

                                    <div className="space-y-4">
                                    <div>
                                        <div className="text-[10px] text-[hsl(var(--fg-orientation))] uppercase tracking-wider mb-2">Contains</div>
                                        <div className="space-y-1">
                                        {room.contents.map(c => (
                                            <div key={c} className="flex items-center gap-2 text-xs text-[hsl(var(--fg-intent))] font-mono">
                                            <span className="w-1 h-1 rounded-full bg-white/5" />
                                            {c}
                                            </div>
                                        ))}
                                        </div>
                                    </div>
                                    
                                    <div className="pt-3 border-t border-white/5">
                                        <div className="text-[10px] text-[hsl(var(--fg-orientation))] uppercase tracking-wider mb-1">Behavior</div>
                                        <div className="text-xs text-[hsl(var(--fg-state))] italic">"{room.behavior}"</div>
                                    </div>
                                    </div>
                                </Card>
                                ))}
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    </div>
  );
}