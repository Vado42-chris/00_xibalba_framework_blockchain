import React from 'react';
import { motion } from 'framer-motion';
import { 
    Globe, Shield, Lock, ArrowRight, Database, 
    Layout, Cpu, Users, Key, Server, Layers,
    GitBranch, Fingerprint, Network
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import DepthBackground from '@/components/ui/design-system/DepthBackground';
import { SiteHeader } from '@/components/site/SiteHeader';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Architecture() {
    return (
        <div className="min-h-screen bg-transparent text-neutral-200 font-sans selection:bg-emerald-500/30 overflow-hidden relative">
            <DepthBackground theme="emerald-500" />
            
            <SiteHeader mode="nav" />

            <div className="relative z-10 pt-32 pb-20 px-6 max-w-[1600px] mx-auto">
                
                {/* Header */}
                <div className="mb-20 text-center space-y-4">
                    <h1 className="text-4xl md:text-6xl font-bold font-serif text-white tracking-tight">System Architecture</h1>
                    <p className="text-neutral-400 max-w-2xl mx-auto text-lg">
                        The structural blueprint defining the separation and bridge between Public Gateway (Front-End) and Private Console (Back-End).
                    </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    
                    {/* PUBLIC ZONE (Front-End) */}
                    <div className="lg:col-span-4 space-y-6">
                        <ZoneHeader 
                            icon={Globe} 
                            title="Public Gateway" 
                            subtitle="Front-End / Unauthenticated"
                            color="text-blue-400"
                            borderColor="border-blue-500/30"
                        />
                        <div className="space-y-4">
                            <ArchCard 
                                title="Landing & Manifesto" 
                                path="/Home"
                                description="Public-facing brand narrative, mission statement, and teaser content."
                                tags={['SSR', 'Static', 'SEO Optimized']}
                            />
                            <ArchCard 
                                title="Xibalba Index" 
                                path="/SearchResults"
                                description="Public web search and limited semantic search capabilities."
                                tags={['LLM Integration', 'External APIs']}
                            />
                            <ArchCard 
                                title="Product Suites" 
                                path="/SovereignCloud"
                                description="Marketing pages for Enterprise, Network, and Cloud products."
                                tags={['Lead Gen', 'Info']}
                            />
                            <div className="p-4 rounded-xl border border-dashed border-white/10 bg-white/5 mt-8">
                                <h4 className="text-xs font-bold uppercase tracking-widest text-neutral-500 mb-2">Public Capabilities</h4>
                                <ul className="space-y-2 text-sm text-neutral-400">
                                    <li className="flex items-center gap-2"><Globe className="w-3 h-3" /> View Public Content</li>
                                    <li className="flex items-center gap-2"><SearchIcon className="w-3 h-3" /> Perform Web Searches</li>
                                    <li className="flex items-center gap-2"><Users className="w-3 h-3" /> Request Access / Waitlist</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    {/* THE BRIDGE (Handshake) */}
                    <div className="lg:col-span-4 relative flex flex-col items-center justify-center min-h-[600px]">
                         {/* Connection Lines */}
                         <div className="absolute top-1/2 left-0 w-full h-px border-t border-dashed border-white/20 -z-10 hidden lg:block" />
                         <div className="absolute top-0 bottom-0 left-1/2 w-px border-l border-dashed border-white/20 -z-10 hidden lg:block" />

                        <div className="space-y-12 w-full">
                            {/* Request Access */}
                            <div className="relative group">
                                <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-full opacity-50 group-hover:opacity-100 transition-opacity" />
                                <div className="relative bg-neutral-900 border border-emerald-500/50 p-6 rounded-2xl text-center space-y-4 shadow-2xl">
                                    <div className="w-12 h-12 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto border border-emerald-500/50">
                                        <Fingerprint className="w-6 h-6 text-emerald-500" />
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-bold text-white">The Handshake</h3>
                                        <p className="text-sm text-emerald-400 font-mono mt-1">Identity Verification Protocol</p>
                                    </div>
                                    <div className="text-xs text-neutral-400 space-y-2 text-left bg-black/50 p-4 rounded-lg font-mono">
                                        <div className="flex justify-between"><span>Step 1:</span> <span className="text-white">Request Access (Email)</span></div>
                                        <div className="flex justify-between"><span>Step 2:</span> <span className="text-white">Admin Approval</span></div>
                                        <div className="flex justify-between"><span>Step 3:</span> <span className="text-white">Token Provisioning</span></div>
                                        <div className="flex justify-between"><span>Step 4:</span> <span className="text-emerald-500">System Initialization</span></div>
                                    </div>
                                </div>
                            </div>

                            {/* Authentication Layer */}
                            <div className="bg-neutral-900 border border-white/10 p-6 rounded-xl space-y-4 relative overflow-hidden">
                                <div className="absolute top-0 left-0 w-1 h-full bg-yellow-500" />
                                <h4 className="font-bold text-white flex items-center gap-2">
                                    <Key className="w-4 h-4 text-yellow-500" />
                                    Auth Boundary
                                </h4>
                                <p className="text-sm text-neutral-400">
                                    Strict separation of concerns. No private data leaks to public gateway.
                                    Session tokens required for all "Private Core" routes.
                                </p>
                                <div className="flex gap-2">
                                    <span className="px-2 py-1 bg-yellow-500/10 text-yellow-500 text-[10px] font-bold rounded">JWT</span>
                                    <span className="px-2 py-1 bg-yellow-500/10 text-yellow-500 text-[10px] font-bold rounded">RBAC</span>
                                    <span className="px-2 py-1 bg-yellow-500/10 text-yellow-500 text-[10px] font-bold rounded">2FA</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* PRIVATE ZONE (Back-End) */}
                    <div className="lg:col-span-4 space-y-6">
                        <ZoneHeader 
                            icon={Lock} 
                            title="Private Console" 
                            subtitle="Back-End / Authenticated"
                            color="text-red-400"
                            borderColor="border-red-500/30"
                        />
                        <div className="space-y-4">
                             <div className="grid grid-cols-1 gap-4">
                                <ArchCard 
                                    title="Control Plane" 
                                    path="/Dashboard"
                                    description="System overview, notifications, and high-level metrics."
                                    tags={['React', 'Live Sockets']}
                                    isPrivate
                                />
                                <ArchCard 
                                    title="Operations" 
                                    path="/WorkRoom"
                                    description="Project management, Distro Builder, and Agent orchestration."
                                    tags={['CRUD', 'Write Access']}
                                    isPrivate
                                />
                                <ArchCard 
                                    title="Intelligence" 
                                    path="/Intelligence"
                                    description="Data synthesis, CRM, Finance, and Analytics dashboards."
                                    tags={['Sensitive Data']}
                                    isPrivate
                                />
                                 <ArchCard 
                                    title="Infrastructure" 
                                    path="/Nodes"
                                    description="Server management, node provisioning, and network topology."
                                    tags={['Root Access']}
                                    isPrivate
                                />
                             </div>

                             <div className="p-4 rounded-xl border border-dashed border-white/10 bg-white/5 mt-8">
                                <h4 className="text-xs font-bold uppercase tracking-widest text-neutral-500 mb-2">Operator Capabilities</h4>
                                <ul className="space-y-2 text-sm text-neutral-400">
                                    <li className="flex items-center gap-2"><Database className="w-3 h-3" /> Full Database Read/Write</li>
                                    <li className="flex items-center gap-2"><Cpu className="w-3 h-3" /> Deploy Agents & Nodes</li>
                                    <li className="flex items-center gap-2"><GitBranch className="w-3 h-3" /> System Configuration</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="mt-20 border-t border-white/10 pt-10">
                    <h3 className="text-2xl font-bold text-white mb-6">Data Flow & Security Model</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <SecurityCard 
                            title="Public Access"
                            description="Anonymous users can only access static content and perform proxied web searches via the LLM layer. No direct database access."
                            icon={Globe}
                            status="Open"
                            color="text-blue-400"
                        />
                        <SecurityCard 
                            title="The Airgap"
                            description="All sensitive entities (CRM, Finance, Nodes) are protected by Row Level Security (RLS) and require a valid session."
                            icon={Network}
                            status="Secure"
                            color="text-emerald-400"
                        />
                         <SecurityCard 
                            title="Service Role"
                            description="Background agents operate with elevated privileges via the Service Role key, bypassing RLS for automated maintenance."
                            icon={Server}
                            status="System Only"
                            color="text-purple-400"
                        />
                    </div>
                </div>

            </div>
        </div>
    );
}

function ZoneHeader({ icon: Icon, title, subtitle, color, borderColor }) {
    return (
        <div className={`flex items-center gap-4 pb-4 border-b ${borderColor}`}>
            <div className={`w-12 h-12 rounded-xl bg-neutral-900 border border-white/10 flex items-center justify-center ${color}`}>
                <Icon className="w-6 h-6" />
            </div>
            <div>
                <h2 className="text-2xl font-bold text-white">{title}</h2>
                <p className="text-sm font-mono opacity-60 uppercase tracking-widest">{subtitle}</p>
            </div>
        </div>
    );
}

function ArchCard({ title, description, tags, path, isPrivate }) {
    return (
        <Link to={createPageUrl(path.replace('/', ''))} className="block group">
            <div className="bg-neutral-900/50 hover:bg-neutral-800 border border-white/5 hover:border-white/20 p-5 rounded-xl transition-all duration-300">
                <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-white group-hover:text-[hsl(var(--color-intent))] transition-colors flex items-center gap-2">
                        {isPrivate && <Lock className="w-3 h-3 text-neutral-500" />}
                        {title}
                    </h3>
                    <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
                </div>
                <p className="text-sm text-neutral-400 mb-4">{description}</p>
                <div className="flex flex-wrap gap-2">
                    {tags.map(tag => (
                        <span key={tag} className="px-2 py-0.5 bg-white/5 rounded text-[10px] font-mono text-neutral-500 uppercase">
                            {tag}
                        </span>
                    ))}
                </div>
            </div>
        </Link>
    );
}

function SecurityCard({ title, description, icon: Icon, status, color }) {
    return (
        <div className="bg-neutral-900 border border-white/5 p-6 rounded-xl">
            <div className="flex justify-between items-start mb-4">
                <div className={`p-2 rounded bg-white/5 ${color}`}>
                    <Icon className="w-5 h-5" />
                </div>
                <span className={`text-xs font-bold px-2 py-1 rounded bg-white/5 ${color}`}>{status}</span>
            </div>
            <h4 className="font-bold text-white mb-2">{title}</h4>
            <p className="text-sm text-neutral-400 leading-relaxed">{description}</p>
        </div>
    );
}

function SearchIcon(props) {
    return (
        <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.3-4.3" />
    </svg>
    )
}