import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, Plus, Shield, Settings, UserPlus, Megaphone } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function TeamHub() {
    const [teams, setTeams] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [newTeamName, setNewTeamName] = useState('');
    const [announcements, setAnnouncements] = useState([]);
    const [newAnnouncement, setNewAnnouncement] = useState('');
    const [isAnnouncementOpen, setIsAnnouncementOpen] = useState(false);

    useEffect(() => {
        fetchTeams();
        fetchAnnouncements();
    }, []);

    const fetchTeams = async () => {
        try {
            const data = await base44.entities.Team.list();
            setTeams(data);
        } catch (error) {
            console.error("Failed to fetch teams", error);
        } finally {
            setLoading(false);
        }
    };

    const fetchAnnouncements = async () => {
        try {
            const data = await base44.entities.TeamAnnouncement.list({ sort: { created_date: -1 }, limit: 5 });
            setAnnouncements(data);
        } catch (error) {
            // silent fail
        }
    };

    const handlePostAnnouncement = async () => {
        if (!newAnnouncement) return;
        try {
            const user = await base44.auth.me();
            const created = await base44.entities.TeamAnnouncement.create({
                content: newAnnouncement,
                author_id: user.id,
                author_name: user.full_name || 'Admin',
            });
            setAnnouncements([created, ...announcements]);
            setNewAnnouncement('');
            setIsAnnouncementOpen(false);
            toast.success("Announcement posted");
        } catch (error) {
            toast.error("Failed to post announcement");
        }
    };

    const handleCreateTeam = async () => {
        if (!newTeamName) return;
        try {
            const newTeam = await base44.entities.Team.create({
                name: newTeamName,
                description: "New team created via Team Hub",
                member_ids: [], // Logic to add current user would go here
                role_ids: []
            });
            setTeams([...teams, newTeam]);
            setIsCreateOpen(false);
            setNewTeamName('');
            toast.success("Team created successfully");
        } catch (error) {
            toast.error("Failed to create team");
        }
    };

    return (
        <div className="min-h-screen bg-black text-white p-8">
            <div className="max-w-6xl mx-auto space-y-8">
                <div className="flex justify-between items-center border-b border-white/10 pb-6">
                    <div>
                        <h1 className="text-3xl font-bold flex items-center gap-3">
                            <Users className="w-8 h-8 text-indigo-500" />
                            Team Hub
                        </h1>
                        <p className="text-neutral-400 mt-2">Manage teams, assign roles, and collaborate.</p>
                    </div>
                    <div className="flex gap-3">
                        <Dialog open={isAnnouncementOpen} onOpenChange={setIsAnnouncementOpen}>
                            <DialogTrigger asChild>
                                <Button variant="outline" className="border-white/10 text-white hover:bg-white/5">
                                    <Megaphone className="w-4 h-4 mr-2" /> Post Update
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-neutral-900 border-white/10 text-white">
                                <DialogHeader>
                                    <DialogTitle>Post Team Announcement</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4 py-4">
                                    <div className="space-y-2">
                                        <Input 
                                            value={newAnnouncement}
                                            onChange={(e) => setNewAnnouncement(e.target.value)}
                                            placeholder="What's the update?"
                                            className="bg-black/50 border-white/10"
                                        />
                                    </div>
                                    <Button onClick={handlePostAnnouncement} className="w-full bg-indigo-600 hover:bg-indigo-700">
                                        Post to Everyone
                                    </Button>
                                </div>
                            </DialogContent>
                        </Dialog>

                        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                            <DialogTrigger asChild>
                                <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                                    <Plus className="w-4 h-4 mr-2" /> Create Team
                                </Button>
                            </DialogTrigger>
                        <DialogContent className="bg-neutral-900 border-white/10 text-white">
                            <DialogHeader>
                                <DialogTitle>Create New Team</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4 py-4">
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Team Name</label>
                                    <Input 
                                        value={newTeamName}
                                        onChange={(e) => setNewTeamName(e.target.value)}
                                        placeholder="e.g. Marketing, Engineering..."
                                        className="bg-black/50 border-white/10"
                                    />
                                </div>
                                <Button onClick={handleCreateTeam} className="w-full bg-indigo-600 hover:bg-indigo-700">
                                    Create Team
                                </Button>
                            </div>
                        </DialogContent>
                    </Dialog>
                </div>
            </div>

                {/* Announcements Section */}
                {announcements.length > 0 && (
                    <div className="mb-8 p-6 bg-indigo-900/20 border border-indigo-500/20 rounded-xl">
                        <h2 className="text-sm font-bold text-indigo-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                            <Megaphone className="w-4 h-4" /> Latest Updates
                        </h2>
                        <div className="space-y-4">
                            {announcements.map((ann) => (
                                <div key={ann.id} className="flex gap-4 items-start border-b border-indigo-500/10 pb-4 last:border-0 last:pb-0">
                                    <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-bold text-xs shrink-0">
                                        {ann.author_name?.charAt(0)}
                                    </div>
                                    <div>
                                        <div className="flex items-center gap-2 mb-1">
                                            <span className="font-bold text-white">{ann.author_name}</span>
                                            <span className="text-xs text-indigo-300/50">• {new Date(ann.created_date).toLocaleDateString()}</span>
                                        </div>
                                        <p className="text-indigo-100/80 text-sm leading-relaxed">{ann.content}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {loading ? (
                        <div className="text-neutral-500 col-span-full text-center py-12">Loading teams...</div>
                    ) : teams.length === 0 ? (
                        <div className="text-neutral-500 col-span-full text-center py-12 border border-dashed border-white/10 rounded-xl">
                            <Users className="w-12 h-12 mx-auto mb-4 opacity-20" />
                            <p>No teams found. Create one to get started.</p>
                        </div>
                    ) : (
                        teams.map((team) => (
                            <Card key={team.id} className="bg-neutral-900/50 border-white/10 hover:border-indigo-500/30 transition-colors group">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <CardTitle className="text-xl font-bold">{team.name}</CardTitle>
                                        <Badge variant="outline" className="border-white/10 text-neutral-400">
                                            {(team.member_ids?.length || 0)} Members
                                        </Badge>
                                    </div>
                                    <CardDescription className="line-clamp-2">{team.description}</CardDescription>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        <div className="flex items-center gap-2 text-sm text-neutral-400">
                                            <Shield className="w-4 h-4 text-indigo-400" />
                                            <span>{(team.role_ids?.length || 0)} Roles Assigned</span>
                                        </div>
                                        <div className="flex gap-2 pt-2">
                                            <Button size="sm" variant="outline" className="flex-1 border-white/10 hover:bg-white/5">
                                                <Settings className="w-3 h-3 mr-2" /> Manage
                                            </Button>
                                            <Button size="sm" variant="secondary" className="bg-white/10 hover:bg-white/20 text-white">
                                                <UserPlus className="w-3 h-3" />
                                            </Button>
                                        </div>
                                    </div>
                                    
                                    {/* Mock Presence Indicator */}
                                    <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-neutral-500">
                                        <div className="flex -space-x-2">
                                            {[1,2,3].map(i => (
                                                <div key={i} className="w-6 h-6 rounded-full bg-neutral-800 border border-neutral-900 flex items-center justify-center text-[8px] text-white">
                                                    U{i}
                                                </div>
                                            ))}
                                        </div>
                                        <span className="flex items-center gap-1.5">
                                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                            2 Active
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
}