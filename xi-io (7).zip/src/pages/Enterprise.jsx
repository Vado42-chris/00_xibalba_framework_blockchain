import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { QuadrantGrid, Quadrant, OrientingText, IntentText } from '@/components/ui/design-system/System';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Building2, Box, AlertCircle, TrendingUp, DollarSign } from 'lucide-react';
import { BusinessPortfolioWidget } from '@/components/dashboards/widgets/BusinessPortfolioWidget';

import { useState } from 'react';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { Search } from 'lucide-react';
import { Input } from "@/components/ui/input";

export default function Enterprise() {
    const [selectedBusiness, setSelectedBusiness] = useState(null);
    const [filter, setFilter] = useState('');

    const { data: businesses = [] } = useQuery({
        queryKey: ['businesses'],
        queryFn: () => base44.entities.Business.list(),
        initialData: []
    });

    const { data: goals = [] } = useQuery({
        queryKey: ['business_goals'],
        queryFn: () => base44.entities.BusinessGoal.list(),
        initialData: []
    });

    const filteredBusinesses = businesses.filter(b => (b.name || '').toLowerCase().includes(filter.toLowerCase()));

    return (
        <div className="h-full w-full bg-transparent overflow-hidden flex flex-col">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Operations" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Building2 className="w-4 h-4 text-neutral-400" />
                                        <OrientingText className="tracking-widest font-bold">ENTERPRISE ERP</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Business Operations</IntentText>
                                </div>
                            </div>

                            <SystemStats 
                                className="grid-cols-1 gap-2"
                                stats={[
                                    { label: "Organizations", value: businesses.length || "0", icon: Building2 },
                                    { label: "Strategic Goals", value: goals.length || "0", icon: TrendingUp },
                                    { label: "Revenue YTD", value: "$4.2M", icon: DollarSign, color: "text-[hsl(var(--color-execution))]" }
                                ]}
                            />
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Portfolio" className="border-t-0 rounded-t-none flex flex-col">
                            <div className="mb-4 relative shrink-0 px-4 pt-4">
                                <Search className="absolute left-6 top-6.5 h-4 w-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search organizations..." 
                                    className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs"
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 p-2 overflow-y-auto scrollbar-thin scrollbar-thumb-white/5">
                                {filteredBusinesses.map((biz) => (
                                    <SystemCard
                                        key={biz.id}
                                        title={biz.name}
                                        subtitle={biz.industry || "Organization"}
                                        status={biz.status === 'active' ? 'active' : 'settled'}
                                        active={selectedBusiness?.id === biz.id}
                                        onClick={() => setSelectedBusiness(biz)}
                                        icon={Building2}
                                        metric={biz.employee_count ? `${biz.employee_count} FTE` : ''}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" step="2" title="Dashboard" dominance="dominant" className="h-full p-0 flex flex-col border-none">
                            {selectedBusiness ? (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300">
                                    <SystemDetailHeader
                                        title={selectedBusiness.name}
                                        subtitle={selectedBusiness.description || "No description"}
                                        category={selectedBusiness.industry?.toUpperCase() || "ENTERPRISE"}
                                        icon={Building2}
                                    />
                                    <div className="flex-1 p-4">
                                        <BusinessPortfolioWidget businessId={selectedBusiness.id} />
                                    </div>
                                </div>
                            ) : (
                                <div className="flex flex-col items-center justify-center h-full text-neutral-500 border border-dashed border-white/10 rounded-lg m-4">
                                    <Building2 className="w-16 h-16 mb-4 opacity-20" />
                                    <h3 className="text-lg text-white font-light tracking-widest">OPERATIONAL OVERVIEW</h3>
                                    <p className="text-[10px] font-mono opacity-50 uppercase mt-2">AWAITING SELECTION // TARGET REQUIRED</p>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}