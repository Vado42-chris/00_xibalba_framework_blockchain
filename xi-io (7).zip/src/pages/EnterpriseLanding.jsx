import React from 'react';
import PublicLayout from '@/components/layout/PublicLayout';
import { Button } from "@/components/ui/button";
import { Building2, ShieldCheck, Lock, Users, BarChart } from 'lucide-react';

export default function EnterpriseLanding() {
    return (
        <PublicLayout theme="amber-500">
            
            {/* HERO */}
            <section className="pt-32 pb-20 px-6 relative">
                <div className="max-w-7xl mx-auto text-center relative z-10">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] font-mono uppercase tracking-widest mb-8 backdrop-blur-md">
                        <Building2 className="w-3 h-3" />
                        <span>Mission Critical</span>
                    </div>
                    
                    <h1 className="text-5xl md:text-7xl font-serif font-light text-white mb-6 drop-shadow-2xl">
                        Sovereignty at <span className="italic text-amber-400">Scale</span>
                    </h1>
                    
                    <p className="text-xl text-neutral-300 max-w-2xl mx-auto leading-relaxed mb-12 font-light">
                        For organizations that cannot afford to rent their core infrastructure. 
                        Dedicated support, custom SLAs, and on-premise deployment assistance.
                    </p>

                    <Button className="h-12 px-8 bg-amber-500 text-black hover:bg-amber-600 rounded-full font-bold shadow-[0_0_20px_-5px_rgba(245,158,11,0.5)]">
                        Contact Sales
                    </Button>
                </div>
            </section>

            <section className="py-24 px-6">
                <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
                    <FeatureCard 
                        icon={ShieldCheck} 
                        title="Compliance Ready" 
                        desc="SOC2 Type II, HIPAA, and GDPR compliant architectures deployed to your private cloud." 
                    />
                    <FeatureCard 
                        icon={Lock} 
                        title="Air-Gapped Mode" 
                        desc="Run the entire stack without an internet connection for maximum security environments." 
                    />
                    <FeatureCard 
                        icon={Users} 
                        title="White-Glove Onboarding" 
                        desc="Our engineers work with your team to migrate data and configure agents for your specific workflows." 
                    />
                </div>
            </section>

        </PublicLayout>
    );
}

function FeatureCard({ icon: Icon, title, desc }) {
    return (
        <div className="p-8 rounded-2xl bg-black/40 border border-white/10 hover:border-amber-500/30 transition-colors backdrop-blur-xl shadow-lg">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center mb-6 text-amber-500">
                <Icon className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-light text-white mb-3">{title}</h3>
            <p className="text-sm text-neutral-400 leading-relaxed">{desc}</p>
        </div>
    );
}