import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
Signal, MessageSquare, Phone, Share2, 
Send, Inbox, BarChart, Plus, RefreshCw,
Search, Mail, Video
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { IntegrationStatus, ConnectPrompt } from '@/components/integrations/IntegrationComponents';
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import NewCampaignModal from '@/components/communications/NewCampaignModal';
import ComposeMessageModal from '@/components/communications/ComposeMessageModal';
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/SystemDesign';
import { SystemNav } from '@/components/ui/design-system/SystemComponents';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { cn } from '@/lib/utils';
import { AddonGate } from '@/components/integrations/AddonGate';
import NexusWidget from '@/components/addons/official/NexusWidget';

// View Components
import UnifiedInbox from '@/components/communications/UnifiedInbox';
import MarketingManager from '@/components/communications/MarketingManager';
import SocialManager from '@/components/communications/SocialManager';
import VoipView from '@/components/communications/VoipView';
import VideoCommandCenter from '@/components/communications/VideoCommandCenter';

export default function Communications() {
  const [activeTab, setActiveTab] = useState('inbox');
  const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [composeType, setComposeType] = useState('email');
  const [replyData, setReplyData] = useState(null);
  const [socialPosts, setSocialPosts] = useState([]);
  const [archivedIds, setArchivedIds] = useState([]);
  const [deletedIds, setDeletedIds] = useState([]);
  
  // Fetch Messages
  const { data: messages = [], refetch } = useQuery({
    queryKey: ['unified_inbox'],
    queryFn: async () => {
        let realLogs = [];
        try {
            if (base44.entities.Log) {
                const logs = await base44.entities.Log.list({ sort: { timestamp: -1 }, limit: 20 });
                realLogs = logs.map(log => ({
                    id: log.id,
                    source: 'SYSTEM',
                    client: log.remote_identity || "System",
                    subject: "System Alert",
                    time: new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                    snippet: log.content?.slice(0, 40) + "...",
                    full: log.content,
                    type: log.type.toUpperCase(),
                    status: log.status
                }));
            }
        } catch (e) {
            console.error("Failed to fetch logs:", e);
        }

        const mockEmails = [
            { id: 'm1', source: 'GMAIL', client: 'investor@vc.firm', subject: 'Series A Follow up', time: '09:42 AM', snippet: 'Just wanted to circle back on the pitch...', full: "Hi team,\n\nJust wanted to circle back on the pitch deck you sent over. The numbers look solid, but we have some questions about the AI integration layer.\n\nCan we schedule a call for Tuesday?\n\nBest,\nSarah", type: 'EMAIL', status: 'unread' },
            { id: 'm2', source: 'OUTLOOK', client: 'legal@corp.net', subject: 'Contract Review', time: '08:15 AM', snippet: 'Attached are the redlines for the...', full: "Please find attached the redlined contract. We need approval by EOD.", type: 'EMAIL', status: 'read' },
            { id: 'm3', source: 'LINKEDIN', client: 'Recruiter', subject: 'Opportunity', time: 'Yesterday', snippet: 'I saw your profile and...', full: "Hey, I saw your profile and thought you'd be a great fit for...", type: 'DM', status: 'unread' },
            { id: 'm4', source: 'TWITTER', client: '@tech_guru', subject: 'Mention', time: 'Yesterday', snippet: 'Mentioned you in a tweet', full: "Huge shoutout to @base44 for the new release! #tech #ai", type: 'SOCIAL', status: 'read' },
            { id: 'm5', source: 'SLACK', client: '#dev-ops', subject: 'Deployment Failed', time: '10:05 AM', snippet: 'Pipeline #442 failed at build step...', full: "Error: Build failed in step 'Install Dependencies'. See logs for details.", type: 'ALERT', status: 'unread' },
            { id: 'm6', source: 'DISCORD', client: 'Community Mod', subject: 'New Member Spike', time: '11:20 AM', snippet: 'We have 500 new members in general...', full: "Heads up, we got raided or featured somewhere. 500 new joins in 10 mins.", type: 'DM', status: 'read' },
            { id: 'm7', source: 'WHATSAPP', client: '+1 555-0199', subject: 'Lunch?', time: '12:00 PM', snippet: 'Are we still on for tacos?', full: "Hey, running 5 mins late but see you there.", type: 'CHAT', status: 'unread' }
        ];
        
        const dynamicMessages = (typeof window !== 'undefined' ? window.__simulatedMessages : []) || [];

        const allMessages = [...dynamicMessages, ...mockEmails, ...realLogs].sort((a,b) => {
             const getTime = (t) => {
                 if (t === 'Yesterday') return Date.now() - 86400000;
                 if (t.includes('AM') || t.includes('PM')) return new Date('1970/01/01 ' + t).getTime();
                 return new Date(t).getTime(); 
             };
             return (getTime(b.time) || 0) - (getTime(a.time) || 0);
        });

        return allMessages.filter(m => !archivedIds.includes(m.id) && !deletedIds.includes(m.id));
    },
    initialData: [] 
  });

  // Simulation Logic
  const simulateTraffic = () => {
      const newMsg = {
          id: `sim_${Date.now()}`,
          source: ['SLACK', 'DISCORD', 'GMAIL', 'WHATSAPP'][Math.floor(Math.random() * 4)],
          client: ['cto@startup.io', 'AlertBot', 'Mom', 'Customer Support'][Math.floor(Math.random() * 4)],
          subject: ['Urgent: Server Down', 'New Lead', 'Missed Call', 'Payment Received'][Math.floor(Math.random() * 4)],
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          snippet: 'Incoming transmission detected...',
          full: "This is a simulated incoming message to demonstrate real-time capabilities.",
          type: 'SIMULATION',
          status: 'unread'
      };
      
      window.__simulatedMessages = [newMsg, ...(window.__simulatedMessages || [])];
      refetch();
      toast.info(`New Message from ${newMsg.source}`);
  };

  // Fetch Campaigns
  const { data: campaigns } = useQuery({
    queryKey: ['campaigns'],
    queryFn: async () => {
        try {
            if (base44.entities.Campaign) {
                return await base44.entities.Campaign.list();
            }
            return [];
        } catch (e) {
            console.error("Failed to fetch campaigns", e);
            return [];
        }
    },
    initialData: []
  });

  // Reply Handler
  const handleReply = (msg) => {
    setComposeType('email');
    setReplyData(msg);
    setIsComposeOpen(true);
  };

  const handleDraft = (msg, type) => {
    let content = "";
    const name = msg.client.split(' ')[0] || 'there';
    
    if (type === 'professional') {
        content = `Hi ${name},\n\nThank you for your note regarding "${msg.subject}".\n\nWe have reviewed the details and would like to proceed with the next steps. Please let us know when you are available to discuss further.\n\nBest regards,\nBase44 System`;
    } else if (type === 'ack') {
        content = `Hi ${name},\n\nReceived, thanks. Will get back to you shortly.\n\nBest,`;
    }

    setComposeType('email');
    setReplyData({ ...msg, content });
    setIsComposeOpen(true);
    toast.success("AI Draft Generated");
  };

  const handleMessageSent = (data) => {
      if (data.channel === 'social') {
          const newPost = {
              id: `sp_${Date.now()}`,
              platform: data.recipient === 'all' ? 'System Broadcast' : data.recipient.charAt(0).toUpperCase() + data.recipient.slice(1),
              author: 'Me',
              content: data.content,
              stats: { comments: 0, reposts: 0, likes: 0, views: '0' }
          };
          setSocialPosts([newPost, ...socialPosts]);
      }
  };

  const handleArchive = (id) => {
      setArchivedIds(prev => [...prev, id]);
      toast.success("Message archived");
      refetch();
  };

  const handleDelete = (id) => {
      setDeletedIds(prev => [...prev, id]);
      toast.success("Message deleted");
      refetch();
  };

  const unreadCount = messages.filter(m => m.status === 'unread').length;

  return (
    <div className="h-full w-full bg-transparent overflow-hidden">
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="orientation" className="border-b">
                        <div className="flex justify-between items-end mb-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <Signal className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">COMMS MATRIX</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Unified Uplink</IntentText>
                            </div>
                            <Link to={createPageUrl('Marketplace') + '?category=communication'}>
                                <Button variant="ghost" size="sm" className="h-6 text-[10px] text-neutral-500 hover:text-white px-2">
                                    <Plus className="w-3 h-3 mr-1" /> Addon
                                </Button>
                            </Link>
                        </div>

                        <SystemStats 
                            className="grid-cols-2 mb-6"
                            stats={[
                                { label: "Unread", value: unreadCount, icon: Mail, color: "text-[hsl(var(--color-execution))]" },
                                { label: "Total", value: messages.length, icon: Inbox, color: "text-white" }
                            ]}
                        />

                        <div className="mb-6">
                            <ConnectPrompt category="communication" title="Link Channels" description="Connect Slack, Discord, or Email." />
                        </div>

                        <div className="flex gap-2">
                            <Button 
                                onClick={simulateTraffic} 
                                variant="outline" 
                                className="flex-1 border-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/10 h-8 text-xs font-bold"
                            >
                                <RefreshCw className="w-3 h-3 mr-2" /> SIMULATE
                            </Button>
                            <Button 
                                onClick={() => { setComposeType('email'); setIsComposeOpen(true); }}
                                className="flex-1 bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 h-8 text-xs font-bold"
                            >
                                <Plus className="w-3 h-3 mr-2" /> COMPOSE
                            </Button>
                        </div>
                    </Quadrant>

                    <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                        <OrientingText className="mb-4">CHANNELS</OrientingText>
                        <SystemNav 
                            activeId={activeTab}
                            onSelect={setActiveTab}
                            items={[
                                { id: 'inbox', label: 'Inbox', icon: Inbox, type: 'active' },
                                { id: 'marketing', label: 'Marketing', icon: BarChart, type: 'settled' },
                                { id: 'social', label: 'Social', icon: MessageSquare, type: 'settled' },
                                { id: 'voip', label: 'VoIP', icon: Phone, type: 'settled' },
                                { id: 'video', label: 'Video Grid', icon: Video, type: 'settled' }
                            ]}
                        />
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col">
                        {activeTab === 'inbox' && (
                            <AddonGate 
                                addonName="Nexus Comms" 
                                integrationType="slack"
                                title="Unified Inbox"
                                icon={Inbox}
                            >
                                <NexusWidget 
                                    messages={messages} 
                                    onReply={handleReply} 
                                    onDraft={handleDraft}
                                    onArchive={handleArchive}
                                    onDelete={handleDelete}
                                />
                            </AddonGate>
                        )}

                        {activeTab === 'marketing' && (
                            <MarketingManager 
                                campaigns={campaigns} 
                                onNewCampaign={() => setIsCampaignModalOpen(true)} 
                            />
                        )}

                        {activeTab === 'social' && (
                            <SocialManager 
                                onCompose={() => { setComposeType('social'); setIsComposeOpen(true); }} 
                                posts={socialPosts}
                            />
                        )}

                        {activeTab === 'voip' && (
                            <div className="h-full w-full">
                                <VoipView />
                            </div>
                        )}

                        {activeTab === 'video' && (
                            <div className="h-full w-full">
                                <VideoCommandCenter />
                            </div>
                        )}
                    </Quadrant>
                </QuadrantGrid>
            }
        />
        <NewCampaignModal open={isCampaignModalOpen} onOpenChange={setIsCampaignModalOpen} />
        <ComposeMessageModal 
            open={isComposeOpen} 
            onOpenChange={setIsComposeOpen} 
            onSent={handleMessageSent}
            type={composeType}
            initialData={replyData}
        />
    </div>
  );
}