import React, { useState, useEffect } from 'react';
import { useSiteContext } from '@/components/identity/SiteContext';
import AgentChatInterface from '@/components/agents/AgentChatInterface';
import { base44 } from '@/api/base44Client';
import { 
    Sparkles, CheckCircle2, Circle, ArrowRight, 
    Palette, Building2, Globe, LayoutTemplate
} from 'lucide-react';
import { OrientingText, IntentText, StateText, Layer, AtomicParagraph } from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery } from '@tanstack/react-query';

import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant } from '@/components/ui/design-system/System';

export default function SetupPage() {
    const { domainData, systemConfig } = useSiteContext();
    const [step, setStep] = useState(1);
    const [agentReady, setAgentReady] = useState(false);

    useEffect(() => {
        const initAgent = async () => {
            const agents = await base44.entities.Agent.list();
            const exists = agents.find(a => a.name === 'OnboardingSpecialist');
            if (!exists) {
                await base44.entities.Agent.create({
                    name: 'OnboardingSpecialist',
                    role: 'Setup Guide',
                    status: 'idle',
                    capabilities: ['system_config', 'onboarding']
                });
            }
            setAgentReady(true);
        };
        initAgent();
    }, []);

    const steps = [
        { id: 1, title: "Welcome", icon: Sparkles },
        { id: 2, title: "Identity", icon: Building2 },
        { id: 3, title: "Integrations", icon: Globe },
        { id: 4, title: "Launch", icon: CheckCircle2 },
    ];

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="h-full flex flex-col justify-center">
                            <div className="max-w-md mx-auto w-full space-y-8">
                                <div>
                                    <OrientingText className="text-[hsl(var(--color-intent))] mb-2">SYSTEM INITIALIZATION</OrientingText>
                                    <IntentText className="text-4xl font-light text-white mb-4">
                                        {systemConfig?.brand_name || domainData.name}
                                    </IntentText>
                                    <AtomicParagraph className="text-neutral-400 text-lg">
                                        Let's configure your white-label environment. I'll guide you through setting up your brand identity and connecting your core services.
                                    </AtomicParagraph>
                                </div>

                                <div className="space-y-4">
                                    {steps.map((s) => {
                                        const Icon = s.icon;
                                        const isActive = s.id === step;
                                        const isPast = s.id < step;
                                        
                                        return (
                                            <div key={s.id} className={`flex items-center gap-4 p-4 rounded-lg border transition-all ${isActive ? 'bg-[hsl(var(--color-intent))]/10 border-[hsl(var(--color-intent))]' : 'border-transparent opacity-50'}`}>
                                                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isActive ? 'bg-[hsl(var(--color-intent))] text-white' : isPast ? 'bg-green-500 text-black' : 'bg-neutral-800 text-neutral-500'}`}>
                                                    {isPast ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-4 h-4" />}
                                                </div>
                                                <div>
                                                    <div className={`font-medium ${isActive ? 'text-white' : 'text-neutral-500'}`}>{s.title}</div>
                                                    {isActive && <div className="text-xs text-[hsl(var(--color-intent))] animate-pulse">In Progress...</div>}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>

                                {step === 4 && (
                                    <div className="pt-8">
                                        <Button className="w-full bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black h-12 text-lg">
                                            Enter Dashboard <ArrowRight className="ml-2 w-5 h-5" />
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col bg-transparent">
                            <div className="h-16 border-b border-neutral-200 flex items-center px-6 justify-between bg-transparent shrink-0">
                                <div className="flex items-center gap-3">
                                    <div className="w-8 h-8 rounded bg-[hsl(var(--color-intent))] flex items-center justify-center text-white">
                                        <Sparkles className="w-4 h-4" />
                                    </div>
                                    <div>
                                        <div className="font-bold text-neutral-900 text-sm">Onboarding Specialist</div>
                                        <div className="text-xs text-neutral-500">Automated Setup Agent</div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="flex-1 bg-transparent relative overflow-hidden">
                                {agentReady ? (
                                    <AgentChatInterface 
                                        agentName="OnboardingSpecialist" 
                                        context={{ step, currentConfig: systemConfig }}
                                        onAgentChange={() => {}}
                                    />
                                ) : (
                                    <div className="flex items-center justify-center h-full text-neutral-400">
                                        Initializing Agent...
                                    </div>
                                )}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}