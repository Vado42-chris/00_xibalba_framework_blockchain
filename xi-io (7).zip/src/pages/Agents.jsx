import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Play, Pause, Activity, Terminal, Bot, Plus, RadioTower, Users, Search, Plug } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    IntentText, StateText, SemanticDot, Layer, 
    OrientingText, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { SystemStats, SystemLog } from '@/components/ui/design-system/SystemContent';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import { toast } from "sonner";
import AgentArchitectModal from '@/components/agents/AgentArchitectModal';
import MissionControl from '@/components/agents/MissionControl';
import { cn } from "@/components/ui/utils";
import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import { useAgentRunner } from '@/components/agents/useAgentRunner';

export default function Agents() {
    const [selectedAgent, setSelectedAgent] = useState(null);
    const [filter, setFilter] = useState('');
    const [isArchitectOpen, setIsArchitectOpen] = useState(false);
    const [viewMode, setViewMode] = useState('details'); // details, mission
    const queryClient = useQueryClient();

    const { data: agents = [] } = useQuery({
        queryKey: ['agents'],
        queryFn: () => base44.entities.Agent.list(),
        initialData: []
    });

    // Activate the autonomous agent runner loop
    useAgentRunner(agents);

    const updateStatusMutation = useMutation({
        mutationFn: ({ id, status }) => base44.entities.Agent.update(id, { status }),
        onSuccess: () => {
            queryClient.invalidateQueries(['agents']);
            toast.success("Agent status updated");
        }
    });

    const AgentRuntimeLogs = ({ agentId, agentName, status }) => {
        // Fetch logs from Global Feed / Logs entity filtered by agent
        const { data: logs = [] } = useQuery({
            queryKey: ['agent_logs', agentId],
            queryFn: () => base44.entities.Log.filter({ remote_identity: agentName }, '-timestamp', 20),
            enabled: !!agentName
        });

        const fallbackLogs = [
            { type: 'SYSTEM', content: `Agent process started (ID: ${agentId})`, status: 'nominal', timestamp: new Date().toISOString() },
            { type: 'INIT', content: `Loading context for ${agentName}...`, status: 'nominal', timestamp: new Date().toISOString() },
            { type: 'INIT', content: 'Context loaded (142ms)', status: 'nominal', timestamp: new Date().toISOString() },
            ...( ['executing', 'busy'].includes(status) ? [
                { type: 'HANDOFF', content: 'Receiving context from Agent A (Chain: #8f92)...', status: 'active', timestamp: new Date().toISOString() },
                { type: 'TASK', content: 'Active process running...', status: 'active', timestamp: new Date().toISOString() },
                { type: 'CURSOR', content: '_ cursor active...', status: 'active', timestamp: new Date().toISOString() }
            ] : [
                { type: 'IDLE', content: 'Waiting for next directive...', status: 'nominal', timestamp: new Date().toISOString() }
            ])
        ];

        return (
            <SystemLog 
                className="h-48"
                logs={logs.length > 0 ? logs : fallbackLogs}
            />
        );
    };

    const filtered = agents.filter(a => (a.name || '').toLowerCase().includes(filter.toLowerCase()));
    
    // Stats
    const activeAgents = agents.filter(a => ['analyzing', 'executing', 'busy'].includes(a.status)).length;
    
    const navigate = useNavigate();

    const navigateToConsole = () => {
        navigate("/Console?cmd=agents");
    };

    const handleSelectAgent = (agent) => {
        setSelectedAgent(agent);
        setViewMode('details');
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Protocol" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Bot className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">AGENT SWARM</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Synthetic Workforce</IntentText>
                                </div>
                                <div className="flex items-center gap-2">
                                        <Badge variant="outline" className="border-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10">
                                            {activeAgents} ACTIVE
                                        </Badge>
                                </div>
                            </div>

                            <GuideBox title="Agent Protocol">
                                <p className="mb-2">
                                    Deploy <TermHelper term="Autonomous Agents" definition="AI programs that can perform tasks without constant supervision." /> to handle complex workflows.
                                </p>
                                <ul className="list-disc list-inside space-y-1 opacity-80">
                                    <li><strong>Architect</strong>: Define new agent roles and permissions.</li>
                                    <li><strong>Mission Control</strong>: Visualize agent coordination.</li>
                                </ul>
                            </GuideBox>
                            
                            <div className="grid grid-cols-2 gap-2">
                                <Button onClick={navigateToConsole} variant="outline" className="border-white/10 text-neutral-400 hover:text-white h-8 text-xs gap-2">
                                    <Terminal className="w-3 h-3" /> Terminal
                                </Button>
                                <Button onClick={() => setIsArchitectOpen(true)} className="bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white h-8 text-xs font-bold">
                                    <Plus className="w-3 h-3 mr-2" /> New Agent
                                </Button>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Roster" className="border-t-0 rounded-t-none flex flex-col" scrollable={false}>
                            <div className="mb-4 relative shrink-0">
                                <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search agents..." 
                                    className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs"
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-1 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {filtered.length === 0 && (
                                    <div className="text-center py-8 border border-dashed border-white/5 rounded flex flex-col items-center group hover:bg-white/5 transition-colors cursor-pointer" onClick={() => setIsArchitectOpen(true)}>
                                        <Bot className="w-8 h-8 text-neutral-600 group-hover:text-[hsl(var(--color-intent))] mb-3 transition-colors" />
                                        <OrientingText className="mb-1">No agents deployed</OrientingText>
                                        <p className="text-[10px] text-neutral-500 max-w-[200px]">
                                            Click to architect your first autonomous agent.
                                        </p>
                                    </div>
                                )}
                                {filtered.map((agent) => (
                                    <SystemCard
                                        key={agent.id}
                                        title={agent.name}
                                        subtitle={agent.role}
                                        icon={Bot}
                                        status={['executing', 'busy'].includes(agent.status) ? 'execution' : agent.status === 'analyzing' ? 'warning' : 'settled'}
                                        active={selectedAgent?.id === agent.id}
                                        onClick={() => handleSelectAgent(agent)}
                                        metric={`v${agent.version}`}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Command" dominance="dominant" className="p-0 flex flex-col overflow-hidden border-b">
                            <Tabs value={viewMode} onValueChange={setViewMode} className="flex-1 flex flex-col h-full">
                                <div className="px-6 pt-4 border-b border-white/5 bg-neutral-900/50">
                                    <TabsList className="bg-transparent h-10 p-0 gap-6">
                                        <TabsTrigger value="details" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-intent))] data-[state=active]:text-[hsl(var(--color-intent))] text-xs uppercase tracking-wider">
                                            Agent Details
                                        </TabsTrigger>
                                        <TabsTrigger value="mission" className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-execution))] data-[state=active]:text-[hsl(var(--color-execution))] text-xs uppercase tracking-wider">
                                            Mission Control
                                        </TabsTrigger>
                                    </TabsList>
                                </div>

                                <div className="flex-1 overflow-hidden relative bg-transparent">
                                    <TabsContent value="details" className="m-0 h-full flex flex-col">
                                        {selectedAgent ? (
                                            <div className="flex flex-col h-full animate-in fade-in duration-300">
                                                <SystemDetailHeader
                                                    title={selectedAgent.name}
                                                    subtitle={`Last Active: ${selectedAgent.last_active ? new Date(selectedAgent.last_active).toLocaleString() : 'Never'}`}
                                                    category={selectedAgent.role.toUpperCase()}
                                                    icon={Bot}
                                                />
                                                
                                                <div className="px-8 mt-4">
                                                    <ActionDock 
                                                        primaryAction={{
                                                            label: ['executing', 'busy'].includes(selectedAgent.status) ? 'Pause Agent' : 'Activate Agent',
                                                            icon: ['executing', 'busy'].includes(selectedAgent.status) ? Pause : Play,
                                                            onClick: () => updateStatusMutation.mutate({ 
                                                                id: selectedAgent.id, 
                                                                status: ['executing', 'busy'].includes(selectedAgent.status) ? 'idle' : 'busy' 
                                                            })
                                                        }}
                                                        secondaryActions={[
                                                            { 
                                                                label: "Kill Process", 
                                                                icon: Activity, 
                                                                onClick: () => updateStatusMutation.mutate({ id: selectedAgent.id, status: 'offline' }) 
                                                            },
                                                            { 
                                                                label: "View Logic", 
                                                                icon: Terminal, 
                                                                onClick: () => toast.info("Logic viewer coming in v2.7") 
                                                            }
                                                        ]}
                                                    />
                                                </div>

                                                <div className="p-8 space-y-6 overflow-y-auto bg-transparent flex-1">
                                                    <div className="grid grid-cols-2 gap-4">
                                                        <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                                                            <StateText className="mb-2">CAPABILITIES & TOOLS</StateText>
                                                            <div className="space-y-3">
                                                                <div className="flex flex-wrap gap-2">
                                                                    {selectedAgent.scope?.map(s => (
                                                                        <Badge key={s} variant="secondary" className="text-[10px] h-5">{s}</Badge>
                                                                    )) || <StateText className="opacity-50">No permissions defined</StateText>}
                                                                </div>
                                                                {selectedAgent.integrations?.length > 0 && (
                                                                    <div className="flex flex-wrap gap-2 border-t border-white/5 pt-2">
                                                                        {selectedAgent.integrations.map(id => (
                                                                            <Badge key={id} variant="outline" className="text-[10px] h-5 border-[hsl(var(--color-intent))]/30 text-[hsl(var(--color-intent))] gap-1">
                                                                                <Plug className="w-2 h-2" /> {id}
                                                                            </Badge>
                                                                        ))}
                                                                    </div>
                                                                )}
                                                            </div>
                                                        </div>
                                                        <SystemStats 
                                                            className="grid-cols-1"
                                                            stats={[
                                                                { label: "Success Rate", value: "98.2%", icon: Activity, color: "text-[hsl(var(--color-execution))]" },
                                                                { label: "Tasks/Hour", value: "420", icon: Search, color: "text-white" }
                                                            ]}
                                                        />
                                                    </div>

                                                    <Layer level="orientation">
                                                        <OrientingText className="mb-2">RUNTIME LOGS</OrientingText>
                                                        <AgentRuntimeLogs agentId={selectedAgent.id} agentName={selectedAgent.name} status={selectedAgent.status} />
                                                    </Layer>
                                                    
                                                    <Layer level="state">
                                                        <OrientingText className="mb-2">CONFIGURATION</OrientingText>
                                                        <pre className="font-mono text-[10px] text-neutral-500 bg-neutral-900/50 p-4 rounded border border-white/5 overflow-x-auto">
                                                            {JSON.stringify({ model: "gpt-4-turbo", temperature: 0.7, max_tokens: 4096, context_window: "128k" }, null, 2)}
                                                        </pre>
                                                    </Layer>
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                                <Bot className="w-16 h-16 text-neutral-500 stroke-1" />
                                                <div>
                                                    <IntentText className="text-xl font-light">Agent Command</IntentText>
                                                    <StateText>Select an agent from the roster to view telemetry and override directives.</StateText>
                                                </div>
                                            </div>
                                        )}
                                    </TabsContent>

                                    <TabsContent value="mission" className="m-0 h-full">
                                        <MissionControl agents={agents} />
                                    </TabsContent>
                                </div>
                            </Tabs>
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Outcome" dominance="supporting" className="border-t-0 rounded-t-none">
                             <div className="p-3 bg-neutral-900 rounded border border-white/5 flex items-center justify-between">
                                <span className="text-xs text-neutral-400">Total Agents</span>
                                <Badge className="bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] border-0">
                                    {agents.length}
                                </Badge>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />

            <AgentArchitectModal open={isArchitectOpen} onOpenChange={setIsArchitectOpen} />

            <TutorialOverlay 
                tutorialId="agents_intro"
                steps={[
                    { title: "Agent Swarm", content: "Welcome to the Command Center for your synthetic workforce.", position: "top-left" },
                    { title: "Architect", content: "Design new autonomous agents with specific roles, scopes, and permissions.", position: "top-left" },
                    { title: "Mission Control", content: "Visualize and monitor active agent threads in real-time.", position: "top-right" },
                    { title: "Telemetry", content: "View detailed logs and intervention options for each agent process.", position: "center" }
                ]}
            />
        </div>
    );
}