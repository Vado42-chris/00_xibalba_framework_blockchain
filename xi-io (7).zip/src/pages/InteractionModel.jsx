import React from 'react';
import { Monitor, Tablet, Smartphone, Eye, EyeOff, CheckCircle, Shield } from 'lucide-react';
import { Card } from "@/components/ui/card";
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText 
} from '@/components/ui/design-system/System';

export default function InteractionModel() {
  const orientations = [
    {
      id: "desktop",
      device: "Desktop",
      role: "Inhabit the Room",
      icon: Monitor,
      visible: ["Full Editor", "Multi-Panel", "Deep Navigation", "System Depth"],
      hidden: ["None (Full Access)"],
      color: "text-[hsl(var(--color-intent))]",
      bg: "bg-neutral-900"
    },
    {
      id: "tablet",
      device: "Tablet",
      role: "Face the Room",
      icon: Tablet,
      visible: ["Inspection", "Logs", "Light Config", "Reasoning"],
      hidden: ["Live Editing", "Multi-Tasking"],
      color: "text-[hsl(var(--color-orientation))]",
      bg: "bg-neutral-900/50"
    },
    {
      id: "mobile",
      device: "Mobile",
      role: "Room Faces You",
      icon: Smartphone,
      visible: ["System Health", "Active Work", "Approvals", "Emergency Control"],
      hidden: ["Editor", "Complexity", "Exploration"],
      color: "text-[hsl(var(--color-execution))]",
      bg: "bg-neutral-900/30"
    }
  ];

  return (
    <div className="h-full w-full bg-transparent overflow-hidden">
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="orientation" className="border-b">
                        <div className="flex justify-between items-end mb-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                <Shield className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">INTERACTION</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Orientation Model</IntentText>
                            </div>
                        </div>
                        <div className="p-4 rounded-lg bg-neutral-900/30 border border-white/5 text-center">
                            <p className="text-[hsl(var(--fg-orientation))] text-xs font-mono">
                                "We do not rotate the UI. We rotate the room."
                            </p>
                        </div>
                    </Quadrant>

                    <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                        <OrientingText className="mb-4">CORE MANTRA</OrientingText>
                        <div className="space-y-4">
                            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded">
                                <StateText className="text-[hsl(var(--fg-state))] font-medium mb-1">Desktop</StateText>
                                <OrientingText className="text-[10px]">INHABIT THE ROOM</OrientingText>
                            </div>
                            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded">
                                <StateText className="text-[hsl(var(--fg-state))] font-medium mb-1">Tablet</StateText>
                                <OrientingText className="text-[10px]">FACE THE ROOM</OrientingText>
                            </div>
                            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded">
                                <StateText className="text-[hsl(var(--fg-state))] font-medium mb-1">Mobile</StateText>
                                <OrientingText className="text-[10px]">ROOM FACES YOU</OrientingText>
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                        <div className="p-8">
                            <div className="grid md:grid-cols-3 gap-8 relative">
                                {/* Connecting line */}
                                <div className="absolute top-[4.5rem] left-0 right-0 h-px bg-gradient-to-r from-[hsl(var(--layer-orientation))] via-[hsl(var(--fg-orientation))] to-[hsl(var(--layer-orientation))] -z-10 hidden md:block opacity-30" />

                                {orientations.map((item) => (
                                <div key={item.id} className="relative group">
                                    <Card className={`h-full p-6 border-white/5 ${item.bg} backdrop-blur-sm transition-all hover:border-white/20 flex flex-col`}>
                                    
                                    {/* Header */}
                                    <div className="flex flex-col items-center text-center mb-8">
                                        <div className={`p-4 rounded-full bg-neutral-950 border border-white/5 mb-4 shadow-xl ${item.color}`}>
                                        <item.icon className="w-8 h-8" />
                                        </div>
                                        <h3 className="text-lg font-bold text-[hsl(var(--fg-intent))]">{item.device}</h3>
                                        <div className="text-xs font-mono text-[hsl(var(--color-active))] uppercase tracking-widest mt-1">
                                        {item.role}
                                        </div>
                                    </div>

                                    {/* Surfaces */}
                                    <div className="flex-1 space-y-6">
                                        
                                        {/* Facing User */}
                                        <div>
                                        <div className="flex items-center gap-2 mb-3 text-xs font-bold text-[hsl(var(--fg-orientation))] uppercase tracking-wider">
                                            <Eye className="w-3 h-3" />
                                            Facing User
                                        </div>
                                        <ul className="space-y-2">
                                            {item.visible.map((s) => (
                                            <li key={s} className="flex items-center gap-2 text-sm text-[hsl(var(--fg-state))] font-mono">
                                                <CheckCircle className="w-3 h-3 text-[hsl(var(--fg-orientation))]" />
                                                {s}
                                            </li>
                                            ))}
                                        </ul>
                                        </div>

                                        {/* Turned Away */}
                                        <div>
                                        <div className="flex items-center gap-2 mb-3 text-xs font-bold text-[hsl(var(--fg-orientation))] uppercase tracking-wider opacity-60">
                                            <EyeOff className="w-3 h-3" />
                                            Turned Away
                                        </div>
                                        <ul className="space-y-2">
                                            {item.hidden.map((s) => (
                                            <li key={s} className="flex items-center gap-2 text-sm text-[hsl(var(--fg-orientation))] font-mono opacity-60">
                                                <span className="w-1 h-1 rounded-full bg-[hsl(var(--layer-orientation))]" />
                                                {s}
                                            </li>
                                            ))}
                                        </ul>
                                        </div>

                                    </div>

                                    </Card>
                                </div>
                                ))}
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    </div>
  );
}