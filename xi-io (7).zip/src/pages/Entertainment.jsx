import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Gamepad2, Film, Plane, Music, 
    Tv, Headphones, Book
} from 'lucide-react';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer
} from '@/components/ui/design-system/System';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Badge } from "@/components/ui/badge";

export default function Entertainment() {
    const { data: items = [] } = useQuery({
        queryKey: ['entertainment_items'],
        queryFn: () => base44.entities.EntertainmentItem.list('-created_date', 50),
        initialData: []
    });

    const inProgress = items.filter(i => i.status === 'in_progress');
    const watchlist = items.filter(i => i.status === 'backlog');
    const completed = items.filter(i => i.status === 'completed');

    const getIcon = (type) => {
        switch(type) {
            case 'game': return Gamepad2;
            case 'movie': return Film;
            case 'show': return Tv;
            case 'book': return Book;
            case 'music': return Music;
            case 'travel': return Plane;
            default: return Film;
        }
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Gamepad2 className="w-4 h-4 text-purple-500" />
                                        <OrientingText className="tracking-widest font-bold text-purple-500">LUDIC ENGINE</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Entertainment & Leisure</IntentText>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-2">
                                <Layer level="orientation" className="p-3 flex flex-col justify-between bg-neutral-900/50">
                                    <div className="text-purple-400"><StateText>Playing</StateText></div>
                                    <IntentText className="text-xl">{inProgress.length}</IntentText>
                                </Layer>
                                <Layer level="orientation" className="p-3 flex flex-col justify-between bg-neutral-900/50">
                                    <div className="text-sky-400"><StateText>Watchlist</StateText></div>
                                    <IntentText className="text-xl">{watchlist.length}</IntentText>
                                </Layer>
                                <Layer level="orientation" className="p-3 flex flex-col justify-between bg-neutral-900/50">
                                    <div className="text-emerald-400"><StateText>Done</StateText></div>
                                    <IntentText className="text-xl">{completed.length}</IntentText>
                                </Layer>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">CONTINUE</OrientingText>
                            <div className="space-y-3 overflow-y-auto max-h-[500px] pr-2">
                                {inProgress.length === 0 && <div className="text-xs text-neutral-500 italic">No active media. Start something new!</div>}
                                {inProgress.map((item) => {
                                    const Icon = getIcon(item.type);
                                    return (
                                        <div key={item.id} className="p-3 rounded border border-white/5 bg-neutral-900/30 flex gap-4 hover:border-purple-500/50 transition-colors cursor-pointer group">
                                            <div className="w-12 h-16 bg-neutral-800 rounded flex items-center justify-center text-neutral-600">
                                                <Icon className="w-6 h-6" />
                                            </div>
                                            <div className="flex-1 py-1">
                                                <div className="flex justify-between items-start">
                                                    <IntentText className="font-bold group-hover:text-purple-400 transition-colors">{item.title}</IntentText>
                                                    <Badge variant="outline" className="text-[9px] uppercase">{item.platform || item.type}</Badge>
                                                </div>
                                                <div className="w-full h-1 bg-neutral-800 rounded-full mt-3 overflow-hidden">
                                                    <div className="h-full bg-purple-500" style={{ width: `${item.progress || 0}%` }} />
                                                </div>
                                                <div className="text-[9px] text-right mt-1 text-purple-500">{item.progress || 0}% Complete</div>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_1fr]">
                        <Quadrant type="intent" dominance="dominant" className="border-b">
                            <OrientingText className="mb-4">WATCHLIST & BACKLOG</OrientingText>
                            <div className="space-y-2 overflow-y-auto h-full pr-2 pb-4">
                                {watchlist.map((item) => {
                                    const Icon = getIcon(item.type);
                                    return (
                                        <div key={item.id} className="flex items-center gap-3 p-2 hover:bg-white/5 rounded border border-transparent hover:border-white/5 transition-all cursor-pointer">
                                            <div className="p-2 rounded bg-neutral-900 text-neutral-500">
                                                <Icon className="w-4 h-4" />
                                            </div>
                                            <div className="flex-1">
                                                <div className="text-sm font-medium text-neutral-300">{item.title}</div>
                                                <div className="text-[10px] text-neutral-500 capitalize">{item.type} • {item.platform}</div>
                                            </div>
                                            <Badge variant="secondary" className="text-[9px]">Queue</Badge>
                                        </div>
                                    );
                                })}
                                {watchlist.length === 0 && <div className="text-xs text-neutral-500 italic">Your queue is empty.</div>}
                            </div>
                        </Quadrant>
                        
                        <Quadrant type="state" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">RECENTLY COMPLETED</OrientingText>
                            <div className="space-y-2 overflow-y-auto h-full pr-2">
                                {completed.map((item) => (
                                    <div key={item.id} className="flex justify-between items-center p-2 hover:bg-white/5 rounded transition-colors opacity-75 hover:opacity-100">
                                        <div className="flex items-center gap-3">
                                            <Badge className="bg-emerald-500/20 text-emerald-500 hover:bg-emerald-500/30 text-[9px]">DONE</Badge>
                                            <span className="text-xs text-white">{item.title}</span>
                                        </div>
                                        <div className="flex gap-0.5">
                                            {[...Array(5)].map((_, i) => (
                                                <div key={i} className={`w-1 h-1 rounded-full ${i < (item.rating || 0) ? 'bg-amber-500' : 'bg-neutral-800'}`} />
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}