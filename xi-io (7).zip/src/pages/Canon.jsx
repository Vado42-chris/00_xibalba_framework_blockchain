import React from 'react';
import { Shield, Lock, Smartphone, Tablet, Monitor, Grid, AlertTriangle, Book, Brain } from 'lucide-react';
import { Card } from "@/components/ui/card";
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, Layer 
} from '@/components/ui/design-system/System';

export default function Canon() {
  return (
    <div className="h-full w-full bg-transparent overflow-hidden">
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="orientation" className="border-b">
                        <div className="flex justify-between items-end mb-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <Shield className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">SYSTEM CANON</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Immutable Laws</IntentText>
                            </div>
                            <div className="text-right">
                                <StateText className="text-[10px] opacity-50">STATUS</StateText>
                                <div className="text-[hsl(var(--color-execution))] font-mono text-sm">ENFORCED</div>
                            </div>
                        </div>
                        
                        <Layer level="orientation" className="p-4">
                            <div className="flex items-center gap-3">
                                <Lock className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                <StateText>HASH: 0x7F...3A</StateText>
                            </div>
                        </Layer>
                    </Quadrant>

                    <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                        <OrientingText className="mb-4">DOCUMENTATION INDEX</OrientingText>
                        <div className="space-y-2 overflow-y-auto h-full pr-2 scrollbar-thin scrollbar-thumb-white/5">
                           {[
                               { name: 'Flow Architecture', path: 'FlowArchitecture' },
                               { name: 'Interaction Model', path: 'InteractionModel' },
                               { name: 'Desktop Topology', path: 'DesktopRooms' },
                               { name: 'Temporal Flow', path: 'DesktopExperience' },
                               { name: 'Domain Manifest', path: 'DomainManifest' },
                               { name: 'User Domain', path: 'UserDomain' },
                               ].map(doc => (
                               <a key={doc.path} href={`/${doc.path}`} className="flex items-center justify-between p-3 bg-neutral-900/30 border border-white/5 rounded hover:bg-neutral-900 hover:border-[hsl(var(--color-intent))] transition-colors group">
                                  <div>
                                      <IntentText className="text-xs font-bold group-hover:text-[hsl(var(--color-intent))]">{doc.name}</IntentText>
                                      <StateText className="text-[9px] font-mono mt-1">DOC-{doc.path.substring(0, 3).toUpperCase()}</StateText>
                                  </div>
                                  <Book className="w-3 h-3 text-neutral-600 group-hover:text-white" />
                               </a>
                               ))}
                               </div>
                               </Quadrant>
                               </QuadrantGrid>
                               }
                               right={
                               <QuadrantGrid className="p-0 h-full gap-0">
                               <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col overflow-y-auto">
                               <div className="p-8 space-y-8">

                               {/* Central Repository Banner */}
                               <div className="p-6 bg-gradient-to-br from-neutral-900 to-black border border-white/10 rounded-lg flex items-center justify-between shadow-2xl">
                               <div>
                                   <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                                       <Book className="w-5 h-5 text-[hsl(var(--color-intent))]" /> 
                                       Central Knowledge Repository
                                   </h2>
                                   <p className="text-sm text-neutral-400 max-w-lg">
                                       All system manuals, training datasets, and protocol documentation are secured in the User Vault.
                                   </p>
                                   <div className="flex items-center gap-2 mt-3 text-xs text-[hsl(var(--color-execution))]">
                                       <Lock className="w-3 h-3" />
                                       <span className="font-mono">ENCRYPTED • LINKED TO USER PROFILE</span>
                                   </div>
                               </div>
                               <div className="hidden md:block">
                                   <div className="w-16 h-16 rounded bg-neutral-800 border border-white/5 flex items-center justify-center">
                                       <Shield className="w-8 h-8 text-neutral-600" />
                                   </div>
                               </div>
                               </div>

                               {/* Core Orientation */}
                               <section className="space-y-4">
                               <OrientingText className="flex items-center gap-2">
                                   <Monitor className="w-3 h-3" /> ORIENTATION PROTOCOL
                               </OrientingText>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div className="p-5 bg-neutral-900 border border-white/5 rounded">
                                        <Monitor className="w-6 h-6 text-[hsl(var(--fg-state))] mb-3" />
                                        <div className="text-sm font-bold text-[hsl(var(--fg-intent))]">Desktop</div>
                                        <div className="text-xs text-[hsl(var(--fg-orientation))] font-mono mt-1 mb-2">INHABIT THE ROOM</div>
                                        <div className="text-[10px] text-[hsl(var(--fg-orientation))] border-t border-white/5 pt-2">Full Control Plane • Deep Work</div>
                                    </div>
                                    <div className="p-5 bg-neutral-900 border border-white/5 rounded">
                                        <Tablet className="w-6 h-6 text-[hsl(var(--fg-state))] mb-3" />
                                        <div className="text-sm font-bold text-[hsl(var(--fg-intent))]">Tablet</div>
                                        <div className="text-xs text-[hsl(var(--fg-orientation))] font-mono mt-1 mb-2">FACE THE ROOM</div>
                                        <div className="text-[10px] text-[hsl(var(--fg-orientation))] border-t border-white/5 pt-2">Inspection • Logs • Review</div>
                                    </div>
                                    <div className="p-5 bg-neutral-900 border border-white/5 rounded">
                                        <Smartphone className="w-6 h-6 text-[hsl(var(--fg-state))] mb-3" />
                                        <div className="text-sm font-bold text-[hsl(var(--fg-intent))]">Mobile</div>
                                        <div className="text-xs text-[hsl(var(--fg-orientation))] font-mono mt-1 mb-2">ROOM FACES YOU</div>
                                        <div className="text-[10px] text-[hsl(var(--fg-orientation))] border-t border-white/5 pt-2">Approvals • Emergency • Status</div>
                                    </div>
                                </div>
                            </section>

                            {/* Immutable Laws */}
                            <section className="space-y-4">
                                <OrientingText className="flex items-center gap-2">
                                    <Lock className="w-3 h-3" /> IMMUTABLE LAWS
                                </OrientingText>
                                <div className="bg-neutral-950 border border-white/5 rounded-lg divide-y divide-white/5">
                                    {[
                                        "Identity is cryptographic, not a login session.",
                                        "AI is a contained utility, never a personality.",
                                        "Responsiveness is capability filtering, not layout reflow.",
                                        "Destructive actions require explicit Scope Capsules.",
                                        "Observer Mode physically disables actuation circuits."
                                    ].map((rule, idx) => (
                                        <div key={idx} className="p-4 flex items-center gap-4 group hover:bg-[hsl(var(--layer-orientation))]/30 transition-colors">
                                            <span className="text-[hsl(var(--fg-orientation))] font-mono text-xs">0{idx + 1}</span>
                                            <p className="text-sm text-[hsl(var(--fg-state))] font-medium">{rule}</p>
                                        </div>
                                    ))}
                                </div>
                            </section>

                            {/* Topology */}
                            <section className="space-y-4">
                                <OrientingText className="flex items-center gap-2">
                                    <Grid className="w-3 h-3" /> SYSTEM TOPOLOGY
                                </OrientingText>
                                <div className="flex flex-wrap gap-2">
                                    {['Console', 'Communications', 'Network', 'Nodes', 'Identity', 'Intelligence', 'Canon'].map(room => (
                                        <span key={room} className="px-3 py-1.5 bg-neutral-900/50 border border-white/5 rounded text-xs text-[hsl(var(--fg-state))] font-mono hover:text-[hsl(var(--color-intent))] transition-colors cursor-default">
                                            {room}
                                        </span>
                                    ))}
                                </div>
                            </section>

                            {/* Training Manuals */}
                            <section className="space-y-4">
                                <OrientingText className="flex items-center gap-2">
                                    <Brain className="w-3 h-3" /> AI TRAINING PROTOCOLS
                                </OrientingText>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="p-4 bg-neutral-900/30 border border-white/5 rounded hover:border-[hsl(var(--color-execution))] transition-colors cursor-pointer group">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="text-sm font-bold text-white group-hover:text-[hsl(var(--color-execution))]">Model Onboarding</div>
                                            <div className="px-2 py-0.5 bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))] text-[9px] rounded font-mono">V2.4</div>
                                        </div>
                                        <p className="text-xs text-neutral-500 mb-3">Standard procedure for ingesting new datasets and configuring hyperparameters.</p>
                                        <div className="text-[10px] text-neutral-600 font-mono">REF: KB-AI-001</div>
                                    </div>
                                    <div className="p-4 bg-neutral-900/30 border border-white/5 rounded hover:border-[hsl(var(--color-execution))] transition-colors cursor-pointer group">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="text-sm font-bold text-white group-hover:text-[hsl(var(--color-execution))]">Certification Standard</div>
                                            <div className="px-2 py-0.5 bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))] text-[9px] rounded font-mono">BLOCKCHAIN</div>
                                        </div>
                                        <p className="text-xs text-neutral-500 mb-3">Verification process for Proof-of-Work model training and ownership assignment.</p>
                                        <div className="text-[10px] text-neutral-600 font-mono">REF: KB-AI-002</div>
                                    </div>
                                </div>
                            </section>

                            <div className="pt-12 border-t border-white/5 flex flex-col items-center justify-center gap-2 opacity-40">
                                <AlertTriangle className="w-4 h-4 text-red-900" />
                                <span className="text-[10px] text-red-900 font-bold uppercase tracking-widest">Modification constitutes system breach</span>
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    </div>
  );
}