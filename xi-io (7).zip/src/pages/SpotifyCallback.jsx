import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function SpotifyCallback() {
    const location = useLocation();
    const navigate = useNavigate();
    const [status, setStatus] = useState('processing'); // processing, success, error

    useEffect(() => {
        const processCallback = async () => {
            const params = new URLSearchParams(location.search);
            const code = params.get('code');
            const error = params.get('error');

            if (error) {
                setStatus('error');
                toast.error("Spotify Auth Failed", { description: error });
                setTimeout(() => navigate('/'), 3000);
                return;
            }

            if (!code) {
                setStatus('error');
                return;
            }

            try {
                // Exchange code for token via backend
                const response = await base44.functions.invoke('spotify', { 
                    action: 'exchange_token', 
                    code: code 
                });

                const { access_token, refresh_token, expires_in } = response.data;

                if (!access_token) throw new Error("No token received");

                // Store tokens securely (HttpOnly cookie is best, but here we use localStorage/Entity for the widget)
                // Ideally, we store this on the User entity if we want it persistent across devices
                // For now, localStorage is "good enough" for a desktop widget prototype
                
                const expiresAt = Date.now() + (expires_in * 1000);
                
                localStorage.setItem('spotify_access_token', access_token);
                if (refresh_token) localStorage.setItem('spotify_refresh_token', refresh_token);
                localStorage.setItem('spotify_expires_at', expiresAt);

                setStatus('success');
                toast.success("Sound Engine Connected");
                
                // Redirect back to desktop after short delay
                setTimeout(() => navigate('/'), 1500);

            } catch (err) {
                console.error("Token Exchange Error:", err);
                setStatus('error');
                toast.error("Failed to connect Sound Engine");
            }
        };

        processCallback();
    }, [location, navigate]);

    return (
        <div className="h-screen w-full flex flex-col items-center justify-center bg-black text-white">
            <div className="p-8 rounded-2xl bg-neutral-900 border border-white/10 flex flex-col items-center gap-6 max-w-sm text-center">
                {status === 'processing' && (
                    <>
                        <Loader2 className="w-12 h-12 text-[#1DB954] animate-spin" />
                        <div>
                            <h2 className="text-xl font-bold">Connecting...</h2>
                            <p className="text-neutral-400 text-sm mt-2">Linking the Sound Engine to your environment.</p>
                        </div>
                    </>
                )}
                
                {status === 'success' && (
                    <>
                        <CheckCircle className="w-12 h-12 text-[#1DB954]" />
                        <div>
                            <h2 className="text-xl font-bold">Connected</h2>
                            <p className="text-neutral-400 text-sm mt-2">Redirecting to Dashboard...</p>
                        </div>
                    </>
                )}

                {status === 'error' && (
                    <>
                        <XCircle className="w-12 h-12 text-red-500" />
                        <div>
                            <h2 className="text-xl font-bold">Connection Failed</h2>
                            <p className="text-neutral-400 text-sm mt-2">Please try again or check your API keys.</p>
                        </div>
                        <button 
                            onClick={() => navigate('/')}
                            className="text-xs text-neutral-500 hover:text-white underline"
                        >
                            Return to Safety
                        </button>
                    </>
                )}
            </div>
        </div>
    );
}