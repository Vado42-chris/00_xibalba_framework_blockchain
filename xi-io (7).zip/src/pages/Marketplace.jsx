import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { ShoppingBag, Star, Download, Box, CreditCard, Search, Brain, Briefcase, Zap, Check, Plus, Package, Cpu, ArrowRight, MessageSquare, Globe, Palette, Plug } from 'lucide-react';
import ServiceRequestModal from '@/components/integrations/ServiceRequestModal';
import CreateListingModal from '@/components/marketplace/CreateListingModal';
import PaymentModal from '@/components/marketplace/PaymentModal';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    IntentText, StateText, SemanticDot, Layer, 
    AtomicParagraph, OrientingText, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader, SystemNav } from '@/components/ui/design-system/SystemComponents';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { cn } from "@/components/ui/utils";
import { SiteHeader } from '@/components/site/SiteHeader';
import { SmartErrorBoundary } from '@/components/ui/SmartErrorBoundary';
import { GhostConsole } from '@/components/marketplace/GhostConsole';
import { BrowserWindow } from '@/components/ui/BrowserWindow';
import { useSiteContext } from '@/components/identity/SiteContext';
import ChronosWidget from '@/components/addons/official/ChronosWidget';
import NeuroLinkViz from '@/components/addons/official/NeuroLinkViz';
import StrataBrowser from '@/components/addons/official/StrataBrowser';
import NexusWidget from '@/components/addons/official/NexusWidget';
import PipelineWidget from '@/components/addons/official/PipelineWidget';
import ResearchDeck from '@/components/addons/official/ResearchDeck';
import { HallbergmathsAudit } from '@/components/marketplace/HallbergmathsAudit';

const LIVE_PREVIEWS = {
    'Chronos Timekeeper': ChronosWidget,
    'Neuro-Link Analytics': NeuroLinkViz,
    'Strata Knowledge': StrataBrowser,
    'Nexus Comms': NexusWidget,
    'Pipeline Hologram': PipelineWidget,
    'Research Deck': ResearchDeck
};

export default function Marketplace() {
    const { systemStage } = useSiteContext();
    const [selectedItem, setSelectedItem] = useState(null);
    const [filter, setFilter] = useState('');
    const params = new URLSearchParams(window.location.search);
    const [activeTab, setActiveTab] = useState(params.get('category') || 'all');
    const [providerFilter, setProviderFilter] = useState('all'); // 'all', 'official', 'partner', 'community'
    const [showReviewForm, setShowReviewForm] = useState(false);
    const [isCreating, setIsCreating] = useState(params.get('action') === 'create');
    const [showSmartSuggestions, setShowSmartSuggestions] = useState(false);
    
    // Concierge / Service Mode State
    const [serviceMode, setServiceMode] = useState('diy'); // 'diy' | 'concierge'
    const [serviceRequestModalOpen, setServiceRequestModalOpen] = useState(false);
    const [requestType, setRequestType] = useState('integration'); // 'integration' | 'bundle'
    
    // Ghost Console State
    const [consoleActive, setConsoleActive] = useState(false);
    const [consoleLogs, setConsoleLogs] = useState([]);

    const queryClient = useQueryClient();

    // Check user for restricted actions
    const [user, setUser] = useState(null);
    React.useEffect(() => {
        base44.auth.me().then(setUser).catch(() => setUser(null));
    }, []);

    // Reset service mode when selection changes
    React.useEffect(() => {
        setServiceMode('diy');
    }, [selectedItem]);

    // Preview Logic
    const [previewItem, setPreviewItem] = useState(null);

    const handlePreviewTheme = async (item) => {
        if (!item) return;
        
        if (item.category === 'theme') {
            const themeData = item.name === 'Neon Genesis' ? {
                "color-intent": 320, 
                "color-execution": 180,
                "color-orientation": 260,
                "glass-blur": 0,
                "glass-opacity": 90,
                "glass-border": 100,
                "glass-saturation": 150,
                "bg-pulse-speed": 80,
                "bg-grid-opacity": 40
            } : null;

            if (themeData) {
                const { applyTheme } = await import('@/components/identity/themeUtils');
                applyTheme(themeData);
                toast.success(`Previewing ${item.name}`);
            } else {
                toast.info("Preview not available for this theme.");
            }
        } else {
            // For non-themes, open the Browser Window
            setPreviewItem(item);
        }
    };
    
    // Payment Modal State
    const [paymentModalOpen, setPaymentModalOpen] = useState(false);
    const [pendingItem, setPendingItem] = useState(null);

    // Mutation moved to CreateListingModal

    const { data: items = [] } = useQuery({
        queryKey: ['marketplace_items'],
        queryFn: () => base44.entities.MarketplaceItem.list(),
        initialData: []
    });

    const { data: installations = [] } = useQuery({
        queryKey: ['installed_addons'],
        queryFn: () => base44.entities.InstalledAddon.list(),
        initialData: []
    });

    // Enrich items with installation status
    const enrichedItems = items.map(item => {
        const install = installations.find(i => i.addon_id === item.id);
        return {
            ...item,
            installed: !!install,
            installStatus: install?.status,
            installed_tier: install?.installed_tier || (install?.config?.tier)
        };
    });

    // Seed Value Packs if missing
    React.useEffect(() => {
        const seedValuePacks = async () => {
            const currentItems = await base44.entities.MarketplaceItem.list();
            const PACKS = [
                // OFFICIAL MODULES
                {
                    name: 'Neuro-Link Analytics',
                    description: 'Deep neural interface for cognitive load monitoring and predictive system telemetry. Lifetime Access.',
                    category: 'module',
                    sub_category: 'Intelligence',
                    provider_type: 'official',
                    price_amount: 49,
                    pricing_type: 'one_time',
                    features: ['D3 Visualization', 'Real-time Telemetry', 'Cognitive Load Metrics', 'Context Window Viz'],
                    featured: true,
                    author: 'Cortex Systems (Seed001)'
                },
                {
                    name: 'Chronos Timekeeper',
                    description: 'Universal calendar sync and schedule optimization engine.',
                    category: 'module',
                    sub_category: 'Lifestyle',
                    provider_type: 'official',
                    price_amount: 29,
                    pricing_type: 'one_time',
                    features: ['Google Calendar Sync', 'Smart Agenda', 'Meeting Alerts', 'Time Blocking'],
                    featured: false,
                    author: 'Cortex Systems (Seed001)'
                },
                {
                    name: 'Strata Knowledge',
                    description: 'External memory mount point. Seamlessly integrate Notion databases into your local archive.',
                    category: 'module',
                    sub_category: 'Archives',
                    provider_type: 'official',
                    price_amount: 39,
                    pricing_type: 'one_time',
                    features: ['Notion Integration', 'Deep Search', 'Auto-Tagging', 'Offline Cache'],
                    featured: false,
                    author: 'Cortex Systems (Seed001)'
                },
                {
                    name: 'Nexus Comms',
                    description: 'Unified communication uplink. Merge Slack, Discord, and Email into a single command center.',
                    category: 'module',
                    sub_category: 'Communications',
                    provider_type: 'official',
                    price_amount: 59,
                    pricing_type: 'one_time',
                    features: ['Unified Inbox', 'Multi-Channel Reply', 'AI Drafts', 'Priority Filtering'],
                    featured: true,
                    author: 'Cortex Systems (Seed001)'
                },
                {
                    name: 'Pipeline Hologram',
                    description: '3D visualization for your sales pipeline. Connects to Salesforce/HubSpot.',
                    category: 'module',
                    sub_category: 'CRM',
                    provider_type: 'official',
                    price_amount: 79,
                    pricing_type: 'one_time',
                    features: ['Salesforce Sync', 'HubSpot Sync', 'Revenue Forecasting', 'Deal Velocity Tracking'],
                    featured: false,
                    author: 'Cortex Systems (Seed001)'
                },
                {
                    name: 'Research Deck',
                    description: 'Academic-grade browser interface with built-in citation management and scholar indexing.',
                    category: 'browser',
                    sub_category: 'Tools',
                    provider_type: 'official',
                    price_amount: 99,
                    pricing_type: 'one_time',
                    features: ['Citation Manager', 'PDF Annotation', 'Scholar Index', 'Offline Archive'],
                    featured: true,
                    author: 'Cortex Systems (Seed001)'
                },
                {
                    name: 'Ledger Quant',
                    description: 'Institutional-grade asset analytics. Volatility tracking, liquidity depth, and predictive APY modeling.',
                    category: 'module',
                    sub_category: 'Finance',
                    provider_type: 'official',
                    price_amount: 149,
                    pricing_type: 'one_time',
                    features: ['Volatility Index', 'Liquidity Heatmap', 'APY Forecasting', 'Risk Analysis'],
                    featured: true,
                    author: 'Cortex Systems (Seed001)'
                },
                {
                    name: 'Sentinel Aegis',
                    description: 'Advanced network security layer. Provides visualized VPN topology and active threat mitigation.',
                    category: 'module',
                    sub_category: 'Network',
                    provider_type: 'official',
                    price_amount: 129,
                    pricing_type: 'one_time',
                    features: ['Tunnel Topology', 'Threat Visualizer', 'Auto-IP Rotation', 'Deep Packet Inspection'],
                    featured: false,
                    author: 'Cortex Systems (Seed001)'
                },
                
                // PARTNER INTEGRATIONS (3rd Party)
                {
                    name: 'Spotify Connect',
                    description: 'Seamless audio stream integration. Control playback directly from your System Dashboard.',
                    category: 'integration',
                    sub_category: 'Media',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Playback Control', 'Playlist Sync', 'Now Playing Widget', 'Mood Analysis'],
                    featured: true,
                    author: 'Spotify AB',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/spotify-2.svg',
                    integration_provider: 'spotify'
                },
                {
                    name: 'Slack Matrix',
                    description: 'Deep Slack integration. Bi-directional message piping and channel monitoring.',
                    category: 'integration',
                    sub_category: 'Communication',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Channel Mirroring', 'Direct DMs', 'Status Sync', 'Thread Summarization'],
                    featured: true,
                    author: 'Slack Technologies',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/slack-new-logo.svg',
                    integration_provider: 'slack'
                },
                {
                    name: 'Discord Node',
                    description: 'Turn your server into a Discord bot host. Manage communities and automate roles.',
                    category: 'integration',
                    sub_category: 'Communication',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Role Management', 'Event Listeners', 'Voice Gateway', 'Webhook Pipes'],
                    featured: false,
                    author: 'Discord Inc',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/discord-6.svg',
                    integration_provider: 'discord'
                },
                {
                    name: 'Linear Sync',
                    description: 'High-performance issue tracking synchronization for your development workflows.',
                    category: 'integration',
                    sub_category: 'Productivity',
                    provider_type: 'partner',
                    price_amount: 19,
                    pricing_type: 'one_time',
                    features: ['Issue Mirroring', 'Roadmap Viz', 'Cycle Analytics', 'PR Linking'],
                    featured: true,
                    author: 'Linear Orbit',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/linear.svg',
                    integration_provider: 'linear'
                },
                {
                    name: 'GitHub Uplink',
                    description: 'Direct repository access. Monitor PRs, deployments, and issues from your console.',
                    category: 'integration',
                    sub_category: 'DevTools',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Repo Monitoring', 'Workflow Dispatch', 'Gist Management', 'Commit Graph'],
                    featured: false,
                    author: 'GitHub',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/github-icon-1.svg',
                    integration_provider: 'github'
                },
                {
                    name: 'Figma Mirror',
                    description: 'Live design frame embedding. View and comment on design files without leaving the OS.',
                    category: 'integration',
                    sub_category: 'Design',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Frame Embedding', 'Comment Sync', 'Asset Export', 'Version History'],
                    featured: false,
                    author: 'Figma',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/figma-1.svg',
                    integration_provider: 'figma'
                },
                {
                    name: 'OpenAI Core',
                    description: 'Native LLM access. Inject GPT-4 capabilities into any text field or agent.',
                    category: 'ai_model',
                    sub_category: 'Intelligence',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Prompt Injection', 'Context Awareness', 'Function Calling', 'Code Gen'],
                    featured: true,
                    author: 'OpenAI',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/openai-2.svg',
                    integration_provider: 'openai'
                },
                {
                    name: 'Google Drive',
                    description: 'Mount your Google Drive as a local file system node.',
                    category: 'integration',
                    sub_category: 'Storage',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['File Mount', 'Offline Sync', 'Shared Drives', 'Docs Editing'],
                    featured: false,
                    author: 'Google',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/google-drive.svg',
                    integration_provider: 'google'
                },
                {
                    name: 'Stripe Payments',
                    description: 'Accept payments and manage subscriptions directly from your commerce dashboard.',
                    category: 'integration',
                    sub_category: 'Finance',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Payment Links', 'Subscription Management', 'Revenue Analytics', 'Fraud Guard'],
                    featured: true,
                    author: 'Stripe',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/stripe-4.svg',
                    integration_provider: 'stripe'
                },
                {
                    name: 'Notion Sync',
                    description: 'Bi-directional database sync. Manage Notion pages as system assets.',
                    category: 'integration',
                    sub_category: 'Productivity',
                    provider_type: 'partner',
                    price_amount: 0,
                    pricing_type: 'free',
                    features: ['Database Sync', 'Page Editing', 'Block Management', 'Wiki View'],
                    featured: false,
                    author: 'Notion Labs',
                    integration_logo: 'https://cdn.worldvectorlogo.com/logos/notion-2.svg',
                    integration_provider: 'notion'
                },

                // COMMUNITY ITEMS
                {
                    name: 'Neon Genesis',
                    description: 'A high-contrast, cyberpunk theme inspired by 90s anime interfaces.',
                    category: 'theme',
                    sub_category: 'Visuals',
                    provider_type: 'community',
                    price_amount: 15,
                    pricing_type: 'one_time',
                    features: ['Custom Palette', 'Glitch Animations', 'Retro Fonts', 'Sound Pack'],
                    featured: false,
                    author: 'Visual Cortex'
                },
                {
                    name: 'Zenith OS',
                    description: 'Total conversion distro. Replaces the standard interface with a spatial computing paradigm.',
                    category: 'distro',
                    sub_category: 'System',
                    provider_type: 'community',
                    price_amount: 199,
                    pricing_type: 'one_time',
                    features: ['Spatial Navigation', '3D Workspace', 'Gesture Control', 'Deep Kernel Access'],
                    featured: true,
                    author: 'Architect_Zero',
                    royalty_bps: 1500, // 15%
                    upstream_ids: ['seed_001']
                },
                {
                    name: 'Secure Signal',
                    description: 'Military-grade encryption for all communication channels. Peer-to-peer routing.',
                    category: 'module',
                    sub_category: 'Communications',
                    provider_type: 'community',
                    price_amount: 89,
                    pricing_type: 'one_time',
                    features: ['E2E Encryption', 'Self-Destruct Messages', 'Onion Routing', 'No Logs'],
                    featured: false,
                    author: 'CypherPunk_Collective',
                    royalty_bps: 500, // 5%
                    upstream_ids: ['nexus_comms']
                },

                // VALUE PACKS
                {
                    name: 'E-Commerce Launchpad',
                    description: 'Complete retail stack. We set up your store, payment gateway, and inventory sync pipeline.',
                    category: 'automation_pack',
                    provider_type: 'official',
                    price_amount: 1499,
                    pricing_type: 'one_time',
                    features: ['Store Setup', 'Payment Integration', 'Social Commerce', 'Accounting Sync'],
                    featured: false,
                    author: 'XI-IO Solutions'
                },
                {
                    name: 'SaaS Growth Engine',
                    description: 'The ultimate stack for software companies. Subscription billing, CRM, and analytics.',
                    category: 'automation_pack',
                    provider_type: 'official',
                    price_amount: 2499,
                    pricing_type: 'one_time',
                    features: ['Subscription Management', 'CRM Implementation', 'Auth Flows', 'Data Warehouse'],
                    featured: false,
                    author: 'XI-IO Solutions'
                }
            ];

            let hasChanges = false;
            for (const pack of PACKS) {
                const existing = currentItems.find(i => i.name === pack.name);
                if (!existing) {
                    await base44.entities.MarketplaceItem.create(pack);
                    hasChanges = true;
                } else {
                    // Enforce Updates (Provider, Description, Features, etc)
                    if (existing.pricing_type !== pack.pricing_type || 
                       existing.price_amount !== pack.price_amount ||
                       existing.description !== pack.description ||
                       existing.provider_type !== pack.provider_type) {
                        await base44.entities.MarketplaceItem.update(existing.id, {
                            pricing_type: pack.pricing_type,
                            price_amount: pack.price_amount,
                            features: pack.features,
                            description: pack.description,
                            provider_type: pack.provider_type,
                            category: pack.category // Ensure category update for new integrations
                        });
                        hasChanges = true;
                    }
                }
            }
            if (hasChanges) queryClient.invalidateQueries(['marketplace_items']);
        };

        seedValuePacks();
    }, []);

    const { data: reviews = [] } = useQuery({
        queryKey: ['marketplace_reviews', selectedItem?.id],
        queryFn: () => selectedItem ? base44.entities.MarketplaceReview.list() : [], // In a real app we'd filter by item_id
        enabled: !!selectedItem,
        select: (data) => data.filter(r => r.item_id === selectedItem?.id)
    });

    const reviewMutation = useMutation({
        mutationFn: async (reviewData) => {
            const user = await base44.auth.me().catch(() => ({ email: 'anonymous@user.com', full_name: 'Anonymous' }));
            
            // 1. Create the review
            await base44.entities.MarketplaceReview.create({
                ...reviewData,
                user_email: user.email,
                author_name: user.full_name || user.email.split('@')[0]
            });

            // 2. Update item rating (simplified average calculation)
            // In a real backend this would be an aggregation, here we do a rough update
            const newRating = ((selectedItem.rating || 5) * (selectedItem.review_count || 1) + reviewData.rating) / ((selectedItem.review_count || 1) + 1);
            
            await base44.entities.MarketplaceItem.update(selectedItem.id, {
                rating: parseFloat(newRating.toFixed(1)),
                review_count: (selectedItem.review_count || 0) + 1
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['marketplace_reviews']);
            queryClient.invalidateQueries(['marketplace_items']);
            setShowReviewForm(false);
            toast.success("Review submitted successfully");
        }
    });

    const installMutation = useMutation({
        mutationFn: async ({ item, tierName }) => {
            // 0. Check for existing installation
            const existing = await base44.entities.InstalledAddon.list();
            const isInstalled = existing.find(i => i.addon_id === item.id);
            if (isInstalled) {
                // Return existing if already installed to prevent duplicates
                // We could also update the tier here if needed
                return { item, tierName };
            }

            // 1. Create InstalledAddon record (The Registry)
            const installation = await base44.entities.InstalledAddon.create({
                addon_id: item.id,
                version: item.version || '1.0.0',
                status: 'provisioning',
                installed_tier: tierName,
                config: {
                    tier: tierName,
                    installed_at: new Date().toISOString()
                }
            });
            
            // 2. Trigger the Installer Agent (The Automation)
            // This backend function handles the actual provisioning logic
            try {
                await base44.functions.invoke('addonInstaller', { 
                    installed_addon_id: installation.id 
                });
            } catch (e) {
                console.error("Installer agent failed to trigger:", e);
                // We don't fail the UI flow, as the background process might retry
            }

            return { item, tierName };
        },
        onSuccess: ({ item, tierName }) => {
            queryClient.invalidateQueries(['marketplace_items']);
            queryClient.invalidateQueries(['installed_addons']);
            
            // Trigger Ghost Console
            setConsoleActive(true);
            setConsoleLogs([{ message: `INITIATING_SEQUENCE: ${item.name}`, type: 'info' }]);
            
            // Simulate Logs
            const steps = [
                "resolving_dependencies...",
                "fetching_manifest...",
                "allocating_resources...",
                "injecting_secrets...",
                `provisioning_${item.category}...`,
                "verifying_integrity...",
                "COMPLETE"
            ];
            
            steps.forEach((step, i) => {
                setTimeout(() => {
                    setConsoleLogs(prev => [...prev, { message: `> ${step}`, type: step === 'COMPLETE' ? 'success' : 'info' }]);
                    if (step === 'COMPLETE') {
                        setTimeout(() => setConsoleActive(false), 2000);
                        toast.success(`${item.name} installation complete.`);
                    }
                }, (i + 1) * 800);
            });
        }
    });

    const filtered = enrichedItems.filter(i => {
        const matchesFilter = (i.name || '').toLowerCase().includes(filter.toLowerCase());
        
        // Category Filter
        const matchesTab = activeTab === 'all' 
            ? true 
            : activeTab === 'featured' 
                ? i.featured 
                : i.category === activeTab;
        
        // Provider Filter
        const matchesProvider = providerFilter === 'all' 
            ? true 
            : i.provider_type === providerFilter || (providerFilter === 'partner' && i.category === 'integration');

        return matchesFilter && matchesTab && matchesProvider;
    });

    const featuredItems = enrichedItems.filter(i => i.featured).slice(0, 3);

    const categories = [
        { id: 'all', label: 'All', icon: Box },
        { id: 'featured', label: 'Featured', icon: Star },
        { id: 'integration', label: 'Integrations', icon: Plug },
        { id: 'module', label: 'Modules', icon: Zap },
        { id: 'automation_pack', label: 'Value Packs', icon: Package },
        { id: 'ai_model', label: 'AI Models', icon: Brain },
        { id: 'distro', label: 'OS / Distros', icon: Cpu },
        { id: 'browser', label: 'Browsers', icon: Globe },
        { id: 'theme', label: 'Themes', icon: Palette },
        { id: 'service', label: 'Services', icon: Briefcase },
    ];

    const providers = [
        { id: 'all', label: 'All Providers' },
        { id: 'official', label: 'Official System' },
        { id: 'partner', label: 'Verified Partners' },
        { id: 'community', label: 'Community' }
    ];

    const getPriceDisplay = (item) => {
        if (item.pricing_type === 'free') return 'FREE';
        if (item.pricing_type === 'contact') return 'CONTACT';
        if (item.price_display) return item.price_display;
        return item.price_amount ? `$${item.price_amount}` : 'PAID';
    };

    const handleAction = (item, tierName = null) => {
        if (!user) {
            toast.error("Please login to install items");
            base44.auth.redirectToLogin();
            return;
        }

        // Redirect integrations to the Connection Flow
        if (item.category === 'integration') {
            toast("Integration Setup Required", {
                description: `To connect ${item.name}, please ask the AI Assistant: "Connect ${item.name}"`,
                action: {
                    label: "Go to Dashboard",
                    onClick: () => window.location.href = createPageUrl('IntegrationDashboard')
                }
            });
            return;
        }
        if (item.pricing_type === 'contact') {
            toast.success("Sales team notified. We will contact you shortly.");
            return;
        }
        
        // Check for Paid Items
        if (item.pricing_type !== 'free' && item.price_amount > 0) {
            setPendingItem({ item, tierName });
            setPaymentModalOpen(true);
            return;
        }
        
        installMutation.mutate({ item, tierName });
    };
    
    const handlePaymentSuccess = () => {
        if (pendingItem) {
            installMutation.mutate({ item: pendingItem.item, tierName: pendingItem.tierName });
            setPaymentModalOpen(false);
            setPendingItem(null);
            toast.success("Payment successful! Provisioning license...");
        }
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <SmartErrorBoundary>
                        <Quadrant type="orientation" step="1" title="Bazaar" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <ShoppingBag className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">SYSTEM BAZAAR</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Commercial Matrix</IntentText>
                                </div>
                            </div>

                            <GuideBox title="Build Your Server Stack">
                                <p className="mb-2">
                                    Architect your custom runtime. Select <TermHelper term="Kernel Modules" definition="AI Models, Value Packs, and System Extensions." /> to power your node.
                                </p>
                                <ul className="list-disc list-inside space-y-1 opacity-80 text-xs">
                                    <li><strong>Value Packs</strong>: Turnkey business logic bundles.</li>
                                    <li><strong>Modules</strong>: Binary extensions for your future kernel.</li>
                                </ul>
                            </GuideBox>

                            <SystemStats 
                            className="grid-cols-2"
                            stats={[
                            { label: "Catalog Size", value: items.length, icon: Box, color: "text-white" },
                            { label: "Acquired", value: installations.length, icon: Download, color: "text-[hsl(var(--color-execution))]" }
                            ]}
                            />

                            <div className="mt-6">
                                <Button 
                                    onClick={() => setIsCreating(true)} 
                                    className="w-full font-bold h-10 text-xs tracking-widest bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                                >
                                    <Plus className="w-3 h-3 mr-2" /> SELL ITEM
                                </Button>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Catalog" className="flex flex-col p-4 border-t-0 rounded-t-none" scrollable={false}>
                            <div className="space-y-4 mb-4">
                                <div className="relative">
                                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                                    <Input 
                                        placeholder="Search catalog..." 
                                        className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs focus-visible:ring-[hsl(var(--color-intent))]"
                                        value={filter}
                                        onChange={(e) => setFilter(e.target.value)}
                                    />
                                    <Button 
                                        size="sm" 
                                        variant="ghost" 
                                        className={cn("absolute right-1 top-1 h-7 px-2 text-[10px] gap-1", showSmartSuggestions ? "text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10" : "text-neutral-500")}
                                        onClick={() => setShowSmartSuggestions(!showSmartSuggestions)}
                                    >
                                        <Brain className="w-3 h-3" />
                                        Smart Match
                                    </Button>
                                </div>
                                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                                    <TabsList className="w-full justify-start bg-transparent p-0 gap-2 h-auto flex-wrap">
                                        {categories.map(cat => (
                                            <TabsTrigger 
                                                key={cat.id} 
                                                value={cat.id}
                                                className="data-[state=active]:bg-[hsl(var(--color-intent))] data-[state=active]:text-white text-xs border border-white/10 bg-neutral-900 px-3 py-1.5 h-auto rounded-full transition-all"
                                            >
                                                <cat.icon className="w-3 h-3 mr-1.5" />
                                                {cat.label}
                                            </TabsTrigger>
                                        ))}
                                    </TabsList>
                                </Tabs>

                                {/* Provider Filter */}
                                <div className="flex gap-2 pt-2 border-t border-white/5 mt-2 overflow-x-auto pb-1 scrollbar-none">
                                    {providers.map(prov => (
                                        <button
                                            key={prov.id}
                                            onClick={() => setProviderFilter(prov.id)}
                                            className={cn(
                                                "text-[10px] px-2 py-1 rounded transition-colors whitespace-nowrap",
                                                providerFilter === prov.id 
                                                    ? "bg-white/10 text-white font-medium" 
                                                    : "text-neutral-500 hover:text-neutral-300"
                                            )}
                                        >
                                            {prov.label}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div className="flex-1 overflow-y-auto space-y-2 p-2 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {showSmartSuggestions && (
                                <div className="mb-4 p-4 bg-[hsl(var(--color-execution))]/5 border border-[hsl(var(--color-execution))]/20 rounded-lg animate-in fade-in slide-in-from-top-2 relative overflow-hidden">
                                    {/* Scanning Effect */}
                                    <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,150,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,150,0.05)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />

                                    <div className="flex items-center justify-between mb-3 relative z-10">
                                        <div className="flex items-center gap-2">
                                            <Brain className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                            <StateText className="text-[hsl(var(--color-execution))] text-xs font-bold tracking-wider">PROJECT PATTERN RECOGNITION</StateText>
                                        </div>
                                        <Badge variant="outline" className="border-[hsl(var(--color-execution))]/30 text-[hsl(var(--color-execution))] text-[9px] bg-[hsl(var(--color-execution))]/10">MATCH: 98%</Badge>
                                    </div>

                                    <p className="text-[10px] text-neutral-400 mb-4 leading-relaxed max-w-sm relative z-10">
                                        Analyzed your codebase (React/CRM/Finance). Based on your architecture, adding these modules will increase system efficiency by an estimated <span className="text-white font-mono">42%</span>.
                                    </p>

                                    <div className="grid grid-cols-2 gap-2 relative z-10">
                                        {items.filter(i => ['Pipeline Hologram', 'Nexus Comms'].includes(i.name)).map(item => (
                                            <div 
                                                key={item.id} 
                                                className="flex items-center gap-3 p-2 bg-neutral-900/80 rounded border border-white/10 cursor-pointer hover:border-[hsl(var(--color-execution))] hover:bg-neutral-900 transition-all group" 
                                                onClick={() => setSelectedItem(item)}
                                            >
                                                <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center group-hover:bg-[hsl(var(--color-execution))]/20 group-hover:text-[hsl(var(--color-execution))] transition-colors">
                                                    {item.category === 'module' ? <Zap className="w-4 h-4" /> : <Package className="w-4 h-4" />}
                                                </div>
                                                <div className="min-w-0">
                                                    <div className="text-[10px] font-bold text-white truncate">{item.name}</div>
                                                    <div className="text-[9px] text-neutral-500 font-mono">{getPriceDisplay(item)} • One-Time</div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                )}
                                {activeTab === 'all' && !filter && featuredItems.length > 0 && (
                                    <div className="mb-6">
                                        <div className="flex items-center gap-2 mb-3 px-1">
                                            <Star className="w-3 h-3 text-[hsl(var(--color-warning))]" />
                                            <StateText className="text-[10px] uppercase tracking-wider opacity-70">Featured Items</StateText>
                                        </div>
                                        <div className="grid grid-cols-1 gap-3">
                                            {featuredItems.map(item => (
                                                <SystemCard
                                                    key={item.id}
                                                    title={item.name}
                                                    subtitle={item.description}
                                                    status="active"
                                                    metric={getPriceDisplay(item)}
                                                    active={selectedItem?.id === item.id}
                                                    onClick={() => setSelectedItem(item)}
                                                    icon={Star}
                                                    className="border-[hsl(var(--color-intent))]/30"
                                                >
                                                    <div className="mt-2 flex justify-between items-center mb-3">
                                                        <Badge className="bg-[hsl(var(--color-execution))] text-black text-[9px] h-4">FEATURED</Badge>
                                                        <div className="flex items-center gap-1 text-[hsl(var(--color-warning))] text-[10px]">
                                                            <Star className="w-3 h-3 fill-current" />
                                                            <span className="font-mono">{item.rating || '5.0'}</span>
                                                        </div>
                                                    </div>
                                                    <ActionDock 
                                                        primaryAction={{
                                                            label: "View Deal",
                                                            icon: Star,
                                                            onClick: (e) => {
                                                                e.stopPropagation();
                                                                setSelectedItem(item);
                                                            }
                                                        }}
                                                        secondaryActions={[
                                                            {
                                                                label: "Get It",
                                                                icon: Download,
                                                                onClick: (e) => {
                                                                    e.stopPropagation();
                                                                    handleAction(item);
                                                                }
                                                            }
                                                        ]}
                                                    />
                                                </SystemCard>
                                            ))}
                                        </div>
                                        <div className="h-px bg-white/5 my-4" />
                                    </div>
                                )}

                                {filtered.length === 0 && (
                                    <div className="text-center py-12 border border-dashed border-white/5 rounded flex flex-col items-center opacity-50 m-2">
                                        <Search className="w-8 h-8 text-neutral-600 mb-2" />
                                        <StateText>No items found</StateText>
                                    </div>
                                )}
                                {filtered.map((item) => (
                                <SystemCard
                                    key={item.id}
                                    title={item.name}
                                    subtitle={item.author}
                                    status={item.installed ? 'execution' : 'settled'}
                                    metric={getPriceDisplay(item)}
                                    active={selectedItem?.id === item.id}
                                    onClick={() => setSelectedItem(item)}
                                    icon={
                                        item.category === 'automation_pack' ? Package :
                                        item.category === 'service' ? Briefcase :
                                        item.category === 'ai_model' ? Brain : Zap
                                    }
                                >
                                    <div className="flex gap-1 mt-1 mb-3">
                                        <Badge variant="outline" className="text-[9px] h-4 px-1 border-white/10 text-neutral-500 uppercase">{item.category?.replace('_', ' ')}</Badge>
                                        {item.provider_type === 'official' && <Badge variant="outline" className="text-[9px] h-4 px-1 border-blue-500/30 text-blue-400 bg-blue-500/10">OFFICIAL</Badge>}
                                        {item.provider_type === 'partner' && <Badge variant="outline" className="text-[9px] h-4 px-1 border-purple-500/30 text-purple-400 bg-purple-500/10">PARTNER</Badge>}
                                        {item.provider_type === 'community' && <Badge variant="outline" className="text-[9px] h-4 px-1 border-orange-500/30 text-orange-400 bg-orange-500/10">COMMUNITY</Badge>}
                                    </div>
                                    <ActionDock 
                                        primaryAction={{
                                            label: item.installed ? "Manage" : "View",
                                            icon: item.installed ? Box : ArrowRight,
                                            onClick: (e) => {
                                                e.stopPropagation();
                                                setSelectedItem(item);
                                            }
                                        }}
                                        secondaryActions={[
                                            {
                                                label: item.installed ? "Config" : (item.category === 'integration' ? "Connect" : "Install"),
                                                icon: item.installed ? Cpu : (item.category === 'integration' ? Plug : Download),
                                                onClick: (e) => {
                                                    e.stopPropagation();
                                                    if (item.installed) {
                                                        toast.info("Opening configuration...");
                                                        setSelectedItem(item);
                                                    } else {
                                                        handleAction(item);
                                                    }
                                                }
                                            }
                                        ]}
                                    />
                                </SystemCard>
                                ))}
                            </div>
                        </Quadrant>
                        </SmartErrorBoundary>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Inspector" dominance="dominant" className="h-full p-0 flex flex-col overflow-hidden border-b relative">
                            <GhostConsole active={consoleActive} logs={consoleLogs} onClose={() => setConsoleActive(false)} />
                            {selectedItem ? (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300">
                                    {/* Item Header */}
                                    <SystemDetailHeader 
                                        title={selectedItem.name}
                                        subtitle={
                                            <span className="flex items-center gap-2">
                                                Provided by {selectedItem.author || "Unknown"}
                                                {(selectedItem.author || '').includes('Seed001') && (
                                                    <Badge variant="outline" className="h-4 px-1 text-[9px] border-emerald-500/30 text-emerald-400 bg-emerald-500/10">
                                                        VERIFIED SEED
                                                    </Badge>
                                                )}
                                            </span>
                                        }
                                        category={selectedItem.sub_category || selectedItem.category}
                                        icon={
                                            selectedItem.category === 'automation_pack' ? Package :
                                            selectedItem.category === 'service' ? Briefcase :
                                            selectedItem.category === 'ai_model' ? Brain : Zap
                                        }
                                    >
                                        <div className="flex gap-2">
                                            {!selectedItem.installed && (
                                                <Button 
                                                    size="sm" 
                                                    variant="outline" 
                                                    onClick={() => handlePreviewTheme(selectedItem)}
                                                    className="h-6 text-[10px] border-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/10"
                                                >
                                                    <Palette className="w-3 h-3 mr-1" /> PREVIEW
                                                </Button>
                                            )}
                                            {selectedItem.installed && (
                                                <Badge className="bg-[hsl(var(--color-execution))] text-black">INSTALLED</Badge>
                                            )}
                                        </div>
                                    </SystemDetailHeader>

                                    <div className="px-8 pb-8 relative z-10">

                                            {/* Service Mode Selection (Visible for Value Packs and Modules) */}
                                            {!selectedItem.installed && (selectedItem.category === 'automation_pack' || selectedItem.category === 'module') && (
                                                <div className="mt-8 mb-6 bg-neutral-900/50 rounded-xl p-1 border border-white/5 flex relative">
                                                    <button
                                                        onClick={() => setServiceMode('diy')}
                                                        className={cn(
                                                            "flex-1 flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-medium transition-all relative z-10",
                                                            serviceMode === 'diy' 
                                                                ? "text-white shadow-sm" 
                                                                : "text-neutral-500 hover:text-neutral-300"
                                                        )}
                                                    >
                                                        <Cpu className="w-4 h-4" />
                                                        Standard Access
                                                    </button>
                                                    <button
                                                        onClick={() => setServiceMode('concierge')}
                                                        className={cn(
                                                            "flex-1 flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-medium transition-all relative z-10",
                                                            serviceMode === 'concierge' 
                                                                ? "text-black shadow-sm" 
                                                                : "text-neutral-500 hover:text-neutral-300"
                                                        )}
                                                    >
                                                        <Briefcase className="w-4 h-4" />
                                                        Concierge Service
                                                    </button>

                                                    {/* Sliding Background */}
                                                    <div className={cn(
                                                        "absolute top-1 bottom-1 w-[calc(50%-4px)] rounded-lg transition-all duration-300",
                                                        serviceMode === 'diy' ? "left-1 bg-[hsl(var(--color-intent))]" : "left-[calc(50%+4px)] bg-[hsl(var(--color-execution))]"
                                                    )} />
                                                </div>
                                            )}

                                            {serviceMode === 'concierge' && !selectedItem.installed ? (
                                                <div className="mt-6 p-6 rounded-xl bg-[hsl(var(--color-execution))]/5 border border-[hsl(var(--color-execution))]/20 space-y-4 animate-in fade-in slide-in-from-bottom-2">
                                                    <div className="flex items-start gap-4">
                                                        <div className="p-2 rounded-lg bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))]">
                                                            <Briefcase className="w-6 h-6" />
                                                        </div>
                                                        <div>
                                                            <h4 className="text-white font-bold mb-1">Managed Service Subscription</h4>
                                                            <p className="text-xs text-neutral-400 leading-relaxed">
                                                                Don't want to manage this yourself? Subscribe to our Concierge Service. We handle installation, updates, and optimization so you can focus on strategy.
                                                            </p>
                                                        </div>
                                                    </div>

                                                    <ul className="space-y-2 my-4">
                                                        {[
                                                            'Professional Implementation Strategy',
                                                            'Custom Configuration & Integration',
                                                            'Security Audit & Optimization',
                                                            '30 Days of Priority Support'
                                                        ].map((item, i) => (
                                                            <li key={i} className="flex items-center gap-2 text-xs text-neutral-300">
                                                                <Check className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                                                                {item}
                                                            </li>
                                                        ))}
                                                    </ul>

                                                    <Button 
                                                        size="lg"
                                                        className="w-full font-bold bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                                                        onClick={() => {
                                                            setServiceRequestModalOpen(true);
                                                            setRequestType(selectedItem.category === 'automation_pack' ? 'bundle' : 'integration');
                                                        }}
                                                    >
                                                        Request Expert Setup • From $499
                                                    </Button>
                                                </div>
                                            ) : (
                                                <div className="mt-6">
                                                    {selectedItem.pricing_type === 'tiered' && selectedItem.tiers ? (
                                                        <div className="space-y-4">
                                                            <OrientingText className="text-neutral-500 text-xs">SELECT A PLAN</OrientingText>
                                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                                {selectedItem.tiers.map((tier, idx) => (
                                                                    <div key={idx} className="p-4 rounded-lg bg-neutral-900/50 border border-white/5 hover:border-[hsl(var(--color-intent))] transition-colors flex flex-col">
                                                                        <div className="flex justify-between items-start mb-2">
                                                                            <IntentText className="font-bold text-lg text-white">{tier.name}</IntentText>
                                                                            <StateText className="text-[hsl(var(--color-execution))] font-mono">{tier.price_display}</StateText>
                                                                        </div>
                                                                        <p className="text-xs text-neutral-400 mb-4 flex-1">{tier.description}</p>
                                                                        {tier.features && (
                                                                            <ul className="space-y-1 mb-4">
                                                                                {tier.features.map((f, i) => (
                                                                                    <li key={i} className="text-[10px] text-neutral-500 flex items-center gap-2">
                                                                                        <div className="w-1 h-1 rounded-full bg-white/20" /> {f}
                                                                                    </li>
                                                                                ))}
                                                                            </ul>
                                                                        )}
                                                                        <Button 
                                                                        size="sm" 
                                                                        className={cn(
                                                                            "w-full",
                                                                            selectedItem.installed && selectedItem.installed_tier === tier.name
                                                                                ? "bg-neutral-800 text-neutral-400 border border-white/10"
                                                                                : "bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white"
                                                                        )}
                                                                        onClick={() => handleAction(selectedItem, tier.name)}
                                                                        disabled={selectedItem.installed && selectedItem.installed_tier === tier.name}
                                                                        >
                                                                        {selectedItem.installed && selectedItem.installed_tier === tier.name 
                                                                            ? 'Current Plan' 
                                                                            : (selectedItem.installed ? 'Switch Plan' : (tier.button_text || 'Select Plan'))}
                                                                        </Button>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    ) : (
                                                        <div className="flex items-center gap-4">
                                                            <Button 
                                                                size="lg"
                                                                className={cn(
                                                                    "flex-1 font-bold tracking-wide shadow-lg transition-all hover:scale-[1.02]",
                                                                    selectedItem.installed 
                                                                        ? 'bg-neutral-800 text-neutral-400 cursor-not-allowed border border-white/5' 
                                                                        : 'bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90 border border-white/10'
                                                                )}
                                                                disabled={selectedItem.installed && selectedItem.pricing_type !== 'subscription'}
                                                                onClick={() => handleAction(selectedItem)}
                                                            >
                                                                {selectedItem.installed && selectedItem.pricing_type !== 'subscription' 
                                                                    ? 'LICENSE OWNED' 
                                                                    : (
                                                                    <>
                                                                        {selectedItem.pricing_type === 'contact' ? <CreditCard className="w-4 h-4 mr-2" /> : <Download className="w-4 h-4 mr-2" />}
                                                                        {selectedItem.pricing_type === 'contact' ? 'CONTACT SALES' : 
                                                                        selectedItem.installed ? 'MANAGE SUBSCRIPTION' :
                                                                        selectedItem.pricing_type === 'one_time' ? `BUY LICENSE • ${getPriceDisplay(selectedItem)}` :
                                                                        `GET ACCESS • ${getPriceDisplay(selectedItem)}`}
                                                                    </>
                                                                )}
                                                            </Button>
                                                            <div className="flex flex-col items-end px-4 border-l border-white/10">
                                                                <div className="flex items-center gap-1 text-[hsl(var(--color-warning))]">
                                                                    <Star className="w-4 h-4 fill-current" />
                                                                    <span className="font-mono font-bold text-lg">{selectedItem.rating || 'New'}</span>
                                                                </div>
                                                                <span className="text-[9px] text-neutral-500 uppercase tracking-wider">Rating</span>
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            )}
                                        </div>

                                    {/* Item Content */}
                                    <div className="p-8 space-y-8 overflow-y-auto bg-transparent flex-1">
                                        <Layer level="state" className="p-6">
                                            <OrientingText className="mb-3 text-[hsl(var(--color-intent))]">OVERVIEW</OrientingText>
                                            <AtomicParagraph className="text-neutral-300 text-sm leading-relaxed">{selectedItem.description}</AtomicParagraph>
                                        </Layer>

                                        {selectedItem.features && selectedItem.features.length > 0 && (
                                            <div>
                                                <OrientingText className="mb-4 text-neutral-500">CAPABILITIES</OrientingText>
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                    {selectedItem.features.map((feature, i) => (
                                                        <div key={i} className="flex items-start gap-3 p-3 rounded bg-neutral-900/30 border border-white/5">
                                                            <Check className="w-4 h-4 text-[hsl(var(--color-execution))] mt-0.5 shrink-0" />
                                                            <span className="text-xs text-neutral-300">{feature}</span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
                                            <div className="p-4 bg-neutral-900/20 rounded border border-white/5">
                                                <StateText className="mb-1 text-neutral-500">License Type</StateText>
                                                <IntentText className="capitalize">{selectedItem.pricing_type?.replace('_', ' ') || 'Standard'}</IntentText>
                                            </div>
                                            <div className="p-4 bg-neutral-900/20 rounded border border-white/5">
                                            <StateText className="mb-1 text-neutral-500">Support Level</StateText>
                                            <IntentText>{selectedItem.category === 'service' ? 'Dedicated Agent' : 'Standard'}</IntentText>
                                            </div>
                                            </div>

                                            {/* Value Chain / Royalty Viz */}
                                            <div className="pt-6 border-t border-white/5">
                                                <HallbergmathsAudit item={selectedItem} />
                                            </div>

                                            {/* Reviews Section */}
                                            <div className="pt-6 border-t border-white/5">
                                            <div className="flex items-center justify-between mb-4">
                                                <OrientingText className="text-[hsl(var(--color-intent))]">REVIEWS ({selectedItem.review_count || reviews.length})</OrientingText>
                                                <Button 
                                                    size="sm" 
                                                    variant="ghost" 
                                                    className="text-xs h-7"
                                                    onClick={() => setShowReviewForm(!showReviewForm)}
                                                >
                                                    Write a Review
                                                </Button>
                                            </div>

                                            {showReviewForm && (
                                                <form 
                                                    className="mb-6 p-4 rounded bg-neutral-900/50 border border-white/10 space-y-3 animate-in fade-in slide-in-from-top-2"
                                                    onSubmit={(e) => {
                                                        e.preventDefault();
                                                        const formData = new FormData(e.target);
                                                        reviewMutation.mutate({
                                                            item_id: selectedItem.id,
                                                            rating: Number(formData.get('rating')),
                                                            comment: formData.get('comment')
                                                        });
                                                    }}
                                                >
                                                    <div className="space-y-1">
                                                        <StateText className="text-xs">Rating</StateText>
                                                        <div className="flex gap-2">
                                                            {[1, 2, 3, 4, 5].map((star) => (
                                                                <label key={star} className="cursor-pointer">
                                                                    <input type="radio" name="rating" value={star} className="sr-only peer" required />
                                                                    <Star className="w-5 h-5 text-neutral-700 peer-checked:text-[hsl(var(--color-warning))] peer-checked:fill-[hsl(var(--color-warning))] hover:text-[hsl(var(--color-warning))]/50 transition-colors" />
                                                                </label>
                                                            ))}
                                                        </div>
                                                    </div>
                                                    <div className="space-y-1">
                                                        <StateText className="text-xs">Comment</StateText>
                                                        <textarea 
                                                            name="comment" 
                                                            required
                                                            className="w-full bg-neutral-950 border border-white/10 rounded p-2 text-xs text-neutral-200 focus:outline-none focus:border-[hsl(var(--color-intent))]"
                                                            rows={3}
                                                            placeholder="Share your experience..."
                                                        />
                                                    </div>
                                                    <div className="flex justify-end gap-2">
                                                        <Button type="button" variant="ghost" size="sm" onClick={() => setShowReviewForm(false)}>Cancel</Button>
                                                        <Button type="submit" size="sm" className="bg-[hsl(var(--color-intent))] text-white">Submit Review</Button>
                                                    </div>
                                                </form>
                                            )}

                                            <div className="space-y-4">
                                                {reviews.length === 0 ? (
                                                    <div className="text-center py-8 opacity-50">
                                                        <MessageSquare className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                                                        <StateText>No reviews yet. Be the first!</StateText>
                                                    </div>
                                                ) : (
                                                    reviews.map((review) => (
                                                        <div key={review.id} className="p-4 rounded bg-neutral-900/20 border border-white/5">
                                                            <div className="flex justify-between items-start mb-2">
                                                                <div className="flex items-center gap-2">
                                                                    <div className="w-6 h-6 rounded-full bg-neutral-800 flex items-center justify-center text-[10px] font-bold">
                                                                        {review.author_name?.[0] || 'U'}
                                                                    </div>
                                                                    <div>
                                                                        <div className="text-xs font-medium text-white">{review.author_name || 'Anonymous'}</div>
                                                                        <div className="flex text-[hsl(var(--color-warning))] text-[10px]">
                                                                            {[...Array(5)].map((_, i) => (
                                                                                <Star key={i} className={cn("w-2.5 h-2.5", i < review.rating ? "fill-current" : "text-neutral-800 fill-none")} />
                                                                            ))}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <StateText className="text-[10px] opacity-40">
                                                                    {new Date(review.created_date || Date.now()).toLocaleDateString()}
                                                                </StateText>
                                                            </div>
                                                            <p className="text-xs text-neutral-400 leading-relaxed">{review.comment}</p>
                                                        </div>
                                                    ))
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="h-full flex flex-col p-6">
                                    <div className="mb-6">
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <OrientingText className="text-[hsl(var(--color-intent))] mb-2">SYSTEM BAZAAR</OrientingText>
                                                <IntentText className="text-3xl font-light">Ecosystem Hub</IntentText>
                                            </div>
                                            <div className="flex gap-2">
                                                <Badge variant="outline" className="border-white/10 text-neutral-500">{items.length} Modules</Badge>
                                            </div>
                                        </div>
                                        <p className="text-sm text-neutral-400 mt-2 max-w-md">
                                            Expand your system's capabilities with verified integrations, community modules, and official expansion packs.
                                        </p>
                                    </div>

                                    <div className="flex-1 overflow-y-auto space-y-8 pr-2 pb-10">
                                        {/* Featured Integrations (Partner) */}
                                        <div className="space-y-3">
                                            <div className="flex items-center justify-between border-b border-white/5 pb-2">
                                                <StateText className="text-xs font-bold tracking-widest text-neutral-400">VERIFIED PARTNERS</StateText>
                                                <Badge variant="outline" className="text-[9px] border-[hsl(var(--color-intent))]/30 text-[hsl(var(--color-intent))] bg-[hsl(var(--color-intent))]/5">OFFICIAL INTEGRATIONS</Badge>
                                            </div>
                                            <div className="grid grid-cols-2 lg:grid-cols-2 gap-3">
                                                {enrichedItems.filter(i => i.provider_type === 'partner').slice(0, 10).map(item => (
                                                    <div 
                                                        key={item.id}
                                                        onClick={() => setSelectedItem(item)}
                                                        className="p-3 bg-neutral-900/40 border border-white/5 rounded-lg hover:bg-neutral-800 hover:border-[hsl(var(--color-intent))]/50 transition-all cursor-pointer group flex items-start gap-3"
                                                    >
                                                        <div className="w-10 h-10 rounded-md bg-white p-1.5 shrink-0 flex items-center justify-center overflow-hidden">
                                                            {item.integration_logo ? (
                                                                <img src={item.integration_logo} alt={item.name} className="w-full h-full object-contain" />
                                                            ) : (
                                                                <Plug className="w-5 h-5 text-neutral-800" />
                                                            )}
                                                        </div>
                                                        <div className="min-w-0">
                                                            <div className="text-xs font-bold text-white truncate mb-0.5 group-hover:text-[hsl(var(--color-intent))] transition-colors">{item.name}</div>
                                                            <div className="text-[10px] text-neutral-500 truncate">{item.sub_category}</div>
                                                            <div className="flex items-center gap-1 mt-1.5">
                                                                <Star className="w-2.5 h-2.5 text-[hsl(var(--color-warning))] fill-current" />
                                                                <span className="text-[9px] text-neutral-400">{item.rating}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        {/* Official System Modules */}
                                        <div className="space-y-3">
                                            <div className="flex items-center justify-between border-b border-white/5 pb-2">
                                                <StateText className="text-xs font-bold tracking-widest text-neutral-400">SYSTEM MODULES</StateText>
                                                <Badge variant="outline" className="text-[9px] border-blue-500/30 text-blue-400 bg-blue-500/5">NATIVE</Badge>
                                            </div>
                                            <div className="grid grid-cols-1 gap-2">
                                                {enrichedItems.filter(i => i.provider_type === 'official' && i.category !== 'automation_pack').slice(0, 4).map(item => (
                                                    <div 
                                                        key={item.id}
                                                        onClick={() => setSelectedItem(item)}
                                                        className="flex items-center gap-4 p-3 bg-blue-950/10 border border-blue-900/20 rounded-lg hover:border-blue-500/50 cursor-pointer transition-colors"
                                                    >
                                                        <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 shrink-0">
                                                            <Zap className="w-4 h-4" />
                                                        </div>
                                                        <div className="flex-1 min-w-0">
                                                            <div className="text-sm font-medium text-white">{item.name}</div>
                                                            <div className="text-xs text-blue-200/50 truncate">{item.description}</div>
                                                        </div>
                                                        <div className="text-xs font-mono text-blue-300">{getPriceDisplay(item)}</div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        {/* Community Picks */}
                                        <div className="space-y-3">
                                            <div className="flex items-center justify-between border-b border-white/5 pb-2">
                                                <StateText className="text-xs font-bold tracking-widest text-neutral-400">COMMUNITY PICKS</StateText>
                                                <Badge variant="outline" className="text-[9px] border-orange-500/30 text-orange-400 bg-orange-500/5">RISING STARS</Badge>
                                            </div>
                                            <div className="grid grid-cols-2 gap-3">
                                                {enrichedItems.filter(i => i.provider_type === 'community').slice(0, 4).map(item => (
                                                    <div 
                                                        key={item.id}
                                                        onClick={() => setSelectedItem(item)}
                                                        className="p-3 bg-neutral-900/30 border border-white/5 rounded hover:bg-neutral-800 cursor-pointer"
                                                    >
                                                        <div className="flex justify-between items-start mb-2">
                                                            <div className="w-6 h-6 rounded bg-orange-500/10 flex items-center justify-center text-orange-400 text-[10px] font-bold">
                                                                {item.author?.[0] || '?'}
                                                            </div>
                                                            <Badge variant="secondary" className="text-[8px] h-3.5 bg-white/5 text-neutral-400">{item.category}</Badge>
                                                        </div>
                                                        <div className="text-xs font-bold text-white mb-1">{item.name}</div>
                                                        <div className="text-[9px] text-neutral-500">by {item.author}</div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Summary" dominance="supporting" className="border-t-0 rounded-t-none">
                             <div className="p-3 bg-neutral-900 rounded border border-white/5 flex items-center justify-between">
                                <span className="text-xs text-neutral-400">Items Available</span>
                                <Badge className="bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] border-0">
                                    {filtered.length}
                                </Badge>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
            <ServiceRequestModal 
                open={serviceRequestModalOpen}
                onOpenChange={setServiceRequestModalOpen}
                item={selectedItem ? { ...selectedItem, price: getPriceDisplay(selectedItem) } : null}
                type={requestType}
            />
            <CreateListingModal 
                open={isCreating}
                onOpenChange={setIsCreating}
            />
            <PaymentModal 
                open={paymentModalOpen}
                onOpenChange={setPaymentModalOpen}
                item={pendingItem?.item}
                onSuccess={handlePaymentSuccess}
            />

            {previewItem && (
                <BrowserWindow
                    isOpen={!!previewItem}
                    onClose={() => setPreviewItem(null)}
                    title={`Preview: ${previewItem.name}`}
                    defaultUrl={`http://marketplace.base44.io/item/${previewItem.id}`}
                    viewState="windowed"
                    variant="browser"
                    initialStage={systemStage}
                >
                    <div className="h-full w-full bg-[#050505] text-white flex items-center justify-center p-8 relative overflow-hidden">
                        {/* Ambient FX */}
                        {systemStage >= 3 && (
                            <>
                                <div className="absolute top-0 right-0 w-full h-full bg-[radial-gradient(circle_at_top_right,hsl(var(--color-intent))/10_0%,transparent_50%)] pointer-events-none" />
                                <div className="absolute bottom-0 left-0 w-full h-full bg-[radial-gradient(circle_at_bottom_left,hsl(var(--color-execution))/10_0%,transparent_50%)] pointer-events-none" />
                            </>
                        )}

                        <div className="text-center max-w-2xl space-y-8 relative z-10">
                            <div className="w-24 h-24 bg-white/5 rounded-3xl mx-auto flex items-center justify-center text-4xl border border-white/10 shadow-2xl backdrop-blur-md">
                                {previewItem.category === 'module' ? '⚡️' : '📦'}
                            </div>
                            
                            <div>
                                <h1 className="text-5xl font-bold text-white mb-2 tracking-tight">{previewItem.name}</h1>
                                <p className="text-xl text-neutral-400 leading-relaxed max-w-lg mx-auto">{previewItem.description}</p>
                            </div>
                            
                            <div className="p-8 bg-white/5 rounded-2xl border border-white/10 text-left backdrop-blur-md shadow-xl">
                                <h3 className="font-bold text-neutral-300 mb-6 text-xs uppercase tracking-widest flex items-center gap-2">
                                    <Package className="w-4 h-4" /> Package Manifest
                                </h3>
                                <ul className="grid grid-cols-2 gap-4">
                                    {previewItem.features?.map((f, i) => (
                                        <li key={i} className="flex items-center gap-3 text-sm text-neutral-300">
                                            <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-intent))]" />
                                            {f}
                                        </li>
                                    ))}
                                </ul>
                            </div>

                            <div className="flex gap-4 justify-center pt-4">
                                <Button variant="ghost" onClick={() => setPreviewItem(null)} className="text-neutral-400 hover:text-white hover:bg-white/5">Close Preview</Button>
                                <Button 
                                    className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 h-12 px-8 font-bold tracking-wide shadow-[0_0_20px_hsl(var(--color-intent))/30]"
                                    onClick={() => {
                                        setPreviewItem(null);
                                        handleAction(previewItem);
                                    }}
                                >
                                    Initialize Acquisition
                                </Button>
                            </div>
                        </div>
                    </div>
                </BrowserWindow>
            )}
        </div>
    );
    }