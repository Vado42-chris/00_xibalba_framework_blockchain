import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { 
    Package, Truck, Search, MapPin, Box, BarChart2, Plus
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { IntegrationStatus, ConnectPrompt } from '@/components/integrations/IntegrationComponents';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, SemanticDot 
} from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { StripeWizard } from '@/components/commerce/StripeWizard';

// OrderRow replaced by SystemCard usage in main component

const InventoryRow = ({ item }) => (
    <div className="flex items-center justify-between p-2 border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
        <div className="flex items-center gap-2">
            <Box className="w-3 h-3 text-neutral-500" />
            <StateText className="text-xs">{item.name}</StateText>
        </div>
        <div className="flex items-center gap-4">
            <StateText className="font-mono text-xs opacity-50">{item.sku}</StateText>
            <div className={cn("text-xs font-mono font-bold", item.quantity < 10 ? "text-[hsl(var(--color-error))]" : "text-[hsl(var(--color-execution))]")}>
                {item.quantity}
            </div>
        </div>
    </div>
);

export default function Commerce() {
    const [selectedOrder, setSelectedOrder] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [stripeWizardOpen, setStripeWizardOpen] = useState(false);
    const [isTestingPayment, setIsTestingPayment] = useState(false);

    const handleTestCheckout = async () => {
        setIsTestingPayment(true);
        try {
            const { url } = await base44.functions.invoke('stripe', { 
                action: 'create_checkout', 
                returnUrl: window.location.href 
            });
            if (url) {
                window.location.href = url;
            } else {
                toast.error("Checkout initialization failed - Check configuration");
            }
        } catch (e) {
            toast.error("Payment Circuit Test Failed", { description: e.message });
        } finally {
            setIsTestingPayment(false);
        }
    };

    const { data: orders = [] } = useQuery({
        queryKey: ['orders'],
        queryFn: () => base44.entities.Order.list(),
        initialData: [] 
    });

    const { data: inventory = [] } = useQuery({
        queryKey: ['inventory'],
        queryFn: () => base44.entities.InventoryItem.list(),
        initialData: []
    });

    const filteredOrders = orders.filter(o => o.id.includes(searchTerm));

    // Stats
    const totalRevenue = orders.reduce((acc, o) => acc + (o.total || 0), 0);
    const pendingOrders = orders.filter(o => o.status === 'pending').length;

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <StripeWizard 
                open={stripeWizardOpen} 
                onOpenChange={setStripeWizardOpen} 
                onConfigured={() => toast.success("Stripe Ready")}
            />
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Stats" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Truck className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">LOGISTICS GRID</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Supply Chain</IntentText>
                                </div>
                                <div className="flex gap-2">
                                    <Link to={createPageUrl('Studio') + '?mode=web&template=store'}>
                                        <Button variant="ghost" size="sm" className="h-6 text-[10px] text-[hsl(var(--color-execution))] hover:text-white hover:bg-[hsl(var(--color-execution))]/10 px-2 border border-[hsl(var(--color-execution))]/30">
                                            <Package className="w-3 h-3 mr-1" /> Store Builder
                                        </Button>
                                    </Link>
                                    <Link to={createPageUrl('Marketplace') + '?category=commerce'}>
                                        <Button variant="ghost" size="sm" className="h-6 text-[10px] text-neutral-500 hover:text-white px-2">
                                            <Plus className="w-3 h-3 mr-1" /> Addon
                                        </Button>
                                    </Link>
                                </div>
                            </div>
                            
                            <SystemStats 
                                className="grid-cols-1 md:grid-cols-1 gap-4 mb-6"
                                stats={[
                                    { label: "Your Balance", value: "$1,240.50", icon: BarChart2, color: "text-green-400" },
                                    { label: "Revenue", value: `$${totalRevenue.toLocaleString()}`, icon: Truck, color: "text-white" },
                                    { label: "Pending Orders", value: pendingOrders, icon: Package, color: "text-[hsl(var(--color-review))]" }
                                ]}
                            />
                            
                            <div className="grid grid-cols-2 gap-2 mb-6">
                                <Button 
                                    size="sm" 
                                    className="h-7 text-[10px] bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/20 border border-[hsl(var(--color-intent))]/20"
                                    onClick={() => setStripeWizardOpen(true)}
                                >
                                    Configure Payments
                                </Button>
                                <Button 
                                size="sm" 
                                className="h-7 text-[10px] bg-white/5 hover:bg-white/10 border border-white/10"
                                onClick={() => toast.success("Payout initiated to default bank account")}
                                >
                                Payout to Bank
                                </Button>
                                </div>

                                <div className="mb-6 p-4 border border-[hsl(var(--color-intent))]/20 bg-[hsl(var(--color-intent))]/5 rounded">
                                <div className="flex justify-between items-center mb-2">
                                <StateText className="font-bold text-[hsl(var(--color-intent))]">PAYMENT CIRCUIT TEST</StateText>
                                <Badge variant="outline" className="text-[10px] border-[hsl(var(--color-intent))]/30 text-[hsl(var(--color-intent))]">
                                    PHASE BRAVO
                                </Badge>
                                </div>
                                <p className="text-[10px] text-neutral-400 mb-3">
                                Initiate a test subscription to validate the payment gateway integration.
                                </p>
                                <Button 
                                size="sm" 
                                className="w-full h-8 text-xs bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90"
                                onClick={handleTestCheckout}
                                disabled={isTestingPayment}
                                >
                                {isTestingPayment ? "Initializing..." : "Test Subscription Checkout"}
                                </Button>
                                </div>

                                <ConnectPrompt category="commerce" title="Sync Store" description="Connect Shopify or WooCommerce." />
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Orders" className="p-0 flex flex-col border-t-0 rounded-t-none">
                            <div className="mb-4 relative shrink-0 p-3 pb-0">
                                <Search className="absolute left-5 top-5 h-4 w-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search order ID..." 
                                    className="pl-8 bg-neutral-950/50 border-white/10 h-9 text-xs"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-1 px-3 pb-3 scrollbar-thin scrollbar-thumb-white/5">
                                {filteredOrders.length === 0 && (
                                    <div className="text-center py-6 border border-dashed border-white/5 rounded flex flex-col items-center">
                                        <Package className="w-8 h-8 text-neutral-600 mb-2 opacity-50" />
                                        <StateText className="opacity-50">No active orders</StateText>
                                    </div>
                                )}
                                {filteredOrders.map(order => (
                                    <SystemCard
                                        key={order.id}
                                        title={order.id}
                                        subtitle={order.customer_name || "Guest"}
                                        status={(order.status === 'delivered' ? 'settled' : order.status === 'shipped' ? 'active' : 'review')}
                                        metric={(order.status || 'pending').toUpperCase()}
                                        active={selectedOrder?.id === order.id}
                                        onClick={() => setSelectedOrder(order)}
                                        icon={Package}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Manifest" dominance="dominant" className="p-0 flex flex-col overflow-hidden border-b">
                            {selectedOrder ? (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4">
                                    <SystemDetailHeader
                                        title={`$${(selectedOrder.total || 0).toFixed(2)}`}
                                        subtitle={`Order #${selectedOrder.id}`}
                                        category={(selectedOrder.status || 'pending').toUpperCase()}
                                        icon={Package}
                                        addonContext="commerce"
                                    >
                                        <div className="text-right">
                                            <StateText className="text-[10px] opacity-50 uppercase">Customer</StateText>
                                            <IntentText className="text-sm">{selectedOrder.customer_name || "Guest User"}</IntentText>
                                        </div>
                                    </SystemDetailHeader>
                                    <div className="flex-1 p-6 space-y-6 overflow-y-auto">
                                        <div className="flex items-center gap-4 p-4 border border-white/5 rounded bg-neutral-900/20">
                                            <div className="p-2 rounded-full bg-neutral-800 text-neutral-400">
                                                <MapPin className="w-5 h-5" />
                                            </div>
                                            <div className="flex-1">
                                                <StateText className="text-[10px] uppercase opacity-50">Shipping Destination</StateText>
                                                <IntentText className="text-sm">{selectedOrder.shipping_address || "No address provided"}</IntentText>
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <OrientingText className="mb-2">LINE ITEMS</OrientingText>
                                            <div className="border border-white/5 rounded divide-y divide-white/5">
                                                {selectedOrder.items?.map((item, i) => (
                                                    <div key={i} className="p-3 flex justify-between items-center">
                                                        <StateText className="text-sm">{item.name || "Product"}</StateText>
                                                        <div className="font-mono text-sm opacity-50">x{item.quantity}</div>
                                                    </div>
                                                )) || <div className="p-4 text-center opacity-30"><StateText>No items</StateText></div>}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center opacity-30">
                                    <Package className="w-16 h-16 mb-4 stroke-1 text-neutral-600" />
                                    <OrientingText>Select an order to view manifest</OrientingText>
                                </div>
                            )}
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Stock" dominance="supporting" className="p-0 flex flex-col border-t-0 rounded-t-none">
                            <div className="flex items-center justify-between p-4 border-b border-white/5 shrink-0 bg-transparent">
                                <OrientingText>INVENTORY LEVELS</OrientingText>
                                <BarChart2 className="w-4 h-4 text-neutral-500" />
                            </div>
                            <div className="flex-1 overflow-y-auto p-4 pt-0 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {inventory.map(item => (
                                    <InventoryRow key={item.id} item={item} />
                                ))}
                                {inventory.length === 0 && (
                                    <div className="text-center py-8 opacity-50 flex flex-col items-center justify-center">
                                        <Box className="w-8 h-8 text-neutral-600 mb-2" />
                                        <StateText>Inventory Empty</StateText>
                                    </div>
                                )}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}