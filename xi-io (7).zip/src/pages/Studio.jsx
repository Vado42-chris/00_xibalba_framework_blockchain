import React, { useState, useEffect } from 'react';
import { DragDropContext } from '@hello-pangea/dnd';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { 
    LayoutTemplate, ChevronDown, FolderOpen, Save, Settings, Package, HardDrive,
    Briefcase, CheckSquare, UploadCloud, ShoppingBag, Share2,
    MousePointer2, Move, RotateCw, Scale, Type, Image, 
    Video, Box, FileText, Globe, Layers, Scissors, PlaySquare, Smartphone, PenTool,
    LayoutGrid, Lightbulb, Camera, Music, RectangleHorizontal, Square
} from 'lucide-react';
import { cn } from "@/components/ui/utils";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { InteractionManager } from '@/components/interaction/InteractionManager';
import DeploymentModal from '@/components/reaper/DeploymentModal';
import { useWindowManager } from '@/components/studio/managers/WindowManager'; // Import WindowManager

// --- SUB-EDITORS ---
import VisualPalette from '@/components/studio/VisualPalette';
import UnifiedCanvas from '@/components/studio/UnifiedCanvas';
import StudioToolbar from '@/components/studio/StudioToolbar';
import ThreeDEditor from '@/components/studio/editors/ThreeDEditor';
import VideoEditor from '@/components/studio/editors/VideoEditor';
import DocumentEditor from '@/components/studio/editors/DocumentEditor';
import MobileAppEditor from '@/components/studio/editors/MobileAppEditor';
import SoundEditor from '@/components/studio/editors/SoundEditor';
import MagazineEditor from '@/components/studio/editors/MagazineEditor';
import SpreadsheetEditor from '@/components/studio/editors/SpreadsheetEditor';
import StoreEditor from '@/components/studio/editors/StoreEditor';
import BlogEditor from '@/components/studio/editors/BlogEditor';
import BrowserEditor from '@/components/studio/editors/BrowserEditor';
import DatabaseEditor from '@/components/studio/editors/DatabaseEditor';
import EmailDesigner from '@/components/studio/editors/EmailClient';
import CodeArchitect from '@/components/studio/editors/CodeArchitect';
import ProgramStore from '@/components/studio/ProgramStore';
import DocketManager from '@/components/studio/DocketManager';
import WorkspaceShell from '@/components/studio/WorkspaceShell';
import StudioLauncher from '@/components/studio/StudioLauncher';

// --- LIBRARIES & CONFIGS ---
const WEB_LIBRARY = [
    { id: 'lib-header', type: 'header', label: 'Header Hero', category: 'Sections', icon: LayoutTemplate },
    { id: 'lib-features', type: 'features', label: 'Feature Grid', category: 'Sections', icon: LayoutGrid },
    { id: 'lib-text', type: 'text', label: 'Text Block', category: 'Basic', icon: Type },
    { id: 'lib-image', type: 'image', label: 'Image', category: 'Media', icon: Image },
    { id: 'lib-button', type: 'button', label: 'Button', category: 'Interactive', icon: MousePointer2 },
    { id: 'lib-card', type: 'card', label: 'Card', category: 'Containers', icon: Square },
    { id: 'lib-video', type: 'video', label: 'Video Embed', category: 'Media', icon: Video },
    { id: 'lib-form', type: 'form', label: 'Contact Form', category: 'Interactive', icon: RectangleHorizontal },
];

const THREE_D_LIBRARY = [
    { id: 'lib-cube', type: 'mesh', label: 'Cube', category: 'Primitives', icon: Box },
    { id: 'lib-light', type: 'light', label: 'Point Light', category: 'Lights', icon: Lightbulb },
    { id: 'lib-camera', type: 'camera', label: 'Camera', category: 'Cameras', icon: Camera },
];

const VIDEO_LIBRARY = [
    { id: 'lib-clip', type: 'clip', label: 'Media Clip', category: 'Media', icon: Video },
    { id: 'lib-audio', type: 'audio', label: 'Audio Track', category: 'Audio', icon: Music },
    { id: 'lib-transition', type: 'transition', label: 'Cross Dissolve', category: 'Effects', icon: Layers },
];

export default function StudioPage() {
    // --- STATE ---
    const queryParams = new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '');
    const [editorMode, setEditorMode] = useState(queryParams.get('mode') || 'launcher'); // launcher, web, 3d, video, document
    const [activeFile, setActiveFile] = useState(null);
    const [activeProject, setActiveProject] = useState({ id: 'proj_1', name: 'Project Titan (Alpha)' });
    
    // Window Manager for Satellite Views
    const { openWindow } = useWindowManager();
    const [activeTask, setActiveTask] = useState({ id: 'task_12', title: 'Design Landing Hero', status: 'in_progress' });
    const [recentFiles, setRecentFiles] = useState([]);
    
    // UI State
    const [showStore, setShowStore] = useState(false);
    const [showDocket, setShowDocket] = useState(false);
    const [showPublish, setShowPublish] = useState(false);
    const [showDeploy, setShowDeploy] = useState(false); // For DeploymentModal
    
    // Web Editor State
    const [items, setItems] = useState([]);
    const [selectedId, setSelectedId] = useState(null);
    const [activeTool, setActiveTool] = useState('select'); 
    const [scale, setScale] = useState(1);
    const [viewportWidth, setViewportWidth] = useState('100%');
    const [highlightedRule, setHighlightedRule] = useState(null);

    useEffect(() => {
        setRecentFiles([
             { id: '1', name: 'Hero_Character_V2.glb', type: '3d', size: '24MB' },
             { id: '2', name: 'Promo_Reel_Final.mp4', type: 'video', size: '145MB' },
             { id: '3', name: 'Q4_Financials.xlsx', type: 'document', size: '2MB' },
             { id: '4', name: 'Landing_Page_V1', type: 'web', size: 'N/A' }
        ]);
    }, []);

    // --- HANDLERS ---
    const handleLaunch = (mode) => {
        setEditorMode(mode);
        let appName = 'Web Architect';
        if (mode === '3d') appName = 'Voxel Forge';
        if (mode === 'video') appName = 'Cinema Node';
        if (mode === 'document') appName = 'Office Suite';
        if (mode === 'sheet') appName = 'Office Grid';
        if (mode === 'mobile') appName = 'App Forge';
        if (mode === 'sound') appName = 'Audio Lab';
        if (mode === 'layout') appName = 'Magazine Pro';
        if (mode === 'store') appName = 'Store Builder';
        if (mode === 'blog') appName = 'Blog Studio';
        if (mode === 'browser') appName = 'Browser Forge';
        if (mode === 'database') appName = 'Data Architect';
        if (mode === 'mail') appName = 'Mail Studio';
        if (mode === 'architect') appName = 'Code Architect';
        
        setActiveFile({ name: 'Untitled Project', type: mode, projectId: 'proj_1' });
        toast.success(`Booting ${appName}...`);
    };

    const handleFileSwitch = (file) => {
        setActiveFile(file);
        // Map file types to editor modes
        if (file.type === '3d') setEditorMode('3d');
        else if (file.type === 'video') setEditorMode('video');
        else if (file.type === 'document') setEditorMode('document');
        else if (file.type === 'sheet') setEditorMode('sheet');
        else if (file.type === 'mobile') setEditorMode('mobile');
        else if (file.type === 'sound') setEditorMode('sound');
        else if (file.type === 'layout') setEditorMode('layout');
        else if (file.type === 'store') setEditorMode('store');
        else if (file.type === 'blog') setEditorMode('blog');
        else if (file.type === 'browser') setEditorMode('browser');
        else if (file.type === 'database') setEditorMode('database');
        else if (file.type === 'mail') setEditorMode('mail');
        else if (file.type === 'architect') setEditorMode('architect');
        else setEditorMode('web');
        
        toast.info(`Opened ${file.name}`);
        setShowDocket(false);
    };
    
    const handleInstallProgram = (program) => {
        toast.success(`Installing ${program.name}...`);
        setTimeout(() => {
            toast.success(`${program.name} installed successfully`);
        }, 1500);
    };

    const handlePublish = (target) => {
        toast.loading(`Publishing to ${target}...`);
        setTimeout(() => {
            toast.success(`Successfully published to ${target}!`);
            setShowPublish(false);
        }, 2000);
    }

    const handleDragEnd = (result) => {
        if (!result.destination) return;
        const { source, destination } = result;

        if (editorMode === 'web') {
            if (source.droppableId === 'palette' && destination.droppableId === 'canvas') {
                const template = WEB_LIBRARY[source.index];
                const newItem = {
                    id: `item-${Date.now()}`,
                    type: template.type,
                    label: template.label,
                    content: `New ${template.label}`,
                    interactions: []
                };
                const newItems = Array.from(items);
                newItems.splice(destination.index, 0, newItem);
                setItems(newItems);
                setSelectedId(newItem.id);
            } else if (source.droppableId === 'canvas' && destination.droppableId === 'canvas') {
                const newItems = Array.from(items);
                const [reorderedItem] = newItems.splice(source.index, 1);
                newItems.splice(destination.index, 0, reorderedItem);
                setItems(newItems);
            }
        }
    };

    const activeLibrary = 
        editorMode === '3d' ? THREE_D_LIBRARY : 
        editorMode === 'video' ? VIDEO_LIBRARY : 
        WEB_LIBRARY;

    useEffect(() => {
        if (editorMode === 'web' && items.length === 0) {
            setItems([
                { id: '1', type: 'web', label: 'Hero Section', html: '<div class="p-8 bg-neutral-900 text-center"><h1 class="text-4xl font-bold text-white mb-4">Welcome to Xibalba</h1><p class="text-neutral-400">The Future of Media Creation</p></div>', interactions: [] },
                { id: '2', type: 'web', label: 'Action Button', html: '<button class="px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-full transition-colors font-bold">Get Started</button>', interactions: [] }
            ]);
        }
    }, [editorMode]);

    const handleHome = () => {
        setEditorMode('launcher');
        setActiveFile(null);
    };

    const getToolbar = () => {
        if (editorMode === 'web') {
            return (
                <div className="flex items-center gap-1">
                    <Button variant={activeTool === 'select' ? 'secondary' : 'ghost'} size="icon" onClick={() => setActiveTool('select')} title="Select"><MousePointer2 className="w-4 h-4" /></Button>
                    <Button variant={activeTool === 'text' ? 'secondary' : 'ghost'} size="icon" onClick={() => setActiveTool('text')} title="Text"><Type className="w-4 h-4" /></Button>
                    <Button variant={activeTool === 'image' ? 'secondary' : 'ghost'} size="icon" onClick={() => setActiveTool('image')} title="Image"><Image className="w-4 h-4" /></Button>
                    <Button variant={activeTool === 'component' ? 'secondary' : 'ghost'} size="icon" onClick={() => setActiveTool('component')} title="Component"><Box className="w-4 h-4" /></Button>
                    <div className="w-px h-4 bg-white/10 mx-2" />
                    <select 
                        className="bg-black border border-white/10 text-[10px] rounded h-7 px-2"
                        value={viewportWidth}
                        onChange={(e) => setViewportWidth(e.target.value)}
                    >
                        <option value="100%">Responsive (100%)</option>
                        <option value="1024px">Desktop (1024px)</option>
                        <option value="768px">Tablet (768px)</option>
                        <option value="375px">Mobile (375px)</option>
                    </select>
                </div>
            );
        }
        if (editorMode === 'mobile') {
            return (
                <div className="flex items-center gap-1">
                    <div className="text-[10px] text-neutral-500 mr-2 font-bold uppercase tracking-widest">Target</div>
                    <select 
                        className="bg-black border border-white/10 text-[10px] rounded h-7 px-2"
                        defaultValue="ios"
                    >
                        <option value="ios">iOS (iPhone 14)</option>
                        <option value="android">Android (Pixel 7)</option>
                    </select>
                    <div className="w-px h-4 bg-white/10 mx-2" />
                    <Button variant="ghost" size="icon" title="Portrait"><Smartphone className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" title="Landscape"><RotateCw className="w-4 h-4" /></Button>
                </div>
            );
        }
        if (editorMode === '3d') {
            return (
                <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" title="Select"><Move className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" title="Rotate"><RotateCw className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" title="Scale"><Scale className="w-4 h-4" /></Button>
                    <div className="w-px h-4 bg-white/10 mx-2" />
                    <Button variant="ghost" size="icon" title="World Space"><Globe className="w-4 h-4" /></Button>
                </div>
            );
        }
        if (editorMode === 'video') {
            return (
                <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" title="Selection Tool"><MousePointer2 className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" title="Razor Tool"><Scissors className="w-4 h-4" /></Button>
                    <div className="w-px h-4 bg-white/10 mx-2" />
                    <Button variant="ghost" size="icon" title="Insert Media"><PlaySquare className="w-4 h-4" /></Button>
                </div>
            );
        }
        if (['book', 'document', 'sheet', 'layout', 'store', 'blog', 'browser', 'database', 'mail', 'architect'].includes(editorMode)) {
            return (
                <div className="flex items-center gap-1 opacity-50 cursor-not-allowed" title="Tools managed by editor">
                    <span className="text-[10px]">Standard Toolbar</span>
                </div>
            );
        }
        return null;
    };

    const allInteractionRules = items.flatMap(i => i.interactions || []);

    const getSidebar = () => {
        if (['document', 'mobile', 'sound', 'layout', 'sheet', 'store', 'blog', 'browser', 'database', 'mail', 'architect'].includes(editorMode)) return null;
        
        return (
            <VisualPalette 
                mode={editorMode}
                items={activeLibrary}
                canvasItems={items}
                selectedItem={items.find(i => (i.id || i.uniqueId) === selectedId)}
                onSelectItem={setSelectedId}
                onUpdateItem={(updated) => setItems(items.map(i => (i.id || i.uniqueId) === (updated.id || updated.uniqueId) ? updated : i))}
                onHighlightRule={setHighlightedRule}
            />
        );
    };

    const getProgramName = () => {
        switch(editorMode) {
            case 'book': return 'Codex Scribe';
            case 'layout': return 'Magazine Pro';
            case 'presentation': return 'Slide Deck';
            case 'social': return 'Social Pulse';
            case 'cad': return 'CAD Construct';
            case 'vector': return 'Vector Curve';
            case '3d': return 'Voxel Forge';
            case 'video': return 'Cinema Node';
            case 'document': return 'Office Suite';
            case 'sheet': return 'Office Grid';
            case 'mobile': return 'App Forge';
            case 'sound': return 'Audio Lab';
            case 'store': return 'Store Builder';
            case 'blog': return 'Blog Studio';
            case 'browser': return 'Browser Forge';
            case 'database': return 'Data Architect';
            case 'mail': return 'Mail Studio';
            case 'architect': return 'Code Architect';
            default: return 'Web Architect';
        }
    };

    const activeStatusBar = (
        <div className="flex items-center gap-4 text-neutral-400">
            <div className="flex items-center gap-2 px-2 py-0.5 rounded hover:bg-white/5 cursor-pointer" title="Current Active Task from WorkRoom">
                <CheckSquare className="w-3 h-3 text-[hsl(var(--color-warning))]" />
                <span className="text-[hsl(var(--color-warning))]">{activeTask.title}</span>
            </div>
            <div className="w-px h-3 bg-white/10" />
            <div className="flex items-center gap-2">
                <Briefcase className="w-3 h-3" />
                <span>{activeProject.name}</span>
            </div>
        </div>
    );

    return (
        <InteractionManager rules={allInteractionRules}>
        <DragDropContext onDragEnd={handleDragEnd}>
            <div className="h-full bg-black">
                <WorkspaceShell
                    mode={editorMode}
                    programName={getProgramName()}
                    fileName={activeFile?.name || 'Dreamcatcher Hub'}
                    project={activeProject}
                    task={activeTask}
                    toolbar={getToolbar()}
                    sidebar={getSidebar()}
                    statusBar={{ left: activeStatusBar }}
                    onAction={(action) => {
                        if (action === 'open...') setShowDocket(true);
                        else if (action === 'publish') setShowPublish(true);
                        else if (action === 'home') handleHome();
                        else toast.info(`Action: ${action}`);
                    }}
                >
                    {/* MODALS */}
                    <ProgramStore 
                        open={showStore} 
                        onOpenChange={setShowStore} 
                        onInstall={handleInstallProgram}
                    />
                    
                    <DocketManager 
                        open={showDocket} 
                        onOpenChange={setShowDocket} 
                        onFileSelect={handleFileSwitch}
                    />

                    {/* PUBLISH DIALOG */}
                    <Dialog open={showPublish} onOpenChange={setShowPublish}>
                        <DialogContent className="bg-neutral-900 border-white/10 text-white">
                            <DialogHeader>
                                <DialogTitle className="flex items-center gap-2">
                                    <UploadCloud className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                                    Publish & Distribute
                                </DialogTitle>
                            </DialogHeader>
                            <div className="grid grid-cols-2 gap-4 py-4">
                                <div 
                                    className="p-4 rounded-xl border border-white/10 bg-black/20 hover:bg-black/40 hover:border-[hsl(var(--color-execution))] cursor-pointer transition-all flex flex-col items-center text-center gap-2"
                                    onClick={() => handlePublish('Marketplace')}
                                >
                                    <ShoppingBag className="w-8 h-8 text-[hsl(var(--color-execution))]" />
                                    <span className="font-bold text-sm">Marketplace</span>
                                    <span className="text-xs text-neutral-500">Sell this asset/component to the community</span>
                                </div>
                                <div 
                                    className="p-4 rounded-xl border border-white/10 bg-black/20 hover:bg-black/40 hover:border-[hsl(var(--color-intent))] cursor-pointer transition-all flex flex-col items-center text-center gap-2"
                                    onClick={() => handlePublish('Distro')}
                                >
                                    <Share2 className="w-8 h-8 text-[hsl(var(--color-intent))]" />
                                    <span className="font-bold text-sm">Distro Builder</span>
                                    <span className="text-xs text-neutral-500">Deploy as part of a product release</span>
                                </div>
                                <div 
                                    className="p-4 rounded-xl border border-white/10 bg-black/20 hover:bg-black/40 hover:border-[hsl(var(--color-active))] cursor-pointer transition-all flex flex-col items-center text-center gap-2 col-span-2"
                                    onClick={() => { setShowPublish(false); setShowDeploy(true); }}
                                >
                                    <UploadCloud className="w-8 h-8 text-[hsl(var(--color-active))]" />
                                    <span className="font-bold text-sm">Deploy UI to Dev Server</span>
                                    <span className="text-xs text-neutral-500">Zip & Ship this Studio to Localhost</span>
                                </div>
                            </div>
                        </DialogContent>
                    </Dialog>

                    <DeploymentModal 
                        open={showDeploy} 
                        onOpenChange={setShowDeploy} 
                        mode="smart_ship"
                    />

                    {/* MAIN EDITOR CONTENT */}
                    <div className="absolute inset-0">
                        {editorMode === 'launcher' && (
                            <StudioLauncher 
                                onLaunch={handleLaunch} 
                                onLaunchWindow={(appId) => openWindow(appId, { file: activeFile })}
                                onOpenProject={(proj) => toast.info(`Opening ${proj.name}`)} 
                            />
                        )}

                        {editorMode === 'web' && (
                            <UnifiedCanvas 
                                items={items}
                                onItemsChange={setItems}
                                selectedId={selectedId}
                                onSelect={(item) => setSelectedId(item ? (item.id || item.uniqueId) : null)}
                                activeTool={activeTool}
                                onToolReset={() => setActiveTool('select')}
                                scale={scale}
                                viewportWidth={viewportWidth}
                                highlightedRule={highlightedRule}
                            />
                        )}
                        
                        {editorMode === '3d' && <ThreeDEditor file={activeFile} />}
                        {editorMode === 'video' && <VideoEditor file={activeFile} />}
                        {(editorMode === 'document' || editorMode === 'book') && <DocumentEditor file={activeFile} />}
                        {editorMode === 'sheet' && <SpreadsheetEditor file={activeFile} />}
                        {editorMode === 'mobile' && <MobileAppEditor file={activeFile} />}
                        {editorMode === 'sound' && <SoundEditor file={activeFile} />}
                        {editorMode === 'layout' && <MagazineEditor file={activeFile} />}
                        {editorMode === 'store' && <StoreEditor file={activeFile} />}
                        {editorMode === 'blog' && <BlogEditor file={activeFile} />}
                        {editorMode === 'browser' && <BrowserEditor file={activeFile} />}
                        {editorMode === 'database' && <DatabaseEditor file={activeFile} />}
                        {editorMode === 'mail' && <EmailDesigner file={activeFile} />}
                        {editorMode === 'architect' && <CodeArchitect file={activeFile} />}
                        
                        {/* Unified Canvas Fallback for other modes */}
                        {['presentation', 'social', 'cad', 'vector'].includes(editorMode) && (
                            <UnifiedCanvas 
                                items={items}
                                onItemsChange={setItems}
                                selectedId={selectedId}
                                onSelect={(item) => setSelectedId(item ? (item.id || item.uniqueId) : null)}
                                activeTool={activeTool}
                                onToolReset={() => setActiveTool('select')}
                                scale={scale}
                                viewportWidth={viewportWidth}
                                highlightedRule={highlightedRule}
                            />
                        )}
                    </div>

                    {/* Floating Controls (Store Access) - Only in Launcher or if needed */}
                    {editorMode === 'launcher' && (
                        <div className="absolute bottom-12 right-12 z-50">
                            <Button 
                                size="lg" 
                                variant="secondary" 
                                className="shadow-2xl border border-white/10 bg-black/80 backdrop-blur-md"
                                onClick={() => setShowStore(true)}
                            >
                                <Package className="w-4 h-4 mr-2" />
                                Addon Marketplace
                            </Button>
                        </div>
                    )}

                </WorkspaceShell>
            </div>
        </DragDropContext>
        </InteractionManager>
    );
}