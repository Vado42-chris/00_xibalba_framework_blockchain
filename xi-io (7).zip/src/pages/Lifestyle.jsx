import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
    Coffee, Heart, Brain, Zap, Shield, ArrowUpRight,
    Briefcase, Home, Wallet, Gamepad2, ChevronRight,
    Activity, LayoutGrid, Calendar
} from 'lucide-react';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer
} from '@/components/ui/design-system/System';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Badge } from "@/components/ui/badge";
import DailyDeck from '@/components/lifestyle/DailyDeck';
import { AddonGate } from '@/components/integrations/AddonGate';
import ChronosWidget from '@/components/addons/official/ChronosWidget';
import LevelProgress from '@/components/lifestyle/LevelProgress';
import MobileCompanion from '@/components/lifestyle/MobileCompanion';

const LifeModule = ({ icon: Icon, title, desc, path, color, status }) => (
    <Link to={createPageUrl(path)} className="group block h-full">
        <SystemCard
            title={title}
            subtitle={desc}
            icon={Icon}
            status="active"
            metric={status}
            className="h-full"
        />
    </Link>
);

export default function Lifestyle() {
    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
        const checkMobile = () => setIsMobile(window.innerWidth < 768);
        checkMobile();
        window.addEventListener('resize', checkMobile);
        return () => window.removeEventListener('resize', checkMobile);
    }, []);

    if (isMobile) {
        return <MobileCompanion />;
    }

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <LayoutGrid className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">LIFE OS</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Central Command</IntentText>
                                </div>
                                <LevelProgress />
                            </div>
                            
                            <div className="grid grid-cols-3 gap-2">
                                <Layer level="orientation" className="p-2 flex flex-col justify-between h-20">
                                    <div className="flex items-center gap-2 text-[hsl(var(--color-error))]"><Heart className="w-3 h-3" /> <StateText>HRV</StateText></div>
                                    <IntentText className="text-xl font-light">54</IntentText>
                                </Layer>
                                <Layer level="orientation" className="p-2 flex flex-col justify-between h-20">
                                    <div className="flex items-center gap-2 text-[hsl(var(--color-intent))]"><Brain className="w-3 h-3" /> <StateText>Focus</StateText></div>
                                    <IntentText className="text-xl font-light">8.2</IntentText>
                                </Layer>
                                <Layer level="orientation" className="p-2 flex flex-col justify-between h-20">
                                    <div className="flex items-center gap-2 text-[hsl(var(--color-warning))]"><Zap className="w-3 h-3" /> <StateText>Energy</StateText></div>
                                    <IntentText className="text-xl font-light">92%</IntentText>
                                </Layer>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none bg-neutral-900/20">
                            <div className="grid grid-cols-2 gap-4 h-full p-4 overflow-y-auto">
                                <LifeModule 
                                    icon={Briefcase}
                                    title="WORKROOM"
                                    desc="Career, Projects, and Professional Development"
                                    path="WorkRoom"
                                    color="text-blue-400"
                                    status="ACTIVE"
                                />
                                <LifeModule 
                                    icon={Home}
                                    title="HOUSEHOLD"
                                    desc="Sanctuary Management, Chores, Family Board"
                                    path="Household"
                                    color="text-emerald-400"
                                    status="ONLINE"
                                />
                                <LifeModule 
                                    icon={Wallet}
                                    title="FINANCE"
                                    desc="Treasury, Assets, and Investment Strategy"
                                    path="Finance"
                                    color="text-amber-400"
                                    status="SYNCED"
                                />
                                <LifeModule 
                                    icon={Shield}
                                    title="LEGAL"
                                    desc="Compliance, Contracts, and IP Protection"
                                    path="Legal"
                                    color="text-rose-400"
                                    status="SECURE"
                                />
                                <LifeModule 
                                    icon={Activity}
                                    title="HEALTH"
                                    desc="Bio-Telemetry, Medical Records, Optimization"
                                    path="Health"
                                    color="text-red-400"
                                    status="TRACKING"
                                />
                                <LifeModule 
                                    icon={Gamepad2}
                                    title="ENTERTAINMENT"
                                    desc="Ludic Engine, Media, Travel, and Hobbies"
                                    path="Entertainment"
                                    color="text-purple-400"
                                    status="READY"
                                />
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" dominance="dominant" className="border-b">
                            <OrientingText className="mb-6">DAILY BRIEFING</OrientingText>
                            
                            <div className="space-y-6 h-full flex flex-col">
                                <div className="flex-1 min-h-[300px]">
                                    <AddonGate
                                        addonName="Chronos Timekeeper"
                                        integrationType="googlecalendar"
                                        title="Smart Schedule"
                                        icon={Calendar}
                                        description="Sync your Google Calendar to see your daily agenda here."
                                    >
                                        <ChronosWidget />
                                    </AddonGate>
                                </div>

                                <div>
                                    <StateText className="mb-2 text-xs opacity-50">ALERTS</StateText>
                                    <div className="space-y-2">
                                        <div className="p-3 bg-neutral-900/50 border border-white/5 rounded-lg flex items-center justify-between">
                                            <div className="flex items-center gap-3">
                                                <Wallet className="w-4 h-4 text-amber-500" />
                                                <div className="text-xs text-neutral-300">Amex Payment Due</div>
                                            </div>
                                            <Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-500">TOMORROW</Badge>
                                        </div>
                                        <div className="p-3 bg-neutral-900/50 border border-white/5 rounded-lg flex items-center justify-between">
                                            <div className="flex items-center gap-3">
                                                <Activity className="w-4 h-4 text-red-500" />
                                                <div className="text-xs text-neutral-300">Recovery Score Low</div>
                                            </div>
                                            <Badge variant="outline" className="text-[9px] border-red-500/30 text-red-500">ADVISE REST</Badge>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </Quadrant>
                        
                        <Quadrant type="intent" step="4" title="Deck" dominance="supporting" className="h-[400px] border-t-0 rounded-t-none p-0 overflow-hidden">
                            <DailyDeck />
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}