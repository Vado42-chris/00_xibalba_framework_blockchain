import React, { useState } from 'react';
import VisualForge from '@/components/reaper/VisualForge';
import { OrientingText } from '@/components/ui/design-system/System';
import PublishComponentModal from '@/components/marketplace/PublishComponentModal';
import { InteractionManager } from '@/components/interaction/InteractionManager';
import { toast } from 'sonner';
import { Share2, Download, Globe } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ComponentForge() {
    const [generatedCode, setGeneratedCode] = useState('');
    const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);

    const handleExport = () => {
        if (!generatedCode || generatedCode.length < 50) {
            toast.error("Build something substantial before publishing.");
            return;
        }
        setIsPublishModalOpen(true);
    };

    const handleQuickInstall = async () => {
        if (!generatedCode) return;
        
        const toastId = toast.loading("Compiling & Installing to System...");
        try {
            // 1. Create a local 'Dev' marketplace item
            const name = `Dev Component ${new Date().toLocaleTimeString()}`;
            const newItem = await base44.entities.MarketplaceItem.create({
                name: name,
                category: 'module',
                provider_type: 'community', // Self
                description: 'Local development build installed from Component Forge.',
                price_amount: 0,
                manifest: {
                    code: generatedCode,
                    version: '0.0.1-dev'
                },
                installed: true // Mark as installed locally
            });

            // 2. Register installation
            await base44.entities.InstalledAddon.create({
                addon_id: newItem.id,
                installed_at: new Date().toISOString(),
                status: 'active',
                settings: {}
            });

            toast.success(`Installed "${name}" to System Library`, { id: toastId });
        } catch (error) {
            console.error(error);
            toast.error("Installation Failed: " + error.message, { id: toastId });
        }
    };

    const handleDeployToPage = async () => {
        if (!generatedCode) return;
        const toastId = toast.loading("Deploying as New Page...");
        try {
            const timestamp = new Date().getTime();
            const pageName = `Forge Page ${timestamp}`;
            const slug = `forge-${timestamp}`;
            
            // In a real scenario, this would write to pages/ directory via a backend function
            // For now, we simulate by creating a ContentPage entity which the dynamic router could pick up
            await base44.entities.ContentPage.create({
                title: pageName,
                slug: slug,
                content: generatedCode,
                status: 'published'
            });
            
            // Add a notification about the URL
            toast.success(
                <div className="flex flex-col gap-2">
                    <span>Page Deployed Successfully</span>
                    <a href={`/${slug}`} target="_blank" className="text-xs underline text-blue-400">
                        View Live Page
                    </a>
                </div>, 
                { id: toastId, duration: 5000 }
            );
        } catch (error) {
            toast.error("Deploy Failed: " + error.message, { id: toastId });
        }
    };

    return (
        <InteractionManager>
            <div className="h-screen w-full flex flex-col bg-neutral-950 overflow-hidden">
                {/* Header */}
                <div className="h-14 border-b border-white/5 bg-neutral-900 flex items-center justify-between px-6 shrink-0 z-50">
                    <div className="flex items-center gap-3">
                        <OrientingText className="text-lg font-bold tracking-tight text-white">COMPONENT FORGE</OrientingText>
                        <div className="h-4 w-px bg-white/10" />
                        <span className="text-xs text-neutral-500 font-mono">v2.0.0-alpha</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <button className="px-3 py-1.5 text-xs font-medium text-neutral-400 hover:text-white transition-colors">
                            Documentation
                        </button>
                        <button 
                            onClick={handleQuickInstall}
                            className="px-3 py-1.5 border border-white/10 hover:bg-white/5 text-neutral-300 text-xs font-bold rounded transition-colors flex items-center gap-2"
                            title="Install to local system for testing"
                        >
                            <Download className="w-3 h-3" />
                            Install Dev Build
                        </button>
                        <button 
                            onClick={handleDeployToPage}
                            className="px-3 py-1.5 border border-white/10 hover:bg-white/5 text-neutral-300 text-xs font-bold rounded transition-colors flex items-center gap-2"
                            title="Deploy as a standalone page"
                        >
                            <Globe className="w-3 h-3" />
                            Deploy Page
                        </button>
                        <button 
                            onClick={handleExport}
                            className="px-3 py-1.5 bg-[hsl(var(--color-execution))] text-black text-xs font-bold rounded hover:bg-[hsl(var(--color-execution))]/90 transition-colors flex items-center gap-2"
                        >
                            <Share2 className="w-3 h-3" />
                            Publish
                        </button>
                    </div>
                </div>

                {/* Main Workspace */}
                <div className="flex-1 relative">
                    <VisualForge 
                        onCodeChange={setGeneratedCode}
                        currentCode={generatedCode}
                    />
                </div>

                <PublishComponentModal 
                    open={isPublishModalOpen}
                    onOpenChange={setIsPublishModalOpen}
                    code={generatedCode}
                />
            </div>
        </InteractionManager>
    );
}