import React from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Fingerprint, ArrowRight, ShieldCheck, Terminal } from 'lucide-react';
import { OrientingText, IntentText } from '@/components/ui/design-system/SystemDesign';

export default function Entrance() {
    const handleLogin = () => {
        base44.auth.redirectToLogin();
    };

    return (
        <div className="min-h-screen w-full bg-neutral-950 flex relative overflow-hidden">
            {/* Background Effects */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(16,185,129,0.1),transparent_70%)]" />
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-100 contrast-150" />
            
            {/* Left Panel - Brand & Context */}
            <div className="hidden lg:flex w-1/2 relative z-10 flex-col justify-between p-12 border-r border-white/5 bg-black/20 backdrop-blur-sm">
                <div>
                    <div className="flex items-center gap-3 mb-8">
                        <div className="w-10 h-10 rounded bg-[hsl(var(--color-execution))] flex items-center justify-center">
                            <Terminal className="w-6 h-6 text-black" />
                        </div>
                        <h1 className="text-2xl font-bold tracking-widest text-white">XIBALBA STUDIO</h1>
                    </div>
                    <div className="space-y-6 max-w-md">
                        <IntentText className="text-4xl leading-tight">
                            Architect Your Sovereign Digital Empire.
                        </IntentText>
                        <p className="text-neutral-400 leading-relaxed">
                            Initialize your workspace. Define your protocols. 
                            Deploy your autonomous infrastructure.
                        </p>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="flex items-center gap-4 text-xs text-neutral-500 font-mono">
                        <div className="flex items-center gap-2">
                            <ShieldCheck className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                            <span>Encrypted Session</span>
                        </div>
                        <div className="w-1 h-1 rounded-full bg-neutral-700" />
                        <div>v2.4.0-stable</div>
                    </div>
                </div>
            </div>

            {/* Right Panel - Auth Interface */}
            <div className="w-full lg:w-1/2 flex items-center justify-center p-8 relative z-10">
                <div className="w-full max-w-sm space-y-8">
                    <div className="text-center lg:text-left">
                        <OrientingText className="text-[hsl(var(--color-execution))] mb-2">ACCESS CONTROL</OrientingText>
                        <h2 className="text-3xl font-light text-white mb-2">Identify Yourself</h2>
                        <p className="text-sm text-neutral-500">Authenticate to decrypt your workspace.</p>
                    </div>

                    <div className="space-y-4">
                        <Button 
                            onClick={handleLogin}
                            className="w-full h-12 bg-white text-black hover:bg-neutral-200 font-bold tracking-wide transition-all group"
                        >
                            <Fingerprint className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
                            INITIATE SESSION
                            <ArrowRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                        </Button>
                        
                        <div className="relative py-4">
                            <div className="absolute inset-0 flex items-center">
                                <span className="w-full border-t border-white/10" />
                            </div>
                            <div className="relative flex justify-center text-xs uppercase">
                                <span className="bg-neutral-950 px-2 text-neutral-600">Secure Gateway</span>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 rounded bg-neutral-900/50 border border-white/5 text-center">
                                <div className="text-2xl font-bold text-white mb-1">99.9%</div>
                                <div className="text-[10px] text-neutral-500 uppercase">System Uptime</div>
                            </div>
                            <div className="p-4 rounded bg-neutral-900/50 border border-white/5 text-center">
                                <div className="text-2xl font-bold text-[hsl(var(--color-execution))] mb-1">0ms</div>
                                <div className="text-[10px] text-neutral-500 uppercase">Local Latency</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}