import React from 'react';
import { 
    Users, MessageSquare, Globe, Heart,
    Sparkles, Radio, Share2
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import DepthBackground from '@/components/ui/design-system/DepthBackground';
import { SiteHeader } from '@/components/site/SiteHeader';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function CommunityLanding() {
    return (
        <div className="min-h-screen bg-transparent text-neutral-200 font-sans selection:bg-orange-500/30 overflow-hidden relative">
            <DepthBackground theme="orange-500" />
            <SiteHeader mode="nav" />

            <div className="relative z-10 pt-32 pb-20 px-6 max-w-[1400px] mx-auto">
                
                <div className="text-center space-y-6 mb-24">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-mono mb-4">
                        <Users className="w-3 h-3" />
                        <span>GLOBAL NETWORK</span>
                    </div>
                    <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight">
                        The Xibalba <br />
                        <span className="text-orange-500">Collective</span>
                    </h1>
                    <p className="text-xl text-neutral-400 max-w-2xl mx-auto leading-relaxed">
                        Join a community of architects, engineers, and creators building the future of sovereign computing.
                        Share blueprints, discuss protocols, and collaborate.
                    </p>
                    <div className="flex justify-center gap-4 pt-8">
                        <Link to={createPageUrl('Community')}>
                            <Button className="bg-orange-600 text-white hover:bg-orange-500 font-bold h-12 px-8 rounded-full">
                                Enter Community
                            </Button>
                        </Link>
                        <Link to={createPageUrl('ContentManager')}>
                            <Button variant="outline" className="h-12 px-8 rounded-full border-white/10 text-neutral-300 hover:bg-white/5">
                                Read Blog
                            </Button>
                        </Link>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="col-span-1 md:col-span-2 bg-neutral-900/50 border border-white/10 rounded-2xl p-8 min-h-[400px]">
                        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                            <Radio className="w-6 h-6 text-orange-500" />
                            Live Discussions
                        </h3>
                        <div className="space-y-4">
                            <DiscussionRow title="RFC: Agent Protocol v3.0" author="@neo_architect" replies="42" />
                            <DiscussionRow title="Best hardware for local LLM inference?" author="@hardware_guru" replies="156" />
                            <DiscussionRow title="Showcase: My sovereign finance dashboard" author="@crypto_dad" replies="89" />
                            <DiscussionRow title="Security patch for Node v18.2" author="@sysadmin_x" replies="12" />
                        </div>
                    </div>
                    
                    <div className="col-span-1 space-y-6">
                        <StatCard icon={Users} value="12,405" label="Active Members" />
                        <StatCard icon={MessageSquare} value="842" label="Daily Messages" />
                        <StatCard icon={Globe} value="45" label="Countries" />
                    </div>
                </div>

            </div>
        </div>
    );
}

function DiscussionRow({ title, author, replies }) {
    return (
        <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 transition-colors cursor-pointer">
            <div>
                <div className="font-medium text-white">{title}</div>
                <div className="text-xs text-neutral-500 mt-1">by {author}</div>
            </div>
            <div className="text-xs font-mono text-neutral-400 bg-black/20 px-2 py-1 rounded">
                {replies} replies
            </div>
        </div>
    );
}

function StatCard({ icon: Icon, value, label }) {
    return (
        <div className="bg-neutral-900/50 border border-white/10 rounded-2xl p-6 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-orange-500/10 flex items-center justify-center">
                <Icon className="w-6 h-6 text-orange-500" />
            </div>
            <div>
                <div className="text-2xl font-bold text-white">{value}</div>
                <div className="text-sm text-neutral-500">{label}</div>
            </div>
        </div>
    );
}