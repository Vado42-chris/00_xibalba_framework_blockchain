import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    CreditCard, TrendingUp, Search, 
    Plus, Wallet, ArrowUpRight, ArrowDownLeft
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, SemanticDot, Layer, 
    ChartFrame
} from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import { cn } from "@/lib/utils";
import AssetModal from '@/components/finance/AssetModal';
import { IntegrationStatus, SyncButton, ConnectPrompt } from '@/components/integrations/IntegrationComponents';
import { AddonGate } from '@/components/integrations/AddonGate';
import LedgerQuant from '@/components/addons/official/LedgerQuant';
import PublicFeaturePage from '@/components/layout/PublicFeaturePage';

// AssetRow replaced by SystemCard usage in main component

export default function Finance() {
    // 1. Check Auth State
    const { data: user, isLoading: isUserLoading } = useQuery({
        queryKey: ['me'],
        queryFn: () => base44.auth.me().catch(() => null),
        retry: false
    });

    const [selectedAsset, setSelectedAsset] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    const { data: assets = [] } = useQuery({
        queryKey: ['assets'],
        queryFn: () => base44.entities.Asset.list(),
        enabled: !!user,
        initialData: [] 
    });

    // 2. Render Public Page if not logged in
    if (!isUserLoading && !user) {
        return (
            <PublicFeaturePage 
                title="Finance"
                subtitle="Sovereign Treasury"
                icon={TrendingUp}
                description="Take absolute control of your capital. Manage crypto assets, fiat accounts, and automated trading strategies from a single, secure ledger."
                features={[
                    "Multi-Chain Wallet Tracking",
                    "Real-Time Portfolio Analytics",
                    "Automated Yield Strategies",
                    "Institution-Grade Security"
                ]}
                interactiveComponent={
                    <div className="w-full h-full bg-black/40 flex flex-col font-mono text-xs p-6 relative">
                        {/* Decorative Graph */}
                        <div className="absolute bottom-0 left-0 right-0 h-32 opacity-20 pointer-events-none">
                            <svg className="w-full h-full" preserveAspectRatio="none">
                                <path d="M0,100 C100,50 200,80 300,40 C400,0 500,60 600,20 L600,128 L0,128 Z" fill="url(#gradient)" />
                                <defs>
                                    <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="hsl(var(--color-execution))" stopOpacity="0.5" />
                                        <stop offset="100%" stopColor="hsl(var(--color-execution))" stopOpacity="0" />
                                    </linearGradient>
                                </defs>
                            </svg>
                        </div>

                        <div className="flex justify-between items-end mb-8 relative z-10">
                            <div>
                                <div className="text-neutral-500 text-[10px] uppercase tracking-widest mb-1">Total Liquidity</div>
                                <div className="text-3xl font-light text-white">$1,240,592.00</div>
                            </div>
                            <div className="text-right">
                                <div className="text-[hsl(var(--color-execution))] text-sm font-bold flex items-center gap-1 justify-end">
                                    <TrendingUp className="w-3 h-3" /> +12.4%
                                </div>
                                <div className="text-neutral-600 text-[9px]">24h Change</div>
                            </div>
                        </div>

                        <div className="space-y-2 relative z-10">
                            {[
                                { name: 'Bitcoin', symbol: 'BTC', amount: '12.4', value: '$842,102', color: 'text-orange-400' },
                                { name: 'Ethereum', symbol: 'ETH', amount: '142.0', value: '$312,400', color: 'text-blue-400' },
                                { name: 'USDC', symbol: 'USD', amount: '85,000', value: '$85,000', color: 'text-green-400' }
                            ].map((coin, i) => (
                                <div key={i} className="flex items-center justify-between p-3 bg-neutral-900/50 border border-white/5 rounded hover:border-white/20 transition-colors cursor-pointer group">
                                    <div className="flex items-center gap-3">
                                        <div className={`w-8 h-8 rounded-full bg-white/5 flex items-center justify-center font-bold ${coin.color}`}>
                                            {coin.symbol[0]}
                                        </div>
                                        <div>
                                            <div className="font-bold text-white group-hover:text-[hsl(var(--color-intent))] transition-colors">{coin.name}</div>
                                            <div className="text-neutral-500 text-[10px]">{coin.amount} {coin.symbol}</div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <div className="text-white">{coin.value}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                }
            />
        );
    }

    const filteredAssets = assets.filter(a => 
        (a.name || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
        (a.symbol || '').toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Stats
    const totalValue = assets.reduce((acc, a) => acc + (a.value_usd || 0), 0);

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Ledger" className="border-b">
                            <div className="mb-6">
                                <SystemDetailHeader 
                                    title="Asset Management" 
                                    subtitle="TREASURY" 
                                    icon={TrendingUp}
                                    addonContext="finance"
                                    className="p-0 border-b-0 bg-transparent mb-0" 
                                />
                            </div>
                            
                            <SystemStats 
                                className="grid-cols-1 mb-6"
                                stats={[
                                    { label: "Total Liquidity", value: `$${totalValue.toLocaleString()}`, icon: Wallet, color: "text-white" }
                                ]}
                            />

                            <Button 
                                onClick={() => setIsModalOpen(true)}
                                className="w-full bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black h-9 text-xs font-bold"
                            >
                                <Plus className="w-3 h-3 mr-2" /> ADD ASSET
                            </Button>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Assets" className="p-0 flex flex-col border-t-0 rounded-t-none">
                            <div className="mb-4 relative shrink-0 p-3 pb-0">
                                <Search className="absolute left-5 top-5 h-4 w-4 text-neutral-500 z-10" />
                                <Input 
                                    placeholder="Search assets..." 
                                    className="pl-8 bg-neutral-950/50 border-white/10 h-9 text-xs"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-1 px-3 pb-3 scrollbar-thin scrollbar-thumb-white/5">
                                {filteredAssets.length === 0 && <div className="text-center opacity-30 py-4"><StateText>No assets found</StateText></div>}
                                {filteredAssets.map(asset => (
                                    <SystemCard
                                        key={asset.id}
                                        title={asset.symbol}
                                        subtitle={asset.name}
                                        status="active"
                                        metric={`$${(asset.value_usd || 0).toLocaleString()}`}
                                        active={selectedAsset?.id === asset.id}
                                        onClick={() => setSelectedAsset(asset)}
                                        icon={asset.type === 'crypto' ? Wallet : CreditCard}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Holdings" dominance="dominant" className="p-0 flex flex-col border-b">
                            {selectedAsset ? (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4">
                                    <SystemDetailHeader
                                        title={selectedAsset.name}
                                        subtitle={`${selectedAsset.balance} ${selectedAsset.symbol} • $${(selectedAsset.value_usd || 0).toLocaleString()}`}
                                        category={(selectedAsset.type || 'unknown').toUpperCase()}
                                        icon={selectedAsset.type === 'crypto' ? Wallet : CreditCard}
                                        addonContext="finance"
                                    >
                                        <div className="flex gap-2">
                                            <Button 
                                                className="bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black h-8 text-xs"
                                                onClick={() => toast.success("Deposit address copied to clipboard")}
                                            >
                                                <ArrowDownLeft className="w-3 h-3 mr-2" /> DEPOSIT
                                            </Button>
                                            <Button 
                                                variant="outline" 
                                                className="border-white/10 h-8 text-xs"
                                                onClick={() => toast.success("Withdrawal module loading...")}
                                            >
                                                <ArrowUpRight className="w-3 h-3 mr-2" /> WITHDRAW
                                            </Button>
                                        </div>
                                    </SystemDetailHeader>

                                    <div className="flex-1 p-8 space-y-8 overflow-y-auto bg-transparent">
                                        <AddonGate
                                            addonName="Ledger Quant"
                                            title="Advanced Analytics"
                                            icon={TrendingUp}
                                            fallback={
                                                <Layer level="state">
                                                    <div className="h-48 w-full bg-transparent rounded border border-white/5 p-4 flex flex-col items-center justify-center relative overflow-hidden">
                                                        <div className="absolute inset-0 bg-neutral-900/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center text-center p-6">
                                                            <TrendingUp className="w-8 h-8 text-[hsl(var(--color-execution))] mb-2" />
                                                            <IntentText className="mb-1">Unlock Ledger Quant</IntentText>
                                                            <StateText className="text-xs max-w-xs mb-4">Deep liquidity analysis and predictive APY modeling requires the Quant engine.</StateText>
                                                            <Link to={createPageUrl('Marketplace') + '?filter=Ledger%20Quant'}>
                                                                <Button size="sm" className="bg-[hsl(var(--color-execution))] text-black">Get Module</Button>
                                                            </Link>
                                                        </div>
                                                        {/* Blurred background chart for effect */}
                                                        <div className="w-full h-full opacity-20 blur-sm">
                                                            <ChartFrame label="PREVIEW" metric="LOCKED" category="execution" />
                                                        </div>
                                                    </div>
                                                </Layer>
                                            }
                                        >
                                            <Layer level="state" className="h-64">
                                                <LedgerQuant selectedAsset={selectedAsset} />
                                            </Layer>
                                        </AddonGate>
                                        
                                        <Layer level="orientation">
                                            <OrientingText className="mb-2">ASSET DETAILS</OrientingText>
                                            <div className="space-y-4 font-mono text-xs">
                                                <div className="flex justify-between py-2 border-b border-white/5">
                                                    <span className="text-neutral-500">Wallet Address</span>
                                                    <span className="text-neutral-300 break-all max-w-[200px] text-right">{selectedAsset.wallet_address || "N/A"}</span>
                                                </div>
                                                <div className="flex justify-between py-2 border-b border-white/5">
                                                    <span className="text-neutral-500">Last Updated</span>
                                                    <span className="text-neutral-300">Just now</span>
                                                </div>
                                            </div>
                                        </Layer>
                                    </div>
                                </div>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center group select-none cursor-pointer" onClick={() => setIsModalOpen(true)}>
                                    <div className="p-6 rounded-full bg-transparent border border-white/5 mb-4 group-hover:border-[hsl(var(--color-execution))] group-hover:bg-[hsl(var(--color-execution))]/10 transition-all duration-500">
                                        <Wallet className="w-12 h-12 text-neutral-600 group-hover:text-[hsl(var(--color-execution))] transition-colors" />
                                    </div>
                                    <OrientingText className="mb-2 text-lg">Asset Portfolio</OrientingText>
                                    <p className="text-sm text-neutral-500 max-w-xs text-center leading-relaxed mb-4">
                                        Select an asset to view performance history, or click here to add a new capital source.
                                    </p>
                                    <Button variant="outline" className="opacity-0 group-hover:opacity-100 transition-opacity border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))] h-8 text-xs">
                                        Add New Asset
                                    </Button>
                                </div>
                            )}
                        </Quadrant>

                        <Quadrant type="intent" step="4" title="Connections" dominance="supporting" className="border-t-0 rounded-t-none">
                             <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <StateText className="text-[10px] opacity-50 uppercase">Linked Accounts</StateText>
                                    <SyncButton category="finance" />
                                </div>
                                <IntegrationStatus category="finance" className="flex-wrap" />
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
            {isModalOpen && <AssetModal open={isModalOpen} onOpenChange={setIsModalOpen} />}
        </div>
    );
}