import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Activity, Shield, Zap, Globe, Cpu, 
    DollarSign, Users, MessageSquare, Terminal,
    AlertCircle, CheckCircle2, Command
} from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer, 
    ChartFrame, AtomicParagraph
} from '@/components/ui/design-system/System';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from '@/lib/utils';
import { TimeGraph } from '@/components/ui/design-system/Infographics';

/* -------------------------------------------------------------------------- */
/*                                DATA INGESTION                              */
/* -------------------------------------------------------------------------- */

const useOmniData = () => {
    return useQuery({
        queryKey: ['omni_telemetry'],
        queryFn: async () => {
            const [nodes, agents, assets, customers, logs] = await Promise.all([
                base44.entities.Node.list(),
                base44.entities.Agent.list(),
                base44.entities.Asset.list(),
                base44.entities.Customer.list(),
                base44.entities.Log.list({ limit: 20, sort: { timestamp: -1 } })
            ]);

            return {
                nodes,
                agents,
                assets,
                customers,
                logs,
                timestamp: new Date().toISOString()
            };
        },
        refetchInterval: 5000
    });
};

/* -------------------------------------------------------------------------- */
/*                                SUB-COMPONENTS                              */
/* -------------------------------------------------------------------------- */

const MetricTile = ({ label, value, trend, icon: Icon, status = 'active' }) => (
    <div className="p-4 bg-neutral-900/50 border border-white/5 rounded flex flex-col justify-between group hover:border-[hsl(var(--color-intent))] transition-colors">
        <div className="flex justify-between items-start mb-2">
            <div className={cn("p-2 rounded bg-neutral-950 border border-white/5", 
                status === 'critical' ? "text-[hsl(var(--color-error))]" : 
                status === 'warning' ? "text-[hsl(var(--color-warning))]" : 
                "text-[hsl(var(--color-active))]"
            )}>
                <Icon className="w-4 h-4" />
            </div>
            <SemanticDot type={status === 'critical' ? 'error' : status === 'warning' ? 'warning' : 'active'} />
        </div>
        <div>
            <StateText className="opacity-50 text-[10px] uppercase tracking-wider mb-1">{label}</StateText>
            <IntentText className="text-xl font-mono">{value}</IntentText>
            {trend && <StateText className={cn("text-[10px]", trend.includes('+') ? "text-[hsl(var(--color-execution))]" : "text-[hsl(var(--color-error))]")}>{trend}</StateText>}
        </div>
    </div>
);

const UnifiedFeed = ({ logs }) => (
    <div className="space-y-1 overflow-y-auto pr-2 h-full scrollbar-thin scrollbar-thumb-white/5">
        {logs.map((log) => (
            <div key={log.id} className="p-2 border-l-2 border-white/5 hover:border-[hsl(var(--color-intent))] bg-neutral-900/20 hover:bg-neutral-900/50 transition-all flex gap-3 text-xs font-mono">
                <span className="text-neutral-600 shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</span>
                <span className={cn("uppercase shrink-0 w-16", 
                    log.type === 'security' ? "text-[hsl(var(--color-warning))]" : 
                    log.type === 'system' ? "text-[hsl(var(--color-system))]" : "text-neutral-500"
                )}>{log.type}</span>
                <span className="text-neutral-300 truncate">{log.content}</span>
            </div>
        ))}
    </div>
);

const AgentMatrix = ({ agents }) => (
    <div className="grid grid-cols-2 gap-2">
        {agents.slice(0, 6).map(agent => (
            <div key={agent.id} className="p-2 bg-neutral-900 border border-white/5 rounded flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <div className={cn("w-2 h-2 rounded-full animate-pulse", 
                        agent.status === 'idle' ? "bg-neutral-500" : 
                        agent.status === 'executing' ? "bg-[hsl(var(--color-intent))]" : "bg-[hsl(var(--color-warning))]"
                    )} />
                    <span className="text-xs font-bold text-neutral-300">{agent.name}</span>
                </div>
                <span className="text-[9px] font-mono text-neutral-600 uppercase">{agent.status}</span>
            </div>
        ))}
    </div>
);

/* -------------------------------------------------------------------------- */
/*                                MAIN DASHBOARD                              */
/* -------------------------------------------------------------------------- */

export default function OmniDashboard() {
    const { data, isLoading } = useOmniData();
    const [cliInput, setCliInput] = useState('');

    if (isLoading || !data) return (
        <div className="h-full w-full bg-transparent flex items-center justify-center">
            <div className="text-center space-y-4">
                <Cpu className="w-12 h-12 text-[hsl(var(--color-system))] animate-pulse mx-auto" />
                <OrientingText>INITIALIZING OMNI-CONSCIOUSNESS...</OrientingText>
            </div>
        </div>
    );

    // Derived Metrics
    const totalAssets = data.assets.reduce((acc, curr) => acc + (curr.value_usd || 0), 0);
    const activeNodes = data.nodes.filter(n => n.status === 'connected').length;
    const nodeHealth = Math.round((activeNodes / (data.nodes.length || 1)) * 100);
    const activeAgents = data.agents.filter(a => a.status === 'executing').length;
    const securityAlerts = data.logs.filter(l => l.type === 'security' && l.severity === 'critical').length;

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        {/* TL: ORIENTATION (Global Status) */}
                        <Quadrant type="orientation" className="border-b bg-neutral-950/80 backdrop-blur">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Zap className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">OMNI-DASHBOARD</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">System 1-Body View</IntentText>
                                </div>
                                <div className="text-right">
                                    <StateText className="text-[10px] opacity-50">SYNC RATE</StateText>
                                    <div className="flex items-center gap-2 text-[hsl(var(--color-system))] font-mono text-sm">
                                        <Activity className="w-3 h-3 animate-pulse" /> 12ms
                                    </div>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <MetricTile 
                                    label="Network Health" 
                                    value={`${nodeHealth}%`} 
                                    trend="+2% / 24h" 
                                    icon={Globe} 
                                    status={nodeHealth > 90 ? 'active' : 'warning'} 
                                />
                                <MetricTile 
                                    label="Security State" 
                                    value={securityAlerts > 0 ? "ALERT" : "SECURE"} 
                                    trend={`${securityAlerts} active`}
                                    icon={Shield} 
                                    status={securityAlerts > 0 ? 'critical' : 'active'} 
                                />
                            </div>
                        </Quadrant>

                        {/* BL: STATE (Unified Feed) */}
                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none flex flex-col">
                            <div className="flex items-center justify-between mb-4 shrink-0">
                                <OrientingText>UNIFIED TELEMETRY STREAM</OrientingText>
                                <Badge variant="outline" className="text-[9px] border-white/10 text-neutral-500">LIVE</Badge>
                            </div>
                            <UnifiedFeed logs={data.logs} />
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        {/* TR: INTENT (Command & Control) */}
                        <Quadrant type="intent" dominance="dominant" className="border-b flex flex-col">
                            <div className="flex items-center justify-between mb-6">
                                <OrientingText>COMMAND LINE INTERFACE</OrientingText>
                                <Terminal className="w-4 h-4 text-neutral-500" />
                            </div>
                            
                            <div className="flex-1 bg-black rounded border border-white/10 p-4 font-mono text-sm text-[hsl(var(--color-execution))] mb-4 overflow-hidden relative">
                                <div className="absolute inset-0 p-4 opacity-50 pointer-events-none">
                                    <div className="opacity-50">System ready.</div>
                                    <div className="opacity-50">Listening on port 443...</div>
                                    <div className="text-[hsl(var(--color-system))]">Agent Swarm initialized ({activeAgents} active).</div>
                                </div>
                                <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2">
                                    <span className="text-[hsl(var(--color-intent))]">{'>'}</span>
                                    <Input 
                                        value={cliInput}
                                        onChange={(e) => setCliInput(e.target.value)}
                                        className="border-none bg-transparent h-auto p-0 focus-visible:ring-0 text-white font-mono"
                                        placeholder="Enter system command..."
                                        autoFocus
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                                <Button variant="outline" className="border-white/10 hover:bg-white/5 hover:border-white/20 h-10 text-xs">
                                    <Command className="w-3 h-3 mr-2" /> EXECUTE WARGAME
                                </Button>
                                <Button variant="outline" className="border-white/10 hover:bg-white/5 hover:border-white/20 h-10 text-xs">
                                    <Users className="w-3 h-3 mr-2" /> SYNC CRM
                                </Button>
                                <Button className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 h-10 text-xs font-bold">
                                    DEPLOY AGENTS
                                </Button>
                            </div>
                        </Quadrant>

                        {/* BR: OUTCOME (Metrics Grid) */}
                        <Quadrant type="state" className="border-t-0 rounded-t-none overflow-y-auto">
                            <OrientingText className="mb-4">OPERATIONAL METRICS</OrientingText>
                            
                            <div className="space-y-6">
                                {/* Treasury */}
                                <Layer level="state" className="p-4">
                                    <div className="flex justify-between items-center mb-4">
                                        <div className="flex items-center gap-2">
                                            <DollarSign className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                            <StateText>TREASURY</StateText>
                                        </div>
                                        <IntentText className="font-mono">${totalAssets.toLocaleString()}</IntentText>
                                    </div>
                                    <div className="h-24 w-full bg-neutral-900/50 rounded overflow-hidden">
                                        <ChartFrame label="ASSET GROWTH" metric="+12%" trend="7D" category="execution">
                                            <TimeGraph data={[{t:'M', v:10}, {t:'T', v:12}, {t:'W', v:11}, {t:'T', v:15}, {t:'F', v:18}]} dataKey="v" category="execution" height={100} />
                                        </ChartFrame>
                                    </div>
                                </Layer>

                                {/* Swarm Health */}
                                <Layer level="state" className="p-4">
                                    <div className="flex justify-between items-center mb-4">
                                        <div className="flex items-center gap-2">
                                            <Cpu className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                            <StateText>AGENT SWARM</StateText>
                                        </div>
                                        <IntentText className="font-mono">{activeAgents} / {data.agents.length} ACTIVE</IntentText>
                                    </div>
                                    <AgentMatrix agents={data.agents} />
                                </Layer>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}