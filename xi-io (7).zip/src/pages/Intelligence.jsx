import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, SemanticDot, Layer } from '@/components/ui/design-system/SystemDesign';
import { SystemNav } from '@/components/ui/design-system/SystemComponents';
import { Brain, Cpu, Network, Zap, Shield, Search, Hammer, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import { SystemMonitor } from '@/components/agents/SystemMonitor';
import { InsightEngine } from '@/components/agents/InsightEngine';
import { ModelForge } from '@/components/agents/ModelForge';
import { cn } from '@/lib/utils';
import { AddonGate } from '@/components/integrations/AddonGate';
import NeuroLinkViz from '@/components/addons/official/NeuroLinkViz';

export default function Intelligence() {
    // 1. Check Auth State
    const { data: user, isLoading: isUserLoading } = useQuery({
        queryKey: ['me'],
        queryFn: () => base44.auth.me().catch(() => null),
        retry: false
    });

    const [activeTab, setActiveTab] = useState('insight'); // insight, forge

    // 2. Render Public Page if not logged in
    if (!isUserLoading && !user) {
        return (
            <PublicFeaturePage 
                title="Intelligence"
                subtitle="System Cognition"
                icon={Brain}
                description="Harness the power of autonomous agents. Deploy neural nets to analyze logs, predict threats, and optimize system performance in real-time."
                features={[
                    "Predictive Anomaly Detection",
                    "Natural Language Ops",
                    "Autonomous Remediation",
                    "Cognitive Load Balancing"
                ]}
                interactiveComponent={
                    <div className="w-full h-full bg-neutral-900 flex flex-col font-mono text-xs p-4">
                        <div className="flex-1 space-y-4 overflow-hidden">
                            <div className="flex gap-3">
                                <div className="w-6 h-6 rounded bg-[hsl(var(--color-intent))] flex items-center justify-center text-black font-bold">AI</div>
                                <div className="bg-white/10 rounded p-3 text-neutral-300 max-w-[80%]">
                                    System operating at nominal levels. Detected a 12% efficiency gain in the last epoch. Shall I optimize the cache strategy?
                                </div>
                            </div>
                            <div className="flex gap-3 flex-row-reverse">
                                <div className="w-6 h-6 rounded bg-white flex items-center justify-center text-black font-bold">U</div>
                                <div className="bg-[hsl(var(--color-execution))]/20 border border-[hsl(var(--color-execution))]/30 rounded p-3 text-[hsl(var(--color-execution))] max-w-[80%]">
                                    Yes, proceed with optimization.
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <div className="w-6 h-6 rounded bg-[hsl(var(--color-intent))] flex items-center justify-center text-black font-bold">AI</div>
                                <div className="bg-white/10 rounded p-3 text-neutral-300 max-w-[80%]">
                                    <div className="flex items-center gap-2 mb-2 text-[hsl(var(--color-warning))]">
                                        <Zap className="w-3 h-3" />
                                        <span>EXECUTING PROTOCOL</span>
                                    </div>
                                    <div className="w-full h-1 bg-black rounded overflow-hidden mb-1">
                                        <div className="h-full bg-[hsl(var(--color-intent))] w-[65%]" />
                                    </div>
                                    <span>Re-indexing shard 0x4A... Done.</span>
                                </div>
                            </div>
                        </div>
                        <div className="mt-4 pt-4 border-t border-white/10">
                            <div className="flex gap-2">
                                <div className="flex-1 h-8 bg-black border border-white/10 rounded px-3 flex items-center text-neutral-500">
                                    Type a command...
                                </div>
                                <div className="w-8 h-8 bg-[hsl(var(--color-intent))] rounded flex items-center justify-center text-black">
                                    <ArrowUpRight className="w-4 h-4" />
                                </div>
                            </div>
                        </div>
                    </div>
                }
            />
        );
    }

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <QuadrantGrid>
                {/* Q1: Orientation */}
                <Quadrant type="orientation" step="1" title="Modules">
                    <div className="flex justify-between items-end mb-6">
                        <div>
                            <div className="flex items-center gap-2 mb-2">
                                <Brain className="w-4 h-4 text-[hsl(var(--color-system))]" />
                                <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-system))]">INTELLIGENCE</OrientingText>
                            </div>
                            <IntentText className="text-2xl font-light">System Cognition</IntentText>
                        </div>
                        <Link to={createPageUrl('Marketplace') + '?category=intelligence'}>
                            <Button variant="ghost" size="sm" className="h-6 text-[10px] text-neutral-500 hover:text-white px-2">
                                <Plus className="w-3 h-3 mr-1" /> Addon
                            </Button>
                        </Link>
                    </div>
                    
                    <Layer level="orientation" className="mb-6 space-y-4">
                        <OrientingText className="mb-2">SELECTION</OrientingText>
                        <SystemNav 
                            items={[
                                { id: 'insight', label: 'Insight Engine', icon: Brain, type: 'active', count: 'AI' },
                                { id: 'forge', label: 'Model Forge', icon: Hammer, type: 'settled', count: 'DEV' }
                            ]}
                            activeId={activeTab}
                            onSelect={setActiveTab}
                        />
                    </Layer>
                </Quadrant>

                {/* Q2: Intent (Dominant) */}
                <Quadrant type="intent" step="2" title="Engine" dominance="dominant" className="p-0 flex flex-col">
                    {activeTab === 'insight' ? (
                        <AddonGate
                            addonName="Neuro-Link Analytics"
                            title="Neural Interface"
                            icon={Brain}
                            description="Deep system analytics and cognitive load visualization."
                        >
                            <NeuroLinkViz />
                            <div className="flex-1 border-t border-white/5">
                                <InsightEngine context="general" />
                            </div>
                        </AddonGate>
                    ) : (
                        <ModelForge />
                    )}
                </Quadrant>

                {/* Q3: State */}
                <Quadrant type="state" step="3" title="Monitor">
                     <SystemMonitor domainFamily="XI-IO" />
                </Quadrant>

                {/* Q4: Outcome */}
                <Quadrant type="intent" step="4" title="Performance" dominance="supporting">
                     <div className="space-y-4">
                        <div className="p-4 bg-neutral-900/50 rounded border border-white/5">
                            <OrientingText className="mb-2">METRICS</OrientingText>
                            <div className="flex justify-between items-center mb-2">
                                <StateText>Response Time</StateText>
                                <span className="font-mono text-xs text-green-400">120ms</span>
                            </div>
                            <div className="flex justify-between items-center mb-2">
                                <StateText>Token Usage</StateText>
                                <span className="font-mono text-xs text-blue-400">1.2M</span>
                            </div>
                            <div className="w-full bg-white/5 h-1 rounded overflow-hidden mt-4">
                                <div className="h-full bg-[hsl(var(--color-system))] w-[60%]" />
                            </div>
                        </div>
                     </div>
                </Quadrant>
            </QuadrantGrid>
        </div>
    );
}