import React from 'react';
import { motion } from 'framer-motion';
import { Users, TrendingUp, Shield, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { GlassPanel } from '@/components/ui/GlassPanel';
import { OrientingText, IntentText } from '@/components/ui/design-system/SystemDesign';

export default function CRMLanding() {
    return (
        <div className="min-h-screen bg-black text-white overflow-hidden relative">
            {/* Background Effects */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(79,70,229,0.1),transparent_50%)]" />
            
            <div className="relative z-10 max-w-7xl mx-auto px-6 py-24">
                {/* Hero Section */}
                <div className="text-center mb-24">
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-mono tracking-widest uppercase mb-6"
                    >
                        <Users className="w-3 h-3" />
                        <span>Rolodex Module</span>
                    </motion.div>
                    
                    <motion.h1 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 }}
                        className="text-5xl md:text-7xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/50"
                    >
                        Relationships, <br />
                        <span className="text-indigo-500">Encoded.</span>
                    </motion.h1>
                    
                    <motion.p 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-xl text-neutral-400 max-w-2xl mx-auto mb-10"
                    >
                        Turn your network into a net worth. AI-driven insights, automated follow-ups, and relationship intelligence.
                    </motion.p>
                    
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.3 }}
                        className="flex flex-col sm:flex-row gap-4 justify-center"
                    >
                        <Link to={createPageUrl('Pricing')}>
                            <Button size="lg" className="bg-indigo-600 hover:bg-indigo-700 text-white min-w-[200px]">
                                Start Free Trial <ArrowRight className="ml-2 w-4 h-4" />
                            </Button>
                        </Link>
                        <Link to={createPageUrl('GatewayLanding')}>
                            <Button size="lg" variant="outline" className="border-white/10 hover:bg-white/5 text-white min-w-[200px]">
                                Live Demo
                            </Button>
                        </Link>
                    </motion.div>
                </div>

                {/* Mirror Preview - Simplified CRM View */}
                <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 }}
                    className="relative mx-auto max-w-5xl"
                >
                    <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl opacity-20 blur" />
                    <GlassPanel className="relative aspect-video bg-neutral-900/80 backdrop-blur-xl border-white/10 rounded-xl overflow-hidden flex flex-col">
                        <div className="p-4 border-b border-white/5 flex items-center justify-between">
                            <div className="flex gap-2">
                                <div className="w-3 h-3 rounded-full bg-red-500/20" />
                                <div className="w-3 h-3 rounded-full bg-yellow-500/20" />
                                <div className="w-3 h-3 rounded-full bg-green-500/20" />
                            </div>
                            <div className="text-xs font-mono text-neutral-500">RELATIONSHIP_MATRIX_V1</div>
                        </div>
                        <div className="flex-1 p-8 flex items-center justify-center bg-[url('https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=2670')] bg-cover bg-center opacity-50 grayscale hover:grayscale-0 transition-all duration-700">
                             <div className="bg-black/80 backdrop-blur-md p-8 rounded-2xl border border-white/10 text-center max-w-md">
                                <Users className="w-12 h-12 text-indigo-500 mx-auto mb-4" />
                                <h3 className="text-2xl font-bold mb-2">Interactive CRM Preview</h3>
                                <p className="text-neutral-400 mb-6">Experience the power of automated relationship management.</p>
                                <Button variant="outline" className="border-indigo-500/50 text-indigo-400 hover:bg-indigo-500/10">
                                    Load Simulation
                                </Button>
                             </div>
                        </div>
                    </GlassPanel>
                </motion.div>
                
                {/* Features Grid */}
                <div className="grid md:grid-cols-3 gap-8 mt-24">
                    {[
                        { title: "Smart Contact Enrichment", desc: "Automatically populate profiles with social data and company intel." },
                        { title: "Deal Velocity Tracking", desc: "AI predicts deal closure probability and suggests next steps." },
                        { title: "Unified Comms", desc: "Sync emails, calls, and messages into a single timeline." }
                    ].map((feature, i) => (
                        <div key={i} className="p-6 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-colors">
                            <CheckCircle2 className="w-8 h-8 text-indigo-500 mb-4" />
                            <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                            <p className="text-neutral-400">{feature.desc}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}