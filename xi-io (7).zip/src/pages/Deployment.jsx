import React from 'react';
import { DeploymentUploader } from '@/components/deployment/DeploymentUploader';
import { OrientingText, IntentText } from '@/components/ui/design-system/System';
import { CiCdPipeline } from '@/components/deployment/CiCdPipeline';

export default function Deployment() {
    return (
        <div className="min-h-screen bg-black p-6 md:p-12">
            <div className="max-w-7xl mx-auto space-y-12">
                
                {/* Header */}
                <div className="flex flex-col gap-2">
                    <OrientingText className="text-[hsl(var(--color-execution))]">OPERATIONS</OrientingText>
                    <IntentText className="text-4xl md:text-5xl font-light text-white">
                        Deployment Pipeline
                    </IntentText>
                    <p className="text-neutral-500 max-w-2xl text-lg font-light">
                        Automated provisioning system for white-label instances. 
                        Upload a validated bundle to initiate the API discovery and injection sequence.
                    </p>
                </div>

                {/* Main Interface */}
                <DeploymentUploader />
                
                {/* Automated Pipeline */}
                <div className="flex flex-col gap-2 pt-8 border-t border-white/10">
                    <OrientingText className="text-[hsl(var(--color-execution))]">AUTOMATION</OrientingText>
                    <IntentText className="text-3xl font-light text-white">
                        CI/CD Status
                    </IntentText>
                </div>
                <div className="pb-20">
                    <CiCdPipeline />
                </div>
            </div>
        </div>
    );
}