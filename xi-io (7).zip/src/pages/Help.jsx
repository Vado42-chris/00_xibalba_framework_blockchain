import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    HelpCircle, Ticket, MessageSquare, Plus, ChevronRight, 
    CheckCircle2, AlertCircle, Clock, Search, FileText
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { OrientingText, IntentText, StateText, QuadrantGrid, Quadrant } from '@/components/ui/design-system/System';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { FluidGrid } from '@/components/ui/FluidGrid';

import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import { Trophy, Star, BookOpen, GraduationCap } from 'lucide-react';

export default function Help() {
    const [view, setView] = useState('list'); // list | detail | new | academy
    const [selectedTicket, setSelectedTicket] = useState(null);
    const [filter, setFilter] = useState('');
    const queryClient = useQueryClient();

    const { data: tickets = [] } = useQuery({
        queryKey: ['my_tickets'],
        queryFn: async () => {
            const user = await base44.auth.me().catch(() => ({ email: 'anonymous@xi-io.com' }));
            return base44.entities.SupportTicket.filter({ user_email: user.email });
        },
        initialData: []
    });

    const createTicketMutation = useMutation({
        mutationFn: async (data) => {
            const user = await base44.auth.me().catch(() => ({ email: 'anonymous@xi-io.com' }));
            await base44.entities.SupportTicket.create({
                ...data,
                user_email: user.email,
                status: 'open',
                comments: []
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['my_tickets']);
            setView('list');
            toast.success("Support ticket created");
        }
    });

    const addCommentMutation = useMutation({
        mutationFn: async ({ id, message }) => {
            const user = await base44.auth.me().catch(() => ({ full_name: 'Me' }));
            const ticket = tickets.find(t => t.id === id);
            if (!ticket) return;

            const newComment = {
                author: user.full_name || 'User',
                message,
                timestamp: new Date().toISOString()
            };
            const updatedComments = [...(ticket.comments || []), newComment];
            await base44.entities.SupportTicket.update(id, { comments: updatedComments });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['my_tickets']);
            toast.success("Reply sent");
        }
    });

    const filteredTickets = tickets.filter(t => 
        t.subject.toLowerCase().includes(filter.toLowerCase())
    );

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <HelpCircle className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">SUPPORT CENTER</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Service Desk</IntentText>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Badge variant="outline" className="border-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10">
                                        {tickets.length} TICKETS
                                    </Badge>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2 mt-4">
                                <Button 
                                    onClick={() => setView('new')} 
                                    className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 h-8 text-xs font-bold"
                                >
                                    <Plus className="w-3 h-3 mr-2" /> NEW REQUEST
                                </Button>
                                <Button 
                                    variant="outline"
                                    onClick={() => setView('academy')}
                                    className="border-white/10 text-neutral-400 hover:text-white h-8 text-xs"
                                >
                                    <GraduationCap className="w-3 h-3 mr-2" /> ACADEMY
                                </Button>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none flex flex-col">
                            <div className="mb-4 relative shrink-0">
                                <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search tickets..." 
                                    className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs"
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-1 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {filteredTickets.length === 0 && (
                                    <div className="text-center py-8 opacity-30">
                                        <Ticket className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                                        <StateText>No tickets found</StateText>
                                    </div>
                                )}
                                {filteredTickets.map((ticket) => (
                                    <SystemCard
                                        key={ticket.id}
                                        title={ticket.subject}
                                        subtitle={`#${ticket.id.slice(0,6)} • ${new Date(ticket.created_date).toLocaleDateString()}`}
                                        status={ticket.status === 'open' ? 'active' : ticket.status === 'resolved' ? 'success' : 'settled'}
                                        metric={ticket.status.toUpperCase()}
                                        active={selectedTicket?.id === ticket.id}
                                        onClick={() => { setSelectedTicket(ticket); setView('detail'); }}
                                        icon={Ticket}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col">
                            {view === 'new' && (
                                <div className="p-8 h-full overflow-y-auto">
                                    <div className="max-w-xl mx-auto space-y-6">
                                        <OrientingText className="text-xl">SUBMIT NEW TICKET</OrientingText>
                                        <form className="space-y-4" onSubmit={(e) => {
                                            e.preventDefault();
                                            const fd = new FormData(e.target);
                                            createTicketMutation.mutate({
                                                subject: fd.get('subject'),
                                                description: fd.get('description'),
                                                category: fd.get('category'),
                                                priority: fd.get('priority')
                                            });
                                        }}>
                                            <div className="space-y-2">
                                                <Label>Subject</Label>
                                                <Input name="subject" required className="bg-neutral-900 border-white/10" />
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div className="space-y-2">
                                                    <Label>Category</Label>
                                                    <Select name="category" defaultValue="question">
                                                        <SelectTrigger className="bg-neutral-900 border-white/10"><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="question">Question</SelectItem>
                                                            <SelectItem value="bug">Bug</SelectItem>
                                                            <SelectItem value="feature_request">Feature</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                                <div className="space-y-2">
                                                    <Label>Priority</Label>
                                                    <Select name="priority" defaultValue="medium">
                                                        <SelectTrigger className="bg-neutral-900 border-white/10"><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="low">Low</SelectItem>
                                                            <SelectItem value="medium">Medium</SelectItem>
                                                            <SelectItem value="high">High</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Description</Label>
                                                <Textarea name="description" required className="bg-neutral-900 border-white/10 h-32" />
                                            </div>
                                            <div className="flex justify-end gap-2 pt-4">
                                                <Button type="button" variant="ghost" onClick={() => setView('list')}>Cancel</Button>
                                                <Button type="submit" className="bg-[hsl(var(--color-execution))] text-black">Submit</Button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            )}

                            {view === 'detail' && selectedTicket && (
                                <div className="flex flex-col h-full animate-in fade-in duration-300">
                                    <div className="p-8 border-b border-white/5 bg-neutral-900/30">
                                        <Badge variant="outline" className="mb-2 border-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]">
                                            {selectedTicket.category.toUpperCase()}
                                        </Badge>
                                        <IntentText className="text-2xl font-light mb-4">{selectedTicket.subject}</IntentText>
                                        <div className="p-4 bg-neutral-950/50 rounded border border-white/5 text-sm text-neutral-300 leading-relaxed">
                                            {selectedTicket.description}
                                        </div>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-8 space-y-6 bg-neutral-950">
                                        <OrientingText>DISCUSSION LOG</OrientingText>
                                        <div className="space-y-4">
                                            {selectedTicket.comments?.map((comment, idx) => (
                                                <div key={idx} className="flex gap-4">
                                                    <div className="w-8 h-8 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center text-xs font-bold text-neutral-500">
                                                        {comment.author?.[0]}
                                                    </div>
                                                    <div className="flex-1 space-y-1">
                                                        <div className="flex items-center justify-between">
                                                            <span className="text-sm font-medium text-white">{comment.author}</span>
                                                            <span className="text-xs text-neutral-600">{new Date(comment.timestamp).toLocaleString()}</span>
                                                        </div>
                                                        <div className="p-3 bg-neutral-900 border border-white/5 rounded-lg text-sm text-neutral-300">
                                                            {comment.message}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="pt-4 border-t border-white/5">
                                            <form onSubmit={(e) => {
                                                e.preventDefault();
                                                const fd = new FormData(e.target);
                                                addCommentMutation.mutate({ id: selectedTicket.id, message: fd.get('message') });
                                                e.target.reset();
                                            }}>
                                                <div className="flex gap-4">
                                                    <Textarea name="message" placeholder="Reply..." className="bg-neutral-900 border-white/10 min-h-[80px]" />
                                                    <Button type="submit" size="icon" className="h-20 w-12 bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90">
                                                        <ChevronRight className="w-5 h-5" />
                                                    </Button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {view === 'academy' && (
                                <div className="p-8 h-full overflow-y-auto">
                                    <OrientingText className="mb-6">SYSTEM ACADEMY</OrientingText>
                                    <div className="grid grid-cols-2 gap-4">
                                        {[
                                            { title: "Node Basics", xp: 500, desc: "Running a sovereign node." },
                                            { title: "Code Studio", xp: 1000, desc: "Master the IDE." },
                                            { title: "Pipelines", xp: 750, desc: "CI/CD flows." },
                                            { title: "Agent Swarm", xp: 2000, desc: "AI orchestration." },
                                        ].map((course, i) => (
                                            <div key={i} className="p-6 rounded-xl bg-neutral-900 border border-white/5 hover:border-[hsl(var(--color-intent))] transition-all group cursor-pointer relative overflow-hidden">
                                                <div className="absolute top-4 right-4 text-[hsl(var(--color-execution))] font-bold text-xs flex items-center gap-1">
                                                    <Trophy className="w-3 h-3" /> {course.xp} XP
                                                </div>
                                                <h3 className="text-lg font-bold text-white mb-2">{course.title}</h3>
                                                <p className="text-sm text-neutral-400 mb-4">{course.desc}</p>
                                                <div className="text-[hsl(var(--color-active))] text-xs opacity-0 group-hover:opacity-100 transition-opacity">Start Module →</div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {!selectedTicket && view === 'list' && (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                    <Ticket className="w-16 h-16 text-neutral-500 stroke-1" />
                                    <div>
                                        <IntentText className="text-xl font-light">Service Desk</IntentText>
                                        <StateText>Select a ticket to view details or start a new request.</StateText>
                                    </div>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}