import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Shield, User, Bot, FileDiff, Database, Lock, ArrowDown, Activity } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText 
} from '@/components/ui/design-system/SystemDesign';
import VisualGraphEditor from '@/components/workflows/VisualGraphEditor';

export default function FlowArchitecture() {
  const { data: nodes = [] } = useQuery({
      queryKey: ['nodes'],
      queryFn: () => base44.entities.Node.list(),
      initialData: []
  });

  const { data: agents = [] } = useQuery({
      queryKey: ['agents'],
      queryFn: () => base44.entities.Agent.list(),
      initialData: []
  });

  return (
    <div className="h-full w-full bg-transparent overflow-hidden">
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="orientation" className="border-b">
                        <div className="flex justify-between items-end mb-6">
                            <div>
                                <div className="flex items-center gap-2 mb-2">
                                    <Activity className="w-4 h-4 text-[hsl(var(--color-active))]" />
                                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-active))]">WORKFLOW ORCHESTRATION</OrientingText>
                                </div>
                                <IntentText className="text-2xl font-light">Visual Pipeline Builder</IntentText>
                            </div>
                        </div>
                        <StateText className="text-[hsl(var(--fg-orientation))] text-sm font-mono mt-4">
                            "Design autonomous loops by connecting agents to compute nodes."
                        </StateText>
                    </Quadrant>

                    <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                        <OrientingText className="mb-4">AVAILABLE RESOURCES</OrientingText>
                        <div className="space-y-4">
                            <div>
                                <StateText className="mb-2 text-xs opacity-50">COMPUTE NODES</StateText>
                                <div className="space-y-1">
                                    {nodes.map(n => (
                                        <div key={n.id} className="px-2 py-1 rounded bg-neutral-900 border border-white/5 text-xs text-neutral-400">
                                            {n.name}
                                        </div>
                                    ))}
                                    {nodes.length === 0 && <div className="text-xs text-neutral-600 italic">No nodes available</div>}
                                </div>
                            </div>
                            <div>
                                <StateText className="mb-2 text-xs opacity-50">AGENTS</StateText>
                                <div className="space-y-1">
                                    {agents.map(a => (
                                        <div key={a.id} className="px-2 py-1 rounded bg-neutral-900 border border-white/5 text-xs text-neutral-400">
                                            {a.name}
                                        </div>
                                    ))}
                                    {agents.length === 0 && <div className="text-xs text-neutral-600 italic">No agents available</div>}
                                </div>
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <div className="h-full w-full bg-transparent">
                    <VisualGraphEditor nodes={nodes} agents={agents} />
                </div>
            }
        />
    </div>
  );
}