import React, { useState, useEffect } from 'react';
import { 
    Zap, Ghost, Shield, Cpu, Activity, 
    Network, ArrowRightLeft, Radio, Terminal
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';
import { SystemNav, SystemCard } from '@/components/ui/design-system/SystemComponents';
import { SystemLog } from '@/components/ui/design-system/SystemContent';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { cn } from '@/lib/utils';
import { WargameSimulation } from '@/components/reaper/WargameSimulation';
import CloudBackupManager from '@/components/reaper/CloudBackupManager';
import ReaperIDE from '@/components/reaper/ReaperIDE';
import DotfileManager from '@/components/identity/DotfileManager';
import StackFoundation from '@/components/reaper/StackFoundation';
import { toast } from 'sonner';
import { TutorialOverlay } from '@/components/education/TutorialOverlay';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";

const LocalBridge = ({ status, onConnect }) => {
    return (
        <Layer level="intent" className="p-4 flex flex-col gap-4 border-l-4 border-l-[hsl(var(--color-intent))]">
            <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                    <Radio className={cn("w-4 h-4", status === 'connected' ? "text-[hsl(var(--color-execution))] animate-pulse" : "text-neutral-500")} />
                    <IntentText className="font-bold">LOCAL OLLAMA BRIDGE</IntentText>
                </div>
                <Badge variant="outline" className={cn("text-[9px] uppercase", status === 'connected' ? "border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))]" : "border-neutral-500 text-neutral-500")}>
                    {status}
                </Badge>
            </div>
            
            <StateText className="opacity-70 leading-relaxed">
                Direct client-side handshake enabled. Utilizing local GPU compute for inference privacy. 
                Routing: <span className="font-mono text-[hsl(var(--color-active))]">http://localhost:11434</span>
            </StateText>

            <Button 
                onClick={onConnect} 
                disabled={status === 'connected'}
                className={cn("w-full text-xs font-mono", status === 'connected' ? "bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))]" : "bg-[hsl(var(--color-intent))] text-white")}
            >
                {status === 'connected' ? "UPLINK ESTABLISHED" : "INITIATE HANDSHAKE"}
            </Button>
        </Layer>
    );
};

export default function ReaperSpace() {
    const [localStatus, setLocalStatus] = useState('disconnected');
    const [computeLoad, setComputeLoad] = useState(0);

    // Dotfiles State
    const [dotfiles, setDotfiles] = useState([
        { id: 1, name: '.zshrc', status: 'synced', size: '4.2kb', updated: '2h ago' },
        { id: 2, name: '.vimrc', status: 'synced', size: '12kb', updated: '2d ago' },
        { id: 3, name: '.gitconfig', status: 'local', size: '1kb', updated: '5d ago' },
        { id: 4, name: '.ssh/config', status: 'encrypted', size: '2kb', updated: '1w ago' },
    ]);

    // Simulate compute load
    useEffect(() => {
        const interval = setInterval(() => {
            setComputeLoad(prev => {
                const noise = Math.random() * 10 - 5;
                return Math.min(100, Math.max(0, prev + noise));
            });
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    const handleConnect = async () => {
        setLocalStatus('negotiating');
        try {
            // Attempt real handshake with Local Ollama
            const controller = new AbortController();
            const id = setTimeout(() => controller.abort(), 1000);
            const res = await fetch('http://localhost:11434/api/tags', { 
                signal: controller.signal 
            });
            clearTimeout(id);
            
            if (res.ok) {
                setLocalStatus('connected');
                setComputeLoad(20); // Local offload reduces global load
                toast.success("Local Cortex Linked: localhost:11434");
            } else {
                throw new Error("Handshake refused");
            }
        } catch (e) {
            console.warn("Local bridge failed, falling back to simulation for demo", e);
            // Fallback for demo purposes if user doesn't have Ollama running
            setTimeout(() => {
                setLocalStatus('connected');
                setComputeLoad(80);
            }, 1500);
        }
    };

    const handleAddDotfile = (file) => {
        setDotfiles(prev => [file, ...prev]);
    };

    const handleSaveConsensus = (consensus) => {
        const fileName = `.wargame_${Date.now()}.log`;
        // Simulate Blockchain Hashing
        const mockHash = '0x' + Array.from(crypto.getRandomValues(new Uint8Array(4))).map(b => b.toString(16).padStart(2, '0')).join('') + '...';
        
        handleAddDotfile({
            id: Date.now(),
            name: fileName,
            status: 'synced',
            size: `${(JSON.stringify(consensus).length / 1024).toFixed(2)}kb`,
            updated: 'Just now',
            hash: mockHash
        });
        toast.success(`Consensus saved to ${fileName}`);
    };

    const [view, setView] = useState('wargame');
    
    // Collaborative: Mock active users
    const activeUsers = [
        { id: 1, name: "Neo", role: "Operator", status: "online", color: "bg-green-500" },
        { id: 2, name: "Trinity", role: "SysAdmin", status: "coding", color: "bg-purple-500" },
        { id: 3, name: "Morpheus", role: "Observer", status: "idle", color: "bg-blue-500" },
    ];

    return (
        <div className="h-full w-full bg-transparent overflow-hidden flex flex-col">
            {/* Main Content */}
            <FluidGrid
                className="flex-1 overflow-hidden"
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Ghost className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">REAPER SPACE</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Unlimited Compute</IntentText>
                                </div>
                                <div className="flex flex-col items-end">
                                   <StateText className="text-[9px] uppercase tracking-widest">Global Load</StateText>
                                   <div className="flex items-center gap-2">
                                        <div className="w-24 h-1 bg-neutral-800 rounded-full overflow-hidden">
                                           <div 
                                               className="h-full bg-[hsl(var(--color-intent))] transition-all duration-300" 
                                               style={{ width: `${computeLoad}%` }}
                                           />
                                        </div>
                                        <span className="font-mono text-[hsl(var(--color-intent))] text-xs">{Math.round(computeLoad)}%</span>
                                   </div>
                                </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4 h-full min-h-0">
                                    <div className="flex flex-col gap-4 h-full overflow-hidden">
                                        <Layer level="orientation" className="flex-1 overflow-hidden flex flex-col p-0">
                                            <div className="p-3 border-b border-white/5 flex items-center justify-between bg-black/20">
                                                <OrientingText className="font-bold">INFRASTRUCTURE STACK</OrientingText>
                                                <div className="flex gap-2">
                                                    <Badge variant="outline" className="text-[9px] h-4 border-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))]">LIVE</Badge>
                                                    <span className="text-[9px] text-neutral-500 font-mono">LIFT FROM BOTTOM</span>
                                                </div>
                                            </div>
                                            <StackFoundation />
                                        </Layer>
                                    </div>

                                    <div className="flex flex-col gap-4 h-full overflow-hidden">
                                        <LocalBridge status={localStatus} onConnect={handleConnect} />
                                        
                                        <Layer level="state" className="flex-1 flex flex-col font-mono text-[10px] min-h-0">
                                           <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/5">
                                               <Terminal className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                                               <span className="text-[hsl(var(--color-execution))]">SYSTEM LOG</span>
                                           </div>
                                           <SystemLog 
                                                className="flex-1"
                                                logs={[
                                                    { type: 'SYS', content: 'Stack topology initialized.', status: 'active', timestamp: new Date().toISOString() },
                                                    { type: 'NET', content: 'Monitoring uplink integrity...', status: 'nominal', timestamp: new Date(Date.now() - 5000).toISOString() },
                                                    ...(localStatus === 'connected' ? [
                                                        { type: 'OK', content: 'Local Bridge active.', status: 'active', timestamp: new Date(Date.now() - 10000).toISOString() },
                                                        { type: 'GPU', content: 'Offloading inference to GPU:0', status: 'nominal', timestamp: new Date(Date.now() - 9000).toISOString() },
                                                    ] : [])
                                                ]}
                                           />
                                        </Layer>
                                    </div>
                                </div>
                                </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                             <OrientingText className="mb-4">SYNC STATUS</OrientingText>
                             <div className="space-y-4">
                                <SystemCard 
                                    title="Cloud Agents"
                                    subtitle="Distributed Swarm"
                                    icon={Network}
                                    status="active"
                                    className="p-2"
                                >
                                    <div className="flex gap-1 justify-end mt-1">
                                        <SemanticDot type="active" />
                                        <SemanticDot type="active" />
                                        <SemanticDot type="settled" />
                                    </div>
                                </SystemCard>

                                <div className="flex items-center justify-center">
                                    <ArrowRightLeft className="w-4 h-4 text-neutral-600 rotate-90" />
                                </div>
                                
                                <SystemCard 
                                    title="Local Tensor"
                                    subtitle="GPU:0 Inference"
                                    icon={Cpu}
                                    status={localStatus === 'connected' ? 'active' : 'error'}
                                    className="p-2"
                                />
                                
                                <div className="pt-4 border-t border-white/5">
                                    <DotfileManager files={dotfiles} onAddFile={handleAddDotfile} />
                                </div>
                             </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col">
                            <Tabs value={view} onValueChange={setView} className="flex-1 flex flex-col h-full">
                                <div className="px-6 pt-4 border-b border-white/5 bg-neutral-900/50">
                                    <TabsList className="bg-transparent h-10 p-0 gap-4">
                                        <TabsTrigger 
                                            value="wargame" 
                                            className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-intent))] data-[state=active]:bg-transparent px-0 pb-2 text-xs uppercase tracking-wider text-neutral-500 data-[state=active]:text-[hsl(var(--color-intent))]"
                                        >
                                            Simulation
                                        </TabsTrigger>
                                        <TabsTrigger 
                                            value="backups" 
                                            className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-system))] data-[state=active]:bg-transparent px-0 pb-2 text-xs uppercase tracking-wider text-neutral-500 data-[state=active]:text-[hsl(var(--color-system))]"
                                        >
                                            Cloud Backups
                                        </TabsTrigger>
                                        <TabsTrigger 
                                            value="forge" 
                                            className="rounded-none border-b-2 border-transparent data-[state=active]:border-[hsl(var(--color-execution))] data-[state=active]:bg-transparent px-0 pb-2 text-xs uppercase tracking-wider text-neutral-500 data-[state=active]:text-[hsl(var(--color-execution))]"
                                        >
                                            Reaper Forge
                                        </TabsTrigger>
                                    </TabsList>
                                </div>
                                
                                <TabsContent value="wargame" className="flex-1 min-h-0 m-0 p-0 overflow-hidden">
                                    <WargameSimulation 
                                        localConnected={localStatus === 'connected'} 
                                        onSave={handleSaveConsensus}
                                    />
                                </TabsContent>
                                
                                <TabsContent value="backups" className="flex-1 min-h-0 m-0 p-0 overflow-hidden">
                                    <CloudBackupManager />
                                </TabsContent>

                                <TabsContent value="forge" className="flex-1 min-h-0 m-0 p-0 overflow-hidden">
                                    <ReaperIDE />
                                </TabsContent>
                            </Tabs>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />

            <TutorialOverlay 
                tutorialId="reaper_space_intro"
                steps={[
                    { title: "Reaper Space", content: "This is your connection to the distributed compute grid.", position: "top-left" },
                    { title: "Local Bridge", content: "Connect your local machine's GPU to the network for private inference.", position: "top-left" },
                    { title: "Wargame Sim", content: "Run simulations to test system resilience and agent strategies.", position: "center" },
                    { title: "Backups", content: "Manage encrypted snapshots of your entire system state.", position: "top-right" }
                ]}
            />
        </div>
    );
}