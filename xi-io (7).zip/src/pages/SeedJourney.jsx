import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, User, Zap, CreditCard, ArrowRight, Play, Layout, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

export default function SeedJourney() {
    const handleAction = (action) => {
        toast.info(`Simulating: ${action}`);
    };

    return (
        <div className="min-h-screen bg-black text-white p-8 font-sans">
            <div className="max-w-4xl mx-auto space-y-8">
                <div className="border-b border-white/10 pb-6 flex justify-between items-end">
                    <div>
                        <Badge variant="outline" className="mb-2 border-purple-500 text-purple-400">SEED001 PROTOCOL</Badge>
                        <h1 className="text-3xl font-bold">The First User Journey</h1>
                        <p className="text-neutral-400 mt-2">
                            "I AM SEED001. MY EXPERIENCE IS THE PRODUCT." <br/>
                            <span className="text-purple-400">Execute Phase Bravo. Prove the Core Loop works.</span>
                        </p>
                    </div>
                    <Button variant="outline" onClick={() => window.location.href='/GoLive'}>
                        Back to Launch Plan
                    </Button>
                </div>

                <div className="grid gap-8">
                    
                    {/* Phase Alpha: Check */}
                    <section className="space-y-4 opacity-80 hover:opacity-100 transition-opacity">
                        <div className="flex items-center gap-3">
                             <div className="w-6 h-6 rounded-full border border-neutral-600 text-neutral-500 flex items-center justify-center font-bold text-xs">A</div>
                             <h2 className="text-sm font-semibold text-neutral-400 uppercase tracking-widest">Phase Alpha: Connectivity (Prerequisite)</h2>
                        </div>
                         <Card className="bg-neutral-900/30 border-white/5 ml-9">
                            <CardContent className="pt-4 flex items-center justify-between">
                                <span className="text-sm text-neutral-400">Deployed & API Connected?</span>
                                <Badge variant="outline" className="text-neutral-500">Check GoLive Page</Badge>
                            </CardContent>
                        </Card>
                    </section>

                    {/* Phase Bravo: The Core Loop */}
                    <div className="relative">
                        <div className="absolute -left-4 top-0 bottom-0 w-1 bg-gradient-to-b from-purple-500 to-transparent opacity-50"></div>
                        
                        <div className="mb-6 ml-4">
                            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                                <span className="text-purple-500">PHASE BRAVO:</span> THE USER
                            </h2>
                            <p className="text-neutral-400 text-sm">15 Minutes • Critical Path Validation</p>
                        </div>

                        {/* Step 1: Arrive */}
                        <section className="space-y-4 ml-4 mb-8">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold">1</div>
                                <h2 className="text-xl font-semibold">Arrive & Acquire</h2>
                            </div>
                            <Card className="bg-neutral-900/50 border-white/10 ml-11">
                                <CardContent className="pt-6 grid md:grid-cols-2 gap-6">
                                    <div>
                                        <h3 className="font-bold text-white mb-2">Actions</h3>
                                        <ul className="space-y-2 text-sm text-neutral-400">
                                            <li>1. Open public URL (Incognito).</li>
                                            <li>2. Does it load?</li>
                                            <li>3. Enter email in "Waitlist".</li>
                                            <li>4. Create Account / Login.</li>
                                        </ul>
                                    </div>
                                    <div className="bg-black/40 p-4 rounded border border-white/5 text-sm">
                                        <h3 className="font-bold text-blue-400 mb-2">Success State</h3>
                                        <div className="space-y-2">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-neutral-600" />
                                                <span>Fast Load</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-neutral-600" />
                                                <span>Lead Captured</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-neutral-600" />
                                                <span>Logged In</span>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </section>

                        {/* Step 2: Nervous System */}
                        <section className="space-y-4 ml-4 mb-8">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">2</div>
                                <h2 className="text-xl font-semibold">Connect Nervous System</h2>
                            </div>
                            <Card className="bg-neutral-900/50 border-white/10 ml-11">
                                <CardContent className="pt-6 grid md:grid-cols-2 gap-6">
                                    <div>
                                        <h3 className="font-bold text-white mb-2">Actions</h3>
                                        <ul className="space-y-2 text-sm text-neutral-400">
                                            <li>1. Go to <strong>/Integrations</strong>.</li>
                                            <li>2. Connect Slack (Your Workspace).</li>
                                            <li>3. Click <strong>"Test Connection"</strong>.</li>
                                        </ul>
                                        <Button size="sm" className="mt-4 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20" onClick={() => window.location.href='/Integrations'}>
                                            Go to Integrations <ArrowRight className="w-3 h-3 ml-2"/>
                                        </Button>
                                    </div>
                                    <div className="bg-black/40 p-4 rounded border border-white/5 text-sm">
                                        <h3 className="font-bold text-emerald-400 mb-2">Success State</h3>
                                        <div className="space-y-2">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-neutral-600" />
                                                <span>Auth Flow Completes</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-neutral-600" />
                                                <span>"Connection Verified" Toast</span>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </section>

                        {/* Step 3: Payment Circuit */}
                        <section className="space-y-4 ml-4">
                            <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">3</div>
                                <h2 className="text-xl font-semibold">Test Payment Circuit</h2>
                            </div>
                            <Card className="bg-neutral-900/50 border-white/10 ml-11">
                                <CardContent className="pt-6 grid md:grid-cols-2 gap-6">
                                    <div>
                                        <h3 className="font-bold text-white mb-2">Actions</h3>
                                        <ul className="space-y-2 text-sm text-neutral-400">
                                            <li>1. Go to <strong>/Commerce</strong>.</li>
                                            <li>2. Attempt Subscribe (Concierge).</li>
                                            <li>3. Expect graceful failure.</li>
                                        </ul>
                                        <Button size="sm" className="mt-4 bg-orange-500/10 text-orange-400 hover:bg-orange-500/20" onClick={() => window.location.href='/Commerce'}>
                                            Go to Commerce <ArrowRight className="w-3 h-3 ml-2"/>
                                        </Button>
                                    </div>
                                    <div className="bg-black/40 p-4 rounded border border-white/5 text-sm">
                                        <h3 className="font-bold text-orange-400 mb-2">Success State</h3>
                                        <div className="space-y-2">
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-neutral-600" />
                                                <span>No Crash</span>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <CheckCircle2 className="w-4 h-4 text-neutral-600" />
                                                <span>"Not Configured" Message</span>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </section>
                    </div>

                    {/* Phase Charlie: Validation */}
                    <div className="mt-8 border-t border-white/10 pt-8">
                         <div className="flex items-center gap-3 mb-6">
                             <div className="w-6 h-6 rounded-full border border-neutral-600 text-neutral-500 flex items-center justify-center font-bold text-xs">C</div>
                             <h2 className="text-sm font-semibold text-neutral-400 uppercase tracking-widest">Phase Charlie: First Contact</h2>
                        </div>
                        
                        <div className="bg-gradient-to-br from-neutral-900 to-black p-8 rounded-xl border border-white/10 text-center space-y-4">
                            <h3 className="text-2xl font-bold text-white">Did Phase Bravo Pass?</h3>
                            <p className="text-neutral-400 max-w-lg mx-auto">
                                If you fixed all blockers and the experience was smooth for you, you are ready to send the email.
                            </p>
                            <div className="flex justify-center gap-4 pt-4">
                                <Button variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10" onClick={() => toast("Fix blockers first.")}>
                                    No, I found issues
                                </Button>
                                <Button 
                                    className="bg-white text-black hover:bg-neutral-200 font-bold px-8"
                                    onClick={() => window.location.href='/GoLive'}
                                >
                                    <CheckCircle2 className="w-4 h-4 mr-2" />
                                    Yes, I am Ready to Share
                                </Button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}