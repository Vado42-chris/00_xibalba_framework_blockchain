import React from 'react';
import AnalyticsDashboard from '@/components/analytics/AnalyticsDashboard';
import { OrientingText, IntentText } from '@/components/ui/design-system/System';

export default function Analytics() {
    return (
        <div className="min-h-screen bg-black p-6 md:p-12">
            <div className="max-w-7xl mx-auto space-y-8">
                 <div className="flex flex-col gap-2">
                    <OrientingText className="text-[hsl(var(--color-execution))]">OBSERVABILITY</OrientingText>
                    <IntentText className="text-4xl md:text-5xl font-light text-white">
                        System Metrics
                    </IntentText>
                </div>
                <AnalyticsDashboard />
            </div>
        </div>
    );
}