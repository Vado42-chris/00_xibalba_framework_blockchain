import React, { useState } from 'react';
import { 
    Terminal, Shield, Cpu, Lock, 
    Wifi, Download, ArrowRight, CheckCircle2,
    AlertTriangle, Laptop, Command
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { InstallerTerminal } from '@/components/installer/InstallerTerminal';
import SiteDeployer from '@/components/installer/SiteDeployer';
import { InstallerService } from '@/components/installer/InstallerService';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/System';
import { toast } from 'sonner';

export default function InstallerPage() {
    const [pairingCode, setPairingCode] = useState('');
    const [isPairing, setIsPairing] = useState(false);

    const handlePair = async (e) => {
        e.preventDefault();
        if (pairingCode.length < 6) return;
        
        setIsPairing(true);
        try {
            const result = await InstallerService.verifyDevice(pairingCode);
            setPairingCode('');
            toast.success("Device Linked Successfully", {
                description: `Node '${result.device.name}' (${result.device.ip}) is now active in the grid.`
            });
        } catch (error) {
            toast.error(error.message);
        } finally {
            setIsPairing(false);
        }
    };

    return (
        <div className="min-h-screen p-6 md:p-12 max-w-7xl mx-auto space-y-12 bg-transparent">
            
            {/* Header Section */}
            <div className="space-y-6 text-center max-w-3xl mx-auto">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900 border border-white/10 text-xs font-mono text-neutral-400">
                    <span className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))]" />
                    SYSTEM UPLINK v2.4.1
                </div>
                
                <h1 className="text-5xl md:text-6xl font-serif font-medium tracking-tight text-white">
                    Secure the <span className="text-[hsl(var(--color-intent))]">Kernel</span>.
                    <br />
                    Own the Grid.
                </h1>
                
                <p className="text-lg text-neutral-400 leading-relaxed max-w-2xl mx-auto">
                    Install the Xibalba Client for local device telemetry, or deploy a full site bundle directly to the grid.
                </p>
            </div>

            <Tabs defaultValue="device" className="w-full">
                <div className="flex justify-center mb-12">
                    <TabsList className="bg-neutral-900 border border-white/10 p-1">
                        <TabsTrigger value="device" className="px-6">Device Uplink</TabsTrigger>
                        <TabsTrigger value="deploy" className="px-6">Site Deployer</TabsTrigger>
                    </TabsList>
                </div>

                <TabsContent value="deploy" className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <SiteDeployer />
                </TabsContent>

                <TabsContent value="device" className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    {/* Main Interactive Installer */}
                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        
                        {/* Left: The Terminal Simulation */}
                        <div className="order-2 lg:order-1 relative">
                    <div className="absolute -inset-1 bg-gradient-to-r from-[hsl(var(--color-intent))] to-[hsl(var(--color-execution))] rounded-xl blur opacity-20" />
                    <InstallerTerminal />
                    
                    {/* Copy Command Box */}
                    <div className="mt-6 p-4 bg-neutral-900/50 border border-white/10 rounded-lg flex items-center justify-between gap-4 group cursor-pointer hover:border-[hsl(var(--color-intent))]/50 transition-colors"
                        onClick={() => {
                            navigator.clipboard.writeText("curl -sL https://install.xibalba.io | sudo bash");
                            toast.success("Install command copied to clipboard");
                        }}
                    >
                        <code className="font-mono text-sm text-[hsl(var(--color-intent))]">
                            curl -sL https://install.xibalba.io | sudo bash
                        </code>
                        <Button size="sm" variant="ghost" className="text-xs">
                            COPY
                        </Button>
                    </div>
                </div>

                {/* Right: The Logic & Pairing */}
                <div className="order-1 lg:order-2 space-y-8">
                    
                    {/* The Linux Incentive */}
                    <Layer level="intent" className="space-y-4">
                        <div className="flex items-center gap-3 mb-2">
                            <Laptop className="w-5 h-5 text-neutral-400" />
                            <OrientingText className="font-bold">BUILD YOUR OWN OS</OrientingText>
                        </div>
                        <p className="text-sm text-neutral-400 leading-relaxed">
                            This headless kernel is your canvas. We provide the core neural sync engine; you provide the flavor. Build your own custom Linux distribution on top of Xibalba.
                        </p>
                        <div className="p-3 bg-neutral-900/50 rounded border border-white/5 space-y-2">
                            <div className="text-xs font-bold text-[hsl(var(--color-intent))]">OPPORTUNITY:</div>
                            <p className="text-xs text-neutral-400">
                                Once verified, you can hook your custom distro up to our Marketplace and <span className="text-white">sell your unique Linux OS</span> to the grid.
                            </p>
                        </div>
                        <ul className="space-y-2 pt-2 border-t border-white/5">
                            <li className="flex items-start gap-2 text-xs text-neutral-300">
                                <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-execution))] shrink-0" />
                                <span>Zero-latency kernel pipe (eBPF based telemetry)</span>
                            </li>
                            <li className="flex items-start gap-2 text-xs text-neutral-300">
                                <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-execution))] shrink-0" />
                                <span>Hardware-enforced encryption keys (TPM 2.0)</span>
                            </li>
                        </ul>
                    </Layer>

                    {/* Device Verification Form */}
                    <Layer level="state" className="border-[hsl(var(--color-execution))]/20">
                        <div className="flex items-center gap-3 mb-4">
                            <Lock className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                            <OrientingText className="font-bold text-[hsl(var(--color-execution))]">DEVICE VERIFICATION</OrientingText>
                        </div>
                        <p className="text-xs text-neutral-500 mb-4">
                            Enter the 8-character pairing code generated by your terminal installer to authorize the secure tunnel.
                        </p>
                        
                        <form onSubmit={handlePair} className="flex gap-2">
                            <Input 
                                value={pairingCode}
                                onChange={(e) => setPairingCode(e.target.value.toUpperCase())}
                                placeholder="XL-XXXX-XX"
                                className="font-mono tracking-widest uppercase text-center text-lg h-12 bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-execution))]"
                                maxLength={10}
                            />
                            <Button 
                                type="submit" 
                                disabled={isPairing || pairingCode.length < 6}
                                className={cn(
                                    "h-12 px-6 font-bold tracking-wide transition-all",
                                    isPairing ? "bg-neutral-800" : "bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                                )}
                            >
                                {isPairing ? "LINKING..." : "AUTHORIZE"}
                            </Button>
                        </form>
                    </Layer>

                </div>
            </div>
                </TabsContent>
            </Tabs>

            {/* Technical Specs Footer */}
            <div className="grid md:grid-cols-3 gap-6 pt-12 border-t border-white/5 opacity-60 hover:opacity-100 transition-opacity">
                <div className="space-y-2">
                    <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-widest flex items-center gap-2">
                        <Shield className="w-3 h-3" /> Encryption
                    </h4>
                    <p className="text-[10px] text-neutral-500 leading-relaxed">
                        All local traffic is wrapped in a custom WireGuard tunnel with rotatable Ed25519 keys. We never see your raw data, only the neural weights.
                    </p>
                </div>
                <div className="space-y-2">
                    <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-widest flex items-center gap-2">
                        <Cpu className="w-3 h-3" /> Requirements
                    </h4>
                    <p className="text-[10px] text-neutral-500 leading-relaxed">
                        • Ubuntu 20.04+ / Debian 11+ / Arch<br/>
                        • 4GB RAM Minimum<br/>
                        • 2GB Disk Space<br/>
                        • Root privileges for daemon init
                    </p>
                </div>
                <div className="space-y-2">
                    <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-widest flex items-center gap-2">
                        <Wifi className="w-3 h-3" /> Connectivity
                    </h4>
                    <p className="text-[10px] text-neutral-500 leading-relaxed">
                        Outbound TCP 443 only. No inbound ports required. Uses WebSocket framing for traversal through corporate firewalls.
                    </p>
                </div>
            </div>

        </div>
    );
}