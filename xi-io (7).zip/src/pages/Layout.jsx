
import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/components/api/LocalClient';

import { Link, useLocation } from 'react-router-dom';
import OmniAssistant from '@/components/assistants/OmniAssistant';
import { SmartErrorBoundary as ErrorBoundary } from '@/components/ui/SmartErrorBoundary';

import { createPageUrl } from '@/utils';
import { Breadcrumbs } from '@/components/ui/Breadcrumbs';
import { BigSearchHeader } from '@/components/ui/BigSearchHeader';
import { 
  Terminal, 
  Server,
  Shield, 
  CircuitBoard,
  Cpu, 
  Activity, 
  Globe, 
  Layout as LayoutIcon, 
  Fingerprint,
  LayoutGrid,
  ShoppingBag,
  Target,
  Wallet,
  MessageSquare,
  Truck,
  LayoutTemplate,
  BarChart3,
  Palette,
  Coffee,
  Search,
  User,
  Plug,
  Ghost,
  HardDrive,
  Settings as SettingsIcon,
  Users,
  Download,
  Building2,
  Disc,
  ChevronRight,
  Wand2,
  Eye,
  EyeOff
  } from 'lucide-react';
import { cn } from '@/components/ui/utils';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import AuthorityChip from '@/components/ui/AuthorityChip';
import { GlobalSearch } from '@/components/ui/GlobalSearch';
import { NotificationCenter } from '@/components/notifications/NotificationCenter';
import { useAuthority } from '@/components/useAuthority';
import { applyTheme } from '@/components/identity/themeUtils';
import { SiteContextProvider, useSiteContext } from '@/components/identity/SiteContext';
import DomainRotator from '@/components/navigation/DomainRotator';
import ToolDock from '@/components/layout/ToolDock';
import { PersonaCard } from '@/components/identity/PersonaCard';
import { GamificationProvider, XPBar } from '@/components/features/GamificationSystem';
import { BookmarkProvider } from '@/components/features/BookmarkSystem';
import DepthBackground from '@/components/ui/design-system/DepthBackground';
import { PrivacyModeDropdown } from '@/components/ui/PrivacyModeDropdown';
import DeploymentModal from '@/components/reaper/DeploymentModal';
import { CollaborativeCursors } from '@/components/collaboration/CollaborativeCursors';
import { LanguageProvider, useLanguage } from '@/components/identity/LanguageContext';
import { OnboardingProvider, useOnboarding } from '@/components/onboarding/OnboardingContext';
import { TutorialOverlay } from '@/components/onboarding/InteractiveTutorial';
import { ContextualTips } from '@/components/onboarding/ContextualTips';
import { UserOnboarding } from '@/components/onboarding/UserOnboarding';
import GitHistoryModal from '@/components/tools/GitHistoryModal';
import { WindowManagerProvider } from '@/components/studio/managers/WindowManager';

import { Toaster, toast } from 'sonner';
import { GlobalProgress } from '@/components/ui/GlobalProgress';
import DesktopEnvironment from '@/components/desktop/DesktopEnvironment';
import FeedbackWidget from '@/components/feedback/FeedbackWidget';
import OnboardingAssistant from '@/components/onboarding/OnboardingAssistant';
import { GridProvider } from '@/components/desktop/DesktopGridSystem';

export default function Layout({ children }) {
  return (
    <ErrorBoundary>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@100..900&family=JetBrains+Mono:wght@100..800&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&display=swap');
          
          /* Custom Scrollbar */
          ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
            background-color: transparent;
          }

          ::-webkit-scrollbar-track {
            background-color: transparent;
          }

          ::-webkit-scrollbar-thumb {
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 99px;
          }

          ::-webkit-scrollbar-thumb:hover {
            background-color: rgba(255, 255, 255, 0.2);
          }

          /* Firefox */
          * {
            scrollbar-width: thin;
            scrollbar-color: rgba(255, 255, 255, 0.1) transparent;
          }

          /* Custom Scrollbar */
          ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
            background-color: transparent;
          }

          ::-webkit-scrollbar-track {
            background-color: transparent;
          }

          ::-webkit-scrollbar-thumb {
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 99px;
          }

          ::-webkit-scrollbar-thumb:hover {
            background-color: rgba(255, 255, 255, 0.2);
          }

          /* Firefox */
          * {
            scrollbar-width: thin;
            scrollbar-color: rgba(255, 255, 255, 0.1) transparent;
          }

          :root {
            --background: 0 0% 0%;
            --foreground: 0 0% 98%;
            --card: 0 0% 3%;
            --card-foreground: 0 0% 98%;
            --popover: 0 0% 3%;
            --popover-foreground: 0 0% 98%;
            --primary: 0 0% 98%;
            --primary-foreground: 0 0% 9%;
            --secondary: 0 0% 14.9%;
            --secondary-foreground: 0 0% 98%;
            --muted: 0 0% 14.9%;
            --muted-foreground: 0 0% 63.9%;
            --accent: 0 0% 14.9%;
            --accent-foreground: 0 0% 98%;
            --destructive: 0 62.8% 30.6%;
            --destructive-foreground: 0 0% 98%;
            --border: 0 0% 14.9%;
            --input: 0 0% 14.9%;
            --ring: 0 0% 83.1%;
            --radius: 0.375rem; /* 6px Median */
            --radius-sm: 0.125rem; /* 2px Small */
            --radius-lg: 0.75rem; /* 12px Large */

            /* XI-SYSTEM VARIABLES (BRAND LOCKED) */
            --void: 0 0% 5%;
            --layer-orientation: 210 50% 45% / 0.1;
            --layer-intent: 224.3 76.3% 48% / 0.1;
            --layer-state: 210 20% 98% / 0.1;
            
            --fg-orientation: 210 50% 45%;
            --fg-intent: 224.3 76.3% 48%;
            
            --color-orientation: 210 50% 45%;
            --color-intent: 224.3 76.3% 48%;
            --color-execution: 142 71% 45%;
            --color-active: 280 65% 60%;
            --color-warning: 30 80% 55%;
            --color-error: 0 80% 60%;
            --color-settled: 210 20% 98%;
            --color-review: 50 90% 60%;
            --color-system: 0 0% 50%;
          }
        `}</style>
        <LanguageProvider>
            <SiteContextProvider>
                <GamificationProvider>
                    <BookmarkProvider>
                        <OnboardingProvider>
                            <GridProvider>
                                <WindowManagerProvider>
                                    <LayoutContent>{children}</LayoutContent>
                                    <GlobalProgress />
                                    <UserOnboarding />
                                    <TutorialOverlay />
                                    <FeedbackWidget />
                                    <OnboardingAssistant />

                                    <Toaster />
                                </WindowManagerProvider>
                            </GridProvider>
                        </OnboardingProvider>
                    </BookmarkProvider>
                </GamificationProvider>
            </SiteContextProvider>
        </LanguageProvider>
    </ErrorBoundary>
  );
}

const LanguageToggle = () => {
    const { mode, toggleMode } = useLanguage();
    return (
        <button 
            onClick={toggleMode}
            className={cn(
                "flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all text-[10px] font-medium tracking-wide uppercase",
                mode === 'human' 
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/20" 
                    : "bg-neutral-900 border-white/10 text-neutral-500 hover:text-white"
            )}
            title="Toggle Interface Language"
        >
            {mode === 'human' ? <MessageSquare className="w-3 h-3" /> : <Terminal className="w-3 h-3" />}
            {mode === 'human' ? 'Plain Speak' : 'System Speak'}
        </button>
    );
};

function LayoutContent({ children }) {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDeployOpen, setIsDeployOpen] = useState(false);
  const [isGitOpen, setIsGitOpen] = useState(false);
  const [openSection, setOpenSection] = useState(null); // Tracks currently open section
  const [isDesktopMode, setIsDesktopMode] = useState(false); // New Desktop Mode State
  const constraintsRef = useRef(null);
  const { role } = useAuthority();
  const { domainData, userTheme, reducedMotion, setReducedMotion } = useSiteContext(); // Access domain context
  const { startOnboarding } = useOnboarding();

  const location = useLocation();
  const currentPath = location.pathname;

  // Check for windowed mode (inside iframe)
  const isWindowed = new URLSearchParams(location.search).get('windowed') === 'true';

  // Auto-expand active section on navigation
  useEffect(() => {
    // Find the section that contains the current path
    const activeSectionIndex = navSections.findIndex(section => 
        section.items.some(item => 
            currentPath.startsWith(`/${item.path}`) || (currentPath === '/' && item.path === 'Console')
        )
    );
    
    if (activeSectionIndex !== -1) {
        setOpenSection(activeSectionIndex);
    }
  }, [currentPath]); // Re-run when path changes
  
  // App Mode Detection (Hides Footer/Breadcrumbs for "App-like" pages)
  const isAppMode = ['/Console', '/WorkRoom', '/Studio', '/DistroBuilder', '/ContentManager', '/SearchResults', '/Marketplace', '/CRM', '/Intelligence', '/Communications', '/Commerce', '/Finance', '/Archives', '/Legal', '/BusinessPlan', '/Enterprise', '/Automation', '/Integrations', '/IntegrationDashboard', '/Agents', '/Community', '/Network', '/Nodes', '/Lifestyle', '/ReaperSpace', '/Identity', '/Settings', '/Audit', '/ServerControl', '/Installer', '/Docs', '/PromptForge'].includes(currentPath);

  // Landing Page & Public Pages Bypass
  const publicPages = ['/SovereignCloud', '/Manifesto', '/NetworkLanding', '/EnterpriseLanding', '/'];
  
  // Public Access Guard
  // If not logged in and not on a public page, show Landing Hero (redirect to home technically, but we handle it here)
  if (!role && !publicPages.includes(currentPath)) {
      // In a real app we might redirect, but here we'll just show the children if it's the home page 
      // (which renders GatewayLanding anyway), or redirect if it's a deep link.
      // For now, let's just let Home page handle its own auth check, but block others.
      // Actually, let's redirect to root if trying to access deep links while guest
      if (currentPath !== '/') {
          window.location.href = '/'; // Simple redirect for security
          return null;
      }
  }

  if (publicPages.includes(currentPath) && currentPath !== '/') {
      return children;
  }

  // Navigation Categories
  const navSections = [
    {
      title: "Empire",
      items: [
        { name: 'Gateway', icon: Globe, path: 'Home', theme: 'indigo-500' },
        { name: 'Web Search', icon: Search, path: 'SearchResults', theme: 'blue-400' },
        { name: 'Overview', icon: LayoutGrid, path: 'Dashboard', theme: 'sky-500' },
        { name: 'Analytics', icon: Activity, path: 'Analytics', theme: 'emerald-500' },
        { name: 'Intelligence', icon: BarChart3, path: 'Intelligence', theme: 'violet-500' },
        { name: 'CRM', icon: User, path: 'CRM', theme: 'blue-500' },
        { name: 'Comms', icon: MessageSquare, path: 'Communications', theme: 'yellow-500' },
        { name: 'Commerce', icon: Truck, path: 'Commerce', theme: 'orange-500' },
        { name: 'Finance', icon: Wallet, path: 'Finance', theme: 'emerald-500' },
        { name: 'Archives', icon: HardDrive, path: 'Archives', theme: 'emerald-700' },
        { name: 'SAM Law', icon: Shield, path: 'Legal', theme: 'slate-500' },
      ]
    },
    {
      title: "Strategy",
      items: [
        { name: 'Business Plan', icon: Target, path: 'BusinessPlan', theme: 'indigo-500' },
        { name: 'Enterprise', icon: Building2, path: 'Enterprise', theme: 'blue-600' },
        { name: 'Automation', icon: CircuitBoard, path: 'Automation', theme: 'cyan-500' },
        { name: 'Integrations', icon: Plug, path: 'Integrations', theme: 'fuchsia-500' },
        { name: 'Int. Dashboard', icon: Activity, path: 'IntegrationDashboard', theme: 'purple-500' },
        { name: 'Marketplace', icon: ShoppingBag, path: 'Marketplace', theme: 'rose-500' },
      ]
    },
    {
      title: "Operations",
      items: [
        { name: 'Work Room', icon: LayoutIcon, path: 'WorkRoom', theme: 'stone-500' },
        { name: 'Distro Builder', icon: Disc, path: 'DistroBuilder', theme: 'rose-500' },
        { name: 'Studio', icon: Palette, path: 'Studio', theme: 'pink-500' },
        { name: 'Site Builder', icon: LayoutTemplate, path: 'ContentManager', theme: 'teal-500' },
        { name: 'Component Forge', icon: Wand2, path: 'ComponentForge', theme: 'amber-500' },
        { name: 'Agents', icon: Cpu, path: 'Agents', theme: 'violet-400' },
        { name: 'Community', icon: Users, path: 'Community', theme: 'orange-400' },
        { name: 'Network', icon: Globe, path: 'Network', theme: 'indigo-400' },
        { name: 'Nodes', icon: Activity, path: 'Nodes', theme: 'blue-400' },
      ]
    },
    {
      title: "Life OS",
      items: [
         { name: 'Lifestyle', icon: Coffee, path: 'Lifestyle', theme: 'lime-500' },
      ]
    },
    {
      title: "Control",
      items: [
        { name: 'Console', icon: Terminal, path: 'Console', theme: 'neutral-600' },
        { name: 'Reaper Space', icon: Ghost, path: 'ReaperSpace', theme: 'purple-600' },
        { name: 'Identity', icon: Fingerprint, path: 'Identity', theme: 'zinc-600' },
        { name: 'System Config', icon: SettingsIcon, path: 'Settings', theme: 'slate-400' },
        { name: 'System Audit', icon: Shield, path: 'Audit', theme: 'red-500' },
        { name: 'Server Control', icon: Server, path: 'ServerControl', theme: 'emerald-400' },
        { name: 'Uplink Installer', icon: Download, path: 'Installer', theme: 'cyan-400' },
        { name: 'Manual', icon: LayoutTemplate, path: 'Docs', theme: 'stone-400' },
      ]
    }
  ];

  // Resolve Active Item for Header
  const activeItem = navSections.flatMap(s => s.items).find(item => 
    currentPath === `/${item.path}` || (currentPath === '/' && item.path === 'Console')
  ) || { name: 'System', icon: Shield, theme: 'neutral-800' };
  
  const ActiveIcon = activeItem.icon;

  return (
    <div ref={constraintsRef} className="dark h-screen max-h-screen bg-black text-neutral-200 font-sans selection:bg-[hsl(var(--color-intent))]/30 flex relative overflow-hidden">
      
      {/* GLOBAL BACKGROUND - The Time Tunnel */}
      <div className="absolute inset-0 z-0">
          <DepthBackground theme={activeItem.theme} settings={userTheme} />
      </div>

      {/* Sidebar Navigation - LAYER 1: ORIENTATION (Bottom) */}
      {!isDesktopMode && !isWindowed && (
      <nav className="w-16 lg:w-64 border-r border-white/5 bg-black/20 backdrop-blur-xl flex flex-col shrink-0 transition-all duration-300 z-30 shadow-[5px_0_30px_-10px_rgba(0,0,0,0.5)]">
        <div className="h-16 flex items-center justify-center lg:justify-start lg:px-6 border-b border-white/5">
          <div className={cn("w-8 h-8 rounded flex items-center justify-center shadow-lg transition-colors duration-300 shrink-0", `bg-${activeItem.theme}`)}>
            <ActiveIcon className="w-4 h-4 text-white" />
          </div>
          <span className="hidden lg:block ml-4 font-medium text-white tracking-wide text-xs">XI-CONTROL</span>
        </div>

        <div className="p-[12px] space-y-6 overflow-y-auto flex-1">
          {navSections.map((section, idx) => {
            return (
                <Collapsible 
                    key={idx} 
                    open={openSection === idx} 
                    onOpenChange={(isOpen) => setOpenSection(isOpen ? idx : null)}
                    className="space-y-1"
                >
                    <CollapsibleTrigger className="px-3 mb-2 hidden lg:flex items-center justify-between w-full text-[9px] font-medium text-[hsl(var(--fg-orientation))] opacity-60 uppercase tracking-widest hover:opacity-100 transition-opacity group/trigger cursor-pointer">
                        {section.title}
                        <ChevronRight className="w-3 h-3 transition-transform duration-200 group-data-[state=open]/trigger:rotate-90" />
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-1 data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down overflow-hidden">
                        {section.items.map((item) => {
                            // Role-based Navigation Filtering
                            if (role !== 'ROOT_ADMIN' && (item.name === 'Console' || item.name === 'Identity' || item.name === 'Audit' || item.name === 'Reaper Space')) {
                                return null; // Hide Control Plane from non-admins
                            }

                            const isActive = currentPath === `/${item.path}` || (currentPath === '/' && item.path === 'Console');

                            return (
                            <Link
                                key={item.path}
                                to={createPageUrl(item.path)}
                                className={cn(
                                "flex items-center gap-[12px] px-3 py-2 rounded-sm transition-all group",
                                isActive 
                                    ? "bg-neutral-800 text-white border border-white/5" 
                                    : "text-neutral-500 hover:text-white hover:bg-neutral-800/50"
                                )}
                                title={item.name}
                            >
                                <item.icon className={cn("w-4 h-4 transition-colors", `text-${item.theme}`)} />
                                <span className="hidden lg:block text-xs font-normal tracking-wide">{item.name}</span>
                                {isActive && (
                                <div className={cn("ml-auto w-1.5 h-1.5 rounded-full shadow-[0_0_8px_currentColor] hidden lg:block", `bg-${item.theme} text-${item.theme}`)} />
                                )}
                            </Link>
                            );
                        })}
                    </CollapsibleContent>
                </Collapsible>
            );
          })}
        </div>

        <div className="mt-auto border-t border-white/5 bg-black/20">
           <XPBar />
           <DomainRotator />
           <div className="p-[15px] pt-2">
              <div className="hidden lg:block">
                  <PersonaCard className="!p-2 !bg-transparent !border-none !shadow-none" />
              </div>
              <div className="lg:hidden">
                  <Link to={createPageUrl('UserProfile')} className="flex items-center justify-center w-8 h-8 rounded-full bg-white/5 border border-white/10 text-xs font-bold text-neutral-400">
                      XI
                  </Link>
              </div>
           </div>
        </div>
      </nav>
      )}

      {/* Main Content Area - LAYER 0: FIELD */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden bg-transparent relative z-10">
        
        {/* Contextual Tips Overlay - Repositioned inside Main */}
        <div className="absolute bottom-4 right-4 z-50 pointer-events-none max-w-sm w-full">
            <div className="pointer-events-auto">
                <ContextualTips />
            </div>
        </div>

        {/* Top Header - LAYER 1: ORIENTATION (Top Edge) */}
        {!isWindowed && (
        <header className="h-14 border-b border-white/5 bg-black/20 backdrop-blur-md flex items-center px-6 justify-between shrink-0 relative z-20 shadow-sm">


           <div className="flex items-center gap-4 h-full">
              {/* Privacy Control */}
              <div className="hidden md:block">
                  <PrivacyModeDropdown />
              </div>
              
              {/* Desktop Mode Toggle */}
              <button
                  onClick={() => setIsDesktopMode(!isDesktopMode)}
                  className={cn(
                      "flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all text-[10px] font-medium tracking-wide uppercase",
                      isDesktopMode 
                          ? "bg-[hsl(var(--color-intent))]/10 border-[hsl(var(--color-intent))]/30 text-[hsl(var(--color-intent))]" 
                          : "bg-neutral-900 border-white/10 text-neutral-500 hover:text-white"
                  )}
                  title="Toggle Desktop Environment"
              >
                  <LayoutTemplate className="w-3 h-3" />
                  {isDesktopMode ? 'Desktop Active' : 'Desktop Mode'}
              </button>

              {/* Reduced Motion Toggle */}
              <button
                  onClick={() => setReducedMotion(!reducedMotion)}
                  className={cn(
                      "flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all text-[10px] font-medium tracking-wide uppercase",
                      reducedMotion
                          ? "bg-rose-500/10 border-rose-500/30 text-rose-500" 
                          : "bg-neutral-900 border-white/10 text-neutral-500 hover:text-white"
                  )}
                  title="Toggle Animation (Epilepsy Safe Mode)"
              >
                  {reducedMotion ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  {reducedMotion ? 'Motion Off' : 'Motion On'}
              </button>

              {/* Language Toggle */}
              <LanguageToggle />

              {/* Gateway (Home) */}
              <Link to={createPageUrl('Home')} className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" title="Gateway">
                 <Globe className="w-4 h-4" />
              </Link>
              
              {/* Web Search */}
              <Link to={createPageUrl('SearchResults')} className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" title="Web Search">
                 <Search className="w-4 h-4" />
              </Link>
              {/* System Status Ticker */}
              <div className="hidden xl:flex items-center gap-[15px] text-[10px] font-mono text-neutral-500">
                <span>MEM: 44%</span>
                <span>CPU: 12%</span>
                <span>NET: SECURE</span>
              </div>

              <div className="h-4 w-px bg-white/5" />

              <div className="flex items-center gap-2 px-2 py-1 rounded bg-[hsl(var(--color-active))]/5 border border-[hsl(var(--color-active))]/10 hover:bg-[hsl(var(--color-active))]/10 transition-colors cursor-help" title="System Connected">
                 <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-active))] animate-[pulse_3s_infinite]" />
                 <span className="text-[10px] text-[hsl(var(--color-active))] font-mono tracking-wider font-bold">v3.0.0-RC1 (SEED)</span>
              </div>
              
              <div className="h-4 w-px bg-white/5" />

              {/* Project Management / Publish Toolbar */}
              <div className="flex items-center gap-2">
                 {/* Search moved to main content area */}

                 <NotificationCenter /> {/* Notification Center Integration */}

                 {role ? (
                    <Link to={createPageUrl('UserProfile')} className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" title="User Profile">
                        <User className="w-4 h-4" />
                    </Link>
                 ) : (
                    <button 
                        onClick={() => base44.auth.redirectToLogin()}
                        className="px-3 py-1.5 bg-[hsl(var(--color-intent))] text-black text-[10px] font-bold uppercase tracking-wider rounded hover:bg-[hsl(var(--color-intent))]/90 transition-colors shadow-[0_0_10px_-4px_hsl(var(--color-intent))]"
                    >
                        Connect
                    </button>
                 )}

                 <button 
                    onClick={() => setIsGitOpen(true)}
                    className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" 
                    title="Git History"
                 >
                    <div className="w-4 h-4"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-git-branch"><line x1="6" x2="6" y1="3" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg></div>
                 </button>
                 <button 
                    onClick={() => { navigator.clipboard.writeText(window.location.href); toast.success("Project link copied"); }} 
                    className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" 
                    title="Share Project"
                 >
                    <div className="w-4 h-4"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-share-2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg></div>
                 </button>
                 <button 
                    onClick={startOnboarding}
                    className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" 
                    title="Initialize Session"
                 >
                    <div className="w-4 h-4"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-play-circle"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg></div>
                 </button>
                 <button 
                    onClick={() => setIsDeployOpen(true)}
                    className="bg-white hover:bg-neutral-200 text-black text-xs font-bold px-3 py-1.5 rounded flex items-center gap-2 transition-colors ml-2"
                 >
                    Publish
                 </button>
              </div>

              <div className="h-4 w-px bg-white/5" />
              <AuthorityChip />
              </div>
              </header>
              )}

              <GlobalSearch open={isSearchOpen} onOpenChange={setIsSearchOpen} />

              {/* Scrollable Page Content OR Desktop Environment */}
              {isDesktopMode ? (
              <DesktopEnvironment 
                  navSections={navSections} 
                  onSearch={() => setIsSearchOpen(true)}
              />
              ) : (
              <div className={cn(
               "flex-1 p-0 relative z-10 flex flex-col min-h-0",
               isAppMode ? "overflow-hidden" : "overflow-y-auto"
              )}>
              {!isAppMode && !isWindowed && <BigSearchHeader onClick={() => setIsSearchOpen(true)} />}

              {!isAppMode && !isWindowed && <Breadcrumbs />}

              <div className={cn(
                  "w-full flex-1 animate-in fade-in duration-500 slide-in-from-bottom-2",
                  isAppMode ? "h-full" : ""
              )}>
                 {children}
              </div>

              {!isAppMode && !isWindowed && (
                  <footer className="py-6 border-t border-white/5 mt-auto text-center bg-black/20 backdrop-blur-md shrink-0">
                     <div className="text-[10px] text-neutral-500 font-mono flex flex-col gap-1 drop-shadow-sm">
                         <span>SYSTEM STATUS: SEED LOCKED • © 2025 XI-CONTROL • v3.0.0-RC1 (SEED)</span>
                         <span className="opacity-50">POWERED BY {domainData?.name?.toUpperCase() || 'XI-IO CORE'}</span>
                     </div>
                  </footer>
              )}
              </div>
              )}
              </main>

              {/* Tool Dock - Right Side */}
              {!isWindowed && <ToolDock />}

              {/* Overlays */}
              {!isWindowed && <OmniAssistant constraintsRef={constraintsRef} />}
      <CollaborativeCursors />
      <DeploymentModal open={isDeployOpen} onOpenChange={setIsDeployOpen} />
      <GitHistoryModal open={isGitOpen} onOpenChange={setIsGitOpen} />
    </div>
  );
}
