import React, { useState } from 'react';
import { 
    Users, Plus, Star, AlertCircle, History, 
    Filter, LayoutGrid, Ticket 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer, SemanticDot } from '@/components/ui/design-system/SystemDesign';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import CRMManager from '@/components/crm/CRMManager';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { IntegrationStatus, SyncButton, ConnectPrompt } from '@/components/integrations/IntegrationComponents';
import { SystemNav, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { SmartErrorBoundary } from '@/components/ui/SmartErrorBoundary';
import { AddonGate } from '@/components/integrations/AddonGate';
import PipelineWidget from '@/components/addons/official/PipelineWidget';
import PublicFeaturePage from '@/components/layout/PublicFeaturePage';

export default function CRM() {
    // 1. Check Auth State
    const { data: user, isLoading: isUserLoading } = useQuery({
        queryKey: ['me'],
        queryFn: () => base44.auth.me().catch(() => null),
        retry: false
    });

    const [selectedCategory, setSelectedCategory] = useState('all');

    const { data: customers = [] } = useQuery({
        queryKey: ['customers'],
        queryFn: () => base44.entities.Customer.list(),
        enabled: !!user, // Only fetch if logged in
        initialData: [] 
    });

    // 2. Render Public Page if not logged in
    if (!isUserLoading && !user) {
        return (
            <PublicFeaturePage 
                title="CRM"
                subtitle="The Relationship Engine"
                icon={Users}
                description="A unified command center for all your customer interactions. Track leads, manage support tickets, and visualize your entire sales pipeline in one fluid interface."
                features={[
                    "360° Customer View",
                    "Automated Lead Scoring",
                    "Support Ticket Integration",
                    "Salesforce & HubSpot Sync"
                ]}
                interactiveComponent={
                    <div className="w-full h-full bg-neutral-900 flex flex-col font-mono text-xs p-4 overflow-hidden relative">
                        <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-2">
                            <div className="flex gap-2 text-neutral-400">
                                <span>Pipeline</span>
                                <span className="text-white">/</span>
                                <span>Q4 Targets</span>
                            </div>
                            <div className="flex gap-2">
                                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                                <span className="text-[10px] text-green-500">LIVE SYNC</span>
                            </div>
                        </div>
                        <div className="flex-1 flex gap-2 overflow-hidden">
                            {['Leads', 'Negotiation', 'Closed'].map((col, i) => (
                                <div key={i} className="flex-1 bg-black/20 rounded border border-white/5 flex flex-col p-2">
                                    <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-2 flex justify-between">
                                        {col} <span className="text-neutral-700">{2 + i}</span>
                                    </div>
                                    <div className="space-y-2">
                                        {[...Array(2 + i)].map((_, j) => (
                                            <div key={j} className="bg-neutral-800 p-2 rounded border border-white/5 hover:border-[hsl(var(--color-intent))] transition-colors cursor-pointer group">
                                                <div className="h-2 w-16 bg-white/10 rounded mb-2 group-hover:bg-[hsl(var(--color-intent))]/20 transition-colors" />
                                                <div className="flex justify-between items-center">
                                                    <div className="h-1.5 w-8 bg-white/5 rounded" />
                                                    <div className="text-[9px] text-[hsl(var(--color-execution))]">$12k</div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                }
            />
        );
    }

    const { data: tickets = [] } = useQuery({
        queryKey: ['tickets'],
        queryFn: () => base44.entities.SupportTicket.filter({ status: 'open' }),
        initialData: []
    });

    const counts = {
        all: customers.length,
        active: customers.filter(c => c.status === 'active').length,
        vip: customers.filter(c => c.status === 'vip').length,
        lead: customers.filter(c => c.status === 'lead').length,
        churned: customers.filter(c => c.status === 'churned').length,
        tickets: tickets.length,
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Matrix" className="border-b">
                             {/* Use SystemDetailHeader for consistency across sections */}
                             <div className="mb-6">
                                <SystemDetailHeader 
                                    title="Relationship Mgmt" 
                                    subtitle="CLIENT MATRIX" 
                                    icon={Users}
                                    addonContext="crm"
                                    className="p-0 border-b-0 bg-transparent mb-0" 
                                />
                             </div>
                            
                            <Layer level="orientation" className="p-4 space-y-4">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2 text-neutral-400 text-xs">
                                        <History className="w-3 h-3" />
                                        <span>Sync Status</span>
                                    </div>
                                    <SyncButton category="crm" />
                                </div>
                                <div className="flex items-center justify-between text-xs">
                                    <span className="font-mono text-neutral-500">{new Date().toLocaleTimeString()}</span>
                                    <IntegrationStatus category="crm" />
                                </div>
                            </Layer>

                            <div className="mt-8">
                                <ConnectPrompt 
                                    category="crm" 
                                    title="Sync CRM Data" 
                                    description="Connect Salesforce or HubSpot." 
                                />
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Segments" className="border-t-0 rounded-t-none">
                            <div className="space-y-6">
                                <div className="space-y-1">
                                    <OrientingText className="pl-2 mb-2 text-[hsl(var(--color-execution))]">SERVICE DESK</OrientingText>
                                    <SystemNav 
                                        items={[{ id: 'tickets', label: 'Tickets', icon: Ticket, count: counts.tickets, type: 'active' }]}
                                        activeId={selectedCategory}
                                        onSelect={setSelectedCategory}
                                    />
                                </div>

                                <div className="space-y-1">
                                    <OrientingText className="pl-2 mb-2">SEGMENTS</OrientingText>
                                    <SystemNav 
                                        items={[
                                            { id: 'all', label: 'All Contacts', icon: LayoutGrid, count: counts.all, type: 'settled' },
                                            { id: 'active', label: 'Active Clients', icon: Users, count: counts.active, type: 'active' },
                                            { id: 'vip', label: 'VIP Tier', icon: Star, count: counts.vip, type: 'warning' },
                                            { id: 'lead', label: 'Leads', icon: Filter, count: counts.lead, type: 'settled' },
                                            { id: 'churned', label: 'Churned', icon: AlertCircle, count: counts.churned, type: 'settled' }
                                        ]}
                                        activeId={selectedCategory}
                                        onSelect={setSelectedCategory}
                                    />
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_auto]">
                        <Quadrant type="intent" step="2" title="Management" dominance="dominant" className="p-0 flex flex-col border-b h-full">
                             <SmartErrorBoundary>
                                <AddonGate 
                                    addonName="Pipeline Hologram" 
                                    integrationType="salesforce"
                                    title="CRM Module"
                                    icon={Users}
                                >
                                    <PipelineWidget category={selectedCategory} className="bg-transparent h-full" />
                                </AddonGate>
                             </SmartErrorBoundary>
                        </Quadrant>
                        <Quadrant type="intent" step="4" title="Activity" dominance="supporting" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">RECENT INTERACTIONS</OrientingText>
                            <div className="space-y-3">
                                {/* Mock Interactions */}
                                {[
                                    { name: 'Acme Corp', action: 'Ticket Created', time: '10m ago', status: 'warning' },
                                    { name: 'Cyberdyne', action: 'Deal Closed', time: '1h ago', status: 'active' },
                                    { name: 'Wayne Ent', action: 'Email Sent', time: '2h ago', status: 'settled' }
                                ].map((item, i) => (
                                    <div key={i} className="flex items-center justify-between p-2 rounded border border-white/5 bg-black/20">
                                        <div>
                                            <div className="text-xs font-bold text-white">{item.name}</div>
                                            <div className="text-[10px] text-neutral-500">{item.action}</div>
                                        </div>
                                        <div className="text-right">
                                             <div className="text-[9px] font-mono text-neutral-600">{item.time}</div>
                                             <SemanticDot type={item.status} className="ml-auto mt-1" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}