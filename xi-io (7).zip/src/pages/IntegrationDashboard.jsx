import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Activity, Zap, Server, Database, Globe, AlertTriangle, CheckCircle } from 'lucide-react';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, 
    SemanticDot, Layer, ChartFrame 
} from '@/components/ui/design-system/System';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { TimeGraph, ProgressLattice } from '@/components/ui/design-system/Infographics';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from "@/lib/utils";
import LogInsight from '@/components/integrations/LogInsight';
import { Workflow } from 'lucide-react';
import { PostLaunchMonitorWidget } from '@/components/dashboards/widgets/PostLaunchMonitorWidget';

export default function IntegrationDashboard() {
    const { data: connectionStatus } = useQuery({
        queryKey: ['connection_status'],
        queryFn: async () => {
            const res = await base44.functions.invoke('checkConnections');
            return res.data?.statuses || {};
        }
    });

    const { data: logs = [] } = useQuery({
        queryKey: ['real_integration_logs'],
        queryFn: () => base44.entities.IntegrationLog.list(),
        initialData: []
    });

    // Derive Traffic Data from Logs
    const trafficData = React.useMemo(() => {
        // Bucket logs by hour
        const buckets = new Array(24).fill(0);
        const now = new Date();
        
        // If no logs, show zero baseline instead of random noise for clarity
        if (logs.length === 0) {
             return Array.from({ length: 24 }, (_, i) => ({
                t: `${i}:00`,
                value: 0,
                trace: 0
            }));
        }

        logs.forEach(log => {
            const date = new Date(log.timestamp);
            if (date.getDate() === now.getDate()) {
                buckets[date.getHours()]++;
            }
        });

        return buckets.map((count, i) => ({
            t: `${i}:00`,
            value: count,
            trace: count // simplified for now
        }));
    }, [logs]);

    const { data: integrations = [] } = useQuery({
        queryKey: ['integrations'],
        queryFn: () => base44.entities.Integration.list(),
        initialData: []
    });

    const { data: workflows = [] } = useQuery({
        queryKey: ['workflows'],
        queryFn: () => base44.entities.Workflow.list(),
        initialData: []
    });

    // Use real logs, fall back to empty state (no mocks)
    const displayLogs = logs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <HumorousLoader delay={1400} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                             <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Activity className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">INTEGRATION MONITOR</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Data Stream Health</IntentText>
                                </div>
                                <div className="flex items-center gap-2">
                                     <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))] animate-pulse" />
                                     <StateText className="text-[hsl(var(--color-execution))]">SYSTEM NOMINAL</StateText>
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-2">
                                <Layer level="orientation" className="p-2 text-center">
                                    <StateText className="opacity-50 text-[10px]">Requests/m</StateText>
                                    <IntentText className="text-lg">4,291</IntentText>
                                </Layer>
                                <Layer level="orientation" className="p-2 text-center">
                                    <StateText className="opacity-50 text-[10px]">Avg Latency</StateText>
                                    <IntentText className="text-lg text-[hsl(var(--color-intent))]">84ms</IntentText>
                                </Layer>
                                <Layer level="orientation" className="p-2 text-center">
                                    <StateText className="opacity-50 text-[10px]">Error Rate</StateText>
                                    <IntentText className="text-lg text-[hsl(var(--color-execution))]">0.02%</IntentText>
                                </Layer>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none flex flex-col">
                            <div className="flex justify-between items-center mb-4 shrink-0">
                                <OrientingText>ACTIVE CONNECTORS</OrientingText>
                            </div>
                            
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6 shrink-0">
                                {['googlecalendar', 'slack', 'salesforce', 'googledrive'].map(key => {
                                    const isConnected = connectionStatus?.[key];
                                    const names = { googlecalendar: 'Calendar', slack: 'Slack', salesforce: 'Salesforce', googledrive: 'Drive' };
                                    return (
                                        <div key={key} className={cn(
                                            "p-3 rounded border flex items-center justify-between",
                                            isConnected 
                                                ? "bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))]/30" 
                                                : "bg-neutral-900 border-white/10 opacity-60"
                                        )}>
                                            <div className="flex items-center gap-2">
                                                <div className={cn("w-2 h-2 rounded-full", isConnected ? "bg-[hsl(var(--color-execution))]" : "bg-neutral-600")} />
                                                <span className="text-xs font-medium">{names[key]}</span>
                                            </div>
                                            {isConnected ? (
                                                <CheckCircle className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                                            ) : (
                                                <span className="text-[9px] uppercase tracking-wider opacity-50">Offline</span>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>

                            <div className="flex justify-between items-center mb-4 shrink-0 border-t border-white/5 pt-4">
                                <OrientingText>LIVE EVENT STREAM</OrientingText>
                                <LogInsight logs={displayLogs} />
                            </div>
                            <div className="space-y-2 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/5 flex-1 min-h-0">
                                {displayLogs.map((log, i) => (
                                    <div key={i} className="p-2 border-l-2 bg-neutral-900/30 flex justify-between items-start" style={{ borderLeftColor: log.status === 'error' ? 'var(--color-error)' : 'var(--color-active)' }}>
                                        <div>
                                            <div className="flex items-center gap-2 mb-1">
                                                <Badge variant="outline" className="text-[9px] h-4 px-1 border-white/10 text-neutral-400">{log.service}</Badge>
                                                <StateText className="text-[10px] font-mono opacity-50">{new Date(log.timestamp).toLocaleTimeString()}</StateText>
                                            </div>
                                            <IntentText className="text-xs text-neutral-300">{log.message}</IntentText>
                                        </div>
                                        <StateText className="font-mono text-[9px] opacity-40">{log.latency}ms</StateText>
                                    </div>
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
                right={
                    <HumorousLoader delay={2000} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_1fr]">
                        <Quadrant type="intent" dominance="dominant" className="border-b overflow-hidden relative">
                             <div className="absolute inset-0 p-6 flex flex-col">
                                <ChartFrame label="API TRAFFIC VOLUME" metric="24h" trend="+12%" category="execution">
                                    <TimeGraph 
                                        data={trafficData} 
                                        dataKey="value"
                                        category="execution"
                                        height={200}
                                    />
                                </ChartFrame>
                             </div>
                        </Quadrant>
                        
                        <Quadrant type="state" className="flex flex-col border-t-0 rounded-t-none p-0">
                            <div className="h-full w-full">
                                <PostLaunchMonitorWidget />
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
            />
        </div>
    );
}