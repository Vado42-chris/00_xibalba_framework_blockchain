import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, AlertCircle, ArrowRight, ExternalLink, Terminal, Copy, Send, Layout, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

export default function GoLive() {
    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        toast.success("Copied to clipboard");
    };

    return (
        <div className="min-h-screen bg-black text-white p-8 font-sans selection:bg-emerald-500/30">
            <div className="max-w-4xl mx-auto space-y-12">
                
                {/* Header */}
                <div className="border-b border-white/10 pb-8 flex justify-between items-start">
                    <div>
                        <div className="flex items-center gap-3 mb-2">
                            <Badge variant="outline" className="border-emerald-500 text-emerald-500 bg-emerald-500/10 animate-pulse">
                                DEPLOYMENT MODE
                            </Badge>
                            <span className="text-neutral-500 font-mono text-xs">PRIORITY: SPEED</span>
                        </div>
                        <h1 className="text-4xl font-bold tracking-tight mb-4">Live-First Protocol</h1>
                        <p className="text-xl text-neutral-400">
                            The accelerated path: Deploy now, validate immediately, configure payments later.
                        </p>
                    </div>
                    <div className="text-right hidden md:block">
                         <div className="text-xs text-neutral-500 uppercase tracking-widest mb-1">Plain Language Objective</div>
                         <div className="text-sm text-white font-medium max-w-xs">
                            "Get the site live first. Payment can wait. Test everything else, then add payment when you're ready."
                         </div>
                    </div>
                </div>

                {/* Phase Alpha */}
                <section className="space-y-6">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold">1</div>
                        <div>
                            <h2 className="text-2xl font-semibold">Phase Alpha: Live Deployment</h2>
                            <p className="text-neutral-500 text-sm">Getting the code onto the public internet.</p>
                        </div>
                        <Badge className="bg-neutral-800 text-neutral-400 ml-auto">15 Minutes</Badge>
                    </div>

                    <div className="grid gap-6">
                        <Card className="bg-neutral-900/50 border-white/10">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <span className="text-emerald-400">1.1</span> Nervous System Link
                                </CardTitle>
                                <CardDescription>Connect Frontend to Backend.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="text-sm text-neutral-300">
                                    <p>In your Frontend deployment settings (Vercel/Netlify):</p>
                                    <p className="mt-2">Add Environment Variable:</p>
                                </div>
                                <div className="flex items-center justify-between text-xs font-mono bg-white/5 p-2 rounded border border-white/5">
                                    <span>REACT_APP_API_URL=https://your-backend-url.com</span>
                                    <Copy className="w-3 h-3 cursor-pointer hover:text-white" onClick={() => copyToClipboard('REACT_APP_API_URL=')} />
                                </div>
                                <div className="text-xs text-yellow-500/80 flex items-center gap-2">
                                    <AlertCircle className="w-3 h-3" />
                                    Trigger a redeploy after saving this variable.
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="bg-neutral-900/50 border-white/10">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <span className="text-emerald-400">1.2</span> Production Push
                                </CardTitle>
                                <CardDescription>Deploy Code to Servers.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2 text-sm text-neutral-300">
                                    <p>1. <strong>Backend:</strong> Deploy to Railway/Render/VPS. <span className="text-neutral-500">(Stripe keys NOT required yet)</span></p>
                                    <p>2. <strong>Frontend:</strong> Ensure Vercel/Netlify has latest build.</p>
                                    <p>3. <strong>Verify:</strong> Open your public URL (e.g., https://valhalla.dev).</p>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </section>

                {/* Phase Bravo */}
                <section className="space-y-6">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold">2</div>
                        <div>
                            <h2 className="text-2xl font-semibold">Phase Bravo: User Validation</h2>
                            <p className="text-neutral-500 text-sm">You become the first user (Seed001).</p>
                        </div>
                        <Badge className="bg-neutral-800 text-neutral-400 ml-auto">15 Minutes</Badge>
                    </div>

                    <div className="mb-4">
                        <Button 
                            variant="outline" 
                            className="w-full h-auto py-4 border-dashed border-emerald-500/30 hover:bg-emerald-500/5 text-left flex items-start gap-4 group" 
                            onClick={() => window.open('/SeedJourney', '_self')}
                        >
                            <div className="p-2 bg-emerald-500/10 rounded-full text-emerald-500 group-hover:scale-110 transition-transform">
                                <Layout className="w-5 h-5" />
                            </div>
                            <div>
                                <div className="font-bold text-white flex items-center gap-2">
                                    Run the Seed001 Protocol
                                    <ArrowRight className="w-4 h-4 opacity-50 group-hover:translate-x-1 transition-transform"/>
                                </div>
                                <div className="text-xs text-neutral-400 mt-1">
                                    Step-by-step guide to validating your own product before showing it to others.
                                </div>
                            </div>
                        </Button>
                    </div>
                </section>

                {/* Phase Charlie */}
                <section className="space-y-6">
                    <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold">3</div>
                        <div>
                            <h2 className="text-2xl font-semibold">Phase Charlie: First Traffic</h2>
                            <p className="text-neutral-500 text-sm">Getting the first 5 eyeballs on the product.</p>
                        </div>
                        <Badge className="bg-neutral-800 text-neutral-400 ml-auto">15 Minutes</Badge>
                    </div>

                    <Card className="bg-gradient-to-br from-indigo-900/20 to-black border-indigo-500/20">
                        <CardHeader>
                            <CardTitle>Validation Outreach</CardTitle>
                            <CardDescription>Send this honest request to 5 contacts.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <div className="bg-black/50 p-4 rounded border border-white/5 font-mono text-sm text-neutral-300 relative group">
                                <Button 
                                    size="icon" 
                                    variant="ghost" 
                                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={() => copyToClipboard(`Subject: Can you test a new platform I'm building?

Hey [Name], Hope you're well.

I'm building a new automation platform called Valhalla. We're in the very early stages (think "day one") and are just putting the finishing touches on the public site. It's not perfect, but I'd be incredibly grateful if you could take 5 minutes to check it out.

I'm specifically looking for feedback on the Slack integration. Can you try clicking "Connect Slack" and then "Test Connection" to see if it works for you?

Link: [YOUR_LIVE_SITE_URL]

This feedback is the most valuable thing to me right now.`)}
                                >
                                    <Copy className="w-4 h-4" />
                                </Button>
                                <p className="mb-2 text-neutral-500">Subject: Can you test a new platform I'm building?</p>
                                <p>Hey [Name], Hope you're well.</p>
                                <p className="mt-2">I'm building a new automation platform called Valhalla. We're in the very early stages (think "day one") and are just putting the finishing touches on the public site. It's not perfect, but I'd be incredibly grateful if you could take 5 minutes to check it out.</p>
                                <p className="mt-2">I'm specifically looking for feedback on the Slack integration. Can you try clicking "Connect Slack" and then "Test Connection" to see if it works for you?</p>
                                <p className="mt-2">Link: [YOUR_LIVE_SITE_URL]</p>
                                <p className="mt-2">This feedback is the most valuable thing to me right now.</p>
                            </div>
                        </CardContent>
                    </Card>
                </section>

                {/* Phase Delta (Locked) */}
                <section className="space-y-6 opacity-60">
                     <div className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold text-neutral-500">4</div>
                        <h2 className="text-2xl font-semibold text-neutral-500">Phase Delta: Revenue Config</h2>
                        <Badge variant="outline" className="border-neutral-700 text-neutral-500">Locked until Validation</Badge>
                    </div>
                    <Card className="bg-neutral-900/20 border-white/5 dashed border">
                        <CardHeader>
                             <CardTitle className="text-neutral-500">Activate Payments</CardTitle>
                             <CardDescription>Configure Stripe only after you have confirmed the site works.</CardDescription>
                        </CardHeader>
                    </Card>
                </section>

                <div className="pt-8 flex justify-center pb-12">
                     <Button size="lg" className="bg-emerald-500 text-black hover:bg-emerald-400 font-bold tracking-widest px-12 py-6 text-lg shadow-[0_0_20px_rgba(16,185,129,0.3)]">
                        <Send className="w-5 h-5 mr-2" />
                        I HAVE DEPLOYED
                     </Button>
                </div>

            </div>
        </div>
    );
}