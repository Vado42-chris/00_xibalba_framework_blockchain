import React from 'react';
import { useSiteContext } from '@/components/identity/SiteContext';
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant
} from '@/components/ui/design-system/System';
import { LoadingLab, InsightTip } from '@/components/ui/design-system/Curiosity';
import { Badge } from "@/components/ui/badge";
import { Server, Layout, Globe, Shield, Activity, Clock, Construction, Database, Cpu } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';

export default function DomainManifest() {
    const { domainData, currentDomain } = useSiteContext();
    const isProduction = domainData.status === 'production';
    
    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <Quadrant type="orientation" className="h-full flex flex-col">
                        <div className="mb-8">
                            <div className="flex items-center gap-3 mb-2">
                                <Globe className="w-5 h-5 text-[hsl(var(--color-active))]" />
                                <OrientingText className="tracking-widest font-bold text-lg">DOMAIN REGISTRY</OrientingText>
                            </div>
                            <IntentText className="text-3xl font-light">{currentDomain}</IntentText>
                            <div className="flex items-center gap-2 mt-2">
                                <Badge variant="outline" className={`
                                    border-opacity-30 
                                    ${isProduction ? 'border-green-500 text-green-500 bg-green-500/10' : 'border-yellow-500 text-yellow-500 bg-yellow-500/10'}
                                `}>
                                    {domainData.status.toUpperCase()}
                                </Badge>
                                <StateText className="uppercase tracking-wider opacity-60">{domainData.family}</StateText>
                            </div>
                        </div>

                        <div className="space-y-4 flex-1">
                             <Layer level="orientation" className="p-6 border-l-2 border-l-[hsl(var(--color-active))]">
                                <OrientingText className="mb-2 text-[hsl(var(--color-active))]">SYSTEM STATUS</OrientingText>
                                <p className="text-xl font-mono text-white leading-relaxed">
                                    "{domainData.specs?.message || "Status Unknown"}"
                                </p>
                             </Layer>
                             
                             <div className="grid grid-cols-2 gap-4">
                                <Layer level="state" className="p-4">
                                    <OrientingText className="mb-1">INTENT</OrientingText>
                                    <IntentText className="text-sm">{domainData.intent}</IntentText>
                                </Layer>
                                <Layer level="state" className="p-4">
                                    <OrientingText className="mb-1">AUTHORITY</OrientingText>
                                    <IntentText className="text-sm">{domainData.categories?.[0] || "Admin"}</IntentText>
                                </Layer>
                             </div>
                             
                             {!isProduction && (
                                <div className="mt-8 relative overflow-hidden rounded-lg border border-white/5 bg-neutral-900/50 p-6 flex flex-col items-center justify-center text-center">
                                    <Construction className="w-12 h-12 text-neutral-700 mb-4" />
                                    <OrientingText>CONSTRUCTION ZONE</OrientingText>
                                    <StateText className="mt-2 max-w-xs opacity-50">
                                        This domain is currently being provisioned by the systems architect.
                                    </StateText>
                                    <LoadingLab active={true} cause="Provisioning Resources" duration="Est. Q3 2025" className="absolute inset-0 opacity-10 pointer-events-none" />
                                </div>
                             )}
                        </div>
                    </Quadrant>
                }
                right={
                    <QuadrantGrid className="p-0 h-full">
                        <Quadrant type="intent" dominance="dominant" className="overflow-y-auto">
                            <div className="flex items-center gap-2 mb-6 border-b border-white/10 pb-4">
                                <Layout className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                                <OrientingText className="text-lg">CONTENT STRATEGY</OrientingText>
                            </div>
                            
                            <div className="prose prose-invert max-w-none">
                                <p className="text-xl text-[hsl(var(--fg-intent))] font-light leading-relaxed mb-6">
                                    {domainData.specs?.content}
                                </p>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                                    <div className="p-4 border border-white/10 rounded bg-neutral-900/50">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Activity className="w-4 h-4 text-neutral-400" />
                                            <StateText className="font-bold">TARGET AUDIENCE</StateText>
                                        </div>
                                        <ul className="list-disc list-inside space-y-1">
                                            {domainData.categories?.map((cat, i) => (
                                                <li key={i} className="text-sm text-neutral-400">{cat}</li>
                                            ))}
                                        </ul>
                                    </div>
                                    <div className="p-4 border border-white/10 rounded bg-neutral-900/50">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Shield className="w-4 h-4 text-neutral-400" />
                                            <StateText className="font-bold">ACCESS LEVEL</StateText>
                                        </div>
                                        <p className="text-sm text-neutral-400">
                                            {isProduction ? "Public / Authenticated" : "Restricted / Developers Only"}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" className="overflow-y-auto">
                            <div className="flex items-center gap-2 mb-6 border-b border-white/10 pb-4">
                                <Server className="w-5 h-5 text-[hsl(var(--color-active))]" />
                                <OrientingText className="text-lg">TECHNICAL ARCHITECTURE</OrientingText>
                            </div>

                            <div className="space-y-6">
                                <div className="p-4 bg-neutral-950 rounded border border-dashed border-white/10 font-mono text-sm text-[hsl(var(--color-active))] leading-relaxed shadow-[inset_0_0_20px_rgba(0,0,0,0.5)]">
                                    <span className="text-neutral-500">$ sys_check --target {currentDomain}</span><br/>
                                    <span className="text-neutral-500">{'>'}</span> {domainData.specs?.backend}
                                </div>

                                <div className="space-y-3">
                                    <Layer level="state" className="flex items-center justify-between p-3">
                                        <div className="flex items-center gap-3">
                                            <Database className="w-4 h-4 text-neutral-500" />
                                            <StateText>DATA PERSISTENCE</StateText>
                                        </div>
                                        <SemanticDot type={isProduction ? "active" : "pending"} />
                                    </Layer>
                                    <Layer level="state" className="flex items-center justify-between p-3">
                                        <div className="flex items-center gap-3">
                                            <Cpu className="w-4 h-4 text-neutral-500" />
                                            <StateText>COMPUTE NODES</StateText>
                                        </div>
                                        <SemanticDot type={isProduction ? "active" : "warning"} />
                                    </Layer>
                                    <Layer level="state" className="flex items-center justify-between p-3">
                                        <div className="flex items-center gap-3">
                                            <Globe className="w-4 h-4 text-neutral-500" />
                                            <StateText>CDN PROPAGATION</StateText>
                                        </div>
                                        <SemanticDot type={isProduction ? "active" : "settled"} />
                                    </Layer>
                                </div>

                                <InsightTip type="mirror" title="Architecture">
                                    The backend adapts to the domain's intent. {domainData.family} utilizes {domainData.family === 'Veilrift' ? 'distributed ledgers' : 'relational models'}.
                                </InsightTip>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}