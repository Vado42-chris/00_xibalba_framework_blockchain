import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Server, Globe, Activity, Terminal, Shield, 
    RefreshCw, Power, Play, Square, Settings, 
    HardDrive, Cpu, AlertCircle, CheckCircle2,
    DollarSign, Lock, Cloud
} from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, 
    StateText, SemanticDot, Layer, AtomicParagraph
} from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader, SystemNav } from '@/components/ui/design-system/SystemComponents';
import { SystemTerminal, SystemStats } from '@/components/ui/design-system/SystemContent';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import DeploymentModal from '@/components/reaper/DeploymentModal';
import { TutorialOverlay } from '@/components/education/TutorialOverlay';

const InteractiveTerminal = ({ nodeName }) => {
    return (
        <SystemTerminal 
            prompt={`root@${nodeName}:~$`}
            initialLines={[
                { type: 'output', content: `Last login: ${new Date().toUTCString()} from 192.168.1.5` },
                { type: 'output', content: 'Welcome to Base44 Server Control.' },
            ]}
            onCommand={(cmd, cb) => {
                setTimeout(() => {
                    let output = '';
                    switch(cmd) {
                        case 'ls': output = 'bin  boot  dev  etc  home  lib  media  mnt  opt  proc  root  run  sbin  srv  sys  tmp  usr  var'; break;
                        case 'whoami': output = 'root'; break;
                        case 'pwd': output = '/root'; break;
                        case 'uptime': output = ' 14:23:01 up 42 days,  3:12,  1 user,  load average: 0.05, 0.03, 0.01'; break;
                        case 'top': output = 'Mem: 8192K used, 245K free, 0K shrd, 0K buff, 421K cached'; break;
                        case 'help': output = 'Available commands: ls, whoami, pwd, uptime, top, clear'; break;
                        default: output = `bash: ${cmd}: command not found`;
                    }
                    cb(output);
                }, 200);
            }}
            className="border-none bg-transparent"
        />
    );
};

import { ServiceRow } from '@/components/server/ServiceRow';
import { DomainRow } from '@/components/server/DomainRow';

export default function ServerControl() {
    const [activeTab, setActiveTab] = useState('dashboard'); // dashboard, domains, services, terminal
    const [selectedNode, setSelectedNode] = useState(null);
    const [isDeployOpen, setIsDeployOpen] = useState(false);

    const { data: nodes = [] } = useQuery({
        queryKey: ['nodes'],
        queryFn: () => base44.entities.Node.list(),
    });

    const { data: domains = [] } = useQuery({
        queryKey: ['managed_domains'],
        queryFn: () => base44.entities.ManagedDomain.list(),
    });

    const { data: services = [] } = useQuery({
        queryKey: ['server_services'],
        queryFn: () => base44.entities.ServerService.list(),
    });

    const { data: deployments = [] } = useQuery({
        queryKey: ['deployments'],
        queryFn: () => base44.entities.DeploymentLog.list({ sort: { created_date: -1 }, limit: 5 }),
    });

    const rollbackMutation = useMutation({
        mutationFn: (deployment) => base44.entities.DeploymentLog.create({
            ...deployment,
            status: 'rolling_back',
            description: `Rollback of ${deployment.version}`,
            id: undefined // Create new record
        }),
        onSuccess: () => {
            queryClient.invalidateQueries(['deployments']);
            toast.success("Rollback sequence initiated");
        }
    });

    // Mock stats
    const stats = {
        cpu: 42,
        mem: 68,
        disk: 55,
        network: "1.2 Gbps"
    };

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Server className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">SERVER CONTROL</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Infrastructure Ops</IntentText>
                                </div>
                                <div className="flex items-center gap-2">
                                     <div className="flex items-center gap-1.5 px-2 py-1 bg-green-500/10 rounded text-green-500 text-xs border border-green-500/20">
                                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                                        SYSTEM OPTIMAL
                                     </div>
                                </div>
                            </div>

                            <SystemNav 
                                activeId={activeTab}
                                onSelect={setActiveTab}
                                items={[
                                    { id: 'dashboard', label: 'Overview', icon: Activity, type: 'active' },
                                    { id: 'domains', label: 'Domains', icon: Globe, type: 'settled' },
                                    { id: 'services', label: 'Services', icon: Settings, type: 'settled' },
                                    { id: 'terminal', label: 'Terminal', icon: Terminal, type: 'warning' }
                                ]}
                            />

                            <GuideBox title="Control Panel">
                                <p className="mb-2">
                                    Manage your <TermHelper term="Bare Metal" definition="Physical servers, not virtual." /> and domain portfolio.
                                </p>
                                <div className="grid grid-cols-2 gap-2 text-[10px] text-neutral-500">
                                    <div>• Auto-scaling: ON</div>
                                    <div>• Backup: Daily</div>
                                    <div>• DNS: Cloudflare</div>
                                    <div>• SSL: Let's Encrypt</div>
                                </div>
                            </GuideBox>
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">ACTIVE NODES</OrientingText>
                            <div className="space-y-2 overflow-y-auto h-full pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {nodes.map((node) => (
                                    <SystemCard
                                        key={node.id}
                                        title={node.name}
                                        subtitle={node.ip_address}
                                        status={node.status === 'connected' ? 'active' : 'error'}
                                        metric="42%"
                                        active={selectedNode?.id === node.id}
                                        onClick={() => setSelectedNode(node)}
                                        icon={Server}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                         <Quadrant type="intent" dominance="dominant" className="p-0 flex flex-col h-full overflow-hidden">
                            {activeTab === 'dashboard' && (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300">
                                    <div className="p-8 border-b border-white/5 bg-neutral-900/30">
                                        <div className="flex items-center gap-2 mb-4">
                                            <Activity className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                            <OrientingText className="tracking-widest font-bold">SYSTEM METRICS</OrientingText>
                                        </div>
                                        
                                        <SystemStats 
                                            className="grid-cols-3"
                                            stats={[
                                                { label: "CPU Load", value: `${stats.cpu}%`, icon: Cpu, progress: stats.cpu, color: "text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]" },
                                                { label: "Memory", value: `${stats.mem}%`, icon: HardDrive, progress: stats.mem, color: "text-blue-500 bg-blue-500" },
                                                { label: "Disk Usage", value: `${stats.disk}%`, icon: Cloud, progress: stats.disk, color: "text-purple-500 bg-purple-500" }
                                            ]}
                                        />
                                    </div>
                                    
                                    <div className="p-8 space-y-6 flex-1 overflow-y-auto">
                                        
                                        {/* Deployment Activity */}
                                        <div className="mb-8">
                                            <div className="flex items-center justify-between mb-4">
                                                <div className="flex items-center gap-4">
                                                    <OrientingText>RECENT DEPLOYMENTS</OrientingText>
                                                    <Badge variant="outline" className="text-[9px] h-5 border-white/10 text-neutral-500">{deployments.length} Records</Badge>
                                                </div>
                                                <Button 
                                                    variant="outline" 
                                                    size="sm" 
                                                    className="h-6 text-[10px] border-white/10 text-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/10"
                                                    onClick={() => setIsDeployOpen(true)}
                                                >
                                                    New Deployment
                                                </Button>
                                            </div>
                                            <div className="space-y-2">
                                                {deployments.length === 0 ? (
                                                    <div className="p-4 border border-dashed border-white/10 rounded text-center text-xs text-neutral-500">
                                                        No deployments recorded yet.
                                                    </div>
                                                ) : (
                                                    deployments.map(deploy => (
                                                        <div key={deploy.id} className="p-3 bg-neutral-900 border border-white/5 rounded flex justify-between items-center group hover:border-white/10 transition-colors">
                                                            <div className="flex items-center gap-3">
                                                                <div className={cn("w-2 h-2 rounded-full", 
                                                                    deploy.status === 'success' ? "bg-green-500" : 
                                                                    deploy.status === 'pending' ? "bg-yellow-500 animate-pulse" : "bg-red-500"
                                                                )} />
                                                                <div>
                                                                    <div className="text-xs font-bold text-neutral-200">{deploy.description}</div>
                                                                    <div className="text-[10px] text-neutral-500 font-mono">
                                                                        Target: <span className="text-[hsl(var(--color-intent))]">{deploy.node_name}</span> • {deploy.version}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="flex items-center gap-3">
                                                                <div className="text-[10px] text-neutral-600 font-mono">
                                                                    {new Date(deploy.created_date).toLocaleTimeString()}
                                                                </div>
                                                                <Button 
                                                                    size="icon" 
                                                                    variant="ghost" 
                                                                    className="h-6 w-6 text-neutral-500 hover:text-red-500 hover:bg-red-500/10" 
                                                                    title="Rollback to this version"
                                                                    onClick={() => rollbackMutation.mutate(deploy)}
                                                                >
                                                                    <RefreshCw className="w-3 h-3" />
                                                                </Button>
                                                            </div>
                                                        </div>
                                                    ))
                                                )}
                                            </div>
                                        </div>

                                        <div className="flex items-center justify-between mb-4">
                                            <OrientingText>QUICK ACTIONS</OrientingText>
                                            <Button variant="outline" size="sm" className="h-6 text-[10px] border-white/10 text-neutral-400">View Logs</Button>
                                        </div>
                                        
                                        <div className="grid grid-cols-2 gap-4">
                                            <Button variant="secondary" className="h-auto p-4 flex flex-col items-center gap-2 bg-neutral-900/50 border border-white/5 hover:border-[hsl(var(--color-execution))] hover:bg-neutral-900">
                                                <RefreshCw className="w-6 h-6 text-[hsl(var(--color-execution))]" />
                                                <span className="text-xs">Restart All Services</span>
                                            </Button>
                                            <Button variant="secondary" className="h-auto p-4 flex flex-col items-center gap-2 bg-neutral-900/50 border border-white/5 hover:border-red-500 hover:bg-neutral-900">
                                                <Shield className="w-6 h-6 text-red-500" />
                                                <span className="text-xs">System Lockdown</span>
                                            </Button>
                                        </div>

                                        <div className="mt-8">
                                            <OrientingText className="mb-4">SYSTEM NOTIFICATIONS</OrientingText>
                                            <div className="space-y-2">
                                                <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded flex gap-3">
                                                    <AlertCircle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
                                                    <div>
                                                        <div className="text-xs font-bold text-yellow-500 mb-1">Update Available</div>
                                                        <p className="text-[10px] text-neutral-400">Kernel patch v6.2.4 ready for installation. Reboot required.</p>
                                                    </div>
                                                </div>
                                                <div className="p-3 bg-neutral-900 border border-white/5 rounded flex gap-3">
                                                    <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                                                    <div>
                                                        <div className="text-xs font-bold text-white mb-1">Backup Completed</div>
                                                        <p className="text-[10px] text-neutral-400">Snapshot taken at 04:00 AM (24GB).</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {activeTab === 'domains' && (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300">
                                    <div className="p-8 border-b border-white/5 bg-neutral-900/30 flex justify-between items-center">
                                        <div>
                                            <div className="flex items-center gap-2 mb-2">
                                                <Globe className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                                <OrientingText className="tracking-widest font-bold">DOMAIN PORTFOLIO</OrientingText>
                                            </div>
                                            <IntentText className="text-xl font-light">At-Cost Management</IntentText>
                                        </div>
                                        <Button className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90">
                                            Register New
                                        </Button>
                                    </div>
                                    <div className="p-8 flex-1 overflow-y-auto space-y-3">
                                        {domains.length === 0 ? (
                                             <div className="text-center py-12 opacity-50">
                                                <Globe className="w-12 h-12 mx-auto mb-4 text-neutral-700" />
                                                <StateText>No domains managed</StateText>
                                            </div>
                                        ) : (
                                            domains.map(domain => <DomainRow key={domain.id} domain={domain} />)
                                        )}
                                        
                                        <div className="mt-8 p-4 border border-white/5 rounded bg-neutral-900/20">
                                            <div className="flex items-center gap-2 mb-2">
                                                <DollarSign className="w-4 h-4 text-green-500" />
                                                <OrientingText className="text-green-500 font-bold">COST SAVINGS</OrientingText>
                                            </div>
                                            <AtomicParagraph>
                                                You are saving an estimated <span className="text-white font-bold">$142/year</span> by using direct-to-registrar pricing with no markup fees.
                                            </AtomicParagraph>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {activeTab === 'services' && (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300">
                                    <div className="p-8 border-b border-white/5 bg-neutral-900/30">
                                        <div className="flex items-center gap-2 mb-2">
                                            <Settings className="w-4 h-4 text-blue-500" />
                                            <OrientingText className="tracking-widest font-bold text-blue-500">SERVICE MESH</OrientingText>
                                        </div>
                                        <IntentText className="text-xl font-light">Process Control</IntentText>
                                    </div>
                                    <div className="flex-1 overflow-y-auto">
                                        {services.map(service => <ServiceRow key={service.id} service={service} />)}
                                        {services.length === 0 && (
                                            <div className="p-8 text-center opacity-50">
                                                <StateText>No services monitored</StateText>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}

                            {activeTab === 'terminal' && (
                                <div className="flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 bg-black">
                                    <div className="p-2 border-b border-white/10 flex items-center gap-2 bg-neutral-900">
                                        <Terminal className="w-3 h-3 text-neutral-400" />
                                        <span className="text-xs text-neutral-400 font-mono">root@{selectedNode?.name || 'core-01'}:~</span>
                                    </div>
                                    <InteractiveTerminal nodeName={selectedNode?.name || 'core-01'} />
                                </div>
                            )}
                         </Quadrant>
                    </QuadrantGrid>
                }
            />
            <DeploymentModal 
                open={isDeployOpen} 
                onOpenChange={setIsDeployOpen} 
            />

            <TutorialOverlay 
                tutorialId="server_control_intro"
                steps={[
                    { title: "Infrastructure", content: "Manage your physical and virtual hardware assets here.", position: "top-left" },
                    { title: "Node List", content: "Monitor the health and status of your active server nodes.", position: "center" },
                    { title: "Metrics", content: "Real-time telemetry on CPU, Memory, and Network usage.", position: "top-right" },
                    { title: "Terminal", content: "Access direct shell control for deep system management.", position: "bottom-left" }
                ]}
            />
        </div>
    );
}