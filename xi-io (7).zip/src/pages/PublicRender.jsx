import React, { useEffect, useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import SandboxedRenderer from '@/components/content/SandboxedRenderer';
import { InteractionManager } from '@/components/interaction/InteractionManager';
import { Loader2, AlertCircle } from 'lucide-react';

export default function PublicRender() {
    const [searchParams] = useSearchParams();
    const slug = searchParams.get('slug');
    const [page, setPage] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        if (!slug) {
            setError("No slug provided");
            setLoading(false);
            return;
        }

        async function fetchPage() {
            try {
                // Fetch published page by slug
                const pages = await base44.entities.ContentPage.list({ 
                    slug: slug,
                    status: 'published'
                });
                
                if (pages.length === 0) {
                    setError("Page not found");
                } else {
                    setPage(pages[0]);
                }
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        }

        fetchPage();
    }, [slug]);

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-black text-white">
                <Loader2 className="w-8 h-8 animate-spin text-[hsl(var(--color-intent))]" />
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen bg-black text-white p-6">
                <AlertCircle className="w-12 h-12 text-red-500 mb-4" />
                <h1 className="text-2xl font-bold mb-2">Error Loading Page</h1>
                <p className="text-neutral-400">{error}</p>
            </div>
        );
    }

    if (!page) return null;

    // Flatten all rules from all blocks for the manager
    const allRules = page.blocks ? page.blocks.flatMap(b => b.interactions || []) : [];

    // Render logic - strips all editor UI
    return (
        <div className="min-h-screen bg-white">
            {/* SEO Metadata injection would go here (e.g. react-helmet) */}
            <title>{page.seo_title || page.title}</title>
            <meta name="description" content={page.seo_description} />

            {/* Content Rendering with Nervous System */}
            <InteractionManager rules={allRules}>
                <div className="w-full">
                    {page.blocks && page.blocks.length > 0 ? (
                        page.blocks.map((block, idx) => (
                            <div key={block.id || idx} className="w-full">
                                <SandboxedRenderer 
                                    id={block.id || block.uniqueId}
                                    html={block.html || block.content} 
                                    data={block.data}
                                    type={block.type}
                                />
                            </div>
                        ))
                    ) : (
                        <div dangerouslySetInnerHTML={{ __html: page.content }} />
                    )}
                </div>
            </InteractionManager>
        </div>
    );
}