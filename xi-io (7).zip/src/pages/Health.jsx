import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Activity, Heart, Thermometer, Brain, 
    Pill
} from 'lucide-react';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, Layer, ChartFrame
} from '@/components/ui/design-system/System';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TimeGraph } from '@/components/ui/design-system/Infographics';
import moment from 'moment';

export default function Health() {
    const { data: metrics = [] } = useQuery({
        queryKey: ['health_metrics'],
        queryFn: () => base44.entities.HealthMetric.list('-date', 50),
        initialData: []
    });

    // Process Data
    const latestMetric = (type) => metrics.find(m => m.type === type);
    const hrv = latestMetric('hrv');
    const sleep = latestMetric('sleep_hours');
    const strain = latestMetric('strain');
    
    // Chart Data (Last 7 sleep records)
    const sleepHistory = metrics
        .filter(m => m.type === 'sleep_hours')
        .slice(0, 7)
        .reverse()
        .map(m => ({
            t: moment(m.date).format('dd'),
            v: m.value
        }));

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Heart className="w-4 h-4 text-rose-500" />
                                        <OrientingText className="tracking-widest font-bold text-rose-500">BIO-TELEMETRY</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Health Optimization</IntentText>
                                </div>
                                <Badge variant="outline" className="border-rose-500/20 text-rose-500 bg-rose-500/10">
                                    LIVE DATA
                                </Badge>
                            </div>
                            
                            <SystemStats
                                className="grid-cols-3 gap-2"
                                stats={[
                                    { 
                                        label: "HRV", 
                                        value: hrv ? `${hrv.value}${hrv.unit || 'ms'}` : '--', 
                                        icon: Heart, 
                                        color: "text-rose-500",
                                        progress: hrv ? Math.min((hrv.value / 100) * 100, 100) : 0
                                    },
                                    { 
                                        label: "Sleep", 
                                        value: sleep ? `${sleep.value}${sleep.unit || 'h'}` : '--', 
                                        icon: Brain, 
                                        color: "text-cyan-500",
                                        progress: sleep ? Math.min((sleep.value / 9) * 100, 100) : 0
                                    },
                                    { 
                                        label: "Strain", 
                                        value: strain ? `${strain.value}` : '--', 
                                        icon: Activity, 
                                        color: "text-orange-500",
                                        progress: strain ? Math.min((strain.value / 21) * 100, 100) : 0
                                    }
                                ]}
                            />
                        </Quadrant>

                        <Quadrant type="state" dominance="dominant" className="border-t-0 rounded-t-none">
                            <OrientingText className="mb-4">RECENT LOGS</OrientingText>
                            <div className="space-y-2 overflow-y-auto max-h-[300px] pr-2">
                                {metrics.length === 0 && <div className="text-xs text-neutral-500 italic">No health data recorded yet.</div>}
                                {metrics.map((m) => (
                                    <div key={m.id} className="p-3 border border-white/5 rounded bg-neutral-900/30 flex justify-between items-center">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded bg-neutral-800 text-neutral-400">
                                                {m.type === 'hrv' ? <Heart className="w-3 h-3" /> : 
                                                 m.type === 'sleep_hours' ? <Brain className="w-3 h-3" /> : 
                                                 <Activity className="w-3 h-3" />}
                                            </div>
                                            <div>
                                                <IntentText className="text-sm capitalize">{m.type.replace('_', ' ')}</IntentText>
                                                <StateText className="text-[10px] opacity-50">{moment(m.date).fromNow()}</StateText>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-sm font-bold text-white">{m.value} <span className="text-[10px] font-normal text-neutral-500">{m.unit}</span></div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[1fr_1fr]">
                        <Quadrant type="intent" dominance="dominant" className="border-b">
                            <div className="h-full flex flex-col">
                                <ChartFrame label="SLEEP TREND (LAST 7 LOGS)" metric={sleep ? `${sleep.value}h` : '--'} trend="Latest" category="settled">
                                    {sleepHistory.length > 0 ? (
                                        <TimeGraph 
                                            data={sleepHistory} 
                                            dataKey="v" 
                                            category="settled" 
                                            height={150} 
                                        />
                                    ) : (
                                        <div className="h-full flex items-center justify-center text-xs text-neutral-500">Not enough data for chart</div>
                                    )}
                                </ChartFrame>
                            </div>
                        </Quadrant>
                        
                        <Quadrant type="state" className="border-t-0 rounded-t-none">
                            <div className="flex justify-between items-center mb-4">
                                <OrientingText>PROTOCOLS</OrientingText>
                                <Button size="sm" variant="ghost" className="h-6 text-[10px]">MANAGE</Button>
                            </div>
                            <div className="space-y-2">
                                <div className="p-2 hover:bg-white/5 rounded transition-colors cursor-pointer flex items-center justify-between group">
                                    <div className="flex items-center gap-3">
                                        <Pill className="w-4 h-4 text-blue-500" />
                                        <span className="text-xs text-neutral-300">Morning Stack (Vit D, Omega 3)</span>
                                    </div>
                                    <Badge variant="outline" className="text-[9px] border-white/10 opacity-0 group-hover:opacity-100">LOG</Badge>
                                </div>
                                <div className="p-2 hover:bg-white/5 rounded transition-colors cursor-pointer flex items-center justify-between group">
                                    <div className="flex items-center gap-3">
                                        <Activity className="w-4 h-4 text-orange-500" />
                                        <span className="text-xs text-neutral-300">Zone 2 Cardio (45m)</span>
                                    </div>
                                    <Badge variant="outline" className="text-[9px] border-white/10 opacity-0 group-hover:opacity-100">LOG</Badge>
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}