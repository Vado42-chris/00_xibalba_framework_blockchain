import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { CircuitBoard, Play, Pause, GitBranch, AlertCircle, Plus, Clock, Search } from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    IntentText, StateText, SemanticDot, Layer, 
    AtomicParagraph, OrientingText, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { GuideBox, TermHelper } from '@/components/ui/GuideBox';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import WorkflowBuilder from '@/components/workflows/WorkflowBuilder';
import { cn } from "@/lib/utils";

export default function Automation() {
    const [selectedWorkflow, setSelectedWorkflow] = useState(null);
    const [filter, setFilter] = useState('');
    const [isBuilderOpen, setIsBuilderOpen] = useState(false);
    
    const { data: workflows = [] } = useQuery({
        queryKey: ['workflows'],
        queryFn: () => base44.entities.Workflow.list(),
        initialData: []
    });

    const filtered = workflows.filter(w => (w.name || '').toLowerCase().includes(filter.toLowerCase()));
    
    // Stats
    const activeCount = workflows.filter(w => w.active).length;
    
    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <HumorousLoader delay={1350} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Node Logic" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <CircuitBoard className="w-4 h-4 text-[hsl(var(--color-system))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-system))]">AUTOMATION GRID</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">Orchestration Engine</IntentText>
                                </div>
                            </div>
                            
                            <GuideBox title="Node Logic">
                                <p className="mb-2">
                                    Program the brain of your <TermHelper term="Sovereign Node" definition="Your independent automation server." />.
                                </p>
                                <p className="text-xs opacity-70">
                                    Workflows built here export directly to <code>systemd</code> services on your future Linux build.
                                </p>
                            </GuideBox>

                            <div className="grid grid-cols-2 gap-4 mt-4">
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">Total Flows</StateText>
                                    <IntentText className="text-xl">{workflows.length}</IntentText>
                                </div>
                                <div className="space-y-1">
                                    <StateText className="text-[10px] opacity-50 uppercase tracking-wider">Active</StateText>
                                    <IntentText className="text-xl text-[hsl(var(--color-system))]">{activeCount}</IntentText>
                                </div>
                            </div>

                            <div className="mt-6">
                                <Button onClick={() => setIsBuilderOpen(true)} className="w-full bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white font-bold h-10 text-xs tracking-widest shadow-[0_0_15px_rgba(236,72,153,0.3)]">
                                    <Plus className="w-3 h-3 mr-2" /> NEW WORKFLOW
                                </Button>
                            </div>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Workflows" className="border-t-0 rounded-t-none flex flex-col">
                            <div className="mb-4 relative shrink-0">
                                <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                                <Input 
                                    placeholder="Search workflows..." 
                                    className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs"
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto space-y-2 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {filtered.map((item) => (
                                    <SystemCard
                                        key={item.id}
                                        title={item.name}
                                        subtitle={`${item.steps?.length || 0} Steps`}
                                        status={item.active ? 'execution' : 'settled'}
                                        metric={item.trigger}
                                        active={selectedWorkflow?.id === item.id}
                                        onClick={() => setSelectedWorkflow(item)}
                                        icon={CircuitBoard}
                                    />
                                ))}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
                right={
                    <HumorousLoader delay={1950} className="h-full">
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" step="2" title="Configuration" dominance="dominant" className="h-full p-0 flex flex-col">
                            {selectedWorkflow ? (
                                <div className="flex flex-col h-full animate-in fade-in duration-300">
                                    <SystemDetailHeader
                                        title={selectedWorkflow.name}
                                        subtitle={selectedWorkflow.active ? 'Running' : 'Paused'}
                                        category="WORKFLOW"
                                        icon={CircuitBoard}
                                    >
                                        <div className="flex gap-2">
                                            <Button 
                                                size="sm" 
                                                variant="outline" 
                                                className="h-7 text-xs border-white/10"
                                                onClick={() => setIsBuilderOpen(true)}
                                            >
                                                Edit
                                            </Button>
                                            <Button size="sm" className={`h-7 text-xs ${selectedWorkflow.active ? 'bg-[hsl(var(--color-error))]/20 text-[hsl(var(--color-error))] hover:bg-[hsl(var(--color-error))]/30' : 'bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/30'}`}>
                                                {selectedWorkflow.active ? <Pause className="w-3 h-3 mr-1" /> : <Play className="w-3 h-3 mr-1" />}
                                                {selectedWorkflow.active ? 'Stop' : 'Start'}
                                            </Button>
                                        </div>
                                    </SystemDetailHeader>
                                    
                                    <div className="p-8 space-y-6 overflow-y-auto bg-transparent flex-1">
                                        <Layer level="intent">
                                            <OrientingText className="mb-2">DESCRIPTION</OrientingText>
                                            <AtomicParagraph className="text-neutral-300">{selectedWorkflow.description || "No description provided."}</AtomicParagraph>
                                        </Layer>

                                        <Layer level="state">
                                            <OrientingText className="mb-4">EXECUTION CHAIN</OrientingText>
                                            <div className="space-y-0">
                                                {selectedWorkflow.steps && selectedWorkflow.steps.length > 0 ? selectedWorkflow.steps.map((step, i) => (
                                                    <div key={i} className="flex gap-4 relative">
                                                        <div className="flex flex-col items-center">
                                                            <div className="w-6 h-6 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center text-[10px] font-mono shrink-0 z-10">
                                                                {i + 1}
                                                            </div>
                                                            {i < selectedWorkflow.steps.length - 1 && <div className="w-px h-full bg-white/5 absolute top-6" />}
                                                        </div>
                                                        <div className="pb-6">
                                                            <div className="p-3 bg-neutral-900/50 border border-white/5 rounded min-w-[200px]">
                                                                <IntentText className="text-sm font-bold">{step.name}</IntentText>
                                                                <StateText className="text-[10px] opacity-50 uppercase">{step.type}</StateText>
                                                            </div>
                                                        </div>
                                                    </div>
                                                )) : (
                                                    <div className="text-center py-8 opacity-30 border border-dashed border-white/5 rounded">
                                                        <OrientingText>No steps configured</OrientingText>
                                                    </div>
                                                )}
                                            </div>
                                        </Layer>
                                        
                                         <Layer level="orientation">
                                            <OrientingText className="mb-2">CONFIGURATION</OrientingText>
                                            <pre className="font-mono text-[10px] text-neutral-500 bg-neutral-900/50 p-4 rounded border border-white/5 overflow-x-auto">
                                                {JSON.stringify({ trigger: selectedWorkflow.trigger, error_policy: selectedWorkflow.error_policy, config: selectedWorkflow.config }, null, 2)}
                                            </pre>
                                        </Layer>
                                    </div>
                                </div>
                            ) : (
                                <div className="flex flex-col items-center justify-center h-full opacity-30 p-8 text-center space-y-4">
                                    <CircuitBoard className="w-16 h-16 text-neutral-500 stroke-1" />
                                    <div>
                                        <IntentText className="text-xl font-light">Workflow Editor</IntentText>
                                        <StateText>Select a workflow to configure steps and triggers.</StateText>
                                    </div>
                                </div>
                            )}
                        </Quadrant>
                    </QuadrantGrid>
                    </HumorousLoader>
                }
            />
            {isBuilderOpen && (
                <WorkflowBuilder 
                    initialData={selectedWorkflow}
                    onCancel={() => {
                        setIsBuilderOpen(false);
                        setSelectedWorkflow(null);
                    }}
                    onSave={(data) => {
                        toast.success(selectedWorkflow ? "Workflow updated" : "Workflow created");
                        setIsBuilderOpen(false);
                        setSelectedWorkflow(null);
                        // In a real app, we'd mutate here
                    }}
                />
            )}
        </div>
    );
}