import { base44 } from './base44Client';


export const healer = base44.functions.healer;

export const provisionInstance = base44.functions.provisionInstance;

export const addonInstaller = base44.functions.addonInstaller;

export const deploySite = base44.functions.deploySite;

export const forgeBrowser = base44.functions.forgeBrowser;

export const exportSite = base44.functions.exportSite;

export const aiGenerate = base44.functions.aiGenerate;

export const promptLibrary = base44.functions.promptLibrary;

export const collabSync = base44.functions.collabSync;

export const summonDashboard = base44.functions.summonDashboard;

export const spotify = base44.functions.spotify;

export const slack = base44.functions.slack;

export const googleCalendar = base44.functions.googleCalendar;

export const salesforce = base44.functions.salesforce;

export const checkConnections = base44.functions.checkConnections;

export const README = base44.functions.README;

export const systemHealth = base44.functions.systemHealth;

export const aiQuery = base44.functions.aiQuery;

export const analyticsRisks = base44.functions.analyticsRisks;

export const marketplaceServices = base44.functions.marketplaceServices;

export const installService = base44.functions.installService;

export const health = base44.functions.health;

export const connectors = base44.functions.connectors;

export const activity = base44.functions.activity;

export const concierge = base44.functions.concierge;

export const stripe = base44.functions.stripe;

export const configureStripe = base44.functions.configureStripe;

export const leads = base44.functions.leads;

export const autoFix = base44.functions.autoFix;

