import React from 'react';
import { 
    Globe, ChevronRight, ChevronUp, Check, 
    Palette, Book, Server, Briefcase, Shield,
    Cpu, Code, Terminal, Layers
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuTrigger,
    DropdownMenuSeparator,
    DropdownMenuLabel,
    DropdownMenuGroup
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useSiteContext } from '@/components/identity/SiteContext';
import { cn } from '@/lib/utils';
import { Badge } from "@/components/ui/badge";

export default function DomainRotator() {
    const { currentDomain, domainData, rotateContext, ecosystem } = useSiteContext();

    // Group domains by Family for the UI
    const groupedDomains = Object.entries(ecosystem).reduce((acc, [key, data]) => {
        if (!acc[data.family]) acc[data.family] = [];
        acc[data.family].push({ key, ...data });
        return acc;
    }, {});

    const getFamilyIcon = (family) => {
        switch(family) {
            case 'Xibalba': return Palette;
            case 'Veilrift': return Terminal;
            case 'XI-IO': return Server;
            case 'Numerical': return Briefcase;
            default: return Globe;
        }
    };

    const CurrentIcon = getFamilyIcon(domainData.family);

    return (
        <div className="w-full px-3 py-2">
            <div className="flex items-center gap-2 mb-2 px-1">
                <Link to={createPageUrl('DomainManifest')} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full h-6 text-[9px] border-white/10 text-neutral-500 hover:text-[hsl(var(--color-active))] hover:border-[hsl(var(--color-active))] uppercase tracking-wider">
                         {domainData.status === 'production' ? 'System Active' : 'Setup Pending'}
                    </Button>
                </Link>
            </div>
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button 
                        variant="ghost" 
                        className={cn(
                            "w-full justify-between h-auto py-2 px-2",
                            "bg-neutral-900/50 hover:bg-neutral-800 border border-white/5",
                            "group transition-all duration-300 relative overflow-hidden"
                        )}
                    >
                        {/* Dynamic Background Hint */}
                        <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--color-intent))]/10 to-transparent opacity-50" />

                        <div className="flex items-center gap-3 overflow-hidden z-10">
                            <div className="w-8 h-8 rounded bg-neutral-950 border border-white/10 flex items-center justify-center shrink-0 group-hover:border-[hsl(var(--color-intent))] transition-colors shadow-sm">
                                <CurrentIcon className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                            </div>
                            <div className="text-left overflow-hidden hidden lg:block">
                                <div className="text-xs font-bold text-neutral-200 truncate flex items-center gap-2">
                                    {domainData.name}
                                    {domainData.status === 'production' && (
                                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                    )}
                                </div>
                                <div className="text-[9px] text-[hsl(var(--color-intent))] font-mono truncate max-w-[120px] opacity-80">
                                    {domainData.intent}
                                </div>
                            </div>
                        </div>
                        <ChevronUp className="w-3 h-3 text-neutral-500 hidden lg:block z-10" />
                    </Button>
                </DropdownMenuTrigger>
                
                <DropdownMenuContent 
                    className="w-72 bg-neutral-950/95 backdrop-blur-xl border-white/10 text-neutral-300 mb-2 ml-2 shadow-2xl" 
                    side="right" 
                    align="end"
                    sideOffset={10}
                >
                    <div className="p-3 bg-neutral-900/50 border-b border-white/5">
                        <div className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest mb-1">Current Lens</div>
                        <div className="flex flex-wrap gap-1">
                            {domainData.categories.map(cat => (
                                <Badge key={cat} variant="outline" className="text-[9px] h-5 bg-neutral-900 border-white/10 text-[hsl(var(--color-intent))]">
                                    {cat}
                                </Badge>
                            ))}
                        </div>
                    </div>

                    <div className="max-h-[400px] overflow-y-auto scrollbar-thin scrollbar-thumb-white/10 p-1">
                        {Object.entries(groupedDomains).map(([family, domains]) => (
                            <div key={family} className="mb-2 last:mb-0">
                                <DropdownMenuLabel className="text-[10px] text-neutral-600 font-mono uppercase tracking-widest px-2 py-1 mt-2">
                                    {family} Network
                                </DropdownMenuLabel>
                                {domains.map((domain) => {
                                    const isActive = currentDomain === domain.key;
                                    const FamilyIcon = getFamilyIcon(domain.family);
                                    
                                    // Determine destination based on domain key
                                    const getDestination = (key) => {
                                        if (key.includes('market')) return createPageUrl('Marketplace');
                                        if (key.includes('crm')) return createPageUrl('CRM');
                                        if (key.includes('finance')) return createPageUrl('Finance');
                                        if (key.includes('content')) return createPageUrl('ContentManager');
                                        return createPageUrl('Dashboard'); // Default
                                    };

                                    const isComingSoon = !isActive && domain.status !== 'production';

                                    return (
                                        <Link 
                                            key={domain.key}
                                            to={getDestination(domain.key)}
                                            onClick={() => rotateContext(domain.key)}
                                        >
                                            <DropdownMenuItem 
                                                className={cn(
                                                    "flex items-start gap-3 cursor-pointer text-xs py-2 px-2 rounded-sm mb-0.5",
                                                    isActive ? "bg-[hsl(var(--color-intent))]/10 text-white" : "hover:bg-white/5 text-neutral-400"
                                                )}
                                            >
                                                <div className={cn(
                                                    "mt-0.5 w-1.5 h-1.5 rounded-full",
                                                    isActive ? "bg-[hsl(var(--color-intent))]" : "bg-neutral-800"
                                                )} />
                                                
                                                <div className="flex-1">
                                                    <div className="flex items-center justify-between">
                                                        <span className={cn("font-medium", isActive && "text-[hsl(var(--color-intent))]")}>
                                                            {domain.name}
                                                        </span>
                                                        {isActive && (
                                                            <span className="text-[8px] uppercase tracking-wider text-emerald-500/80 font-mono">Active</span>
                                                        )}
                                                        {(isComingSoon || domain.badge) && (
                                                            <span className="text-[8px] uppercase tracking-wider text-orange-500/80 font-mono bg-orange-500/10 px-1 rounded">
                                                                {domain.badge || 'Coming Soon - Q1 2026'}
                                                            </span>
                                                        )}
                                                    </div>
                                                    <div className="text-[9px] opacity-60 font-mono mt-0.5 truncate">
                                                        {domain.key} • {isComingSoon ? "Coming Soon" : domain.intent}
                                                    </div>
                                                </div>
                                                
                                                {isActive && <Check className="w-3 h-3 text-[hsl(var(--color-intent))]" />}
                                            </DropdownMenuItem>
                                        </Link>
                                    );
                                })}
                            </div>
                        ))}
                    </div>
                    
                    <DropdownMenuSeparator className="bg-white/5" />
                    <div className="p-2 flex justify-between items-center text-[9px] text-neutral-600 font-mono bg-neutral-900/50">
                        <span>XI-IO UNIFIED BACKEND</span>
                        <span>v2.4.0</span>
                    </div>
                </DropdownMenuContent>
            </DropdownMenu>
        </div>
    );
}