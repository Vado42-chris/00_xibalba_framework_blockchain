{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "widgetId": { "type": "string" },
    "position": {
      "type": "object",
      "properties": {
        "x": { "type": "integer" },
        "y": { "type": "integer" },
        "w": { "type": "integer" },
        "h": { "type": "integer" }
      }
    },
    "settings": { "type": "object" }
  },
  "required": ["widgetId", "position"]
}