{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "status": { "type": "string", "enum": ["success", "error"] },
    "data": { "type": ["object", "array", "null"] },
    "message": { "type": "string" },
    "meta": {
      "type": "object",
      "properties": {
        "page": { "type": "integer" },
        "total": { "type": "integer" }
      }
    }
  },
  "required": ["status"]
}