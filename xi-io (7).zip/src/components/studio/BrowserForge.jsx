import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { MousePointer2, Move, Type, Trash2, Code, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

/**
 * BrowserForge - The "Whiteboard" / "Interactive Browser"
 * 
 * Allows selecting DOM elements, highlighting them, and manipulating them via commands.
 * Acts as a layer on top of the actual page content.
 */
export default function BrowserForge({ children, enabled = true, processing = false, onSelect, onCommand }) {
    const containerRef = useRef(null);
    const [hoveredNode, setHoveredNode] = useState(null);
    const [selectedNode, setSelectedNode] = useState(null);
    const [highlightRect, setHighlightRect] = useState(null);
    const [selectRect, setSelectRect] = useState(null);

    // Track mouse movement for hover effect
    useEffect(() => {
        if (!enabled) return;

        const container = containerRef.current;
        if (!container) return;

        const handleMouseOver = (e) => {
            e.stopPropagation();
            // Don't select the highlight box itself
            if (e.target.id === 'forge-highlight' || e.target.id === 'forge-select') return;
            setHoveredNode(e.target);
        };

        const handleClick = (e) => {
            if (!enabled) return;
            e.preventDefault();
            e.stopPropagation();
            
            if (e.target.id === 'forge-highlight' || e.target.id === 'forge-select') return;
            
            setSelectedNode(e.target);
            if (onSelect) onSelect(e.target);
            
            // Calculate initial rect
            const rect = e.target.getBoundingClientRect();
            const containerRect = container.getBoundingClientRect();
            
            setSelectRect({
                top: rect.top - containerRect.top + container.scrollTop,
                left: rect.left - containerRect.left + container.scrollLeft,
                width: rect.width,
                height: rect.height,
            });
        };

        container.addEventListener('mouseover', handleMouseOver);
        container.addEventListener('click', handleClick);
        
        return () => {
            container.removeEventListener('mouseover', handleMouseOver);
            container.removeEventListener('click', handleClick);
        };
    }, [enabled, onSelect]);

    // Update highlight rect when hovered node changes
    useEffect(() => {
        if (!hoveredNode || !containerRef.current) {
            setHighlightRect(null);
            return;
        }

        const container = containerRef.current;
        const rect = hoveredNode.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();

        setHighlightRect({
            top: rect.top - containerRect.top + container.scrollTop,
            left: rect.left - containerRect.left + container.scrollLeft,
            width: rect.width,
            height: rect.height,
        });

    }, [hoveredNode]);

    // Update select rect when selected node changes (or scrolls)
    useEffect(() => {
        if (!selectedNode || !containerRef.current) return;
        
        const updateRect = () => {
             const container = containerRef.current;
             const rect = selectedNode.getBoundingClientRect();
             const containerRect = container.getBoundingClientRect();
             
             setSelectRect({
                top: rect.top - containerRect.top + container.scrollTop,
                left: rect.left - containerRect.left + container.scrollLeft,
                width: rect.width,
                height: rect.height,
             });
        };

        // Update on scroll/resize
        window.addEventListener('resize', updateRect);
        containerRef.current.addEventListener('scroll', updateRect);
        
        return () => {
            window.removeEventListener('resize', updateRect);
            if (containerRef.current) containerRef.current.removeEventListener('scroll', updateRect);
        };
    }, [selectedNode]);


    // Exposed API for parent to manipulate DOM
    useEffect(() => {
        if (onCommand && selectedNode) {
            // Register a listener or just expose functionality?
            // The parent will call a function. We can attach it to the DOM node for now hackily
            // or better, we pass a "commandContext" up.
        }
    }, [selectedNode, onCommand]);

    return (
        <div className="relative w-full h-full isolate">
            {/* The Content */}
            <div 
                ref={containerRef} 
                className={cn(
                    "w-full h-full overflow-y-auto scrollbar-hide relative",
                    enabled ? "cursor-crosshair" : ""
                )}
            >
                {children}
                
                {/* Highlight Overlay (Hover) */}
                {enabled && highlightRect && (
                    <div 
                        id="forge-highlight"
                        className="absolute border-2 border-blue-400/50 bg-blue-500/10 pointer-events-none z-[9999] transition-all duration-75 rounded-sm"
                        style={{
                            top: highlightRect.top,
                            left: highlightRect.left,
                            width: highlightRect.width,
                            height: highlightRect.height
                        }}
                    />
                )}

                {/* Selection Overlay (Active) */}
                {enabled && selectRect && (
                    <div 
                        id="forge-select"
                        className={cn(
                            "absolute border-2 z-[10000] pointer-events-none transition-all duration-100 flex flex-col items-start justify-start shadow-[0_0_20px_rgba(0,0,0,0.5)]",
                            processing 
                                ? "border-[hsl(var(--color-warning))] animate-[pulse_1s_ease-in-out_infinite]" 
                                : "border-[hsl(var(--color-intent))]"
                        )}
                        style={{
                            top: selectRect.top,
                            left: selectRect.left,
                            width: selectRect.width,
                            height: selectRect.height
                        }}
                    >
                        {/* Context Tag - Smart Positioning */}
                        <div 
                            className={cn(
                                "absolute left-0 text-black text-[10px] font-bold px-2 py-0.5 flex items-center gap-2 whitespace-nowrap z-[10001] shadow-md transition-all duration-200",
                                processing ? "bg-[hsl(var(--color-warning))]" : "bg-[hsl(var(--color-intent))]",
                                selectRect.top < 30 
                                    ? "top-full rounded-b"  // Flip to bottom if near top
                                    : "-top-6 rounded-t"    // Default top
                            )}
                        >
                            {processing ? (
                                <>
                                    <span className="animate-spin">⟳</span>
                                    <span>MUTATING DNA...</span>
                                </>
                            ) : (
                                <>
                                    <span className="font-mono">{selectedNode?.tagName.toLowerCase()}</span>
                                    <span className="opacity-50">|</span>
                                    <span>{Math.round(selectRect.width)}x{Math.round(selectRect.height)}</span>
                                    {selectedNode?.id && <span className="opacity-70">#{selectedNode.id}</span>}
                                </>
                            )}
                        </div>
                        
                        {/* Drag Handles (Visual Only for now) */}
                        <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-white border border-black" />
                        <div className="absolute -top-1 -left-1 w-2 h-2 bg-white border border-black" />
                        <div className="absolute -top-1 -right-1 w-2 h-2 bg-white border border-black" />
                        <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-white border border-black" />
                    </div>
                )}
            </div>
        </div>
    );
}

// Utility to apply classes to the DOM node directly (Preview Mode)
export const applyTailwindToNode = (node, classes) => {
    if (!node) return;
    
    // Simple logic: if class starts with -, remove it. Else add it.
    const classList = classes.split(' ');
    classList.forEach(cls => {
        if (cls.startsWith('-')) {
            node.classList.remove(cls.substring(1));
        } else {
            // Check if it's a replacement (e.g. bg-red-500 replacing bg-blue-500)
            // This is complex for regex, so we'll just append for now and rely on CSS specificity (last wins) 
            // or just add it.
            node.classList.add(cls);
        }
    });
    
    // Add a flash effect
    const originalTransition = node.style.transition;
    node.style.transition = 'all 0.2s ease';
    node.style.transform = 'scale(1.05)';
    setTimeout(() => {
        node.style.transform = 'scale(1)';
        setTimeout(() => {
            node.style.transition = originalTransition;
        }, 200);
    }, 200);
};