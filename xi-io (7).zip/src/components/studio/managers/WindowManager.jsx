import React, { createContext, useContext, useEffect, useState, useRef } from 'react';

const WindowContext = createContext();

export const useWindowManager = () => useContext(WindowContext);

export const WindowManagerProvider = ({ children }) => {
    const [windows, setWindows] = useState({});
    const channelRef = useRef(null);
    const [isMain, setIsMain] = useState(true);

    // Initialize Broadcast Channel for cross-window communication
    useEffect(() => {
        const channel = new BroadcastChannel('xi_window_mesh');
        channelRef.current = channel;

        // Check if we are a satellite
        const params = new URLSearchParams(window.location.search);
        const type = params.get('type');
        if (type) {
            setIsMain(false);
            // Notify main window we are alive
            channel.postMessage({ type: 'SATELLITE_MOUNTED', id: params.get('id'), panelType: type });
        }

        channel.onmessage = (event) => {
            const { type, payload } = event.data;
            
            if (isMain) {
                if (type === 'SATELLITE_CLOSED') {
                    setWindows(prev => {
                        const next = { ...prev };
                        delete next[payload.id];
                        return next;
                    });
                }
            } else {
                // Satellite logic: Receive state updates from Core
                if (type === 'STATE_UPDATE' && payload.targetId === params.get('id')) {
                    // Dispatch custom event for components to listen to
                    window.dispatchEvent(new CustomEvent('satellite-update', { detail: payload.data }));
                }
            }
        };

        const handleUnload = () => {
            if (!isMain) {
                channel.postMessage({ 
                    type: 'SATELLITE_CLOSED', 
                    payload: { id: params.get('id') } 
                });
            }
            channel.close();
        };

        window.addEventListener('beforeunload', handleUnload);
        return () => {
            window.removeEventListener('beforeunload', handleUnload);
            channel.close();
        };
    }, [isMain]);

    const openWindow = (panelType, initialData = {}) => {
        const id = `${panelType}_${Date.now()}`;
        const width = 800;
        const height = 600;
        const left = window.screenX + 50;
        const top = window.screenY + 50;

        const win = window.open(
            `/Satellite?type=${panelType}&id=${id}`, 
            id, 
            `width=${width},height=${height},left=${left},top=${top},menubar=no,toolbar=no,location=no,status=no`
        );

        if (win) {
            setWindows(prev => ({
                ...prev,
                [panelType]: { id, window: win, type: panelType, active: true }
            }));
            
            // Send initial data after a small delay to ensure load
            setTimeout(() => {
                sendToWindow(id, initialData);
            }, 1000);
        }
    };

    const closeWindow = (panelType) => {
        const winData = windows[panelType];
        if (winData && winData.window) {
            winData.window.close();
        }
    };

    const sendToWindow = (targetId, data) => {
        if (channelRef.current) {
            channelRef.current.postMessage({
                type: 'STATE_UPDATE',
                payload: { targetId, data }
            });
        }
    };

    const isPoppedOut = (panelType) => !!windows[panelType];

    return (
        <WindowContext.Provider value={{ 
            openWindow, 
            closeWindow, 
            isPoppedOut, 
            sendToWindow,
            isMain 
        }}>
            {children}
        </WindowContext.Provider>
    );
};