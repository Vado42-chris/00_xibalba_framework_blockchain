import React, { useState } from 'react';
import { cn } from "@/lib/utils";
import { MoreHorizontal, Copy, Trash2, ArrowUp, ArrowDown, Move, Sparkles, Wand2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

/**
 * THE GOLDEN RULE COMPONENT WRAPPER
 * 
 * Enforces:
 * 1. Universal Selectable State (Hover/Selected rings)
 * 2. Universal Context Menu (Duplicate, Delete, Layers)
 * 3. Consistent Visuals (Border radius, Shadows)
 */
export default function UnifiedItemWrapper({
    item,
    isSelected,
    isDragging,
    children,
    onSelect,
    onDuplicate,
    onDelete,
    onMoveLayer,
    onAiEdit
}) {
    const [aiPrompt, setAiPrompt] = useState("");
    const [isAiOpen, setIsAiOpen] = useState(false);

    const handleAiSubmit = (e) => {
        e.preventDefault();
        if (aiPrompt.trim() && onAiEdit) {
            onAiEdit(item, aiPrompt);
            setAiPrompt("");
            setIsAiOpen(false);
        }
    };

    return (
        <div 
            className={cn(
                "group relative transition-all duration-200 rounded-lg",
                // Visual System: Spacing & Radius
                "p-0", 
                // Universal Selectable State
                isSelected 
                    ? "ring-2 ring-[hsl(var(--color-intent))] z-10 shadow-lg bg-neutral-900/50" 
                    : "hover:ring-1 hover:ring-white/20 hover:bg-white/5",
                // Dragging State
                isDragging && "shadow-2xl scale-[1.02] opacity-90 ring-2 ring-[hsl(var(--color-execution))]"
            )}
            onClick={(e) => {
                e.stopPropagation();
                if (onSelect) onSelect(item);
            }}
        >
            {/* Universal Context Menu & Tools - Visible on Selection or Hover */}
            <div className={cn(
                "absolute -top-3 right-2 flex items-center gap-1 transition-opacity duration-200 z-50",
                isSelected || isDragging ? "opacity-100" : "opacity-0 group-hover:opacity-100"
            )}>
                {/* Visual Label */}
                <div className="px-2 py-0.5 bg-[hsl(var(--color-intent))] text-black text-[9px] font-bold rounded-full uppercase tracking-wider shadow-sm">
                    {item.label || item.type}
                </div>

                {/* AI Magic Edit - The Spark */}
                <Popover open={isAiOpen} onOpenChange={setIsAiOpen}>
                    <PopoverTrigger asChild>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 rounded-full bg-[hsl(var(--color-intent))] text-black border border-transparent hover:bg-[hsl(var(--color-intent))]/90 shadow-[0_0_10px_-2px_hsl(var(--color-intent))]"
                            title="AI Edit"
                        >
                            <Sparkles className="w-3 h-3" />
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent side="top" align="center" className="w-64 p-2 bg-neutral-900/90 backdrop-blur-xl border border-[hsl(var(--color-intent))]/30">
                        <form onSubmit={handleAiSubmit} className="flex gap-2">
                            <Input 
                                autoFocus
                                value={aiPrompt}
                                onChange={(e) => setAiPrompt(e.target.value)}
                                placeholder="Make it darker..." 
                                className="h-7 text-xs bg-black/50 border-white/10 focus-visible:ring-[hsl(var(--color-intent))]"
                            />
                            <Button type="submit" size="icon" className="h-7 w-7 bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/80">
                                <Wand2 className="w-3 h-3" />
                            </Button>
                        </form>
                    </PopoverContent>
                </Popover>

                {/* Context Menu */}
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 rounded-full bg-neutral-800 border border-white/10 hover:bg-white/10 hover:text-white text-neutral-400 shadow-sm"
                        >
                            <MoreHorizontal className="w-3 h-3" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-neutral-900 border border-white/10">
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onMoveLayer(item, 'up'); }}>
                            <ArrowUp className="w-3 h-3 mr-2" /> Bring Forward
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onMoveLayer(item, 'down'); }}>
                            <ArrowDown className="w-3 h-3 mr-2" /> Send Backward
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDuplicate(item); }}>
                            <Copy className="w-3 h-3 mr-2" /> Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                            onClick={(e) => { e.stopPropagation(); onDelete(item); }}
                            className="text-red-400 focus:text-red-400 focus:bg-red-400/10"
                        >
                            <Trash2 className="w-3 h-3 mr-2" /> Delete
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </div>

            {/* Content Container with Standardized overflow/clipping if needed */}
            <div className="relative w-full h-full rounded-[inherit] overflow-hidden">
                {children}
            </div>

            {/* Resize Handles (Visual Only for now) - Only when selected */}
            {isSelected && !isDragging && (
                <>
                    <div className="absolute -top-1 -left-1 w-2 h-2 bg-[hsl(var(--color-intent))] rounded-full border border-black shadow-sm" />
                    <div className="absolute -top-1 -right-1 w-2 h-2 bg-[hsl(var(--color-intent))] rounded-full border border-black shadow-sm" />
                    <div className="absolute -bottom-1 -left-1 w-2 h-2 bg-[hsl(var(--color-intent))] rounded-full border border-black shadow-sm" />
                    <div className="absolute -bottom-1 -right-1 w-2 h-2 bg-[hsl(var(--color-intent))] rounded-full border border-black shadow-sm" />
                </>
            )}
        </div>
    );
}