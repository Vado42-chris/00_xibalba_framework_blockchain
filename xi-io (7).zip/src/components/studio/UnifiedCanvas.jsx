import React, { useState, useEffect } from 'react';
import { Droppable, Draggable } from '@hello-pangea/dnd';
import { cn } from "@/lib/utils";
import { Grid, Monitor, Tablet, Smartphone, GripVertical, Plus, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import UnifiedItemWrapper from './UnifiedItemWrapper';
import { InteractionManager } from '@/components/interaction/InteractionManager';
import SandboxedRenderer from '@/components/content/SandboxedRenderer';

export default function UnifiedCanvas({ 
    items = [], 
    onItemsChange, 
    renderItem, 
    selectedId, 
    onSelect,
    scale = 1,
    viewportWidth = '100%',
    activeTool = 'select', // select, image, component, etc.
    onToolReset, // callback to reset tool to select after use
    highlightedRule
}) {
    const [drawStart, setDrawStart] = useState(null);
    const [drawRect, setDrawRect] = useState(null);
    const [connections, setConnections] = useState([]); // Array of SVG lines to draw
    const containerRef = React.useRef(null);
    const [showPromptInput, setShowPromptInput] = useState(false);
    const [genPrompt, setGenPrompt] = useState("");
    const [isGenerating, setIsGenerating] = useState(false);

    // Drawing Handlers
    const handleMouseDown = (e) => {
        if (activeTool === 'select') return;
        const rect = e.currentTarget.getBoundingClientRect();
        // Adjust for scale
        const x = (e.clientX - rect.left) / scale;
        const y = (e.clientY - rect.top) / scale;
        setDrawStart({ x, y });
        setDrawRect({ x, y, width: 0, height: 0 });
    };

    const handleMouseMove = (e) => {
        if (activeTool === 'select' || !drawStart) return;
        const rect = e.currentTarget.getBoundingClientRect();
        const currentX = (e.clientX - rect.left) / scale;
        const currentY = (e.clientY - rect.top) / scale;
        
        setDrawRect({
            x: Math.min(drawStart.x, currentX),
            y: Math.min(drawStart.y, currentY),
            width: Math.abs(currentX - drawStart.x),
            height: Math.abs(currentY - drawStart.y)
        });
    };

    const handleMouseUp = () => {
        if (activeTool === 'select' || !drawStart) return;
        setDrawStart(null);
        if (drawRect && drawRect.width > 20 && drawRect.height > 20) {
            setShowPromptInput(true);
        } else {
            setDrawRect(null);
        }
    };

    const handleGenerate = async () => {
        if (!genPrompt.trim()) return;
        
        const tempId = `gen-${Date.now()}`;
        setIsGenerating(true);
        
        // 1. Intelligent Placement (Find insertion index)
        let insertIndex = items.length;
        if (containerRef.current) {
            const children = Array.from(containerRef.current.children).filter(c => c.dataset.rbdDraggableId);
            for (let i = 0; i < children.length; i++) {
                const child = children[i];
                const centerY = child.offsetTop + child.offsetHeight / 2;
                if (drawRect.y < centerY) {
                    insertIndex = i;
                    break;
                }
            }
        }

        // Context Awareness
        const surroundingItems = items.slice(Math.max(0, insertIndex - 2), Math.min(items.length, insertIndex + 2));
        const contextDesc = surroundingItems.map(i => i.label || i.type).join(', ');

        // 2. Add Placeholder Item (Enhanced Preview)
        const tempItem = {
            id: tempId,
            type: 'generating',
            label: `Generating ${activeTool}...`,
            height: drawRect.height, // Keep dimension
            width: drawRect.width
        };

        const itemsWithTemp = [...items];
        itemsWithTemp.splice(insertIndex, 0, tempItem);
        onItemsChange(itemsWithTemp);

        setDrawRect(null);
        setShowPromptInput(false);
        setGenPrompt("");

        try {
            // 3. Perform Generation with Context
            let finalItem = {
                ...tempItem,
                type: activeTool,
                data: {},
                label: `AI ${activeTool.charAt(0).toUpperCase() + activeTool.slice(1)}`
            };

            if (activeTool === 'image') {
                const { url } = await base44.integrations.Core.GenerateImage({ prompt: genPrompt });
                finalItem.data = { url };
                finalItem.html = `<div style="width: 100%; height: ${drawRect.height}px; background-image: url('${url}'); background-size: cover; background-position: center; border-radius: 8px;"></div>`;
            } else if (['component', 'text', 'wireframe'].includes(activeTool)) {
                const prompt = `Generate HTML for a ${activeTool} based on: "${genPrompt}".
                Context: This component will be placed among: [${contextDesc}]. Ensure visual consistency.
                Dimensions: ${Math.round(drawRect.width)}x${Math.round(drawRect.height)}px.
                Style: Use Tailwind CSS. No html/body tags.`;
                
                const html = await base44.integrations.Core.InvokeLLM({ prompt });
                finalItem.html = `<div style="width: 100%; min-height: ${drawRect.height}px;">${html}</div>`;
                finalItem.data = { html };
            }

            const finalItems = itemsWithTemp.map(i => i.id === tempId ? finalItem : i);
            onItemsChange(finalItems);
            
            if (onSelect) onSelect(finalItem);
            if (onToolReset) onToolReset();
            toast.success("Generated successfully");

        } catch (error) {
            toast.error("Generation failed: " + error.message);
            const revertedItems = itemsWithTemp.filter(i => i.id !== tempId);
            onItemsChange(revertedItems);
        } finally {
            setIsGenerating(false);
        }
    };

    // AI Edit Handler
    const handleAiEdit = async (item, prompt) => {
        const toastId = toast.loading("AI is refining this component...");
        try {
            const editPrompt = `
                You are an expert UI editor. Update the following component based on the user's request: "${prompt}".
                Current HTML: ${item.html || item.content || ''}
                Output ONLY the updated HTML. Use Tailwind CSS.
            `;
            
            const newHtml = await base44.integrations.Core.InvokeLLM({ prompt: editPrompt });
            
            const updatedItem = {
                ...item,
                html: newHtml,
                data: { ...item.data, html: newHtml }
            };

            const newItems = items.map(i => (i.id || i.uniqueId) === (item.id || item.uniqueId) ? updatedItem : i);
            onItemsChange(newItems);
            toast.success("Component updated", { id: toastId });
        } catch (error) {
            toast.error("Edit failed: " + error.message, { id: toastId });
        }
    };

    // Aggregate rules for preview
    const allRules = items.flatMap(i => i.interactions || []);

    // Calculate connections for visual feedback
    useEffect(() => {
        if (!highlightedRule || !containerRef.current) {
            setConnections([]);
            return;
        }

        const calculateLines = () => {
            const lines = [];
            const triggerId = highlightedRule.triggerId;
            const targetId = highlightedRule.targetId;

            // Find DOM elements
            // We use data-rbd-draggable-id which is set by Hello Pangea DND
            const triggerEl = containerRef.current.querySelector(`[data-rbd-draggable-id='${triggerId}']`);
            const targetEl = containerRef.current.querySelector(`[data-rbd-draggable-id='${targetId}']`);

            if (triggerEl && targetEl) {
                // Get positions relative to container
                const containerRect = containerRef.current.getBoundingClientRect();
                const triggerRect = triggerEl.getBoundingClientRect();
                const targetRect = targetEl.getBoundingClientRect();

                // Calculate center points relative to container
                const startX = triggerRect.left - containerRect.left + triggerRect.width / 2;
                const startY = triggerRect.top - containerRect.top + triggerRect.height / 2;
                const endX = targetRect.left - containerRect.left + targetRect.width / 2;
                const endY = targetRect.top - containerRect.top + targetRect.height / 2;

                lines.push({ startX, startY, endX, endY });
            }
            setConnections(lines);
        };

        // Run immediately and on resize
        calculateLines();
        // window.addEventListener('resize', calculateLines); // Optional for better responsiveness
        // return () => window.removeEventListener('resize', calculateLines);
        
        // Small timeout to allow DOM to settle if just reordered
        const timer = setTimeout(calculateLines, 100);
        return () => clearTimeout(timer);

    }, [highlightedRule, items, scale]); // Recalculate when rule, items or scale changes

    // --- Component Philosophy Actions ---
    const handleDuplicate = (item) => {
        const newItem = {
            ...item,
            id: `${item.id || item.uniqueId}-copy-${Date.now()}`,
            label: `${item.label} (Copy)`
        };
        // Insert after original
        const index = items.findIndex(i => (i.id || i.uniqueId) === (item.id || item.uniqueId));
        const newItems = [...items];
        newItems.splice(index + 1, 0, newItem);
        onItemsChange(newItems);
        toast.success("Duplicated component");
    };

    const handleDelete = (item) => {
        const newItems = items.filter(i => (i.id || i.uniqueId) !== (item.id || item.uniqueId));
        onItemsChange(newItems);
        if ((item.id || item.uniqueId) === selectedId) {
            if (onSelect) onSelect(null);
        }
        toast.success("Deleted component");
    };

    const handleMoveLayer = (item, direction) => {
        const index = items.findIndex(i => (i.id || i.uniqueId) === (item.id || item.uniqueId));
        if (index < 0) return;
        
        const newItems = [...items];
        if (direction === 'up' && index > 0) {
            // Swap with previous (visually higher in list = rendered earlier? No, usually later is top. 
            // If dragging list, index 0 is top. Let's assume standard DOM order: last is top z-index.
            // Wait, visual list usually implies top-to-bottom flow. 
            // "Bring Forward" in a vertical stack usually means "move down the list" if it's a flow, 
            // or "move to end of array" if it's absolute positioning.
            // Since this looks like a stack builder (PageBuilder), moving "up" visually means moving to lower index.
            // "Bring Forward" usually means Z-index. 
            // Let's stick to list order: "Up" = Move to index - 1. "Down" = Move to index + 1.
            // Context menu says "Bring Forward" (Z-index) vs "Move Up" (List position).
            // Let's interpret "Bring Forward" as "Swap with next item" (render later -> higher z).
            // Actually, in a vertical stack, "Up" is index-1. 
            // I'll swap logic to match typical list reordering.
            
            // "Bring Forward" / "Send Backward" usually implies Z-order.
            // But this is a vertical flow list mostly. 
            // I'll map "Bring Forward" to "Move Up in List" (index - 1) for now, as that's more intuitive for document flow.
            
            [newItems[index], newItems[index - 1]] = [newItems[index - 1], newItems[index]];
        } else if (direction === 'down' && index < items.length - 1) {
            [newItems[index], newItems[index + 1]] = [newItems[index + 1], newItems[index]];
        } else {
            return;
        }
        onItemsChange(newItems);
    };

    return (
        <div 
            className="flex-1 h-full relative overflow-y-auto bg-neutral-950/50 transition-all select-none"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
        >
            <div 
                className={cn(
                    "min-h-full mx-auto relative transition-all duration-300 shadow-2xl",
                    activeTool !== 'select' && "cursor-crosshair"
                )}
                style={{
                    width: viewportWidth,
                    transform: `scale(${scale})`,
                    transformOrigin: 'top center',
                    padding: '2rem'
                }}
            >
                {/* Grid Background */}
                <div 
                    className="absolute inset-0 pointer-events-none opacity-[0.03]"
                    style={{ 
                        backgroundImage: 'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
                        backgroundSize: '20px 20px'
                    }}
                />

                {/* Breakpoint Guides (Overlay) - Only show if 100% width */}
                {viewportWidth === '100%' && (
                    <div className="absolute inset-0 pointer-events-none flex justify-center opacity-0 hover:opacity-100 transition-opacity duration-500 z-0">
                        <div className="h-full w-[375px] border-x border-dashed border-blue-500/20 relative">
                            <div className="absolute top-2 left-2 text-[9px] text-blue-500/50 flex items-center gap-1"><Smartphone className="w-3 h-3" /> Mobile</div>
                        </div>
                        <div className="absolute h-full w-[768px] border-x border-dashed border-purple-500/20 pointer-events-none">
                                <div className="absolute top-2 left-2 text-[9px] text-purple-500/50 flex items-center gap-1"><Tablet className="w-3 h-3" /> Tablet</div>
                        </div>
                        <div className="absolute h-full w-[1024px] border-x border-dashed border-green-500/20 pointer-events-none">
                                <div className="absolute top-2 left-2 text-[9px] text-green-500/50 flex items-center gap-1"><Monitor className="w-3 h-3" /> Desktop</div>
                        </div>
                    </div>
                )}

                {/* Drawing Overlay (Smoother Visuals) */}
                {drawRect && (
                    <div 
                        className="absolute z-50 pointer-events-none transition-all duration-75 ease-out"
                        style={{
                            left: drawRect.x,
                            top: drawRect.y,
                            width: drawRect.width,
                            height: drawRect.height
                        }}
                    >
                        {/* Fluid Drawing Box */}
                        <div className="w-full h-full border-2 border-[hsl(var(--color-intent))] bg-[hsl(var(--color-intent))]/5 rounded-lg backdrop-blur-[1px] shadow-[0_0_15px_rgba(0,255,255,0.1)] animate-in fade-in duration-150">
                            {/* Corner Accents */}
                            <div className="absolute -top-1 -left-1 w-2 h-2 border-t-2 border-l-2 border-[hsl(var(--color-intent))]" />
                            <div className="absolute -bottom-1 -right-1 w-2 h-2 border-b-2 border-r-2 border-[hsl(var(--color-intent))]" />
                            
                            {/* Dimensions Label */}
                            <div className="absolute bottom-full left-0 mb-1 px-1.5 py-0.5 bg-[hsl(var(--color-intent))] text-black text-[9px] font-mono font-bold rounded-sm">
                                {Math.round(drawRect.width)} × {Math.round(drawRect.height)}
                            </div>
                        </div>

                        {/* Prompt Input */}
                        <div className="absolute top-full left-0 mt-2 bg-neutral-900/90 backdrop-blur-xl border border-white/10 p-3 rounded-xl shadow-2xl pointer-events-auto min-w-[240px] animate-in slide-in-from-top-2 duration-200">
                            {showPromptInput && (
                                <div className="flex flex-col gap-2">
                                    <div className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">
                                        GENERATE {activeTool.toUpperCase()}
                                    </div>
                                    <input 
                                        autoFocus
                                        placeholder={`Describe ${activeTool}...`}
                                        className="w-full bg-black border border-white/20 rounded px-2 py-1 text-xs text-white focus:outline-none focus:border-[hsl(var(--color-intent))]"
                                        value={genPrompt}
                                        onChange={e => setGenPrompt(e.target.value)}
                                        onKeyDown={e => e.key === 'Enter' && handleGenerate()}
                                    />
                                    <div className="flex justify-end gap-2">
                                        <button onClick={() => { setDrawRect(null); setShowPromptInput(false); if(onToolReset) onToolReset(); }} className="text-[10px] text-neutral-400 hover:text-white">Cancel</button>
                                        <button 
                                            onClick={handleGenerate} 
                                            disabled={isGenerating}
                                            className="px-2 py-1 bg-[hsl(var(--color-execution))] text-black text-[10px] rounded hover:bg-opacity-90 flex items-center gap-1"
                                        >
                                            {isGenerating && <Loader2 className="w-3 h-3 animate-spin" />}
                                            Generate
                                        </button>
                                    </div>
                                </div>
                            )}
                            {!showPromptInput && !isGenerating && (
                                <span className="text-[10px] text-white">Release to Create</span>
                            )}
                        </div>
                    </div>
                )}

                {/* Droppable Area */}
                <Droppable droppableId="canvas">
                    {(provided, snapshot) => (
                        <div 
                            ref={(el) => {
                                provided.innerRef(el);
                                containerRef.current = el;
                            }}
                            {...provided.droppableProps}
                            className={cn(
                                "relative z-10 min-h-full space-y-4 max-w-4xl mx-auto pb-32",
                                snapshot.isDraggingOver && "bg-[hsl(var(--color-execution))]/5 ring-1 ring-inset ring-[hsl(var(--color-execution))]/20 rounded-lg"
                            )}
                        >
                            {/* Logic Connection Overlay */}
                            <svg className="absolute inset-0 w-full h-full pointer-events-none z-0 overflow-visible">
                                <defs>
                                    <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                                        <polygon points="0 0, 10 3.5, 0 7" fill="hsl(var(--color-execution))" />
                                    </marker>
                                </defs>
                                {connections.map((line, i) => (
                                    <g key={i}>
                                        <path 
                                            d={`M${line.startX},${line.startY} C${line.startX + 50},${line.startY} ${line.endX - 50},${line.endY} ${line.endX},${line.endY}`}
                                            fill="none"
                                            stroke="hsl(var(--color-execution))"
                                            strokeWidth="2"
                                            strokeDasharray="5,5"
                                            markerEnd="url(#arrowhead)"
                                            className="animate-pulse"
                                        />
                                        <circle cx={line.startX} cy={line.startY} r="4" fill="hsl(var(--color-execution))" />
                                        <circle cx={line.endX} cy={line.endY} r="4" fill="hsl(var(--color-execution))" />
                                    </g>
                                ))}
                            </svg>

                            {items.length === 0 && !drawRect && (
                                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                    <div className="text-center space-y-4 opacity-20">
                                        <div className="w-20 h-20 border-2 border-dashed border-white rounded-2xl mx-auto flex items-center justify-center">
                                            <Plus className="w-10 h-10 text-white" />
                                        </div>
                                        <p className="text-sm text-white font-mono uppercase tracking-widest">
                                            Drag Components<br/>or Draw to Generate
                                        </p>
                                    </div>
                                </div>
                            )}
                            
                            {items.map((item, index) => {
                                if (item.type === 'generating') {
                                    return (
                                        <div key={item.id} className="relative rounded-lg overflow-hidden border border-[hsl(var(--color-intent))]/30 bg-[hsl(var(--color-intent))]/5" style={{ height: item.height }}>
                                            {/* AI Constructing Animation */}
                                            <div className="absolute inset-0 flex flex-col items-center justify-center">
                                                <Loader2 className="w-6 h-6 text-[hsl(var(--color-intent))] animate-spin mb-2" />
                                                <span className="text-[10px] font-mono text-[hsl(var(--color-intent))] animate-pulse tracking-widest uppercase">
                                                    Constructing {activeTool}...
                                                </span>
                                            </div>
                                            {/* Scanning Line Effect */}
                                            <div className="absolute inset-0 bg-[linear-gradient(transparent_0%,hsl(var(--color-intent))/10_50%,transparent_100%)] bg-[length:100%_200%] animate-[scan_2s_ease-in-out_infinite]" />
                                            {/* Wireframe Grid */}
                                            <div 
                                                className="absolute inset-0 opacity-20 pointer-events-none" 
                                                style={{ backgroundImage: 'linear-gradient(to right, hsl(var(--color-intent)) 1px, transparent 1px), linear-gradient(to bottom, hsl(var(--color-intent)) 1px, transparent 1px)', backgroundSize: '20px 20px' }} 
                                            />
                                        </div>
                                    );
                                }

                                return (
                                    <Draggable key={item.id || item.uniqueId} draggableId={item.id || item.uniqueId} index={index}>
                                        {(provided, snapshot) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps} 
                                                className="outline-none" 
                                            >
                                                <UnifiedItemWrapper
                                                    item={item}
                                                    isSelected={selectedId === (item.id || item.uniqueId)}
                                                    isDragging={snapshot.isDragging}
                                                    onSelect={(itm) => {
                                                        // Ensure we select the item when clicked, even if not dragging
                                                        if (onSelect) onSelect(itm);
                                                    }}
                                                    onDuplicate={handleDuplicate}
                                                    onDelete={handleDelete}
                                                    onMoveLayer={handleMoveLayer}
                                                    onAiEdit={handleAiEdit}
                                                    className={cn(
                                                        "transition-all duration-200",
                                                        selectedId === (item.id || item.uniqueId) 
                                                            ? "ring-2 ring-[hsl(var(--color-intent))] ring-offset-2 ring-offset-black z-20 shadow-xl" 
                                                            : "hover:ring-1 hover:ring-white/20"
                                                    )}
                                                    >
                                                    
                                                    {/* Professional Selection Overlay */}
                                                    {selectedId === (item.id || item.uniqueId) && (
                                                        <>
                                                            <div className="absolute -inset-[2px] border-2 border-[hsl(var(--color-execution))] pointer-events-none z-50 rounded-[inherit]">
                                                                {/* Resize Handles - Corners */}
                                                                <div className="absolute -top-1.5 -left-1.5 w-2.5 h-2.5 bg-white border border-[hsl(var(--color-execution))] shadow-sm" />
                                                                <div className="absolute -top-1.5 -right-1.5 w-2.5 h-2.5 bg-white border border-[hsl(var(--color-execution))] shadow-sm" />
                                                                <div className="absolute -bottom-1.5 -left-1.5 w-2.5 h-2.5 bg-white border border-[hsl(var(--color-execution))] shadow-sm" />
                                                                <div className="absolute -bottom-1.5 -right-1.5 w-2.5 h-2.5 bg-white border border-[hsl(var(--color-execution))] shadow-sm" />
                                                                
                                                                {/* Quick Actions Overlay (Appears on Hover of Selected) */}
                                                                <div className="absolute -top-10 left-0 flex gap-1 bg-neutral-900/90 backdrop-blur border border-white/10 rounded-md p-1 shadow-xl pointer-events-auto opacity-0 group-hover:opacity-100 transition-opacity delay-75">
                                                                    <button className="p-1 hover:bg-white/10 rounded text-neutral-400 hover:text-white" title="Ungroup" onClick={(e) => { e.stopPropagation(); handleUngroup(); }}><Box className="w-3 h-3" /></button>
                                                                    <div className="w-px h-3 bg-white/10 my-auto" />
                                                                    <button className="p-1 hover:bg-white/10 rounded text-neutral-400 hover:text-white"><Lock className="w-3 h-3" /></button>
                                                                    <button className="p-1 hover:bg-white/10 rounded text-neutral-400 hover:text-white" onClick={(e) => { e.stopPropagation(); handleDuplicate(item); }}><Copy className="w-3 h-3" /></button>
                                                                </div>
                                                            </div>
                                                        </>
                                                    )}
                                                    {/* Render Item Content */}
                                                    {renderItem ? renderItem(item) : (
                                                        <div className="bg-neutral-900/50 border border-white/5 rounded-[inherit] overflow-hidden min-h-[50px]">
                                                            {item.type === 'web' || item.html ? (
                                                                <SandboxedRenderer 
                                                                    id={item.id || item.uniqueId}
                                                                    html={item.html || item.content} 
                                                                    className="min-h-[50px]"
                                                                />
                                                            ) : (
                                                                <div className="p-4 text-neutral-600 font-mono text-xs" dangerouslySetInnerHTML={{ __html: item.content || 'Empty Block' }} />
                                                            )}
                                                        </div>
                                                    )}
                                                </UnifiedItemWrapper>
                                            </div>
                                        )}
                                    </Draggable>
                                );
                            })}
                            {provided.placeholder}
                        </div>
                    )}
                </Droppable>
            </div>
        </div>
    );
}