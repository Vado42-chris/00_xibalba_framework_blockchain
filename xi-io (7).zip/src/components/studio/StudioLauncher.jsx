import React from 'react';
import { Package, ArrowRight } from 'lucide-react';
import { Button } from "@/components/ui/button";
import ProductIcon, { PRODUCT_CONFIG } from '@/components/brand/ProductIcon';

import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu";
import { ExternalLink, Maximize2 } from 'lucide-react';

export default function StudioLauncher({ onLaunch, onLaunchWindow, onOpenProject }) {
    const apps = Object.keys(PRODUCT_CONFIG).map(key => ({
        id: key,
        ...PRODUCT_CONFIG[key],
        desc: getAppDesc(key)
    }));

    function getAppDesc(key) {
        const descs = {
            web: 'Full-stack React builder',
            mobile: 'Mobile App Builder',
            document: 'Word Processing',
            sheet: 'Spreadsheets',
            layout: 'Desktop Publishing',
            sound: 'Sound Editing',
            video: 'Video Editing',
            '3d': '3D Modeling',
            cad: 'Technical Drawings',
            vector: 'Illustration',
            store: 'E-commerce',
            blog: 'CMS & Publishing',
            browser: 'Custom Browsers',
            database: 'Database & Schemas',
            mail: 'Email Client & Campaigns',
            architect: 'AI-Native IDE'
        };
        return descs[key] || 'Application Suite';
    }

    return (
        <div className="w-full h-full bg-[#0a0a0a] flex p-0 relative overflow-hidden font-sans text-neutral-200">
            {/* Sidebar */}
            <div className="w-64 border-r border-white/5 bg-neutral-950 flex flex-col z-20">
                <div className="h-16 flex items-center px-6 border-b border-white/5">
                     <span className="font-bold tracking-tight">STUDIO HUB</span>
                </div>
                <div className="p-4 space-y-2">
                     <div className="px-3 py-2 bg-white/5 rounded-lg text-sm font-medium text-white cursor-pointer">Home</div>
                     <div className="px-3 py-2 hover:bg-white/5 rounded-lg text-sm font-medium text-neutral-400 cursor-pointer">Your Projects</div>
                     <div className="px-3 py-2 hover:bg-white/5 rounded-lg text-sm font-medium text-neutral-400 cursor-pointer">Shared with You</div>
                     <div className="px-3 py-2 hover:bg-white/5 rounded-lg text-sm font-medium text-neutral-400 cursor-pointer">Deleted</div>
                </div>
                <div className="mt-auto p-4 border-t border-white/5">
                    <div className="text-xs text-neutral-500 font-mono">STORAGE: 45% USED</div>
                    <div className="h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
                        <div className="h-full w-[45%] bg-[hsl(var(--color-intent))]" />
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 flex flex-col overflow-y-auto bg-[#0a0a0a] relative">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(50,50,50,0.15)_0,transparent_50%)] pointer-events-none" />

                {/* Hero / Recent */}
                <div className="p-8 pb-0">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-2xl font-light">Good Morning, Creator.</h2>
                        <Button variant="outline" className="border-white/10 gap-2" onClick={() => onOpenProject && onOpenProject({name: 'New Project'})}>
                             <Package className="w-4 h-4" /> Open Project
                        </Button>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-12">
                        {[1, 2, 3, 4].map(i => (
                            <div key={i} className="aspect-video bg-neutral-900 border border-white/5 rounded-lg p-4 flex flex-col justify-end hover:border-white/20 transition-colors cursor-pointer group">
                                <div className="text-sm font-medium text-white group-hover:text-[hsl(var(--color-intent))] transition-colors">Untitled Project {i}</div>
                                <div className="text-xs text-neutral-500">Last edited 2h ago</div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Apps Grid */}
                <div className="p-8 pt-0">
                    <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-widest mb-6">Installed Suites</h3>
                    <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                        {apps.filter(app => !['chat', 'agents'].includes(app.id)).map(app => (
                            <ContextMenu key={app.id}>
                                <ContextMenuTrigger>
                                    <div 
                                        className="group relative bg-neutral-900/30 border border-white/5 rounded-xl p-4 hover:bg-neutral-900 hover:border-white/10 transition-all duration-200 cursor-pointer flex items-center gap-4"
                                        onClick={() => onLaunch(app.id)}
                                    >
                                        <div className="group-hover:scale-105 transition-transform">
                                            <ProductIcon id={app.id} size="md" />
                                        </div>
                                        <div>
                                            <h3 className="font-bold text-white group-hover:text-[hsl(var(--color-intent))] transition-colors">
                                                {app.name}
                                            </h3>
                                            <p className="text-xs text-neutral-500">{app.desc}</p>
                                        </div>
                                        
                                        {/* Hover Action to Pop Out */}
                                        <div 
                                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 hover:bg-white/10 rounded-md text-neutral-400 hover:text-white"
                                            onClick={(e) => { e.stopPropagation(); onLaunchWindow && onLaunchWindow(app.id); }}
                                            title="Launch in Desktop Window"
                                        >
                                            <ExternalLink className="w-3.5 h-3.5" />
                                        </div>
                                    </div>
                                </ContextMenuTrigger>
                                <ContextMenuContent className="bg-[#18181b] border-[#27272a] text-neutral-200">
                                    <ContextMenuItem onClick={() => onLaunch(app.id)} className="text-xs focus:bg-[#27272a] focus:text-white cursor-pointer">
                                        <Maximize2 className="w-3.5 h-3.5 mr-2" /> Open in Workspace
                                    </ContextMenuItem>
                                    <ContextMenuItem onClick={() => onLaunchWindow && onLaunchWindow(app.id)} className="text-xs focus:bg-[#27272a] focus:text-white cursor-pointer">
                                        <ExternalLink className="w-3.5 h-3.5 mr-2" /> Launch Desktop Window
                                    </ContextMenuItem>
                                </ContextMenuContent>
                            </ContextMenu>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}