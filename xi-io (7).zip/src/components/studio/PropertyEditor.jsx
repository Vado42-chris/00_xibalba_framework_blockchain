import React, { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Type, Layout, Palette, Code, Trash2, AlignLeft, AlignCenter, AlignRight, Maximize, Globe, Box, Layers } from 'lucide-react';
import { cn } from "@/lib/utils";

export default function PropertyEditor({ item, onUpdate, onDelete, globalTheme = {}, onUpdateGlobal }) {
    const [mode, setMode] = useState('item'); // 'item' or 'global'

    if (!item && mode === 'item') {
        return (
            <div className="h-full flex flex-col items-center justify-center text-neutral-500 p-6 text-center bg-neutral-900 border-l border-white/5">
                <Layout className="w-12 h-12 mb-4 opacity-20" />
                <p className="text-xs uppercase tracking-widest font-bold mb-4">No Selection</p>
                <Button variant="outline" size="sm" onClick={() => setMode('global')} className="text-xs gap-2">
                    <Globe className="w-3 h-3" /> Edit Global Theme
                </Button>
            </div>
        );
    }

    const handleChange = (field, value) => {
        onUpdate(item.uniqueId, { [field]: value });
    };

    const addClass = (cls) => {
        const current = item.className || '';
        if (!current.includes(cls)) {
            handleChange('className', `${current} ${cls}`.trim());
        }
    };

    return (
        <div className="h-full flex flex-col bg-neutral-900 border-l border-white/10 w-80 shrink-0 animate-in slide-in-from-right-10 duration-200">
            {/* Mode Switcher */}
            <div className="h-10 grid grid-cols-2 border-b border-white/10 text-[10px] font-bold tracking-widest uppercase">
                <button 
                    onClick={() => setMode('item')}
                    className={cn(
                        "flex items-center justify-center gap-2 transition-colors",
                        mode === 'item' ? "bg-white/5 text-white border-b-2 border-[hsl(var(--color-execution))]" : "text-neutral-500 hover:text-white"
                    )}
                >
                    <Box className="w-3 h-3" /> Item
                </button>
                <button 
                    onClick={() => setMode('global')}
                    className={cn(
                        "flex items-center justify-center gap-2 transition-colors",
                        mode === 'global' ? "bg-white/5 text-white border-b-2 border-[hsl(var(--color-execution))]" : "text-neutral-500 hover:text-white"
                    )}
                >
                    <Globe className="w-3 h-3" /> Global
                </button>
            </div>

            {mode === 'global' ? (
                <div className="flex-1 overflow-y-auto p-4 space-y-8 scrollbar-thin scrollbar-thumb-white/10">
                    <div className="space-y-4">
                        <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Brand Colors</Label>
                        <div className="space-y-3">
                            <div>
                                <div className="flex justify-between mb-1 text-xs text-neutral-400">
                                    <span>Primary (Intent)</span>
                                    <span className="font-mono text-[hsl(var(--color-intent))]">#Color</span>
                                </div>
                                <div className="h-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500" />
                            </div>
                            <div>
                                <div className="flex justify-between mb-1 text-xs text-neutral-400">
                                    <span>Accent (Execution)</span>
                                    <span className="font-mono text-[hsl(var(--color-execution))]">#Color</span>
                                </div>
                                <div className="h-2 rounded-full bg-gradient-to-r from-emerald-500 to-green-500" />
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4 pt-4 border-t border-white/5">
                        <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Global Typography</Label>
                        <select className="w-full bg-black border border-white/10 rounded px-2 py-1.5 text-xs text-white">
                            <option>Inter (System)</option>
                            <option>Roboto</option>
                            <option>Playfair Display</option>
                            <option>Space Mono</option>
                        </select>
                    </div>

                    <div className="space-y-4 pt-4 border-t border-white/5">
                        <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Border Radius</Label>
                        <div className="grid grid-cols-3 gap-2">
                            <button className="h-8 border border-white/10 flex items-center justify-center text-xs hover:bg-white/5">Sharp</button>
                            <button className="h-8 border border-white/10 rounded-md bg-white/10 flex items-center justify-center text-xs text-white">Soft</button>
                            <button className="h-8 border border-white/10 rounded-full flex items-center justify-center text-xs hover:bg-white/5">Round</button>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-white/10">
                    <div className="flex items-center justify-between pb-4 border-b border-white/5">
                        <span className="text-[10px] font-mono text-neutral-500">{item.uniqueId}</span>
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-neutral-400 hover:text-red-400" onClick={() => onDelete(item.uniqueId)}>
                            <Trash2 className="w-3 h-3" />
                        </Button>
                    </div>
                
                {/* Theme Context */}
                {/* Theme Context */}
                <div className="space-y-4 pb-6 border-b border-white/5">
                    <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Theme & State</Label>
                    
                    {/* Theme Selector */}
                    <select 
                        className="w-full bg-black border border-white/10 rounded px-2 py-1.5 text-xs text-white focus:outline-none focus:border-[hsl(var(--color-execution))]"
                        onChange={(e) => {
                            const theme = e.target.value;
                            if (theme) {
                                let classes = "bg-neutral-900 text-white";
                                if (theme === 'cyber') classes = "bg-black border border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))] shadow-[0_0_15px_rgba(0,255,100,0.1)]";
                                if (theme === 'paper') classes = "bg-[#f5f5f5] text-black border border-neutral-200 shadow-sm";
                                if (theme === 'glass') classes = "bg-white/5 backdrop-blur-xl border border-white/10 text-white";
                                
                                let current = item.className || '';
                                current = current.replace(/bg-\S+|text-\S+|border-\S+|shadow-\S+|backdrop-\S+/g, '').trim();
                                handleChange('className', `${current} ${classes}`.trim());
                            }
                        }}
                    >
                        <option value="">Select System Theme...</option>
                        <option value="cyber">Cyberpunk (Execution)</option>
                        <option value="paper">Paper (Minimal)</option>
                        <option value="glass">Glassmorphism</option>
                        <option value="void">Void (Dark)</option>
                    </select>

                    {/* Interaction States */}
                    <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 border border-white/5 rounded bg-white/5">
                            <span className="text-[10px] text-neutral-400 block mb-1">Hover State</span>
                            <select 
                                className="w-full bg-black h-6 text-[10px] border border-white/10 rounded"
                                onChange={(e) => {
                                    if(e.target.value) addClass(`hover:${e.target.value}`);
                                }}
                            >
                                <option value="">Add Hover Effect...</option>
                                <option value="scale-105">Scale Up</option>
                                <option value="opacity-80">Dim</option>
                                <option value="bg-white/10">Highlight</option>
                                <option value="border-white">Border Glow</option>
                            </select>
                        </div>
                        <div className="p-2 border border-white/5 rounded bg-white/5">
                            <span className="text-[10px] text-neutral-400 block mb-1">Active State</span>
                            <select 
                                className="w-full bg-black h-6 text-[10px] border border-white/10 rounded"
                                onChange={(e) => {
                                    if(e.target.value) addClass(`active:${e.target.value}`);
                                }}
                            >
                                <option value="">Add Click Effect...</option>
                                <option value="scale-95">Press Down</option>
                                <option value="bg-green-500">Success Flash</option>
                            </select>
                        </div>
                    </div>
                </div>

                {/* Quick Actions */}
                <div className="grid grid-cols-4 gap-2 pb-6 border-b border-white/5">
                    <Button variant="outline" size="icon" className="h-8 w-full bg-white/5 border-white/10" onClick={() => addClass('text-left')} title="Align Left"><AlignLeft className="w-3 h-3" /></Button>
                    <Button variant="outline" size="icon" className="h-8 w-full bg-white/5 border-white/10" onClick={() => addClass('text-center')} title="Align Center"><AlignCenter className="w-3 h-3" /></Button>
                    <Button variant="outline" size="icon" className="h-8 w-full bg-white/5 border-white/10" onClick={() => addClass('text-right')} title="Align Right"><AlignRight className="w-3 h-3" /></Button>
                    <Button variant="outline" size="icon" className="h-8 w-full bg-white/5 border-white/10" onClick={() => addClass('w-full')} title="Full Width"><Maximize className="w-3 h-3" /></Button>
                </div>

                {/* Identity Section */}
                <div className="space-y-3">
                    <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Identity</Label>
                    <div className="space-y-2">
                        <Label className="text-xs text-neutral-300">Label</Label>
                        <Input 
                            value={item.label || ''} 
                            onChange={(e) => handleChange('label', e.target.value)}
                            className="bg-black/50 border-white/10 h-8 text-xs font-mono"
                        />
                    </div>
                </div>

                {/* Content Section */}
                <div className="space-y-3">
                    <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest flex items-center gap-2">
                        <Type className="w-3 h-3" /> Content
                    </Label>
                    <div className="space-y-2">
                        <Label className="text-xs text-neutral-300">HTML / Code</Label>
                        <Textarea 
                            value={item.html || ''} 
                            onChange={(e) => handleChange('html', e.target.value)}
                            className="bg-black/50 border-white/10 min-h-[150px] text-[10px] font-mono leading-relaxed resize-none"
                        />
                    </div>
                </div>

                {/* Styling Section */}
                <div className="space-y-3">
                    <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest flex items-center gap-2">
                        <Palette className="w-3 h-3" /> Design System
                    </Label>
                    
                    {/* Theme Presets */}
                    <div className="grid grid-cols-4 gap-2 mb-2">
                        {[
                            { name: 'Intent', color: 'bg-[hsl(var(--color-intent))]' },
                            { name: 'Exec', color: 'bg-[hsl(var(--color-execution))]' },
                            { name: 'Orient', color: 'bg-[hsl(var(--color-orientation))]' },
                            { name: 'Void', color: 'bg-neutral-900' },
                        ].map((theme) => (
                            <button
                                key={theme.name}
                                onClick={() => {
                                    // Intelligent class replacement for bg colors
                                    let current = item.className || '';
                                    current = current.replace(/bg-\[hsl\(var\(--color-[^)]+\)\)\]/g, '').replace(/bg-neutral-\d+/g, '').trim();
                                    handleChange('className', `${current} ${theme.color} text-black`.trim());
                                }}
                                className={`h-8 rounded border border-white/10 ${theme.color} opacity-80 hover:opacity-100 transition-opacity`}
                                title={`Apply ${theme.name} Theme`}
                            />
                        ))}
                    </div>

                    <div className="space-y-2">
                        <Label className="text-xs text-neutral-300">Raw Classes</Label>
                        <Input 
                            value={item.className || ''} 
                            onChange={(e) => handleChange('className', e.target.value)}
                            placeholder="p-4 flex..."
                            className="bg-black/50 border-white/10 h-8 text-xs font-mono"
                        />
                    </div>
                </div>

                {/* Layout Helpers */}
                <div className="space-y-3 pt-4 border-t border-white/5">
                    <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest flex items-center gap-2">
                        <Layout className="w-3 h-3" /> Layout System
                    </Label>
                    <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" size="sm" className="text-[10px] h-7" onClick={() => handleChange('className', (item.className || '') + ' flex flex-col gap-4')}>
                            Flex Col
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-7" onClick={() => handleChange('className', (item.className || '') + ' flex flex-row items-center gap-4')}>
                            Flex Row
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-7" onClick={() => handleChange('className', (item.className || '') + ' flex items-center justify-center')}>
                            Center
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-7" onClick={() => handleChange('className', (item.className || '') + ' flex items-center justify-between')}>
                            Space Between
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-7" onClick={() => handleChange('className', (item.className || '') + ' grid grid-cols-2 gap-4')}>
                            Grid 2x
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-7" onClick={() => handleChange('className', (item.className || '') + ' grid grid-cols-3 gap-4')}>
                            Grid 3x
                        </Button>
                        <Button variant="outline" size="sm" className="text-[10px] h-7 col-span-2" onClick={() => handleChange('className', (item.className || '') + ' p-6 rounded-xl border border-white/10 bg-white/5 backdrop-blur-md')}>
                            Smart Container
                        </Button>
                    </div>
                </div>

                {/* Typography Section */}
                <div className="space-y-4 pt-4 border-t border-white/5">
                    <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest flex items-center gap-2">
                        <Type className="w-3 h-3" /> Typography
                    </Label>
                    <div className="space-y-4">
                         <div className="grid grid-cols-4 gap-2">
                            {['xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl'].map(size => (
                                <Button 
                                    key={size}
                                    variant="outline" 
                                    size="sm" 
                                    className={cn("text-[10px] h-7 border-white/10", (item.className || '').includes(`text-${size}`) ? "bg-white/10 text-white" : "text-neutral-400")}
                                    onClick={() => {
                                        let current = item.className || '';
                                        current = current.replace(/text-(xs|sm|base|lg|xl|2xl|3xl|4xl|5xl|6xl|7xl|8xl)/g, '').trim();
                                        handleChange('className', `${current} text-${size}`.trim());
                                    }}
                                >
                                    {size.toUpperCase()}
                                </Button>
                            ))}
                         </div>

                         <div className="grid grid-cols-3 gap-2">
                            {['font-thin', 'font-normal', 'font-medium', 'font-bold', 'font-black', 'italic', 'underline', 'uppercase', 'tracking-widest'].map(style => (
                                <Button 
                                    key={style}
                                    variant="outline" 
                                    size="sm" 
                                    className={cn("text-[9px] h-7 border-white/10 px-1 truncate", (item.className || '').includes(style) ? "bg-white/10 text-white" : "text-neutral-400")}
                                    onClick={() => {
                                        const current = item.className || '';
                                        if (['font-thin', 'font-normal', 'font-medium', 'font-bold', 'font-black'].includes(style)) {
                                            // Replace existing weight
                                            let cleaned = current.replace(/font-(thin|normal|medium|bold|black)/g, '').trim();
                                            handleChange('className', `${cleaned} ${style}`.trim());
                                        } else {
                                            // Toggle others
                                            const hasStyle = current.includes(style);
                                            handleChange('className', hasStyle ? current.replace(style, '').trim() : `${current} ${style}`.trim());
                                        }
                                    }}
                                    title={style}
                                >
                                    {style.replace('font-', '').replace('tracking-', '')}
                                </Button>
                            ))}
                         </div>

                         <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5">
                            <Button 
                                variant="outline" 
                                size="sm" 
                                className={cn("text-[10px] h-7 border-white/10", (item.className || '').includes('font-mono') ? "bg-white/10 text-white" : "text-neutral-400")}
                                onClick={() => {
                                    const current = item.className || '';
                                    const isMono = current.includes('font-mono');
                                    handleChange('className', isMono ? current.replace('font-mono', '').trim() : `${current} font-mono`.trim());
                                }}
                            >
                                Monospace
                            </Button>
                            <Button 
                                variant="outline" 
                                size="sm" 
                                className={cn("text-[10px] h-7 border-white/10", (item.className || '').includes('font-serif') ? "bg-white/10 text-white" : "text-neutral-400")}
                                onClick={() => {
                                    const current = item.className || '';
                                    const isSerif = current.includes('font-serif');
                                    handleChange('className', isSerif ? current.replace('font-serif', '').trim() : `${current} font-serif`.trim());
                                }}
                            >
                                Serif
                            </Button>
                         </div>
                    </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-white/5">
                    <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest flex items-center gap-2">
                        <Maximize className="w-3 h-3" /> Spacing (Padding)
                    </Label>
                    <div className="space-y-6">
                        <div className="space-y-2">
                            <div className="flex justify-between text-[10px] text-neutral-400">
                                <span>Internal Spacing</span>
                                <span>{(item.padding || 0) * 4}px</span>
                            </div>
                            <Slider 
                                defaultValue={[item.padding || 0]} 
                                max={12} 
                                step={1} 
                                onValueChange={(vals) => {
                                    const val = vals[0];
                                    // Remove existing p-* classes
                                    let current = item.className || '';
                                    current = current.replace(/p-\d+/g, '').trim();
                                    handleChange('className', `${current} p-${val}`.trim());
                                    // Also store specifically if needed, but class is source of truth
                                    onUpdate(item.uniqueId, { padding: val });
                                }}
                                className="[&_.bg-primary]:bg-[hsl(var(--color-intent))]"
                            />
                        </div>
                        <div className="space-y-2">
                            <div className="flex justify-between text-[10px] text-neutral-400">
                                <span>Rounded Corners</span>
                                <span>{(item.rounded || 0) * 2}px</span>
                            </div>
                            <Slider 
                                defaultValue={[item.rounded || 0]} 
                                max={8} 
                                step={1} 
                                onValueChange={(vals) => {
                                    const val = vals[0];
                                    const map = { 0: 'rounded-none', 1: 'rounded-sm', 2: 'rounded', 4: 'rounded-md', 6: 'rounded-lg', 8: 'rounded-xl', 12: 'rounded-2xl', 16: 'rounded-3xl', 99: 'rounded-full' };
                                    let current = item.className || '';
                                    current = current.replace(/rounded-\w+/g, '').trim();
                                    // Simple mapping for slider
                                    let cls = 'rounded-none';
                                    if(val > 0) cls = 'rounded-sm';
                                    if(val > 2) cls = 'rounded-md';
                                    if(val > 4) cls = 'rounded-lg';
                                    if(val > 6) cls = 'rounded-xl';
                                    if(val > 7) cls = 'rounded-2xl';
                                    
                                    handleChange('className', `${current} ${cls}`.trim());
                                    onUpdate(item.uniqueId, { rounded: val });
                                }}
                                className="[&_.bg-primary]:bg-[hsl(var(--color-execution))]"
                            />
                        </div>
                        
                        <div className="space-y-2 pt-2 border-t border-white/5">
                            <div className="flex justify-between text-[10px] text-neutral-400">
                                <span>Opacity</span>
                                <span>{(item.opacity || 100)}%</span>
                            </div>
                            <Slider 
                                defaultValue={[item.opacity || 100]} 
                                max={100} 
                                step={10} 
                                onValueChange={(vals) => {
                                    const val = vals[0];
                                    let current = item.className || '';
                                    current = current.replace(/opacity-\d+/g, '').trim();
                                    
                                    let cls = `opacity-${val}`;
                                    if (val === 100) cls = '';
                                    
                                    handleChange('className', `${current} ${cls}`.trim());
                                    onUpdate(item.uniqueId, { opacity: val });
                                }}
                                className="[&_.bg-primary]:bg-white"
                            />
                        </div>

                        <div className="space-y-2 pt-2 border-t border-white/5">
                            <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest">Shadow Depth</Label>
                            <div className="grid grid-cols-4 gap-2">
                                {['None', 'SM', 'MD', 'LG', 'XL', '2XL', 'Inner'].map((shadow) => (
                                    <button
                                        key={shadow}
                                        onClick={() => {
                                            let current = item.className || '';
                                            current = current.replace(/shadow-(sm|md|lg|xl|2xl|inner|none)/g, '').replace(/\bshadow\b/g, '').trim();
                                            
                                            let cls = shadow === 'None' ? 'shadow-none' : shadow === 'MD' ? 'shadow' : `shadow-${shadow.toLowerCase()}`;
                                            
                                            handleChange('className', `${current} ${cls}`.trim());
                                        }}
                                        className={cn(
                                            "h-7 rounded text-[9px] font-medium border border-white/10 hover:bg-white/10 transition-colors",
                                            (item.className || '').includes(shadow === 'None' ? 'shadow-none' : shadow === 'MD' ? 'shadow ' : `shadow-${shadow.toLowerCase()}`) 
                                                ? "bg-white/20 text-white" 
                                                : "text-neutral-400"
                                        )}
                                    >
                                        {shadow}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Dimensions & Borders */}
                        <div className="space-y-4 pt-4 border-t border-white/5">
                             <Label className="text-[10px] uppercase text-neutral-500 font-bold tracking-widest flex items-center gap-2">
                                <Maximize className="w-3 h-3" /> Geometry
                            </Label>
                            <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-1">
                                    <Label className="text-[9px] text-neutral-400">Width</Label>
                                    <Input 
                                        className="h-7 text-xs bg-black/50 border-white/10" 
                                        placeholder="auto"
                                        value={item.style?.width || ''}
                                        onChange={(e) => {
                                            handleChange('style', { ...item.style, width: e.target.value });
                                        }}
                                    />
                                </div>
                                <div className="space-y-1">
                                    <Label className="text-[9px] text-neutral-400">Height</Label>
                                    <Input 
                                        className="h-7 text-xs bg-black/50 border-white/10" 
                                        placeholder="auto"
                                        value={item.style?.height || ''}
                                        onChange={(e) => {
                                            handleChange('style', { ...item.style, height: e.target.value });
                                        }}
                                    />
                                </div>
                                <div className="space-y-1">
                                    <Label className="text-[9px] text-neutral-400">Border Width</Label>
                                    <select 
                                        className="w-full h-7 bg-black/50 border border-white/10 rounded text-xs text-white px-2"
                                        onChange={(e) => {
                                            let current = item.className || '';
                                            current = current.replace(/border-\d+|border\b/g, '').trim();
                                            const val = e.target.value;
                                            if (val !== '0') {
                                                handleChange('className', `${current} border-${val} border`.trim());
                                            } else {
                                                handleChange('className', current);
                                            }
                                        }}
                                    >
                                        <option value="0">None</option>
                                        <option value="1">1px</option>
                                        <option value="2">2px</option>
                                        <option value="4">4px</option>
                                        <option value="8">8px</option>
                                    </select>
                                </div>
                                <div className="space-y-1">
                                    <Label className="text-[9px] text-neutral-400">Border Color</Label>
                                    <select 
                                        className="w-full h-7 bg-black/50 border border-white/10 rounded text-xs text-white px-2"
                                        onChange={(e) => {
                                            let current = item.className || '';
                                            current = current.replace(/border-(white|neutral|red|blue|green|yellow|indigo)-(\d+|\w+)/g, '').trim();
                                            handleChange('className', `${current} ${e.target.value}`.trim());
                                        }}
                                    >
                                        <option value="border-white/10">Default</option>
                                        <option value="border-[hsl(var(--color-intent))]">Intent</option>
                                        <option value="border-[hsl(var(--color-execution))]">Execution</option>
                                        <option value="border-white/50">White 50%</option>
                                        <option value="border-transparent">Transparent</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        )}
        </div>
    );
}