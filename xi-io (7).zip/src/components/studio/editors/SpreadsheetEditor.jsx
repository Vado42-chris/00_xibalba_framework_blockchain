import React, { useState } from 'react';
import { Table, Grid, Save, Download, Plus, Search, Filter, MoreHorizontal, Bold, Italic, AlignLeft, AlignCenter, AlignRight, DollarSign, Percent } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function SpreadsheetEditor({ file }) {
    const [activeCell, setActiveCell] = useState(null);
    const [formula, setFormula] = useState('');
    const [data, setData] = useState({});

    // Generate grid columns (A-Z) and rows (1-50)
    const cols = Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i));
    const rows = Array.from({ length: 50 }, (_, i) => i + 1);

    const handleCellClick = (cellId) => {
        setActiveCell(cellId);
        setFormula(data[cellId]?.value || '');
    };

    return (
        <div className="w-full h-full bg-white text-neutral-900 flex flex-col font-sans">
            {/* Ribbon / Toolbar */}
            <div className="h-28 border-b border-neutral-200 flex flex-col shrink-0">
                {/* File Menu */}
                <div className="h-8 bg-[#217346] flex items-center px-4 gap-4 text-white text-xs">
                    <span className="font-bold cursor-pointer">File</span>
                    <span className="cursor-pointer hover:bg-white/10 px-2 py-1 rounded">Home</span>
                    <span className="cursor-pointer hover:bg-white/10 px-2 py-1 rounded">Insert</span>
                    <span className="cursor-pointer hover:bg-white/10 px-2 py-1 rounded">Layout</span>
                    <span className="cursor-pointer hover:bg-white/10 px-2 py-1 rounded">Formulas</span>
                    <span className="cursor-pointer hover:bg-white/10 px-2 py-1 rounded">Data</span>
                </div>
                
                {/* Tools */}
                <div className="flex-1 bg-neutral-50 flex items-center px-4 gap-4 overflow-x-auto">
                    {/* Clipboard */}
                    <div className="flex flex-col gap-1 pr-4 border-r border-neutral-200">
                        <Button variant="ghost" size="sm" className="h-6 justify-start text-xs"><span className="mr-2">📋</span> Paste</Button>
                        <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-6 w-6 text-xs">✂️</Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6 text-xs">📄</Button>
                        </div>
                    </div>

                    {/* Font */}
                    <div className="flex flex-col gap-1 pr-4 border-r border-neutral-200">
                        <div className="flex gap-2">
                            <select className="h-6 text-xs border border-neutral-300 rounded w-24"><option>Calibri</option></select>
                            <select className="h-6 text-xs border border-neutral-300 rounded w-12"><option>11</option></select>
                        </div>
                        <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-6 w-6"><Bold className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6"><Italic className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6 underline">U</Button>
                            <div className="w-px h-4 bg-neutral-300 mx-1" />
                            <Button variant="ghost" size="icon" className="h-6 w-6 text-[10px] bg-yellow-100 border border-yellow-200">A</Button>
                        </div>
                    </div>

                    {/* Alignment */}
                    <div className="flex flex-col gap-1 pr-4 border-r border-neutral-200">
                        <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-6 w-6"><AlignLeft className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6"><AlignCenter className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6"><AlignRight className="w-3 h-3" /></Button>
                        </div>
                    </div>

                    {/* Number */}
                    <div className="flex flex-col gap-1 pr-4 border-r border-neutral-200">
                         <select className="h-6 text-xs border border-neutral-300 rounded w-24 mb-1"><option>General</option></select>
                         <div className="flex gap-1">
                            <Button variant="ghost" size="icon" className="h-6 w-6"><DollarSign className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6"><Percent className="w-3 h-3" /></Button>
                         </div>
                    </div>
                </div>
            </div>

            {/* Formula Bar */}
            <div className="h-8 border-b border-neutral-200 flex items-center px-2 bg-white shrink-0">
                <div className="w-10 text-xs font-bold text-neutral-500 border-r border-neutral-200 pr-2 text-center">
                    {activeCell || 'A1'}
                </div>
                <div className="px-2 text-neutral-400">ƒx</div>
                <input 
                    className="flex-1 h-full text-sm px-2 focus:outline-none" 
                    value={formula}
                    onChange={(e) => setFormula(e.target.value)}
                />
            </div>

            {/* Grid */}
            <div className="flex-1 overflow-auto bg-neutral-100 relative">
                <div className="inline-block min-w-full bg-white">
                    {/* Header Row */}
                    <div className="flex sticky top-0 z-10">
                        <div className="w-10 h-6 bg-neutral-50 border-r border-b border-neutral-300 shrink-0" />
                        {cols.map(col => (
                            <div key={col} className="w-24 h-6 bg-neutral-50 border-r border-b border-neutral-300 flex items-center justify-center text-xs font-bold text-neutral-600 shrink-0 resize-x overflow-hidden">
                                {col}
                            </div>
                        ))}
                    </div>

                    {/* Rows */}
                    {rows.map(row => (
                        <div key={row} className="flex h-6">
                            <div className="w-10 bg-neutral-50 border-r border-b border-neutral-300 flex items-center justify-center text-xs font-bold text-neutral-600 shrink-0 sticky left-0 z-10">
                                {row}
                            </div>
                            {cols.map(col => {
                                const cellId = `${col}${row}`;
                                const isActive = activeCell === cellId;
                                return (
                                    <div 
                                        key={cellId}
                                        onClick={() => handleCellClick(cellId)}
                                        className={cn(
                                            "w-24 h-full border-r border-b border-neutral-200 text-xs px-1 flex items-center outline-none shrink-0",
                                            isActive ? "border-2 border-[#217346] z-20" : ""
                                        )}
                                        contentEditable={isActive}
                                        suppressContentEditableWarning
                                    >
                                        {data[cellId]?.value}
                                    </div>
                                );
                            })}
                        </div>
                    ))}
                </div>
            </div>

            {/* Footer / Sheets */}
            <div className="h-8 bg-neutral-50 border-t border-neutral-200 flex items-center px-2 gap-1 shrink-0">
                <div className="flex gap-2">
                    <Button variant="ghost" size="icon" className="h-6 w-6"><Plus className="w-3 h-3" /></Button>
                    <div className="px-3 py-1 bg-white border-t-2 border-[#217346] text-xs font-bold text-[#217346] shadow-sm rounded-t">
                        Sheet1
                    </div>
                    <div className="px-3 py-1 text-xs text-neutral-500 hover:bg-neutral-200 rounded-t cursor-pointer">
                        Sheet2
                    </div>
                </div>
            </div>
        </div>
    );
}