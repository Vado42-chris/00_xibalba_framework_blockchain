import React from 'react';
import { Mail, Inbox, Send, Archive, Trash, Star, Plus, Paperclip, MoreHorizontal, Reply, Forward, Search, Calendar, User, Tag } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function EmailDesigner({ file }) {
    return (
        <div className="w-full h-full bg-[#f5f5f5] text-neutral-900 flex font-sans">
            {/* Sidebar */}
            <div className="w-64 bg-white border-r border-neutral-200 flex flex-col py-6 shadow-xl z-20">
                <div className="px-6 mb-6">
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white shadow-lg h-10 rounded-xl font-bold tracking-wide transition-all transform active:scale-95">
                        <Plus className="w-4 h-4 mr-2" /> New Message
                    </Button>
                </div>
                <div className="space-y-1 px-3">
                    {[
                        { icon: Inbox, label: 'Inbox', count: 4, active: true },
                        { icon: Star, label: 'Starred', count: 0 },
                        { icon: Send, label: 'Sent', count: 0 },
                        { icon: Archive, label: 'Archive', count: 0 },
                        { icon: Trash, label: 'Trash', count: 0 },
                    ].map(item => (
                        <button key={item.label} className={cn(
                            "w-full flex items-center justify-between px-4 py-2.5 text-sm rounded-lg transition-all group",
                            item.active ? "bg-blue-50 text-blue-700 font-bold" : "text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900"
                        )}>
                            <div className="flex items-center gap-3">
                                <item.icon className={cn("w-4 h-4", item.active ? "text-blue-600" : "text-neutral-400 group-hover:text-neutral-600")} />
                                {item.label}
                            </div>
                            {item.count > 0 && <span className={cn("text-xs px-2 py-0.5 rounded-full font-bold", item.active ? "bg-blue-100" : "bg-neutral-100")}>{item.count}</span>}
                        </button>
                    ))}
                </div>
                
                <div className="mt-8 px-6">
                    <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-3 flex items-center justify-between">
                        Labels <Plus className="w-3 h-3 cursor-pointer hover:text-black" />
                    </div>
                    <div className="space-y-1">
                        {['Work', 'Personal', 'Finance'].map(label => (
                            <div key={label} className="flex items-center gap-3 text-sm text-neutral-600 px-2 py-1.5 cursor-pointer hover:bg-neutral-50 rounded-lg transition-colors">
                                <Tag className={cn("w-3 h-3", label === 'Work' ? "text-orange-500" : label === 'Personal' ? "text-green-500" : "text-blue-500")} />
                                {label}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Message List */}
            <div className="w-96 bg-white border-r border-neutral-200 flex flex-col z-10">
                <div className="p-4 border-b border-neutral-100 flex items-center gap-2 sticky top-0 bg-white z-10">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-2.5 w-4 h-4 text-neutral-400" />
                        <input className="w-full bg-neutral-100 border-transparent rounded-lg pl-9 pr-3 py-2 text-sm focus:bg-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all outline-none" placeholder="Search mail..." />
                    </div>
                    <Button variant="ghost" size="icon" className="h-9 w-9 text-neutral-400 hover:text-neutral-900 rounded-lg hover:bg-neutral-100"><Calendar className="w-4 h-4" /></Button>
                </div>
                <div className="flex-1 overflow-y-auto">
                    {[
                        { from: "GitHub", subject: "[GitHub] A new public key was added", preview: "The following key was added to your account...", time: "10:42 AM", read: false },
                        { from: "Linear", subject: "Update on T-492: Design System", preview: "Commented: We should probably align the...", time: "Yesterday", read: true },
                        { from: "Vercel", subject: "Deployment Successful: production", preview: "The deployment was completed in 45s...", time: "Oct 24", read: true },
                        { from: "Stripe", subject: "Payment received: $49.00", preview: "You have received a payment from...", time: "Oct 22", read: true },
                    ].map((mail, i) => (
                        <div key={i} className={cn(
                            "p-4 border-b border-neutral-100 cursor-pointer transition-all hover:bg-neutral-50 group relative",
                            !mail.read ? "bg-blue-50/40 border-l-4 border-l-blue-500 pl-[13px]" : "pl-[17px]"
                        )}>
                            <div className="flex justify-between items-baseline mb-1.5">
                                <span className={cn("text-sm truncate max-w-[180px]", !mail.read ? "font-bold text-neutral-900" : "font-medium text-neutral-700")}>{mail.from}</span>
                                <span className="text-[10px] text-neutral-400 font-medium whitespace-nowrap">{mail.time}</span>
                            </div>
                            <div className={cn("text-sm mb-1.5 truncate", !mail.read ? "font-bold text-neutral-900" : "text-neutral-600")}>{mail.subject}</div>
                            <div className="text-xs text-neutral-500 truncate leading-relaxed">{mail.preview}</div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Reading Pane */}
            <div className="flex-1 flex flex-col bg-white">
                {/* Header */}
                <div className="h-16 border-b border-neutral-100 flex items-center justify-between px-8 bg-white sticky top-0 z-10">
                    <div className="flex gap-2">
                        <Button variant="ghost" size="icon" className="text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg"><Archive className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" className="text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg"><Trash className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" className="text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100 rounded-lg"><Mail className="w-4 h-4" /></Button>
                        <div className="w-px h-6 bg-neutral-200 mx-2 my-auto" />
                        <div className="flex items-center gap-2 px-3 py-1 bg-neutral-100 rounded-lg text-xs font-medium text-neutral-600">
                            <span className="w-2 h-2 rounded-full bg-green-500" /> Personal
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <Button variant="ghost" size="icon" className="text-neutral-500 hover:bg-neutral-100 rounded-lg"><MoreHorizontal className="w-4 h-4" /></Button>
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto p-10 bg-white">
                    <div className="max-w-3xl mx-auto">
                        <h1 className="text-2xl font-bold mb-8 text-neutral-900 leading-tight">[GitHub] A new public key was added to your account</h1>
                        
                        <div className="flex items-start gap-4 mb-8">
                            <div className="w-12 h-12 rounded-full bg-neutral-900 flex items-center justify-center text-white font-bold text-lg shadow-md">G</div>
                            <div className="flex-1">
                                <div className="flex items-baseline justify-between">
                                    <div className="font-bold text-sm text-neutral-900">GitHub <span className="font-normal text-neutral-500 ml-1">&lt;noreply@github.com&gt;</span></div>
                                    <div className="text-xs text-neutral-400 font-medium">10:42 AM (2 hours ago)</div>
                                </div>
                                <div className="text-xs text-neutral-500 mt-0.5">To: me@base44.io</div>
                            </div>
                        </div>

                        <div className="prose prose-sm max-w-none text-neutral-700 leading-relaxed font-serif text-base">
                            <p>Hey there,</p>
                            <p>The following SSH key was added to your account:</p>
                            <div className="bg-neutral-50 border border-neutral-200 p-4 rounded-lg my-6 font-mono text-xs text-neutral-600 shadow-sm flex items-center gap-3">
                                <KeyIcon className="w-4 h-4 text-neutral-400" />
                                SHA256:r/w+g8... (MacBook Pro)
                            </div>
                            <p>If you haven't added this key, you should immediately check your account settings.</p>
                            <p className="mt-8 text-neutral-500">Cheers,<br/>The GitHub Team</p>
                        </div>

                        <div className="mt-12 pt-8 border-t border-neutral-100 flex gap-4">
                            <Button variant="outline" className="gap-2 h-10 px-6 rounded-lg font-medium border-neutral-300 text-neutral-700 hover:bg-neutral-50 hover:text-black shadow-sm"><Reply className="w-4 h-4" /> Reply</Button>
                            <Button variant="outline" className="gap-2 h-10 px-6 rounded-lg font-medium border-neutral-300 text-neutral-700 hover:bg-neutral-50 hover:text-black shadow-sm"><Forward className="w-4 h-4" /> Forward</Button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

function KeyIcon({ className }) {
    return <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>;
}