import React, { useState } from 'react';
import { ShoppingBag, Box, Tag, Users, BarChart3, Settings, Plus, Search, Filter, ArrowUpRight, Image as ImageIcon, Check } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function StoreEditor({ file }) {
    const [activeTab, setActiveTab] = useState('products');

    return (
        <div className="w-full h-full bg-[#f6f6f7] text-neutral-900 flex font-sans">
            {/* Sidebar Navigation */}
            <div className="w-64 bg-[#1a1a1a] text-[#b3b3b3] flex flex-col shadow-2xl z-20">
                <div className="h-16 flex items-center px-4 border-b border-white/10 bg-[#151515]">
                    <div className="w-8 h-8 rounded bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center mr-3 text-white font-bold text-xs shadow-lg">S</div>
                    <div>
                        <span className="text-white font-bold text-sm block">Store Admin</span>
                        <span className="text-[10px] text-green-500 flex items-center gap-1">● Live</span>
                    </div>
                </div>
                
                <div className="p-3 space-y-1">
                    {[
                        { id: 'home', icon: BarChart3, label: 'Home' },
                        { id: 'orders', icon: ShoppingBag, label: 'Orders', count: 12 },
                        { id: 'products', icon: Box, label: 'Products' },
                        { id: 'customers', icon: Users, label: 'Customers' },
                        { id: 'discounts', icon: Tag, label: 'Discounts' },
                    ].map(item => (
                        <button 
                            key={item.id}
                            onClick={() => setActiveTab(item.id)}
                            className={cn(
                                "w-full flex items-center gap-3 px-3 py-2 text-sm rounded transition-all font-medium group relative",
                                activeTab === item.id 
                                    ? "bg-white/10 text-white" 
                                    : "hover:bg-white/5 hover:text-white"
                            )}
                        >
                            {activeTab === item.id && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-green-500 rounded-r-full" />}
                            <item.icon className={cn("w-4 h-4", activeTab === item.id ? "text-green-400" : "text-neutral-500 group-hover:text-white")} />
                            <span className="flex-1 text-left">{item.label}</span>
                            {item.count && (
                                <span className="text-[10px] bg-white/20 px-1.5 py-0.5 rounded text-white">{item.count}</span>
                            )}
                        </button>
                    ))}
                </div>

                <div className="mt-auto p-4 border-t border-white/10">
                    <div className="text-[10px] font-bold uppercase tracking-widest text-[#666] mb-3">Sales Channels</div>
                    <div className="space-y-2">
                        <div className="flex items-center gap-2 text-xs text-[#b3b3b3] hover:text-white cursor-pointer px-2 py-1 hover:bg-white/5 rounded">
                            <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_5px_lime]" /> Online Store
                        </div>
                        <div className="flex items-center gap-2 text-xs text-[#b3b3b3] hover:text-white cursor-pointer px-2 py-1 hover:bg-white/5 rounded">
                            <div className="w-2 h-2 rounded-full bg-blue-500" /> Facebook Shop
                        </div>
                    </div>
                    <Button variant="ghost" className="w-full justify-start mt-4 text-xs text-[#b3b3b3] hover:text-white px-2 hover:bg-white/5">
                        <Settings className="w-4 h-4 mr-2" /> Settings
                    </Button>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 flex flex-col overflow-hidden bg-white">
                <div className="h-16 border-b border-neutral-200 bg-white flex items-center px-8 justify-between sticky top-0 z-10">
                    <h1 className="text-2xl font-bold text-neutral-900 tracking-tight">Products</h1>
                    <div className="flex gap-2">
                        <Button variant="outline" className="text-xs h-9 border-neutral-300">Export</Button>
                        <Button variant="outline" className="text-xs h-9 border-neutral-300">Import</Button>
                        <Button className="bg-[#1a1a1a] text-white hover:bg-neutral-800 text-xs font-bold shadow-lg h-9 px-4">
                            <Plus className="w-4 h-4 mr-1" /> Add Product
                        </Button>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-8 bg-[#f9fafb]">
                    {/* Filters */}
                    <div className="bg-white rounded-t-xl border border-neutral-200 p-4 flex items-center justify-between shadow-sm">
                        <div className="flex gap-2">
                            <button className="text-xs font-medium px-4 py-1.5 bg-neutral-100 rounded-full text-neutral-900 hover:bg-neutral-200 transition-colors border border-transparent">All</button>
                            <button className="text-xs font-medium px-4 py-1.5 rounded-full text-neutral-500 hover:bg-neutral-50 transition-colors border border-transparent hover:border-neutral-200">Active</button>
                            <button className="text-xs font-medium px-4 py-1.5 rounded-full text-neutral-500 hover:bg-neutral-100 transition-colors border border-transparent hover:border-neutral-200">Draft</button>
                            <button className="text-xs font-medium px-4 py-1.5 rounded-full text-neutral-500 hover:bg-neutral-100 transition-colors border border-transparent hover:border-neutral-200">Archived</button>
                        </div>
                        <div className="flex items-center gap-3">
                            <div className="relative group">
                                <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-400 group-focus-within:text-neutral-600" />
                                <input className="pl-9 pr-4 py-2 text-sm border border-neutral-200 rounded-lg w-64 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 transition-all bg-neutral-50 focus:bg-white" placeholder="Search products..." />
                            </div>
                            <Button variant="ghost" size="icon" className="h-9 w-9 border border-neutral-200 rounded-lg hover:bg-neutral-50"><Filter className="w-4 h-4 text-neutral-500" /></Button>
                        </div>
                    </div>

                    {/* Product List */}
                    <div className="bg-white rounded-b-xl shadow-sm border-x border-b border-neutral-200 overflow-hidden">
                        <div className="grid grid-cols-12 gap-4 p-4 border-b border-neutral-100 bg-neutral-50/50 text-[11px] font-bold text-neutral-500 uppercase tracking-wider">
                            <div className="col-span-1 text-center"><input type="checkbox" className="rounded text-green-600 focus:ring-green-500" /></div>
                            <div className="col-span-5">Product</div>
                            <div className="col-span-2">Status</div>
                            <div className="col-span-2">Inventory</div>
                            <div className="col-span-2 text-right">Vendor</div>
                        </div>

                        {[
                            { name: 'Classic T-Shirt', img: 'bg-neutral-200', status: 'Active', inv: '25 in stock', vendor: 'Base44' },
                            { name: 'Leather Wallet', img: 'bg-orange-100', status: 'Active', inv: '14 in stock', vendor: 'Crafts' },
                            { name: 'Ceramic Mug', img: 'bg-blue-100', status: 'Draft', inv: '0 in stock', vendor: 'Home' },
                            { name: 'Denim Jacket', img: 'bg-indigo-100', status: 'Active', inv: '42 in stock', vendor: 'DenimCo' },
                            { name: 'Canvas Sneakers', img: 'bg-red-100', status: 'Active', inv: '8 in stock', vendor: 'Steps' },
                        ].map((prod, i) => (
                            <div key={i} className="grid grid-cols-12 gap-4 p-4 border-b border-neutral-100 items-center hover:bg-neutral-50 transition-colors group cursor-pointer">
                                <div className="col-span-1 text-center"><input type="checkbox" className="rounded text-green-600 focus:ring-green-500" /></div>
                                <div className="col-span-5 flex items-center gap-4">
                                    <div className={cn("w-12 h-12 rounded-lg border border-neutral-200 flex items-center justify-center", prod.img)}>
                                        <ImageIcon className="w-5 h-5 text-black/20" />
                                    </div>
                                    <span className="text-sm font-semibold text-neutral-800 group-hover:text-green-600 transition-colors">{prod.name}</span>
                                </div>
                                <div className="col-span-2">
                                    <span className={cn(
                                        "px-2.5 py-1 rounded-full text-[10px] font-bold inline-flex items-center gap-1",
                                        prod.status === 'Active' ? "bg-green-100 text-green-700" : "bg-neutral-100 text-neutral-600"
                                    )}>
                                        {prod.status === 'Active' && <div className="w-1.5 h-1.5 rounded-full bg-green-500" />}
                                        {prod.status}
                                    </span>
                                </div>
                                <div className="col-span-2 text-sm text-neutral-600 font-medium">
                                    {prod.inv}
                                </div>
                                <div className="col-span-2 text-right text-sm text-neutral-500">
                                    {prod.vendor}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}