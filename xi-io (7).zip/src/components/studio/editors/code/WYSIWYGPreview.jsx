import React, { useState, useEffect, useRef } from 'react';
import { 
    MousePointer2, Move, Type, Image, Box, Layers, 
    Eye, EyeOff, Smartphone, Tablet, Laptop, RefreshCw,
    Maximize2, Settings, Zap, Edit3, Code, Palette, Cuboid, Gamepad2
} from 'lucide-react';
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export default function WYSIWYGPreview({ code, activeFile, isDark = true }) {
    const [mode, setMode] = useState('interactive'); // interactive, inspect, design
    const [viewport, setViewport] = useState('desktop'); // desktop, tablet, mobile
    const [selectedElement, setSelectedElement] = useState(null);
    const [hoveredElement, setHoveredElement] = useState(null);
    const [scale, setScale] = useState(1);
    
    // Simulated parsing of the "code" to render a live preview
    // In a real app, this would use a bundler/transpiler. 
    // Here we'll use a sophisticated mock that "reacts" to the code string for demo purposes.

    const containerRef = useRef(null);

    const handleElementClick = (e, id, tag) => {
        if (mode === 'interactive') return;
        e.stopPropagation();
        e.preventDefault();
        setSelectedElement({ id, tag, styles: e.target.className });
    };

    const handleElementHover = (e, id, tag) => {
        if (mode === 'interactive') return;
        e.stopPropagation();
        setHoveredElement({ id, tag, rect: e.target.getBoundingClientRect() });
    };

    const resetSelection = () => {
        setSelectedElement(null);
        setHoveredElement(null);
    };

    // This would be replaced by actual compiled code in production
    const RenderedContent = () => (
        <div className={cn("min-h-full font-sans transition-colors duration-500", isDark ? "bg-black text-white" : "bg-white text-black")}>
            <header className="flex justify-between items-center p-8 border-b border-white/10">
                <h1 
                    className={cn(
                        "text-4xl font-bold tracking-tighter transition-all hover:text-blue-500 cursor-default",
                        selectedElement?.id === 'h1' && "ring-2 ring-blue-500 ring-offset-2 ring-offset-black"
                    )}
                    onClick={(e) => handleElementClick(e, 'h1', 'h1')}
                    onMouseEnter={(e) => handleElementHover(e, 'h1', 'h1')}
                >
                    Hello World
                </h1>
                <nav className="flex gap-6 text-sm font-medium text-gray-400">
                    {['Home', 'Features', 'Pricing', 'About'].map((item, i) => (
                        <a 
                            key={i} 
                            href="#" 
                            className="hover:text-white transition-colors"
                            onClick={(e) => handleElementClick(e, `nav-${i}`, 'a')}
                        >
                            {item}
                        </a>
                    ))}
                </nav>
            </header>

            <main className="p-12 max-w-4xl mx-auto text-center space-y-8">
                <div 
                    className={cn(
                        "p-6 rounded-2xl bg-gradient-to-br from-purple-900/20 to-blue-900/20 border border-white/10",
                        selectedElement?.id === 'hero-card' && "ring-2 ring-purple-500"
                    )}
                    onClick={(e) => handleElementClick(e, 'hero-card', 'div')}
                >
                    <h2 className="text-2xl font-semibold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
                        AI-Powered Architecture
                    </h2>
                    <p className="text-gray-400 leading-relaxed mb-6">
                        Experience the future of coding with our advanced neural engine.
                        Build faster, smarter, and with greater precision.
                    </p>
                    <div className="flex gap-4 justify-center">
                        <button className="px-6 py-2 bg-blue-600 rounded-lg font-medium hover:bg-blue-500 transition-all active:scale-95 shadow-lg shadow-blue-900/20">
                            Get Started
                        </button>
                        <button className="px-6 py-2 bg-white/5 border border-white/10 rounded-lg font-medium hover:bg-white/10 transition-all">
                            Documentation
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-4 text-left">
                    {[1, 2, 3].map((i) => (
                        <div key={i} className="p-4 rounded-xl bg-white/5 border border-white/5 hover:border-white/20 transition-all group">
                            <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                                <Zap className="w-4 h-4" />
                            </div>
                            <h3 className="font-medium mb-1">Feature {i}</h3>
                            <p className="text-xs text-gray-500">Automated optimization for your workflow.</p>
                        </div>
                    ))}
                </div>
            </main>
        </div>
    );

    return (
        <div className="flex flex-col h-full bg-[#0c0c0e] border-l border-[#27272a]" onClick={resetSelection}>
            {/* Toolbar */}
            <div className="h-10 border-b border-[#27272a] bg-[#09090b] flex items-center justify-between px-3 shrink-0">
                <div className="flex items-center gap-1 bg-[#18181b] p-0.5 rounded-lg border border-[#27272a]">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn("h-6 w-6 rounded-md", mode === 'interactive' && "bg-[#27272a] text-white shadow-sm")} 
                        onClick={() => setMode('interactive')}
                        title="Interactive Mode"
                    >
                        <MousePointer2 className="w-3.5 h-3.5" />
                    </Button>
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn("h-6 w-6 rounded-md", mode === 'inspect' && "bg-[#27272a] text-blue-400 shadow-sm")} 
                        onClick={() => setMode('inspect')}
                        title="Inspector Mode"
                    >
                        <Code className="w-3.5 h-3.5" />
                    </Button>
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn("h-6 w-6 rounded-md", mode === 'design' && "bg-[#27272a] text-purple-400 shadow-sm")} 
                        onClick={() => setMode('design')}
                        title="Design Mode"
                    >
                        <Palette className="w-3.5 h-3.5" />
                    </Button>
                    <div className="w-px h-3 bg-[#27272a] mx-0.5" />
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn("h-6 w-6 rounded-md", mode === '3d' && "bg-[#27272a] text-green-400 shadow-sm")} 
                        onClick={() => setMode('3d')}
                        title="3D/Spatial Mode"
                    >
                        <Cuboid className="w-3.5 h-3.5" />
                    </Button>
                </div>

                <div className="flex items-center gap-2 bg-[#18181b] px-3 py-1 rounded-md border border-[#27272a] text-[11px] text-[#71717a] font-mono min-w-[200px]">
                    <span className={cn("w-2 h-2 rounded-full animate-pulse", activeFile ? "bg-green-500" : "bg-yellow-500")} />
                    localhost:3000
                    <span className="text-[#3f3f46]">/</span>
                    <span className="text-[#a1a1aa] truncate max-w-[100px]">{activeFile || 'index'}</span>
                    <RefreshCw className="w-3 h-3 ml-auto hover:text-white cursor-pointer hover:rotate-180 transition-transform duration-500" />
                </div>

                <div className="flex items-center gap-1">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn("h-7 w-7", viewport === 'desktop' && "text-white bg-[#27272a]")} 
                        onClick={() => setViewport('desktop')}
                    >
                        <Laptop className="w-3.5 h-3.5" />
                    </Button>
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn("h-7 w-7", viewport === 'tablet' && "text-white bg-[#27272a]")} 
                        onClick={() => setViewport('tablet')}
                    >
                        <Tablet className="w-3.5 h-3.5" />
                    </Button>
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        className={cn("h-7 w-7", viewport === 'mobile' && "text-white bg-[#27272a]")} 
                        onClick={() => setViewport('mobile')}
                    >
                        <Smartphone className="w-3.5 h-3.5" />
                    </Button>
                </div>
            </div>

            {/* Canvas Area */}
            <div className="flex-1 overflow-hidden relative bg-[#18181b] flex items-center justify-center p-8 bg-[radial-gradient(#27272a_1px,transparent_1px)] [background-size:16px_16px]">
                <div 
                    ref={containerRef}
                    className={cn(
                        "bg-white h-full transition-all duration-300 shadow-2xl relative overflow-hidden group/preview",
                        viewport === 'desktop' ? "w-full rounded-none border-x border-[#27272a]" : 
                        viewport === 'tablet' ? "w-[768px] h-[1024px] rounded-xl border-[8px] border-[#27272a]" : 
                        "w-[375px] h-[812px] rounded-[3rem] border-[12px] border-[#27272a]"
                    )}
                    style={{ transform: `scale(${scale})` }}
                >
                    <RenderedContent />

                    {/* Drag & Drop Overlays */}
                    {mode === 'design' && (
                        <div className="absolute inset-0 z-40">
                             {/* Simulated Drop Zones */}
                             <div className="absolute top-0 left-0 right-0 h-16 border-2 border-dashed border-blue-500/30 bg-blue-500/5 flex items-center justify-center m-2 rounded-lg opacity-0 hover:opacity-100 transition-opacity pointer-events-auto cursor-copy">
                                <span className="text-xs font-bold text-blue-400">Drop Header Component</span>
                             </div>
                             <div className="absolute bottom-0 left-0 right-0 h-32 border-2 border-dashed border-purple-500/30 bg-purple-500/5 flex items-center justify-center m-2 rounded-lg opacity-0 hover:opacity-100 transition-opacity pointer-events-auto cursor-copy">
                                <span className="text-xs font-bold text-purple-400">Drop Footer / Section</span>
                             </div>
                        </div>
                    )}

                    {/* 3D Mode Overlay */}
                    {mode === '3d' && (
                        <div className="absolute inset-0 z-40 bg-black/80 flex flex-col items-center justify-center text-center p-8 backdrop-blur-sm">
                            <Gamepad2 className="w-12 h-12 text-green-400 mb-4 animate-pulse" />
                            <h3 className="text-xl font-bold text-white mb-2">Spatial Computing View</h3>
                            <p className="text-sm text-gray-400 max-w-xs">
                                3D/4D Rendering Engine active. 
                                Projecting code logic into spatial environment...
                            </p>
                            <div className="mt-6 flex gap-2">
                                <div className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded text-green-400 text-xs">WebGL 2.0</div>
                                <div className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded text-blue-400 text-xs">WebXR</div>
                            </div>
                        </div>
                    )}

                    {/* Inspector Overlay */}
                    {mode !== 'interactive' && (
                        <div className="absolute inset-0 pointer-events-none z-50">
                            {hoveredElement && !selectedElement && (
                                <div 
                                    className="absolute border-2 border-blue-400/50 bg-blue-400/5 transition-all duration-75"
                                    style={{
                                        top: 0, left: 0, right: 0, bottom: 0 // In real impl, would follow rect
                                    }}
                                >
                                    <div className="absolute top-0 left-0 -translate-y-full bg-blue-500 text-white text-[9px] font-mono px-1.5 py-0.5 rounded-t">
                                        {hoveredElement.tag}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {/* Floating Inspector Panel */}
                {selectedElement && (
                    <div className="absolute top-4 right-4 w-64 bg-[#09090b]/90 backdrop-blur-xl border border-[#27272a] rounded-xl shadow-2xl p-4 animate-in slide-in-from-right-4 fade-in duration-200">
                        <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#27272a]">
                            <div className="flex items-center gap-2">
                                <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 text-[10px] font-mono font-bold">
                                    {selectedElement.tag}
                                </span>
                                <span className="text-xs font-medium text-white">Properties</span>
                            </div>
                            <Button variant="ghost" size="icon" className="h-4 w-4" onClick={resetSelection}>
                                <EyeOff className="w-3 h-3" />
                            </Button>
                        </div>
                        
                        <div className="space-y-3">
                            <div>
                                <label className="text-[10px] text-[#71717a] uppercase font-bold">Classes</label>
                                <div className="mt-1 p-2 bg-[#18181b] rounded border border-[#27272a] text-[10px] font-mono text-green-300 break-words">
                                    {selectedElement.styles || 'No classes'}
                                </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                    <label className="text-[10px] text-[#71717a] uppercase font-bold">Layout</label>
                                    <div className="mt-1 flex gap-1">
                                        <div className="h-6 w-6 bg-[#27272a] rounded hover:bg-blue-500/20 cursor-pointer flex items-center justify-center border border-transparent hover:border-blue-500/50"><Box className="w-3 h-3" /></div>
                                        <div className="h-6 w-6 bg-[#27272a] rounded hover:bg-blue-500/20 cursor-pointer flex items-center justify-center border border-transparent hover:border-blue-500/50"><Layers className="w-3 h-3" /></div>
                                    </div>
                                </div>
                                <div>
                                    <label className="text-[10px] text-[#71717a] uppercase font-bold">Typography</label>
                                    <div className="mt-1 flex gap-1">
                                        <div className="h-6 w-6 bg-[#27272a] rounded hover:bg-blue-500/20 cursor-pointer flex items-center justify-center border border-transparent hover:border-blue-500/50"><Type className="w-3 h-3" /></div>
                                    </div>
                                </div>
                            </div>

                            <Button className="w-full h-7 text-[10px] bg-blue-600 hover:bg-blue-500 mt-2">
                                <Edit3 className="w-3 h-3 mr-2" />
                                Edit Source
                            </Button>
                        </div>
                    </div>
                )}
            </div>

            {/* Zoom Controls */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-[#18181b] border border-[#27272a] rounded-full px-2 py-1 flex items-center gap-2 shadow-xl">
                <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => setScale(s => Math.max(0.5, s - 0.1))}>-</Button>
                <span className="text-[10px] font-mono min-w-[3ch] text-center">{Math.round(scale * 100)}%</span>
                <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => setScale(s => Math.min(1.5, s + 0.1))}>+</Button>
            </div>
        </div>
    );
}