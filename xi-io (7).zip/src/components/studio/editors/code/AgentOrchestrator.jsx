import React, { useState, useEffect } from 'react';
import { 
    Cpu, Play, Pause, RotateCw, Terminal, 
    Activity, CheckCircle2, AlertCircle, Clock,
    Bot, Workflow, GitBranch, Shield, Plus, X
} from 'lucide-react';
import ProductIcon from '@/components/brand/ProductIcon';
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from 'sonner';

export default function AgentOrchestrator() {
    const [agents, setAgents] = useState([
        { id: 'a1', name: 'RefactorBot', role: 'Architect', status: 'active', progress: 45, task: 'Restructuring /components/ui', logs: ['Analyzing dependency graph...', 'Identified circular ref in Button.js', 'Refactoring imports...'] },
        { id: 'a2', name: 'TestRunner', role: 'QA', status: 'idle', progress: 0, task: 'Waiting for changes', logs: [] },
        { id: 'a3', name: 'SecuritySentinel', role: 'Security', status: 'active', progress: 78, task: 'Audit: npm packages', logs: ['Scanning package.json', 'Vulnerability found in lodash@4.17.15', 'Suggesting update...'] },
        { id: 'a4', name: 'DocWriter', role: 'Docs', status: 'completed', progress: 100, task: 'Update README.md', logs: ['Generated API docs', 'Updated installation steps', 'Commit created'] },
    ]);
    const [isDeployOpen, setIsDeployOpen] = useState(false);
    const [newAgent, setNewAgent] = useState({ name: '', role: 'Architect', task: '' });

    const handleDeploy = () => {
        if (!newAgent.name) return;
        
        const id = `a${Date.now()}`;
        setAgents(prev => [...prev, {
            id,
            name: newAgent.name,
            role: newAgent.role,
            status: 'active',
            progress: 5,
            task: newAgent.task || 'Initializing...',
            logs: ['Booting agent...', 'Connecting to Neural Core...', 'Task context loaded.']
        }]);
        
        setIsDeployOpen(false);
        setNewAgent({ name: '', role: 'Architect', task: '' });
        toast.success(`${newAgent.name} successfully deployed.`);
    };

    const getStatusColor = (status) => {
        if (status === 'active') return 'text-blue-400 bg-blue-400/10 border-blue-400/20';
        if (status === 'completed') return 'text-green-400 bg-green-400/10 border-green-400/20';
        if (status === 'error') return 'text-red-400 bg-red-400/10 border-red-400/20';
        return 'text-neutral-500 bg-neutral-500/10 border-neutral-500/20';
    };

    return (
        <div className="h-full flex flex-col bg-[#09090b] text-[#e4e4e7] font-mono text-[12px]">
            {/* Header / Toolbar */}
            <div className="h-10 border-b border-[#27272a] bg-[#0c0c0e] flex items-center justify-between px-4 shrink-0">
                <div className="flex items-center gap-3">
                    <ProductIcon id="agents" size="xs" />
                    <span className="font-bold text-[11px] uppercase tracking-wider text-[#71717a]">Agent Orchestration Grid</span>
                    <Badge variant="outline" className="ml-2 bg-purple-500/10 text-purple-400 border-purple-500/20">
                        {agents.filter(a => a.status === 'active').length} Active
                    </Badge>
                </div>
                <div className="flex items-center gap-2">
                    <Dialog open={isDeployOpen} onOpenChange={setIsDeployOpen}>
                        <DialogTrigger asChild>
                            <Button size="sm" variant="outline" className="h-6 text-[10px] bg-[#27272a] border-none hover:bg-[#3f3f46]">
                                <Play className="w-3 h-3 mr-1.5 text-green-400" /> Deploy New Agent
                            </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-[#18181b] border-[#27272a] text-[#e4e4e7]">
                            <DialogHeader>
                                <DialogTitle>Deploy Autonomous Agent</DialogTitle>
                                <DialogDescription className="text-[#a1a1aa]">
                                    Configure a new AI agent to perform tasks in the background.
                                </DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                                <div className="grid gap-2">
                                    <Label htmlFor="name" className="text-xs">Agent Name</Label>
                                    <Input 
                                        id="name" 
                                        value={newAgent.name}
                                        onChange={(e) => setNewAgent({...newAgent, name: e.target.value})}
                                        className="bg-[#09090b] border-[#27272a]" 
                                        placeholder="e.g. BugHunter" 
                                    />
                                </div>
                                <div className="grid gap-2">
                                    <Label htmlFor="role" className="text-xs">Role</Label>
                                    <Select 
                                        value={newAgent.role} 
                                        onValueChange={(val) => setNewAgent({...newAgent, role: val})}
                                    >
                                        <SelectTrigger className="bg-[#09090b] border-[#27272a]">
                                            <SelectValue placeholder="Select role" />
                                        </SelectTrigger>
                                        <SelectContent className="bg-[#18181b] border-[#27272a] text-[#e4e4e7]">
                                            <SelectItem value="Architect">Architect</SelectItem>
                                            <SelectItem value="QA">QA Engineer</SelectItem>
                                            <SelectItem value="Security">Security Specialist</SelectItem>
                                            <SelectItem value="Docs">Technical Writer</SelectItem>
                                            <SelectItem value="DevOps">DevOps Engineer</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="grid gap-2">
                                    <Label htmlFor="task" className="text-xs">Initial Task</Label>
                                    <Input 
                                        id="task" 
                                        value={newAgent.task}
                                        onChange={(e) => setNewAgent({...newAgent, task: e.target.value})}
                                        className="bg-[#09090b] border-[#27272a]" 
                                        placeholder="e.g. Scan for unused imports" 
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={() => setIsDeployOpen(false)} className="bg-transparent border-[#27272a] text-[#a1a1aa] hover:bg-[#27272a]">Cancel</Button>
                                <Button onClick={handleDeploy} className="bg-purple-600 hover:bg-purple-500 text-white">Deploy Agent</Button>
                            </DialogFooter>
                        </DialogContent>
                    </Dialog>
                </div>
            </div>

            {/* Agent Grid */}
            <div className="flex-1 overflow-auto p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {agents.map(agent => (
                    <div key={agent.id} className="bg-[#18181b] border border-[#27272a] rounded-lg overflow-hidden flex flex-col hover:border-[#3f3f46] transition-colors group">
                        {/* Agent Header */}
                        <div className="p-3 border-b border-[#27272a] flex items-center justify-between bg-[#0c0c0e]">
                            <div className="flex items-center gap-3">
                                <div className={cn("w-2 h-2 rounded-full animate-pulse", 
                                    agent.status === 'active' ? "bg-blue-400" : 
                                    agent.status === 'completed' ? "bg-green-400" : "bg-neutral-600"
                                )} />
                                <div>
                                    <div className="font-bold text-white leading-none">{agent.name}</div>
                                    <div className="text-[10px] text-[#71717a] mt-1 flex items-center gap-1">
                                        {agent.role === 'Architect' && <Cpu className="w-3 h-3" />}
                                        {agent.role === 'QA' && <CheckCircle2 className="w-3 h-3" />}
                                        {agent.role === 'Security' && <Shield className="w-3 h-3" />}
                                        {agent.role}
                                    </div>
                                </div>
                            </div>
                            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button size="icon" variant="ghost" className="h-6 w-6"><Pause className="w-3 h-3" /></Button>
                                <Button size="icon" variant="ghost" className="h-6 w-6"><RotateCw className="w-3 h-3" /></Button>
                            </div>
                        </div>

                        {/* Agent Body */}
                        <div className="p-3 flex-1 flex flex-col gap-3">
                            <div>
                                <div className="flex justify-between text-[10px] mb-1 text-[#a1a1aa]">
                                    <span>Current Task</span>
                                    <span>{agent.progress}%</span>
                                </div>
                                <div className="h-1.5 w-full bg-[#27272a] rounded-full overflow-hidden">
                                    <div 
                                        className={cn("h-full transition-all duration-500", 
                                            agent.status === 'completed' ? "bg-green-500" : "bg-blue-500"
                                        )}
                                        style={{ width: `${agent.progress}%` }}
                                    />
                                </div>
                                <div className="mt-1 text-[11px] truncate text-white">{agent.task}</div>
                            </div>

                            <div className="flex-1 bg-[#09090b] rounded border border-[#27272a] p-2 overflow-y-auto h-24 scrollbar-none">
                                {agent.logs.length > 0 ? (
                                    agent.logs.map((log, i) => (
                                        <div key={i} className="text-[10px] text-[#71717a] mb-0.5 font-mono">
                                            <span className="text-[#3f3f46] mr-2">{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                            {log}
                                        </div>
                                    ))
                                ) : (
                                    <div className="text-[10px] text-[#3f3f46] italic">System initialized. Waiting for task...</div>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
                
                {/* Add Agent Card (Shortcut) */}
                <div 
                    className="bg-[#18181b]/50 border border-[#27272a] border-dashed rounded-lg flex flex-col items-center justify-center gap-3 p-6 cursor-pointer hover:bg-[#18181b] hover:border-[#3f3f46] transition-all text-[#52525b] hover:text-[#a1a1aa]"
                    onClick={() => setIsDeployOpen(true)}
                >
                    <div className="w-10 h-10 rounded-full bg-[#27272a] flex items-center justify-center">
                        <Bot className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-medium">Provision New Agent</span>
                </div>
            </div>
        </div>
    );
}