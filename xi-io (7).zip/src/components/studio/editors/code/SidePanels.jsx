import React, { useState } from 'react';
import { 
    Search, GitBranch, Folder, MoreHorizontal, 
    ChevronRight, ChevronDown, FileCode, FileJson, FileType, 
    Settings, RefreshCw, Plus, X, Command,
    Box, Download, Star, ExternalLink
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export const FileIcon = ({ name, className }) => {
    if (name.endsWith('.js') || name.endsWith('.jsx')) return <FileCode className={cn("w-4 h-4 text-yellow-400", className)} />;
    if (name.endsWith('.css')) return <FileType className={cn("w-4 h-4 text-blue-400", className)} />;
    if (name.endsWith('.json')) return <FileJson className={cn("w-4 h-4 text-orange-400", className)} />;
    if (name.endsWith('.md')) return <FileType className={cn("w-4 h-4 text-purple-400", className)} />;
    return <FileType className={cn("w-4 h-4 text-neutral-500", className)} />;
};

const FileTreeItem = ({ name, item, level = 0, activeFile, onSelect }) => {
    const [isOpen, setIsOpen] = useState(true);
    const indent = level * 12 + 12;

    if (item.type === 'folder') {
        return (
            <div>
                <div 
                    className="flex items-center gap-1.5 py-1 hover:bg-[#2a2a2b] cursor-pointer text-neutral-400 hover:text-neutral-200 transition-colors select-none"
                    style={{ paddingLeft: indent }}
                    onClick={() => setIsOpen(!isOpen)}
                >
                    {isOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                    <Folder className={cn("w-3.5 h-3.5", isOpen ? "text-blue-400" : "text-blue-300")} />
                    <span className="text-[11px] font-medium">{name}</span>
                </div>
                {isOpen && (
                    <div>
                        {Object.entries(item.children).map(([childName, childItem]) => (
                            <FileTreeItem 
                                key={childName} 
                                name={childName} 
                                item={childItem} 
                                level={level + 1} 
                                activeFile={activeFile}
                                onSelect={onSelect}
                            />
                        ))}
                    </div>
                )}
            </div>
        );
    }

    return (
        <div 
            className={cn(
                "flex items-center gap-2 py-1 cursor-pointer transition-colors select-none border-l-2 border-transparent",
                activeFile === name 
                    ? "bg-[#37373d] text-white border-blue-500" 
                    : "hover:bg-[#2a2a2b] text-neutral-400 hover:text-neutral-200"
            )}
            style={{ paddingLeft: indent }}
            onClick={() => onSelect(name)}
        >
            <FileIcon name={name} />
            <span className="text-[11px]">{name}</span>
            {activeFile === name && <span className="ml-auto mr-2 text-[9px] opacity-50">M</span>}
        </div>
    );
};

export const ExplorerPanel = ({ files, activeFile, onSelect }) => (
    <div className="flex flex-col h-full">
        <div className="h-9 px-4 flex items-center justify-between text-[10px] font-bold text-neutral-500 uppercase tracking-wider bg-[#1e1e1e]">
            <span>Explorer</span>
            <MoreHorizontal className="w-3 h-3 cursor-pointer hover:text-white" />
        </div>
        <div className="p-2">
            <div className="text-[10px] font-bold text-blue-400 mb-2 px-2">OPEN EDITORS</div>
            <div className="space-y-0.5 mb-4">
                {['App.js', 'index.css'].map(f => (
                    <div key={f} className="flex items-center gap-2 px-2 py-1 hover:bg-[#2a2a2b] cursor-pointer text-neutral-300 text-[11px] group">
                        <span className="opacity-0 group-hover:opacity-100 hover:bg-neutral-700 rounded p-0.5"><X className="w-3 h-3" /></span>
                        <FileIcon name={f} className="w-3 h-3" />
                        {f}
                    </div>
                ))}
            </div>
            
            <div className="mb-4">
                <div className="text-[10px] font-bold text-purple-400 mb-1 px-2 flex justify-between">
                    <span>ACTIVE AGENTS</span>
                    <span className="bg-purple-500/20 text-purple-300 px-1 rounded text-[9px]">2</span>
                </div>
                <div className="space-y-0.5 opacity-80">
                    <div className="flex items-center gap-2 px-2 py-1 hover:bg-[#2a2a2b] cursor-pointer text-neutral-300 text-[11px]">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                        <span>RefactorBot</span>
                    </div>
                    <div className="flex items-center gap-2 px-2 py-1 hover:bg-[#2a2a2b] cursor-pointer text-neutral-300 text-[11px]">
                        <div className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
                        <span>TestRunner</span>
                    </div>
                </div>
                <div className="mt-2 px-2">
                    <div className="text-[9px] text-neutral-500 border-t border-white/5 pt-1">View full grid in panel ↓</div>
                </div>
            </div>

            <div className="text-[10px] font-bold text-neutral-500 mb-1 px-2 uppercase flex justify-between group cursor-pointer">
                <span>Project Titan</span>
            </div>
            <div className="space-y-0.5">
                {Object.entries(files).map(([name, item]) => (
                    <FileTreeItem key={name} name={name} item={item} activeFile={activeFile} onSelect={onSelect} />
                ))}
            </div>
        </div>
    </div>
);

export const SearchPanel = () => (
    <div className="flex flex-col h-full">
        <div className="h-9 px-4 flex items-center text-[10px] font-bold text-neutral-500 uppercase tracking-wider bg-[#1e1e1e]">
            Search
        </div>
        <div className="p-4 space-y-4">
            <div className="space-y-2">
                <div className="relative">
                    <Input 
                        placeholder="Search" 
                        className="bg-[#2a2a2b] border-[#3e3e42] h-8 text-[11px] focus:border-blue-500 pl-7" 
                    />
                    <ChevronRight className="w-3.5 h-3.5 absolute left-2 top-2.5 text-neutral-500" />
                </div>
                <div className="relative">
                    <Input 
                        placeholder="Replace" 
                        className="bg-[#2a2a2b] border-[#3e3e42] h-8 text-[11px] focus:border-blue-500 pl-7" 
                    />
                    <Command className="w-3.5 h-3.5 absolute left-2 top-2.5 text-neutral-500" />
                </div>
            </div>
            <div className="text-[11px] text-neutral-500 text-center py-8">
                No results found.
            </div>
        </div>
    </div>
);

export const GitPanel = () => (
    <div className="flex flex-col h-full">
        <div className="h-9 px-4 flex items-center justify-between text-[10px] font-bold text-neutral-500 uppercase tracking-wider bg-[#1e1e1e]">
            <span>Source Control</span>
            <div className="flex gap-2">
                <RefreshCw className="w-3 h-3 cursor-pointer hover:text-white" />
                <Plus className="w-3 h-3 cursor-pointer hover:text-white" />
            </div>
        </div>
        <div className="p-4 space-y-4">
            <Input 
                placeholder="Message (Cmd+Enter to commit)" 
                className="bg-[#2a2a2b] border-[#3e3e42] h-8 text-[11px] focus:border-blue-500" 
            />
            <Button className="w-full bg-blue-600 hover:bg-blue-500 h-7 text-[11px] font-bold">
                Commit & Push
            </Button>
            
            <div className="space-y-2 mt-4">
                <div className="flex items-center justify-between text-[10px] text-neutral-400 px-1">
                    <span>Changes</span>
                    <Badge variant="outline" className="text-[9px] h-4 border-[#3e3e42] text-neutral-400">3</Badge>
                </div>
                {['App.js', 'styles.css', 'README.md'].map(file => (
                    <div key={file} className="flex items-center gap-2 px-2 py-1 hover:bg-[#2a2a2b] cursor-pointer text-neutral-300 text-[11px] group">
                        <GitBranch className="w-3 h-3 text-yellow-500" />
                        {file}
                        <span className="ml-auto text-[9px] text-neutral-500">M</span>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100">
                            <Plus className="w-3 h-3 hover:text-white" />
                            <RefreshCw className="w-3 h-3 hover:text-white" />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </div>
);

export const ExtensionsPanel = () => (
    <div className="flex flex-col h-full">
        <div className="h-9 px-4 flex items-center justify-between text-[10px] font-bold text-neutral-500 uppercase tracking-wider bg-[#1e1e1e]">
            <span>Marketplace</span>
            <RefreshCw className="w-3 h-3 cursor-pointer hover:text-white" />
        </div>
        <div className="p-2 space-y-4 overflow-y-auto">
            
            {/* Installed Section */}
            <div>
                 <div className="text-[10px] font-bold text-blue-400 mb-2 px-2">INSTALLED SKILLS</div>
                 <div className="space-y-1">
                    {[
                        { name: 'React IntelliSense', version: 'v1.2.0', downloads: '4.5M', icon: FileCode },
                        { name: 'Tailwind CSS', version: 'v3.0.1', downloads: '2.1M', icon: FileType },
                        { name: 'Prettier', version: 'v9.1.0', downloads: '10M', icon: Star }
                    ].map((ext, i) => (
                        <div key={i} className="flex gap-3 p-2 hover:bg-[#2a2a2b] cursor-pointer rounded group">
                            <div className="w-8 h-8 bg-[#3e3e42] rounded flex items-center justify-center shrink-0">
                                <ext.icon className="w-4 h-4 text-[#a1a1aa]" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-center">
                                    <span className="text-[11px] font-bold text-[#e4e4e7] truncate">{ext.name}</span>
                                    <span className="text-[9px] text-neutral-500">{ext.version}</span>
                                </div>
                                <div className="flex items-center gap-2 mt-0.5">
                                    <span className="text-[9px] text-[#71717a] flex items-center gap-1">
                                        <Download className="w-2.5 h-2.5" /> {ext.downloads}
                                    </span>
                                    <div className="flex gap-0.5 ml-auto opacity-0 group-hover:opacity-100">
                                        <Settings className="w-3 h-3 text-neutral-400 hover:text-white" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                 </div>
            </div>

            {/* Recommendations */}
            <div>
                 <div className="text-[10px] font-bold text-purple-400 mb-2 px-2">RECOMMENDED FOR YOU</div>
                 <div className="space-y-1">
                    {[
                        { name: 'Docker Explorer', desc: 'Manage containers', icon: Box },
                        { name: 'Python Pro', desc: 'Advanced linting', icon: FileCode },
                        { name: 'Vim Mode', desc: 'Legacy keybindings', icon: Command }
                    ].map((ext, i) => (
                        <div key={i} className="flex gap-3 p-2 hover:bg-[#2a2a2b] cursor-pointer rounded group opacity-80 hover:opacity-100">
                            <div className="w-8 h-8 bg-[#3e3e42] rounded flex items-center justify-center shrink-0">
                                <ext.icon className="w-4 h-4 text-[#a1a1aa]" />
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-center">
                                    <span className="text-[11px] font-bold text-[#e4e4e7] truncate">{ext.name}</span>
                                    <Button size="sm" className="h-4 px-1.5 text-[9px] bg-blue-600 hover:bg-blue-500">Install</Button>
                                </div>
                                <div className="text-[9px] text-[#71717a] truncate mt-0.5">{ext.desc}</div>
                            </div>
                        </div>
                    ))}
                 </div>
            </div>
            
            <div className="pt-2 border-t border-[#2a2a2b]">
                <Button variant="ghost" className="w-full text-[10px] text-neutral-500 hover:text-white">
                    <ExternalLink className="w-3 h-3 mr-2" /> Browse Full Marketplace
                </Button>
            </div>

        </div>
    </div>
);