import React, { useState, useRef, useEffect } from 'react';
import { 
    Send, Paperclip, Mic, Image, X, Bot, User, Code, Terminal, 
    Sparkles, Zap, ChevronDown, Book, FileText, Hash, Globe,
    ArrowRight, History, Layers, PenTool, Brain, Copy, Check,
    MessageSquare, AlertCircle, Loader2, Download
} from 'lucide-react';
import ProductIcon from '@/components/brand/ProductIcon';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { Plus } from 'lucide-react';

// --- CHERRY STUDIO FEATURES ---
const StacksView = ({ stacks, onLoad }) => (
    <div className="p-4 space-y-4">
        <div className="text-[10px] font-bold text-[#71717a] uppercase tracking-wider mb-2">Saved Stacks</div>
        {stacks.map((stack, i) => (
            <div 
                key={i} 
                onClick={() => onLoad(stack)}
                className="bg-[#18181b] border border-[#27272a] p-3 rounded-lg hover:border-purple-500/50 cursor-pointer group transition-all relative"
            >
                <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-white group-hover:text-purple-400">{stack.name}</span>
                    <div className="flex gap-2">
                        <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-5 w-5 hover:bg-white/10" 
                            onClick={(e) => { e.stopPropagation(); navigator.clipboard.writeText(JSON.stringify(stack.content)); toast.success("Stack copied to clipboard"); }}
                        >
                            <Copy className="w-3 h-3 text-[#52525b] hover:text-white" />
                        </Button>
                        <Layers className="w-3 h-3 text-[#52525b]" />
                    </div>
                </div>
                <div className="flex items-center justify-between text-[10px] text-[#71717a]">
                    <span className="capitalize">{stack.type}</span>
                    <span>{new Date(stack.date).toLocaleDateString()}</span>
                </div>
            </div>
        ))}
        {stacks.length === 0 && <div className="text-xs text-[#52525b] text-center py-4">No saved stacks yet. Save a conversation to start.</div>}
    </div>
);

const NotepadView = () => (
    <div className="h-full flex flex-col">
        <div className="p-2 border-b border-[#27272a] flex justify-between items-center bg-[#18181b]">
            <span className="text-[10px] font-bold text-[#71717a] uppercase px-2">Scratchpad</span>
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => toast.success('Copied to clipboard')}><Copy className="w-3 h-3" /></Button>
        </div>
        <textarea 
            className="flex-1 bg-[#09090b] text-[#a1a1aa] p-4 text-xs font-mono resize-none focus:outline-none"
            placeholder="// Paste snippets, prompt ideas, or temporary code here..."
            defaultValue="// TODO: Refactor the auth middleware&#10;// Remember to check JWT expiration&#10;// PROMPT IDEA: Refactor this component to use React.memo for performance"
        />
    </div>
);

const KnowledgeView = () => (
    <div className="p-4 space-y-4">
         <div className="text-[10px] font-bold text-[#71717a] uppercase tracking-wider mb-2">Project Knowledge</div>
         <div className="space-y-2">
            {[
                { name: 'Pipeline Context', icon: Globe, color: 'text-purple-400' },
                { name: 'System Design', icon: Book, color: 'text-blue-400' },
                { name: 'API Contracts', icon: FileText, color: 'text-green-400' },
                { name: 'Brand Guidelines', icon: Image, color: 'text-pink-400' },
                { name: 'Database Schema', icon: Layers, color: 'text-yellow-400' },
            ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 p-2 rounded hover:bg-[#27272a] cursor-pointer group">
                    <item.icon className={cn("w-4 h-4", item.color)} />
                    <span className="text-xs text-[#e4e4e7] group-hover:text-white transition-colors">{item.name}</span>
                </div>
            ))}
         </div>
         <Button variant="outline" className="w-full text-xs border-dashed border-[#27272a] hover:border-[#3f3f46] text-[#71717a] hover:text-[#a1a1aa] h-8">
            <Plus className="w-3 h-3 mr-2" /> Add Knowledge Source
         </Button>
    </div>
);

export default function ChatInterface({ selectedModel, activeFile }) {
    const [activeTab, setActiveTab] = useState('chat'); // chat, stacks, notepad, knowledge
    const [messages, setMessages] = useState([
        { 
            role: 'assistant', 
            content: "I'm ready to help you architect your code. I have full context of your codebase. Try '/agent' to deploy an autonomous worker.", 
            type: 'text',
            context: ['codebase', 'docs', 'memory']
        }
    ]);
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [stacks, setStacks] = useState([
        { name: 'React + Vite Config', type: 'setup', date: Date.now() - 172800000 },
        { name: 'Auth Flow Logic', type: 'logic', date: Date.now() - 18000000 }
    ]);
    const endRef = useRef(null);

    const handleSend = async () => {
        if (!input.trim()) return;
        
        const userMsg = { role: 'user', content: input, type: 'text' };
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsTyping(true);
        
        try {
            // Attempt to use real LLM
            try {
                // This requires the app to have the 'Core' integration and proper configuration
                // We wrap in try/catch to fall back to simulation if it fails (e.g. no API key)
                const result = await base44.integrations.Core.InvokeLLM({
                    prompt: `You are an expert software architect and coding assistant using the ${selectedModel?.name || 'Standard'} model. 
                    The user is asking: "${input}". 
                    Current active file: ${activeFile}
                    
                    Provide a helpful, concise response. 
                    If code is requested, provide it in a markdown code block.
                    Assume context of a React/Node.js project.
                    `,
                    // We don't have real file context here, but we can simulate it in the prompt
                });
                
                // Parse result if it's a string, or use directly
                const content = typeof result === 'string' ? result : (result.output || result);
                
                setMessages(prev => [...prev, {
                    role: 'assistant',
                    content: content,
                    type: content.includes('```') ? 'code' : 'text',
                    context: [selectedModel?.provider || 'Neural Core']
                }]);
                
            } catch (err) {
                console.warn("LLM Call failed, falling back to simulation:", err);
                // FALLBACK SIMULATION
                setTimeout(() => {
                    const isCodeRequest = input.toLowerCase().match(/code|create|refactor|function|component/);
                    let responseContent = [];
                    
                    if (isCodeRequest) {
                        responseContent = [
                            { 
                                role: 'assistant', 
                                content: `I've drafted a solution using ${selectedModel?.name || 'Neural Core'}. This component uses \`framer-motion\` for transitions and \`tanstack-query\` for state management.`,
                                type: 'text',
                                context: ['SystemDesign.js', 'package.json']
                            }, 
                            {
                                role: 'assistant', 
                                content: `// Optimized Component
import React from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';

export default function ArchitectComponent({ id }) {
  const { data, isLoading } = useQuery({
    queryKey: ['entity', id],
    queryFn: () => fetchEntity(id)
  });

  if (isLoading) return <div className="animate-pulse bg-neutral-900 h-32 rounded-lg" />;

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }}
      className="p-4 border border-white/10 rounded-lg bg-black/50 backdrop-blur"
    >
      <h3 className="text-lg font-bold text-white">{data?.title}</h3>
      <div className="mt-2 text-sm text-neutral-400">
        {/* Advanced logic here */}
        {data?.description}
      </div>
    </motion.div>
  );
}`,
                                type: 'code',
                                lang: 'jsx'
                            }
                        ];
                    } else {
                        responseContent = [{
                            role: 'assistant',
                            content: `I'm listening on the ${selectedModel?.name || 'Standard'} channel. I can help with code generation, refactoring, debugging, or architectural planning.`,
                            type: 'text',
                            context: ['Memory']
                        }];
                    }
                    setMessages(prev => [...prev, ...responseContent]);
                }, 1000);
            }
        } catch (error) {
            setMessages(prev => [...prev, { role: 'assistant', content: "Connection to Neural Core failed.", type: 'error' }]);
        } finally {
            setIsTyping(false);
        }
    };

    const saveStack = () => {
        if (messages.length < 2) return;
        const newStack = { 
            name: input.trim() ? input.substring(0, 20) + '...' : `Stack ${stacks.length + 1}`, 
            type: 'conversation', 
            date: Date.now(),
            content: messages 
        };
        setStacks(prev => [newStack, ...prev]);
        toast.success('Conversation saved to Stacks');
    };

    const loadStack = (stack) => {
        // In a real app this would load the conversation context
        toast.info(`Loaded stack: ${stack.name}`);
        // Simulate loading context for next prompt
        setMessages(prev => [...prev, { 
            role: 'system', 
            content: `Context loaded from stack: ${stack.name}`, 
            type: 'info' 
        }]);
    };

    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isTyping]);

    return (
        <div className="flex flex-col h-full bg-[#0c0c0e] text-[#e4e4e7]">
            {/* Advanced Chat Toolbar (Cherry Studio Style) */}
            <div className="flex items-center border-b border-[#27272a] bg-[#0c0c0e]">
                <div className="px-3 border-r border-[#27272a] flex items-center justify-center h-full">
                    <ProductIcon id="chat" size="xs" />
                </div>
                <button 
                    onClick={() => setActiveTab('chat')}
                    className={cn("flex-1 py-3 text-[10px] font-bold uppercase tracking-wider border-b-2 transition-colors", activeTab === 'chat' ? "border-purple-500 text-white" : "border-transparent text-[#71717a] hover:text-[#a1a1aa]")}
                >
                    Chat
                </button>
                <button 
                    onClick={() => setActiveTab('stacks')}
                    className={cn("flex-1 py-3 text-[10px] font-bold uppercase tracking-wider border-b-2 transition-colors", activeTab === 'stacks' ? "border-purple-500 text-white" : "border-transparent text-[#71717a] hover:text-[#a1a1aa]")}
                >
                    Stacks
                </button>
                <button 
                    onClick={() => setActiveTab('notepad')}
                    className={cn("flex-1 py-3 text-[10px] font-bold uppercase tracking-wider border-b-2 transition-colors", activeTab === 'notepad' ? "border-purple-500 text-white" : "border-transparent text-[#71717a] hover:text-[#a1a1aa]")}
                >
                    Notes
                </button>
                <button 
                    onClick={() => setActiveTab('knowledge')}
                    className={cn("flex-1 py-3 text-[10px] font-bold uppercase tracking-wider border-b-2 transition-colors", activeTab === 'knowledge' ? "border-purple-500 text-white" : "border-transparent text-[#71717a] hover:text-[#a1a1aa]")}
                >
                    Context
                </button>
            </div>

            {/* TAB CONTENT */}
            {activeTab !== 'chat' ? (
                <div className="flex-1 overflow-y-auto bg-[#09090b]">
                    {activeTab === 'stacks' && <StacksView stacks={stacks} onLoad={loadStack} />}
                    {activeTab === 'notepad' && <NotepadView />}
                    {activeTab === 'knowledge' && <KnowledgeView />}
                </div>
            ) : (
                <>
                    {/* Context Header */}
                    <div className="px-4 py-2 border-b border-[#27272a] bg-[#0c0c0e] flex items-center justify-between overflow-x-auto scrollbar-none">
                        <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold text-[#71717a] uppercase tracking-wider shrink-0">Context:</span>
                            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#27272a] rounded-full text-[10px] text-blue-300 border border-blue-500/20 shrink-0 cursor-pointer hover:bg-[#3f3f46]">
                                <Code className="w-3 h-3" /> @Codebase
                            </div>
                            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-[#27272a] rounded-full text-[10px] text-green-300 border border-green-500/20 shrink-0 cursor-pointer hover:bg-[#3f3f46]">
                                <Book className="w-3 h-3" /> @Docs
                            </div>
                        </div>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 text-[#71717a] hover:text-purple-400"
                            onClick={saveStack}
                            title="Save Stack"
                        >
                            <Layers className="w-3.5 h-3.5" />
                        </Button>
                    </div>

                    {/* Messages */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-6">
                        {messages.map((msg, i) => (
                            <div key={i} className={cn("flex gap-3 group", msg.role === 'user' ? "flex-row-reverse" : "flex-row")}>
                                <div className={cn(
                                    "w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border shadow-sm",
                                    msg.role === 'assistant' 
                                        ? "bg-gradient-to-br from-purple-900 to-indigo-900 border-purple-500/30 text-white" 
                                        : "bg-[#27272a] border-[#3f3f46] text-[#a1a1aa]"
                                )}>
                                    {msg.role === 'assistant' ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                                </div>
                                <div className={cn(
                                    "max-w-[90%] text-[13px] leading-relaxed space-y-2",
                                    msg.role === 'user' ? "text-right" : "text-left"
                                )}>
                                    {msg.context && msg.role === 'assistant' && (
                                        <div className="flex items-center justify-between mb-1 opacity-50 text-[10px] w-full">
                                            <div className="flex gap-1">
                                                {msg.context.map(c => (
                                                    <span key={c} className="flex items-center gap-1"><FileText className="w-3 h-3" /> {c}</span>
                                                ))}
                                            </div>
                                            <button className="hover:text-white flex items-center gap-1" title="Generate Report">
                                                <Download className="w-3 h-3" />
                                            </button>
                                        </div>
                                    )}
                                    
                                    {(msg.type === 'code' || msg.content.includes('```')) ? (
                                        <div className="font-mono text-[12px] bg-[#18181b] rounded-lg overflow-hidden border border-[#27272a] shadow-lg group-hover:border-purple-500/30 transition-colors">
                                            <div className="flex items-center justify-between px-3 py-1.5 bg-[#27272a] border-b border-[#18181b]">
                                                <span className="text-[10px] text-[#a1a1aa]">{msg.lang || 'code'}</span>
                                                <div className="flex gap-2">
                                                    <button 
                                                        onClick={() => { navigator.clipboard.writeText(msg.content); toast.success('Copied to clipboard'); }}
                                                        className="text-[10px] text-[#a1a1aa] hover:text-white flex items-center gap-1 transition-colors"
                                                    >
                                                        <Copy className="w-3 h-3" /> Copy
                                                    </button>
                                                    <button className="text-[10px] text-green-400 hover:text-green-300 flex items-center gap-1 transition-colors"><Zap className="w-3 h-3" /> Apply</button>
                                                </div>
                                            </div>
                                            <div className="p-3 overflow-x-auto text-blue-100">
                                                <pre>{msg.content.replace(/```\w*\n?|```/g, '')}</pre>
                                            </div>
                                        </div>
                                    ) : (
                                        <div className={cn(
                                            "px-4 py-2 rounded-2xl inline-block",
                                            msg.role === 'user' ? "bg-[#27272a] text-[#e4e4e7]" : "text-[#d4d4d8]"
                                        )}>
                                            {msg.content}
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                        {isTyping && (
                            <div className="flex gap-3">
                                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-900 to-indigo-900 border border-purple-500/30 flex items-center justify-center shrink-0">
                                    <Bot className="w-4 h-4 text-white animate-pulse" />
                                </div>
                                <div className="flex items-center gap-1 pt-2">
                                    <div className="w-1.5 h-1.5 bg-[#52525b] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                    <div className="w-1.5 h-1.5 bg-[#52525b] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                    <div className="w-1.5 h-1.5 bg-[#52525b] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                                </div>
                            </div>
                        )}
                        <div ref={endRef} />
                    </div>

                    {/* Input Area */}
                    <div className="p-4 bg-[#09090b] border-t border-[#27272a]">
                        <div className="relative bg-[#18181b] border border-[#27272a] rounded-xl focus-within:border-purple-500/50 focus-within:ring-1 focus-within:ring-purple-500/20 transition-all shadow-sm">
                            {/* Command Pills Overlay (if slash typed) */}
                            {input === '/' && (
                                <div className="absolute bottom-full left-0 w-64 bg-[#18181b] border border-[#27272a] rounded-lg shadow-xl mb-2 p-1 overflow-hidden animate-in slide-in-from-bottom-2 fade-in duration-200 z-50">
                                    {[
                                        { icon: Code, label: 'Generate', desc: 'Write new code' },
                                        { icon: Bot, label: 'Explain', desc: 'Explain selection' },
                                        { icon: Terminal, label: 'Terminal', desc: 'Run command' },
                                        { icon: Zap, label: 'Fix', desc: 'Fix bugs' },
                                        { icon: Brain, label: 'Agent', desc: 'Delegate to Agent' },
                                    ].map(cmd => (
                                        <button key={cmd.label} className="w-full flex items-center gap-3 px-2 py-1.5 hover:bg-[#27272a] rounded text-left group">
                                            <div className="w-5 h-5 rounded bg-[#27272a] group-hover:bg-[#3f3f46] flex items-center justify-center">
                                                <cmd.icon className="w-3 h-3 text-[#a1a1aa]" />
                                            </div>
                                            <div>
                                                <div className="text-[11px] font-bold text-[#e4e4e7]">{cmd.label}</div>
                                                <div className="text-[9px] text-[#71717a]">{cmd.desc}</div>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            )}

                            <textarea 
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
                                placeholder="Ask anything (Cmd+K) or type '/' for commands..."
                                className="w-full bg-transparent border-none text-[13px] text-[#e4e4e7] p-3 min-h-[44px] max-h-32 resize-none focus:ring-0 placeholder:text-[#52525b]"
                            />
                            
                            <div className="flex items-center justify-between p-2 pt-0 border-t border-[#27272a]/50 mt-1">
                                <div className="flex gap-1">
                                    <Button variant="ghost" size="icon" className="h-6 w-6 text-[#71717a] hover:text-[#e4e4e7] hover:bg-white/5"><Paperclip className="w-3.5 h-3.5" /></Button>
                                    <Button variant="ghost" size="icon" className="h-6 w-6 text-[#71717a] hover:text-[#e4e4e7] hover:bg-white/5"><Image className="w-3.5 h-3.5" /></Button>
                                    <div className="w-px h-4 bg-[#27272a] mx-1 my-auto" />
                                    <Button variant="ghost" size="icon" className="h-6 w-6 text-[#71717a] hover:text-[#e4e4e7] hover:bg-white/5"><Hash className="w-3.5 h-3.5" /></Button>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="text-[10px] text-[#52525b] hidden sm:inline-block">RETURN to send</span>
                                    <Button 
                                        size="icon" 
                                        className={cn("h-6 w-6 rounded-md transition-all", input.trim() ? "bg-purple-600 text-white hover:bg-purple-500 shadow-md shadow-purple-500/20" : "bg-[#27272a] text-[#52525b]")}
                                        onClick={handleSend}
                                    >
                                        <ArrowRight className="w-3.5 h-3.5" />
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}