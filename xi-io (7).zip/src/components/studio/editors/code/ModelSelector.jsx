import React from 'react';
import { ChevronDown, Cpu, Sparkles, Zap, Lock, Globe, Server, Cloud, Brain, Activity } from 'lucide-react';
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent
} from "@/components/ui/dropdown-menu";

export default function ModelSelector({ activeModel, onSelect }) {
    const current = activeModel || { id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', provider: 'Anthropic', icon: Sparkles };

    return (
        <DropdownMenu>
            <DropdownMenuTrigger className="w-full outline-none">
                <div className="flex items-center justify-between bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] rounded-lg px-3 py-2 transition-colors cursor-pointer group">
                    <div className="flex items-center gap-3 overflow-hidden">
                        <div className="w-6 h-6 rounded bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shrink-0 shadow-lg shadow-purple-500/20">
                            {current.icon ? <current.icon className="w-3.5 h-3.5 text-white" /> : <Sparkles className="w-3.5 h-3.5 text-white" />}
                        </div>
                        <div className="flex flex-col items-start truncate">
                            <span className="text-[11px] font-bold text-white leading-none">{current.name}</span>
                            <span className="text-[9px] text-[#71717a] group-hover:text-[#a1a1aa] transition-colors">{current.provider}</span>
                        </div>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-[#71717a]" />
                </div>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-72 bg-[#18181b] border-[#27272a] text-[#e4e4e7] p-2">
                <DropdownMenuLabel className="text-[10px] text-[#71717a] uppercase tracking-wider mb-2">Intelligence Models</DropdownMenuLabel>
                
                <div className="mb-2">
                    <div className="text-[10px] font-bold text-[#52525b] px-2 mb-1">PROPRIETARY SOTA</div>
                    <DropdownMenuItem 
                        onClick={() => onSelect({ id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', provider: 'Anthropic', icon: Sparkles })}
                        className="focus:bg-[#27272a] focus:text-white cursor-pointer py-2 rounded-md"
                    >
                        <div className="flex items-center gap-3">
                            <Sparkles className="w-4 h-4 text-purple-400" />
                            <div className="flex flex-col">
                                <span className="text-xs font-medium">Claude 3.5 Sonnet</span>
                                <span className="text-[9px] text-[#71717a]">Anthropic • Best for Coding</span>
                            </div>
                            <Server className="w-3 h-3 text-green-500 ml-auto" />
                        </div>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                        onClick={() => onSelect({ id: 'gpt-4o', name: 'GPT-4o', provider: 'OpenAI', icon: Zap })}
                        className="focus:bg-[#27272a] focus:text-white cursor-pointer py-2 rounded-md"
                    >
                        <div className="flex items-center gap-3">
                            <Zap className="w-4 h-4 text-green-400" />
                            <div className="flex flex-col">
                                <span className="text-xs font-medium">GPT-4o</span>
                                <span className="text-[9px] text-[#71717a]">OpenAI • High Speed</span>
                            </div>
                        </div>
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                        onClick={() => onSelect({ id: 'o1-preview', name: 'O1 Preview', provider: 'OpenAI', icon: Brain })}
                        className="focus:bg-[#27272a] focus:text-white cursor-pointer py-2 rounded-md"
                    >
                        <div className="flex items-center gap-3">
                            <Brain className="w-4 h-4 text-pink-400" />
                            <div className="flex flex-col">
                                <span className="text-xs font-medium">O1 Preview</span>
                                <span className="text-[9px] text-[#71717a]">OpenAI • Deep Reasoning</span>
                            </div>
                        </div>
                    </DropdownMenuItem>
                </div>

                <div className="mb-2">
                    <div className="text-[10px] font-bold text-[#52525b] px-2 mb-1">OPEN SOURCE</div>
                    <DropdownMenuItem className="focus:bg-[#27272a] focus:text-white cursor-pointer py-2 rounded-md">
                        <div className="flex items-center gap-3">
                            <Lock className="w-4 h-4 text-blue-400" />
                            <div className="flex flex-col">
                                <span className="text-xs font-medium">Llama 3 70B</span>
                                <span className="text-[9px] text-[#71717a]">Meta • Open Weights</span>
                            </div>
                        </div>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="focus:bg-[#27272a] focus:text-white cursor-pointer py-2 rounded-md">
                        <div className="flex items-center gap-3">
                            <Lock className="w-4 h-4 text-yellow-400" />
                            <div className="flex flex-col">
                                <span className="text-xs font-medium">Mixtral 8x22B</span>
                                <span className="text-[9px] text-[#71717a]">Mistral AI • MoE Architecture</span>
                            </div>
                        </div>
                    </DropdownMenuItem>
                </div>

                <DropdownMenuSeparator className="bg-[#27272a]" />
                
                <DropdownMenuItem className="focus:bg-[#27272a] focus:text-white cursor-pointer py-2 rounded-md">
                    <div className="flex items-center gap-2 text-xs">
                        <Globe className="w-3.5 h-3.5" /> Configure Custom Endpoint...
                    </div>
                </DropdownMenuItem>
                
                <DropdownMenuSub>
                    <DropdownMenuSubTrigger className="focus:bg-[#27272a] focus:text-white cursor-pointer py-2 rounded-md text-xs">
                        <Activity className="w-3.5 h-3.5 mr-2" /> Model Settings
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent className="bg-[#18181b] border-[#27272a] text-[#e4e4e7]">
                         <DropdownMenuItem className="text-xs">Temperature</DropdownMenuItem>
                         <DropdownMenuItem className="text-xs">Max Tokens</DropdownMenuItem>
                         <DropdownMenuItem className="text-xs">System Prompt</DropdownMenuItem>
                    </DropdownMenuSubContent>
                </DropdownMenuSub>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}