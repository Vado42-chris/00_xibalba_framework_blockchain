import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
  DropdownMenuShortcut
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Menu, File, Folder, Save, Settings, Scissors, Copy, Clipboard, Layout, Monitor, Maximize, ExternalLink } from 'lucide-react';

export const MainMenu = ({ onAction }) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="w-10 h-10 rounded-none text-[#71717a] hover:text-white hover:bg-[#27272a]">
          <Menu className="w-5 h-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56 bg-[#18181b] border-[#27272a] text-[#e4e4e7]" align="start" side="right">
        
        <DropdownMenuSub>
          <DropdownMenuSubTrigger className="focus:bg-[#27272a] focus:text-white">
            <File className="w-3.5 h-3.5 mr-2" /> File
          </DropdownMenuSubTrigger>
          <DropdownMenuSubContent className="bg-[#18181b] border-[#27272a] text-[#e4e4e7]">
            <DropdownMenuItem onClick={() => onAction('new_file')}>
              <File className="w-3.5 h-3.5 mr-2" /> New File <DropdownMenuShortcut>⌘N</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction('new_window')}>
              <Layout className="w-3.5 h-3.5 mr-2" /> New Window <DropdownMenuShortcut>⇧⌘N</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-[#27272a]" />
            <DropdownMenuItem onClick={() => onAction('open')}>
              <Folder className="w-3.5 h-3.5 mr-2" /> Open... <DropdownMenuShortcut>⌘O</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction('save')}>
              <Save className="w-3.5 h-3.5 mr-2" /> Save <DropdownMenuShortcut>⌘S</DropdownMenuShortcut>
            </DropdownMenuItem>
          </DropdownMenuSubContent>
        </DropdownMenuSub>

        <DropdownMenuSub>
          <DropdownMenuSubTrigger className="focus:bg-[#27272a] focus:text-white">
            <Scissors className="w-3.5 h-3.5 mr-2" /> Edit
          </DropdownMenuSubTrigger>
          <DropdownMenuSubContent className="bg-[#18181b] border-[#27272a] text-[#e4e4e7]">
            <DropdownMenuItem onClick={() => onAction('undo')}>
              Undo <DropdownMenuShortcut>⌘Z</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction('redo')}>
              Redo <DropdownMenuShortcut>⇧⌘Z</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-[#27272a]" />
            <DropdownMenuItem onClick={() => onAction('cut')}>
              <Scissors className="w-3.5 h-3.5 mr-2" /> Cut <DropdownMenuShortcut>⌘X</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction('copy')}>
              <Copy className="w-3.5 h-3.5 mr-2" /> Copy <DropdownMenuShortcut>⌘C</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction('paste')}>
              <Clipboard className="w-3.5 h-3.5 mr-2" /> Paste <DropdownMenuShortcut>⌘V</DropdownMenuShortcut>
            </DropdownMenuItem>
          </DropdownMenuSubContent>
        </DropdownMenuSub>

        <DropdownMenuSub>
          <DropdownMenuSubTrigger className="focus:bg-[#27272a] focus:text-white">
            <Monitor className="w-3.5 h-3.5 mr-2" /> View
          </DropdownMenuSubTrigger>
          <DropdownMenuSubContent className="bg-[#18181b] border-[#27272a] text-[#e4e4e7]">
            <DropdownMenuItem onClick={() => onAction('toggle_sidebar')}>
              <Layout className="w-3.5 h-3.5 mr-2" /> Toggle Sidebar <DropdownMenuShortcut>⌘B</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction('toggle_terminal')}>
              <Layout className="w-3.5 h-3.5 mr-2" /> Toggle Terminal <DropdownMenuShortcut>⌘J</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-[#27272a]" />
            <DropdownMenuItem onClick={() => onAction('zoom_in')}>
              Zoom In <DropdownMenuShortcut>⌘+</DropdownMenuShortcut>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction('zoom_out')}>
              Zoom Out <DropdownMenuShortcut>⌘-</DropdownMenuShortcut>
            </DropdownMenuItem>
          </DropdownMenuSubContent>
        </DropdownMenuSub>

        <DropdownMenuSeparator className="bg-[#27272a]" />

        <DropdownMenuItem onClick={() => onAction('settings')}>
          <Settings className="w-3.5 h-3.5 mr-2" /> Settings <DropdownMenuShortcut>⌘,</DropdownMenuShortcut>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};