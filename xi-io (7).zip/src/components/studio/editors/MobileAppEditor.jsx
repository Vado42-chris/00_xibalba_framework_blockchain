import React from 'react';
import { Smartphone, Wifi, Share2, Layers, Plus, Settings, Battery, Signal } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function MobileAppEditor({ file }) {
    return (
        <div className="w-full h-full bg-[#1a1a1a] text-white flex">
            {/* Mobile Components */}
            <div className="w-64 border-r border-white/10 flex flex-col bg-neutral-900">
                <div className="p-4 border-b border-white/10 font-bold text-xs tracking-widest text-neutral-500">
                    COMPONENTS
                </div>
                <div className="p-4 space-y-2">
                    {['Header Bar', 'Bottom Nav', 'List View', 'Card Grid', 'Floating Action Button', 'Map View', 'Chat Interface', 'Profile Header'].map(c => (
                        <div key={c} className="p-3 bg-white/5 rounded border border-white/5 hover:border-white/20 cursor-grab text-xs">
                            {c}
                        </div>
                    ))}
                </div>
                
                <div className="mt-auto p-4 border-t border-white/10">
                    <div className="font-bold text-xs tracking-widest text-neutral-500 mb-3">DATA CONNECTORS</div>
                    <div className="space-y-3">
                        <div className="p-2 bg-blue-900/20 border border-blue-500/30 rounded">
                            <div className="flex items-center justify-between mb-1">
                                <span className="text-[10px] font-bold text-blue-400">Identity</span>
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_5px_lime]" />
                            </div>
                            <div className="text-[9px] text-blue-200/60">Google, Apple, Email</div>
                        </div>
                        
                        <div className="p-2 bg-purple-900/20 border border-purple-500/30 rounded">
                            <div className="flex items-center justify-between mb-1">
                                <span className="text-[10px] font-bold text-purple-400">Database</span>
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_5px_lime]" />
                            </div>
                            <div className="text-[9px] text-purple-200/60">Postgres (Read/Write)</div>
                        </div>

                        <div className="p-2 bg-orange-900/20 border border-orange-500/30 rounded">
                            <div className="flex items-center justify-between mb-1">
                                <span className="text-[10px] font-bold text-orange-400">Payments</span>
                                <div className="w-1.5 h-1.5 rounded-full bg-neutral-600" />
                            </div>
                            <div className="text-[9px] text-orange-200/60">Stripe Connect (Inactive)</div>
                        </div>

                        <Button variant="outline" size="sm" className="w-full text-[10px] h-7 mt-1 bg-white/5 border-white/10 hover:bg-white/10">
                            <Plus className="w-3 h-3 mr-1" /> Configure Source
                        </Button>
                    </div>
                </div>
            </div>

            {/* Canvas Area */}
            <div className="flex-1 flex items-center justify-center bg-neutral-950 relative overflow-hidden">
                <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
                
                {/* Phone Frame */}
                <div className="w-[375px] h-[812px] bg-white rounded-[40px] border-[8px] border-neutral-800 shadow-2xl relative overflow-hidden flex flex-col">
                    {/* Status Bar */}
                    <div className="h-12 bg-white flex items-center justify-between px-6 text-black select-none">
                        <span className="text-xs font-bold">9:41</span>
                        <div className="flex items-center gap-1.5">
                            <Signal className="w-3 h-3" />
                            <Wifi className="w-3 h-3" />
                            <Battery className="w-4 h-4" />
                        </div>
                    </div>

                    {/* App Content (Mock) */}
                    <div className="flex-1 bg-neutral-50 flex flex-col">
                        <div className="p-6">
                            <h1 className="text-2xl font-bold text-black mb-2">Welcome Back</h1>
                            <div className="h-32 bg-blue-500 rounded-xl shadow-lg mb-6 p-4 text-white flex flex-col justify-between">
                                <span className="text-sm opacity-80">Total Balance</span>
                                <span className="text-3xl font-bold">$12,450</span>
                            </div>
                            <div className="space-y-3">
                                <div className="h-16 bg-white rounded-lg shadow-sm border border-neutral-100 flex items-center px-4 gap-4">
                                    <div className="w-10 h-10 rounded-full bg-neutral-100" />
                                    <div className="h-2 w-32 bg-neutral-100 rounded" />
                                </div>
                                <div className="h-16 bg-white rounded-lg shadow-sm border border-neutral-100 flex items-center px-4 gap-4">
                                    <div className="w-10 h-10 rounded-full bg-neutral-100" />
                                    <div className="h-2 w-24 bg-neutral-100 rounded" />
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Bottom Nav */}
                    <div className="h-20 bg-white border-t border-neutral-100 flex items-center justify-around px-6 pb-4">
                        <div className="w-6 h-6 bg-blue-500 rounded-full" />
                        <div className="w-6 h-6 bg-neutral-200 rounded-full" />
                        <div className="w-6 h-6 bg-neutral-200 rounded-full" />
                        <div className="w-6 h-6 bg-neutral-200 rounded-full" />
                    </div>
                    
                    {/* Home Indicator */}
                    <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-black rounded-full" />
                </div>
            </div>

            {/* Properties */}
            <div className="w-72 border-l border-white/10 bg-neutral-900 p-4">
                <div className="font-bold text-xs tracking-widest text-neutral-500 mb-4">APP SETTINGS</div>
                <div className="space-y-4">
                    <div className="space-y-1">
                        <label className="text-[10px] text-neutral-400">App Name</label>
                        <input className="w-full bg-black border border-white/10 rounded px-2 py-1 text-xs" value="FinTech Pro" readOnly />
                    </div>
                    <div className="space-y-1">
                        <label className="text-[10px] text-neutral-400">Bundle ID</label>
                        <input className="w-full bg-black border border-white/10 rounded px-2 py-1 text-xs" value="com.base44.fintech" readOnly />
                    </div>
                    <div className="pt-4 border-t border-white/10">
                        <Button className="w-full bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 text-xs font-bold">
                            <Share2 className="w-3 h-3 mr-2" /> Build .IPA / .APK
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}