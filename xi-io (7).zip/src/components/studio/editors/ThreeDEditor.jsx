import React from 'react';
import { Box, Layers, Move, Rotate3d, Maximize, Image, Sun, Video, Grid, Settings } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function ThreeDEditor({ file }) {
    return (
        <div className="w-full h-full relative bg-[#050505] text-white flex overflow-hidden">
            {/* Left Toolbar */}
            <div className="w-14 border-r border-white/10 bg-[#0a0a0a] flex flex-col items-center py-4 gap-4 z-20">
                <ToolButton icon={Move} active />
                <ToolButton icon={Rotate3d} />
                <ToolButton icon={Maximize} />
                <div className="h-px w-8 bg-white/10" />
                <ToolButton icon={Box} />
                <ToolButton icon={Sun} />
                <ToolButton icon={Video} />
            </div>

            {/* Viewport */}
            <div className="flex-1 relative bg-gradient-to-b from-[#1a1a1a] to-[#050505] flex items-center justify-center overflow-hidden perspective-1000">
                {/* 3D Grid */}
                <div 
                    className="absolute inset-0 opacity-20 pointer-events-none"
                    style={{ 
                        backgroundImage: 'radial-gradient(circle, #4f46e5 1px, transparent 1px), linear-gradient(to right, rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.05) 1px, transparent 1px)',
                        backgroundSize: '30px 30px, 60px 60px, 60px 60px',
                        transform: 'perspective(500px) rotateX(60deg) translateY(0) scale(2)',
                        transformOrigin: 'center 60%'
                    }} 
                />
                
                {/* Object */}
                <div className="relative z-10 animate-[float_6s_ease-in-out_infinite] group cursor-grab active:cursor-grabbing">
                    <div className="w-48 h-48 bg-gradient-to-tr from-blue-600/80 to-purple-600/80 rounded-xl backdrop-blur-md border border-white/20 shadow-[0_0_100px_rgba(79,70,229,0.3)] flex items-center justify-center transform transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110">
                        <Box className="w-24 h-24 text-white drop-shadow-lg" />
                    </div>
                    
                    {/* Gizmo Overlay */}
                    <div className="absolute -top-12 -right-12 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="flex flex-col gap-1">
                            <div className="w-8 h-8 rounded-full bg-red-500/20 text-red-500 flex items-center justify-center border border-red-500/50">X</div>
                            <div className="w-8 h-8 rounded-full bg-green-500/20 text-green-500 flex items-center justify-center border border-green-500/50">Y</div>
                            <div className="w-8 h-8 rounded-full bg-blue-500/20 text-blue-500 flex items-center justify-center border border-blue-500/50">Z</div>
                        </div>
                    </div>
                </div>

                {/* View Controls */}
                <div className="absolute top-4 right-4 flex gap-2">
                    <Button variant="ghost" size="sm" className="bg-black/50 border border-white/10 text-xs">Perspective</Button>
                    <Button variant="ghost" size="sm" className="bg-black/50 border border-white/10 text-xs">Wireframe</Button>
                    <Button variant="ghost" size="sm" className="bg-black/50 border border-white/10 text-xs">Lit</Button>
                </div>
            </div>

            {/* Right Properties Panel */}
            <div className="w-64 border-l border-white/10 bg-[#0a0a0a] flex flex-col">
                <div className="h-10 border-b border-white/10 flex items-center px-4 justify-between bg-white/5">
                    <span className="text-xs font-bold tracking-wider text-neutral-400">SCENE GRAPH</span>
                    <Layers className="w-3 h-3 text-neutral-500" />
                </div>
                <div className="p-2 space-y-1 overflow-y-auto flex-1">
                    {['Scene Collection', 'Camera', 'PointLight', 'Cube_001', 'Plane'].map((item, i) => (
                        <div key={item} className={cn(
                            "px-3 py-1.5 rounded flex items-center gap-2 text-xs cursor-pointer",
                            item === 'Cube_001' ? "bg-blue-600/20 text-blue-400" : "hover:bg-white/5 text-neutral-400"
                        )}>
                            {i < 3 ? <div className="w-1.5 h-1.5 rounded-full bg-neutral-600" /> : <Box className="w-3 h-3" />}
                            {item}
                        </div>
                    ))}
                </div>
                
                {/* Properties */}
                <div className="h-1/2 border-t border-white/10 flex flex-col">
                    <div className="h-10 border-b border-white/10 flex items-center px-4 bg-white/5">
                        <span className="text-xs font-bold tracking-wider text-neutral-400">PROPERTIES</span>
                    </div>
                    <div className="p-4 space-y-4 overflow-y-auto">
                        <div className="space-y-2">
                            <label className="text-[10px] text-neutral-500 font-bold">TRANSFORM</label>
                            <div className="grid grid-cols-3 gap-2">
                                {['X', 'Y', 'Z'].map(axis => (
                                    <div key={axis} className="space-y-1">
                                        <span className="text-[9px] text-neutral-600">{axis}</span>
                                        <input className="w-full bg-black border border-white/10 rounded px-2 py-1 text-xs text-right font-mono text-blue-400" defaultValue="0.00" />
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="space-y-2">
                            <label className="text-[10px] text-neutral-500 font-bold">MATERIAL</label>
                            <div className="h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded border border-white/10" />
                            <div className="flex justify-between text-xs text-neutral-400">
                                <span>Roughness</span>
                                <span>0.4</span>
                            </div>
                            <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                                <div className="w-[40%] h-full bg-blue-500" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

function ToolButton({ icon: Icon, active }) {
    return (
        <button className={cn(
            "w-8 h-8 rounded flex items-center justify-center transition-all",
            active ? "bg-blue-600 text-white shadow-[0_0_15px_rgba(37,99,235,0.5)]" : "text-neutral-500 hover:text-white hover:bg-white/10"
        )}>
            <Icon className="w-4 h-4" />
        </button>
    )
}