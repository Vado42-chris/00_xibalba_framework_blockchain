import React, { useState } from 'react';
import { PenTool, Image as ImageIcon, Settings, MoreHorizontal, ArrowLeft, Globe, Eye, Send, Plus, X, AlignLeft, Bold, Italic } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function BlogEditor({ file }) {
    return (
        <div className="w-full h-full bg-white text-neutral-900 flex font-sans">
            {/* Sidebar (Posts) */}
            <div className="w-80 bg-[#f9f9f9] border-r border-neutral-200 flex flex-col z-20">
                <div className="h-16 flex items-center px-6 justify-between border-b border-neutral-200/50 bg-[#f9f9f9]/80 backdrop-blur">
                    <span className="font-bold text-sm tracking-tight text-neutral-900">Blog Posts</span>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-500 hover:text-black hover:bg-neutral-200/50"><Plus className="w-4 h-4" /></Button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                    {[
                        { title: "The Future of Design Systems", status: "Published", date: "Oct 24", views: 1240 },
                        { title: "Migrating to React 19", status: "Draft", date: "Just now", active: true },
                        { title: "Understanding Server Components", status: "Published", date: "Oct 20", views: 850 },
                        { title: "10 Tips for Better UX", status: "Scheduled", date: "Nov 01" },
                    ].map((post, i) => (
                        <div key={i} className={cn(
                            "p-4 rounded-xl cursor-pointer transition-all group border",
                            post.active ? "bg-white shadow-sm border-neutral-200" : "border-transparent hover:bg-neutral-200/50 hover:border-neutral-200/50"
                        )}>
                            <h4 className={cn("text-sm font-medium mb-2 leading-tight", post.active ? "text-black" : "text-neutral-600")}>{post.title}</h4>
                            <div className="flex items-center justify-between text-[10px]">
                                <span className={cn(
                                    "px-2 py-0.5 rounded-full font-bold",
                                    post.status === 'Published' ? "text-green-700 bg-green-100/50" :
                                    post.status === 'Draft' ? "text-amber-700 bg-amber-100/50" : "text-blue-700 bg-blue-100/50"
                                )}>{post.status}</span>
                                <span className="text-neutral-400">{post.date}</span>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="p-4 border-t border-neutral-200 bg-white">
                    <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center font-bold text-xs shadow-md">J</div>
                        <div className="flex-1">
                            <div className="text-sm font-bold text-neutral-900">John Doe</div>
                            <div className="text-[10px] text-neutral-500 font-medium">Editor in Chief</div>
                        </div>
                        <Settings className="w-4 h-4 text-neutral-400 cursor-pointer hover:text-black transition-colors" />
                    </div>
                </div>
            </div>

            {/* Editor Area */}
            <div className="flex-1 flex flex-col bg-white relative">
                {/* Editor Header */}
                <div className="h-16 border-b border-neutral-100 flex items-center px-8 justify-between shrink-0 sticky top-0 bg-white/80 backdrop-blur z-10">
                    <div className="flex items-center gap-4 text-sm text-neutral-500">
                        <span className="hover:text-black cursor-pointer transition-colors">Posts</span>
                        <span className="text-neutral-300">/</span>
                        <span className="text-black font-medium">Migrating to React 19</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <span className="text-xs text-neutral-400 font-medium mr-2">Saved 2m ago</span>
                        <Button variant="ghost" className="text-neutral-500 hover:text-black gap-2 h-9 text-xs font-medium rounded-full"><Eye className="w-4 h-4" /> Preview</Button>
                        <Button className="bg-black hover:bg-neutral-800 text-white h-9 text-xs font-bold gap-2 rounded-full px-5 shadow-lg shadow-neutral-200"><Send className="w-3 h-3" /> Publish</Button>
                        <Button variant="ghost" size="icon" className="h-9 w-9 border border-neutral-200 rounded-full ml-2"><Settings className="w-4 h-4" /></Button>
                    </div>
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto">
                    <div className="max-w-3xl mx-auto py-16 px-8">
                        {/* Cover Image Placeholder */}
                        <div className="w-full aspect-[21/9] bg-neutral-50 rounded-2xl mb-12 flex flex-col items-center justify-center text-neutral-400 border border-dashed border-neutral-200 hover:border-neutral-300 hover:bg-neutral-100 cursor-pointer transition-all group overflow-hidden relative">
                            <ImageIcon className="w-8 h-8 mb-2 group-hover:scale-110 transition-transform relative z-10" />
                            <span className="text-xs font-medium relative z-10">Add Cover Image</span>
                            <div className="absolute inset-0 bg-gradient-to-tr from-neutral-100 to-white opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>

                        {/* Title */}
                        <input 
                            className="w-full text-5xl font-extrabold text-black placeholder:text-neutral-300 border-none focus:ring-0 p-0 mb-8 resize-none bg-transparent tracking-tight leading-tight" 
                            placeholder="Post Title" 
                            defaultValue="Migrating to React 19"
                        />

                        {/* Formatting Bar Floating */}
                        <div className="sticky top-20 z-20 mb-8">
                            <div className="inline-flex items-center gap-1 p-1 bg-white border border-neutral-200 shadow-xl rounded-full px-3">
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-full hover:bg-neutral-100"><Bold className="w-4 h-4" /></Button>
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-full hover:bg-neutral-100"><Italic className="w-4 h-4" /></Button>
                                <div className="w-px h-4 bg-neutral-200 mx-1" />
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-full hover:bg-neutral-100"><AlignLeft className="w-4 h-4" /></Button>
                                <div className="w-px h-4 bg-neutral-200 mx-1" />
                                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-full hover:bg-neutral-100"><ImageIcon className="w-4 h-4" /></Button>
                            </div>
                        </div>

                        {/* Block Editor Mock */}
                        <div className="space-y-8 text-xl leading-relaxed text-neutral-800 font-serif">
                            <p className="first-letter:text-5xl first-letter:font-bold first-letter:mr-1 first-letter:float-left first-letter:leading-none">
                                React 19 introduces a paradigm shift in how we think about state management and server-side rendering. 
                                In this guide, we'll explore the key features and how to prepare your codebase for the future of web development.
                            </p>
                            
                            <div className="group relative pl-4 border-l-2 border-transparent hover:border-neutral-200 transition-colors">
                                <div className="absolute -left-10 top-1 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                                    <button className="w-6 h-6 rounded flex items-center justify-center hover:bg-neutral-100 text-neutral-400 hover:text-black transition-colors"><Plus className="w-4 h-4" /></button>
                                    <button className="w-6 h-6 rounded flex items-center justify-center hover:bg-neutral-100 text-neutral-400 hover:text-black transition-colors"><MoreHorizontal className="w-4 h-4" /></button>
                                </div>
                                <h2 className="text-3xl font-bold font-sans mt-12 mb-6 tracking-tight">The New Compiler</h2>
                                <p>
                                    React Forget is now the default compiler, automatically memoizing components without the need for useMemo or useCallback.
                                    This simplifies the mental model significantly and reduces boilerplate code by approximately 40%.
                                </p>
                            </div>

                            <div className="p-8 bg-blue-50/50 rounded-2xl border border-blue-100 font-sans text-base text-blue-900 leading-relaxed">
                                <span className="font-bold block mb-2 text-blue-700">💡 Pro Tip</span>
                                You can start adopting the compiler incrementally in your existing projects. It's fully backward compatible and can be enabled per-directory.
                            </div>

                            <p className="text-neutral-300 font-sans text-base">Type '/' for commands...</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Settings Sidebar (Hidden by default or toggled) */}
            <div className="w-80 border-l border-neutral-200 bg-white hidden xl:flex flex-col">
                <div className="p-6 border-b border-neutral-100">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-900">Post Settings</h3>
                </div>
                
                <div className="p-6 space-y-8 overflow-y-auto flex-1">
                    <div className="space-y-3">
                        <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider">URL Slug</label>
                        <input className="w-full bg-neutral-50 border border-neutral-200 rounded-lg px-3 py-2 text-sm text-neutral-600 focus:outline-none focus:border-neutral-400 transition-colors" defaultValue="migrating-to-react-19" />
                    </div>

                    <div className="space-y-3">
                        <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Excerpt</label>
                        <textarea className="w-full h-32 bg-neutral-50 border border-neutral-200 rounded-lg px-3 py-2 text-sm text-neutral-600 resize-none focus:outline-none focus:border-neutral-400 transition-colors leading-relaxed" defaultValue="A comprehensive guide to the new features in React 19..." />
                    </div>

                    <div className="space-y-3">
                        <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Tags</label>
                        <div className="flex flex-wrap gap-2">
                            <span className="px-3 py-1 bg-neutral-100 rounded-full text-xs font-medium text-neutral-600 flex items-center gap-1 group cursor-pointer hover:bg-neutral-200 transition-colors">React <X className="w-3 h-3 group-hover:text-red-500" /></span>
                            <span className="px-3 py-1 bg-neutral-100 rounded-full text-xs font-medium text-neutral-600 flex items-center gap-1 group cursor-pointer hover:bg-neutral-200 transition-colors">Engineering <X className="w-3 h-3 group-hover:text-red-500" /></span>
                            <button className="px-3 py-1 border border-dashed border-neutral-300 rounded-full text-xs text-neutral-400 hover:border-neutral-400 hover:text-neutral-600 transition-colors">+ Add</button>
                        </div>
                    </div>

                    <div className="pt-8 border-t border-neutral-100">
                        <h4 className="text-xs font-bold uppercase tracking-widest text-neutral-500 mb-4">SEO Preview</h4>
                        <div className="bg-white p-4 rounded-xl border border-neutral-200 shadow-sm">
                            <div className="text-xs text-neutral-500 mb-1 flex items-center gap-1.5"><Globe className="w-3 h-3" /> base44.io › blog</div>
                            <div className="text-base text-[#1a0dab] font-medium hover:underline cursor-pointer truncate mb-1">Migrating to React 19 - The Complete Guide</div>
                            <div className="text-xs text-neutral-600 leading-snug line-clamp-2">React 19 introduces a paradigm shift in how we think about state management...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}