import React, { useState } from 'react';
import { Globe, Layout, Search, Plus, X, Settings, Shield, Star, RefreshCw, ChevronLeft, ChevronRight, Lock, Sidebar, CreditCard } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function BrowserEditor({ file }) {
    const [config, setConfig] = useState({
        theme: 'dark',
        tabStyle: 'rounded', // rounded, angled, floating
        addressBar: 'center', // top, bottom, floating
        sidebar: true,
        privacy: 'high'
    });

    return (
        <div className="w-full h-full bg-[#1e1e1e] text-white flex flex-col font-sans">
            {/* Editor Toolbar */}
            <div className="h-14 border-b border-white/10 bg-black/50 flex items-center px-6 justify-between shrink-0 shadow-xl z-20">
                <div className="flex items-center gap-4">
                    <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
                        <Globe className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="text-sm font-bold tracking-wide">BROWSER FORGE</h1>
                        <p className="text-[10px] text-neutral-500 font-mono">v1.0.4 • Chromium Kernel</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className="flex bg-white/5 rounded-lg p-1 border border-white/5">
                        <button onClick={() => setConfig({...config, theme: 'dark'})} className={cn("px-3 py-1 text-xs rounded-md transition-all font-medium", config.theme === 'dark' ? "bg-white/10 text-white shadow-sm" : "text-neutral-500 hover:text-white")}>Dark</button>
                        <button onClick={() => setConfig({...config, theme: 'light'})} className={cn("px-3 py-1 text-xs rounded-md transition-all font-medium", config.theme === 'light' ? "bg-white text-black shadow-sm" : "text-neutral-500 hover:text-white")}>Light</button>
                    </div>
                    <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold px-4 shadow-[0_0_15px_-3px_rgba(147,51,234,0.6)]">
                        COMPILE .EXE
                    </Button>
                </div>
            </div>

            <div className="flex-1 flex overflow-hidden">
                {/* Configuration Sidebar */}
                <div className="w-80 bg-neutral-900 border-r border-white/5 flex flex-col overflow-y-auto shadow-2xl z-10">
                    <div className="p-6 space-y-8">
                        <div className="space-y-4">
                            <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-widest flex items-center gap-2">
                                <Layout className="w-3 h-3" /> Interface Layout
                            </h3>
                            
                            <div className="space-y-3">
                                <label className="text-xs text-neutral-300 font-medium">Tab Geometry</label>
                                <div className="grid grid-cols-3 gap-3">
                                    {['Rounded', 'Angled', 'Floating'].map(style => (
                                        <button 
                                            key={style}
                                            onClick={() => setConfig({...config, tabStyle: style.toLowerCase()})}
                                            className={cn(
                                                "h-20 border rounded-xl flex flex-col items-center justify-center gap-2 transition-all relative overflow-hidden group",
                                                config.tabStyle === style.toLowerCase() 
                                                    ? "bg-purple-500/10 border-purple-500/50 text-purple-400" 
                                                    : "bg-white/5 border-white/5 text-neutral-500 hover:border-white/20 hover:bg-white/10"
                                            )}
                                        >
                                            <div className={cn("w-10 h-6 border-t border-x border-current opacity-70 group-hover:opacity-100 transition-opacity", style === 'Rounded' ? "rounded-t-lg" : style === 'Angled' ? "skew-x-12" : "rounded mb-1")} />
                                            <span className="text-[10px] font-medium">{style}</span>
                                            {config.tabStyle === style.toLowerCase() && <div className="absolute inset-0 border-2 border-purple-500/30 rounded-xl" />}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div className="space-y-3">
                                <label className="text-xs text-neutral-300 font-medium">Address Bar</label>
                                <select 
                                    value={config.addressBar}
                                    onChange={(e) => setConfig({...config, addressBar: e.target.value})}
                                    className="w-full bg-black border border-white/10 rounded-lg px-3 py-2.5 text-xs focus:border-purple-500 outline-none text-white transition-colors"
                                >
                                    <option value="top">Standard (Top)</option>
                                    <option value="center">Floating (Center)</option>
                                    <option value="bottom">Mobile (Bottom)</option>
                                    <option value="sidebar">Vertical (Sidebar)</option>
                                </select>
                            </div>

                            <div 
                                className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/5 cursor-pointer hover:bg-white/10 transition-colors group"
                                onClick={() => setConfig({...config, sidebar: !config.sidebar})}
                            >
                                <span className="text-xs text-neutral-300 font-medium group-hover:text-white transition-colors">Vertical Sidebar</span>
                                <div className={cn("w-9 h-5 rounded-full relative transition-colors duration-300", config.sidebar ? "bg-purple-600" : "bg-neutral-700")}>
                                    <div className={cn("absolute top-1 w-3 h-3 rounded-full bg-white transition-all duration-300 shadow-sm", config.sidebar ? "left-5" : "left-1")} />
                                </div>
                            </div>
                        </div>

                        <div className="space-y-4 pt-6 border-t border-white/5">
                            <h3 className="text-xs font-bold text-neutral-500 uppercase tracking-widest flex items-center gap-2">
                                <Shield className="w-3 h-3" /> Security Kernel
                            </h3>
                            <div className="space-y-3">
                                {['Ad Blocker Built-in', 'VPN Tunneling', 'Fingerprint Masking'].map((feature, i) => (
                                    <div key={i} className="flex items-center gap-3 text-xs text-neutral-400 p-2 bg-white/5 rounded-lg border border-white/5">
                                        <div className="w-4 h-4 rounded border border-purple-500/50 bg-purple-500/20 flex items-center justify-center">
                                            <div className="w-2 h-2 bg-purple-400 rounded-sm" />
                                        </div>
                                        <span className="font-medium text-neutral-300">{feature}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Live Preview Canvas */}
                <div className="flex-1 bg-[#050505] p-12 flex items-center justify-center relative overflow-hidden">
                    {/* Background Pattern */}
                    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/10 via-[#050505] to-[#050505]" />
                    <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
                    
                    {/* The Browser Window Mockup */}
                    <div className={cn(
                        "w-full max-w-6xl h-[650px] bg-neutral-900 rounded-xl shadow-[0_50px_100px_-20px_rgba(0,0,0,0.7)] border border-white/10 flex flex-col overflow-hidden transition-all duration-500 relative z-10",
                        config.theme === 'light' ? "bg-white text-black" : "bg-[#1a1a1a] text-white"
                    )}>
                        {/* Chrome / Top Bar */}
                        <div className={cn(
                            "h-10 flex items-center px-3 gap-3 border-b transition-all select-none",
                            config.theme === 'light' ? "bg-[#f3f3f3] border-neutral-200" : "bg-[#111] border-white/5"
                        )}>
                            <div className="flex gap-2 ml-1 mr-2">
                                <div className="w-3 h-3 rounded-full bg-red-500/80 shadow-sm" />
                                <div className="w-3 h-3 rounded-full bg-yellow-500/80 shadow-sm" />
                                <div className="w-3 h-3 rounded-full bg-green-500/80 shadow-sm" />
                            </div>

                            {/* Tabs */}
                            {!config.sidebar && (
                                <div className="flex-1 flex items-end gap-1 overflow-x-auto">
                                    <div className={cn(
                                        "px-4 h-8 flex items-center gap-2 text-xs min-w-[140px] max-w-[200px] transition-all",
                                        config.tabStyle === 'rounded' && "rounded-t-lg mx-0.5",
                                        config.tabStyle === 'angled' && "skew-x-6 border-r mx-1",
                                        config.tabStyle === 'floating' && "rounded-lg mb-1 h-7 mx-1 shadow-sm",
                                        config.theme === 'light' ? "bg-white text-black shadow-sm" : "bg-[#1a1a1a] text-white"
                                    )}>
                                        <Globe className="w-3 h-3 text-blue-400" />
                                        <span className="font-medium truncate">New Tab</span>
                                        <X className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-100 hover:bg-black/10 rounded-full p-0.5 transition-all" />
                                    </div>
                                    <div className="w-8 h-8 flex items-center justify-center text-neutral-400 hover:text-white cursor-pointer hover:bg-white/5 rounded-lg mb-1">
                                        <Plus className="w-4 h-4" />
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="flex flex-1 overflow-hidden">
                            {/* Vertical Sidebar Tabs */}
                            {config.sidebar && (
                                <div className={cn(
                                    "w-14 flex flex-col items-center py-4 gap-4 border-r transition-all",
                                    config.theme === 'light' ? "bg-[#f9f9f9] border-neutral-200" : "bg-[#111] border-white/5"
                                )}>
                                    <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shadow-sm border border-blue-500/30">
                                        <Globe className="w-5 h-5" />
                                    </div>
                                    <div className="w-9 h-9 rounded-xl hover:bg-white/5 text-neutral-500 flex items-center justify-center transition-colors cursor-pointer">
                                        <Search className="w-5 h-5" />
                                    </div>
                                    <div className="w-9 h-9 rounded-xl hover:bg-white/5 text-neutral-500 flex items-center justify-center transition-colors cursor-pointer">
                                        <Star className="w-5 h-5" />
                                    </div>
                                    <div className="mt-auto w-9 h-9 rounded-xl hover:bg-white/5 text-neutral-500 flex items-center justify-center transition-colors cursor-pointer">
                                        <Settings className="w-5 h-5" />
                                    </div>
                                </div>
                            )}

                            {/* Main Content Area */}
                            <div className="flex-1 flex flex-col relative">
                                {/* Navigation / Address Bar */}
                                <div className={cn(
                                    "h-14 flex items-center px-6 gap-4 border-b transition-all",
                                    config.theme === 'light' ? "bg-white border-neutral-200" : "bg-[#1a1a1a] border-white/5"
                                )}>
                                    <div className="flex gap-3 text-neutral-400">
                                        <ChevronLeft className="w-5 h-5 hover:text-white cursor-pointer transition-colors" />
                                        <ChevronRight className="w-5 h-5 hover:text-white cursor-pointer transition-colors" />
                                        <RefreshCw className="w-4 h-4 hover:text-white cursor-pointer transition-colors mt-0.5" />
                                    </div>

                                    {/* OmniBox */}
                                    <div className={cn(
                                        "flex-1 h-10 rounded-full flex items-center px-5 gap-3 text-sm transition-all",
                                        config.theme === 'light' ? "bg-neutral-100 text-black hover:bg-neutral-200 shadow-inner" : "bg-black/50 text-white hover:bg-black/70 border border-white/5 shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]",
                                        config.addressBar === 'center' && "mx-auto max-w-2xl shadow-lg"
                                    )}>
                                        <Lock className="w-3.5 h-3.5 text-green-500" />
                                        <span className="opacity-50 select-none">search or type url...</span>
                                        <Star className="w-4 h-4 ml-auto opacity-50 hover:opacity-100 cursor-pointer hover:text-yellow-400 transition-colors" />
                                    </div>

                                    <div className="flex gap-4 text-neutral-400">
                                        <CreditCard className="w-5 h-5 hover:text-white cursor-pointer transition-colors" />
                                        <Sidebar className="w-5 h-5 hover:text-white cursor-pointer transition-colors" />
                                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-pink-500 to-rose-500 shadow-md border border-white/10" />
                                    </div>
                                </div>

                                {/* Viewport Content */}
                                <div className="flex-1 bg-white relative flex flex-col items-center justify-center text-neutral-300">
                                    <div className="animate-[float_8s_ease-in-out_infinite]">
                                        <Globe className="w-32 h-32 mb-6 text-neutral-100" />
                                    </div>
                                    <h2 className="text-3xl font-light text-neutral-300 tracking-tight">Start Browsing</h2>
                                    
                                    {/* Mock Web Content */}
                                    <div className="absolute inset-0 bg-neutral-50 p-12 opacity-0 hover:opacity-100 transition-opacity flex flex-col gap-6 backdrop-blur-sm bg-white/90">
                                        <div className="h-48 bg-neutral-200 rounded-2xl animate-pulse w-full" />
                                        <div className="grid grid-cols-3 gap-6">
                                            <div className="h-32 bg-neutral-200 rounded-xl animate-pulse" />
                                            <div className="h-32 bg-neutral-200 rounded-xl animate-pulse" />
                                            <div className="h-32 bg-neutral-200 rounded-xl animate-pulse" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}