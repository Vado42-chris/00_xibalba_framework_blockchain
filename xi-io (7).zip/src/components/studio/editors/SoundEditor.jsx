import React, { useState } from 'react';
import { Play, Pause, Square, Mic, Music, Volume2, Settings, Scissors, Move, Copy, Grid, Layers, Download, Radio, Sliders } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function SoundEditor({ file }) {
    const [isPlaying, setIsPlaying] = useState(false);
    
    const tracks = [
        { id: 1, name: 'Vocals Main', type: 'audio', color: 'bg-blue-500', clips: [{ start: 10, width: 200 }, { start: 300, width: 150 }] },
        { id: 2, name: 'Drums', type: 'midi', color: 'bg-orange-500', clips: [{ start: 0, width: 800 }] },
        { id: 3, name: 'Bass', type: 'midi', color: 'bg-yellow-500', clips: [{ start: 0, width: 400 }, { start: 400, width: 400 }] },
        { id: 4, name: 'Synth Pad', type: 'midi', color: 'bg-purple-500', clips: [{ start: 50, width: 300 }] },
        { id: 5, name: 'FX Swoosh', type: 'audio', color: 'bg-pink-500', clips: [{ start: 180, width: 50 }, { start: 380, width: 50 }] },
    ];

    return (
        <div className="w-full h-full bg-[#121214] text-neutral-400 flex flex-col font-sans">
            {/* Top Toolbar / Transport */}
            <div className="h-16 bg-[#1e1e20] border-b border-white/5 flex items-center px-4 justify-between shrink-0 shadow-md z-20">
                <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-red-500/10 border border-red-500/20 rounded cursor-pointer hover:bg-red-500/20 transition-colors">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse shadow-[0_0_8px_red]" />
                        <span className="text-xs font-bold text-red-400 tracking-widest">REC</span>
                    </div>
                    
                    {/* Transport Controls */}
                    <div className="flex items-center gap-1 bg-black/40 rounded-lg p-1 border border-white/5">
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-neutral-400 hover:text-white"><Square className="w-4 h-4 fill-current" /></Button>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className={cn("h-10 w-10 rounded-md transition-all shadow-lg transform active:scale-95", isPlaying ? "bg-[hsl(var(--color-execution))] text-black" : "bg-white/10 text-white hover:bg-white/20")}
                            onClick={() => setIsPlaying(!isPlaying)}
                        >
                            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-1" />}
                        </Button>
                        <Button variant="ghost" size="icon" className="h-9 w-9 text-neutral-400 hover:text-white"><Radio className="w-4 h-4" /></Button>
                    </div>

                    {/* Time Display */}
                    <div className="bg-black border border-white/10 rounded-lg px-4 py-2 font-mono text-xl text-[hsl(var(--color-execution))] tracking-widest shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]">
                        00:01:24<span className="text-sm text-neutral-600">.42</span>
                    </div>

                    {/* BPM / Time Sig */}
                    <div className="flex flex-col text-[10px] font-bold gap-1">
                        <div className="flex gap-2 items-center bg-white/5 px-2 py-0.5 rounded border border-white/5"><span className="text-white">128.00</span> <span className="text-neutral-500">BPM</span></div>
                        <div className="flex gap-2 items-center bg-white/5 px-2 py-0.5 rounded border border-white/5"><span className="text-white">4 / 4</span> <span className="text-neutral-500">SIG</span></div>
                    </div>
                </div>

                <div className="flex items-center gap-4">
                    <div className="flex gap-1 bg-white/5 p-1 rounded-lg border border-white/5">
                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/10 rounded"><Scissors className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/10 rounded"><Move className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/10 rounded"><Copy className="w-4 h-4" /></Button>
                    </div>
                    <Button size="sm" className="bg-[hsl(var(--color-execution))] text-black text-xs font-bold gap-2 shadow-[0_0_15px_-5px_hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90">
                        <Download className="w-3 h-3" /> Export Mix
                    </Button>
                </div>
            </div>

            <div className="flex-1 flex overflow-hidden">
                {/* Track Headers */}
                <div className="w-72 bg-[#18181a] border-r border-white/5 flex flex-col shrink-0 overflow-y-auto custom-scrollbar">
                    {tracks.map(track => (
                        <div key={track.id} className="h-28 border-b border-white/5 bg-[#1e1e20] p-3 flex flex-col justify-between group hover:bg-[#252528] transition-colors relative">
                            <div className={cn("absolute left-0 top-0 bottom-0 w-1.5", track.color)} />
                            
                            <div className="flex justify-between items-start">
                                <div className="flex items-center gap-2">
                                    <div className={cn("w-6 h-6 rounded flex items-center justify-center bg-black/30", track.color.replace('bg-', 'text-'))}>
                                        {track.type === 'audio' ? <Mic className="w-3 h-3" /> : <Music className="w-3 h-3" />}
                                    </div>
                                    <span className="text-xs font-bold text-neutral-200 tracking-wide">{track.name}</span>
                                </div>
                                <Settings className="w-3 h-3 opacity-0 group-hover:opacity-100 cursor-pointer hover:text-white transition-opacity" />
                            </div>

                            {/* Controls */}
                            <div className="space-y-2">
                                <div className="flex items-center gap-2">
                                    <Volume2 className="w-3 h-3 text-neutral-500" />
                                    <div className="flex-1 h-1.5 bg-black rounded-full overflow-hidden">
                                        <div className="w-[70%] h-full bg-green-500 rounded-full" />
                                    </div>
                                    <span className="text-[9px] font-mono">-6dB</span>
                                </div>
                                
                                <div className="flex gap-1 justify-between">
                                    <div className="flex gap-1">
                                        <button className="w-6 h-6 rounded bg-black/50 text-[9px] font-bold text-neutral-500 hover:text-red-400 hover:bg-red-900/20 border border-white/5">R</button>
                                        <button className="w-6 h-6 rounded bg-black/50 text-[9px] font-bold text-neutral-500 hover:text-yellow-400 hover:bg-yellow-900/20 border border-white/5">S</button>
                                        <button className="w-6 h-6 rounded bg-black/50 text-[9px] font-bold text-neutral-500 hover:text-blue-400 hover:bg-blue-900/20 border border-white/5">M</button>
                                    </div>
                                    <div className="flex gap-1">
                                        <button className="w-6 h-6 rounded bg-black/50 text-[9px] font-bold text-neutral-500 hover:text-white border border-white/5 flex items-center justify-center"><Sliders className="w-3 h-3" /></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Timeline / Arrange View */}
                <div className="flex-1 bg-[#121214] flex flex-col overflow-hidden relative">
                    {/* Ruler */}
                    <div className="h-8 border-b border-white/5 bg-[#18181a] flex items-end pb-1 px-4 select-none shadow-sm z-10">
                        {[...Array(20)].map((_, i) => (
                            <div key={i} className="flex-1 border-l border-white/10 h-3 text-[9px] text-neutral-600 pl-1 font-mono">
                                {i + 1}
                            </div>
                        ))}
                    </div>

                    {/* Grid */}
                    <div className="flex-1 overflow-auto relative custom-scrollbar">
                        {/* Background Grid Lines */}
                        <div className="absolute inset-0 flex pointer-events-none">
                            {[...Array(20)].map((_, i) => (
                                <div key={i} className="flex-1 border-r border-white/5 h-full opacity-30" />
                            ))}
                        </div>

                        {/* Tracks */}
                        <div className="absolute inset-0 flex flex-col">
                            {tracks.map(track => (
                                <div key={track.id} className="h-28 border-b border-white/5 relative group bg-[#141416]/50">
                                    {/* Clips */}
                                    {track.clips.map((clip, i) => (
                                        <div 
                                            key={i}
                                            className={cn(
                                                "absolute top-2 bottom-2 rounded-md border border-black/20 shadow-md cursor-move hover:brightness-110 active:brightness-125 overflow-hidden ring-1 ring-white/5",
                                                track.color
                                            )}
                                            style={{ left: clip.start, width: clip.width }}
                                        >
                                            <div className="absolute top-0 left-0 right-0 h-5 bg-black/20 px-2 flex items-center justify-between backdrop-blur-sm">
                                                <span className="text-[9px] font-bold text-white/70 truncate tracking-wide">{track.name}_{i+1}</span>
                                            </div>
                                            {/* Waveform / MIDI Notes Mock */}
                                            <div className="absolute inset-0 top-5 opacity-40 bg-[url('https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/Audio-waveform.png/640px-Audio-waveform.png')] bg-cover bg-left-bottom mix-blend-multiply filter contrast-150" />
                                        </div>
                                    ))}
                                </div>
                            ))}
                        </div>
                        
                        {/* Playhead */}
                        <div className="absolute top-0 bottom-0 w-0.5 bg-[hsl(var(--color-execution))] shadow-[0_0_10px_hsl(var(--color-execution))] z-50 pointer-events-none" style={{ left: '30%' }}>
                            <div className="absolute -top-2 -left-2 w-4 h-4 bg-[hsl(var(--color-execution))] rotate-45 border-2 border-white/20 shadow-lg" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}