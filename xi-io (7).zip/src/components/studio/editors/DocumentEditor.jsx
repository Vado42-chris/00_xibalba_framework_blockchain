import React, { useState } from 'react';
import { FileText, Save, Download, Printer, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, List, Image, Link, ChevronDown } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function DocumentEditor({ file }) {
    const [content, setContent] = useState(`
        <h1 style="font-size: 24px; font-weight: bold; margin-bottom: 16px;">Project Proposal: Xibalba v2</h1>
        <p style="margin-bottom: 12px;">This document outlines the strategic roadmap for the next generation of our operating system.</p>
        <h2 style="font-size: 18px; font-weight: bold; margin-bottom: 8px;">1. Introduction</h2>
        <p style="margin-bottom: 12px;">We aim to revolutionize the way users interact with digital content by blurring the lines between creation and consumption.</p>
        <ul>
            <li>Unified Component Forge</li>
            <li>Desktop-class Web Apps</li>
            <li>Seamless Deployment Pipelines</li>
        </ul>
    `);

    return (
        <div className="w-full h-full bg-[#f3f3f3] text-neutral-900 flex flex-col font-sans">
            {/* Ribbon / Toolbar */}
            <div className="h-32 border-b border-neutral-300 flex flex-col shrink-0 bg-white">
                {/* Title Bar */}
                <div className="h-10 bg-[#2b579a] flex items-center justify-between px-4 text-white">
                    <div className="flex items-center gap-4">
                        <FileText className="w-5 h-5" />
                        <span className="text-sm font-medium">{file?.name || 'Untitled Document'}</span>
                        <div className="flex gap-2 text-xs opacity-80 ml-4">
                            <span className="hover:bg-white/10 px-2 py-1 rounded cursor-pointer">File</span>
                            <span className="hover:bg-white/10 px-2 py-1 rounded cursor-pointer font-bold bg-white/20">Home</span>
                            <span className="hover:bg-white/10 px-2 py-1 rounded cursor-pointer">Insert</span>
                            <span className="hover:bg-white/10 px-2 py-1 rounded cursor-pointer">Layout</span>
                            <span className="hover:bg-white/10 px-2 py-1 rounded cursor-pointer">References</span>
                            <span className="hover:bg-white/10 px-2 py-1 rounded cursor-pointer">Review</span>
                            <span className="hover:bg-white/10 px-2 py-1 rounded cursor-pointer">View</span>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs">US</div>
                    </div>
                </div>

                {/* Toolbar */}
                <div className="flex-1 bg-white flex items-center px-4 gap-2 shadow-sm overflow-x-auto">
                    {/* Clipboard */}
                    <div className="flex flex-col gap-1 pr-3 border-r border-neutral-200">
                        <Button variant="ghost" size="sm" className="h-10 flex-col gap-1 text-[10px] w-12">
                            <span className="text-lg">📋</span> Paste
                        </Button>
                    </div>

                    {/* Font */}
                    <div className="flex flex-col gap-2 pr-3 border-r border-neutral-200 p-2">
                        <div className="flex gap-2">
                            <select className="h-6 text-xs border border-neutral-300 rounded w-32 bg-white"><option>Calibri (Body)</option><option>Times New Roman</option><option>Arial</option></select>
                            <select className="h-6 text-xs border border-neutral-300 rounded w-16 bg-white"><option>11</option><option>12</option><option>14</option><option>18</option></select>
                        </div>
                        <div className="flex gap-0.5">
                            <Button variant="ghost" size="icon" className="h-6 w-6"><Bold className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6"><Italic className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6"><Underline className="w-3 h-3" /></Button>
                            <div className="w-px h-4 bg-neutral-300 mx-1" />
                            <Button variant="ghost" size="icon" className="h-6 w-6"><span className="font-bold text-red-600">A</span></Button>
                        </div>
                    </div>

                    {/* Paragraph */}
                    <div className="flex flex-col gap-2 pr-3 border-r border-neutral-200 p-2">
                        <div className="flex gap-0.5">
                            <Button variant="ghost" size="icon" className="h-6 w-6"><List className="w-3 h-3" /></Button>
                            <div className="w-px h-4 bg-neutral-300 mx-1" />
                            <Button variant="ghost" size="icon" className="h-6 w-6"><AlignLeft className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6 bg-neutral-100"><AlignCenter className="w-3 h-3" /></Button>
                            <Button variant="ghost" size="icon" className="h-6 w-6"><AlignRight className="w-3 h-3" /></Button>
                        </div>
                    </div>

                    {/* Styles */}
                    <div className="flex-1 flex items-center gap-2 overflow-hidden px-2">
                        {['Normal', 'No Spacing', 'Heading 1', 'Heading 2', 'Title'].map((style, i) => (
                            <div key={style} className={cn(
                                "h-16 w-20 border border-neutral-200 rounded bg-white p-1 cursor-pointer hover:bg-neutral-50 flex flex-col justify-between group",
                                i === 0 ? "border-[#2b579a] bg-[#2b579a]/5" : ""
                            )}>
                                <div className={cn(
                                    "text-[10px]",
                                    style.includes('Heading') ? "font-bold text-[#2b579a]" : "",
                                    style === 'Title' ? "text-xl" : ""
                                )}>AaBbCc</div>
                                <div className="text-[9px] text-neutral-500 text-center truncate">{style}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Document Area */}
            <div className="flex-1 overflow-y-auto p-8 flex justify-center bg-[#f3f3f3]">
                <div className="w-[816px] min-h-[1056px] bg-white shadow-lg p-[96px] outline-none text-sm leading-relaxed selection:bg-[#2b579a]/20" contentEditable>
                    <div dangerouslySetInnerHTML={{ __html: content }} />
                </div>
            </div>

            {/* Status Bar */}
            <div className="h-6 bg-[#2b579a] text-white flex items-center justify-between px-4 text-[10px]">
                <div className="flex gap-4">
                    <span>Page 1 of 1</span>
                    <span>42 words</span>
                    <span>English (US)</span>
                </div>
                <div className="flex gap-4 items-center">
                    <span>Focus Mode</span>
                    <div className="w-32 h-1 bg-white/20 rounded-full overflow-hidden">
                        <div className="w-1/2 h-full bg-white" />
                    </div>
                    <span>100%</span>
                </div>
            </div>
        </div>
    );
}