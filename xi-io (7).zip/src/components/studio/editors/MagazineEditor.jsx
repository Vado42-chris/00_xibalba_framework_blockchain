import React, { useState } from 'react';
import { Layout, Type, Image as ImageIcon, Grid, Layers, Eye, Plus, FileText, Settings, Download, Palette, AlignLeft, Printer } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function MagazineEditor({ file }) {
    const [pages, setPages] = useState([{ id: 1 }, { id: 2 }]);
    
    return (
        <div className="w-full h-full bg-[#2a2a2a] text-white flex flex-col font-sans">
            {/* Top Toolbar */}
            <div className="h-14 bg-[#333] border-b border-black/20 flex items-center px-4 justify-between shrink-0 shadow-lg z-20">
                <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-[#ff3366] flex items-center justify-center rounded text-white font-bold shadow-[0_0_10px_#ff3366]">Id</div>
                    <div>
                        <h1 className="text-sm font-bold tracking-wide">Magazine Layout Pro</h1>
                        <p className="text-[10px] text-neutral-400">A4 Print • CMYK • 300 DPI</p>
                    </div>
                </div>
                
                <div className="flex items-center gap-2">
                     <div className="flex bg-black/20 rounded-lg p-1 border border-white/5">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-300 hover:text-white hover:bg-white/10 rounded"><Eye className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-300 hover:text-white hover:bg-white/10 rounded"><Printer className="w-4 h-4" /></Button>
                     </div>
                     <Button size="sm" className="bg-[#ff3366] hover:bg-[#e62e5c] text-white text-xs font-bold shadow-lg">
                        <Download className="w-3 h-3 mr-2" /> Export PDF
                     </Button>
                </div>
            </div>

            <div className="flex-1 flex overflow-hidden">
                {/* Tools Sidebar */}
                <div className="w-16 bg-[#333] border-r border-black/20 flex flex-col items-center py-6 gap-6 z-10">
                    <ToolButton icon={Layout} active />
                    <ToolButton icon={Type} />
                    <ToolButton icon={ImageIcon} />
                    <ToolButton icon={Grid} />
                    <ToolButton icon={Palette} />
                    <div className="mt-auto" />
                    <ToolButton icon={Layers} />
                    <ToolButton icon={Settings} />
                </div>

                {/* Workspace */}
                <div className="flex-1 bg-[#1a1a1a] flex justify-center overflow-auto p-12 relative shadow-inner">
                    {/* Ruler (Top) */}
                    <div className="absolute top-0 left-0 right-0 h-6 bg-[#262626] border-b border-white/10 flex items-end px-12 z-10">
                         {[...Array(20)].map((_,i) => (
                             <div key={i} className="flex-1 border-l border-white/20 h-2 text-[8px] text-neutral-500 pl-1">{i*10}mm</div>
                         ))}
                    </div>

                    {/* Canvas Spreads */}
                    <div className="flex gap-1 h-[842px] scale-95 origin-top mt-4"> 
                        {/* Page 1 (Left) */}
                        <div className="w-[595px] h-full bg-white shadow-2xl relative overflow-hidden group">
                            {/* Bleed Lines */}
                            <div className="absolute inset-4 border border-cyan-500/20 pointer-events-none" />
                            <div className="absolute inset-12 border border-magenta-500/20 pointer-events-none" />
                            
                            {/* Content */}
                            <div className="p-12 h-full flex flex-col">
                                <h1 className="text-8xl font-black text-black tracking-tighter leading-[0.8] mix-blend-multiply">THE<br/>FUTURE<br/>OF<br/>DESIGN</h1>
                                <div className="mt-auto flex gap-8">
                                    <p className="w-1/3 text-[10px] text-black font-serif leading-relaxed text-justify">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.
                                    </p>
                                    <div className="w-2/3 h-48 bg-neutral-100 flex items-center justify-center text-neutral-300 font-bold uppercase tracking-widest text-xs border border-neutral-200">Image Placeholder</div>
                                </div>
                            </div>

                            {/* Hover Overlay */}
                            <div className="absolute top-0 left-0 bg-[#ff3366] text-white text-[10px] px-2 py-0.5 font-bold opacity-0 group-hover:opacity-100 transition-opacity">Page 2</div>
                        </div>

                        {/* Page 2 (Right) */}
                        <div className="w-[595px] h-full bg-white shadow-2xl relative overflow-hidden group">
                             <div className="absolute inset-4 border border-cyan-500/20 pointer-events-none" />
                             <div className="absolute inset-12 border border-magenta-500/20 pointer-events-none" />

                             <div className="absolute top-0 right-0 w-2/3 h-full bg-black" />
                             <div className="absolute top-1/2 left-12 right-12 text-white font-serif text-4xl italic leading-tight mix-blend-difference z-10">
                                "Design is not just what it looks like and feels like. Design is how it works."
                             </div>

                             <div className="absolute top-0 right-0 bg-[#ff3366] text-white text-[10px] px-2 py-0.5 font-bold opacity-0 group-hover:opacity-100 transition-opacity">Page 3</div>
                        </div>
                    </div>
                </div>

                {/* Properties Panel */}
                <div className="w-72 bg-[#333] border-l border-black/20 flex flex-col shadow-lg z-10">
                    <div className="p-4 border-b border-black/20">
                        <span className="text-xs font-bold uppercase tracking-widest text-neutral-400">Properties</span>
                    </div>
                    <div className="p-4 space-y-6">
                        <div className="space-y-2">
                            <label className="text-xs text-neutral-300 font-bold">Dimensions</label>
                            <div className="grid grid-cols-2 gap-2">
                                <div className="bg-black/20 rounded px-3 py-2 text-xs text-white border border-white/5 flex justify-between"><span>W</span> 595mm</div>
                                <div className="bg-black/20 rounded px-3 py-2 text-xs text-white border border-white/5 flex justify-between"><span>H</span> 842mm</div>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs text-neutral-300 font-bold">Typography</label>
                            <select className="w-full bg-black/20 border border-white/5 rounded text-xs text-white p-2 outline-none"><option>Helvetica Now Display</option></select>
                            <div className="flex gap-1">
                                <Button variant="ghost" size="sm" className="flex-1 bg-black/20 h-8 hover:bg-white/10"><AlignLeft className="w-3 h-3" /></Button>
                                <Button variant="ghost" size="sm" className="flex-1 bg-black/20 h-8 hover:bg-white/10"><Type className="w-3 h-3" /></Button>
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label className="text-xs text-neutral-300 font-bold">Palette</label>
                            <div className="grid grid-cols-5 gap-2">
                                {['#000', '#fff', '#ff3366', '#00ccff', '#ffcc00'].map(c => (
                                    <div key={c} className="w-8 h-8 rounded-full border border-white/10 shadow-sm cursor-pointer hover:scale-110 transition-transform" style={{backgroundColor: c}} />
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Pages Strip */}
            <div className="h-36 bg-[#262626] border-t border-black/20 flex items-center px-4 gap-4 overflow-x-auto shrink-0 shadow-lg z-20">
                {pages.map(p => (
                    <div key={p.id} className="w-24 h-32 bg-white shadow-lg flex items-center justify-center relative cursor-pointer hover:ring-2 hover:ring-[#ff3366] transition-all group rounded-sm overflow-hidden">
                        <div className="absolute inset-0 flex flex-col p-2 gap-1 opacity-20">
                            <div className="h-2 w-full bg-black/50 rounded-sm" />
                            <div className="h-full w-full bg-black/10 rounded-sm" />
                        </div>
                        <span className="text-black/50 text-xl font-bold z-10">{p.id}</span>
                        <div className="absolute bottom-1 right-1 text-[8px] text-black">A4</div>
                    </div>
                ))}
                <button 
                    onClick={() => setPages([...pages, { id: pages.length + 1 }])}
                    className="w-24 h-32 border-2 border-dashed border-white/20 flex flex-col gap-2 items-center justify-center hover:border-white/40 hover:bg-white/5 transition-all text-neutral-500 hover:text-white rounded-sm"
                >
                    <Plus className="w-6 h-6" />
                    <span className="text-xs font-medium">Add Spread</span>
                </button>
            </div>
        </div>
    );
}

function ToolButton({ icon: Icon, active }) {
    return (
        <button className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300",
            active ? "bg-[#ff3366] text-white shadow-[0_5px_15px_rgba(255,51,102,0.4)]" : "text-neutral-400 hover:text-white hover:bg-white/10"
        )}>
            <Icon className="w-5 h-5" />
        </button>
    )
}