import React from 'react';
import { Play, Pause, SkipBack, SkipForward, Sliders, Scissors, Plus, Layers, Monitor, Mic, Settings, Video } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function VideoEditor({ file }) {
    return (
        <div className="w-full h-full flex flex-col bg-[#050505] text-white">
            {/* Upper Section */}
            <div className="flex-1 flex min-h-0">
                {/* Assets / Bin */}
                <div className="w-64 border-r border-white/5 bg-[#0a0a0a] flex flex-col">
                    <div className="h-10 border-b border-white/5 flex items-center px-4 font-bold text-xs text-neutral-500 tracking-wider">PROJECT BIN</div>
                    <div className="p-2 grid grid-cols-2 gap-2 overflow-y-auto">
                        {[1, 2, 3, 4, 5, 6].map(i => (
                            <div key={i} className="aspect-video bg-white/5 rounded border border-white/5 flex items-center justify-center hover:bg-white/10 cursor-grab active:cursor-grabbing group relative">
                                <Video className="w-6 h-6 text-neutral-600 group-hover:text-neutral-400" />
                                <span className="absolute bottom-1 right-1 text-[8px] font-mono bg-black/80 px-1 rounded">00:12</span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Viewer */}
                <div className="flex-1 flex flex-col bg-black relative group">
                    <div className="flex-1 flex items-center justify-center">
                        <div className="relative aspect-video w-[80%] bg-[#111] border border-white/5 shadow-2xl flex items-center justify-center overflow-hidden">
                            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-purple-500/10" />
                            <h1 className="text-4xl font-black tracking-tighter opacity-20 select-none">CINEMA NODE</h1>
                            
                            {/* Play Overlay */}
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                                <Play className="w-12 h-12 fill-white text-white drop-shadow-xl cursor-pointer hover:scale-110 transition-transform" />
                            </div>
                        </div>
                    </div>
                    
                    {/* Transport Bar */}
                    <div className="h-12 border-t border-white/5 bg-[#0a0a0a] flex items-center justify-center gap-4">
                        <span className="text-xs font-mono text-blue-400">00:01:24:12</span>
                        <div className="flex items-center gap-2">
                            <SkipBack className="w-4 h-4 text-neutral-400 hover:text-white cursor-pointer" />
                            <Play className="w-5 h-5 text-white hover:text-blue-400 cursor-pointer fill-current" />
                            <SkipForward className="w-4 h-4 text-neutral-400 hover:text-white cursor-pointer" />
                        </div>
                        <span className="text-xs font-mono text-neutral-600">00:03:45:00</span>
                    </div>
                </div>

                {/* Inspector */}
                <div className="w-64 border-l border-white/5 bg-[#0a0a0a] p-4 overflow-y-auto">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-xs font-bold text-neutral-400 uppercase">Effect Controls</h3>
                        <Sliders className="w-3 h-3 text-neutral-500" />
                    </div>
                    <div className="space-y-6">
                        <div className="space-y-2">
                            <label className="text-[10px] text-neutral-500 font-bold">TRANSFORM</label>
                            <div className="space-y-1">
                                <div className="flex justify-between text-xs text-neutral-400"><span>Scale</span> <span>100%</span></div>
                                <div className="h-1 bg-white/10 rounded-full"><div className="w-1/2 h-full bg-blue-500 rounded-full"/></div>
                            </div>
                            <div className="space-y-1">
                                <div className="flex justify-between text-xs text-neutral-400"><span>Rotation</span> <span>0°</span></div>
                                <div className="h-1 bg-white/10 rounded-full"><div className="w-0 h-full bg-blue-500 rounded-full"/></div>
                            </div>
                        </div>
                        
                        <div className="space-y-2">
                            <label className="text-[10px] text-neutral-500 font-bold">COLOR GRADING</label>
                            <div className="grid grid-cols-3 gap-2">
                                <div className="aspect-square rounded-full border border-white/10 bg-gradient-to-br from-red-500 to-blue-500 opacity-50" />
                                <div className="aspect-square rounded-full border border-white/10 bg-gradient-to-br from-green-500 to-purple-500 opacity-50" />
                                <div className="aspect-square rounded-full border border-white/10 bg-gradient-to-br from-yellow-500 to-cyan-500 opacity-50" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Timeline */}
            <div className="h-64 bg-[#0a0a0a] border-t border-white/10 flex flex-col shrink-0">
                {/* Timeline Tools */}
                <div className="h-8 border-b border-white/5 flex items-center px-4 gap-4 bg-[#111]">
                    <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-neutral-400 hover:text-white"><Scissors className="w-3 h-3" /></Button>
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-neutral-400 hover:text-white"><Plus className="w-3 h-3" /></Button>
                    </div>
                    <div className="h-4 w-px bg-white/10" />
                    <div className="flex-1 overflow-hidden relative h-4">
                        {/* Ruler marks */}
                        <div className="absolute inset-0 flex items-end">
                            {[...Array(50)].map((_, i) => (
                                <div key={i} className="flex-1 border-l border-white/10 h-2 text-[8px] text-neutral-600 pl-0.5">{i}s</div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Tracks */}
                <div className="flex-1 overflow-y-auto relative">
                    <div className="absolute top-0 bottom-0 left-48 w-px bg-red-500 z-20 shadow-[0_0_10px_red]" />
                    
                    {/* Video Tracks */}
                    {[1, 2].map(t => (
                        <div key={`v${t}`} className="h-12 border-b border-white/5 bg-[#111] relative group flex">
                            <div className="w-24 border-r border-white/5 flex items-center justify-center text-[10px] font-bold text-blue-400 bg-black/20 shrink-0">
                                V{t} <Monitor className="w-3 h-3 ml-2 opacity-50" />
                            </div>
                            <div className="flex-1 relative">
                                <div className="absolute top-1 bottom-1 left-20 w-64 bg-blue-900/40 border border-blue-500/30 rounded flex items-center px-2 overflow-hidden hover:bg-blue-800/50 cursor-move">
                                    <div className="flex gap-1 opacity-20">
                                        {[...Array(5)].map((_, i) => <div key={i} className="w-12 h-8 bg-white/10 rounded-sm" />)}
                                    </div>
                                    <span className="absolute inset-0 flex items-center px-2 text-[10px] font-medium truncate">Clip_Sequence_{t}.mp4</span>
                                </div>
                            </div>
                        </div>
                    ))}

                    <div className="h-1 bg-black w-full" />

                    {/* Audio Tracks */}
                    {[1, 2].map(t => (
                        <div key={`a${t}`} className="h-10 border-b border-white/5 bg-[#111] relative group flex">
                            <div className="w-24 border-r border-white/5 flex items-center justify-center text-[10px] font-bold text-green-400 bg-black/20 shrink-0">
                                A{t} <Mic className="w-3 h-3 ml-2 opacity-50" />
                            </div>
                            <div className="flex-1 relative">
                                <div className="absolute top-1 bottom-1 left-20 w-64 bg-green-900/40 border border-green-500/30 rounded flex items-center px-2 overflow-hidden hover:bg-green-800/50 cursor-move">
                                    {/* Waveform Visualization Mock */}
                                    <div className="absolute inset-0 flex items-center gap-px opacity-40">
                                        {[...Array(40)].map((_, i) => (
                                            <div key={i} className="w-1 bg-green-400" style={{ height: `${Math.random() * 80 + 20}%` }} />
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}