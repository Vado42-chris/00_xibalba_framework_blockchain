import React from 'react';
import { Database, Table, Key, MoreHorizontal, Plus, Search, Link as LinkIcon, Server, Shield, Activity, Calendar } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function DatabaseEditor({ file }) {
    return (
        <div className="w-full h-full bg-[#f8f9fa] text-neutral-900 flex font-sans">
            {/* Sidebar - Tables */}
            <div className="w-72 bg-white border-r border-neutral-200 flex flex-col shadow-sm z-20">
                <div className="h-16 border-b border-neutral-200 flex items-center justify-between px-6 bg-white">
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-200">
                            <Database className="w-4 h-4" />
                        </div>
                        <div>
                            <span className="font-bold text-sm block text-neutral-900">CRM_DB</span>
                            <span className="text-[10px] text-green-600 font-bold flex items-center gap-1">
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> Connected
                            </span>
                        </div>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-black"><SettingsIcon className="w-4 h-4" /></Button>
                </div>
                
                <div className="p-4 space-y-1 flex-1 overflow-y-auto">
                    <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-3 px-2">Collections</div>
                    {['Users', 'Orders', 'Products', 'Invoices', 'Settings', 'Logs'].map(table => (
                        <button key={table} className={cn(
                            "w-full text-left px-3 py-2.5 text-sm font-medium rounded-lg flex items-center gap-3 transition-colors group",
                            table === 'Users' ? "bg-blue-50 text-blue-700" : "text-neutral-600 hover:bg-neutral-50"
                        )}>
                            <Table className={cn("w-4 h-4", table === 'Users' ? "text-blue-500" : "text-neutral-400 group-hover:text-neutral-600")} />
                            {table}
                            <span className="ml-auto text-[10px] text-neutral-400 font-mono opacity-0 group-hover:opacity-100">1.2k</span>
                        </button>
                    ))}
                    <button className="w-full text-left px-3 py-2.5 text-sm font-medium text-neutral-400 hover:text-blue-600 flex items-center gap-3 hover:bg-blue-50 rounded-lg transition-colors mt-2 border border-dashed border-neutral-200 hover:border-blue-200">
                        <Plus className="w-4 h-4" /> Create Collection
                    </button>
                </div>
                
                <div className="p-6 border-t border-neutral-200 bg-neutral-50">
                    <div className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-3">Infrastructure</div>
                    <div className="space-y-3">
                        <div className="flex items-center gap-3 text-xs text-neutral-700 bg-white p-2 rounded border border-neutral-200">
                            <Server className="w-4 h-4 text-blue-500" /> 
                            <div className="flex-1">
                                <div className="font-bold">Postgres Primary</div>
                                <div className="text-[9px] text-neutral-400">us-east-1 • Read/Write</div>
                            </div>
                            <div className="w-2 h-2 rounded-full bg-green-500" />
                        </div>
                        <div className="flex items-center gap-3 text-xs text-neutral-700 bg-white p-2 rounded border border-neutral-200">
                            <Shield className="w-4 h-4 text-purple-500" />
                            <div className="flex-1">
                                <div className="font-bold">Redis Cache</div>
                                <div className="text-[9px] text-neutral-400">Memory: 45%</div>
                            </div>
                            <div className="w-2 h-2 rounded-full bg-green-500" />
                        </div>
                    </div>
                </div>
            </div>

            {/* Main View - Schema/Data */}
            <div className="flex-1 flex flex-col overflow-hidden bg-white">
                {/* Header */}
                <div className="h-16 bg-white border-b border-neutral-200 flex items-center px-8 justify-between sticky top-0 z-10">
                    <div className="flex items-center gap-6">
                        <h1 className="font-bold text-xl text-neutral-900">Users</h1>
                        <div className="h-6 w-px bg-neutral-200" />
                        <div className="flex gap-1 bg-neutral-100 p-1 rounded-lg">
                            <Button variant="ghost" size="sm" className="h-8 text-xs bg-white shadow-sm font-bold text-neutral-900">Data</Button>
                            <Button variant="ghost" size="sm" className="h-8 text-xs text-neutral-500 hover:text-neutral-900">Schema</Button>
                            <Button variant="ghost" size="sm" className="h-8 text-xs text-neutral-500 hover:text-neutral-900">API</Button>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <div className="relative">
                            <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-400" />
                            <input className="pl-9 pr-4 py-2 text-sm border border-neutral-200 rounded-lg w-64 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all bg-neutral-50 focus:bg-white" placeholder="Search records..." />
                        </div>
                        <Button size="sm" className="h-9 bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 shadow-md px-4 rounded-lg">
                            <Plus className="w-4 h-4 mr-1" /> Add Record
                        </Button>
                    </div>
                </div>

                {/* Table Grid */}
                <div className="flex-1 overflow-auto bg-white">
                    <div className="min-w-full inline-block align-middle">
                        <div className="border-b border-neutral-200 bg-neutral-50/80 backdrop-blur sticky top-0 z-10">
                            <div className="flex">
                                <div className="w-12 p-3 border-r border-neutral-200 text-center text-xs font-bold text-neutral-400">#</div>
                                {[
                                    { name: 'id', type: 'uuid', icon: Key },
                                    { name: 'email', type: 'varchar', icon: Text },
                                    { name: 'full_name', type: 'varchar', icon: Text },
                                    { name: 'role', type: 'enum', icon: Tag },
                                    { name: 'created_at', type: 'timestamp', icon: Calendar },
                                    { name: 'plan_id', type: 'fk', icon: LinkIcon }
                                ].map(col => (
                                    <div key={col.name} className="w-56 p-3 border-r border-neutral-200 text-xs font-bold text-neutral-600 flex items-center gap-2 group cursor-pointer hover:bg-neutral-100 transition-colors">
                                        <col.icon className="w-3.5 h-3.5 text-neutral-400" />
                                        {col.name}
                                        <span className="text-[9px] text-neutral-400 font-normal bg-neutral-100 px-1.5 py-0.5 rounded ml-2">{col.type}</span>
                                        <MoreHorizontal className="w-3.5 h-3.5 ml-auto opacity-0 group-hover:opacity-100 text-neutral-400 hover:text-black transition-opacity" />
                                    </div>
                                ))}
                            </div>
                        </div>
                        {Array.from({ length: 20 }).map((_, i) => (
                            <div key={i} className="flex border-b border-neutral-100 hover:bg-blue-50/30 transition-colors group">
                                <div className="w-12 p-3 border-r border-neutral-100 text-center text-xs text-neutral-400 font-mono bg-neutral-50/30">{i + 1}</div>
                                <div className="w-56 p-3 border-r border-neutral-100 text-xs font-mono text-neutral-500 truncate flex items-center gap-2">
                                    <span className="select-all cursor-text">550e8400-e29b...</span>
                                    <button className="opacity-0 group-hover:opacity-100 ml-auto hover:text-blue-600"><SettingsIcon className="w-3 h-3" /></button>
                                </div>
                                <div className="w-56 p-3 border-r border-neutral-100 text-xs text-neutral-800 font-medium">user_{i}@example.com</div>
                                <div className="w-56 p-3 border-r border-neutral-100 text-xs text-neutral-800">User {i}</div>
                                <div className="w-56 p-3 border-r border-neutral-100 text-xs flex items-center">
                                    <span className={cn("px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider", i % 3 === 0 ? "bg-purple-100 text-purple-700" : "bg-neutral-100 text-neutral-500")}>
                                        {i % 3 === 0 ? 'admin' : 'member'}
                                    </span>
                                </div>
                                <div className="w-56 p-3 border-r border-neutral-100 text-xs text-neutral-500 flex items-center gap-2">
                                    2024-12-15 <span className="text-neutral-300">|</span> 10:30
                                </div>
                                <div className="w-56 p-3 border-r border-neutral-100 text-xs text-blue-600 hover:underline cursor-pointer font-medium flex items-center gap-1">
                                    <LinkIcon className="w-3 h-3" /> plan_basic_v1
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

function SettingsIcon({ className }) {
    return <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.1a2 2 0 0 1-1-1.74v-.47a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>;
}
function Text({ className }) { return <span className={className}>T</span> }
function Tag({ className }) { return <span className={className}>🏷️</span> }