import React, { useState } from 'react';
import { 
    Cpu, Code, Terminal, Play, Settings, Search, 
    GitBranch, Folder, MessageSquare, Monitor, 
    Split, Check, Sparkles, Box, LayoutTemplate,
    ChevronRight, ChevronDown, Plus, X, Globe, Eye,
    Maximize2, Minimize2, MoreHorizontal, Layout, Tablet, Smartphone, Laptop, RefreshCw
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import DeploymentModal from '@/components/reaper/DeploymentModal';
import ModelSelector from './code/ModelSelector';
import ChatInterface from './code/ChatInterface';
import WYSIWYGPreview from './code/WYSIWYGPreview';
import AgentOrchestrator from './code/AgentOrchestrator';
import { ExplorerPanel, SearchPanel, GitPanel, ExtensionsPanel, FileIcon } from './code/SidePanels';
import { MainMenu } from './code/CodeMenus';
import { toast } from 'sonner';
import { WindowManagerProvider, useWindowManager } from '@/components/studio/managers/WindowManager';
import { ExternalLink } from 'lucide-react';
import ProductIcon from '@/components/brand/ProductIcon';

export default function CodeArchitectWrapper(props) {
    return (
        <WindowManagerProvider>
            <CodeArchitect {...props} />
        </WindowManagerProvider>
    );
}

function CodeArchitect({ file }) {
    const [activeSide, setActiveSide] = useState('explorer'); // explorer, search, git, ai, extensions
    const [activeFile, setActiveFile] = useState('App.js');
    const [showPreview, setShowPreview] = useState(true);
    const [showTerminal, setShowTerminal] = useState(true);
    const [bottomPanelTab, setBottomPanelTab] = useState('terminal'); // terminal, agents, output
    const [previewMode, setPreviewMode] = useState('desktop'); 
    const [editMode, setEditMode] = useState(false); 
    const [workspaceMode, setWorkspaceMode] = useState('standard');
    const [deploymentOpen, setDeploymentOpen] = useState(false);
    const [selectedModel, setSelectedModel] = useState({ id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', provider: 'Anthropic' });
    
    const { openWindow, isPoppedOut, sendToWindow, closeWindow } = useWindowManager();

    // Sync state to satellites when they change
    React.useEffect(() => {
        if (isPoppedOut('chat')) sendToWindow('chat', { model: selectedModel, file: activeFile });
        if (isPoppedOut('preview')) sendToWindow('preview', { file: activeFile });
    }, [selectedModel, activeFile, isPoppedOut]);

    const handleMenuAction = (action) => {
        switch(action) {
            case 'new_file': toast.success('New file created'); break;
            case 'save': toast.success('File saved successfully'); break;
            case 'toggle_sidebar': setActiveSide(activeSide ? null : 'explorer'); break;
            case 'toggle_terminal': setShowTerminal(!showTerminal); break;
            default: toast.info(`Action: ${action}`);
        }
    };

    const files = {
        'src': {
            type: 'folder',
            isOpen: true,
            children: {
                'components': {
                    type: 'folder',
                    isOpen: true,
                    children: {
                        'Header.js': { type: 'file', lang: 'react' },
                        'Sidebar.js': { type: 'file', lang: 'react' },
                        'Button.jsx': { type: 'file', lang: 'react' }
                    }
                },
                'App.js': { type: 'file', lang: 'react' },
                'index.css': { type: 'file', lang: 'css' },
                'utils.js': { type: 'file', lang: 'js' }
            }
        },
        'package.json': { type: 'file', lang: 'json' },
        'README.md': { type: 'file', lang: 'markdown' }
    };

    return (
        <div className="w-full h-full bg-[#09090b] text-[#a1a1aa] flex overflow-hidden font-mono text-[13px]">
            {/* Activity Bar (Leftmost) */}
            <div className="w-12 flex flex-col items-center border-r border-[#27272a] bg-[#09090b] z-30 shrink-0 py-2">
                <div className="mb-4 w-full flex justify-center pb-1">
                    <ProductIcon id="architect" size="sm" className="shadow-lg shadow-black/50" />
                </div>
                
                <div className="mb-2 w-full flex justify-center border-b border-[#27272a] pb-2">
                    <MainMenu onAction={handleMenuAction} />
                </div>
                <ActivityIcon icon={Folder} active={activeSide === 'explorer'} onClick={() => setActiveSide(activeSide === 'explorer' ? null : 'explorer')} tooltip="Explorer" />
                <ActivityIcon icon={Search} active={activeSide === 'search'} onClick={() => setActiveSide(activeSide === 'search' ? null : 'search')} tooltip="Search" />
                <ActivityIcon icon={GitBranch} active={activeSide === 'git'} onClick={() => setActiveSide(activeSide === 'git' ? null : 'git')} tooltip="Source Control" />
                <ActivityIcon icon={Box} active={activeSide === 'extensions'} onClick={() => setActiveSide(activeSide === 'extensions' ? null : 'extensions')} tooltip="Extensions & Marketplace" />
                <div className="h-px w-6 bg-[#27272a] my-2" />
                <ActivityIcon icon={Sparkles} active={activeSide === 'ai'} onClick={() => setActiveSide('ai')} className="text-purple-500 hover:text-purple-400" tooltip="AI Assistant" />
                <div className="mt-auto flex flex-col gap-2">
                    <ActivityIcon icon={Settings} tooltip="Settings" />
                    <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-blue-500 to-cyan-500 mx-auto opacity-50 hover:opacity-100 transition-opacity cursor-pointer border border-white/10" title="Profile" />
                </div>
            </div>

            {/* Sidebar Panel */}
            {activeSide && (
                <div className="w-72 bg-[#0c0c0e] border-r border-[#27272a] flex flex-col shrink-0 animate-in slide-in-from-left-2 duration-200">
                    {activeSide === 'explorer' && <ExplorerPanel files={files} activeFile={activeFile} onSelect={setActiveFile} />}
                    {activeSide === 'search' && <SearchPanel />}
                    {activeSide === 'git' && <GitPanel />}
                    {activeSide === 'extensions' && <ExtensionsPanel />}
                    {activeSide === 'ai' && (
                        <div className="flex flex-col h-full relative">
                            {isPoppedOut('chat') ? (
                                <div className="flex-1 flex flex-col items-center justify-center bg-[#0c0c0e] text-[#52525b] p-6 text-center space-y-4">
                                    <div className="animate-pulse">
                                        <ProductIcon id="chat" size="lg" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[#e4e4e7]">Chat Detached</h3>
                                        <p className="text-[11px] mt-1">AI Assistant is active in an external window.</p>
                                    </div>
                                    <Button variant="outline" size="sm" onClick={() => closeWindow('chat')} className="text-xs">
                                        <Minimize2 className="w-3 h-3 mr-2" /> Recall Window
                                    </Button>
                                </div>
                            ) : (
                                <>
                                    <div className="p-3 border-b border-[#27272a] bg-[#0c0c0e] flex gap-2">
                                        <div className="flex-1"><ModelSelector activeModel={selectedModel} onSelect={setSelectedModel} /></div>
                                        <Button 
                                            variant="ghost" 
                                            size="icon" 
                                            className="h-9 w-9 border border-[#27272a] bg-[#18181b] hover:text-white"
                                            onClick={() => openWindow('chat', { model: selectedModel, file: activeFile })}
                                            title="Pop Out Chat"
                                        >
                                            <ExternalLink className="w-4 h-4" />
                                        </Button>
                                    </div>
                                    <div className="flex-1 overflow-hidden">
                                        <ChatInterface selectedModel={selectedModel} activeFile={activeFile} />
                                    </div>
                                </>
                            )}
                        </div>
                    )}
                </div>
            )}

            {/* Main Editor Area */}
            <div className="flex-1 flex flex-col min-w-0 bg-[#09090b]">
                {/* Editor Tabs & Toolbar */}
                <div className="h-10 flex bg-[#09090b] border-b border-[#27272a] items-center">
                    <div className="flex-1 flex overflow-x-auto scrollbar-none h-full">
                        {['App.js', 'index.css', 'Header.js'].map(file => (
                            <div 
                                key={file}
                                className={cn(
                                    "flex items-center gap-2 px-3 min-w-[120px] max-w-[200px] border-r border-[#27272a] cursor-pointer group hover:bg-[#18181b] h-full transition-colors",
                                    file === activeFile ? "bg-[#09090b] text-[#e4e4e7] border-t-2 border-t-blue-500" : "bg-[#0c0c0e] text-[#71717a] border-t-2 border-t-transparent"
                                )}
                                onClick={() => setActiveFile(file)}
                            >
                                <FileIcon name={file} className="w-3.5 h-3.5" />
                                <span className="truncate flex-1 text-[12px]">{file}</span>
                                <X className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 hover:text-white rounded-sm hover:bg-white/10 p-0.5" />
                            </div>
                        ))}
                    </div>
                    <div className="flex items-center px-2 gap-1 border-l border-[#27272a] bg-[#0c0c0e] h-full">
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            className={cn("h-7 px-2 hover:bg-[#27272a] gap-2", showPreview ? "text-blue-400 bg-blue-500/10" : "text-[#71717a]")}
                            onClick={() => setShowPreview(!showPreview)}
                        >
                            <Split className="w-3.5 h-3.5" />
                            <span className="text-[10px] font-bold">Preview</span>
                        </Button>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className={cn("h-7 w-7 hover:bg-[#27272a]", isPoppedOut('preview') && "text-blue-400")}
                            onClick={() => isPoppedOut('preview') ? closeWindow('preview') : openWindow('preview', { file: activeFile })}
                            title={isPoppedOut('preview') ? "Recall Preview" : "Pop Out Preview"}
                        >
                            {isPoppedOut('preview') ? <Minimize2 className="w-3.5 h-3.5" /> : <ExternalLink className="w-3.5 h-3.5" />}
                        </Button>
                        <div className="w-px h-4 bg-[#27272a] mx-1" />
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className={cn("h-7 w-7 hover:bg-[#27272a]", workspaceMode === 'zen' && "text-purple-400")}
                            onClick={() => setWorkspaceMode(workspaceMode === 'zen' ? 'standard' : 'zen')}
                            title="Zen Mode"
                        >
                            <Maximize2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 hover:bg-[#27272a] text-[#71717a] hover:text-white"
                            onClick={() => { window.open(window.location.href + '?windowed=true', '_blank', 'width=1200,height=800'); }}
                            title="Pop Out Window"
                        >
                            <ExternalLink className="w-3.5 h-3.5" />
                        </Button>
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-7 w-7 hover:bg-[#27272a] text-green-500"
                            onClick={() => setDeploymentOpen(true)}
                            title="Deploy to Cloud"
                        >
                            <Play className="w-3.5 h-3.5" />
                        </Button>
                    </div>
                </div>

                <div className="flex-1 flex overflow-hidden">
                    {/* Code Surface */}
                    <div className="flex-1 relative group bg-[#09090b]">
                        <div className="absolute left-0 top-0 bottom-0 w-12 bg-[#09090b] border-r border-[#27272a] flex flex-col items-end pr-3 py-4 text-[#52525b] select-none text-[12px] leading-6 font-mono">
                            {Array.from({length: 50}).map((_, i) => <div key={i} className="h-6">{i + 1}</div>)}
                        </div>
                        <div className="absolute inset-0 left-12 p-4 font-mono text-[13px] leading-6 text-[#e4e4e7] overflow-auto">
                            <pre>
                                <span className="text-purple-400">import</span> React, {'{'} useState, useEffect {'}'} <span className="text-purple-400">from</span> <span className="text-green-400">'react'</span>;<br/>
                                <span className="text-purple-400">import</span> {'{'} motion {'}'} <span className="text-purple-400">from</span> <span className="text-green-400">'framer-motion'</span>;<br/>
                                <br/>
                                <span className="text-blue-400">export default function</span> <span className="text-yellow-300">App</span>() {'{'}<br/>
                                &nbsp;&nbsp;<span className="text-gray-500">// AI-Optimized State Management</span><br/>
                                &nbsp;&nbsp;<span className="text-purple-400">const</span> [count, setCount] = <span className="text-blue-300">useState</span>(0);<br/>
                                &nbsp;&nbsp;<span className="text-purple-400">const</span> [isHovered, setIsHovered] = <span className="text-blue-300">useState</span>(<span className="text-orange-400">false</span>);<br/>
                                <br/>
                                &nbsp;&nbsp;<span className="text-purple-400">return</span> (<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">div</span> <span className="text-yellow-300">className</span>=<span className="text-green-400">"min-h-screen bg-black text-white p-8"</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">header</span> <span className="text-yellow-300">className</span>=<span className="text-green-400">"flex justify-between items-center mb-12"</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">h1</span> <span className="text-yellow-300">className</span>=<span className="text-green-400">"text-4xl font-bold tracking-tighter"</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hello World<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-red-400">h1</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">nav</span> <span className="text-yellow-300">className</span>=<span className="text-green-400">"flex gap-4"</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">a</span> <span className="text-yellow-300">href</span>=<span className="text-green-400">"#"</span>&gt;Home&lt;/<span className="text-red-400">a</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">a</span> <span className="text-yellow-300">href</span>=<span className="text-green-400">"#"</span>&gt;About&lt;/<span className="text-red-400">a</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-red-400">nav</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-red-400">header</span>&gt;<br/>
                                <br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">main</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;<span className="text-red-400">button</span> <br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span className="text-yellow-300">onClick</span>={'{'}() =&gt; setCount(c =&gt; c + 1){'}'}<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span className="text-yellow-300">className</span>=<span className="text-green-400">"px-6 py-3 bg-blue-600 rounded-lg font-medium"</span><br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Count is {'{'}count{'}'}<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-red-400">button</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-red-400">main</span>&gt;<br/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&lt;/<span className="text-red-400">div</span>&gt;<br/>
                                &nbsp;&nbsp;);<br/>
                                {'}'}
                            </pre>
                            
                            {/* AI Ghost Text Suggestion */}
                            <div className="absolute top-[400px] left-16 right-4 bg-purple-900/10 border border-purple-500/20 p-2 rounded text-purple-200/50 text-[11px] italic pointer-events-none">
                                AI Suggestion: Consider extracting the Header into its own component for better maintainability.
                            </div>
                        </div>
                        
                        {/* AI Inline Chat Trigger */}
                        <div className="absolute bottom-4 right-4 bg-[#18181b] hover:bg-[#27272a] border border-[#27272a] rounded-full shadow-2xl p-2 px-4 flex items-center gap-2 cursor-pointer transition-all hover:scale-105 group/trigger z-20">
                            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                            <span className="text-[11px] text-[#e4e4e7] font-medium">Generate...</span>
                            <span className="text-[9px] text-[#71717a] ml-2 border border-[#3f3f46] rounded px-1">⌘K</span>
                        </div>
                    </div>

                    {/* Preview / WYSIWYG Pane */}
                    {showPreview && (
                        <div className="w-[45%] border-l border-[#27272a] bg-[#0c0c0e] flex flex-col shrink-0 relative z-10">
                            {isPoppedOut('preview') ? (
                                <div className="flex-1 flex flex-col items-center justify-center text-[#52525b] p-8 text-center space-y-4">
                                    <div className="opacity-50">
                                        <ProductIcon id="web" size="lg" />
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-bold text-[#e4e4e7]">Preview Externalized</h3>
                                        <p className="text-[11px] mt-1 max-w-[200px] mx-auto">
                                            The rendering engine is currently active in a satellite window.
                                        </p>
                                    </div>
                                    <Button variant="outline" size="sm" onClick={() => closeWindow('preview')} className="text-xs">
                                        <Minimize2 className="w-3 h-3 mr-2" /> Recall Window
                                    </Button>
                                </div>
                            ) : (
                                <WYSIWYGPreview 
                                    code="" 
                                    activeFile={activeFile} 
                                    isDark={true}
                                />
                            )}
                        </div>
                    )}
                </div>

                {/* Terminal / Agents Panel */}
                {showTerminal && (
                    <div className="h-56 border-t border-[#27272a] bg-[#09090b] flex flex-col shrink-0 transition-all duration-300">
                        <div className="flex items-center px-4 h-9 border-b border-[#27272a] gap-6 text-[11px] font-bold text-[#71717a] uppercase tracking-wider bg-[#0c0c0e]">
                            <span 
                                className={cn("h-full flex items-center cursor-pointer transition-colors border-b-2", bottomPanelTab === 'terminal' ? "text-[#e4e4e7] border-blue-500" : "border-transparent hover:text-[#e4e4e7]")}
                                onClick={() => setBottomPanelTab('terminal')}
                            >
                                Terminal
                            </span>
                            <span 
                                className={cn("h-full flex items-center cursor-pointer transition-colors border-b-2", bottomPanelTab === 'agents' ? "text-purple-400 border-purple-500" : "border-transparent hover:text-purple-300")}
                                onClick={() => setBottomPanelTab('agents')}
                            >
                                <Sparkles className="w-3 h-3 mr-1.5" /> Agent Orchestrator
                            </span>
                            <span className="hover:text-[#e4e4e7] cursor-pointer h-full flex items-center">Problems <Badge className="ml-2 h-4 px-1 bg-red-500/20 text-red-400 border-none">1</Badge></span>
                            <div className="ml-auto flex gap-2 items-center">
                                <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-5 w-5 hover:bg-white/10"
                                    onClick={() => isPoppedOut('agents') ? closeWindow('agents') : openWindow('agents')}
                                    title="Pop Out Panel"
                                >
                                    {isPoppedOut('agents') ? <Minimize2 className="w-3.5 h-3.5" /> : <ExternalLink className="w-3.5 h-3.5" />}
                                </Button>
                                <Plus className="w-3.5 h-3.5 cursor-pointer hover:text-white" />
                                <ChevronDown className="w-3.5 h-3.5 cursor-pointer hover:text-white" onClick={() => setShowTerminal(false)} />
                                <X className="w-3.5 h-3.5 cursor-pointer hover:text-white" onClick={() => setShowTerminal(false)} />
                            </div>
                        </div>
                        
                        <div className="flex-1 overflow-hidden relative">
                             {isPoppedOut('agents') && bottomPanelTab === 'agents' ? (
                                <div className="h-full flex flex-col items-center justify-center text-[#52525b] text-[11px] gap-2">
                                    <div className="animate-pulse opacity-50"><ProductIcon id="agents" size="md" /></div>
                                    <span>Orchestrator active on second monitor</span>
                                </div>
                             ) : (
                                <>
                                    {bottomPanelTab === 'terminal' && (
                                        <div className="h-full p-3 font-mono text-[12px] overflow-auto bg-[#09090b]">
                                            <div className="flex gap-2">
                                                <span className="text-green-500">➜</span>
                                                <span className="text-cyan-500">project-titan</span>
                                                <span className="text-[#71717a]">git:(</span><span className="text-red-500">main</span><span className="text-[#71717a]">)</span>
                                                <span className="text-[#e4e4e7]">npm run dev</span>
                                            </div>
                                            <div className="text-[#a1a1aa] mt-2 pl-4 border-l-2 border-[#27272a]">
                                                <div>&gt; vite dev</div>
                                                <div className="mt-2">
                                                    <span className="text-blue-400 font-bold">  VITE v5.0.0</span>  <span className="text-green-400">ready in 240 ms</span>
                                                </div>
                                                <div className="mt-2 flex flex-col gap-1">
                                                    <div>  <span className="text-green-500 font-bold">➜</span>  <span className="text-[#e4e4e7] font-bold">Local:</span>   <span className="text-blue-400 underline">http://localhost:5173/</span></div>
                                                    <div>  <span className="text-green-500 font-bold">➜</span>  <span className="text-[#e4e4e7] font-bold">Network:</span> <span className="text-[#71717a]">use --host to expose</span></div>
                                                </div>
                                            </div>
                                            <div className="flex gap-2 mt-4">
                                                <span className="text-green-500">➜</span>
                                                <span className="text-cyan-500">project-titan</span>
                                                <span className="text-[#71717a]">git:(</span><span className="text-red-500">main</span><span className="text-[#71717a]">)</span>
                                                <span className="animate-pulse block w-2 h-4 bg-[#a1a1aa]" />
                                            </div>
                                        </div>
                                    )}

                                    {bottomPanelTab === 'agents' && (
                                        <AgentOrchestrator />
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                )}
            </div>
            
            {/* Status Bar */}
            <div className="fixed bottom-0 left-0 right-0 h-6 bg-[#007acc] text-white flex items-center px-3 text-[11px] font-medium z-40 select-none shadow-lg">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1 hover:bg-white/10 px-1 rounded cursor-pointer">
                        <GitBranch className="w-3 h-3" /> 
                        <span>main*</span>
                    </div>
                    <div className="flex items-center gap-1 hover:bg-white/10 px-1 rounded cursor-pointer">
                        <RefreshCw className="w-3 h-3" /> 
                        <span>0 errors</span>
                    </div>
                </div>
                <div className="flex-1" />
                <div className="flex items-center gap-4">
                    <span className="hover:bg-white/10 px-1 rounded cursor-pointer">Ln 12, Col 34</span>
                    <span className="hover:bg-white/10 px-1 rounded cursor-pointer">UTF-8</span>
                    <span className="hover:bg-white/10 px-1 rounded cursor-pointer">JavaScript React</span>
                    <div className="flex items-center gap-1 hover:bg-white/10 px-1 rounded cursor-pointer">
                        <Cpu className="w-3 h-3" /> 
                        <span>{selectedModel.name}</span>
                    </div>
                    <div className="flex items-center gap-1 hover:bg-white/10 px-1 rounded cursor-pointer">
                        <div className="w-2 h-2 rounded-full bg-green-400" />
                        <span>Prettier</span>
                    </div>
                </div>
            </div>

            <DeploymentModal 
                open={deploymentOpen} 
                onOpenChange={setDeploymentOpen}
                mode="smart_ship"
            />
        </div>
    );
}

function ActivityIcon({ icon: Icon, active, onClick, className, tooltip }) {
    return (
        <div 
            onClick={onClick}
            className={cn(
                "w-10 h-10 flex items-center justify-center cursor-pointer transition-all relative mb-1 rounded-lg group",
                active ? "text-[#e4e4e7]" : "text-[#52525b] hover:text-[#a1a1aa] hover:bg-[#27272a]",
                className
            )}
            title={tooltip}
        >
            {active && <div className="absolute left-0 top-2 bottom-2 w-0.5 bg-[#e4e4e7] rounded-r-full" />}
            <Icon className="w-5 h-5" strokeWidth={1.5} />
        </div>
    );
}