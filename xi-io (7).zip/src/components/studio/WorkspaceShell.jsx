import React from 'react';
import { 
    Layout, Maximize, Minimize, X, 
    Menu, Settings, Share, Save, 
    MoreHorizontal, Command, ChevronRight
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function WorkspaceShell({ 
    children, 
    mode = 'web', 
    programName = 'Web Architect',
    fileName = 'Untitled',
    project = { name: 'Local Project' },
    task = null,
    toolbar = null,
    sidebar = null,
    statusBar = null,
    onAction
}) {
    return (
        <div className="flex flex-col h-full bg-black text-white overflow-hidden font-sans">
            {/* UNIVERSAL HEADER - LAYER 1: ORIENTATION */}
            <header className="h-10 border-b border-white/10 bg-neutral-900/50 flex items-center justify-between px-3 shrink-0 select-none">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 text-neutral-400 hover:text-white transition-colors cursor-pointer" onClick={() => onAction('home')}>
                        <Layout className="w-4 h-4" />
                        <span className="font-bold text-xs tracking-wider">{programName.toUpperCase()}</span>
                    </div>
                    <div className="h-4 w-px bg-white/10" />
                    <div className="flex items-center gap-2 text-xs">
                        <span className="text-neutral-500">{project.name}</span>
                        <ChevronRight className="w-3 h-3 text-neutral-700" />
                        <span className="text-white font-medium cursor-pointer hover:underline" onClick={() => onAction('open...')}>{fileName}</span>
                        {task && (
                            <>
                                <ChevronRight className="w-3 h-3 text-neutral-700" />
                                <span className="text-[hsl(var(--color-intent))] opacity-80">{task.title}</span>
                            </>
                        )}
                    </div>
                </div>

                {/* Center Toolbar Injection */}
                <div className="absolute left-1/2 -translate-x-1/2">
                    {toolbar}
                </div>

                <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onAction('share')}>
                        <Share className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onAction('save')}>
                        <Save className="w-3 h-3" />
                    </Button>
                    <div className="h-4 w-px bg-white/10" />
                    <Button 
                        size="sm" 
                        className="h-7 text-[10px] bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 font-bold"
                        onClick={() => onAction('publish')}
                    >
                        PUBLISH
                    </Button>
                </div>
            </header>

            {/* MAIN WORKSPACE - LAYER 0: FIELD */}
            <div className="flex-1 flex overflow-hidden relative">
                {/* Left Sidebar (Optional) */}
                {sidebar && (
                    <aside className="w-64 border-r border-white/5 bg-neutral-900/30 flex flex-col z-10 backdrop-blur-sm">
                        {sidebar}
                    </aside>
                )}

                {/* Viewport */}
                <main className="flex-1 relative bg-[#050505] flex flex-col min-w-0">
                    {/* Background Grid/Context */}
                    <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
                        style={{ 
                            backgroundImage: 'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
                            backgroundSize: '40px 40px'
                        }} 
                    />
                    
                    {/* Editor Content */}
                    <div className="relative w-full h-full overflow-hidden">
                        {children}
                    </div>
                </main>

                {/* Right Sidebar (Optional - Properties etc) */}
                {/* Could be injected via children or props, but keeping simple for now */}
            </div>

            {/* UNIVERSAL STATUS BAR - LAYER 2: STATE */}
            <footer className="h-7 border-t border-white/10 bg-neutral-950 flex items-center justify-between px-3 text-[10px] font-mono text-neutral-500 shrink-0 select-none">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))]" />
                        <span>READY</span>
                    </div>
                    {statusBar?.left}
                </div>
                <div className="flex items-center gap-4">
                    {statusBar?.right}
                    <span>KERNEL: v2.4.0</span>
                </div>
            </footer>
        </div>
    );
}