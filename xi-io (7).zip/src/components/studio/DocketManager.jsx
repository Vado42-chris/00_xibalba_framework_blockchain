import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { FolderOpen, Clock, Cloud, HardDrive, FileText, Box, Video, MoreHorizontal } from 'lucide-react';
import { ScrollArea } from "@/components/ui/scroll-area";

const MOCK_FILES = [
    { id: 1, name: 'Hero_Character_V2.glb', type: '3d', size: '24MB', updated: '2h ago' },
    { id: 2, name: 'Promo_Reel_Final.mp4', type: 'video', size: '145MB', updated: '1d ago' },
    { id: 3, name: 'Q4_Financials.xlsx', type: 'document', size: '2MB', updated: '3d ago' },
    { id: 4, name: 'Landing_Page_V1', type: 'web', size: 'N/A', updated: 'Just now' },
    { id: 5, name: 'Cyberpunk_City_Block.glb', type: '3d', size: '1.2GB', updated: '1w ago' },
];

export default function DocketManager({ open, onOpenChange, onFileSelect }) {
    const getIcon = (type) => {
        switch(type) {
            case '3d': return Box;
            case 'video': return Video;
            case 'document': return FileText;
            default: return FileText;
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-[#0a0a0a] border-white/10 text-white max-w-3xl h-[600px] flex flex-col p-0 gap-0 overflow-hidden">
                <div className="h-12 border-b border-white/5 flex items-center px-4 justify-between bg-white/5">
                    <div className="flex items-center gap-2">
                        <FolderOpen className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                        <span className="font-bold tracking-wider text-sm">DOCKET MANAGER</span>
                    </div>
                    <div className="flex gap-2">
                        <input 
                            placeholder="Search filesystem..." 
                            className="bg-black/50 border border-white/10 rounded px-3 py-1 text-xs w-64 focus:outline-none focus:border-[hsl(var(--color-intent))]"
                        />
                    </div>
                </div>

                <div className="flex-1 flex overflow-hidden">
                    {/* Sidebar */}
                    <div className="w-48 border-r border-white/5 bg-black/20 p-2 space-y-1">
                        <div className="px-3 py-2 text-xs font-bold text-neutral-500 uppercase tracking-wider">Locations</div>
                        <button className="w-full text-left px-3 py-2 text-sm rounded hover:bg-white/5 flex items-center gap-2 bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))]">
                            <Cloud className="w-4 h-4" /> Cloud Home
                        </button>
                        <button className="w-full text-left px-3 py-2 text-sm rounded hover:bg-white/5 flex items-center gap-2 text-neutral-400">
                            <Clock className="w-4 h-4" /> Recent
                        </button>
                        <button className="w-full text-left px-3 py-2 text-sm rounded hover:bg-white/5 flex items-center gap-2 text-neutral-400">
                            <HardDrive className="w-4 h-4" /> Local Drive
                        </button>
                    </div>

                    {/* File Grid */}
                    <ScrollArea className="flex-1 p-4">
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                            {MOCK_FILES.map(file => {
                                const Icon = getIcon(file.type);
                                return (
                                    <div 
                                        key={file.id}
                                        onClick={() => onFileSelect(file)}
                                        className="group p-3 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 hover:border-[hsl(var(--color-intent))]/50 cursor-pointer transition-all flex flex-col gap-3"
                                    >
                                        <div className="aspect-square rounded-lg bg-black/50 flex items-center justify-center relative overflow-hidden group-hover:shadow-[0_0_15px_rgba(var(--color-intent),0.2)] transition-all">
                                            <Icon className="w-8 h-8 text-neutral-600 group-hover:text-[hsl(var(--color-intent))] group-hover:scale-110 transition-all duration-300" />
                                            {/* Preview Overlay */}
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-2">
                                                <span className="text-[10px] font-bold uppercase tracking-wider">Open</span>
                                            </div>
                                        </div>
                                        <div>
                                            <div className="text-xs font-medium truncate group-hover:text-white text-neutral-200">{file.name}</div>
                                            <div className="flex justify-between items-center mt-1">
                                                <span className="text-[10px] text-neutral-500">{file.size}</span>
                                                <span className="text-[10px] text-neutral-500">{file.updated}</span>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </ScrollArea>
                </div>
            </DialogContent>
        </Dialog>
    );
}