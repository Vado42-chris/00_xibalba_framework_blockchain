import React, { useState } from 'react';
import { 
    Activity, Zap, Link as LinkIcon, ArrowRight, 
    Trash2, Plus, MousePointer2, PlayCircle 
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useInteraction } from '@/components/interaction/InteractionManager';
import { cn } from "@/lib/utils";

export default function InteractionPalette({ canvasItems = [], onHighlightRule }) {
    const { rules, addRule, removeRule } = useInteraction();
    
    // New Rule State
    const [sourceId, setSourceId] = useState('');
    const [event, setEvent] = useState('click');
    const [targetId, setTargetId] = useState('');
    const [action, setAction] = useState('toggle');

    // Available Events & Actions
    const events = [
        { id: 'click', label: 'On Click', icon: MousePointer2 },
        { id: 'hover', label: 'On Hover', icon: Activity },
        { id: 'mount', label: 'On Load', icon: Zap },
    ];

    const actions = [
        { id: 'toggle', label: 'Toggle Visibility', icon: Zap },
        { id: 'hide', label: 'Hide', icon: Zap },
        { id: 'show', label: 'Show', icon: Zap },
        { id: 'animate', label: 'Trigger Animation', icon: PlayCircle },
        { id: 'update_text', label: 'Update Text', icon: Zap },
    ];

    const handleAdd = () => {
        if (!sourceId || !targetId) return;
        
        addRule({
            sourceId,
            event,
            targetId,
            action,
            payload: {} 
        });
        
        // Reset (optional)
        // setSourceId('');
        // setTargetId('');
    };

    return (
        <div className="h-full flex flex-col bg-neutral-900 border-l border-white/5">
            <div className="p-4 border-b border-white/5">
                <div className="flex items-center gap-2 text-[hsl(var(--color-execution))] mb-1">
                    <Activity className="w-4 h-4" />
                    <span className="font-bold tracking-wider text-xs uppercase">Neural Wiring</span>
                </div>
                <p className="text-[10px] text-neutral-500">Define signal pathways between components.</p>
            </div>

            <div className="p-4 space-y-4 flex-1 overflow-y-auto">
                {/* WIRING FORM */}
                <div className="bg-black/40 rounded-lg p-3 border border-white/5 space-y-3">
                    <div className="space-y-1">
                        <label className="text-[9px] text-neutral-500 uppercase font-bold">When (Trigger)</label>
                        <div className="flex gap-2">
                            <select 
                                className="flex-1 bg-neutral-800 text-xs border border-white/10 rounded px-2 py-1.5"
                                value={sourceId}
                                onChange={e => setSourceId(e.target.value)}
                            >
                                <option value="">Select Source...</option>
                                {canvasItems.map(item => (
                                    <option key={item.id} value={item.id}>
                                        {item.label || item.id}
                                    </option>
                                ))}
                            </select>
                            <select 
                                className="w-24 bg-neutral-800 text-xs border border-white/10 rounded px-2 py-1.5"
                                value={event}
                                onChange={e => setEvent(e.target.value)}
                            >
                                {events.map(ev => (
                                    <option key={ev.id} value={ev.id}>{ev.label}</option>
                                ))}
                            </select>
                        </div>
                    </div>

                    <div className="flex justify-center">
                        <ArrowRight className="w-4 h-4 text-neutral-600 rotate-90" />
                    </div>

                    <div className="space-y-1">
                        <label className="text-[9px] text-neutral-500 uppercase font-bold">Do (Action)</label>
                        <div className="flex gap-2">
                            <select 
                                className="flex-1 bg-neutral-800 text-xs border border-white/10 rounded px-2 py-1.5"
                                value={targetId}
                                onChange={e => setTargetId(e.target.value)}
                            >
                                <option value="">Select Target...</option>
                                {canvasItems.map(item => (
                                    <option key={item.id} value={item.id}>
                                        {item.label || item.id}
                                    </option>
                                ))}
                            </select>
                            <select 
                                className="w-24 bg-neutral-800 text-xs border border-white/10 rounded px-2 py-1.5"
                                value={action}
                                onChange={e => setAction(e.target.value)}
                            >
                                {actions.map(ac => (
                                    <option key={ac.id} value={ac.id}>{ac.label}</option>
                                ))}
                            </select>
                        </div>
                    </div>

                    <Button 
                        size="sm" 
                        className="w-full bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/80 mt-2"
                        onClick={handleAdd}
                        disabled={!sourceId || !targetId}
                    >
                        <LinkIcon className="w-3 h-3 mr-2" />
                        Connect Nodes
                    </Button>
                </div>

                {/* ACTIVE CONNECTIONS */}
                <div className="space-y-2">
                    <div className="text-[9px] text-neutral-500 uppercase font-bold px-1">Active Synapses</div>
                    {rules.length === 0 && (
                        <div className="text-xs text-neutral-600 italic text-center py-4">
                            No connections established.
                        </div>
                    )}
                    {rules.map((rule, idx) => {
                        const source = canvasItems.find(i => i.id === rule.sourceId);
                        const target = canvasItems.find(i => i.id === rule.targetId);
                        
                        return (
                            <div 
                                key={idx} 
                                className="group relative bg-neutral-800/30 rounded border border-white/5 p-2 text-xs flex items-center justify-between hover:border-[hsl(var(--color-execution))]/30 transition-colors cursor-crosshair"
                                onMouseEnter={() => onHighlightRule && onHighlightRule({ triggerId: rule.sourceId, targetId: rule.targetId })}
                                onMouseLeave={() => onHighlightRule && onHighlightRule(null)}
                            >
                                <div className="flex items-center gap-2 overflow-hidden">
                                    <div className="flex items-center gap-1 min-w-0">
                                        <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-warning))]" />
                                        <span className="truncate max-w-[60px]">{source?.label || rule.sourceId}</span>
                                    </div>
                                    <ArrowRight className="w-3 h-3 text-neutral-600 shrink-0" />
                                    <div className="flex items-center gap-1 min-w-0">
                                        <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))]" />
                                        <span className="truncate max-w-[60px]">{target?.label || rule.targetId}</span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2 ml-2">
                                    <span className="text-[9px] font-mono text-neutral-500 bg-neutral-900 px-1 rounded">
                                        {rule.event}→{rule.action}
                                    </span>
                                    <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity hover:text-[hsl(var(--color-error))]"
                                        onClick={() => removeRule(rule.id)}
                                    >
                                        <Trash2 className="w-3 h-3" />
                                    </Button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}