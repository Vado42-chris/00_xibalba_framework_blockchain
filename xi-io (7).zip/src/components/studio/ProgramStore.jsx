import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Package, Download, Check, Star } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

const PROGRAMS = [
    { id: 'p1', name: 'Voxel Forge', description: 'Advanced 3D modeling and sculpting suite.', category: '3D', installed: true, icon: '🧊' },
    { id: 'p2', name: 'Cinema Node', description: 'Non-linear video editing with AI frame interpolation.', category: 'Video', installed: true, icon: '🎬' },
    { id: 'p3', name: 'Ledger Suite', description: 'Secure document and spreadsheet editor.', category: 'Office', installed: true, icon: '📊' },
    { id: 'p4', name: 'Synth Audio', description: 'DAW for sound design and mixing.', category: 'Audio', installed: false, icon: '🎹' },
    { id: 'p5', name: 'Vector Cad', description: 'Precision CAD tools for engineering.', category: 'Design', installed: false, icon: '📐' },
];

export default function ProgramStore({ open, onOpenChange, onInstall }) {
    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-[#0a0a0a] border-white/10 text-white max-w-2xl">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Package className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                        Program Store
                    </DialogTitle>
                </DialogHeader>
                <div className="py-4">
                    <ScrollArea className="h-[400px] pr-4">
                        <div className="space-y-3">
                            {PROGRAMS.map(prog => (
                                <div key={prog.id} className="flex items-center gap-4 p-4 rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-colors">
                                    <div className="w-12 h-12 rounded-lg bg-black flex items-center justify-center text-2xl">
                                        {prog.icon}
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2">
                                            <h3 className="font-bold text-sm">{prog.name}</h3>
                                            <span className="px-1.5 py-0.5 rounded text-[10px] bg-white/10 border border-white/5 text-neutral-400">{prog.category}</span>
                                        </div>
                                        <p className="text-xs text-neutral-400 mt-1">{prog.description}</p>
                                    </div>
                                    <Button 
                                        size="sm" 
                                        variant={prog.installed ? "secondary" : "default"}
                                        disabled={prog.installed}
                                        onClick={() => onInstall(prog)}
                                        className={prog.installed ? "bg-white/5 text-neutral-500" : "bg-[hsl(var(--color-intent))] text-black"}
                                    >
                                        {prog.installed ? (
                                            <>
                                                <Check className="w-3 h-3 mr-1" /> Installed
                                            </>
                                        ) : (
                                            <>
                                                <Download className="w-3 h-3 mr-1" /> Install
                                            </>
                                        )}
                                    </Button>
                                </div>
                            ))}
                        </div>
                    </ScrollArea>
                </div>
            </DialogContent>
        </Dialog>
    );
}