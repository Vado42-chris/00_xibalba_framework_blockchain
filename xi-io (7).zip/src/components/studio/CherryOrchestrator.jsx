import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Aperture, Eye, Image as ImageIcon, Layers, 
    RefreshCw, Zap, Maximize2, Monitor, Wifi,
    Activity, Play, Pause, XCircle, Plus
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer 
} from '@/components/ui/design-system/System';
import { cn } from '@/lib/utils';
import { toast } from "sonner";
import { LoadingLab } from '@/components/ui/design-system/Curiosity';

export default function CherryOrchestrator() {
    const [selectedAgent, setSelectedAgent] = useState(null);
    const [selectedModel, setSelectedModel] = useState('flux-schnell');
    const queryClient = useQueryClient();

    const models = [
        { id: 'flux-schnell', name: 'Flux.1 Schnell', vram: '12GB' },
        { id: 'flux-dev', name: 'Flux.1 Dev', vram: '24GB' },
        { id: 'sdxl-turbo', name: 'SDXL Turbo', vram: '8GB' },
        { id: 'stable-cascade', name: 'Stable Cascade', vram: '16GB' }
    ];

    // --- DATA FETCHING ---
    const { data: agents = [] } = useQuery({
        queryKey: ['agents'],
        queryFn: () => base44.entities.Agent.list(),
    });

    const { data: tasks = [] } = useQuery({
        queryKey: ['visual_tasks'],
        queryFn: () => base44.entities.VisualTask.list(),
    });
    
    // --- FILE UPLOAD MOCK ---
    const [uploading, setUploading] = useState(false);
    
    const handleFileUpload = () => {
        setUploading(true);
        setTimeout(() => {
            setUploading(false);
            toast.success("Asset imported from local file system");
        }, 2000);
    };

    const { data: sessions = [] } = useQuery({
        queryKey: ['cherry_sessions'],
        queryFn: () => base44.entities.CherrySession.list(),
        initialData: [
            { id: 'mock-1', hostname: 'local-station-1', status: 'connected', active_observers: 1, gpu_load: 42, current_focus: "Adobe Photoshop 2024" }
        ]
    });

    // --- MOCK MUTATIONS ---
    const connectMutation = useMutation({
        mutationFn: async () => {
            await new Promise(r => setTimeout(r, 1500));
            return { success: true };
        },
        onSuccess: () => {
            toast.success("Cherry Studio Bridge Established");
        }
    });

    const activeSession = sessions.find(s => s.status === 'connected');
    const visualAgents = agents.filter(a => a.capabilities?.includes('visual') || a.role.toLowerCase().includes('designer') || a.role.toLowerCase().includes('artist'));

    return (
        <div className="h-full w-full bg-transparent p-6 overflow-hidden flex flex-col gap-6">
            
            {/* Header / Bridge Status */}
            <div className="flex items-center justify-between p-4 bg-neutral-900 border border-white/10 rounded-lg shrink-0">
                <div className="flex items-center gap-4">
                    <div className="p-2 bg-neutral-950 rounded border border-white/5">
                        <Aperture className="w-6 h-6 text-[hsl(var(--color-active))]" />
                    </div>
                    <div>
                        <div className="flex items-center gap-2">
                            <IntentText className="font-bold text-lg">CHERRY STUDIO <span className="opacity-50">BRIDGE</span></IntentText>
                            {activeSession ? (
                                <Badge variant="outline" className="bg-pink-500/10 text-pink-500 border-pink-500/20 text-[10px] animate-pulse">
                                    LIVE
                                </Badge>
                            ) : (
                                <Badge variant="outline" className="bg-neutral-800 text-neutral-500 border-white/5 text-[10px]">
                                    OFFLINE
                                </Badge>
                            )}
                        </div>
                        <StateText className="text-xs opacity-50 font-mono">
                            {activeSession ? `Host: ${activeSession.hostname} • GPU: ${activeSession.gpu_load}%` : "Connecting to local vision server..."}
                        </StateText>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <div className="text-right hidden sm:block">
                        <div className="text-[10px] text-[hsl(var(--fg-orientation))] font-mono">OBSERVER LATENCY</div>
                        <div className="text-xs font-mono text-[hsl(var(--color-active))]">12ms</div>
                    </div>
                    <Button 
                        disabled={connectMutation.isPending || !!activeSession}
                        onClick={() => connectMutation.mutate()}
                        className={cn(
                            "w-32",
                            activeSession ? "bg-red-900/20 text-red-500 hover:bg-red-900/40" : "bg-[hsl(var(--color-active))] text-white"
                        )}
                    >
                        {connectMutation.isPending ? <RefreshCw className="w-4 h-4 animate-spin" /> : activeSession ? "Disconnect" : "Connect"}
                    </Button>
                </div>
            </div>

            {/* Main Grid */}
            <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* LEFT: Visual Agents */}
                <div className="lg:col-span-1 flex flex-col bg-neutral-900/30 border border-white/5 rounded-lg overflow-hidden">
                    <div className="p-3 border-b border-white/5 bg-neutral-900/50 flex justify-between items-center">
                        <OrientingText className="tracking-widest">VISUAL AGENTS</OrientingText>
                        <Badge variant="outline" className="text-[9px] h-5">{visualAgents.length} Ready</Badge>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 space-y-2">
                        {visualAgents.length > 0 ? visualAgents.map(agent => (
                            <div 
                                key={agent.id}
                                onClick={() => setSelectedAgent(agent)}
                                className={cn(
                                    "p-3 rounded border cursor-pointer transition-all group relative overflow-hidden",
                                    selectedAgent?.id === agent.id ? "bg-[hsl(var(--color-intent))]/10 border-[hsl(var(--color-intent))]" : "bg-neutral-900 border-white/5 hover:border-white/20"
                                )}
                            >
                                <div className="flex justify-between items-start relative z-10">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded bg-neutral-950 flex items-center justify-center border border-white/10">
                                            <Eye className="w-4 h-4 text-[hsl(var(--fg-intent))]" />
                                        </div>
                                        <div>
                                            <div className="text-sm font-bold text-white">{agent.name}</div>
                                            <div className="text-[10px] text-neutral-500 font-mono">{agent.role}</div>
                                        </div>
                                    </div>
                                    <SemanticDot type={agent.status === 'executing' ? 'active' : 'settled'} />
                                </div>
                                {agent.capabilities?.includes('observer') && (
                                    <div className="mt-3 flex items-center gap-2 text-[10px] text-[hsl(var(--color-intent))] font-mono bg-black/20 p-1.5 rounded relative z-10">
                                        <Monitor className="w-3 h-3" />
                                        <span>Local Observer Active</span>
                                    </div>
                                )}
                            </div>
                        )) : (
                            <div className="text-center py-8 opacity-50">
                                <Aperture className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                                <OrientingText>No visual agents deployed</OrientingText>
                            </div>
                        )}
                        <Button variant="ghost" className="w-full border border-dashed border-white/10 hover:bg-white/5 text-xs text-neutral-500">
                            <Plus className="w-3 h-3 mr-2" /> Deploy Artist
                        </Button>
                        
                        <div className="mt-4 pt-4 border-t border-white/5">
                            <div className="flex items-center justify-between mb-2">
                                <OrientingText className="text-[10px] opacity-70">LOCAL BRIDGE</OrientingText>
                                <Badge variant="outline" className="text-[9px] bg-green-500/10 text-green-500 border-green-500/20">READY</Badge>
                            </div>
                            <div 
                                onClick={handleFileUpload}
                                className="border-2 border-dashed border-white/10 rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer hover:border-[hsl(var(--color-intent))] hover:bg-white/5 transition-all group"
                            >
                                {uploading ? (
                                    <div className="flex flex-col items-center">
                                        <RefreshCw className="w-5 h-5 text-[hsl(var(--color-intent))] animate-spin mb-2" />
                                        <span className="text-[10px] text-neutral-500">Syncing...</span>
                                    </div>
                                ) : (
                                    <>
                                        <ImageIcon className="w-5 h-5 text-neutral-600 group-hover:text-[hsl(var(--color-intent))] mb-2" />
                                        <span className="text-[10px] text-neutral-500 group-hover:text-white">Drag assets here</span>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* MIDDLE: Active Visual Pipeline */}
                <div className="lg:col-span-1 flex flex-col bg-neutral-900/30 border border-white/5 rounded-lg overflow-hidden">
                    <div className="p-3 border-b border-white/5 bg-neutral-900/50 flex justify-between items-center">
                        <OrientingText className="tracking-widest">RENDER PIPELINE</OrientingText>
                        <div className="flex gap-2 items-center">
                             <select 
                                value={selectedModel}
                                onChange={(e) => setSelectedModel(e.target.value)}
                                className="bg-neutral-900 border border-white/10 rounded text-[10px] h-5 px-1 text-white outline-none"
                             >
                                {models.map(m => (
                                    <option key={m.id} value={m.id}>{m.name}</option>
                                ))}
                             </select>
                             <Button size="icon" variant="ghost" className="h-5 w-5"><RefreshCw className="w-3 h-3" /></Button>
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-3 space-y-2">
                        {tasks.length > 0 ? tasks.map(task => (
                            <div key={task.id} className="p-3 bg-neutral-900 rounded border border-white/5 hover:border-[hsl(var(--color-intent))] transition-colors group">
                                <div className="flex justify-between items-start mb-2">
                                    <Badge variant="outline" className={cn(
                                        "text-[9px] border-none",
                                        task.status === 'processing' ? "bg-blue-500/20 text-blue-400" :
                                        task.status === 'completed' ? "bg-green-500/20 text-green-400" :
                                        "bg-neutral-800 text-neutral-400"
                                    )}>
                                        {task.type.toUpperCase()}
                                    </Badge>
                                    <span className="text-[10px] font-mono text-neutral-600">{task.resolution}</span>
                                </div>
                                <IntentText className="text-xs font-medium mb-1 line-clamp-2 opacity-80">{task.prompt}</IntentText>
                                
                                {task.status === 'processing' ? (
                                    <div className="mt-3 h-1 w-full bg-neutral-800 rounded-full overflow-hidden">
                                        <div className="h-full bg-[hsl(var(--color-intent))] w-2/3 animate-[progress_1s_infinite_linear]" 
                                             style={{ backgroundSize: '20px 20px', backgroundImage: 'linear-gradient(45deg,rgba(255,255,255,.15) 25%,transparent 25%,transparent 50%,rgba(255,255,255,.15) 50%,rgba(255,255,255,.15) 75%,transparent 75%,transparent)' }} 
                                        />
                                    </div>
                                ) : task.output_url ? (
                                    <div className="mt-2 aspect-video bg-black rounded overflow-hidden relative group/img">
                                        <img src={task.output_url} className="w-full h-full object-cover opacity-50 group-hover/img:opacity-100 transition-opacity" alt="Result" />
                                        <div className="absolute bottom-1 right-1 bg-black/50 text-white text-[9px] px-1 rounded">FLUX.1</div>
                                    </div>
                                ) : null}
                            </div>
                        )) : (
                             <div className="text-center py-8 opacity-50">
                                <Layers className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                                <OrientingText>Pipeline idle</OrientingText>
                            </div>
                        )}
                    </div>
                </div>

                {/* RIGHT: Observer Feed */}
                <div className="lg:col-span-1 flex flex-col gap-6">
                    {/* Live View */}
                    <div className="bg-neutral-900/50 border border-white/5 rounded-lg p-1 flex flex-col gap-1 relative overflow-hidden h-[240px]">
                        <div className="absolute top-3 left-3 z-10 flex gap-2">
                             <Badge variant="destructive" className="animate-pulse bg-red-500 text-white border-none text-[9px]">LIVE FEED</Badge>
                             <div className="bg-black/50 backdrop-blur px-2 rounded text-[9px] text-white flex items-center">
                                 <Monitor className="w-3 h-3 mr-1" />
                                 {activeSession?.current_focus || "Desktop"}
                             </div>
                        </div>
                        
                        {/* Mock Screen Content */}
                        <div className="flex-1 bg-black rounded relative overflow-hidden group">
                            <div className="absolute inset-0 flex items-center justify-center opacity-20">
                                <ImageIcon className="w-16 h-16 text-neutral-500" />
                            </div>
                            <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-black/80 to-transparent p-3 flex flex-col justify-end">
                                <div className="text-[10px] font-mono text-[hsl(var(--color-active))]">>> Analysis: User is editing a vector path...</div>
                                <div className="text-[10px] font-mono text-neutral-400">>> Suggestion: Simplify nodes for cleaner SVG export.</div>
                            </div>
                            
                            {/* Static overlay effect */}
                            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 pointer-events-none mix-blend-overlay"></div>
                        </div>
                    </div>

                    {/* Agent Output Log */}
                    <div className="flex-1 bg-black border border-white/10 rounded-lg p-4 font-mono text-[10px] text-neutral-400 overflow-y-auto min-h-[150px]">
                        <div className="text-[hsl(var(--color-active))] mb-2">$ tail -f cherry_observer_log</div>
                        <div className="opacity-50">[14:21:05] Observer attached to PID 4412 (Photoshop)</div>
                        <div className="opacity-50">[14:21:08] Screen capture buffer initialized.</div>
                        <div className="text-pink-400">[14:21:12] Agent 'Iris' detecting color palette change...</div>
                        <div className="text-blue-400">[14:21:15] Context update: #F42211 added to swatches.</div>
                        <div>[14:21:20] Syncing asset library... OK</div>
                    </div>
                </div>
            </div>
        </div>
    );
}