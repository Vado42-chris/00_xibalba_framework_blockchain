import { 
    Zap, RefreshCw, Eye, EyeOff, Camera, UploadCloud
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export const CherryTools = () => {
    const handleSync = () => {
        toast.promise(new Promise(r => setTimeout(r, 2000)), {
            loading: 'Syncing assets from Cherry Studio...',
            success: 'Assets synced',
            error: 'Sync failed'
        });
    };

    return (
        <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" className="h-auto flex flex-col gap-1 py-3 border-white/5 bg-neutral-900 hover:bg-neutral-800" onClick={handleSync}>
                    <UploadCloud className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <span className="text-[10px] font-bold">Sync Assets</span>
                </Button>
                <Button variant="outline" className="h-auto flex flex-col gap-1 py-3 border-white/5 bg-neutral-900 hover:bg-neutral-800">
                    <Camera className="w-4 h-4 text-[hsl(var(--color-active))]" />
                    <span className="text-[10px] font-bold">Snapshot</span>
                </Button>
            </div>
            <Button variant="ghost" className="w-full justify-start text-[10px] text-neutral-400 h-8 hover:text-[hsl(var(--color-intent))]">
                <Eye className="w-3 h-3 mr-2" /> Enable Observer
            </Button>
        </div>
    );
};