import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Search, Database, Server, Globe, 
    Filter, BarChart, Settings, Sliders,
    Shield, Network, Code, RefreshCw
} from 'lucide-react';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, 
    StateText, SemanticDot, Layer
} from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export default function SearchForge() {
    const [config, setConfig] = useState({
        name: 'XI Search',
        type: 'meta', // meta, crawler, hybrid
        indexFrequency: 30, // minutes
        privacyLevel: 'strict',
        sources: {
            google: true,
            ddg: true,
            bing: false,
            local: true
        }
    });

    const [deploying, setDeploying] = useState(false);

    const createServiceMutation = useMutation({
        mutationFn: (data) => base44.entities.ServerService.create(data),
    });

    const createLogMutation = useMutation({
        mutationFn: (data) => base44.entities.DeploymentLog.create(data),
    });

    const handleDeploy = () => {
        setDeploying(true);
        setTimeout(() => {
            setDeploying(false);
            toast.success("Search engine deployed to local node");

            // Persist Records
            createServiceMutation.mutate({
                name: config.name,
                node_id: 'local-node-01',
                status: 'running',
                version: 'v1.0.0',
                uptime: '0m',
                cpu_usage: 5,
                memory_usage: 256
            });

            createLogMutation.mutate({
                node_id: 'local-node-01',
                node_name: 'Local Node',
                status: 'success',
                version: 'v1.0.0',
                description: `Deployed search indexer: ${config.name} (${config.type})`
            });

        }, 2000);
    };

    return (
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="state" dominance="dominant" className="border-r border-white/5 h-full p-0 flex flex-col">
                        <div className="p-6 border-b border-white/5 bg-neutral-900/10">
                            <div className="flex items-center gap-2 mb-2">
                                <Search className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                                <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">SEARCH FORGE</OrientingText>
                            </div>
                            <IntentText className="text-xl font-light">Sovereign Index</IntentText>
                            <StateText className="mt-2 text-xs opacity-70">
                                Deploy a private search instance. Aggregate results from multiple providers or crawl specific domains for your own index.
                            </StateText>
                        </div>

                        <div className="flex-1 overflow-y-auto p-6 space-y-8">
                            {/* Engine Config */}
                            <div className="space-y-4">
                                <OrientingText>ENGINE ARCHITECTURE</OrientingText>
                                <div className="space-y-2">
                                    <StateText>Instance Name</StateText>
                                    <Input 
                                        value={config.name}
                                        onChange={(e) => setConfig({...config, name: e.target.value})}
                                        className="bg-neutral-900 border-white/10 font-mono text-xs"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <StateText>Index Strategy</StateText>
                                    <div className="grid grid-cols-3 gap-2">
                                        {[
                                            { id: 'meta', label: 'Meta Search', icon: Network },
                                            { id: 'crawler', label: 'Web Crawler', icon: Globe },
                                            { id: 'hybrid', label: 'Hybrid', icon: Database }
                                        ].map(type => (
                                            <button
                                                key={type.id}
                                                onClick={() => setConfig({...config, type: type.id})}
                                                className={cn(
                                                    "p-2 rounded border text-xs font-medium transition-all flex flex-col items-center gap-2",
                                                    config.type === type.id 
                                                        ? "bg-[hsl(var(--color-execution))]/20 border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))]" 
                                                        : "bg-neutral-900 border-white/10 text-neutral-400 hover:border-white/20"
                                                )}
                                            >
                                                <type.icon className="w-4 h-4" />
                                                {type.label}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* Sources */}
                            <div className="space-y-4">
                                <OrientingText>DATA SOURCES</OrientingText>
                                <div className="space-y-2">
                                    {Object.entries(config.sources).map(([source, enabled]) => (
                                        <div key={source} className="flex items-center justify-between p-2 rounded bg-neutral-900/30 border border-white/5">
                                            <div className="text-xs font-medium text-white capitalize">{source}</div>
                                            <Switch 
                                                checked={enabled}
                                                onCheckedChange={(c) => setConfig({
                                                    ...config, 
                                                    sources: {...config.sources, [source]: c}
                                                })}
                                                className="data-[state=checked]:bg-[hsl(var(--color-execution))]"
                                            />
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Ranking */}
                            <div className="space-y-4">
                                <OrientingText>RANKING BIAS</OrientingText>
                                <div className="p-4 bg-neutral-900/30 rounded border border-white/5 space-y-4">
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-xs text-neutral-400">
                                            <span>Privacy vs Personalization</span>
                                            <span className="text-[hsl(var(--color-execution))]">Strict Privacy</span>
                                        </div>
                                        <Slider defaultValue={[90]} max={100} step={1} className="[&>span]:bg-[hsl(var(--color-execution))]" />
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-xs text-neutral-400">
                                            <span>Recency Bias</span>
                                            <span className="text-[hsl(var(--color-execution))]">Balanced</span>
                                        </div>
                                        <Slider defaultValue={[50]} max={100} step={1} className="[&>span]:bg-[hsl(var(--color-execution))]" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col bg-neutral-950">
                        <div className="flex-1 p-8 flex flex-col gap-6">
                            <div className="flex justify-between items-center">
                                <IntentText className="text-2xl font-light">Live Console</IntentText>
                                <Button 
                                    onClick={handleDeploy}
                                    disabled={deploying}
                                    className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                                >
                                    {deploying ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Server className="w-4 h-4 mr-2" />}
                                    {deploying ? 'INITIALIZING POD...' : 'DEPLOY SERVICE'}
                                </Button>
                            </div>

                            {/* Search Dashboard Mockup */}
                            <div className="flex-1 bg-neutral-900 rounded-lg border border-white/10 overflow-hidden flex flex-col">
                                <div className="p-4 border-b border-white/5 bg-neutral-800 flex items-center justify-between">
                                    <div className="flex items-center gap-2">
                                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                                        <span className="text-xs font-mono text-green-400">SYSTEM.ACTIVE</span>
                                    </div>
                                    <div className="text-xs font-mono text-neutral-500">
                                        PORT: 8080 | QPS: 0
                                    </div>
                                </div>
                                
                                <div className="flex-1 p-8 flex flex-col items-center justify-center gap-8 relative overflow-hidden">
                                    {/* Abstract Data Flow Visualization */}
                                    <div className="absolute inset-0 opacity-10">
                                        <div className="absolute top-1/2 left-0 right-0 h-px bg-[hsl(var(--color-execution))]" />
                                        <div className="absolute top-0 bottom-0 left-1/2 w-px bg-[hsl(var(--color-execution))]" />
                                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,black_100%)]" />
                                    </div>

                                    <div className="relative z-10 text-center space-y-6">
                                        <div className="inline-flex items-center justify-center w-24 h-24 rounded-full border border-[hsl(var(--color-execution))]/30 bg-[hsl(var(--color-execution))]/10 mb-4">
                                            <Search className="w-10 h-10 text-[hsl(var(--color-execution))]" />
                                        </div>
                                        <div>
                                            <h2 className="text-3xl font-light text-white mb-2">{config.name}</h2>
                                            <p className="text-neutral-500 max-w-md mx-auto">
                                                Private search aggregator running on local metal.
                                                Zero telemetry. Enforced privacy.
                                            </p>
                                        </div>
                                        
                                        <div className="grid grid-cols-3 gap-4 max-w-lg mx-auto w-full">
                                            <div className="p-4 rounded border border-white/5 bg-black/40 backdrop-blur text-center">
                                                <div className="text-2xl font-mono text-white mb-1">0ms</div>
                                                <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Latency</div>
                                            </div>
                                            <div className="p-4 rounded border border-white/5 bg-black/40 backdrop-blur text-center">
                                                <div className="text-2xl font-mono text-white mb-1">0</div>
                                                <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Queries</div>
                                            </div>
                                            <div className="p-4 rounded border border-white/5 bg-black/40 backdrop-blur text-center">
                                                <div className="text-2xl font-mono text-white mb-1">100%</div>
                                                <div className="text-[10px] text-neutral-500 uppercase tracking-widest">Uptime</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    );
}