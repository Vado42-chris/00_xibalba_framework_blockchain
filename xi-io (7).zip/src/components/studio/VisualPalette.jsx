import React, { useState } from 'react';
import { Droppable, Draggable } from '@hello-pangea/dnd';
import { Search, GripVertical, ChevronRight, X, Layers, Box, Type, MousePointer2, Component, Eye, Lock, Image as ImageIcon } from 'lucide-react';
import { cn } from "@/lib/utils";
import UnifiedItemWrapper from './UnifiedItemWrapper';
import InteractionPalette from './InteractionPalette';

export default function VisualPalette({ 
    items = [], 
    onClose, 
    selectedItem, 
    onUpdateItem, 
    canvasItems = [], 
    onSelectItem,
    onHighlightRule,
    mode = 'web' // web, 3d, video, document
}) {
    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState('library'); // library, layers, properties, logic

    // Mapping for tab labels based on mode
    const TAB_CONFIG = {
        web: { library: 'Library', layers: 'Layers', styles: 'Styles', logic: 'Logic' },
        '3d': { library: 'Assets', layers: 'Scene', styles: 'Materials', logic: 'Nodes' },
        video: { library: 'Media', layers: 'Tracks', styles: 'Grading', logic: 'Keyframes' },
        document: { library: 'Insert', layers: 'Outline', styles: 'Theme', logic: 'Review' }
    };

    const labels = TAB_CONFIG[mode] || TAB_CONFIG.web;

    // If items have categories, use them. If flat list, wrap in default category.
    const normalizedCategories = items.length > 0 && items[0].items 
        ? items 
        : [{ category: "Components", items: items }];

    const filteredCategories = normalizedCategories.map(cat => ({
        ...cat,
        items: cat.items.filter(item => 
            (item.label || item.name || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
            (item.type || '').toLowerCase().includes(searchTerm.toLowerCase())
        )
    })).filter(cat => cat.items.length > 0);

    const handleUpdateRules = (newRules) => {
        if (selectedItem) {
            onUpdateItem(selectedItem.id || selectedItem.uniqueId, { interactions: newRules });
        }
    };

    return (
        <div className="w-full h-full flex flex-col">
            
            {/* Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                    <Box className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    <span className="font-bold text-sm tracking-wide">FORGE</span>
                </div>
                {onClose && (
                    <button onClick={onClose} className="text-neutral-500 hover:text-white">
                        <X className="w-4 h-4" />
                    </button>
                )}
            </div>

            {/* Tabs */}
            <div className="flex border-b border-white/5 shrink-0">
                <button 
                    onClick={() => setActiveTab('library')}
                    className={cn(
                        "flex-1 py-3 text-xs font-medium uppercase tracking-wider transition-colors",
                        activeTab === 'library' ? "text-white border-b-2 border-[hsl(var(--color-execution))]" : "text-neutral-500 hover:text-white"
                    )}
                >
                    {labels.library}
                </button>
                <button 
                    onClick={() => setActiveTab('layers')}
                    className={cn(
                        "flex-1 py-3 text-xs font-medium uppercase tracking-wider transition-colors",
                        activeTab === 'layers' ? "text-white border-b-2 border-[hsl(var(--color-execution))]" : "text-neutral-500 hover:text-white"
                    )}
                >
                    {labels.layers}
                </button>
                <button 
                    onClick={() => setActiveTab('styles')}
                    className={cn(
                        "flex-1 py-3 text-xs font-medium uppercase tracking-wider transition-colors",
                        activeTab === 'styles' ? "text-white border-b-2 border-[hsl(var(--color-execution))]" : "text-neutral-500 hover:text-white"
                    )}
                >
                    {labels.styles}
                </button>
                <button 
                    onClick={() => setActiveTab('logic')}
                    className={cn(
                        "flex-1 py-3 text-xs font-medium uppercase tracking-wider transition-colors",
                        activeTab === 'logic' ? "text-white border-b-2 border-[hsl(var(--color-execution))]" : "text-neutral-500 hover:text-white"
                    )}
                >
                    {labels.logic}
                </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto xi-scroll p-0">

                {activeTab === 'library' && (
                    <div className="p-4 space-y-6">
                        {/* Search */}
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                            <input 
                                type="text"
                                placeholder="Search components..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full bg-black/50 border border-white/10 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-[hsl(var(--color-execution))]"
                            />
                        </div>

                        <Droppable droppableId="palette" isDropDisabled={true}>
                            {(provided) => (
                                <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-6">
                                    {filteredCategories.map((category, idx) => (
                                        <div key={idx}>
                                            <h3 className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest mb-3">{category.category}</h3>
                                            <div className="grid grid-cols-2 gap-2">
                                                {category.items.map((item, itemIdx) => (
                                                    <Draggable key={item.id} draggableId={item.id} index={itemIdx}>
                                                        {(provided, snapshot) => (
                                                            <>
                                                                <div
                                                                    ref={provided.innerRef}
                                                                    {...provided.draggableProps}
                                                                    {...provided.dragHandleProps}
                                                                    className={cn(
                                                                        "p-3 bg-neutral-800/50 border border-white/5 rounded-lg hover:bg-neutral-800 hover:border-white/20 transition-all cursor-grab active:cursor-grabbing group",
                                                                        snapshot.isDragging && "opacity-50"
                                                                    )}
                                                                >
                                                                    <div className="flex flex-col items-center gap-2 text-center">
                                                                        <div className="w-8 h-8 rounded-full bg-black/50 flex items-center justify-center text-neutral-400 group-hover:text-white transition-colors">
                                                                            {item.icon ? <item.icon className="w-4 h-4" /> : <Component className="w-4 h-4" />}
                                                                        </div>
                                                                        <span className="text-[10px] font-medium text-neutral-300 group-hover:text-white leading-tight">{item.label || item.name}</span>
                                                                    </div>
                                                                </div>
                                                                {/* Clone for dragging visual */}
                                                                {snapshot.isDragging && (
                                                                    <div className="hidden">Clone</div>
                                                                )}
                                                            </>
                                                        )}
                                                    </Draggable>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                    {provided.placeholder}
                                </div>
                            )}
                        </Droppable>
                    </div>
                )}

                {activeTab === 'layers' && (
                    <div className="flex flex-col h-full">
                        <div className="p-2 border-b border-white/5 flex items-center justify-between text-[10px] text-neutral-500 font-bold uppercase tracking-wider bg-neutral-900/50">
                            <span>Layer Tree</span>
                            <span>{canvasItems.length} Items</span>
                        </div>
                        <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
                            {canvasItems.length === 0 ? (
                                <div className="text-center text-neutral-500 text-xs py-8 opacity-50">
                                    <Layers className="w-8 h-8 mx-auto mb-2 opacity-20" />
                                    No layers yet.
                                </div>
                            ) : (
                                canvasItems.map((item, index) => {
                                    const isSelected = selectedItem?.id === item.id || selectedItem?.uniqueId === item.uniqueId;
                                    return (
                                        <div 
                                            key={item.id || item.uniqueId || index}
                                            onClick={() => onSelectItem(item)}
                                            className={cn(
                                                "flex items-center gap-2 px-2 py-1.5 rounded-sm cursor-pointer transition-all border border-transparent group",
                                                isSelected 
                                                    ? "bg-[hsl(var(--color-execution))]/20 border-[hsl(var(--color-execution))]/30 text-white" 
                                                    : "hover:bg-white/5 text-neutral-400 hover:text-white"
                                            )}
                                        >
                                            {/* Indentation Mock if grouped */}
                                            {/* <div className="w-2" /> */}

                                            {item.type === 'container' || item.type === 'group' ? (
                                                <Box className={cn("w-3 h-3", isSelected ? "text-[hsl(var(--color-execution))]" : "text-blue-400")} />
                                            ) : item.type === 'image' ? (
                                                <ImageIcon className="w-3 h-3 text-purple-400" />
                                            ) : item.type === 'text' ? (
                                                <Type className="w-3 h-3 text-neutral-500" />
                                            ) : (
                                                <Layers className="w-3 h-3 text-neutral-600" />
                                            )}

                                            <span className="text-[11px] truncate flex-1 font-medium">{item.label || item.name || 'Untitled'}</span>

                                            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button className="p-1 hover:bg-white/10 rounded"><Eye className="w-3 h-3" /></button>
                                                <button className="p-1 hover:bg-white/10 rounded"><Lock className="w-3 h-3" /></button>
                                            </div>
                                        </div>
                                    );
                                })
                            )}
                        </div>
                    </div>
                )}

                {activeTab === 'styles' && (
                    <div className="p-4 space-y-6">
                        <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                            <h4 className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-2">Design Tokens</h4>
                            <div className="grid grid-cols-2 gap-2">
                                {[
                                    { label: 'Intent', class: 'bg-[hsl(var(--color-intent))] text-black' },
                                    { label: 'Exec', class: 'bg-[hsl(var(--color-execution))] text-black' },
                                    { label: 'Orient', class: 'bg-[hsl(var(--color-orientation))] text-white' },
                                    { label: 'Glass', class: 'bg-white/10 backdrop-blur-md border-white/20' },
                                    { label: 'Card', class: 'bg-neutral-900 border-white/10' },
                                    { label: 'Void', class: 'bg-black border-white/5' }
                                ].map(token => (
                                    <Draggable key={token.label} draggableId={`token-${token.label}`} index={0}>
                                        {(provided) => (
                                            <div
                                                ref={provided.innerRef}
                                                {...provided.draggableProps}
                                                {...provided.dragHandleProps}
                                                className={cn(
                                                    "h-10 rounded-md border flex items-center justify-center text-[10px] font-bold cursor-grab active:cursor-grabbing hover:scale-105 transition-transform",
                                                    token.class.includes('border') ? token.class : `${token.class} border-transparent`
                                                )}
                                                onClick={() => {
                                                    if (selectedItem) {
                                                        const current = selectedItem.className || '';
                                                        // Simple append for now, ideally would replace conflicting classes
                                                        onUpdateItem(selectedItem.id || selectedItem.uniqueId, { className: `${current} ${token.class}`.trim() });
                                                    }
                                                }}
                                            >
                                                {token.label}
                                            </div>
                                        )}
                                    </Draggable>
                                ))}
                            </div>
                            <p className="text-[9px] text-neutral-500 mt-2 text-center">Drag onto canvas or click to apply to selected</p>
                        </div>

                        {/* Typography Tokens */}
                        <div className="space-y-2">
                            <h4 className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest">Typography</h4>
                            <div className="space-y-1">
                                {[
                                    { label: 'Heading XL', class: 'text-4xl font-bold tracking-tight' },
                                    { label: 'Heading L', class: 'text-2xl font-bold' },
                                    { label: 'Body', class: 'text-sm text-neutral-300' },
                                    { label: 'Mono', class: 'font-mono text-xs text-[hsl(var(--color-execution))]' },
                                    { label: 'Caption', class: 'text-[10px] text-neutral-500 uppercase tracking-widest' }
                                ].map(type => (
                                    <div 
                                        key={type.label}
                                        onClick={() => selectedItem && onUpdateItem(selectedItem.id || selectedItem.uniqueId, { className: `${selectedItem.className || ''} ${type.class}`.trim() })}
                                        className="p-2 hover:bg-white/5 rounded cursor-pointer group"
                                    >
                                        <div className={type.class}>{type.label}</div>
                                        <div className="text-[9px] text-neutral-600 opacity-0 group-hover:opacity-100">{type.class}</div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {activeTab === 'logic' && (
                    <InteractionPalette 
                        selectedItem={selectedItem}
                        allItems={canvasItems}
                        onUpdateRules={handleUpdateRules}
                        onHighlightRule={onHighlightRule}
                    />
                )}

            </div>
        </div>
    );
}