import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { SystemLog } from '@/components/ui/design-system/SystemContent';
import { OrientingText } from '@/components/ui/design-system/System';

export default function SystemMemory() {
  const { data: events = [] } = useQuery({
    queryKey: ['timeline'],
    queryFn: () => base44.entities.TimelineEvent.list({ sort: { timestamp: -1 }, limit: 20 }),
    initialData: []
  });

  const logs = events.map(e => ({
      id: e.id,
      type: e.type?.toUpperCase() || 'SYSTEM',
      content: e.text,
      status: e.severity === 'critical' ? 'error' : e.severity === 'warning' ? 'warning' : 'nominal',
      timestamp: e.timestamp
  }));

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-2 pb-2 border-b border-[hsl(var(--layer-orientation))]">
        <OrientingText>System Memory (Narrative)</OrientingText>
        <span className="text-[10px] text-[hsl(var(--fg-orientation))] font-mono">RETENTION: PERMANENT</span>
      </div>
      <SystemLog logs={logs} className="flex-1" />
    </div>
  );
}