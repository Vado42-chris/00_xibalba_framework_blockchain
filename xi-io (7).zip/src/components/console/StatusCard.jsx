import React from 'react';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';

export default function StatusCard({ title, value, status, icon, subtext }) {
  const mapStatus = (s) => {
      switch(s) {
          case 'nominal': return 'active';
          case 'warning': return 'warning';
          case 'critical': return 'error';
          case 'offline': return 'settled';
          default: return 'settled';
      }
  };

  return (
    <SystemCard
        title={title}
        subtitle={subtext}
        metric={value}
        status={mapStatus(status)}
        icon={icon}
    />
  );
}