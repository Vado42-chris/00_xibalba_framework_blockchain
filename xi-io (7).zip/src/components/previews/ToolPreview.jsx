import React from 'react';
import { Lock, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { 
    QuadrantGrid, Quadrant, OrientingText, IntentText, StateText 
} from '@/components/ui/design-system/SystemDesign';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { base44 } from '@/api/base44Client';

export default function ToolPreview({ title, subtitle, description, features = [], demoComponent }) {
    const handleLogin = () => base44.auth.redirectToLogin();

    return (
        <div className="h-full w-full bg-transparent overflow-hidden">
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                        <Quadrant type="orientation" step="1" title="Education" className="border-b">
                            <div className="flex justify-between items-end mb-6">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Lock className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-intent))]">PREVIEW MODE</OrientingText>
                                    </div>
                                    <IntentText className="text-2xl font-light">{title}</IntentText>
                                    <StateText className="text-lg opacity-70 mt-1">{subtitle}</StateText>
                                </div>
                            </div>

                            <p className="text-neutral-400 mb-8 leading-relaxed">
                                {description}
                            </p>

                            <div className="space-y-4 mb-8">
                                {features.map((feature, i) => (
                                    <div key={i} className="flex items-start gap-3">
                                        <CheckCircle2 className="w-5 h-5 text-[hsl(var(--color-execution))] mt-0.5 shrink-0" />
                                        <span className="text-sm text-neutral-300">{feature}</span>
                                    </div>
                                ))}
                            </div>

                            <Button 
                                onClick={handleLogin} 
                                className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold"
                            >
                                LOGIN TO ACCESS <ArrowRight className="w-4 h-4 ml-2" />
                            </Button>
                        </Quadrant>

                        <Quadrant type="state" step="3" title="Locked" className="border-t-0 rounded-t-none">
                            <div className="h-full flex items-center justify-center opacity-30">
                                <div className="text-center">
                                    <Lock className="w-12 h-12 mx-auto mb-4" />
                                    <StateText>Authentication Required</StateText>
                                </div>
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col relative overflow-hidden group">
                            {/* Interactive/Visual Demo */}
                            <div className="absolute inset-0 bg-neutral-950/50 backdrop-blur-[2px] z-10 flex items-center justify-center group-hover:backdrop-blur-none transition-all duration-500">
                                <div className="bg-black/80 border border-white/10 p-6 rounded-xl text-center transform group-hover:scale-105 transition-transform duration-500">
                                    <h3 className="text-xl font-bold text-white mb-2">Interactive Preview</h3>
                                    <p className="text-sm text-neutral-400 mb-4">Hover to inspect the interface structure</p>
                                    <Button size="sm" variant="outline" onClick={handleLogin}>
                                        Unlock Full Tool
                                    </Button>
                                </div>
                            </div>
                            <div className="flex-1 opacity-50 pointer-events-none filter grayscale group-hover:grayscale-0 transition-all duration-1000">
                                {demoComponent}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
        </div>
    );
}