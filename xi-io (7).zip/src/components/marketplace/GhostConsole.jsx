import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Check, Loader2, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from "@/lib/utils";

export const GhostConsole = ({ active, logs = [], onClose }) => {
    const scrollRef = useRef(null);

    // Auto-scroll to bottom
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [logs]);

    return (
        <AnimatePresence>
            {active && (
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 20 }}
                    className="absolute inset-0 z-20 bg-black/90 backdrop-blur-md p-4 flex flex-col font-mono text-xs border border-[hsl(var(--color-execution))]/30 rounded-md"
                >
                    {/* Header */}
                    <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2 shrink-0">
                        <div className="flex items-center gap-2 text-[hsl(var(--color-execution))]">
                            <Terminal className="w-3 h-3" />
                            <span className="font-bold tracking-wider">AGENT_UPLINK</span>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[hsl(var(--color-execution))] opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-[hsl(var(--color-execution))]"></span>
                            </span>
                            <span className="text-[10px] text-neutral-500">LIVE</span>
                        </div>
                    </div>

                    {/* Logs Area */}
                    <div 
                        ref={scrollRef}
                        className="flex-1 overflow-y-auto space-y-1.5 min-h-0 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent pr-2"
                    >
                        {logs.map((log, i) => (
                            <motion.div 
                                key={i}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                className={cn(
                                    "flex items-start gap-2",
                                    log.type === 'error' ? "text-red-400" : 
                                    log.type === 'success' ? "text-green-400" : "text-neutral-400"
                                )}
                            >
                                <span className="text-neutral-600 shrink-0 mt-0.5">
                                    <ChevronRight className="w-3 h-3" />
                                </span>
                                <span className="break-all leading-relaxed">
                                    {log.message}
                                </span>
                            </motion.div>
                        ))}
                        {/* Cursor */}
                        <div className="w-2 h-4 bg-[hsl(var(--color-execution))] animate-pulse ml-5" />
                    </div>

                    {/* Footer */}
                    <div className="mt-2 pt-2 border-t border-white/10 text-[9px] text-neutral-600 flex justify-between shrink-0">
                        <span>SESSION: {Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
                        <span>ENCRYPTED_PIPE</span>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};