import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Package, Settings, Trash2, Power, 
    AlertCircle, CheckCircle2, RotateCw, 
    MoreVertical, Box, Cpu
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    Dialog, DialogContent, DialogHeader, 
    DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog";
import {
    DropdownMenu, DropdownMenuContent, 
    DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { IntentText, StateText } from '@/components/ui/design-system/SystemDesign';

export default function AddonManager({ context }) {
    const queryClient = useQueryClient();
    const [selectedAddon, setSelectedAddon] = useState(null);
    const [configOpen, setConfigOpen] = useState(false);
    const [configJson, setConfigJson] = useState('');

    // Fetch Installed Addons
    const { data: installedAddons = [], isLoading } = useQuery({
        queryKey: ['installedAddons', context],
        queryFn: async () => {
            // Get all installed addons
            const addons = await base44.entities.InstalledAddon.list();
            
            // Get the marketplace item details for each addon
            const enrichedAddons = await Promise.all(addons.map(async (addon) => {
                const item = await base44.entities.MarketplaceItem.list({ id: addon.addon_id }, 1);
                return {
                    ...addon,
                    details: (item && item[0]) || { name: 'Unknown Addon', description: 'Item removed from marketplace' }
                };
            }));

            // Filter by context if provided (assuming addons might have a 'category' in their details)
            if (context) {
                return enrichedAddons.filter(a => a.details.category === context);
            }
            return enrichedAddons;
        }
    });

    // Mutations
    const updateStatusMutation = useMutation({
        mutationFn: async ({ id, status }) => {
            return await base44.entities.InstalledAddon.update(id, { status });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['installedAddons']);
            toast.success("Addon status updated");
        }
    });

    const updateConfigMutation = useMutation({
        mutationFn: async ({ id, config }) => {
            return await base44.entities.InstalledAddon.update(id, { config });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['installedAddons']);
            setConfigOpen(false);
            toast.success("Configuration saved");
        }
    });

    const uninstallMutation = useMutation({
        mutationFn: async (id) => {
            return await base44.entities.InstalledAddon.delete(id);
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['installedAddons']);
            toast.success("Addon uninstalled");
        }
    });

    // Handlers
    const handleConfigOpen = (addon) => {
        setSelectedAddon(addon);
        setConfigJson(JSON.stringify(addon.config || {}, null, 2));
        setConfigOpen(true);
    };

    const handleConfigSave = () => {
        try {
            const parsed = JSON.parse(configJson);
            updateConfigMutation.mutate({ id: selectedAddon.id, config: parsed });
        } catch (e) {
            toast.error("Invalid JSON configuration");
        }
    };

    if (isLoading) return <div className="p-4 text-center text-neutral-500">Loading addons...</div>;

    if (installedAddons.length === 0) {
        return (
            <div className="text-center p-8 border border-dashed border-white/10 rounded-lg bg-white/5">
                <Box className="w-8 h-8 text-neutral-600 mx-auto mb-3" />
                <h3 className="text-neutral-400 font-medium mb-1">No Addons Installed</h3>
                <p className="text-neutral-600 text-xs max-w-[200px] mx-auto">
                    Enhance this section by installing modules from the Marketplace.
                </p>
            </div>
        );
    }

    return (
        <div className="space-y-3">
            {installedAddons.map((addon) => (
                <div 
                    key={addon.id} 
                    className={cn(
                        "group flex items-start justify-between p-3 rounded-md border transition-all",
                        addon.status === 'active' 
                            ? "bg-black/40 border-[hsl(var(--color-intent))]/30" 
                            : "bg-neutral-900/20 border-white/5 opacity-70 hover:opacity-100"
                    )}
                >
                    <div className="flex items-start gap-3">
                        <div className={cn(
                            "w-8 h-8 rounded flex items-center justify-center shrink-0 mt-0.5",
                            addon.status === 'active' ? "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]" : "bg-white/5 text-neutral-500"
                        )}>
                            <Package className="w-4 h-4" />
                        </div>
                        <div>
                            <div className="flex items-center gap-2">
                                <IntentText className="text-sm font-medium leading-none">
                                    {addon.details.name}
                                </IntentText>
                                <Badge variant={addon.status === 'active' ? 'default' : 'secondary'} className="text-[9px] h-4 px-1">
                                    {addon.status}
                                </Badge>
                            </div>
                            <StateText className="text-xs text-neutral-500 mt-1 line-clamp-1">
                                {addon.details.description}
                            </StateText>
                            
                            {/* Version & Auto-update indicator */}
                            <div className="flex items-center gap-3 mt-2 text-[10px] text-neutral-600">
                                <span className="font-mono">v{addon.version || '1.0.0'}</span>
                                {addon.auto_update && (
                                    <span className="flex items-center gap-1 text-green-800/70">
                                        <RotateCw className="w-3 h-3" /> Auto-Update
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>

                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6 -mr-1 text-neutral-500 hover:text-white">
                                <MoreVertical className="w-3 h-3" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-40 bg-neutral-950 border-white/10">
                            <DropdownMenuItem onClick={() => updateStatusMutation.mutate({ 
                                id: addon.id, 
                                status: addon.status === 'active' ? 'inactive' : 'active' 
                            })}>
                                <Power className="w-3 h-3 mr-2" />
                                {addon.status === 'active' ? 'Deactivate' : 'Activate'}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleConfigOpen(addon)}>
                                <Settings className="w-3 h-3 mr-2" />
                                Configuration
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                                className="text-red-400 focus:text-red-400 focus:bg-red-950/20"
                                onClick={() => uninstallMutation.mutate(addon.id)}
                            >
                                <Trash2 className="w-3 h-3 mr-2" />
                                Uninstall
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            ))}

            <Dialog open={configOpen} onOpenChange={setConfigOpen}>
                <DialogContent className="bg-neutral-950 border-white/10 sm:max-w-lg">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Cpu className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                            Configure {selectedAddon?.details?.name}
                        </DialogTitle>
                        <DialogDescription>
                            Modify the JSON configuration for this addon instance.
                        </DialogDescription>
                    </DialogHeader>
                    
                    <div className="py-4">
                        <Label className="text-xs text-neutral-400 mb-2 block">Config JSON</Label>
                        <Textarea 
                            value={configJson}
                            onChange={(e) => setConfigJson(e.target.value)}
                            className="font-mono text-xs min-h-[200px] bg-black/50 border-white/10"
                            placeholder="{}"
                        />
                    </div>

                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setConfigOpen(false)}>Cancel</Button>
                        <Button onClick={handleConfigSave} className="gap-2">
                            <CheckCircle2 className="w-4 h-4" />
                            Save Config
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}