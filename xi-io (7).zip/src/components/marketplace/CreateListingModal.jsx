import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/System';
import { useQuery } from '@tanstack/react-query';
import { Badge } from "@/components/ui/badge";
import { GitFork, DollarSign, PieChart } from 'lucide-react';

export default function CreateListingModal({ open, onOpenChange }) {
    const queryClient = useQueryClient();
    const [upstreamId, setUpstreamId] = useState('');
    const [royalty, setRoyalty] = useState(0);
    const [manHours, setManHours] = useState(100);
    const [patentScore, setPatentScore] = useState(50);

    // Derived Hallbergmaths Value
    // V = (MH * PV) / (Saturation || 1)
    // Simplified for UI: Base = MH * (1 + PV/100)
    const recommendedPrice = Math.floor(manHours * (1 + patentScore / 100) * 0.5);

    const { data: existingItems = [] } = useQuery({
        queryKey: ['marketplace_items_select'],
        queryFn: () => base44.entities.MarketplaceItem.list(),
        initialData: []
    });

    const createListingMutation = useMutation({
        mutationFn: async (data) => {
            const user = await base44.auth.me().catch(() => ({ full_name: 'Anonymous' }));
            return base44.entities.MarketplaceItem.create({
                ...data,
                author: user.full_name,
                rating: 0,
                review_count: 0,
                installed: false,
                featured: false
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['marketplace_items']);
            onOpenChange(false);
            toast.success("Listing created successfully");
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        createListingMutation.mutate({
            name: fd.get('name'),
            description: fd.get('description'),
            category: fd.get('category'),
            price_amount: Number(fd.get('price')),
            pricing_type: Number(fd.get('price')) > 0 ? 'one_time' : 'free',
            features: fd.get('features').split(',').map(s => s.trim()).filter(Boolean),
            upstream_ids: upstreamId ? [upstreamId] : [],
            royalty_bps: Number(royalty) * 100,
            // Storing Hallbergmaths data in the manifest for the Audit component to read
            manifest: {
                hallbergmaths: {
                    man_hours: manHours,
                    patent_score: patentScore,
                    saturation_index: 0.5 // Default for new items
                }
            }
        });
        };

        const selectedParent = existingItems.find(i => i.id === upstreamId);

        return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-950/90 border-white/10 sm:max-w-[600px] text-white backdrop-blur-xl">
                <DialogHeader>
                    <div className="mb-2">
                        <OrientingText className="text-[hsl(var(--color-execution))] mb-1">SELLER DASHBOARD</OrientingText>
                        <DialogTitle className="text-2xl font-light">Create New Listing</DialogTitle>
                    </div>
                    <StateText>Publish your intellectual property to the global marketplace.</StateText>
                </DialogHeader>

                <form className="space-y-6 mt-4" onSubmit={handleSubmit}>
                    <div className="space-y-2">
                        <StateText className="text-xs">Product Name</StateText>
                        <Input name="name" required className="bg-neutral-900/50 border-white/10 focus-visible:ring-[hsl(var(--color-execution))]" placeholder="e.g. Advanced SEO Agent" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <StateText className="text-xs">Category</StateText>
                            <select name="category" className="w-full h-10 bg-neutral-900/50 border border-white/10 rounded-md px-3 text-sm text-white focus:outline-none focus:border-[hsl(var(--color-execution))]">
                                <option value="module">Module</option>
                                <option value="ai_model">AI Model</option>
                                <option value="automation_pack">Value Pack</option>
                                <option value="distro">OS / Distro</option>
                                <option value="browser">Browser</option>
                                <option value="theme">Theme</option>
                                <option value="service">Service</option>
                                <option value="dataset">Dataset</option>
                            </select>
                        </div>
                        <div className="space-y-2">
                            <StateText className="text-xs">Price (USD)</StateText>
                            <Input name="price" type="number" min="0" step="0.01" defaultValue="0" className="bg-neutral-900/50 border-white/10 focus-visible:ring-[hsl(var(--color-execution))]" />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <StateText className="text-xs">Description</StateText>
                        <textarea name="description" required className="w-full h-32 bg-neutral-900/50 border border-white/10 rounded-md p-3 text-sm text-white resize-none focus:outline-none focus:border-[hsl(var(--color-execution))]" placeholder="Describe functionality..." />
                    </div>

                    <div className="space-y-2">
                        <StateText className="text-xs">Features (comma separated)</StateText>
                        <Input name="features" className="bg-neutral-900/50 border-white/10 focus-visible:ring-[hsl(var(--color-execution))]" placeholder="Auto-scaling, API Access, 24/7 Support" />
                    </div>

                    {/* Hallbergmaths Section */}
                    <div className="p-4 rounded-lg bg-neutral-900/50 border border-white/10 space-y-4">
                        <div className="flex items-center gap-2 mb-2">
                            <GitFork className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                            <StateText className="font-bold text-[hsl(var(--color-intent))]">ATTRIBUTION & DERIVATION</StateText>
                        </div>
                        
                        <div className="space-y-2">
                            <StateText className="text-xs">Derived From (Upstream Source)</StateText>
                            <select 
                                value={upstreamId} 
                                onChange={(e) => setUpstreamId(e.target.value)} 
                                className="w-full h-10 bg-black/50 border border-white/10 rounded-md px-3 text-sm text-white focus:outline-none focus:border-[hsl(var(--color-execution))]"
                            >
                                <option value="">Original Work (Seed)</option>
                                {existingItems.map(item => (
                                    <option key={item.id} value={item.id}>{item.name} by {item.author || 'Unknown'}</option>
                                ))}
                            </select>
                        </div>

                        {upstreamId && (
                            <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                                {/* Hallbergmaths Input Grid */}
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <StateText className="text-xs">Development Hours</StateText>
                                        <div className="flex items-center gap-2">
                                            <Input 
                                                type="number" 
                                                value={manHours} 
                                                onChange={(e) => setManHours(Number(e.target.value))} 
                                                className="bg-black/50 border-white/10 h-8 text-xs"
                                            />
                                            <span className="text-xs text-neutral-500">hrs</span>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <StateText className="text-xs">Innovation Score (0-100)</StateText>
                                        <div className="flex items-center gap-2">
                                            <Input 
                                                type="number" 
                                                max="100"
                                                value={patentScore} 
                                                onChange={(e) => setPatentScore(Number(e.target.value))} 
                                                className="bg-black/50 border-white/10 h-8 text-xs"
                                            />
                                            <span className="text-xs text-neutral-500">pts</span>
                                        </div>
                                    </div>
                                </div>

                                {/* Hallbergmaths Calculator Visual */}
                                <div className="p-3 bg-neutral-950 rounded border border-white/5 space-y-3">
                                    <div className="flex justify-between items-center border-b border-white/5 pb-2">
                                        <div className="flex items-center gap-2">
                                            <PieChart className="w-3 h-3 text-purple-400" />
                                            <span className="text-[10px] font-mono text-purple-400">HALLBERGMATHS_ENGINE</span>
                                        </div>
                                        <Badge variant="outline" className="text-[9px] border-purple-500/30 text-purple-400 h-4">
                                            V = (MH × PV) / SAT
                                        </Badge>
                                    </div>
                                    <div className="grid grid-cols-3 gap-2 text-[10px] font-mono text-neutral-500">
                                        <div className="p-2 rounded bg-white/5 text-center">
                                            <div className="mb-1 text-purple-300">FAIR_VALUE</div>
                                            <div className="text-white text-xs">${recommendedPrice}</div>
                                        </div>
                                        <div className="p-2 rounded bg-white/5 text-center">
                                            <div className="mb-1 text-neutral-400">INPUT_HOURS</div>
                                            <div className="text-white text-xs">{manHours}h</div>
                                        </div>
                                        <div className="p-2 rounded bg-white/5 text-center">
                                            <div className="mb-1 text-[hsl(var(--color-intent))]">REC_SPLIT</div>
                                            <div className="text-white text-xs">{(patentScore * 0.2).toFixed(0)}%</div>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex justify-between">
                                    <StateText className="text-xs">Royalty Split (%)</StateText>
                                    <span className="text-xs font-mono text-[hsl(var(--color-execution))]">{royalty}%</span>
                                </div>
                                <Input 
                                    type="range" 
                                    min="0" 
                                    max="100" 
                                    value={royalty} 
                                    onChange={(e) => setRoyalty(e.target.value)} 
                                    className="h-2 bg-neutral-800"
                                />
                                
                                <div className="mt-4 p-3 bg-black/50 rounded border border-white/5 flex gap-4 items-center justify-center text-xs">
                                    <div className="text-center">
                                        <div className="text-[hsl(var(--color-execution))] font-bold">{100 - royalty}%</div>
                                        <div className="text-neutral-500">You</div>
                                    </div>
                                    <ArrowRight className="w-3 h-3 text-neutral-600" />
                                    <div className="text-center">
                                        <div className="text-[hsl(var(--color-intent))] font-bold">{royalty}%</div>
                                        <div className="text-neutral-500">{selectedParent?.author || 'Upstream'}</div>
                                    </div>
                                    <ArrowRight className="w-3 h-3 text-neutral-600" />
                                    <div className="text-center">
                                        <div className="text-purple-400 font-bold">1%</div>
                                        <div className="text-neutral-500">Seed001</div>
                                    </div>
                                </div>
                                <p className="text-[10px] text-neutral-500 text-center pt-2">
                                    Smart Contract permanently records this attribution chain on the ledger.
                                </p>
                            </div>
                        )}
                    </div>

                    <div className="flex justify-end gap-2 pt-4">
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} className="hover:bg-white/5 text-neutral-400 hover:text-white">Cancel</Button>
                        <Button type="submit" disabled={createListingMutation.isPending} className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 font-bold">
                            {createListingMutation.isPending ? 'Publishing...' : 'Publish Listing'}
                        </Button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}