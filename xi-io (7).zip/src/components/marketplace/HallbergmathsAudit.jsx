import React, { useState, useEffect } from 'react';
import { 
    GitCommit, GitMerge, GitPullRequest, 
    Calculator, TrendingUp, Clock, 
    Award, ShieldCheck, Share2
} from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { 
    OrientingText, IntentText, StateText, 
    SemanticDot, Layer 
} from '@/components/ui/design-system/System';
import { cn } from "@/lib/utils";

export const HallbergmathsAudit = ({ item }) => {
    const [calculating, setCalculating] = useState(true);
    const [metrics, setMetrics] = useState({
        manHours: 0,
        patentScore: 0,
        marketSaturation: 0,
        baseValue: 0
    });

    useEffect(() => {
        setCalculating(true);
        
        // Read from Item Manifest if available, else simulate
        const manifest = item.manifest?.hallbergmaths || {};
        const hours = manifest.man_hours || Math.floor(Math.random() * 500) + 120;
        const patent = manifest.patent_score || Math.floor(Math.random() * 90) + 10;
        const saturation = manifest.saturation_index || Math.random() * 0.8 + 0.2;
        
        // Hallbergmaths Formula
        // Value = (ManHours * PatentScore) / Saturation Index
        const value = Math.floor((hours * patent) / saturation);

        setTimeout(() => {
            setMetrics({
                manHours: hours,
                patentScore: patent,
                marketSaturation: saturation,
                baseValue: value
            });
            setCalculating(false);
        }, 800);
    }, [item.id, item.manifest]);

    const steps = [
        { label: 'Current Node (You)', share: 100 - (item.royalty_bps / 100), color: 'text-[hsl(var(--color-execution))]', bg: 'bg-[hsl(var(--color-execution))]', icon: GitCommit },
        { label: item.author || 'Upstream Author', share: (item.royalty_bps / 100) * 0.9, color: 'text-[hsl(var(--color-intent))]', bg: 'bg-[hsl(var(--color-intent))]', icon: GitPullRequest },
        { label: 'Seed001 (Root)', share: (item.royalty_bps / 100) * 0.1, color: 'text-purple-400', bg: 'bg-purple-400', icon: Share2 }
    ];

    if (calculating) {
        return (
            <div className="p-4 rounded-lg bg-neutral-900/30 border border-white/5 animate-pulse space-y-3">
                <div className="flex items-center gap-2 text-[hsl(var(--color-execution))]">
                    <Calculator className="w-4 h-4 animate-spin" />
                    <StateText className="text-xs font-mono">RUNNING HALLBERGMATHS ALGORITHM...</StateText>
                </div>
                <div className="h-2 bg-white/5 rounded-full w-3/4" />
                <div className="h-2 bg-white/5 rounded-full w-1/2" />
            </div>
        );
    }

    return (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
            <div className="p-4 rounded-lg bg-neutral-900/30 border border-white/5 space-y-4">
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <div className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-[hsl(var(--color-warning))]" />
                        <OrientingText className="text-[hsl(var(--color-warning))] font-bold">VALUE VERIFICATION</OrientingText>
                    </div>
                    <Badge variant="outline" className="font-mono text-[9px] border-white/10 text-neutral-500">
                        HASH: {Math.random().toString(36).substring(7).toUpperCase()}
                    </Badge>
                </div>

                <div className="p-3 bg-black/40 rounded border border-white/5 font-mono text-[10px] text-neutral-400 mb-2 flex justify-between items-center">
                    <span>VALUE_FORMULA:</span>
                    <span className="text-[hsl(var(--color-execution))]">V = (MH × PV) / SAT</span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                    <div className="p-2 rounded bg-black/20 border border-white/5 text-center relative group overflow-hidden">
                        <div className="absolute inset-0 bg-[hsl(var(--color-intent))]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <Clock className="w-3 h-3 text-[hsl(var(--color-intent))] mx-auto mb-1" />
                        <div className="text-xs font-mono text-white">{metrics.manHours}h</div>
                        <div className="text-[9px] text-neutral-600">MAN_HOURS</div>
                    </div>
                    <div className="p-2 rounded bg-black/20 border border-white/5 text-center relative group overflow-hidden">
                        <div className="absolute inset-0 bg-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <ShieldCheck className="w-3 h-3 text-purple-400 mx-auto mb-1" />
                        <div className="text-xs font-mono text-white">{metrics.patentScore}/100</div>
                        <div className="text-[9px] text-neutral-600">EXPERTISE</div>
                    </div>
                    <div className="p-2 rounded bg-black/20 border border-white/5 text-center relative group overflow-hidden">
                        <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <TrendingUp className="w-3 h-3 text-blue-400 mx-auto mb-1" />
                        <div className="text-xs font-mono text-white">{(metrics.marketSaturation * 100).toFixed(0)}%</div>
                        <div className="text-[9px] text-neutral-600">SATURATION</div>
                    </div>
                </div>

                <div className="pt-4">
                    <div className="flex justify-between items-end mb-2">
                        <StateText className="text-[10px] text-neutral-500">DERIVATION CHAIN</StateText>
                        <StateText className="text-[10px] text-neutral-500">ROYALTY DISTRIBUTION</StateText>
                    </div>
                    
                    <div className="relative pl-4 space-y-2 border-l border-white/10 ml-2">
                        {steps.map((step, i) => (
                            <div key={i} className="relative group">
                                <div className={cn("absolute -left-[21px] top-3 w-3 h-3 rounded-full border-2 border-black ring-1 ring-white/10 z-10", step.bg)} />
                                <div className="flex justify-between items-center p-2 rounded bg-white/5 border border-white/5 hover:border-white/20 transition-all">
                                    <div className="flex items-center gap-3">
                                        <div className={cn("p-1.5 rounded bg-black/50", step.color)}>
                                            <step.icon className="w-3 h-3" />
                                        </div>
                                        <div className="flex flex-col">
                                            <span className={cn("text-[10px] font-bold tracking-wide", step.color)}>{step.label}</span>
                                            <span className="text-[9px] text-neutral-500 font-mono">
                                                {i === 0 ? 'LICENSED_OWNER' : i === 1 ? 'CREATOR_ORIGIN' : 'PROTOCOL_ROOT'}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="flex flex-col items-end">
                                        <span className="text-xs font-mono text-white">{step.share.toFixed(1)}%</span>
                                        <div className="h-1 w-12 bg-neutral-800 rounded-full overflow-hidden mt-1">
                                            <div className={cn("h-full", step.bg)} style={{ width: '100%' }} />
                                        </div>
                                    </div>
                                </div>
                                {i < steps.length - 1 && (
                                    <div className="absolute left-[3px] top-6 bottom-[-8px] w-px bg-dashed border-l border-dashed border-white/20" />
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="p-3 rounded bg-[hsl(var(--color-execution))]/5 border border-[hsl(var(--color-execution))]/20 flex items-start gap-3">
                <Share2 className="w-4 h-4 text-[hsl(var(--color-execution))] mt-0.5 shrink-0" />
                <div>
                    <StateText className="text-[hsl(var(--color-execution))] text-xs font-bold mb-1">SMART CONTRACT ENFORCED</StateText>
                    <p className="text-[10px] text-neutral-400 leading-relaxed">
                        This item's value chain is immutable. Every transaction automatically executes the royalty split defined above, ensuring fair compensation for all contributors back to the seed.
                    </p>
                </div>
            </div>
        </div>
    );
};