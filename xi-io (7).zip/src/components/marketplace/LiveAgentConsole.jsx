import React, { useEffect, useRef } from 'react';
import { Terminal, CheckCircle2, Loader2, Server, Shield, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

export const LiveAgentConsole = ({ active, logs = [] }) => {
    const bottomRef = useRef(null);

    useEffect(() => {
        if (bottomRef.current) {
            bottomRef.current.scrollIntoView({ behavior: 'smooth' });
        }
    }, [logs]);

    if (!active && logs.length === 0) return null;

    return (
        <div className="flex flex-col h-full bg-black/80 backdrop-blur-md rounded-xl border border-white/10 overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 bg-neutral-900/90 border-b border-white/5">
                <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    <span className="text-xs font-mono font-bold text-neutral-300 tracking-wider">LIVE_AGENT_CONSOLE</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/20">
                        <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))] animate-pulse" />
                        <span className="text-[9px] font-mono text-[hsl(var(--color-execution))]">ACTIVE</span>
                    </div>
                </div>
            </div>

            {/* Terminal Window */}
            <ScrollArea className="flex-1 p-4 font-mono text-xs">
                <div className="space-y-1.5">
                    {logs.map((log, i) => (
                        <div key={i} className="flex items-start gap-2 animate-in slide-in-from-left-2 duration-200">
                            <span className="text-neutral-600 shrink-0 select-none">
                                {new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                            </span>
                            <div className="flex items-center gap-2">
                                <span className="text-[hsl(var(--color-execution))] select-none">➜</span>
                                <span className={cn(
                                    log.type === 'success' ? "text-green-400" :
                                    log.type === 'error' ? "text-red-400" :
                                    log.type === 'warning' ? "text-yellow-400" :
                                    "text-neutral-300"
                                )}>
                                    {log.message}
                                </span>
                            </div>
                        </div>
                    ))}
                    {active && (
                        <div className="flex items-center gap-2 mt-2 animate-pulse">
                            <span className="text-[hsl(var(--color-execution))]">➜</span>
                            <span className="w-2 h-4 bg-[hsl(var(--color-execution))]" />
                        </div>
                    )}
                    <div ref={bottomRef} />
                </div>
            </ScrollArea>

            {/* Status Footer */}
            <div className="px-4 py-2 bg-neutral-900/50 border-t border-white/5 flex gap-4 text-[10px] font-mono text-neutral-500">
                <div className="flex items-center gap-1.5">
                    <Server className="w-3 h-3" />
                    <span>PROVISIONING</span>
                </div>
                <div className="flex items-center gap-1.5">
                    <Shield className="w-3 h-3" />
                    <span>SECURE_TUNNEL</span>
                </div>
                <div className="flex items-center gap-1.5">
                    <Zap className="w-3 h-3" />
                    <span>AUTO_SCALING</span>
                </div>
            </div>
        </div>
    );
};