import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea"; // Assuming we have this
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Package, DollarSign, Tag, Code, UploadCloud } from 'lucide-react';

export default function PublishComponentModal({ open, onOpenChange, code, previewImage }) {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        name: '',
        description: '',
        price_amount: 0,
        pricing_type: 'free',
        category: 'module',
        tags: ''
    });

    const queryClient = useQueryClient();

    const publishMutation = useMutation({
        mutationFn: async (data) => {
            // 1. Create the Marketplace Item
            const item = await base44.entities.MarketplaceItem.create({
                name: data.name,
                description: data.description,
                category: data.category,
                price_amount: Number(data.price_amount),
                pricing_type: Number(data.price_amount) > 0 ? 'one_time' : 'free',
                provider_type: 'community',
                features: data.tags.split(',').map(t => t.trim()).filter(Boolean),
                // We store the code in the 'manifest' field for now, or we could create a Blueprint entity
                manifest: {
                    code: code,
                    version: "1.0.0",
                    build_date: new Date().toISOString()
                },
                author: (await base44.auth.me()).full_name || "Anonymous",
                installed: false, // Not installed by default for others
                rating: 0,
                review_count: 0
            });

            // 2. (Optional) Auto-install for the creator?
            // For now, let's just creating it.
            return item;
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['marketplace_items']);
            toast.success("Component Published to Marketplace!");
            onOpenChange(false);
            setStep(1);
            setFormData({ name: '', description: '', price_amount: 0, pricing_type: 'free', category: 'module', tags: '' });
        },
        onError: (err) => {
            toast.error("Failed to publish: " + err.message);
        }
    });

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border border-white/10 text-white sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-xl">
                        <UploadCloud className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                        Publish Component
                    </DialogTitle>
                </DialogHeader>

                <div className="space-y-6 py-4">
                    {step === 1 && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-left-4">
                            <div className="space-y-2">
                                <Label>Component Name</Label>
                                <Input 
                                    value={formData.name} 
                                    onChange={e => setFormData({...formData, name: e.target.value})}
                                    placeholder="e.g. Neo-Brutalist Card"
                                    className="bg-black border-white/10"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Description</Label>
                                <textarea 
                                    value={formData.description} 
                                    onChange={e => setFormData({...formData, description: e.target.value})}
                                    placeholder="What does this component do?"
                                    className="w-full h-24 bg-black border border-white/10 rounded-md p-3 text-sm text-white resize-none focus:outline-none focus:border-[hsl(var(--color-intent))]"
                                />
                            </div>
                            <div className="space-y-2">
                                <Label>Category</Label>
                                <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                                    <SelectTrigger className="bg-black border-white/10">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="module">UI Module</SelectItem>
                                        <SelectItem value="theme">Theme System</SelectItem>
                                        <SelectItem value="template">Page Template</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    )}

                    {step === 2 && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                            <div className="p-4 bg-white/5 rounded-lg border border-white/10 mb-4">
                                <div className="flex items-center gap-2 mb-2 text-[hsl(var(--color-execution))]">
                                    <Code className="w-4 h-4" />
                                    <span className="text-xs font-bold uppercase tracking-wider">Source Preview</span>
                                </div>
                                <div className="font-mono text-[10px] text-neutral-400 truncate opacity-70">
                                    {code.slice(0, 100)}...
                                </div>
                                <div className="mt-2 text-[10px] text-neutral-500">
                                    {code.length} bytes • Ready for distribution
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label>Pricing Model</Label>
                                <div className="grid grid-cols-2 gap-2">
                                    <button 
                                        onClick={() => setFormData({...formData, pricing_type: 'free', price_amount: 0})}
                                        className={`p-3 rounded border text-sm font-medium transition-all ${formData.pricing_type === 'free' ? 'bg-[hsl(var(--color-execution))]/20 border-[hsl(var(--color-execution))] text-white' : 'bg-black border-white/10 text-neutral-400'}`}
                                    >
                                        Free / Open Source
                                    </button>
                                    <button 
                                        onClick={() => setFormData({...formData, pricing_type: 'paid'})}
                                        className={`p-3 rounded border text-sm font-medium transition-all ${formData.pricing_type === 'paid' ? 'bg-[hsl(var(--color-intent))]/20 border-[hsl(var(--color-intent))] text-white' : 'bg-black border-white/10 text-neutral-400'}`}
                                    >
                                        Premium License
                                    </button>
                                </div>
                            </div>

                            {formData.pricing_type === 'paid' && (
                                <div className="space-y-2">
                                    <Label>Price (USD)</Label>
                                    <div className="relative">
                                        <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                                        <Input 
                                            type="number"
                                            value={formData.price_amount} 
                                            onChange={e => setFormData({...formData, price_amount: e.target.value})}
                                            className="pl-9 bg-black border-white/10"
                                        />
                                    </div>
                                </div>
                            )}

                            <div className="space-y-2">
                                <Label>Tags (comma separated)</Label>
                                <div className="relative">
                                    <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                                    <Input 
                                        value={formData.tags} 
                                        onChange={e => setFormData({...formData, tags: e.target.value})}
                                        placeholder="react, tailwind, dark-mode"
                                        className="pl-9 bg-black border-white/10"
                                    />
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                <DialogFooter className="flex justify-between sm:justify-between">
                    {step === 2 ? (
                        <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
                    ) : (
                        <div /> // Spacer
                    )}
                    
                    {step === 1 ? (
                        <Button onClick={() => setStep(2)} className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90">
                            Next: Pricing
                        </Button>
                    ) : (
                        <Button 
                            onClick={() => publishMutation.mutate(formData)} 
                            disabled={publishMutation.isPending}
                            className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 font-bold"
                        >
                            {publishMutation.isPending ? 'Minting...' : 'Publish to Marketplace'}
                        </Button>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}