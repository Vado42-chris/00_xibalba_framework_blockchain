// Mock Service for Addon Management
export const AddonService = {
    list: async () => {
        await new Promise(resolve => setTimeout(resolve, 800));
        return [
            { id: 'stripe', name: 'Stripe Payments', status: 'active', version: '2.4.0' },
            { id: 'sendgrid', name: 'SendGrid Email', status: 'active', version: '1.1.2' },
            { id: 'redis', name: 'Redis Cache', status: 'provisioning', version: '6.2.0' }
        ];
    },

    provision: async (addonId) => {
        console.log(`Provisioning addon: ${addonId}`);
        await new Promise(resolve => setTimeout(resolve, 2000));
        return { success: true, id: addonId, status: 'active' };
    },

    deprovision: async (addonId) => {
        console.log(`Deprovisioning addon: ${addonId}`);
        await new Promise(resolve => setTimeout(resolve, 1500));
        return { success: true };
    },

    getLogs: async (addonId) => {
        return [
            { timestamp: new Date().toISOString(), level: 'info', message: 'Service healthy' },
            { timestamp: new Date(Date.now() - 60000).toISOString(), level: 'info', message: 'Connection established' }
        ];
    }
};