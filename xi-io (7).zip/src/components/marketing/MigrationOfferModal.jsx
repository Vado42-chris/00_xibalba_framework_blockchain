import React, { useState } from 'react';
import { 
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
    MoveRight, ShieldCheck, Database, 
    ArrowRightLeft, CheckCircle2, Loader2, Lock, Zap
} from "lucide-react";
import { toast } from "sonner";
import { GreatMigrationTool } from '@/components/tools/GreatMigrationTool';

export default function MigrationOfferModal({ open, onOpenChange }) {
    const [showTool, setShowTool] = useState(false);
    const [step, setStep] = useState(1);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        // Simulate API call
        setTimeout(() => {
            setIsSubmitting(false);
            setStep(3);
            toast.success("Migration Request Logged");
        }, 1500);
    };

    if (showTool) {
        return (
            <GreatMigrationTool 
                open={true} 
                onOpenChange={(val) => {
                    if (!val) setShowTool(false);
                }} 
            />
        );
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[600px] bg-neutral-900 border-white/10 text-neutral-200 p-0 overflow-hidden gap-0">
                <div className="relative overflow-hidden p-8 bg-neutral-950 border-b border-white/5 text-center">
                    <div className="absolute top-0 right-0 p-4 opacity-10">
                        <ArrowRightLeft className="w-32 h-32 text-[hsl(var(--color-intent))]" />
                    </div>
                    
                    <Badge variant="outline" className="mb-4 border-[hsl(var(--color-intent))]/30 text-[hsl(var(--color-intent))] bg-[hsl(var(--color-intent))]/10">
                        THE GREAT MIGRATION
                    </Badge>
                    <DialogTitle className="text-3xl font-serif font-light text-white mb-2">
                        You've Built It. <span className="italic text-[hsl(var(--color-intent))]">Now Own It.</span>
                    </DialogTitle>
                    <DialogDescription className="text-neutral-400 max-w-sm mx-auto">
                        Break free from vendor lock-in. We'll migrate your existing workflows to Valhalla for free.
                    </DialogDescription>
                </div>

                {step === 1 && (
                    <div className="p-8 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="p-4 rounded-xl bg-red-500/5 border border-red-500/20">
                                <div className="text-xs font-bold text-red-500 mb-2 uppercase tracking-widest">Legacy Reality</div>
                                <ul className="space-y-2">
                                    <li className="flex items-center gap-2 text-sm text-neutral-400">
                                        <Lock className="w-3 h-3 text-red-500" /> Locked Data Formats
                                    </li>
                                    <li className="flex items-center gap-2 text-sm text-neutral-400">
                                        <Database className="w-3 h-3 text-red-500" /> Hidden Exit Fees
                                    </li>
                                </ul>
                            </div>
                            <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                                <div className="text-xs font-bold text-emerald-500 mb-2 uppercase tracking-widest">Valhalla Promise</div>
                                <ul className="space-y-2">
                                    <li className="flex items-center gap-2 text-sm text-neutral-400">
                                        <CheckCircle2 className="w-3 h-3 text-emerald-500" /> 100% Data Sovereignty
                                    </li>
                                    <li className="flex items-center gap-2 text-sm text-neutral-400">
                                        <ShieldCheck className="w-3 h-3 text-emerald-500" /> Blockchain Audit
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <Button 
                            className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold h-12 mb-3"
                            onClick={() => setStep(2)}
                        >
                            Request Human Architect <MoveRight className="w-4 h-4 ml-2" />
                        </Button>

                        <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                                <span className="w-full border-t border-white/10" />
                            </div>
                            <div className="relative flex justify-center text-xs uppercase">
                                <span className="bg-neutral-950 px-2 text-neutral-500">Or Do It Yourself</span>
                            </div>
                        </div>

                        <Button 
                            className="w-full bg-white text-black hover:bg-neutral-200 font-bold h-12 mt-3"
                            onClick={() => setShowTool(true)}
                        >
                            Launch Migration Tool <Zap className="w-4 h-4 ml-2" />
                        </Button>
                    </div>
                )}

                {step === 2 && (
                    <form onSubmit={handleSubmit} className="p-8 space-y-4">
                        <div className="space-y-2">
                            <Label>Current Platform</Label>
                            <Select name="platform">
                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                    <SelectValue placeholder="Select your current vendor" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="zapier">Zapier</SelectItem>
                                    <SelectItem value="integromat">Make (Integromat)</SelectItem>
                                    <SelectItem value="workato">Workato</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Approximate Workflow Count</Label>
                            <Input placeholder="e.g. 15 active workflows" className="bg-neutral-950 border-white/10" />
                        </div>
                        <div className="space-y-2">
                            <Label>Email for Analysis Report</Label>
                            <Input type="email" placeholder="architect@company.com" className="bg-neutral-950 border-white/10" required />
                        </div>

                        <div className="pt-4 flex gap-3">
                            <Button type="button" variant="ghost" onClick={() => setStep(1)}>Back</Button>
                            <Button 
                                type="submit" 
                                className="flex-1 bg-white text-black hover:bg-neutral-200"
                                disabled={isSubmitting}
                            >
                                {isSubmitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                                Submit for Analysis
                            </Button>
                        </div>
                    </form>
                )}

                {step === 3 && (
                    <div className="p-8 text-center space-y-6">
                        <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                            <CheckCircle2 className="w-8 h-8 text-green-500" />
                        </div>
                        <h3 className="text-2xl font-light text-white">Request Received</h3>
                        <p className="text-neutral-400">
                            Our migration architects are reviewing your profile. We will reach out within 24 hours with a custom migration plan.
                        </p>
                        <Button variant="outline" onClick={() => onOpenChange(false)} className="border-white/10">
                            Close
                        </Button>
                    </div>
                )}
            </DialogContent>
        </Dialog>
    );
}