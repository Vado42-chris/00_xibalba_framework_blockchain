import React, { useState } from 'react';
import { 
    Plus, Save, 
    Clock, Webhook, Hand, Activity, Globe, Database, Code, Zap
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { 
    OrientingText, IntentText, StateText, SemanticDot 
} from '@/components/ui/design-system/System';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { WorkflowStepNode } from './WorkflowStepNode';
import CronBuilder from '@/components/integrations/CronBuilder';

export default function WorkflowBuilder({ initialData, onSave, onCancel }) {
    const [workflow, setWorkflow] = useState(initialData || {
        name: "",
        description: "",
        trigger: "manual",
        error_policy: { action: 'stop', max_retries: 0 },
        steps: []
    });

    // Helper to deeply update a step in the tree
    const updateStepInTree = (steps, index, newStep) => {
        const newSteps = [...steps];
        newSteps[index] = newStep;
        return newSteps;
    };

    const handleRootUpdate = (index, newStep) => {
        setWorkflow(prev => ({
            ...prev,
            steps: updateStepInTree(prev.steps, index, newStep)
        }));
    };

    const addRootStep = () => {
        setWorkflow(prev => ({
            ...prev,
            steps: [...prev.steps, { 
                id: Math.random().toString(36).substr(2, 9), 
                type: 'api_request', 
                name: 'New Step', 
                condition: '',
                config: { method: 'GET', endpoint: '', payload: '' } 
            }]
        }));
    };

    const removeRootStep = (index) => {
        const newSteps = [...workflow.steps];
        newSteps.splice(index, 1);
        setWorkflow({ ...workflow, steps: newSteps });
    };

    const moveRootStep = (index, direction) => {
        if (index + direction < 0 || index + direction >= workflow.steps.length) return;
        const newSteps = [...workflow.steps];
        const temp = newSteps[index];
        newSteps[index] = newSteps[index + direction];
        newSteps[index + direction] = temp;
        setWorkflow({ ...workflow, steps: newSteps });
    };

    const TriggerIcon = {
        manual: Hand,
        scheduled: Clock,
        webhook: Webhook,
        event: Activity
    }[workflow.trigger] || Activity;

    // Fetch integrations for the dropdown (passed via context or queried here if needed by children)
    // Kept for consistency if we want to pass it down props later
    const { data: integrations = [] } = useQuery({
        queryKey: ['integrations_list'],
        queryFn: () => base44.entities.Integration.list(),
        initialData: []
    });

    return (
        <div className="h-full flex flex-col bg-[hsl(var(--void))]">
            <div className="p-6 border-b border-[hsl(var(--layer-orientation))] flex justify-between items-start bg-[hsl(var(--layer-orientation))]">
                <div className="space-y-4 w-1/2">
                    <div>
                        <div className="flex items-center gap-2 mb-1">
                            <Zap className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                            <OrientingText>WORKFLOW COMPOSER</OrientingText>
                        </div>
                        <Input 
                            value={workflow.name}
                            onChange={(e) => setWorkflow({...workflow, name: e.target.value})}
                            placeholder="Workflow Name"
                            className="text-lg font-bold bg-transparent border-none px-0 h-auto focus-visible:ring-0 placeholder:text-[hsl(var(--fg-orientation))] text-[hsl(var(--fg-intent))]"
                        />
                    </div>
                    <Input 
                        value={workflow.description}
                        onChange={(e) => setWorkflow({...workflow, description: e.target.value})}
                        placeholder="Description..."
                        className="bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))] text-xs text-[hsl(var(--fg-orientation))]"
                    />
                </div>
                <div className="flex gap-2">
                    <Button variant="ghost" onClick={onCancel}>Cancel</Button>
                    <Button onClick={() => onSave(workflow)} className="bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90">
                        <Save className="w-4 h-4 mr-2" /> Save Workflow
                    </Button>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-8 bg-[hsl(var(--void))]">
                <div className="max-w-4xl mx-auto space-y-12">
                    {/* Trigger Node */}
                    <div className="flex justify-center relative z-20">
                        <Card className="w-72 p-4 bg-[hsl(var(--layer-intent))] border-[hsl(var(--layer-orientation))] relative group shadow-2xl">
                            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-2 bg-[hsl(var(--layer-intent))]">
                                <StateText className="text-[hsl(var(--color-identity))]">TRIGGER</StateText>
                            </div>
                            <div className="flex items-center gap-3 mb-3">
                                <div className="p-2 rounded bg-[hsl(var(--color-identity))]/10 text-[hsl(var(--color-identity))]">
                                    <TriggerIcon className="w-5 h-5" />
                                </div>
                                <Select 
                                    value={workflow.trigger} 
                                    onValueChange={(v) => setWorkflow({...workflow, trigger: v})}
                                >
                                    <SelectTrigger className="h-8 text-xs border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="manual">Manual Invocation</SelectItem>
                                        <SelectItem value="scheduled">Scheduled (Cron)</SelectItem>
                                        <SelectItem value="webhook">Webhook</SelectItem>
                                        <SelectItem value="event">System Event</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            
                            {workflow.trigger === 'scheduled' && (
                                <div className="mb-3">
                                    <CronBuilder 
                                        value={workflow.schedule || '* * * * *'} 
                                        onChange={(val) => setWorkflow({...workflow, schedule: val})} 
                                    />
                                </div>
                            )}

                            <StateText className="text-center opacity-50 text-[10px]">
                                {workflow.trigger === 'scheduled' ? 'Runs on defined schedule' : 'Initiates execution chain'}
                            </StateText>
                            
                            {/* Global Error Policy */}
                            <div className="mt-4 pt-4 border-t border-[hsl(var(--layer-orientation))]/50">
                                <div className="flex justify-between items-center">
                                    <StateText className="text-[9px] opacity-70">Global Error Policy</StateText>
                                    <Select 
                                        value={workflow.error_policy?.action || 'stop'} 
                                        onValueChange={(v) => setWorkflow({...workflow, error_policy: { ...workflow.error_policy, action: v }})}
                                    >
                                        <SelectTrigger className="h-5 w-24 text-[9px] border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]"><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="stop">Stop All</SelectItem>
                                            <SelectItem value="continue">Ignore</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                        </Card>
                         <div className="absolute -bottom-12 left-1/2 -translate-x-1/2 w-px h-12 bg-[hsl(var(--layer-orientation))]" />
                    </div>

                    {/* Steps Tree */}
                    <div className="flex flex-col items-center gap-8 min-h-[200px]">
                        {workflow.steps.map((step, index) => (
                            <WorkflowStepNode 
                                key={step.id}
                                step={step}
                                index={index}
                                onUpdate={handleRootUpdate}
                                onRemove={removeRootStep}
                                onMove={moveRootStep}
                                parentId={null}
                            />
                        ))}
                    </div>

                    {/* Add Root Step */}
                    <div className="flex justify-center pt-4 pb-12">
                        <Button 
                            variant="outline" 
                            className="border-dashed border-[hsl(var(--layer-orientation))] hover:border-[hsl(var(--color-intent))] hover:text-[hsl(var(--color-intent))] bg-transparent"
                            onClick={addRootStep}
                        >
                            <Plus className="w-4 h-4 mr-2" /> Add Step
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}