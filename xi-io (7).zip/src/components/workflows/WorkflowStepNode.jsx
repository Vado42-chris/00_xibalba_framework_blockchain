import React from 'react';
import { 
    Trash2, ArrowDown, Settings, Code, Copy, 
    GitBranch, Split, AlertCircle, Database,
    CheckCircle2, XCircle, PlayCircle, ArrowRightLeft
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import DataMapper from '.@/api/integrations/DataMapper';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { 
    StateText, IntentText, SemanticDot 
} from '@/components/ui/design-system/System';
import { cn } from "@/lib/utils";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

const StepConfig = ({ step, updateStep }) => {
    // Fetch agents list for configuration
    const { data: agents = [] } = useQuery({
        queryKey: ['agents_list_workflow'],
        queryFn: () => base44.entities.Agent.list(),
        initialData: []
    });

    // Shared configuration UI for error handling
    const ErrorConfig = () => (
        <div className="space-y-3 pt-2 border-t border-[hsl(var(--layer-orientation))]">
            <div className="flex items-center gap-2">
                <AlertCircle className="w-3 h-3 text-[hsl(var(--color-warning))]" />
                <StateText className="text-[hsl(var(--color-warning))]">Error Handling Strategy</StateText>
            </div>
            <div className="grid grid-cols-2 gap-2">
                <div>
                    <StateText className="text-[9px] mb-1">On Failure</StateText>
                    <Select 
                        value={step.errorPolicy?.action || 'stop'} 
                        onValueChange={(v) => updateStep('errorPolicy', { ...step.errorPolicy, action: v })}
                    >
                        <SelectTrigger className="h-6 text-[10px] border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="stop">Stop Workflow</SelectItem>
                            <SelectItem value="continue">Continue (Ignore)</SelectItem>
                            <SelectItem value="retry">Retry Step</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                {step.errorPolicy?.action === 'retry' && (
                    <div>
                        <StateText className="text-[9px] mb-1">Max Retries</StateText>
                        <Input 
                            type="number" 
                            className="h-6 text-[10px] border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]" 
                            value={step.errorPolicy?.maxRetries || 3}
                            onChange={(e) => updateStep('errorPolicy', { ...step.errorPolicy, maxRetries: parseInt(e.target.value) })}
                        />
                    </div>
                )}
            </div>
        </div>
    );

    if (step.type === 'if_else') {
        return (
            <div className="space-y-3 p-2">
                <div className="flex items-center gap-2">
                    <Code className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                    <Input 
                        placeholder="Condition (e.g. step1.status === 200)" 
                        value={step.condition || ''}
                        onChange={(e) => updateStep('condition', e.target.value)}
                        className="h-7 text-xs font-mono bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))]"
                    />
                </div>
                <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[9px] h-5 bg-[hsl(var(--void))] text-[hsl(var(--fg-orientation))] cursor-pointer hover:text-[hsl(var(--color-active))] border-[hsl(var(--layer-orientation))]" onClick={() => updateStep('condition', (step.condition || '') + ' {{step_id.output}}')}>
                        + Add Variable
                    </Badge>
                </div>
            </div>
        );
    }

    if (step.type === 'api_request') {
        return (
            <div className="space-y-3 p-2">
                 <div className="grid grid-cols-4 gap-2">
                    <Select value={step.config?.method || 'GET'} onValueChange={(v) => updateStep('config', { ...step.config, method: v })}>
                        <SelectTrigger className="h-7 text-xs border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]"><SelectValue placeholder="Method" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="GET">GET</SelectItem>
                            <SelectItem value="POST">POST</SelectItem>
                            <SelectItem value="PUT">PUT</SelectItem>
                            <SelectItem value="DELETE">DELETE</SelectItem>
                        </SelectContent>
                    </Select>
                    <Input 
                        className="col-span-3 h-7 text-xs font-mono border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]" 
                        placeholder="https://api.example.com/v1/..."
                        value={step.config?.endpoint || ''}
                        onChange={(e) => updateStep('config', { ...step.config, endpoint: e.target.value })}
                    />
                 </div>
                 <ErrorConfig />
            </div>
        );
    }

    if (step.type === 'ai_agent') {
        return (
            <div className="space-y-3 p-2">
                <div className="space-y-1">
                    <StateText className="text-[9px]">Select Agent Identity</StateText>
                    <Select value={step.config?.agentId || ''} onValueChange={(v) => updateStep('config', { ...step.config, agentId: v })}>
                        <SelectTrigger className="h-7 text-xs border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]"><SelectValue placeholder="Choose Agent..." /></SelectTrigger>
                        <SelectContent>
                            {agents.map(agent => (
                                <SelectItem key={agent.id} value={agent.id}>
                                    {agent.name} ({agent.role})
                                </SelectItem>
                            ))}
                            <SelectItem value="system_default">System Default (GPT-4)</SelectItem>
                        </SelectContent>
                    </Select>
                    {step.config?.agentId && step.config?.agentId !== 'system_default' && (
                         <div className="px-2 py-1 bg-[hsl(var(--color-intent))]/10 border border-[hsl(var(--color-intent))]/20 rounded text-[9px] text-[hsl(var(--color-intent))]">
                            Using configuration for {agents.find(a => a.id === step.config?.agentId)?.name || 'Unknown Agent'}
                         </div>
                    )}
                </div>
                <div className="space-y-1">
                    <StateText className="text-[9px]">Task / Prompt</StateText>
                    <textarea 
                        className="w-full h-16 text-xs bg-[hsl(var(--void))] border border-[hsl(var(--layer-orientation))] rounded p-2 resize-none focus:border-[hsl(var(--color-intent))]"
                        placeholder="Analyze the following data: {{previous_step.output}}..."
                        value={step.config?.prompt || ''}
                        onChange={(e) => updateStep('config', { ...step.config, prompt: e.target.value })}
                    />
                </div>
                <ErrorConfig />
            </div>
        );
    }

    if (step.type === 'system_task') {
        return (
            <div className="space-y-3 p-2">
                <div className="space-y-1">
                    <StateText className="text-[9px]">Action</StateText>
                    <Select value={step.config?.action || 'email'} onValueChange={(v) => updateStep('config', { ...step.config, action: v })}>
                        <SelectTrigger className="h-7 text-xs border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="email">Send Email</SelectItem>
                            <SelectItem value="notification">Push Notification</SelectItem>
                            <SelectItem value="log">Write System Log</SelectItem>
                            <SelectItem value="delay">Delay / Sleep</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                {step.config?.action === 'email' && (
                    <Input 
                        className="h-7 text-xs border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]"
                        placeholder="Recipient (e.g. admin@xi.io)"
                        value={step.config?.recipient || ''}
                        onChange={(e) => updateStep('config', { ...step.config, recipient: e.target.value })}
                    />
                )}
                {step.config?.action === 'delay' && (
                    <div className="flex items-center gap-2">
                        <Input 
                            type="number"
                            className="h-7 text-xs border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))] w-20"
                            placeholder="1000"
                            value={step.config?.duration || ''}
                            onChange={(e) => updateStep('config', { ...step.config, duration: e.target.value })}
                        />
                        <StateText className="text-[10px]">ms</StateText>
                    </div>
                )}
                <ErrorConfig />
            </div>
        );
    }

    if (step.type === 'data_mapper') {
        return (
            <div className="space-y-3 p-2">
                <DataMapper 
                    mappings={step.config?.mappings || []} 
                    onChange={(newMappings) => updateStep('config', { ...step.config, mappings: newMappings })}
                />
                <ErrorConfig />
            </div>
        );
    }

    return <div className="p-2"><StateText className="opacity-50">Select a step type to configure.</StateText><ErrorConfig /></div>;
};

export const WorkflowStepNode = ({ step, index, onUpdate, onRemove, onMove, onAddChild, parentId = null }) => {
    // Handling updates for complex structures
    const handleUpdate = (field, value) => {
        const newStep = { ...step, [field]: value };
        onUpdate(index, newStep, parentId);
    };

    const handleAddStep = (branchIndex) => {
        // Logic to add a step to a specific branch (for if/else or parallel)
        const newStep = { 
            id: Math.random().toString(36).substr(2, 9), 
            type: 'api_request', 
            name: 'New Action', 
            config: {} 
        };
        
        let updatedStep = { ...step };
        if (step.type === 'if_else') {
            const branchKey = branchIndex === 0 ? 'true_steps' : 'false_steps';
            updatedStep[branchKey] = [...(updatedStep[branchKey] || []), newStep];
        } else if (step.type === 'parallel') {
            const newBranches = [...(updatedStep.branches || [])];
            if (!newBranches[branchIndex]) newBranches[branchIndex] = { steps: [] };
            newBranches[branchIndex].steps.push(newStep);
            updatedStep.branches = newBranches;
        }
        
        onUpdate(index, updatedStep, parentId);
    };

    const handleChildUpdate = (branchIndex, childIndex, updatedChild) => {
        let updatedStep = { ...step };
        if (step.type === 'if_else') {
            const branchKey = branchIndex === 0 ? 'true_steps' : 'false_steps';
            const newSteps = [...updatedStep[branchKey]];
            newSteps[childIndex] = updatedChild;
            updatedStep[branchKey] = newSteps;
        } else if (step.type === 'parallel') {
            const newBranches = [...updatedStep.branches];
            const newSteps = [...newBranches[branchIndex].steps];
            newSteps[childIndex] = updatedChild;
            newBranches[branchIndex].steps = newSteps;
            updatedStep.branches = newBranches;
        }
        onUpdate(index, updatedStep, parentId);
    };

    const handleChildRemove = (branchIndex, childIndex) => {
        let updatedStep = { ...step };
        if (step.type === 'if_else') {
            const branchKey = branchIndex === 0 ? 'true_steps' : 'false_steps';
            const newSteps = [...updatedStep[branchKey]];
            newSteps.splice(childIndex, 1);
            updatedStep[branchKey] = newSteps;
        } else if (step.type === 'parallel') {
            const newBranches = [...updatedStep.branches];
            const newSteps = [...newBranches[branchIndex].steps];
            newSteps.splice(childIndex, 1);
            newBranches[branchIndex].steps = newSteps;
            updatedStep.branches = newBranches;
        }
        onUpdate(index, updatedStep, parentId);
    };

    return (
        <div className="relative flex flex-col items-center">
            <Card className={cn(
                "w-96 p-3 bg-[hsl(var(--layer-orientation))] border-[hsl(var(--layer-orientation))] transition-all relative group z-10",
                step.type === 'if_else' && "border-l-4 border-l-[hsl(var(--color-intent))]",
                step.type === 'parallel' && "border-l-4 border-l-[hsl(var(--color-execution))]"
            )}>
                {/* Header Actions */}
                <div className="absolute right-2 top-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button size="icon" variant="ghost" className="h-5 w-5 hover:bg-[hsl(var(--layer-state))]" onClick={() => onMove(index, -1)} disabled={index === 0}>↑</Button>
                    <Button size="icon" variant="ghost" className="h-5 w-5 hover:bg-[hsl(var(--layer-state))]" onClick={() => onMove(index, 1)}>↓</Button>
                    <Button size="icon" variant="ghost" className="h-5 w-5 text-red-500 hover:bg-red-950/30" onClick={() => onRemove(index)}><Trash2 className="w-3 h-3" /></Button>
                </div>

                {/* Step Header */}
                <div className="flex items-center gap-3 mb-2">
                    <div className={cn(
                        "w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-mono",
                        step.type === 'if_else' ? "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]" :
                        step.type === 'parallel' ? "bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))]" :
                        "bg-[hsl(var(--void))] text-[hsl(var(--fg-orientation))]"
                    )}>
                        {step.type === 'if_else' ? <GitBranch className="w-3 h-3" /> : 
                         step.type === 'parallel' ? <Split className="w-3 h-3" /> : 
                         step.type === 'data_mapper' ? <ArrowRightLeft className="w-3 h-3" /> :
                         index + 1}
                    </div>
                    <Input 
                        value={step.name}
                        onChange={(e) => handleUpdate('name', e.target.value)}
                        className="h-7 bg-transparent border-transparent hover:border-[hsl(var(--fg-orientation))]/30 focus:border-[hsl(var(--color-active))] font-medium text-sm px-1 text-[hsl(var(--fg-intent))]"
                    />
                </div>

                {/* Config Area */}
                <div className="pl-9 space-y-2">
                    <Select value={step.type} onValueChange={(v) => handleUpdate('type', v)}>
                        <SelectTrigger className="h-7 text-xs bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="api_request">API Request</SelectItem>
                            <SelectItem value="if_else">Conditional (If/Else)</SelectItem>
                            <SelectItem value="parallel">Parallel Group</SelectItem>
                            <SelectItem value="data_mapper">Data Transformation</SelectItem>
                            <SelectItem value="system_task">System Task</SelectItem>
                            <SelectItem value="ai_agent">Invoke AI Agent</SelectItem>
                        </SelectContent>
                    </Select>
                    
                    <StepConfig step={step} updateStep={handleUpdate} />
                </div>
            </Card>

            {/* Recursive Branch Rendering */}
            {step.type === 'if_else' && (
                <div className="flex w-full mt-8 gap-8 justify-center relative">
                    {/* Connection Lines */}
                    <div className="absolute top-[-32px] left-1/2 w-px h-8 bg-[hsl(var(--layer-orientation))]" />
                    <div className="absolute top-0 left-1/4 right-1/4 h-px bg-[hsl(var(--layer-orientation))]" />
                    <div className="absolute top-0 left-1/4 w-px h-8 bg-[hsl(var(--layer-orientation))]" />
                    <div className="absolute top-0 right-1/4 w-px h-8 bg-[hsl(var(--layer-orientation))]" />

                    {/* True Branch */}
                    <div className="flex-1 flex flex-col items-center">
                        <div className="mb-4 px-2 py-1 rounded bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] text-[9px] font-bold">TRUE</div>
                        <div className="flex flex-col gap-8 w-full items-center">
                            {step.true_steps?.map((child, i) => (
                                <WorkflowStepNode 
                                    key={child.id} 
                                    step={child} 
                                    index={i} 
                                    onUpdate={(idx, s) => handleChildUpdate(0, idx, s)}
                                    onRemove={(idx) => handleChildRemove(0, idx)}
                                    onMove={() => {}} // simplified
                                />
                            ))}
                            <Button variant="outline" size="sm" className="h-7 text-xs border-dashed border-[hsl(var(--layer-orientation))] hover:border-[hsl(var(--color-active))]" onClick={() => handleAddStep(0)}><ArrowDown className="w-3 h-3 mr-1" /> Add True Step</Button>
                        </div>
                    </div>

                    {/* False Branch */}
                    <div className="flex-1 flex flex-col items-center">
                        <div className="mb-4 px-2 py-1 rounded bg-[hsl(var(--color-error))]/10 border border-[hsl(var(--color-error))]/20 text-[hsl(var(--color-error))] text-[9px] font-bold">FALSE</div>
                        <div className="flex flex-col gap-8 w-full items-center">
                            {step.false_steps?.map((child, i) => (
                                <WorkflowStepNode 
                                    key={child.id} 
                                    step={child} 
                                    index={i} 
                                    onUpdate={(idx, s) => handleChildUpdate(1, idx, s)}
                                    onRemove={(idx) => handleChildRemove(1, idx)}
                                    onMove={() => {}}
                                />
                            ))}
                            <Button variant="outline" size="sm" className="h-7 text-xs border-dashed border-[hsl(var(--layer-orientation))] hover:border-[hsl(var(--color-active))]" onClick={() => handleAddStep(1)}><ArrowDown className="w-3 h-3 mr-1" /> Add False Step</Button>
                        </div>
                    </div>
                </div>
            )}

            {step.type === 'parallel' && (
                <div className="flex w-full mt-8 gap-4 justify-center relative overflow-x-auto p-4">
                     <div className="absolute top-[-32px] left-1/2 w-px h-8 bg-[hsl(var(--layer-orientation))]" />
                     {/* Simplified rendering for N branches - creating specific add branch UI would be better but keeping it simple */}
                     {(step.branches || [{steps:[]}, {steps:[]}]).map((branch, bIdx) => (
                         <div key={bIdx} className="min-w-[300px] flex flex-col items-center border-t border-[hsl(var(--layer-orientation))] pt-4 relative">
                             <div className="absolute top-[-16px] w-px h-4 bg-[hsl(var(--layer-orientation))]" />
                             <StateText className="mb-4">Branch {bIdx + 1}</StateText>
                             <div className="flex flex-col gap-8 w-full items-center">
                                {branch.steps?.map((child, i) => (
                                    <WorkflowStepNode 
                                        key={child.id} 
                                        step={child} 
                                        index={i} 
                                        onUpdate={(idx, s) => handleChildUpdate(bIdx, idx, s)}
                                        onRemove={(idx) => handleChildRemove(bIdx, idx)}
                                        onMove={() => {}}
                                    />
                                ))}
                                <Button variant="outline" size="sm" className="h-7 text-xs border-dashed border-[hsl(var(--layer-orientation))] hover:border-[hsl(var(--color-active))]" onClick={() => handleAddStep(bIdx)}><ArrowDown className="w-3 h-3 mr-1" /> Add Step</Button>
                             </div>
                         </div>
                     ))}
                     <Button variant="ghost" className="h-full min-h-[100px] border-l border-[hsl(var(--layer-orientation))] ml-4 text-[hsl(var(--fg-orientation))]" onClick={() => {
                         const newBranches = [...(step.branches || []), {steps: []}];
                         handleUpdate('branches', newBranches);
                     }}>+ Branch</Button>
                </div>
            )}

            {/* Down Connector */}
            {step.type !== 'if_else' && step.type !== 'parallel' && (
                <div className="absolute -bottom-8 text-[hsl(var(--layer-orientation))]">
                    <ArrowDown className="w-5 h-5" />
                </div>
            )}
        </div>
    );
};