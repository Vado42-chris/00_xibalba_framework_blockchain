import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bot, Server, Zap, X, Shield, Activity } from 'lucide-react';
import { cn } from "@/lib/utils";

const Node = ({ id, type, x, y, label, onDrag, isSelected, onClick, onConnectStart, onConnectEnd }) => {
    const Icon = type === 'agent' ? Bot : type === 'node' ? Server : Zap;
    const color = type === 'agent' ? 'text-[hsl(var(--color-intent))]' : type === 'node' ? 'text-[hsl(var(--color-system))]' : 'text-[hsl(var(--color-execution))]';
    const borderColor = type === 'agent' ? 'border-[hsl(var(--color-intent))]' : type === 'node' ? 'border-[hsl(var(--color-system))]' : 'border-[hsl(var(--color-execution))]';

    return (
        <motion.div
            drag
            dragMomentum={false}
            onDrag={(e, info) => onDrag(id, info.point.x, info.point.y)}
            initial={{ x, y }}
            className={cn(
                "absolute w-32 bg-neutral-900/90 backdrop-blur border rounded-lg p-3 cursor-grab active:cursor-grabbing shadow-xl z-20 group",
                isSelected ? `${borderColor} ring-1 ring-[hsl(var(--color-active))]` : "border-white/10"
            )}
            onClick={(e) => { e.stopPropagation(); onClick(id); }}
        >
            <div className="flex flex-col items-center gap-2 pointer-events-none">
                <div className={cn("p-2 rounded-full bg-black/50 border border-white/5", color)}>
                    <Icon className="w-5 h-5" />
                </div>
                <div className="text-[10px] font-bold text-center text-neutral-300 truncate w-full">{label}</div>
            </div>
            
            {/* Connection Ports */}
            <div 
                className="absolute -right-1 top-1/2 -translate-y-1/2 w-3 h-3 bg-neutral-800 border border-white/50 rounded-full cursor-crosshair opacity-0 group-hover:opacity-100 transition-opacity hover:scale-125 hover:bg-white"
                onMouseDown={(e) => { e.stopPropagation(); onConnectStart(id, e); }}
            />
            <div 
                className="absolute -left-1 top-1/2 -translate-y-1/2 w-3 h-3 bg-neutral-800 border border-white/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                onMouseUp={(e) => { e.stopPropagation(); onConnectEnd(id); }}
            />
        </motion.div>
    );
};

export default function VisualGraphEditor({ nodes: initialNodes = [], agents = [] }) {
    const [nodes, setNodes] = useState([
        { id: 'start', type: 'trigger', x: 50, y: 300, label: 'Manual Trigger' },
        ...initialNodes.map((n, i) => ({ id: n.id, type: 'node', x: 300 + (i*100), y: 100 + (i*100), label: n.name })),
        ...agents.map((a, i) => ({ id: a.id, type: 'agent', x: 600, y: 50 + (i*120), label: a.name }))
    ]);
    const [edges, setEdges] = useState([]);
    const [connecting, setConnecting] = useState(null); // { nodeId, startX, startY, currentX, currentY }
    const [selected, setSelected] = useState(null);
    
    const containerRef = useRef(null);

    const handleDrag = (id, x, y) => {
        // We need to convert screen coords to relative container coords if we weren't using motion's drag
        // But Framer Motion handles it. We just need to update state for line drawing.
        // Actually, framer motion drag doesn't auto-update react state for performance.
        // We need to force update for lines.
        // Let's use a simpler approach: Update state on drag.
        // NOTE: 'info.point' is screen coordinates. We need relative.
        // A better way with Framer Motion is to rely on visual updates or use onDragEnd to save.
        // For live lines, we need live state.
        
        const rect = containerRef.current.getBoundingClientRect();
        const relX = x - rect.left;
        const relY = y - rect.top;
        
        setNodes(prev => prev.map(n => n.id === id ? { ...n, x: relX, y: relY } : n));
    };

    const startConnection = (id, e) => {
        const rect = containerRef.current.getBoundingClientRect();
        const startX = e.clientX - rect.left;
        const startY = e.clientY - rect.top;
        setConnecting({ nodeId: id, startX, startY, currentX: startX, currentY: startY });
    };

    const updateConnection = (e) => {
        if (!connecting) return;
        const rect = containerRef.current.getBoundingClientRect();
        setConnecting(prev => ({ ...prev, currentX: e.clientX - rect.left, currentY: e.clientY - rect.top }));
    };

    const endConnection = (targetId) => {
        if (connecting && connecting.nodeId !== targetId) {
            setEdges(prev => [...prev, { source: connecting.nodeId, target: targetId }]);
        }
        setConnecting(null);
    };

    // Helper to get center of a node
    const getNodeCenter = (id) => {
        const n = nodes.find(n => n.id === id);
        if (!n) return { x: 0, y: 0 };
        return { x: n.x + 64, y: n.y + 40 }; // Approx center (w-32=128, h-auto~80)
    };

    return (
        <div 
            ref={containerRef}
            className="w-full h-full relative bg-[hsl(var(--void))] overflow-hidden select-none"
            onMouseMove={updateConnection}
            onMouseUp={() => setConnecting(null)}
            onClick={() => setSelected(null)}
        >
            {/* Grid Background */}
            <div className="absolute inset-0 opacity-10 pointer-events-none" 
                style={{ 
                    backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', 
                    backgroundSize: '40px 40px' 
                }} 
            />

            {/* Edges */}
            <svg className="absolute inset-0 pointer-events-none z-10 w-full h-full">
                {edges.map((edge, i) => {
                    const start = getNodeCenter(edge.source);
                    const end = getNodeCenter(edge.target);
                    return (
                        <path 
                            key={i}
                            d={`M ${start.x} ${start.y} C ${start.x + 50} ${start.y}, ${end.x - 50} ${end.y}, ${end.x} ${end.y}`}
                            stroke="hsl(var(--color-execution))"
                            strokeWidth="2"
                            fill="none"
                            className="opacity-50"
                        />
                    );
                })}
                {connecting && (
                    <path 
                        d={`M ${connecting.startX} ${connecting.startY} C ${connecting.startX + 50} ${connecting.startY}, ${connecting.currentX - 50} ${connecting.currentY}, ${connecting.currentX} ${connecting.currentY}`}
                        stroke="hsl(var(--color-active))"
                        strokeWidth="2"
                        strokeDasharray="5,5"
                        fill="none"
                    />
                )}
            </svg>

            {/* Nodes */}
            {nodes.map(node => (
                <Node 
                    key={node.id} 
                    {...node} 
                    isSelected={selected === node.id}
                    onClick={setSelected}
                    onDrag={handleDrag}
                    onConnectStart={startConnection}
                    onConnectEnd={endConnection}
                />
            ))}

            {/* Controls */}
            <div className="absolute top-4 left-4 z-30 p-2 bg-neutral-900/80 rounded border border-white/10 backdrop-blur">
                <OrientingText className="text-[10px] tracking-widest mb-2">GRAPH COMPOSER</OrientingText>
                <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-intent))]" />
                        <span>Agents: {nodes.filter(n => n.type === 'agent').length}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-system))]" />
                        <span>Nodes: {nodes.filter(n => n.type === 'node').length}</span>
                    </div>
                </div>
            </div>
        </div>
    );
}