import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileArchive, CheckCircle2, Server, Shield, Zap, Loader2, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { SecurityGate } from './SecurityGate';
import { Progress } from "@/components/ui/progress";
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/System';

export default function SiteDeployer() {
    const [status, setStatus] = useState('idle'); // idle, uploading, scanning, deploying, success, error
    const [progress, setProgress] = useState(0);
    const [logs, setLogs] = useState([]);
    const [deployStats, setDeployStats] = useState(null);
    const [uploadedFile, setUploadedFile] = useState(null);

    const addLog = (msg) => setLogs(prev => [...prev, { time: new Date().toLocaleTimeString(), msg }]);

    const onDrop = useCallback(async (acceptedFiles) => {
        const file = acceptedFiles[0];
        if (!file) return;

        setStatus('uploading');
        setProgress(10);
        addLog(`Initiating upload: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`);

        try {
            // 1. Upload File
            const { file_url } = await base44.integrations.Core.UploadFile({ file });
            setProgress(40);
            addLog("Upload complete. Secure URL generated.");
            
            setUploadedFile({ file, file_url });
            setStatus('scanning');
            
        } catch (error) {
            console.error(error);
            setStatus('error');
            addLog(`Error: ${error.message}`);
            toast.error("Upload Failed");
        }
    }, []);

    const handleDeploy = async () => {
        if (!uploadedFile) return;

        setStatus('deploying');
        addLog("Security verification passed. Sending bundle to Deployment Engine...");
        
        try {
            const progressInterval = setInterval(() => {
                setProgress(p => Math.min(p + 5, 90));
            }, 500);

            const response = await base44.functions.invoke('deploySite', { 
                file_url: uploadedFile.file_url,
                environment: 'production' 
            });

            clearInterval(progressInterval);
            
            if (response.data.success) {
                setProgress(100);
                setStatus('success');
                setDeployStats(response.data.details);
                addLog("Deployment successful. System is live.");
                toast.success("Site Deployed Successfully");
            } else {
                throw new Error(response.data.error || "Deployment failed");
            }

        } catch (error) {
            console.error(error);
            setStatus('error');
            addLog(`Error: ${error.message}`);
            toast.error("Deployment Failed");
        }
    };

    const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
        onDrop,
        accept: {
            'application/zip': ['.zip'],
            'application/x-zip-compressed': ['.zip']
        },
        maxFiles: 1
    });

    return (
        <div className="w-full max-w-2xl mx-auto space-y-8">
            <div className="space-y-2 text-center">
                <OrientingText className="text-[hsl(var(--color-execution))]">DEPLOYMENT ENGINE</OrientingText>
                <IntentText className="text-3xl font-light">Drop & Deploy</IntentText>
                <p className="text-neutral-500 text-sm max-w-md mx-auto">
                    Upload your site bundle (.zip). We'll handle the API hooks, VPN configuration, and addon provisioning automatically.
                </p>
            </div>

            {/* Drop Zone */}
            {status === 'idle' && (
                <div 
                    {...getRootProps()} 
                    className={cn(
                        "border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all duration-300 group",
                        isDragActive 
                            ? "border-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/5 scale-[1.02]" 
                            : "border-white/10 hover:border-white/20 hover:bg-white/5"
                    )}
                >
                    <input {...getInputProps()} />
                    <div className="w-16 h-16 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform shadow-xl">
                        <Upload className="w-6 h-6 text-neutral-400 group-hover:text-white transition-colors" />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">
                        {isDragActive ? "Drop bundle here..." : "Drag & Drop site bundle"}
                    </h3>
                    <p className="text-sm text-neutral-500">
                        or click to browse files
                    </p>
                    <div className="mt-6 flex items-center justify-center gap-2 text-[10px] text-neutral-600 uppercase tracking-wider font-mono">
                        <span className="flex items-center gap-1"><FileArchive className="w-3 h-3" /> .ZIP ONLY</span>
                        <span>•</span>
                        <span>MAX 500MB</span>
                    </div>
                </div>
            )}

            {/* Security Gate State */}
            {status === 'scanning' && uploadedFile && (
                <SecurityGate 
                    file={uploadedFile.file} 
                    onVerified={handleDeploy}
                    onCancel={() => setStatus('idle')}
                />
            )}

            {/* Processing State */}
            {(status === 'uploading' || status === 'deploying') && (
                <div className="bg-neutral-900/50 border border-white/10 rounded-xl p-8 space-y-6">
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                            <Loader2 className="w-5 h-5 animate-spin text-[hsl(var(--color-execution))]" />
                            <span className="text-sm font-medium text-white">
                                {status === 'uploading' ? 'Uploading Bundle...' : 'Provisioning System...'}
                            </span>
                        </div>
                        <span className="text-xs font-mono text-neutral-500">{Math.round(progress)}%</span>
                    </div>
                    <Progress value={progress} className="h-1" />
                    
                    <div className="bg-black/40 rounded border border-white/5 p-4 h-32 overflow-y-auto font-mono text-[10px] space-y-1">
                        {logs.map((log, i) => (
                            <div key={i} className="text-neutral-400">
                                <span className="text-neutral-600 mr-2">[{log.time}]</span>
                                {log.msg}
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Success State */}
            {status === 'success' && deployStats && (
                <div className="bg-[hsl(var(--color-execution))]/5 border border-[hsl(var(--color-execution))]/20 rounded-xl p-8 text-center space-y-6 animate-in fade-in zoom-in duration-300">
                    <div className="w-16 h-16 rounded-full bg-[hsl(var(--color-execution))]/20 flex items-center justify-center mx-auto mb-4">
                        <CheckCircle2 className="w-8 h-8 text-[hsl(var(--color-execution))]" />
                    </div>
                    
                    <div>
                        <h3 className="text-xl font-medium text-white mb-2">Deployment Complete</h3>
                        <p className="text-sm text-neutral-400">Your site is live and securely configured.</p>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-left max-w-lg mx-auto bg-neutral-900/50 p-4 rounded-lg border border-white/5">
                        <div className="space-y-1">
                            <div className="text-[10px] uppercase text-neutral-500 font-bold">Network</div>
                            <div className="flex items-center gap-1.5 text-xs text-white">
                                <Shield className="w-3 h-3 text-green-500" />
                                {deployStats.vpn_status}
                            </div>
                        </div>
                        <div className="space-y-1">
                            <div className="text-[10px] uppercase text-neutral-500 font-bold">Endpoints</div>
                            <div className="flex items-center gap-1.5 text-xs text-white">
                                <Zap className="w-3 h-3 text-yellow-500" />
                                {deployStats.endpoints_hooked} Active
                            </div>
                        </div>
                        <div className="space-y-1">
                            <div className="text-[10px] uppercase text-neutral-500 font-bold">Addons</div>
                            <div className="flex items-center gap-1.5 text-xs text-white">
                                <Server className="w-3 h-3 text-blue-500" />
                                {deployStats.addons_installed.length} Installed
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-center gap-4">
                        <Button variant="outline" onClick={() => { setStatus('idle'); setLogs([]); setProgress(0); }}>
                            Deploy Another
                        </Button>
                        <Button className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90">
                            Visit Site <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </div>
                </div>
            )}

             {/* Error State */}
             {status === 'error' && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-8 text-center space-y-4">
                    <div className="text-red-500 font-bold">Deployment Failed</div>
                    <p className="text-sm text-neutral-400">Something went wrong during the provisioning process.</p>
                    <Button variant="outline" onClick={() => { setStatus('idle'); setLogs([]); setProgress(0); }}>
                        Try Again
                    </Button>
                </div>
            )}
        </div>
    );
}