import React, { useState, useEffect, useRef } from 'react';
import { 
    Terminal, Check, Shield, Cpu, Lock, 
    Wifi, Download, RefreshCw, ChevronRight 
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/System';
import { InstallerService } from './InstallerService';

export const InstallerTerminal = () => {
    const [lines, setLines] = useState([]);
    const [completed, setCompleted] = useState(false);
    const [deviceCode, setDeviceCode] = useState(null);
    const scrollRef = useRef(null);
    const [started, setStarted] = useState(false);

    useEffect(() => {
        if (started) return;
        setStarted(true);

        const runSimulation = async () => {
            try {
                // Initialize Service
                const code = await InstallerService.getInstallLogs((log) => {
                    setLines(prev => [...prev, log]);
                });
                
                setDeviceCode(code);
                setCompleted(true);
            } catch (error) {
                setLines(prev => [...prev, { type: 'error', text: `Installation Failed: ${error.message}` }]);
            }
        };

        const timer = setTimeout(runSimulation, 1000);
        return () => clearTimeout(timer);
    }, []);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [lines]);

    const handleCopy = () => {
        navigator.clipboard.writeText("curl -sL https://install.xibalba.io | sudo bash");
    };

    return (
        <div className="w-full max-w-2xl mx-auto rounded-xl overflow-hidden bg-[#0c0c0c] border border-white/10 shadow-2xl font-mono text-sm relative group">
            {/* Terminal Header */}
            <div className="flex items-center justify-between px-4 py-2 bg-white/5 border-b border-white/5">
                <div className="flex items-center gap-2">
                    <div className="flex gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/50" />
                        <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20 border border-yellow-500/50" />
                        <div className="w-2.5 h-2.5 rounded-full bg-green-500/20 border border-green-500/50" />
                    </div>
                    <span className="ml-2 text-[10px] text-neutral-500">user@local-machine:~</span>
                </div>
                <Badge variant="outline" className="text-[9px] h-5 border-[hsl(var(--color-execution))]/30 text-[hsl(var(--color-execution))]">
                    <Shield className="w-3 h-3 mr-1" />
                    SECURE SHELL
                </Badge>
            </div>

            {/* Terminal Content */}
            <ScrollArea className="h-[300px] w-full p-4" ref={scrollRef}>
                <div className="space-y-1">
                    <div className="text-neutral-500 mb-4">
                        # Initiate Uplink Protocol (Linux Kernel 5.4+)
                    </div>
                    
                    {lines.map((line, i) => (
                        <div key={i} className={cn(
                            "break-all",
                            line.type === 'prompt' ? "text-neutral-200" : "text-neutral-400"
                        )}>
                            {line.type === 'prompt' && <span className="text-[hsl(var(--color-execution))] mr-2">$</span>}
                            {line.text}
                        </div>
                    ))}

                    {completed && (
                        <div className="mt-4 p-4 border border-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/5 rounded animate-in fade-in zoom-in duration-500">
                            <div className="text-[hsl(var(--color-execution))] font-bold mb-2">VERIFICATION REQUIRED</div>
                            <div className="text-neutral-300 mb-2">Please enter the following pairing code in your Control Plane:</div>
                            <div className="text-2xl font-bold tracking-[0.5em] text-white text-center py-2 select-all cursor-pointer hover:text-[hsl(var(--color-execution))] transition-colors">
                                {deviceCode}
                            </div>
                        </div>
                    )}
                    
                    {!completed && (
                        <div className="animate-pulse text-[hsl(var(--color-execution))]">_</div>
                    )}
                </div>
            </ScrollArea>

            {/* Quick Copy Overlay (Only visible initially) */}
            {lines.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-10 transition-opacity opacity-100 group-hover:opacity-0 pointer-events-none group-hover:pointer-events-none">
                     <div className="px-4 py-2 bg-neutral-900 border border-white/10 rounded flex items-center gap-2">
                        <Terminal className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                        <span className="text-neutral-400">Hover to visualize install</span>
                     </div>
                </div>
            )}
        </div>
    );
};