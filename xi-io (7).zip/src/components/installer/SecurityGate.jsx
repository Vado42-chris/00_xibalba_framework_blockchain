import React, { useState, useEffect } from 'react';
import { Shield, CheckCircle2, FileSearch } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { ManifestPreview } from '@/components/deployment/ManifestPreview';

export const SecurityGate = ({ file, onVerified, onCancel }) => {
    const [scanStep, setScanStep] = useState(0); // 0: init, 1: scanning, 2: analyzing, 3: verified
    const [progress, setProgress] = useState(0);

    // Simulate scanning phases
    useEffect(() => {
        const steps = [
            { p: 20, t: 800 },
            { p: 45, t: 1500 },
            { p: 70, t: 2200 },
            { p: 90, t: 3000 },
            { p: 100, t: 3500 }
        ];

        let timeouts = [];

        steps.forEach((step, i) => {
            const timeout = setTimeout(() => {
                setProgress(step.p);
                if (step.p < 50) setScanStep(1); // Scanning
                else if (step.p < 100) setScanStep(2); // Analyzing
                else setScanStep(3); // Verified
            }, step.t);
            timeouts.push(timeout);
        });

        return () => timeouts.forEach(clearTimeout);
    }, []);

    return (
        <div className="bg-neutral-950 rounded-xl border border-white/10 overflow-hidden relative">
            {/* Header */}
            <div className="bg-neutral-900/50 p-4 border-b border-white/5 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Shield className={cn("w-4 h-4", scanStep === 3 ? "text-green-500" : "text-[hsl(var(--color-execution))]")} />
                    <span className="text-xs font-bold tracking-widest text-neutral-300">SECURITY GATEKEEPER</span>
                </div>
                <div className="text-[10px] font-mono text-neutral-500">
                    {file.name}
                </div>
            </div>

            <div className="p-8 min-h-[300px] flex flex-col items-center justify-center relative">
                
                {/* Scanner Animation */}
                <div className="relative mb-8">
                    <div className={cn(
                        "w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500",
                        scanStep === 3 ? "bg-green-500/10 border-green-500/50" : "bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))]/30",
                        "border-2"
                    )}>
                        {scanStep === 3 ? (
                            <CheckCircle2 className="w-10 h-10 text-green-500" />
                        ) : (
                            <FileSearch className="w-10 h-10 text-[hsl(var(--color-execution))] animate-pulse" />
                        )}
                    </div>
                    
                    {/* Radar Sweep */}
                    {scanStep < 3 && (
                        <motion.div 
                            className="absolute inset-0 border-t-2 border-[hsl(var(--color-execution))] rounded-full"
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                        />
                    )}
                </div>

                {/* Status Text */}
                <div className="text-center space-y-2 mb-8">
                    <h3 className="text-xl font-medium text-white">
                        {scanStep === 0 && "Initializing Scan..."}
                        {scanStep === 1 && "Scanning Signature..."}
                        {scanStep === 2 && "Analyzing Manifest..."}
                        {scanStep === 3 && "Bundle Verified Safe"}
                    </h3>
                    <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                        {scanStep < 3 
                            ? "Checking against known malware signatures and verifying cryptographic integrity."
                            : "No threats detected. Valid manifest found. Ready for deployment."
                        }
                    </p>
                </div>

                {/* Progress Bar (Hidden when verified) */}
                {scanStep < 3 && (
                    <div className="w-full max-w-xs space-y-2">
                        <Progress value={progress} className="h-1 bg-neutral-800" indicatorClassName="bg-[hsl(var(--color-execution))]" />
                        <div className="flex justify-between text-[10px] font-mono text-neutral-600">
                            <span>SHA-256 HASHING</span>
                            <span>{progress}%</span>
                        </div>
                    </div>
                )}

                {/* Verified Manifest Preview */}
                {scanStep === 3 && (
                    <ManifestPreview 
                        manifest={{
                            name: file.name.replace('.zip', ''),
                            ui_version: "1.0.0",
                            permissions: {
                                requires_auth: true,
                                read_config: true,
                                provision_addons: true
                            }
                        }}
                        onAuthorize={onVerified}
                        onReject={onCancel}
                    />
                )}
            </div>
        </div>
    );
};