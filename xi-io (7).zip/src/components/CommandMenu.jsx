import React, { useEffect, useState } from 'react';
import { Command } from 'cmdk';
import { useNavigate } from 'react-router-dom';
import { 
  Calculator, 
  Calendar, 
  CreditCard, 
  Settings, 
  Smile, 
  User,
  LayoutGrid,
  Terminal,
  Cpu,
  Shield,
  Search,
  Zap,
  LogOut,
  Plus
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Dialog, DialogContent } from "@/components/ui/dialog";

export function CommandMenu() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const down = (e) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
      if (e.key === 'p' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  const runCommand = (command) => {
    setOpen(false);
    command();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="p-0 overflow-hidden bg-transparent border-none shadow-2xl max-w-[640px]">
        <Command className="bg-[hsl(var(--layer-state))] border border-[hsl(var(--layer-orientation))] rounded-xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
          <div className="flex items-center border-b border-[hsl(var(--layer-orientation))] px-3" cmdk-input-wrapper="">
            <Search className="w-4 h-4 mr-2 text-[hsl(var(--fg-orientation))]" />
            <Command.Input 
              placeholder="Type a command or search..." 
              className="flex h-12 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-[hsl(var(--fg-orientation))] text-[hsl(var(--fg-intent))] disabled:cursor-not-allowed disabled:opacity-50"
            />
          </div>
          <Command.List className="max-h-[300px] overflow-y-auto overflow-x-hidden py-2 px-2 scrollbar-thin scrollbar-thumb-[hsl(var(--layer-orientation))]">
            <Command.Empty className="py-6 text-center text-sm text-[hsl(var(--fg-orientation))]">No results found.</Command.Empty>
            
            <Command.Group heading="Navigation" className="text-xs font-medium text-[hsl(var(--fg-orientation))] px-2 pb-1.5 pt-2">
              <Command.Item 
                onSelect={() => runCommand(() => navigate(createPageUrl('Dashboard')))}
                className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-[hsl(var(--layer-orientation))] aria-selected:text-[hsl(var(--fg-intent))] text-[hsl(var(--fg-state))] data-[disabled]:pointer-events-none data-[disabled]:opacity-50"
              >
                <LayoutGrid className="mr-2 h-4 w-4" />
                <span>Dashboard</span>
              </Command.Item>
              <Command.Item 
                onSelect={() => runCommand(() => navigate(createPageUrl('Console')))}
                className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-[hsl(var(--layer-orientation))] aria-selected:text-[hsl(var(--fg-intent))] text-[hsl(var(--fg-state))]"
              >
                <Terminal className="mr-2 h-4 w-4" />
                <span>Console</span>
              </Command.Item>
              <Command.Item 
                onSelect={() => runCommand(() => navigate(createPageUrl('Agents')))}
                className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-[hsl(var(--layer-orientation))] aria-selected:text-[hsl(var(--fg-intent))] text-[hsl(var(--fg-state))]"
              >
                <Cpu className="mr-2 h-4 w-4" />
                <span>Agents</span>
              </Command.Item>
              <Command.Item 
                onSelect={() => runCommand(() => navigate(createPageUrl('Audit')))}
                className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-[hsl(var(--layer-orientation))] aria-selected:text-[hsl(var(--fg-intent))] text-[hsl(var(--fg-state))]"
              >
                <Shield className="mr-2 h-4 w-4" />
                <span>System Audit</span>
              </Command.Item>
            </Command.Group>

            <Command.Separator className="my-1 h-px bg-[hsl(var(--layer-orientation))]" />

            <Command.Group heading="Actions" className="text-xs font-medium text-[hsl(var(--fg-orientation))] px-2 pb-1.5 pt-2">
              <Command.Item 
                onSelect={() => runCommand(() => console.log('New Project'))}
                className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-[hsl(var(--layer-orientation))] aria-selected:text-[hsl(var(--fg-intent))] text-[hsl(var(--fg-state))]"
              >
                <Plus className="mr-2 h-4 w-4" />
                <span>Create New Project</span>
                <span className="ml-auto text-xs tracking-widest text-[hsl(var(--fg-orientation))]">⌘N</span>
              </Command.Item>
              <Command.Item 
                onSelect={() => runCommand(() => console.log('System Scan'))}
                className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-[hsl(var(--layer-orientation))] aria-selected:text-[hsl(var(--fg-intent))] text-[hsl(var(--fg-state))]"
              >
                <Zap className="mr-2 h-4 w-4" />
                <span>Run System Scan</span>
              </Command.Item>
            </Command.Group>

            <Command.Separator className="my-1 h-px bg-[hsl(var(--layer-orientation))]" />

            <Command.Group heading="System" className="text-xs font-medium text-[hsl(var(--fg-orientation))] px-2 pb-1.5 pt-2">
              <Command.Item 
                onSelect={() => runCommand(() => console.log('Logout'))}
                className="relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none aria-selected:bg-[hsl(var(--layer-orientation))] aria-selected:text-[hsl(var(--fg-intent))] text-[hsl(var(--fg-state))]"
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>Disconnect Session</span>
              </Command.Item>
            </Command.Group>
          </Command.List>
          
          <div className="border-t border-[hsl(var(--layer-orientation))] p-2 flex items-center justify-between">
             <div className="text-[10px] text-[hsl(var(--fg-orientation))] font-mono px-2">
                XI-OS v2.0.4
             </div>
             <div className="flex gap-2">
                <span className="text-[10px] text-[hsl(var(--fg-orientation))] bg-[hsl(var(--layer-orientation))] border border-[hsl(var(--layer-orientation))] px-1.5 py-0.5 rounded">Esc to close</span>
                <span className="text-[10px] text-[hsl(var(--fg-orientation))] bg-[hsl(var(--layer-orientation))] border border-[hsl(var(--layer-orientation))] px-1.5 py-0.5 rounded">↵ to select</span>
             </div>
          </div>
        </Command>
      </DialogContent>
    </Dialog>
  );
}