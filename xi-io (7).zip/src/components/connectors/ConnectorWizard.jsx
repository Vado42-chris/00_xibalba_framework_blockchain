import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bot, Code, Database, Key, Save, Play, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { createConnector } from '@/components/sdk/ConnectorSDK';

export const ConnectorWizard = () => {
    const [step, setStep] = useState(1);
    const [config, setConfig] = useState({
        name: '',
        id: '',
        authType: 'api_key',
        description: '',
        docsUrl: ''
    });
    const [aiPrompt, setAiPrompt] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedSpec, setGeneratedSpec] = useState(null);

    const handleGenerate = () => {
        if (!aiPrompt) return;
        setIsGenerating(true);
        
        // Simulate AI generation
        setTimeout(() => {
            setIsGenerating(false);
            const connector = createConnector({
                id: config.id || 'custom-connector',
                name: config.name || 'Custom Connector',
                authType: config.authType
            });
            
            // AI "guesses" actions based on prompt
            if (aiPrompt.toLowerCase().includes('crm')) {
                connector.defineAction('create_contact', 'Create Contact', { type: 'object', properties: { email: { type: 'string' } } }, () => {});
                connector.defineAction('get_deal', 'Get Deal', { type: 'object', properties: { id: { type: 'string' } } }, () => {});
            } else if (aiPrompt.toLowerCase().includes('email')) {
                connector.defineAction('send_email', 'Send Email', { type: 'object', properties: { to: { type: 'string' }, body: { type: 'string' } } }, () => {});
            } else {
                connector.defineAction('generic_action', 'Execute', { type: 'object' }, () => {});
            }

            setGeneratedSpec(connector.toJSON());
            setStep(3);
            toast.success("Connector Spec Generated", { description: "AI has drafted the integration logic." });
        }, 2000);
    };

    const handleSave = async () => {
        // In a real app, this would save to the backend
        toast.success("Connector Published", { description: `${config.name} is now available in your mesh.` });
        // Redirect or close would happen here
    };

    return (
        <div className="max-w-4xl mx-auto p-6 space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Connector Forge</h1>
                    <p className="text-neutral-400">Build custom integrations using the Valhalla SDK.</p>
                </div>
                <div className="flex items-center gap-2">
                    {[1, 2, 3].map(i => (
                        <div key={i} className={`w-3 h-3 rounded-full ${step >= i ? 'bg-[hsl(var(--color-intent))]' : 'bg-white/10'}`} />
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Sidebar */}
                <div className="md:col-span-1 space-y-4">
                    <Card className="bg-white/5 border-white/10">
                        <CardHeader>
                            <CardTitle className="text-sm uppercase tracking-wider text-neutral-400">Forge Status</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center justify-between text-sm">
                                <span>SDK Version</span>
                                <Badge variant="outline">v1.0.4</Badge>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                                <span>Environment</span>
                                <span className="text-[hsl(var(--color-execution))]">Production</span>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                {/* Main Content */}
                <div className="md:col-span-2">
                    {step === 1 && (
                        <Card className="bg-black/40 border-white/10">
                            <CardHeader>
                                <CardTitle>Core Configuration</CardTitle>
                                <CardDescription>Define the identity of your connector.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Connector Name</label>
                                    <Input 
                                        placeholder="e.g. My Custom CRM" 
                                        value={config.name}
                                        onChange={e => setConfig({...config, name: e.target.value, id: e.target.value.toLowerCase().replace(/\s+/g, '-')})}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Connector ID</label>
                                    <Input 
                                        value={config.id}
                                        readOnly
                                        className="font-mono text-neutral-500 bg-black/20" 
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Authentication Type</label>
                                    <Select value={config.authType} onValueChange={v => setConfig({...config, authType: v})}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="none">No Auth</SelectItem>
                                            <SelectItem value="api_key">API Key</SelectItem>
                                            <SelectItem value="oauth2">OAuth 2.0</SelectItem>
                                            <SelectItem value="basic">Basic Auth</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="pt-4 flex justify-end">
                                    <Button onClick={() => setStep(2)} className="bg-[hsl(var(--color-intent))] text-black">
                                        Next: Define Logic <ArrowRight className="w-4 h-4 ml-2" />
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {step === 2 && (
                        <Card className="bg-black/40 border-white/10">
                            <CardHeader>
                                <CardTitle>AI Logic Generation</CardTitle>
                                <CardDescription>Describe the API interaction. Our AI will generate the SDK code.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-sm font-medium">Describe the integration</label>
                                    <textarea 
                                        className="w-full h-32 bg-black/20 border border-white/10 rounded-md p-3 text-sm focus:outline-none focus:border-[hsl(var(--color-intent))]"
                                        placeholder="e.g. I need to fetch contacts from HubSpot using an API key and create new deals when a form is submitted."
                                        value={aiPrompt}
                                        onChange={e => setAiPrompt(e.target.value)}
                                    />
                                </div>
                                
                                <div className="flex justify-between items-center">
                                    <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
                                    <Button 
                                        onClick={handleGenerate} 
                                        disabled={!aiPrompt || isGenerating}
                                        className="bg-[hsl(var(--color-intent))] text-black"
                                    >
                                        {isGenerating ? (
                                            <>
                                                <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                                                Generating Spec...
                                            </>
                                        ) : (
                                            <>
                                                <Bot className="w-4 h-4 mr-2" />
                                                Generate Logic
                                            </>
                                        )}
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {step === 3 && generatedSpec && (
                        <Card className="bg-black/40 border-white/10">
                            <CardHeader>
                                <CardTitle>Review & Publish</CardTitle>
                                <CardDescription>Verify the generated connector specification.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="bg-black/50 p-4 rounded-md border border-white/5 font-mono text-xs overflow-auto max-h-64">
                                    <pre className="text-[hsl(var(--color-intent))]">
                                        {JSON.stringify(generatedSpec, null, 2)}
                                    </pre>
                                </div>

                                <div className="flex gap-4">
                                    <div className="flex-1 p-3 bg-white/5 rounded border border-white/10">
                                        <div className="text-xs text-neutral-400 mb-1">Actions Defined</div>
                                        <div className="text-xl font-bold">{generatedSpec.capabilities.actions.length}</div>
                                    </div>
                                    <div className="flex-1 p-3 bg-white/5 rounded border border-white/10">
                                        <div className="text-xs text-neutral-400 mb-1">Auth Type</div>
                                        <div className="text-xl font-bold uppercase">{generatedSpec.auth.type}</div>
                                    </div>
                                </div>
                                
                                <div className="flex justify-between items-center pt-4">
                                    <Button variant="ghost" onClick={() => setStep(2)}>Back</Button>
                                    <Button onClick={handleSave} className="bg-emerald-500 text-white hover:bg-emerald-600">
                                        <Save className="w-4 h-4 mr-2" />
                                        Publish Connector
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </div>
            </div>
        </div>
    );
};