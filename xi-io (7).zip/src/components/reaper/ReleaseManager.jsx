import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import DeploymentModal from '@/components/reaper/DeploymentModal';
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
    GitBranch, Sparkles, Rocket, Clock, 
    RotateCcw, CheckCircle2, AlertCircle, Loader2,
    Tag, History
} from 'lucide-react';
import { toast } from "sonner";
import { format } from 'date-fns';

export default function ReleaseManager({ projectId, onDeploy }) {
    const [isCreating, setIsCreating] = useState(false);
    const [deployRelease, setDeployRelease] = useState(null);
    const queryClient = useQueryClient();

    // Fetch Releases
    const { data: releases = [], isLoading } = useQuery({
        queryKey: ['releases'],
        queryFn: () => base44.entities.Release.list({ sort: { created_date: -1 } }),
        initialData: []
    });

    // Create Release Mutation
    const createReleaseMutation = useMutation({
        mutationFn: (releaseData) => base44.entities.Release.create(releaseData),
        onSuccess: () => {
            toast.success("Release cut successfully");
            queryClient.invalidateQueries(['releases']);
            setIsCreating(false);
        },
        onError: () => toast.error("Failed to cut release")
    });

    const handleCreateRelease = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        
        createReleaseMutation.mutate({
            version: formData.get('version'),
            description: formData.get('description'),
            status: 'stable', // Default for now
            commit_hash: 'sha-' + Math.random().toString(36).substring(7), // Mock hash
            artifacts: [], // Would capture file IDs here
            built_by: 'User' // Should be current user ID
        });
    };

    return (
        <div className="h-full flex flex-col">
            <div className="p-4 border-b border-white/5 space-y-4">
                <div className="flex items-center justify-between">
                    <OrientingText className="tracking-widest">RELEASES</OrientingText>
                    <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => setIsCreating(!isCreating)}
                        className="h-6 text-[10px] gap-2"
                    >
                        <Sparkles className="w-3 h-3" /> New Release
                    </Button>
                </div>

                {isCreating && (
                    <form onSubmit={handleCreateRelease} className="space-y-3 p-3 bg-neutral-900 rounded border border-white/10 animate-in slide-in-from-top-2">
                        <div className="space-y-1">
                            <label className="text-[10px] text-neutral-500">Version Tag</label>
                            <Input 
                                name="version" 
                                placeholder="v1.0.0" 
                                required
                                defaultValue={`v1.0.${releases.length}`}
                                className="h-7 text-xs bg-neutral-950 border-white/10"
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-[10px] text-neutral-500">Changelog</label>
                            <Textarea 
                                name="description" 
                                placeholder="What's new?" 
                                className="min-h-[60px] text-xs bg-neutral-950 border-white/10 resize-none"
                            />
                        </div>
                        <div className="flex justify-end gap-2">
                            <Button type="button" variant="ghost" size="sm" onClick={() => setIsCreating(false)} className="h-6 text-[10px]">Cancel</Button>
                            <Button type="submit" size="sm" className="h-6 text-[10px] bg-[hsl(var(--color-intent))] text-black">Cut Release</Button>
                        </div>
                    </form>
                )}
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {isLoading ? (
                    <div className="flex justify-center p-4">
                        <Loader2 className="w-4 h-4 animate-spin text-neutral-500" />
                    </div>
                ) : releases.length === 0 ? (
                    <div className="text-center p-8 text-neutral-600 space-y-2">
                        <GitBranch className="w-8 h-8 mx-auto opacity-20" />
                        <p className="text-xs">No releases yet</p>
                    </div>
                ) : (
                    releases.map(release => (
                        <div key={release.id} className="group relative p-3 rounded bg-neutral-900/30 border border-transparent hover:border-white/10 hover:bg-neutral-900/50 transition-all">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                    <Tag className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                                    <IntentText className="font-mono text-xs">{release.version}</IntentText>
                                    <Badge variant="outline" className={`text-[9px] h-4 px-1 ${
                                        release.status === 'stable' ? 'text-green-500 border-green-500/20' : 
                                        release.status === 'draft' ? 'text-yellow-500 border-yellow-500/20' :
                                        'text-neutral-500'
                                    }`}>
                                        {release.status}
                                    </Badge>
                                </div>
                                <span className="text-[9px] text-neutral-600 font-mono">
                                    {release.created_date ? format(new Date(release.created_date), 'MMM d, HH:mm') : 'Just now'}
                                </span>
                            </div>
                            
                            <p className="text-[10px] text-neutral-400 mb-3 line-clamp-2">
                                {release.description || "No description provided."}
                            </p>

                            <div className="flex items-center gap-2 pt-2 border-t border-white/5 opacity-60 group-hover:opacity-100 transition-opacity">
                                <Button 
                                    size="sm" 
                                    variant="ghost" 
                                    className="h-5 px-2 text-[9px] hover:text-[hsl(var(--color-execution))] gap-1"
                                    onClick={() => setDeployRelease(release)}
                                >
                                    <Rocket className="w-3 h-3" /> Deploy
                                </Button>
                                <div className="h-3 w-px bg-white/10" />
                                <span className="text-[9px] text-neutral-600 font-mono flex items-center gap-1">
                                    <History className="w-3 h-3" /> {release.commit_hash?.substring(0, 7)}
                                </span>
                            </div>
                        </div>
                    ))
                )}
            </div>
            
            <DeploymentModal 
                open={!!deployRelease} 
                onOpenChange={(open) => !open && setDeployRelease(null)} 
                preselectedRelease={deployRelease} 
            />
        </div>
    );
}