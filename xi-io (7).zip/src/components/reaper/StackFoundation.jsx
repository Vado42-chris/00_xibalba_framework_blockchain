import React from 'react';
import { cn } from '@/lib/utils';
import { Layers, Database, Shield, Cpu, ArrowUp, Activity } from 'lucide-react';

export default function StackFoundation() {
    const layers = [
        { name: 'Experience', icon: Layers, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
        { name: 'Application', icon: Cpu, color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
        { name: 'Data & State', icon: Database, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20' },
        { name: 'Network & Security', icon: Shield, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20' },
        { name: 'Infrastructure (Physical)', icon: Activity, color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/20' },
    ];

    return (
        <div className="w-full h-full flex flex-col-reverse gap-2 p-4 overflow-y-auto">
            <div className="text-[10px] text-center text-neutral-600 font-mono mb-2 uppercase tracking-widest">Foundation Level</div>
            {layers.map((layer, index) => (
                <div 
                    key={layer.name}
                    className={cn(
                        "flex items-center gap-4 p-3 rounded-lg border backdrop-blur-sm transition-all hover:scale-[1.02] cursor-default relative overflow-hidden group",
                        layer.bg, layer.border
                    )}
                >
                    {/* Lifting Animation */}
                    <div className="absolute bottom-0 left-0 w-full h-full bg-gradient-to-t from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    
                    <div className={cn("p-2 rounded-md bg-black/20 relative z-10", layer.color)}>
                        <layer.icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 relative z-10">
                        <div className={cn("font-bold text-sm", layer.color)}>{layer.name}</div>
                        <div className="h-1.5 w-full bg-black/20 rounded-full mt-2 overflow-hidden">
                            <div className={cn("h-full w-full animate-pulse opacity-50", layer.color.replace('text-', 'bg-'))} />
                        </div>
                    </div>
                    <div className="text-[10px] font-mono opacity-50 relative z-10">L{5 - index}</div>
                </div>
            ))}
            <div className="flex flex-col items-center my-4 gap-2">
                <div className="flex gap-1">
                    <ArrowUp className="w-4 h-4 text-[hsl(var(--color-intent))] animate-bounce" />
                    <ArrowUp className="w-4 h-4 text-[hsl(var(--color-intent))] animate-bounce delay-75" />
                    <ArrowUp className="w-4 h-4 text-[hsl(var(--color-intent))] animate-bounce delay-150" />
                </div>
                <span className="text-[9px] font-mono text-[hsl(var(--color-intent))] tracking-[0.2em] uppercase animate-pulse">Lifting From Bottom</span>
            </div>
        </div>
    );
}