import React, { useState } from 'react';
import { 
    Maximize2, Play, Save, Code, Layout, 
    Monitor, RefreshCw, Smartphone, Tablet, Plus,
    Trash2
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { QuadrantGrid, Quadrant, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { Explainable } from '@/components/ui/design-system/RosettaStone';
import { toast } from 'sonner';
import { Check } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import FileTree from '@/components/ui/FileTree';

import CodeForge from './CodeForge';
import VisualForge from './VisualForge';
import DeploymentModal from '@/components/reaper/DeploymentModal';
import CodeAssistant from '@/components/assistants/CodeAssistant';
import InlineAIPrompt from './InlineAIPrompt';
import { SystemConfirmation } from '@/components/ui/design-system/SystemDialogs';
import { Toggle } from "@/components/ui/toggle";
import { Command } from "lucide-react";

const DEFAULT_CODE = `
<div class="min-h-screen bg-neutral-950 text-white p-8 flex flex-col items-center justify-center font-sans">
  <div class="max-w-md w-full text-center space-y-6">
    <div class="inline-block p-3 rounded-full bg-green-500/10 mb-4">
      <div class="w-8 h-8 rounded-full bg-green-500 animate-pulse"></div>
    </div>
    <h1 class="text-4xl font-bold tracking-tight">System Online</h1>
    <p class="text-neutral-400">The Reaper Forge is active. Begin constructing your interface.</p>
    
    <div class="grid grid-cols-2 gap-4 pt-8">
      <button class="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 rounded border border-white/10 transition-colors">
        Documentation
      </button>
      <button class="px-4 py-2 bg-green-600 hover:bg-green-500 text-black font-bold rounded transition-colors">
        Deploy Node
      </button>
    </div>
  </div>
</div>
`;

export default function ReaperIDE() {
    const [activeFile, setActiveFile] = useState({ path: 'index.html', content: DEFAULT_CODE });
    const [code, setCode] = useState(DEFAULT_CODE);
    const [mode, setMode] = useState('visual'); 
    const [viewport, setViewport] = useState('desktop'); 
    const [key, setKey] = useState(0); 
    const [isDeployOpen, setIsDeployOpen] = useState(false);
    const [showAssistant, setShowAssistant] = useState(false);
    const [showInlinePrompt, setShowInlinePrompt] = useState(false);
    const [vimMode, setVimMode] = useState(false);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

    const queryClient = useQueryClient();

    // Keyboard Shortcuts
    React.useEffect(() => {
        const handleKeyDown = (e) => {
            // Cmd+K for Inline Prompt
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                setShowInlinePrompt(prev => !prev);
            }
            // Cmd+L for Chat Assistant (Cursor style)
            if ((e.metaKey || e.ctrlKey) && e.key === 'l') {
                e.preventDefault();
                setShowAssistant(prev => !prev);
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    // Fetch files
    const { data: files = [] } = useQuery({
        queryKey: ['source_files'],
        queryFn: () => base44.entities.SourceFile.list(),
        initialData: []
    });

    // Update code when active file changes
    React.useEffect(() => {
        setCode(activeFile.content || '');
    }, [activeFile]);

    const saveMutation = useMutation({
        mutationFn: async ({ path, content }) => {
            const existing = files.find(f => f.path === path);
            if (existing) {
                return base44.entities.SourceFile.update(existing.id, { content });
            } else {
                return base44.entities.SourceFile.create({
                    path,
                    content,
                    language: path.split('.').pop() || 'txt',
                    locked_by: 'user'
                });
            }
        },
        onSuccess: () => {
            toast.success("File committed");
            queryClient.invalidateQueries(['source_files']);
        }
    });

    const deleteMutation = useMutation({
        mutationFn: async (path) => {
            const file = files.find(f => f.path === path);
            if (file) {
                return base44.entities.SourceFile.delete(file.id);
            }
        },
        onSuccess: () => {
            toast.success("File deleted");
            queryClient.invalidateQueries(['source_files']);
            setActiveFile({ path: 'index.html', content: '' }); // Reset
            setShowDeleteConfirm(false);
        }
    });

    const createNewFile = () => {
        const name = prompt("File name (e.g. styles.css):");
        if (!name) return;
        const newFile = { path: name, content: '' };
        setActiveFile(newFile);
        saveMutation.mutate(newFile);
    };

    const handleFileSelect = (file) => {
        setActiveFile(file);
    };

    const handleRun = () => {
        setKey(prev => prev + 1);
        toast.success("Preview Refreshed");
    };

    const handleSave = () => {
        saveMutation.mutate({ path: activeFile.path, content: code });
    };

    return (
        <div className="h-full w-full flex flex-col bg-neutral-950 overflow-hidden">
            {/* Toolbar */}
            <div className="h-12 border-b border-white/5 bg-neutral-900 flex items-center justify-between px-4 shrink-0">
                <div className="flex items-center gap-4">
                    <OrientingText 
                        className="text-[hsl(var(--color-execution))] font-bold tracking-widest"
                        human="WEBSITE BUILDER"
                    >
                        REAPER FORGE v1.0
                    </OrientingText>
                    <div className="h-4 w-px bg-white/10" />
                    <div className="flex bg-neutral-950 rounded p-1 border border-white/5">
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => setMode('visual')}
                            className={`h-6 text-[10px] px-3 ${mode === 'visual' ? 'bg-neutral-800 text-white' : 'text-neutral-500'}`}
                        >
                            <Layout className="w-3 h-3 mr-2" /> VISUAL
                        </Button>
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => setMode('code')}
                            className={`h-6 text-[10px] px-3 ${mode === 'code' ? 'bg-neutral-800 text-white' : 'text-neutral-500'}`}
                        >
                            <Code className="w-3 h-3 mr-2" /> SOURCE
                        </Button>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 mr-4 bg-neutral-950 rounded p-1 border border-white/5">
                        <Button variant="ghost" size="icon" className={`h-6 w-6 ${viewport === 'mobile' ? 'text-white' : 'text-neutral-600'}`} onClick={() => setViewport('mobile')}><Smartphone className="w-3 h-3" /></Button>
                        <Button variant="ghost" size="icon" className={`h-6 w-6 ${viewport === 'tablet' ? 'text-white' : 'text-neutral-600'}`} onClick={() => setViewport('tablet')}><Tablet className="w-3 h-3" /></Button>
                        <Button variant="ghost" size="icon" className={`h-6 w-6 ${viewport === 'desktop' ? 'text-white' : 'text-neutral-600'}`} onClick={() => setViewport('desktop')}><Monitor className="w-3 h-3" /></Button>
                    </div>
                    
                    <Button 
                        size="sm" 
                        variant="outline"
                        onClick={handleRun}
                        className="h-7 text-xs border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/10"
                    >
                        <RefreshCw className="w-3 h-3 mr-2" /> REFRESH
                    </Button>
                    <Button 
                        size="sm" 
                        onClick={handleSave}
                        disabled={saveMutation.isPending}
                        className="h-7 text-xs bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                    >
                        <Save className="w-3 h-3 mr-2" /> {saveMutation.isPending ? 'SAVING...' : 'COMMIT'}
                    </Button>
                    <div className="h-4 w-px bg-white/10 mx-2" />
                    <Button 
                        size="sm" 
                        onClick={() => setIsDeployOpen(true)}
                        className="h-7 text-xs bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90"
                    >
                        <Play className="w-3 h-3 mr-2" /> 
                        <Explainable technical="DEPLOY" human="PUBLISH SITE" generational="YEET IT">DEPLOY</Explainable>
                    </Button>
                </div>
            </div>

            {/* Inline AI Prompt Overlay */}
            <InlineAIPrompt 
                isOpen={showInlinePrompt}
                onClose={() => setShowInlinePrompt(false)}
                onApply={(newCode) => {
                    setCode(newCode);
                    handleSave(); // Auto-save on apply? Maybe not, but let's keep it safe.
                }}
                currentCode={code}
                language={activeFile.language || 'javascript'}
            />

            {/* Main Workspace */}
            <div className="flex-1 flex overflow-hidden">
                {/* File Explorer (Left) */}
                <div className="w-48 flex-shrink-0 flex flex-col border-r border-white/5 bg-neutral-900/30">
                    <div className="p-2 border-b border-white/5 flex justify-between items-center">
                        <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest pl-2">Explorer</span>
                        <div className="flex gap-1">
                            <Button size="icon" variant="ghost" className="h-6 w-6 hover:text-red-500" onClick={() => setShowDeleteConfirm(true)} disabled={activeFile.path === 'index.html'}>
                                <Trash2 className="w-3 h-3" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={createNewFile}>
                                <Plus className="w-3 h-3" />
                            </Button>
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto">
                        <FileTree files={files} activeFile={activeFile} onSelect={handleFileSelect} />
                    </div>
                </div>

                {/* Editor Pane (Middle) */}
                <div className="flex-1 border-r border-white/5 flex flex-col bg-neutral-950 min-w-0">
                    <div className="h-8 border-b border-white/5 flex items-center justify-between px-4 bg-neutral-900/50">
                        <div className="flex items-center">
                            <Code className="w-3 h-3 text-neutral-500 mr-2" />
                            <span className="text-xs text-neutral-300 font-mono">{activeFile.path}</span>
                            {vimMode && <span className="ml-3 text-[9px] bg-green-500/20 text-green-500 px-1 rounded font-mono">VIM</span>}
                        </div>
                        <div className="flex items-center gap-2">
                             <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => setVimMode(!vimMode)}
                                className={cn("h-5 text-[9px] px-2", vimMode ? "text-green-500 bg-green-500/10" : "text-neutral-500")}
                            >
                                VIM MODE
                            </Button>
                             <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => setShowAssistant(!showAssistant)}
                                className={cn("h-5 text-[9px] px-2 gap-1", showAssistant ? "text-[hsl(var(--color-intent))]" : "text-neutral-500")}
                            >
                                <Command className="w-2 h-2" /> L
                            </Button>
                        </div>
                    </div>
                    <div className="flex-1 relative">
                        {mode === 'visual' ? (
                            <VisualForge 
                                currentCode={code} 
                                onCodeChange={setCode} 
                            />
                        ) : (
                            <CodeForge 
                                code={code} 
                                onChange={setCode}
                                vimMode={vimMode} 
                            />
                        )}
                    </div>
                </div>

                {/* AI Assistant Sidebar (Right of Editor, Left of Preview) */}
                {showAssistant && (
                    <div className="w-80 border-r border-white/5 bg-neutral-900/50 flex flex-col animate-in slide-in-from-left-4 duration-200">
                        <CodeAssistant 
                            mode="chat" 
                            onClose={() => setShowAssistant(false)} 
                            contextCode={code}
                            onApplyCode={(newCode) => {
                                setCode(newCode);
                                toast.success("Code applied to editor");
                            }}
                        />
                    </div>
                )}

                {/* Preview Pane (Right) */}
                <div className="w-1/2 bg-[#050505] flex flex-col items-center justify-center relative bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-neutral-900/20 to-neutral-950">
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />
                    
                    <div 
                        className={`transition-all duration-300 bg-white shadow-2xl overflow-hidden ${
                            viewport === 'mobile' ? 'w-[375px] h-[667px] rounded-[30px] border-8 border-neutral-900' :
                            viewport === 'tablet' ? 'w-[768px] h-[1024px] rounded-[20px] border-8 border-neutral-900 scale-75' :
                            'w-full h-full'
                        }`}
                    >
                        <iframe
                            key={key}
                            srcDoc={`
                                <!DOCTYPE html>
                                <html>
                                <head>
                                    <script src="https://cdn.tailwindcss.com"></script>
                                    <style>
                                        body { margin: 0; overflow-x: hidden; }
                                        ::-webkit-scrollbar { width: 0px; background: transparent; }
                                    </style>
                                </head>
                                <body>${activeFile.path.endsWith('.html') ? code : '<div class="p-8 text-white font-mono">Select an HTML file to preview</div>'}</body>
                                </html>
                            `}
                            className="w-full h-full border-none bg-white"
                            title="Preview"
                            sandbox="allow-scripts"
                        />
                    </div>
                </div>
            </div>
            <DeploymentModal 
                open={isDeployOpen} 
                onOpenChange={setIsDeployOpen} 
                mode="smart_ship"
                preselectedRelease={{ version: 'latest-build', id: 'dev' }}
            />

            <SystemConfirmation 
                open={showDeleteConfirm}
                onOpenChange={setShowDeleteConfirm}
                title={`Delete ${activeFile.path}?`}
                description="This action will permanently delete the file from the source control."
                onConfirm={() => deleteMutation.mutate(activeFile.path)}
                variant="destructive"
                confirmText="Delete File"
            />
        </div>
    );
}