import React, { useState } from 'react';
import UnifiedCanvas from '@/components/studio/UnifiedCanvas';
import VisualPalette from '@/components/studio/VisualPalette';
import StudioToolbar from '@/components/studio/StudioToolbar';
import PropertyEditor from '@/components/studio/PropertyEditor';
import { COMPONENT_LIBRARY } from './ComponentLibrary';
import { toast } from 'sonner';
import { DragDropContext } from '@hello-pangea/dnd';
import { cn } from "@/lib/utils";
import { Monitor, Tablet, Smartphone } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

export default function VisualForge({ onCodeChange, currentCode }) {
    const [canvasItems, setCanvasItems] = useState([]);
    const [isPaletteOpen, setIsPaletteOpen] = useState(true);
    const [viewportWidth, setViewportWidth] = useState('100%');
    const [selectedItem, setSelectedItem] = useState(null);
    const [scale, setScale] = useState(1);
    const [activeTool, setActiveTool] = useState('select');
    
    // History
    const [history, setHistory] = useState([]);
    const [historyIndex, setHistoryIndex] = useState(-1);

    // Update code when items change
    React.useEffect(() => {
        if (canvasItems.length === 0) return;
        const generatedCode = `
<div class="p-8 space-y-6 min-h-screen bg-neutral-950 text-white font-sans">
${canvasItems.map(item => `  <!-- ${item.label} -->\n  ${item.html}`).join('\n\n')}
</div>`;
        onCodeChange(generatedCode);
    }, [canvasItems, onCodeChange]);

    const updateItems = (newItems) => {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newItems);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        setCanvasItems(newItems);
    };

    // Supply Chain: Fetch Installed Modules
    const { data: installedItems = [] } = useQuery({
        queryKey: ['installed_marketplace_items'],
        queryFn: async () => {
            const installed = await base44.entities.InstalledAddon.list();
            const items = await base44.entities.MarketplaceItem.list();
            
            // Filter only items that are installed AND have a manifest (code)
            const myItems = items.filter(item => 
                installed.some(inst => inst.addon_id === item.id) && item.manifest?.code
            );

            return [{
                category: "My Modules",
                items: myItems.map(item => ({
                    id: item.id,
                    type: 'module',
                    label: item.name,
                    icon: 'Box',
                    html: item.manifest.code,
                    data: {} 
                }))
            }];
        },
        initialData: []
    });

    // Merge libraries
    const mergedLibrary = [...installedItems, ...COMPONENT_LIBRARY];

    const handleDragEnd = (result) => {
        if (!result.destination) return;
        const { source, destination } = result;

        if (source.droppableId === 'palette' && destination.droppableId === 'canvas') {
            // Check merged library
            const template = mergedLibrary.flatMap(c => c.items).find(i => i.id === result.draggableId);
            if (!template) return;

            const newItem = {
                ...template,
                uniqueId: `${template.id}-${Date.now()}`
            };
            const newItems = [...canvasItems];
            newItems.splice(destination.index, 0, newItem);
            updateItems(newItems);
            setSelectedItem(newItem);
        } else if (source.droppableId === 'canvas' && destination.droppableId === 'canvas') {
            const newItems = [...canvasItems];
            const [moved] = newItems.splice(source.index, 1);
            newItems.splice(destination.index, 0, moved);
            updateItems(newItems);
        }
    };

    return (
        <div className="flex h-full w-full relative bg-neutral-950 overflow-hidden">
            <DragDropContext onDragEnd={handleDragEnd}>
                <StudioToolbar 
                    activeTool={activeTool}
                    onSetTool={setActiveTool}
                    onZoomIn={() => setScale(s => Math.min(2, s + 0.1))}
                    onZoomOut={() => setScale(s => Math.max(0.5, s - 0.1))}
                    onUndo={() => {
                        if (historyIndex > 0) {
                            setHistoryIndex(historyIndex - 1);
                            setCanvasItems(history[historyIndex - 1]);
                        }
                    }}
                    onRedo={() => {
                        if (historyIndex < history.length - 1) {
                            setHistoryIndex(historyIndex + 1);
                            setCanvasItems(history[historyIndex + 1]);
                        }
                    }}
                    onClear={() => updateItems([])}
                    canUndo={historyIndex > 0}
                    canRedo={historyIndex < history.length - 1}
                />

                {/* Viewport Controls */}
                <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1 bg-neutral-900 border border-white/10 p-1 rounded-md shadow-lg">
                     <button onClick={() => setViewportWidth('100%')} className={cn("p-2 rounded hover:bg-white/10", viewportWidth === '100%' && "bg-white/10")} title="Desktop"><Monitor className="w-4 h-4" /></button>
                     <button onClick={() => setViewportWidth('768px')} className={cn("p-2 rounded hover:bg-white/10", viewportWidth === '768px' && "bg-white/10")} title="Tablet"><Tablet className="w-4 h-4" /></button>
                     <button onClick={() => setViewportWidth('375px')} className={cn("p-2 rounded hover:bg-white/10", viewportWidth === '375px' && "bg-white/10")} title="Mobile"><Smartphone className="w-4 h-4" /></button>
                </div>

                {isPaletteOpen && (
                    <VisualPalette 
                        items={mergedLibrary}
                        onClose={() => setIsPaletteOpen(false)}
                        selectedItem={selectedItem}
                        onUpdateItem={(id, updates) => {
                            const newItems = canvasItems.map(i => i.uniqueId === id ? { ...i, ...updates } : i);
                            updateItems(newItems);
                            setSelectedItem(prev => ({ ...prev, ...updates }));
                        }}
                        canvasItems={canvasItems}
                        onSelectItem={(item) => setSelectedItem(item)}
                    />
                )}

                <UnifiedCanvas 
                    items={canvasItems}
                    onItemsChange={updateItems}
                    selectedId={selectedItem?.uniqueId}
                    onSelect={setSelectedItem}
                    scale={scale}
                    viewportWidth={viewportWidth}
                    activeTool={activeTool}
                    onToolReset={() => setActiveTool('select')}
                />
            </DragDropContext>

            {/* Right Side Property Editor */}
            <PropertyEditor 
                item={selectedItem}
                onUpdate={(id, updates) => {
                     const newItems = canvasItems.map(i => i.uniqueId === id ? { ...i, ...updates } : i);
                     updateItems(newItems);
                     setSelectedItem(prev => ({ ...prev, ...updates }));
                }}
                onDelete={(id) => {
                    const newItems = canvasItems.filter(i => i.uniqueId !== id);
                    updateItems(newItems);
                    setSelectedItem(null);
                }}
            />
        </div>
    );
}