import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Rocket, Server, Globe, Tag, CheckCircle2, AlertCircle, Loader2, RefreshCcw, ShieldCheck, Split, History, Activity, ShieldAlert, BarChart } from 'lucide-react';
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { StateText, IntentText, Layer, OrientingText } from '@/components/ui/design-system/System';
import ProcessCompletion from '@/components/ui/design-system/ProcessCompletion';
import { Explainable } from '@/components/ui/design-system/RosettaStone';
import api from '@/components/api/service';

const DeploymentHistoryView = () => {
    const { data: history = [] } = useQuery({
        queryKey: ['deploy_history'],
        queryFn: async () => {
            const { data } = await base44.functions.invoke('deploySite', {}, { method: 'GET' });
            return data.history || [];
        }
    });

    const [compareMode, setCompareMode] = useState(false);
    const [selectedId, setSelectedId] = useState(null);
    const [diffData, setDiffData] = useState(null);

    const handleCompare = async (id) => {
        setSelectedId(id);
        setCompareMode(true);
        const { data } = await base44.functions.invoke('deploySite', {}, { method: 'GET', params: { compare: id } });
        setDiffData(data.diff);
    };

    if (compareMode && diffData) {
        return (
            <div className="space-y-3 animate-in fade-in slide-in-from-right-4">
                <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-[hsl(var(--color-execution))]">Version Comparison</h4>
                    <Button variant="ghost" size="sm" onClick={() => setCompareMode(false)} className="h-6 text-[10px]">Back</Button>
                </div>
                <div className="space-y-2 text-[10px]">
                    <div className="bg-black/20 p-2 rounded border border-white/5">
                        <div className="font-bold text-neutral-400 mb-1">Files Changed</div>
                        {diffData.files_changed.map(f => <div key={f} className="text-neutral-300 font-mono">• {f}</div>)}
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                        <div className="bg-black/20 p-2 rounded border border-white/5">
                            <div className="font-bold text-neutral-400 mb-1">Metrics (Latency)</div>
                            <div className="flex justify-between">
                                <span className="text-red-400">{diffData.metrics.latency.from}</span>
                                <span className="text-neutral-500">→</span>
                                <span className="text-green-400">{diffData.metrics.latency.to}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-2 h-full overflow-y-auto pr-2">
            {history.map(h => (
                <div key={h.id} className="p-2 bg-black/20 border border-white/5 rounded flex justify-between items-center group hover:border-white/10">
                    <div>
                        <div className="flex items-center gap-2">
                            <span className={`w-1.5 h-1.5 rounded-full ${h.status === 'success' ? 'bg-green-500' : 'bg-red-500'}`} />
                            <span className="text-[10px] font-mono text-white">{h.version}</span>
                        </div>
                        <div className="text-[9px] text-neutral-500">{new Date(h.timestamp).toLocaleDateString()}</div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => handleCompare(h.id)} className="h-6 text-[10px] bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity">
                        Compare
                    </Button>
                </div>
            ))}
        </div>
    );
};

// Deployment Modal
export default function DeploymentModal({ open, onOpenChange, preselectedRelease = null, mode = 'standard', projectId = '' }) {
    const [step, setStep] = useState(1); // 1: Config, 2: Deploying, 3: Success
    const [config, setConfig] = useState({
        releaseId: preselectedRelease?.id || '',
        nodeId: '',
        domainId: projectId,
        message: '',
        file: null, // For Zip Upload
        strategy: 'standard', // standard, blue_green, canary
        rollbackEnabled: false,
        canaryPercent: 10,
        healthCheckPath: '/health',
        rollbackErrorRate: 5
    });
    
    const [rollbackMode, setRollbackMode] = useState(false);
    const [activeTab, setActiveTab] = useState('strategy');
    
    const isSmartShip = mode === 'smart_ship';
    const queryClient = useQueryClient();

    // Data Fetching
    const { data: releases = [] } = useQuery({
        queryKey: ['releases_deploy'],
        queryFn: () => base44.entities.Release.list({ sort: { created_date: -1 }, limit: 10 }),
        initialData: []
    });

    const { data: nodes = [] } = useQuery({
        queryKey: ['nodes_deploy'],
        queryFn: () => base44.entities.Node.list({ filter: { status: 'connected' } }),
        initialData: []
    });

    // Auto-select first node if available
    React.useEffect(() => {
        if (nodes.length > 0 && !config.nodeId) {
            setConfig(prev => ({ ...prev, nodeId: nodes[0].id }));
        }
    }, [nodes]);

    const { data: domains = [] } = useQuery({
        queryKey: ['domains_deploy'],
        queryFn: () => base44.entities.ManagedDomain.list(),
        initialData: []
    });

    const shipMutation = useMutation({
        mutationFn: async (data) => {
            // 1. Create Release (if Smart Ship)
            let releaseVersion = releases.find(r => r.id === data.releaseId)?.version;
            
            // 1. ZIP UPLOAD FLOW (Smart Ship)
            if (isSmartShip && data.file) {
                // A. Upload
                toast.loading("Uploading Bundle...");
                
                const uploadResult = await api.uploadBundle(data.file);
                
                // B. Execute Deployment
                toast.loading("Executing Deployment Script...");
                let executeResult;

                // Remote / Bridge Flow using Enhanced deploySite function
                const { data: result } = await base44.functions.invoke('deploySite', {
                    file_url: uploadResult.file_url || 'direct-upload-id',
                    environment: 'production',
                    strategy: data.strategy,
                    canaryPercent: data.canaryPercent,
                    healthCheckConfig: { path: data.healthCheckPath, timeout: 5000 },
                    rollbackTriggers: { errorRate: data.rollbackErrorRate, latency: 500 }
                });
                executeResult = result;
                
                if (!executeResult.success) throw new Error(executeResult.error || 'Deployment failed');
                
                releaseVersion = executeResult.details?.version || 'v-bundle-' + Date.now();
                return executeResult;
            }

            // STANDARD FLOW (Legacy/Mock)
            if (isSmartShip && !data.file) {
                releaseVersion = 'v' + Date.now().toString().slice(-6);
                await base44.entities.Release.create({
                    version: releaseVersion,
                    status: 'stable',
                    description: data.message || 'Auto-ship from WorkRoom',
                    built_by: 'user'
                });
                await new Promise(resolve => setTimeout(resolve, 1500));
            }

            // 2. Simulate deployment process (for non-file flows)
            if (!data.file) await new Promise(resolve => setTimeout(resolve, 2000));
            
            // 3. Create deployment log
            if (!data.file) {
                await base44.entities.DeploymentLog.create({
                    node_id: data.nodeId,
                    node_name: nodes.find(n => n.id === data.nodeId)?.name,
                    project_id: projectId || data.domainId, 
                    version: releaseVersion,
                    status: 'success',
                    description: `Shipped ${releaseVersion} to ${nodes.find(n => n.id === data.nodeId)?.name}`
                });
            }

            // 4. Install to Desktop (Simulated by creating an InstalledAddon entry)
            if (data.installToDesktop) {
                // We create a mock Marketplace Item for this "User App" if it doesn't exist, or update it
                const appName = data.message ? data.message.split(':')[0] : `App ${releaseVersion}`;
                // In a real system, we'd link to the actual Project ID
                // For now, we simulate installing a "Custom App" widget
                await base44.entities.InstalledAddon.create({
                    addon_id: 'custom-app-' + Date.now(), // Fake ID
                    status: 'active',
                    config: { name: appName, version: releaseVersion, url: `https://deployment-${releaseVersion}.local` }
                });
            }
            
            return data;
        },
        onSuccess: () => {
            setStep(3);
            queryClient.invalidateQueries(['deployments', 'releases']);
            toast.success(isSmartShip ? "Shipped successfully" : "Deployment successful");
        },
        onError: () => {
            toast.error("Operation failed");
            setStep(1);
        }
    });

    // Rollback Handler
    const handleRollback = async () => {
        setStep(2);
        try {
            const { data } = await base44.functions.invoke('deploySite', {
                rollbackJobId: config.releaseId, 
                strategy: 'rollback',
                environment: 'production'
            });
            if (data.success) {
                setStep(3);
                toast.success("Rollback Successful");
            } else {
                throw new Error(data.error);
            }
        } catch (e) {
            toast.error("Rollback Failed: " + e.message);
            setStep(1);
        }
    };

    const handleDeploy = () => {
        if (!config.nodeId) {
            toast.error("No target node available");
            return;
        }
        if (!isSmartShip && !config.releaseId) {
            toast.error("Please select a release");
            return;
        }
        setStep(2);
        shipMutation.mutate(config);
    };

    const reset = () => {
        setStep(1);
        setConfig({ 
            releaseId: '', nodeId: '', domainId: '', message: '', 
            file: null, strategy: 'standard', rollbackEnabled: false, canaryPercent: 10 
        });
        setRollbackMode(false);
        onOpenChange(false);
    };

    return (
        <Dialog open={open} onOpenChange={(val) => !val && reset()}>
            <DialogContent className="bg-neutral-950 border-white/10 text-white sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        {rollbackMode ? <History className="w-5 h-5 text-red-500" /> : <Rocket className="w-5 h-5 text-[hsl(var(--color-execution))]" />}
                        {rollbackMode ? "Emergency Rollback" : <Explainable technical="Deploy to Production" human="Go Live" />}
                    </DialogTitle>
                    <DialogDescription>
                        {rollbackMode ? 
                            "Revert the production environment to a previous stable state." : 
                            <Explainable technical="Push a release artifact to a live server node." human="Update your live website with the latest changes." />
                        }
                    </DialogDescription>
                </DialogHeader>

                <div className="py-6">
                    {step === 1 && (
                        <div className="space-y-6">
                            {rollbackMode ? (
                                <div className="space-y-4 animate-in fade-in slide-in-from-right-4">
                                    <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-start gap-3">
                                        <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                                        <div className="space-y-1">
                                            <h4 className="text-sm font-bold text-red-400">Confirm Reversion</h4>
                                            <p className="text-xs text-red-300/70">This will immediately replace the current production build with the selected previous version. This action is logged.</p>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs text-neutral-500 uppercase font-bold">Select Restore Point</label>
                                        <Select defaultValue={releases[1]?.id}>
                                            <SelectTrigger className="bg-neutral-900 border-white/10">
                                                <SelectValue placeholder="Select version..." />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {releases.slice(1).map(r => (
                                                    <SelectItem key={r.id} value={r.id}>
                                                        <div className="flex items-center justify-between w-full min-w-[200px]">
                                                            <span className="font-mono text-xs">{r.version}</span>
                                                            <span className="text-neutral-500 text-[10px]">Deployed 2h ago</span>
                                                        </div>
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs text-neutral-500 uppercase font-bold">Reason for Rollback</label>
                                        <input 
                                            className="w-full bg-black/40 border border-white/10 rounded px-3 py-2 text-sm text-white focus:border-red-500"
                                            placeholder="e.g. Critical bug in payment flow"
                                        />
                                    </div>
                                </div>
                            ) : isSmartShip ? (
                                <Layer level="intent" className="space-y-4 p-4 rounded-lg bg-[hsl(var(--color-execution))]/5 border-[hsl(var(--color-execution))]/20">
                                    <div className="flex items-start gap-3">
                                        <div className="p-1 rounded-full bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] mt-0.5">
                                            <CheckCircle2 className="w-3.5 h-3.5" />
                                        </div>
                                        <div>
                                            <OrientingText className="text-[hsl(var(--color-execution))] mb-1">ATOMIC DEPLOYMENT READY</OrientingText>
                                            <p className="text-[11px] text-neutral-400 leading-relaxed max-w-[90%]">
                                                The system will verify the build integrity before swapping traffic. Zero-downtime guaranteed. Automatic rollback on failure.
                                            </p>
                                        </div>
                                    </div>

                                    {/* Zip Upload Area */}
                                    <div className="space-y-2 pt-2">
                                        <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold flex items-center gap-2">
                                            <Tag className="w-3 h-3" /> <Explainable technical="UI BUNDLE (ZIP)" human="Upload Theme" />
                                        </label>
                                        <div className="relative group">
                                            <input 
                                                type="file"
                                                accept=".zip"
                                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                                                onChange={(e) => setConfig({...config, file: e.target.files[0]})}
                                            />
                                            <div className="w-full bg-black/40 border border-dashed border-white/20 rounded-lg px-4 py-6 text-center transition-colors group-hover:border-[hsl(var(--color-execution))] group-hover:bg-[hsl(var(--color-execution))]/5">
                                                {config.file ? (
                                                    <div className="flex items-center justify-center gap-2 text-[hsl(var(--color-execution))]">
                                                        <CheckCircle2 className="w-4 h-4" />
                                                        <span className="text-sm font-bold">{config.file.name}</span>
                                                    </div>
                                                ) : (
                                                    <div className="space-y-1">
                                                        <p className="text-sm text-neutral-300 font-medium">Drag & Drop or Click to Upload</p>
                                                        <p className="text-[10px] text-neutral-500">Supports .zip bundles containing dist/ and manifest.json</p>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>

                                    <div className="space-y-2 pt-2">
                                        <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold flex items-center gap-2">
                                            <Tag className="w-3 h-3" /> <Explainable technical="RELEASE MESSAGE" human="CHANGE LOG" />
                                        </label>
                                        <input 
                                            className="w-full bg-black/40 border border-white/10 rounded px-3 py-2.5 text-sm text-white focus:outline-none focus:border-[hsl(var(--color-execution))] transition-colors placeholder:text-neutral-600"
                                            placeholder="What changed? (e.g. 'Updated homepage layout')"
                                            value={config.message}
                                            onChange={(e) => setConfig({...config, message: e.target.value})}
                                        />
                                    </div>

                                    {/* Install to Desktop Option */}
                                    <div className="flex items-center gap-3 p-3 bg-white/5 rounded border border-white/10">
                                        <input 
                                            type="checkbox" 
                                            id="install-desktop"
                                            className="w-4 h-4 rounded border-white/20 bg-black/50 accent-[hsl(var(--color-execution))]"
                                            checked={config.installToDesktop}
                                            onChange={(e) => setConfig({...config, installToDesktop: e.target.checked})}
                                        />
                                        <label htmlFor="install-desktop" className="text-xs text-neutral-300 cursor-pointer select-none flex-1">
                                            Install as App on Desktop
                                            <p className="text-[10px] text-neutral-500">Creates a shortcut in the system menu for all users.</p>
                                        </label>
                                    </div>

                                    {/* Advanced Deployment Strategies Tabs */}
                                    <Tabs value={activeTab} onValueChange={setActiveTab} className="pt-4 border-t border-white/5">
                                        <TabsList className="w-full bg-black/40">
                                            <TabsTrigger value="strategy" className="flex-1 text-[10px]">Strategy</TabsTrigger>
                                            <TabsTrigger value="health" className="flex-1 text-[10px]">Health & Guards</TabsTrigger>
                                            <TabsTrigger value="history" className="flex-1 text-[10px]">History</TabsTrigger>
                                        </TabsList>

                                        <TabsContent value="strategy" className="space-y-3 pt-2">
                                            <div className="grid grid-cols-3 gap-2">
                                                {[
                                                    { id: 'standard', label: 'Standard', desc: 'Direct Replace' },
                                                    { id: 'blue_green', label: 'Blue/Green', desc: 'Zero Downtime' },
                                                    { id: 'canary', label: 'Canary', desc: 'Gradual Rollout' }
                                                ].map(s => (
                                                    <button
                                                        key={s.id}
                                                        onClick={() => setConfig({...config, strategy: s.id})}
                                                        className={`p-2 rounded border text-left transition-all ${config.strategy === s.id ? 'bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))]' : 'bg-black/20 border-white/10 hover:bg-white/5'}`}
                                                    >
                                                        <div className={`text-xs font-bold ${config.strategy === s.id ? 'text-[hsl(var(--color-execution))]' : 'text-white'}`}>{s.label}</div>
                                                        <div className="text-[9px] text-neutral-500">{s.desc}</div>
                                                    </button>
                                                ))}
                                            </div>

                                            {config.strategy === 'canary' && (
                                                <div className="space-y-2 pt-2 animate-in fade-in slide-in-from-top-2">
                                                    <div className="flex justify-between text-[10px]">
                                                        <span className="text-neutral-400">Traffic Split</span>
                                                        <span className="text-[hsl(var(--color-execution))] font-mono">{config.canaryPercent}%</span>
                                                    </div>
                                                    <Slider 
                                                        defaultValue={[10]} 
                                                        max={50} 
                                                        step={5}
                                                        onValueChange={(v) => setConfig({...config, canaryPercent: v[0]})}
                                                    />
                                                </div>
                                            )}
                                        </TabsContent>

                                        <TabsContent value="health" className="space-y-4 pt-2">
                                            <div className="space-y-2">
                                                <label className="text-[10px] text-neutral-500 uppercase font-bold flex items-center gap-2">
                                                    <Activity className="w-3 h-3" /> Health Check Endpoint
                                                </label>
                                                <Input 
                                                    value={config.healthCheckPath}
                                                    onChange={(e) => setConfig({...config, healthCheckPath: e.target.value})}
                                                    className="bg-black/20 border-white/10 h-8 text-xs"
                                                    placeholder="/health"
                                                />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] text-neutral-500 uppercase font-bold flex items-center gap-2">
                                                    <ShieldAlert className="w-3 h-3" /> Auto-Rollback Trigger (Error %)
                                                </label>
                                                <div className="flex items-center gap-3">
                                                    <Slider 
                                                        value={[config.rollbackErrorRate]} 
                                                        max={20} 
                                                        step={1}
                                                        onValueChange={(v) => setConfig({...config, rollbackErrorRate: v[0]})}
                                                        className="flex-1"
                                                    />
                                                    <span className="text-xs font-mono w-8 text-right">{config.rollbackErrorRate}%</span>
                                                    </div>
                                                    </div>
                                                    </TabsContent>

                                                    <TabsContent value="history" className="space-y-4 pt-2 h-[200px]">
                                                    <DeploymentHistoryView />
                                                    </TabsContent>
                                                    </Tabs>
                                                    </Layer>
                                                    ) : (
                                /* Standard Release Selection */
                                <div className="space-y-2">
                                    <label className="text-xs text-neutral-500 uppercase tracking-wider font-bold flex items-center gap-2">
                                        <Tag className="w-3 h-3" /> <Explainable technical="Select Artifact" human="Choose Version" />
                                    </label>
                                    <Select 
                                        value={config.releaseId} 
                                        onValueChange={(v) => setConfig({...config, releaseId: v})}
                                    >
                                        <SelectTrigger className="bg-neutral-900 border-white/10">
                                            <SelectValue placeholder="Choose a release version..." />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {releases.map(r => (
                                                <SelectItem key={r.id} value={r.id}>
                                                    <div className="flex items-center gap-2">
                                                        <span className="font-mono text-xs">{r.version}</span>
                                                        <span className="text-neutral-500 text-[10px]">• {r.status}</span>
                                                    </div>
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            )}

                            {/* Node Selection */}
                            <div className="space-y-2">
                                <label className="text-xs text-neutral-500 uppercase tracking-wider font-bold flex items-center gap-2">
                                    <Server className="w-3 h-3" /> <Explainable technical="Target Node" human="Destination Server" />
                                </label>
                                <Select 
                                    value={config.nodeId} 
                                    onValueChange={(v) => setConfig({...config, nodeId: v})}
                                >
                                    <SelectTrigger className="bg-neutral-900 border-white/10">
                                        <SelectValue placeholder="Select target server..." />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {nodes.map(n => (
                                            <SelectItem key={n.id} value={n.id}>
                                                <div className="flex items-center gap-2">
                                                    <div className={`w-2 h-2 rounded-full ${n.status === 'connected' ? 'bg-green-500' : 'bg-red-500'}`} />
                                                    <span>{n.name}</span>
                                                    <span className="font-mono text-xs opacity-50">({n.ip_address})</span>
                                                </div>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    )}

                    {step === 2 && (
                        <div className="flex flex-col h-[300px]">
                            {/* Build Process Visualization */}
                            <div className="flex-1 bg-black/50 rounded-lg border border-white/10 p-4 font-mono text-[10px] text-neutral-400 overflow-y-auto mb-4 space-y-1">
                                <div className="text-[hsl(var(--color-execution))]">$ init_sequence --target=prod</div>
                                <div>[info] Resolving dependencies...</div>
                                <div className="text-neutral-500">→ found 42 modules</div>
                                <div>[info] Compiling assets...</div>
                                <div className="pl-2 text-green-500">✓ src/pages/index.js (4kb)</div>
                                <div className="pl-2 text-green-500">✓ src/components/Header.js (2kb)</div>
                                <div>[info] Optimizing bundle...</div>
                                <div className="text-yellow-500">⚠ Tree-shaking removed 12 unused exports</div>
                                <div>[net] Handshaking with Node {config.nodeId.slice(0,8)}...</div>
                                <div className="text-[hsl(var(--color-execution))]">[success] Uploading artifacts (100%)</div>
                                <div className="animate-pulse">_ Verifying integrity...</div>
                            </div>

                            <div className="flex items-center gap-4">
                                <div className="relative">
                                    <div className="w-10 h-10 border-2 border-[hsl(var(--color-execution))] border-t-transparent rounded-full animate-spin" />
                                </div>
                                <div className="flex-1">
                                    <div className="flex justify-between text-xs mb-1">
                                        <span className="text-white font-bold">Building & Deploying</span>
                                        <span className="text-[hsl(var(--color-execution))]">78%</span>
                                    </div>
                                    <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                                        <div className="h-full w-[78%] bg-[hsl(var(--color-execution))]" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {step === 3 && (
                        <ProcessCompletion 
                            title="Deployment Complete"
                            subtitle={`Release ${isSmartShip ? 'auto-generated' : 'v' + config.releaseId} is now live.`}
                            artifacts={[
                                { name: "build_log.txt", type: "Log", size: "12kb" },
                                { name: "release_manifest.json", type: "JSON", size: "4kb" }
                            ]}
                            actions={[
                                { label: "View Live Site", icon: Globe, onClick: () => window.open(`https://${domains.find(d => d.id === config.domainId)?.domain_name || 'example.com'}`, '_blank'), primary: true },
                                { label: "Deployment Logs", icon: Tag, onClick: () => console.log('View logs') }
                            ]}
                            onClose={reset}
                        />
                    )}
                </div>

                <DialogFooter>
                    {step === 1 && (
                        <>
                            <Button variant="ghost" onClick={reset}>
                                <Explainable technical="Cancel" human="Cancel" />
                            </Button>
                            {rollbackMode ? (
                                <Button 
                                    onClick={handleRollback} 
                                    className="bg-red-500 text-white hover:bg-red-600 font-bold tracking-wide"
                                >
                                    <History className="w-4 h-4 mr-2" /> 
                                    Confirm Rollback
                                </Button>
                            ) : (
                                <div className="flex gap-2 w-full">
                                    <Button 
                                        variant="outline"
                                        onClick={() => setRollbackMode(true)}
                                        className="border-red-500/30 text-red-500 hover:bg-red-500/10"
                                    >
                                        <History className="w-4 h-4" />
                                    </Button>
                                    <Button 
                                        onClick={handleDeploy} 
                                        className="flex-1 bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 font-bold tracking-wide"
                                        disabled={(!isSmartShip && !config.releaseId) || (isSmartShip && !config.file && !config.message) || !config.nodeId}
                                    >
                                        <Rocket className="w-4 h-4 mr-2" /> 
                                        {isSmartShip ? <Explainable technical="SHIP BUNDLE" human="Deploy Zip" /> : <Explainable technical="DEPLOY" human="Start Publishing" />}
                                    </Button>
                                </div>
                            )}
                        </>
                    )}
                    {step === 3 && (
                        <Button onClick={reset} variant="outline" className="w-full">
                            <Explainable technical="Close" human="Done" />
                        </Button>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}