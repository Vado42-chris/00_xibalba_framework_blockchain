
import React, { useState } from 'react';
import { 
    Layout, Type, Image as ImageIcon, Box, Grid, List, 
    MousePointer2, CreditCard, Mail, Bell, Shield,
    Cpu, Activity, Database, Globe, Zap, Settings,
    FileText, Calendar, User, Search
} from 'lucide-react';

export const COMPONENT_LIBRARY = [
    {
        category: "Base Elements",
        items: [
            { id: 'btn-1', type: 'button', label: 'Action Button', icon: MousePointer2, html: '<button class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors font-medium">Click Me</button>' },
            { id: 'txt-1', type: 'text', label: 'Heading', icon: Type, html: '<h2 class="text-2xl font-bold mb-2 text-white">Section Title</h2>' },
            { id: 'txt-2', type: 'text', label: 'Paragraph', icon: Type, html: '<p class="text-neutral-400 leading-relaxed">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore.</p>' },
            { id: 'img-1', type: 'image', label: 'Image Card', icon: ImageIcon, html: '<div class="rounded-lg overflow-hidden border border-white/10 bg-neutral-900"><div class="aspect-video bg-neutral-800 animate-pulse"></div><div class="p-4"><div class="h-4 bg-neutral-800 rounded w-3/4 mb-2"></div><div class="h-3 bg-neutral-800 rounded w-1/2"></div></div></div>' },
            { id: 'card-1', type: 'card', label: 'Feature Card', icon: Box, html: '<div class="p-6 bg-neutral-900 border border-white/10 rounded-xl hover:border-blue-500/50 transition-colors group"><div class="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-500/20 text-blue-400"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg></div><h3 class="text-lg font-semibold text-white mb-2">Feature Name</h3><p class="text-sm text-neutral-400">Description of the feature goes here.</p></div>' },
        ]
    },
    {
        category: "Structure",
        items: [
            { id: 'layout-1', type: 'layout', label: '2 Column Grid', icon: Grid, html: '<div class="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 border border-dashed border-white/10 rounded bg-white/5"><div class="min-h-[100px] flex items-center justify-center text-neutral-500 bg-black/20 rounded border border-white/5">Col 1</div><div class="min-h-[100px] flex items-center justify-center text-neutral-500 bg-black/20 rounded border border-white/5">Col 2</div></div>' },
            { id: 'layout-2', type: 'layout', label: '3 Column Grid', icon: Grid, html: '<div class="grid grid-cols-1 md:grid-cols-3 gap-6 p-4 border border-dashed border-white/10 rounded bg-white/5"><div class="min-h-[100px] bg-black/20 rounded border border-white/5"></div><div class="min-h-[100px] bg-black/20 rounded border border-white/5"></div><div class="min-h-[100px] bg-black/20 rounded border border-white/5"></div></div>' },
            { id: 'hero-1', type: 'section', label: 'Hero Section', icon: Layout, html: '<div class="py-20 text-center px-4"><h1 class="text-5xl font-bold mb-6 bg-gradient-to-r from-white to-neutral-500 bg-clip-text text-transparent">Build Something Amazing</h1><p class="text-xl text-neutral-400 max-w-2xl mx-auto mb-8">Deploy full-stack applications in seconds with our advanced infrastructure.</p><div class="flex gap-4 justify-center"><button class="px-6 py-3 bg-white text-black font-bold rounded-full hover:bg-neutral-200">Get Started</button><button class="px-6 py-3 border border-white/20 rounded-full hover:bg-white/5">Documentation</button></div></div>' },
        ]
    },
    {
        category: "Forms & Data",
        items: [
            { id: 'input-1', type: 'input', label: 'Email Input', icon: Mail, html: '<div class="space-y-2"><label class="text-xs font-bold text-neutral-400 uppercase tracking-wide">Email Address</label><input type="email" placeholder="you@example.com" class="w-full bg-black border border-white/20 rounded px-4 py-2 text-white focus:border-blue-500 outline-none transition-colors" /></div>' },
            { id: 'list-1', type: 'list', label: 'Data List', icon: List, html: '<div class="divide-y divide-white/10 border border-white/10 rounded-lg overflow-hidden"><div class="p-4 bg-neutral-900 flex justify-between items-center"><span class="font-medium">Item 1</span><span class="text-sm text-neutral-500">Active</span></div><div class="p-4 bg-neutral-900 flex justify-between items-center"><span class="font-medium">Item 2</span><span class="text-sm text-neutral-500">Pending</span></div><div class="p-4 bg-neutral-900 flex justify-between items-center"><span class="font-medium">Item 3</span><span class="text-sm text-neutral-500">Offline</span></div></div>' },
        ]
    },
    {
        category: "Integrations",
        items: [
            { id: 'stripe-1', type: 'integration', label: 'Stripe Card', icon: CreditCard, html: '<div class="p-6 bg-[#1a1f36] rounded-xl border border-[#3c4257] shadow-lg"><div class="flex justify-between items-center mb-6"><h3 class="font-medium text-white">Payment Method</h3><span class="px-2 py-1 bg-[#2e3548] text-xs rounded text-[#aab7c4]">Test Mode</span></div><div class="space-y-4"><div class="p-3 bg-[#0a2540] border border-[#3c4257] rounded text-white font-mono text-sm flex gap-2"><svg width="20" height="20" viewBox="0 0 24 24" fill="white"><rect x="2" y="5" width="20" height="14" rx="2" /></svg> **** **** **** 4242</div><button class="w-full py-2 bg-[#635bff] hover:bg-[#7771fc] text-white font-medium rounded transition-colors">Pay $49.00</button></div></div>' },
            { id: 'chart-1', type: 'chart', label: 'Analytics Chart', icon: Activity, html: '<div class="p-6 bg-neutral-900 border border-white/10 rounded-xl"><div class="flex justify-between mb-8"><div class="space-y-1"><h3 class="text-sm font-medium text-neutral-400">Total Revenue</h3><div class="text-2xl font-bold text-white">$42,069.00</div></div><select class="bg-black border border-white/20 rounded px-2 text-xs h-8"><option>Last 30 Days</option></select></div><div class="h-32 flex items-end gap-2"><div class="flex-1 bg-blue-500/20 h-1/2 rounded-t hover:bg-blue-500/40 transition-colors"></div><div class="flex-1 bg-blue-500/20 h-3/4 rounded-t hover:bg-blue-500/40 transition-colors"></div><div class="flex-1 bg-blue-500/20 h-2/3 rounded-t hover:bg-blue-500/40 transition-colors"></div><div class="flex-1 bg-blue-500/50 h-full rounded-t hover:bg-blue-500/70 transition-colors border-t-2 border-blue-400"></div><div class="flex-1 bg-blue-500/20 h-4/5 rounded-t hover:bg-blue-500/40 transition-colors"></div></div></div>' },
        ]
    }
];
