import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, ArrowRight, Loader2, X, Command, Check, XCircle, FileDiff } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import { OrientingText } from '@/components/ui/design-system/System';
import { DeltaDiff } from '@/components/ui/design-system/Infographics';

export default function InlineAIPrompt({ isOpen, onClose, onApply, currentCode, language = 'javascript' }) {
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [generatedCode, setGeneratedCode] = useState(null);
    const inputRef = useRef(null);

    useEffect(() => {
        if (isOpen && inputRef.current && !generatedCode) {
            inputRef.current.focus();
        }
    }, [isOpen, generatedCode]);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                if (generatedCode) {
                    setGeneratedCode(null); // Go back to prompt
                } else {
                    onClose();
                }
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [onClose, generatedCode]);

    const handleSubmit = async () => {
        if (!input.trim()) return;
        setIsLoading(true);

        try {
            const prompt = `
You are an expert coding assistant. 
Task: ${input}
Current Code:
\`\`\`${language}
${currentCode}
\`\`\`
Return only the modified code block without markdown fencing. Do not explain.
            `;

            const response = await base44.integrations.Core.InvokeLLM({
                prompt: prompt,
                add_context_from_internet: false
            });

            let newCode = response;
            if (typeof response === 'object' && response.text) newCode = response.text;
            
            // Cleanup generic markdown if returned
            newCode = newCode.replace(/^```[a-z]*\n/i, '').replace(/\n```$/, '');
            
            setGeneratedCode(newCode);
        } catch (error) {
            console.error(error);
            toast.error("Failed to generate code");
        } finally {
            setIsLoading(false);
        }
    };

    const handleAccept = () => {
        if (generatedCode) {
            onApply(generatedCode);
            onClose();
            setInput('');
            setGeneratedCode(null);
            toast.success("Code applied successfully");
        }
    };

    const handleReject = () => {
        setGeneratedCode(null);
        setTimeout(() => inputRef.current?.focus(), 0);
    };

    if (!isOpen) return null;

    return (
        <>
            {/* Backdrop to close on click outside */}
            <div className="fixed inset-0 bg-black/20 z-40" onClick={onClose} />
            
            <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[700px] z-50 animate-in fade-in zoom-in-95 duration-200">
                <div className="bg-neutral-900/95 backdrop-blur-xl border border-[hsl(var(--color-intent))] rounded-lg shadow-2xl overflow-hidden flex flex-col">
                
                {/* Prompt Input */}
                {!generatedCode && (
                    <div className="p-1 pl-4 pr-1 flex items-center gap-3 border-b border-white/5">
                        <Sparkles className="w-4 h-4 text-[hsl(var(--color-intent))] animate-pulse" />
                        <input 
                            ref={inputRef}
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleSubmit();
                                }
                            }}
                            placeholder="Edit logic, generate code, or fix bugs..."
                            disabled={isLoading}
                            className="flex-1 bg-transparent border-none outline-none h-12 text-sm text-white placeholder-neutral-500 font-medium disabled:opacity-50"
                        />
                        <div className="flex items-center gap-2">
                            <div className="flex items-center gap-1 px-2 py-1 bg-neutral-800 rounded text-[10px] text-neutral-400 font-mono border border-white/5">
                                <Command className="w-3 h-3" />
                                <span>K</span>
                            </div>
                        </div>
                        
                        {/* Quick Presets */}
                        <div className="flex gap-2 p-2 bg-black/20 border-t border-white/5 overflow-x-auto scrollbar-none">
                            {['Fix Bugs', 'Add Types', 'Refactor', 'Optimize', 'Add Comments'].map(preset => (
                                <button
                                    key={preset}
                                    onClick={() => setInput(prev => `${prev ? prev + ' ' : ''}${preset}`)}
                                    className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-[10px] text-neutral-400 hover:text-white transition-colors whitespace-nowrap border border-white/5"
                                >
                                    {preset}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {/* Diff Review Mode */}
                {generatedCode && (
                    <div className="flex flex-col">
                        <div className="p-3 border-b border-white/10 bg-black/20 flex justify-between items-center">
                            <div className="flex items-center gap-2 text-[hsl(var(--color-intent))]">
                                <FileDiff className="w-4 h-4" />
                                <span className="text-xs font-bold tracking-wide">REVIEW CHANGES</span>
                            </div>
                            <div className="flex gap-2">
                                <Button size="sm" variant="ghost" onClick={handleReject} className="h-7 text-xs hover:bg-red-500/10 hover:text-red-500">
                                    <XCircle className="w-3 h-3 mr-2" /> Reject
                                </Button>
                                <Button size="sm" onClick={handleAccept} className="h-7 text-xs bg-green-600 hover:bg-green-500 text-white">
                                    <Check className="w-3 h-3 mr-2" /> Accept Changes
                                </Button>
                            </div>
                        </div>
                        <div className="max-h-[500px] overflow-auto p-4 bg-[#0d0d0d] font-mono text-xs">
                           <DeltaDiff 
                                original={currentCode}
                                modified={generatedCode}
                                className="w-full"
                           />
                        </div>
                    </div>
                )}

                {/* Status Bar */}
                {isLoading && (
                    <div className="p-2 bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))] text-xs flex items-center justify-center gap-2 font-mono">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        Generating changes...
                    </div>
                )}
                {!isLoading && !generatedCode && (
                    <div className="p-2 bg-neutral-950/50 flex justify-between items-center text-[10px] text-neutral-500 font-mono px-4">
                        <span>Scope: Current File</span>
                        <div className="flex gap-2">
                            <span>Esc to cancel</span>
                            <span className="text-white">Enter to generate</span>
                        </div>
                    </div>
                )}
            </div>
        </div>
        </>
    );
}