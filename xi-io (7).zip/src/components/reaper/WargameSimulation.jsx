import React, { useState, useEffect, useRef } from 'react';
import { 
    Users, MessageSquare, Play, Pause, FastForward, 
    Brain, Shield, Paintbrush, DollarSign, Target,
    ArrowRight, CheckCircle2, Loader2, GitMerge
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, AtomicParagraph 
} from '@/components/ui/design-system/SystemDesign';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { base44 } from '@/api/base44Client';

const PERSONAS = [
    { id: 'design', name: 'Design Lead', role: 'UX/UI', icon: Paintbrush, color: 'text-[hsl(var(--color-intent))]' },
    { id: 'tech', name: 'System Architect', role: 'Engineering', icon: Brain, color: 'text-[hsl(var(--color-system))]' },
    { id: 'product', name: 'Product Owner', role: 'Strategy', icon: Target, color: 'text-[hsl(var(--color-execution))]' },
    { id: 'security', name: 'Security Chief', role: 'Risk', icon: Shield, color: 'text-[hsl(var(--color-warning))]' },
    { id: 'stakeholder', name: 'Business Exec', role: 'ROI', icon: DollarSign, color: 'text-[hsl(var(--color-settled))]' },
];

export const WargameSimulation = ({ localConnected, onSave, initialTopic, scenario = 'debate' }) => {
    const [topic, setTopic] = useState(initialTopic || "");
    const [isRunning, setIsRunning] = useState(false);
    const [messages, setMessages] = useState([]);
    const [consensus, setConsensus] = useState(null);
    const [isThinking, setIsThinking] = useState(false);
    const scrollRef = useRef(null);

    const fetchAgentResponse = async (persona, contextMessages) => {
        try {
            const contextText = contextMessages.map(m => `${m.speaker.name}: ${m.text}`).join('\n');
            
            let systemPrompt = "";
            if (scenario === 'audit') {
                systemPrompt = `
                    Roleplay as ${persona.name}, the ${persona.role}.
                    Scenario: SECURITY AUDIT & THREAT ANALYSIS
                    Objective: Analyze the provided system logs/context for vulnerabilities.
                    Topic/Logs: "${topic}"
                    
                    Context of discussion:
                    ${contextText}

                    Provide a technical, risk-focused assessment (1 sentence). Identify specific vectors or mitigation strategies.
                `;
            } else {
                systemPrompt = `
                    Roleplay as ${persona.name}, the ${persona.role}.
                    Topic: "${topic}"
                    
                    Context of discussion:
                    ${contextText}
                    
                    Provide a sharp, concise (1 sentence) contribution to the debate reflecting your specific expertise and concerns.
                    Do not be polite. Be constructive but critical.
                `;
            }

            const res = await base44.integrations.Core.InvokeLLM({ prompt: systemPrompt });
            return res || "Thinking...";
        } catch (e) {
            console.error(e);
            return `From a ${persona.role} perspective, we need to analyze this further.`;
        }
    };

    useEffect(() => {
        let mounted = true;

        const runTurn = async () => {
            if (!isRunning || isThinking || messages.length > 8) {
                if (isRunning && messages.length > 8) {
                    setIsRunning(false);
                    reduceConsensus();
                }
                return;
            }

            setIsThinking(true);
            const speaker = PERSONAS[Math.floor(Math.random() * PERSONAS.length)];
            
            // Artificial delay for realism if LLM is too fast, or just to show thinking
            await new Promise(r => setTimeout(r, 1000));
            
            if (!mounted) return;

            // Yin-Yang Intelligence Routing
            let text;
            if (localConnected) {
                try {
                    // Try Local Ollama (The "Yin")
                    const res = await fetch('http://localhost:11434/api/generate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            model: "llama3", // Default to a common model
                            prompt: `You are ${speaker.name} (${speaker.role}). Context: ${topic}. Discussion: ${JSON.stringify(messages.slice(-3))}. Give a 1 sentence opinion.`,
                            stream: false
                        })
                    });
                    const data = await res.json();
                    text = data.response;
                } catch (e) {
                    // Fallback to Cloud (The "Yang")
                    text = await fetchAgentResponse(speaker, messages);
                }
            } else {
                // Cloud Only
                text = await fetchAgentResponse(speaker, messages);
            }
            
            if (!mounted) return;

            setMessages(prev => [...prev, {
                id: Date.now(),
                speaker,
                text,
                timestamp: new Date().toLocaleTimeString()
            }]);
            setIsThinking(false);
        };

        if (isRunning) {
            runTurn();
        }

        return () => { mounted = false; };
    }, [isRunning, messages, isThinking]);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isThinking]);

    const reduceConsensus = async () => {
        setIsThinking(true);
        try {
            const contextText = messages.map(m => `${m.speaker.name}: ${m.text}`).join('\n');
            const prompt = `
                Summarize the following technical debate about "${topic}" into a consensus statement.
                
                Debate:
                ${contextText}
                
                Output JSON format:
                {
                    "summary": "1-2 sentence summary",
                    "actionItems": ["action 1", "action 2", "action 3"],
                    "confidence": 85
                }
            `;
            
            const res = await base44.integrations.Core.InvokeLLM({ 
                prompt,
                response_json_schema: {
                    type: "object",
                    properties: {
                        summary: { type: "string" },
                        actionItems: { type: "array", items: { type: "string" } },
                        confidence: { type: "number" }
                    }
                }
            });

            setConsensus(res);
        } catch (e) {
            setConsensus({
                summary: "Consensus reached on hybrid architecture with local failover.",
                actionItems: ["Deploy Edge Nodes", "Update Config", "Verify Security"],
                confidence: 88
            });
        }
        setIsThinking(false);
    };

    const handleStart = () => {
        if (!topic) return;
        setMessages([]);
        setConsensus(null);
        setIsRunning(true);
        setMessages([{
            id: 'init',
            speaker: { name: 'System', role: 'Moderator', color: 'text-white', icon: Users },
            text: `WARGAME INITIATED (${scenario.toUpperCase()} MODE): Analyzing "${topic}"...`,
            timestamp: new Date().toLocaleTimeString()
        }]);
    };

    return (
        <div className="flex flex-col h-full bg-neutral-950">
            {/* Header */}
            <div className="p-6 border-b border-white/10 bg-neutral-900/50 flex justify-between items-center shrink-0">
                <div>
                    <OrientingText className="mb-1 text-[hsl(var(--color-intent))]">SIMULATION ENGINE</OrientingText>
                    <IntentText className="text-xl font-light">
                        Multi-Agent Wargame
                        {localConnected && <Badge variant="outline" className="ml-2 border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))] text-[10px]">LOCAL GPU ACTIVE</Badge>}
                    </IntentText>
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex -space-x-2 mr-4">
                        {PERSONAS.map(p => (
                            <div key={p.id} className="w-8 h-8 rounded-full bg-neutral-800 border border-neutral-900 flex items-center justify-center" title={p.name}>
                                <p.icon className={cn("w-4 h-4", p.color)} />
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Chat / Simulation Area */}
            <div className="flex-1 overflow-hidden relative flex flex-col">
                <div 
                    ref={scrollRef}
                    className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin scrollbar-thumb-white/10"
                >
                    {messages.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center opacity-30">
                            <Users className="w-16 h-16 mb-4" />
                            <OrientingText>Awaiting Wargame Parameters</OrientingText>
                        </div>
                    ) : (
                        messages.map(msg => (
                            <div key={msg.id} className="flex gap-4 max-w-3xl animate-in slide-in-from-left-4 duration-300">
                                <div className={cn("w-10 h-10 rounded-full flex items-center justify-center shrink-0 border border-white/5 bg-neutral-900", msg.speaker.color)}>
                                    {msg.speaker.icon ? <msg.speaker.icon className="w-5 h-5" /> : <Users className="w-5 h-5" />}
                                </div>
                                <div className="space-y-1">
                                    <div className="flex items-center gap-2">
                                        <span className={cn("text-xs font-bold tracking-wide", msg.speaker.color)}>{msg.speaker.name}</span>
                                        <SemanticDot variant="orientation" className="w-1 h-1" />
                                        <span className="text-[10px] text-neutral-500 uppercase tracking-wider">{msg.speaker.role}</span>
                                        <span className="text-[10px] text-neutral-600 font-mono ml-auto opacity-50">{msg.timestamp}</span>
                                    </div>
                                    <Layer level="state" className="text-sm text-neutral-300 p-3 rounded-tr-xl rounded-b-xl border-white/5">
                                        <AtomicParagraph>
                                            {msg.text}
                                        </AtomicParagraph>
                                    </Layer>
                                </div>
                            </div>
                        ))
                    )}
                    {isThinking && (
                        <div className="flex items-center gap-2 text-[hsl(var(--color-intent))] text-xs animate-pulse pl-14">
                            <Loader2 className="w-3 h-3 animate-spin" /> Agents thinking...
                        </div>
                    )}
                </div>

                {/* Consensus Overlay (The "1 Body Solution") */}
                {consensus && (
                    <div className="absolute bottom-0 left-0 right-0 bg-neutral-900/95 backdrop-blur-xl border-t border-[hsl(var(--color-intent))]/30 p-6 animate-in slide-in-from-bottom-full duration-500 shadow-2xl z-20">
                        <div className="max-w-4xl mx-auto flex gap-6">
                            <div className="flex flex-col items-center justify-center text-[hsl(var(--color-intent))] shrink-0">
                                <GitMerge className="w-12 h-12 mb-2" />
                                <StateText className="font-mono text-xl">{consensus.confidence}%</StateText>
                                <OrientingText className="text-[9px]">CONFIDENCE</OrientingText>
                            </div>
                            <div className="flex-1 space-y-4">
                                <div>
                                    <OrientingText className="text-[hsl(var(--color-intent))] mb-1">1-BODY CONSENSUS REACHED</OrientingText>
                                    <p className="text-white text-sm leading-relaxed">{consensus.summary}</p>
                                </div>
                                <div className="grid grid-cols-2 gap-2">
                                    {consensus.actionItems.map((item, i) => (
                                        <div key={i} className="flex items-center gap-2 text-xs text-neutral-400 bg-black/20 p-2 rounded">
                                            <CheckCircle2 className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                                            {item}
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div className="flex flex-col justify-center gap-2">
                                <Button className="bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white font-bold">
                                    Execute
                                </Button>
                                <Button 
                                    variant="outline" 
                                    className="border-white/10 text-neutral-400"
                                    onClick={() => onSave && onSave(consensus)}
                                >
                                    Save to Dotfile
                                </Button>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Input Area */}
            <div className="p-6 border-t border-white/10 bg-neutral-900 shrink-0 z-30">
                <div className="max-w-4xl mx-auto flex gap-4">
                    <Input 
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder="Define wargame objective (Who, What, Where, When, Why, How)..."
                        className="bg-neutral-950 border-white/10 h-12 text-lg focus:border-[hsl(var(--color-intent))]"
                        onKeyDown={(e) => e.key === 'Enter' && !isRunning && handleStart()}
                    />
                    <Button 
                        size="lg" 
                        onClick={handleStart} 
                        disabled={isRunning || !topic}
                        className={cn("h-12 w-32 font-bold", isRunning ? "bg-[hsl(var(--color-error))]/20 text-[hsl(var(--color-error))]" : "bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white")}
                    >
                        {isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                        {isRunning ? "HALT" : "SIMULATE"}
                    </Button>
                </div>
            </div>
        </div>
    );
};