import React from 'react';
import { cn } from "@/lib/utils";

export default function CodeForge({ code, onChange, vimMode = false }) {
    // Simple line number generation
    const lines = code.split('\n').length;
    const textareaRef = React.useRef(null);
    const lineNumbersRef = React.useRef(null);

    const handleScroll = (e) => {
        if (lineNumbersRef.current) {
            lineNumbersRef.current.scrollTop = e.target.scrollTop;
        }
    };

    const handleKeyDown = (e) => {
        const textarea = e.target;
        const { selectionStart, selectionEnd, value } = textarea;

        // Tab Handling (Indent / Unindent)
        if (e.key === 'Tab') {
            e.preventDefault();
            
            if (e.shiftKey) {
                // Unindent (Simple 2 space removal at start of line)
                const lineStart = value.lastIndexOf('\n', selectionStart - 1) + 1;
                const lineEnd = value.indexOf('\n', selectionEnd);
                const currentLine = value.substring(lineStart, lineEnd === -1 ? value.length : lineEnd);
                
                if (currentLine.startsWith('  ')) {
                    const newValue = value.substring(0, lineStart) + currentLine.substring(2) + value.substring(lineEnd === -1 ? value.length : lineEnd);
                    onChange(newValue);
                    setTimeout(() => {
                        textarea.selectionStart = selectionStart - 2;
                        textarea.selectionEnd = selectionEnd - 2;
                    }, 0);
                }
            } else {
                // Indent (2 spaces)
                const newValue = value.substring(0, selectionStart) + '  ' + value.substring(selectionEnd);
                onChange(newValue);
                setTimeout(() => {
                    textarea.selectionStart = textarea.selectionEnd = selectionStart + 2;
                }, 0);
            }
        }
        
        // Enter Handling (Auto-indent)
        if (e.key === 'Enter') {
            e.preventDefault();
            const lineStart = value.lastIndexOf('\n', selectionStart - 1) + 1;
            const currentLine = value.substring(lineStart, selectionStart);
            const match = currentLine.match(/^(\s*)/);
            const indent = match ? match[1] : '';
            
            // Check for opening bracket to add extra indentation
            const extraIndent = currentLine.trim().endsWith('{') || currentLine.trim().endsWith('(') || currentLine.trim().endsWith('[') ? '  ' : '';
            
            const newValue = value.substring(0, selectionStart) + '\n' + indent + extraIndent + value.substring(selectionEnd);
            
            onChange(newValue);
            setTimeout(() => {
                textarea.selectionStart = textarea.selectionEnd = selectionStart + 1 + indent.length + extraIndent.length;
            }, 0);
        }

        // Bracket Closing (Simple)
        const pairs = { '{': '}', '(': ')', '[': ']', '"': '"', "'": "'" };
        if (pairs[e.key]) {
            e.preventDefault();
            const newValue = value.substring(0, selectionStart) + e.key + pairs[e.key] + value.substring(selectionEnd);
            onChange(newValue);
            setTimeout(() => {
                textarea.selectionStart = textarea.selectionEnd = selectionStart + 1;
            }, 0);
        }

        // --- POWER USER SHORTCUTS ---
        
        // Cmd + / (Toggle Comment)
        if ((e.metaKey || e.ctrlKey) && e.key === '/') {
            e.preventDefault();
            const lineStart = value.lastIndexOf('\n', selectionStart - 1) + 1;
            const lineEnd = value.indexOf('\n', selectionEnd);
            const currentLineEnd = lineEnd === -1 ? value.length : lineEnd;
            const currentLine = value.substring(lineStart, currentLineEnd);
            
            let newLine;
            if (currentLine.trim().startsWith('//')) {
                // Uncomment
                newLine = currentLine.replace('// ', '').replace('//', '');
            } else {
                // Comment
                newLine = `// ${currentLine}`;
            }
            
            const newValue = value.substring(0, lineStart) + newLine + value.substring(currentLineEnd);
            onChange(newValue);
            
            // Maintain selection position roughly
            setTimeout(() => {
                textarea.selectionStart = lineStart + newLine.length;
                textarea.selectionEnd = lineStart + newLine.length;
            }, 0);
        }

        // Cmd + D (Duplicate Line)
        if ((e.metaKey || e.ctrlKey) && e.key === 'd') {
            e.preventDefault();
            const lineStart = value.lastIndexOf('\n', selectionStart - 1) + 1;
            const lineEnd = value.indexOf('\n', selectionEnd);
            const currentLineEnd = lineEnd === -1 ? value.length : lineEnd;
            const currentLine = value.substring(lineStart, currentLineEnd);
            
            const newValue = value.substring(0, currentLineEnd) + '\n' + currentLine + value.substring(currentLineEnd);
            onChange(newValue);
            
            setTimeout(() => {
                textarea.selectionStart = currentLineEnd + 1;
                textarea.selectionEnd = currentLineEnd + 1 + currentLine.length;
            }, 0);
        }

        // Alt + Up/Down (Move Line)
        if (e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
            e.preventDefault();
            const lineStart = value.lastIndexOf('\n', selectionStart - 1) + 1;
            const lineEnd = value.indexOf('\n', selectionEnd);
            const currentLineEnd = lineEnd === -1 ? value.length : lineEnd;
            const currentLine = value.substring(lineStart, currentLineEnd);
            
            if (e.key === 'ArrowUp') {
                // Move Up
                if (lineStart === 0) return; // Already at top
                const prevLineStart = value.lastIndexOf('\n', lineStart - 2) + 1;
                const prevLine = value.substring(prevLineStart, lineStart - 1);
                
                const newValue = value.substring(0, prevLineStart) + currentLine + '\n' + prevLine + value.substring(currentLineEnd);
                onChange(newValue);
                setTimeout(() => {
                    textarea.selectionStart = prevLineStart;
                    textarea.selectionEnd = prevLineStart + currentLine.length;
                }, 0);
            } else {
                // Move Down
                if (lineEnd === -1) return; // Already at bottom
                const nextLineEnd = value.indexOf('\n', lineEnd + 1);
                const actualNextLineEnd = nextLineEnd === -1 ? value.length : nextLineEnd;
                const nextLine = value.substring(lineEnd + 1, actualNextLineEnd);
                
                const newValue = value.substring(0, lineStart) + nextLine + '\n' + currentLine + value.substring(actualNextLineEnd);
                onChange(newValue);
                setTimeout(() => {
                    const newStart = lineStart + nextLine.length + 1;
                    textarea.selectionStart = newStart;
                    textarea.selectionEnd = newStart + currentLine.length;
                }, 0);
            }
        }
    };

    return (
        <div className="h-full flex flex-col font-mono text-xs relative">
            <div className="flex-1 relative group bg-[#0d0d0d] overflow-hidden">
                {/* Line Numbers */}
                <div 
                    ref={lineNumbersRef}
                    className="absolute left-0 top-0 bottom-0 w-10 bg-neutral-900/50 border-r border-white/5 text-right pr-2 pt-4 text-neutral-600 select-none font-mono leading-6 overflow-hidden"
                >
                    {Array.from({ length: Math.max(lines, 50) }).map((_, i) => (
                        <div key={i} className={cn(i === 0 && vimMode ? "text-green-500 font-bold" : "")}>{i + 1}</div>
                    ))}
                </div>

                {/* Editor Textarea */}
                <textarea
                    ref={textareaRef}
                    value={code}
                    onChange={(e) => onChange(e.target.value)}
                    onScroll={handleScroll}
                    onKeyDown={handleKeyDown}
                    spellCheck="false"
                    className={cn(
                        "w-full h-full bg-transparent text-neutral-300 resize-none outline-none border-none p-4 pl-12 leading-6 font-mono",
                        "selection:bg-[hsl(var(--color-execution))]/20 scrollbar-none",
                        vimMode && "caret-green-500 caret-block" 
                    )}
                    placeholder="// Write your code here..."
                    style={vimMode ? { caretColor: 'transparent' } : {}} // Hide default caret in vim mode if simulating block (CSS trickery needed, simplified here)
                />
                
                {/* Visual Flair */}
                <div className="absolute top-2 right-2 px-2 py-1 bg-neutral-900 rounded border border-white/5 text-[9px] text-neutral-500 pointer-events-none opacity-50 flex gap-2">
                    <span>JS/HTML</span>
                    {vimMode && <span className="text-green-500 font-bold">NORMAL</span>}
                </div>

                {/* Vim Mode Status Bar */}
                {vimMode && (
                    <div className="absolute bottom-0 left-0 right-0 h-6 bg-green-900/20 border-t border-green-500/30 flex items-center px-2 justify-between text-[10px] text-green-400 font-mono select-none">
                        <div className="flex gap-4">
                            <span className="font-bold">NORMAL</span>
                            <span>master</span>
                        </div>
                        <div className="flex gap-4">
                            <span>utf-8</span>
                            <span>javascript</span>
                            <span>1:1</span>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}