import React, { useState } from 'react';
import { 
    MousePointer2, Move, Type, Image as ImageIcon, 
    Box, Monitor, Tablet, Smartphone, Maximize, 
    Minimize, Undo, Redo, Trash2, Grid, Layers,
    Wand2, Table, BarChart, Map, Grip, Film
} from 'lucide-react';
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const ToolButton = ({ icon: Icon, active, onClick, title, label }) => (
    <Button
        variant="ghost"
        size="icon"
        onClick={onClick}
        className={cn(
            "h-9 w-9 p-0 transition-all",
            active 
                ? "bg-[hsl(var(--color-execution))] text-black shadow-md scale-105" 
                : "text-neutral-400 hover:text-white hover:bg-white/10"
        )}
        title={title}
    >
        <Icon className="w-4 h-4" />
        {label && <span className="sr-only">{label}</span>}
    </Button>
);

export default function StudioToolbar({ 
    onUndo, onRedo, onClear, onAutoLayout, 
    onZoomIn, onZoomOut, onSetTool, activeTool,
    canUndo, canRedo 
}) {
    return (
        <div className="absolute top-4 right-4 z-40 flex flex-col gap-2">
            
            {/* Primary Tools */}
            <div className="bg-neutral-900/90 backdrop-blur-md border border-white/10 p-1.5 rounded-xl shadow-2xl flex flex-col gap-1">
                <ToolButton 
                    icon={MousePointer2} 
                    active={activeTool === 'select'} 
                    onClick={() => onSetTool('select')} 
                    title="Select (V)" 
                />
                <ToolButton 
                    icon={Box} 
                    active={activeTool === 'component'} 
                    onClick={() => onSetTool('component')} 
                    title="Generate Component (C)" 
                />
                <ToolButton 
                    icon={Type} 
                    active={activeTool === 'text'} 
                    onClick={() => onSetTool('text')} 
                    title="Generate Text (T)" 
                />
                <ToolButton 
                    icon={ImageIcon} 
                    active={activeTool === 'image'} 
                    onClick={() => onSetTool('image')} 
                    title="Generate Image (I)" 
                />
                 <ToolButton 
                    icon={Film} 
                    active={activeTool === 'video'} 
                    onClick={() => onSetTool('video')} 
                    title="Generate Video (V)" 
                />
                 <ToolButton 
                    icon={Grid} 
                    active={activeTool === 'wireframe'} 
                    onClick={() => onSetTool('wireframe')} 
                    title="Generate Wireframe (W)" 
                />
                 <ToolButton 
                    icon={Grid} 
                    active={activeTool === 'pattern'} 
                    onClick={() => onSetTool('pattern')} 
                    title="Generate Pattern (P)" 
                />
                 <ToolButton 
                    icon={Table} 
                    active={activeTool === 'table'} 
                    onClick={() => onSetTool('table')} 
                    title="Generate Table" 
                />
                 <ToolButton 
                    icon={BarChart} 
                    active={activeTool === 'chart'} 
                    onClick={() => onSetTool('chart')} 
                    title="Generate Chart" 
                />
                 <ToolButton 
                    icon={Map} 
                    active={activeTool === 'map'} 
                    onClick={() => onSetTool('map')} 
                    title="Generate Map" 
                />
            </div>

            {/* Actions */}
            <div className="bg-neutral-900/90 backdrop-blur-md border border-white/10 p-1.5 rounded-xl shadow-2xl flex flex-col gap-1">
                <div className="flex flex-col gap-1 border-b border-white/5 pb-1 mb-1">
                    <Button 
                        size="icon" variant="ghost" className="h-8 w-8 text-neutral-400 hover:text-white"
                        onClick={onUndo} disabled={!canUndo}
                    >
                        <Undo className="w-4 h-4" />
                    </Button>
                    <Button 
                        size="icon" variant="ghost" className="h-8 w-8 text-neutral-400 hover:text-white"
                        onClick={onRedo} disabled={!canRedo}
                    >
                        <Redo className="w-4 h-4" />
                    </Button>
                </div>

                <ToolButton icon={Wand2} onClick={onAutoLayout} title="Auto Layout" />
                <ToolButton icon={Maximize} onClick={onZoomIn} title="Zoom In" />
                <ToolButton icon={Minimize} onClick={onZoomOut} title="Zoom Out" />
                <ToolButton icon={Trash2} onClick={onClear} title="Clear Canvas" />
            </div>

        </div>
    );
}