// components/ui/ActivityStream.js
import React, { useState, useEffect } from 'react';
import { GlassPanel } from './GlassPanel';
import { theme } from './design-system/design-tokens';

export const ActivityStream = ({
  items = [],
  maxItems = 20,
  className = '',
}) => {
  const [filteredItems, setFilteredItems] = useState([]);

  useEffect(() => {
    // Sort by relevance score and timestamp
    const sorted = [...items]
      .sort((a, b) => {
        // Primary sort: relevance score
        if (b.relevanceScore !== a.relevanceScore) {
          return (b.relevanceScore || 0) - (a.relevanceScore || 0);
        }
        // Secondary sort: timestamp (newest first)
        const timeA = new Date(a.timestamp).getTime();
        const timeB = new Date(b.timestamp).getTime();
        return timeB - timeA;
      })
      .slice(0, maxItems);
    
    setFilteredItems(sorted);
  }, [items, maxItems]);

  const getSourceIcon = (source) => {
    const icons = {
      slack: '💬',
      github: '🐙',
      notion: '📝',
      google: '📊',
      twitter: '🐦',
      system: '⚙️',
    };
    return icons[source] || '📌';
  };

  const formatTime = (dateStr) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  return (
    <div className={`activity-stream ${className}`} style={{
      display: 'flex',
      flexDirection: 'column',
      gap: theme.spacing.sm,
      maxHeight: '600px',
      overflowY: 'auto',
      paddingRight: '4px', // Space for scrollbar
    }}>
      {filteredItems.map((item) => (
        <GlassPanel
          key={item.id}
          variant="light"
          padding="md"
          onClick={item.action}
          style={{
            cursor: item.action ? 'pointer' : 'default',
          }}
        >
          <div style={{ display: 'flex', gap: theme.spacing.md }}>
            <div style={{ fontSize: theme.typography['size-lg'] }}>
              {getSourceIcon(item.source)}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: theme.spacing.sm,
                marginBottom: theme.spacing.xs,
              }}>
                <div style={{
                  color: theme.colors['text-primary'],
                  fontWeight: theme.typography['weight-medium'],
                  fontSize: theme.typography['size-base'],
                }}>
                  {item.title}
                </div>
                <div style={{
                  color: theme.colors['text-accent'],
                  fontSize: theme.typography['size-xs'],
                }}>
                  {formatTime(item.timestamp)}
                </div>
              </div>
              {item.description && (
                <div style={{
                  color: theme.colors['text-secondary'],
                  fontSize: theme.typography['size-sm'],
                }}>
                  {item.description}
                </div>
              )}
            </div>
            {/* Relevance Indicator */}
            <div style={{
              width: '4px',
              height: '100%',
              minHeight: '24px',
              background: `linear-gradient(to bottom, 
                ${theme.colors['accent-primary']} ${(item.relevanceScore || 0) * 100}%, 
                transparent ${(item.relevanceScore || 0) * 100}%)`,
              borderRadius: theme.rounding.pill,
            }} />
          </div>
        </GlassPanel>
      ))}
      {filteredItems.length === 0 && (
        <div style={{ padding: theme.spacing.md, textAlign: 'center', color: theme.colors['text-accent'] }}>
          No recent activity
        </div>
      )}
    </div>
  );
};