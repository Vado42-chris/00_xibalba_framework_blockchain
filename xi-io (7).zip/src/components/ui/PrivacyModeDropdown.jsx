import React from 'react';
import { 
    Eye, EyeOff, Briefcase, Settings, 
    Shield, ShieldAlert, Lock
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuLabel, 
    DropdownMenuSeparator, 
    DropdownMenuTrigger,
    DropdownMenuRadioGroup,
    DropdownMenuRadioItem
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useSiteContext } from '@/components/identity/SiteContext';
import { cn } from "@/components/ui/utils";

export const PrivacyModeDropdown = () => {
    const { privacyMode, setPrivacyMode } = useSiteContext();

    const modes = {
        public: {
            label: "Public Mode",
            icon: Eye,
            color: "text-green-500",
            bg: "bg-green-500/10",
            border: "border-green-500/20",
            description: "Visible to everyone"
        },
        private: {
            label: "Private Mode",
            icon: Lock,
            color: "text-red-500",
            bg: "bg-red-500/10",
            border: "border-red-500/20",
            description: "Encrypted & Local only"
        },
        work: {
            label: "Work Mode",
            icon: Briefcase,
            color: "text-blue-500",
            bg: "bg-blue-500/10",
            border: "border-blue-500/20",
            description: "Professional Context"
        }
    };

    const current = modes[privacyMode] || modes.private;
    const Icon = current.icon;

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button 
                    variant="outline" 
                    className={cn(
                        "h-8 gap-2 border transition-all duration-300 min-w-[140px] justify-between",
                        current.bg, current.border, current.color,
                        "hover:bg-opacity-20 hover:border-opacity-30"
                    )}
                >
                    <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        <span className="text-xs font-bold uppercase tracking-wider">{privacyMode}</span>
                    </div>
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-64 bg-neutral-900 border-white/10 text-neutral-200">
                <DropdownMenuLabel className="text-xs text-neutral-500 uppercase tracking-wider">
                    Visibility & Context
                </DropdownMenuLabel>
                
                <DropdownMenuRadioGroup value={privacyMode} onValueChange={setPrivacyMode}>
                    <DropdownMenuRadioItem value="public" className="data-[state=checked]:bg-green-950/30 data-[state=checked]:text-green-500">
                        <Eye className="w-4 h-4 mr-2" />
                        <div className="flex flex-col">
                            <span>Public</span>
                            <span className="text-[10px] opacity-50">Shareable views enabled</span>
                        </div>
                    </DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="private" className="data-[state=checked]:bg-red-950/30 data-[state=checked]:text-red-500">
                        <EyeOff className="w-4 h-4 mr-2" />
                        <div className="flex flex-col">
                            <span>Private</span>
                            <span className="text-[10px] opacity-50">Maximum security enforced</span>
                        </div>
                    </DropdownMenuRadioItem>
                    <DropdownMenuRadioItem value="work" className="data-[state=checked]:bg-blue-950/30 data-[state=checked]:text-blue-500">
                        <Briefcase className="w-4 h-4 mr-2" />
                        <div className="flex flex-col">
                            <span>Work Mode</span>
                            <span className="text-[10px] opacity-50">Professional interface</span>
                        </div>
                    </DropdownMenuRadioItem>
                </DropdownMenuRadioGroup>

                <DropdownMenuSeparator className="bg-white/10" />
                
                <DropdownMenuItem asChild className="text-xs cursor-pointer hover:bg-white/5">
                    <Link to="/PrivacyPreferences" className="flex items-center w-full">
                        <Settings className="w-3 h-3 mr-2" />
                        Privacy Preferences...
                    </Link>
                </DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>
    );
};