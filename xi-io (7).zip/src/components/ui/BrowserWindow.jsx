import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    X, Maximize2, Minimize2, RefreshCw, Globe, 
    Smartphone, Tablet, Monitor, Menu, MessageSquare, 
    PanelRightClose, ChevronLeft, ChevronRight, 
    Wifi, Battery, FileText, Folder, MousePointer2, 
    Sun, Moon, ArrowRight, Layout, Save, Command,
    MoreHorizontal, Search, Shield, Zap, Terminal,
    Activity, Layers, Sparkles, Cpu, Mic, Volume2
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import CodeAssistant from '@/components/assistants/CodeAssistant';
import { Input } from "@/components/ui/input";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { cn } from "@/components/ui/utils";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { useSiteContext } from "@/components/identity/SiteContext";

const STAGES = {
    1: { 
        name: 'PROTOCOL', 
        border: 'border-neutral-800', 
        bg: 'bg-[#050505]', 
        blur: 'backdrop-blur-none', 
        shadow: 'shadow-none',
        text: 'font-mono text-neutral-400',
        accent: 'bg-neutral-800'
    },
    2: { 
        name: 'SYNTH', 
        border: 'border-white/10', 
        bg: 'bg-[#0A0A0A]/80', 
        blur: 'backdrop-blur-xl', 
        shadow: 'shadow-2xl',
        text: 'font-sans text-neutral-200',
        accent: 'bg-white/10'
    },
    3: { 
        name: 'SOVEREIGN', 
        border: 'border-[hsl(var(--color-intent))]/30', 
        bg: 'bg-[hsl(var(--color-intent))]/5', 
        blur: 'backdrop-blur-3xl backdrop-saturate-150', 
        shadow: 'shadow-[0_0_50px_-10px_hsl(var(--color-intent))/20]',
        text: 'font-sans text-white',
        accent: 'bg-[hsl(var(--color-intent))]/20'
    }
};

export const BrowserWindow = ({ 
    isOpen, 
    onClose, 
    children, 
    title = "System Browser",
    defaultUrl = "http://localhost:3000",
    viewState = 'windowed', 
    onViewStateChange,
    variant = 'browser',
    showUrlBar = true,
    initialStage = 3, // Default to Tony Stark mode
    initialDeviceMode = 'tablet'
    }) => {
    // Context Sync (Global Evolution)
    const { systemStage } = useSiteContext() || {}; // Optional chaining in case context is missing in isolated tests

    // Browser State
    const [isLoading, setIsLoading] = useState(false);
    const [progress, setProgress] = useState(0);
    const [stage, setStage] = useState(systemStage || initialStage);

    // Sync local stage with global context when it changes
    useEffect(() => {
        if (systemStage) setStage(systemStage);
    }, [systemStage]);

    // View State
    const [deviceMode, setDeviceMode] = useState(initialDeviceMode);
    const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState(false);
    const [isRightDrawerOpen, setIsRightDrawerOpen] = useState(false);
    
    // Tools State
    const [isInspectMode, setIsInspectMode] = useState(false);
    const [isDarkMode, setIsDarkMode] = useState(true);
    
    const constraintsRef = useRef(null);

    const handleStateChange = (newState) => {
        if (onViewStateChange) onViewStateChange(newState);
    };

    // Auto-collapse logic
    useEffect(() => {
        if (deviceMode === 'mobile') {
            setIsLeftSidebarOpen(false);
            if (isRightDrawerOpen) setIsRightDrawerOpen(false);
        } else if (deviceMode === 'desktop') {
             // In desktop mode, we might want sidebars open by default for "IDE" feel
             // but let's keep it user-controlled for now
        }
    }, [deviceMode]);

    if (!isOpen && viewState !== 'minimized') return null;

    // Simulated Navigation Progress
    const handleRefresh = () => {
        setIsLoading(true);
        setProgress(10);
        const interval = setInterval(() => {
            setProgress(prev => prev >= 90 ? 90 : prev + Math.random() * 20);
        }, 100);

        setTimeout(() => {
            clearInterval(interval);
            setProgress(100);
            setTimeout(() => {
                setIsLoading(false);
                setProgress(0);
            }, 300);
        }, 800);
    };

    const currentStyle = STAGES[stage];

    // Animation Variants
    const containerVariants = {
        maximized: { 
            position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, 
            width: "100%", height: "100%", 
            borderRadius: 0,
            transition: { duration: 0.5, ease: [0.32, 0.72, 0, 1] },
            zIndex: 9999
        },
        windowed: { 
            position: 'fixed',
            width: "min(90vw, 1200px)", height: "min(85vh, 850px)",
            borderRadius: 24,
            boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.5)",
            transition: { duration: 0.4, ease: [0.32, 0.72, 0, 1] },
            zIndex: 9990
        },
        minimized: {
             position: 'fixed',
             bottom: 20, right: 20,
             width: 300, height: 48,
             borderRadius: 12,
             transition: { duration: 0.3 },
             zIndex: 9990
        },
        static: {
            width: "100%", height: "100%",
            borderRadius: 12,
            position: "relative",
            zIndex: 10
        }
    };

    const isPortal = viewState === 'windowed' || viewState === 'maximized';
    const Wrapper = isPortal ? ({children}) => createPortal(children, document.body) : ({children}) => <div className="w-full h-full relative z-10 overflow-hidden">{children}</div>;

    return (
        <Wrapper>
            {isPortal && (
                <div className={cn(
                    "fixed inset-0 pointer-events-none flex items-center justify-center font-sans",
                    viewState === 'windowed' ? "z-[100]" : "z-[9999]"
                )}>
                    {/* Constraints & Backdrop */}
                    <div ref={constraintsRef} className="absolute inset-0 pointer-events-none" />
                    <AnimatePresence>
                        {(viewState === 'maximized' || viewState === 'windowed') && (
                            <motion.div 
                                initial={{ opacity: 0 }} 
                                animate={{ opacity: 1 }} 
                                exit={{ opacity: 0 }}
                                className="absolute inset-0 bg-black/60 backdrop-blur-md pointer-events-auto"
                                onClick={() => viewState === 'windowed' && onClose && onClose()} 
                            />
                        )}
                    </AnimatePresence>
                </div>
            )}

            <motion.div
                drag={viewState === 'windowed'}
                dragMomentum={false}
                dragConstraints={constraintsRef}
                dragElastic={0.05}
                initial={false}
                animate={viewState}
                variants={containerVariants}
                className={cn(
                    "flex flex-col overflow-hidden relative group transition-all duration-500 isolate border",
                    currentStyle.border,
                    currentStyle.bg,
                    currentStyle.blur,
                    currentStyle.shadow,
                    isPortal ? "pointer-events-auto" : "w-full h-full",
                    viewState === 'maximized' && "z-[201] border-none rounded-none",
                    viewState === 'windowed' && "z-[101]",
                    viewState === 'minimized' && "items-center justify-between px-4 z-[200] border-white/10 bg-black"
                )}
            >
                {/* Minimized View */}
                {viewState === 'minimized' ? (
                     <div className="flex items-center justify-between w-full h-full cursor-pointer" onClick={() => handleStateChange('windowed')}>
                        <span className="text-sm font-medium text-white truncate max-w-[200px]">{title}</span>
                        <div className="flex gap-2">
                             <Maximize2 className="w-3 h-3 text-neutral-500" />
                             <X onClick={(e) => { e.stopPropagation(); onClose && onClose(); }} className="w-3 h-3 text-neutral-500 hover:text-white" />
                        </div>
                     </div>
                ) : (
                    <>
                        {/* STAGE 3: Holographic Border Effect */}
                        {stage === 3 && (
                            <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden rounded-[inherit]">
                                <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[hsl(var(--color-intent))] to-transparent opacity-50" />
                                <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[hsl(var(--color-intent))] to-transparent opacity-50" />
                            </div>
                        )}

                        {/* HEADER */}
                        <div 
                            className={cn(
                                "h-14 flex items-center justify-between px-4 shrink-0 select-none z-30 relative border-b transition-colors duration-500",
                                stage === 1 ? "bg-neutral-900 border-neutral-800" : "bg-white/[0.02] border-white/5"
                            )}
                            onDoubleClick={() => handleStateChange(viewState === 'maximized' ? 'windowed' : 'maximized')}
                        >
                            {/* Progress Line */}
                            {isLoading && (
                                <motion.div 
                                    initial={{ width: 0 }} 
                                    animate={{ width: `${progress}%` }} 
                                    className="absolute bottom-0 left-0 h-[1px] bg-[hsl(var(--color-intent))] shadow-[0_0_10px_hsl(var(--color-intent))]" 
                                />
                            )}

                            {/* LEFT CONTROLS */}
                            <div className="flex items-center gap-4 w-1/3">
                                <div className="flex gap-2 group/traffic p-2 hover:bg-white/5 rounded-lg transition-colors">
                                    <button onClick={() => onClose && onClose()} className="w-3 h-3 rounded-full bg-red-500/20 hover:bg-red-500 border border-red-500/50 transition-colors shadow-sm" />
                                    <button onClick={() => handleStateChange('minimized')} className="w-3 h-3 rounded-full bg-yellow-500/20 hover:bg-yellow-500 border border-yellow-500/50 transition-colors shadow-sm" />
                                    <button onClick={() => handleStateChange(viewState === 'maximized' ? 'windowed' : 'maximized')} className="w-3 h-3 rounded-full bg-green-500/20 hover:bg-green-500 border border-green-500/50 transition-colors shadow-sm" />
                                </div>

                                <div className="h-6 w-px bg-white/5" />

                                <TooltipProvider>
                                    <Tooltip>
                                        <TooltipTrigger asChild>
                                            <button 
                                                onClick={() => setIsLeftSidebarOpen(!isLeftSidebarOpen)}
                                                className={cn(
                                                    "p-2 rounded-lg transition-all",
                                                    isLeftSidebarOpen ? "bg-white/10 text-white" : "text-neutral-500 hover:text-white"
                                                )}
                                            >
                                                <Menu className="w-4 h-4" />
                                            </button>
                                        </TooltipTrigger>
                                        <TooltipContent>Toggle Sidebar</TooltipContent>
                                    </Tooltip>
                                </TooltipProvider>

                                <div className="flex items-center bg-black/20 rounded-lg p-0.5 border border-white/5">
                                    <button className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-white/5"><ChevronLeft className="w-3 h-3" /></button>
                                    <button className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-white/5"><ChevronRight className="w-3 h-3" /></button>
                                    <button onClick={handleRefresh} className={cn("p-1.5 text-neutral-400 hover:text-white rounded hover:bg-white/5", isLoading && "animate-spin")}><RefreshCw className="w-3 h-3" /></button>
                                </div>
                            </div>

                            {/* CENTER OMNIBAR */}
                            <div className="flex-1 max-w-xl mx-4 relative group">
                                {showUrlBar ? (
                                    <div className={cn(
                                        "h-9 transition-all duration-300 border rounded-lg flex items-center px-3 gap-3 cursor-text shadow-inner",
                                        stage === 1 ? "bg-black border-neutral-800" : "bg-black/40 hover:bg-black/50 border-white/5"
                                    )}>
                                        <div className={cn(
                                            "p-0.5 rounded transition-colors",
                                            stage === 3 ? "text-[hsl(var(--color-intent))]" : "text-neutral-500"
                                        )}>
                                            <Globe className="w-3.5 h-3.5" />
                                        </div>
                                        <div className="flex-1 flex items-center min-w-0">
                                            <span className="text-xs text-neutral-500">https://</span>
                                            <span className="text-sm text-neutral-300 font-medium ml-0.5 selection:bg-[hsl(var(--color-intent))]/30 flex-1 truncate font-mono">
                                                {title.toLowerCase().replace(/\s+/g, '.')}.base44.io
                                            </span>
                                        </div>
                                        {stage >= 2 && (
                                            <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <Badge variant="outline" className="h-5 text-[9px] border-white/10 text-green-500 bg-green-500/5 px-1.5">SECURE</Badge>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div className="flex items-center justify-center gap-2 opacity-50">
                                        <Shield className="w-3 h-3 text-neutral-500" />
                                        <span className="text-xs font-mono text-neutral-500 tracking-widest uppercase">{title}</span>
                                    </div>
                                )}
                                
                                {/* Dev Evolution Controls (Visible for testing) */}
                                <div className="absolute top-full left-1/2 -translate-x-1/2 pt-4 opacity-0 group-hover:opacity-100 transition-opacity z-50">
                                    <div className="flex items-center gap-2 p-1.5 bg-black/90 backdrop-blur-xl rounded-full border border-white/10 shadow-2xl">
                                        <span className="text-[10px] font-bold text-neutral-500 px-2 uppercase tracking-wider">Sys Evolution</span>
                                        <div className="h-4 w-px bg-white/10" />
                                        {[1, 2, 3].map(s => (
                                            <button
                                                key={s}
                                                onClick={() => setStage(s)}
                                                className={cn(
                                                    "px-3 py-1 rounded-full text-[10px] font-bold flex items-center justify-center transition-all",
                                                    stage === s 
                                                        ? "bg-[hsl(var(--color-intent))] text-black shadow-[0_0_10px_hsl(var(--color-intent))/50]" 
                                                        : "text-neutral-400 hover:text-white hover:bg-white/10"
                                                )}
                                            >
                                                {s === 1 ? 'PROTO' : s === 2 ? 'SYNTH' : 'SOV'}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* RIGHT TOOLS */}
                            <div className="flex items-center justify-end gap-3 w-1/3">
                                <div className="flex items-center bg-black/20 rounded-lg p-0.5 border border-white/5">
                                    {[
                                        { id: 'desktop', icon: Monitor, label: 'Desktop' },
                                        { id: 'tablet', icon: Tablet, label: 'Tablet' },
                                        { id: 'mobile', icon: Smartphone, label: 'Mobile' }
                                    ].map((mode) => (
                                        <TooltipProvider key={mode.id}>
                                            <Tooltip>
                                                <TooltipTrigger asChild>
                                                    <button
                                                        onClick={() => setDeviceMode(mode.id)}
                                                        className={cn(
                                                            "p-1.5 rounded-md transition-all",
                                                            deviceMode === mode.id ? "bg-white/10 text-white shadow-sm" : "text-neutral-500 hover:text-neutral-300"
                                                        )}
                                                    >
                                                        <mode.icon className="w-3.5 h-3.5" />
                                                    </button>
                                                </TooltipTrigger>
                                                <TooltipContent>{mode.label}</TooltipContent>
                                            </Tooltip>
                                        </TooltipProvider>
                                    ))}
                                </div>

                                <div className="h-6 w-px bg-white/5" />

                                <TooltipProvider>
                                    <Tooltip>
                                        <TooltipTrigger asChild>
                                            <button 
                                                onClick={() => setIsRightDrawerOpen(!isRightDrawerOpen)}
                                                className={cn(
                                                    "flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all text-xs font-medium",
                                                    isRightDrawerOpen 
                                                        ? "bg-[hsl(var(--color-intent))]/10 border-[hsl(var(--color-intent))]/30 text-[hsl(var(--color-intent))]" 
                                                        : "bg-transparent border-transparent hover:bg-white/5 text-neutral-400 hover:text-white"
                                                )}
                                            >
                                                {stage >= 3 ? <Sparkles className="w-3.5 h-3.5" /> : <MessageSquare className="w-3.5 h-3.5" />}
                                                <span className="hidden sm:inline">Jarvis</span>
                                            </button>
                                        </TooltipTrigger>
                                        <TooltipContent>AI Assistant</TooltipContent>
                                    </Tooltip>
                                </TooltipProvider>

                                {viewState !== 'maximized' && (
                                    <button 
                                        onClick={() => handleStateChange(viewState === 'docked' ? 'windowed' : 'docked')}
                                        className="p-2 text-neutral-500 hover:text-white transition-colors"
                                    >
                                        {viewState === 'docked' ? <ArrowRight className="w-4 h-4 rotate-45" /> : <Layout className="w-4 h-4" />}
                                    </button>
                                )}
                            </div>
                        </div>

                        {/* CONTENT BODY */}
                        <div className="flex-1 flex overflow-hidden relative bg-transparent">
                            {/* LEFT SIDEBAR: NAVIGATION */}
                            <AnimatePresence>
                                {isLeftSidebarOpen && (
                                    <motion.div 
                                        initial={{ width: 0, opacity: 0, x: -20 }}
                                        animate={{ width: 240, opacity: 1, x: 0 }}
                                        exit={{ width: 0, opacity: 0, x: -20 }}
                                        transition={{ duration: 0.3, ease: "circOut" }}
                                        className="bg-black/40 border-r border-white/5 backdrop-blur-xl flex flex-col z-20 relative overflow-hidden"
                                    >
                                        <div className="p-4 space-y-6 flex-1 overflow-y-auto">
                                            {/* Stage 1: Basic File Tree */}
                                            {stage === 1 && (
                                                <div className="space-y-1 font-mono text-xs text-neutral-500">
                                                    <div>/src</div>
                                                    <div className="pl-4">/components</div>
                                                    <div className="pl-4">app.js</div>
                                                </div>
                                            )}

                                            {/* Stage 2 & 3: Rich Navigation */}
                                            {stage >= 2 && (
                                                <>
                                                    <div className="space-y-1">
                                                        <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest px-2 mb-2 flex items-center gap-2">
                                                            <Globe className="w-3 h-3" /> Project Files
                                                        </div>
                                                        {['index.html', 'styles.css', 'app.js', 'manifest.json'].map(file => (
                                                            <div key={file} className="flex items-center gap-2 px-2 py-2 rounded-md cursor-pointer text-xs text-neutral-400 hover:text-white hover:bg-white/5 transition-colors group">
                                                                <FileText className="w-3.5 h-3.5 opacity-50 group-hover:text-[hsl(var(--color-intent))]" />
                                                                <span>{file}</span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                    <div className="space-y-1">
                                                        <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest px-2 mb-2 flex items-center gap-2">
                                                            <Folder className="w-3 h-3" /> Assets
                                                        </div>
                                                        {['images', 'fonts', 'scripts', 'data'].map(folder => (
                                                            <div key={folder} className="flex items-center gap-2 px-2 py-2 rounded-md cursor-pointer text-xs text-neutral-400 hover:text-white hover:bg-white/5 transition-colors group">
                                                                <Folder className="w-3.5 h-3.5 text-blue-400/50 group-hover:text-blue-400" />
                                                                <span>{folder}</span>
                                                                <ChevronRight className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-50" />
                                                            </div>
                                                        ))}
                                                    </div>
                                                </>
                                            )}

                                            {/* Stage 3: Audio Viz / Reactive Elements */}
                                            {stage === 3 && (
                                                <div className="px-2 mt-8 opacity-50">
                                                    <div className="flex items-end gap-1 h-8">
                                                        {[...Array(15)].map((_, i) => (
                                                            <motion.div 
                                                                key={i} 
                                                                animate={{ height: [Math.random() * 20 + 10, Math.random() * 100 + 10] }}
                                                                transition={{ duration: 0.2, repeat: Infinity, repeatType: "reverse" }}
                                                                className="w-1 bg-[hsl(var(--color-intent))]" 
                                                                style={{ height: `${Math.random() * 100}%` }}
                                                            />
                                                        ))}
                                                    </div>
                                                    <div className="text-[9px] text-[hsl(var(--color-intent))] mt-1 font-mono uppercase flex items-center gap-2">
                                                        <Activity className="w-3 h-3" /> System Reactive
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                        
                                        {/* Status Footer */}
                                        <div className="p-4 border-t border-white/5 bg-black/20">
                                            <div className="flex items-center gap-3">
                                                <div className={cn(
                                                    "w-8 h-8 rounded-full flex items-center justify-center border",
                                                    stage === 3 ? "bg-[hsl(var(--color-intent))]/20 border-[hsl(var(--color-intent))]/30" : "bg-white/5 border-white/10"
                                                )}>
                                                    <Terminal className={cn("w-4 h-4", stage === 3 ? "text-[hsl(var(--color-intent))]" : "text-neutral-400")} />
                                                </div>
                                                <div className="text-xs">
                                                    <div className="text-white font-medium">Local Host</div>
                                                    <div className="text-neutral-500 text-[10px]">Active • Port 3000</div>
                                                </div>
                                            </div>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>

                            {/* MAIN VIEWPORT */}
                            <div className="flex-1 relative flex flex-col min-w-0 overflow-hidden">
                                {/* Floating Toolbar Overlay */}
                                <div className="absolute top-6 left-6 z-40 flex flex-col gap-2 pointer-events-auto">
                                    <ToolbarButton icon={MousePointer2} label="Inspect Element" isActive={isInspectMode} onClick={() => setIsInspectMode(!isInspectMode)} />
                                    <ToolbarButton icon={isDarkMode ? Moon : Sun} label="Toggle Theme" isActive={isDarkMode} onClick={() => setIsDarkMode(!isDarkMode)} />
                                    <ToolbarButton icon={Activity} label="Performance" onClick={() => toast.info("Performance: Optimal (60fps)")} />
                                    <ToolbarButton icon={Save} label="Snapshot" onClick={() => toast.success("Snapshot saved to Archives")} />
                                    {stage >= 2 && (
                                        <ToolbarButton icon={Smartphone} label="Mobile View" onClick={() => setDeviceMode('mobile')} />
                                    )}
                                    {stage === 3 && (
                                        <ToolbarButton icon={Layers} label="X-Ray Vision" onClick={() => toast("X-Ray Vision Active: DOM Layer Revealed")} />
                                    )}
                                </div>

                                {/* Device Frame / Content Area */}
                                <div className="flex-1 flex items-center justify-center overflow-auto bg-transparent relative">
                                    {/* Ambient Backgrounds */}
                                    {stage >= 2 && <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.03)_0%,transparent_70%)]" />}
                                    {stage === 3 && <div className="absolute top-[-20%] right-[-20%] w-[800px] h-[800px] bg-[hsl(var(--color-intent))]/5 blur-[100px] rounded-full pointer-events-none" />}
                                    
                                    <motion.div
                                        layout
                                        animate={{
                                            width: deviceMode === 'desktop' ? '100%' : deviceMode === 'tablet' ? 768 : 375,
                                            height: deviceMode === 'desktop' ? '100%' : deviceMode === 'tablet' ? 1024 : 812,
                                            borderRadius: deviceMode === 'desktop' ? 0 : 48,
                                            scale: deviceMode === 'desktop' ? 1 : 0.85,
                                        }}
                                        transition={{ duration: 0.5, ease: [0.32, 0.72, 0, 1] }}
                                        className={cn(
                                            "relative shadow-2xl overflow-hidden transition-all origin-top",
                                            isDarkMode ? "bg-[#050505]/80" : "bg-white/80",
                                            stage >= 2 && "backdrop-blur-xl",
                                            // Realistic Device Borders
                                            deviceMode !== 'desktop' ? "border-[12px] border-[#1a1a1a] ring-1 ring-white/20 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)]" : "",
                                            deviceMode === 'tablet' && "aspect-[3/4]",
                                            deviceMode === 'mobile' && "aspect-[9/19.5]"
                                        )}
                                    >
                                        {/* Status Bar for Mobile/Tablet */}
                                        {deviceMode !== 'desktop' && (
                                            <>
                                                <div className="absolute top-0 left-0 right-0 h-12 z-30 flex items-center justify-between px-8 pointer-events-none">
                                                    <span className={cn("text-[12px] font-medium tracking-wide", isDarkMode ? "text-white/80" : "text-black/80")}>9:41</span>
                                                    {deviceMode === 'mobile' && <div className="absolute left-1/2 top-0 -translate-x-1/2 w-32 h-6 bg-[#1a1a1a] rounded-b-[16px] shadow-sm" />}
                                                    <div className={cn("flex gap-2 opacity-80", isDarkMode ? "text-white" : "text-black")}>
                                                        <Wifi className="w-4 h-4" />
                                                        <Battery className="w-4 h-4" />
                                                    </div>
                                                </div>
                                                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-32 h-1 bg-white/20 rounded-full z-30" />
                                            </>
                                        )}

                                        {/* Content Scroll Area */}
                                        <div className={cn(
                                            "w-full h-full overflow-auto scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent transition-colors",
                                            deviceMode !== 'desktop' && "pt-8"
                                        )}>
                                            {/* Inspect Overlay */}
                                            {isInspectMode && (
                                                <div className="absolute inset-0 z-50 pointer-events-none border-2 border-[hsl(var(--color-intent))] bg-[hsl(var(--color-intent))]/5 flex items-center justify-center backdrop-blur-[1px]">
                                                    <div className="bg-[hsl(var(--color-intent))] text-black px-4 py-2 rounded-full text-xs font-bold animate-pulse flex items-center gap-2 shadow-[0_0_20px_hsl(var(--color-intent))]">
                                                        <MousePointer2 className="w-4 h-4" /> INSPECT ELEMENT
                                                    </div>
                                                </div>
                                            )}
                                            
                                            {/* Render Children with injected props */}
                                            {React.cloneElement(children, { isDarkMode, deviceMode, stage })}
                                        </div>
                                    </motion.div>
                                </div>
                            </div>

                            {/* RIGHT DRAWER: JARVIS */}
                            <AnimatePresence>
                                {isRightDrawerOpen && (
                                    <motion.div 
                                        initial={{ width: 0, opacity: 0, x: 20 }}
                                        animate={{ width: 380, opacity: 1, x: 0 }}
                                        exit={{ width: 0, opacity: 0, x: 20 }}
                                        transition={{ duration: 0.3, ease: "circOut" }}
                                        className="bg-black/40 border-l border-white/5 backdrop-blur-xl flex flex-col z-20 shadow-2xl relative"
                                    >
                                        <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
                                            <div className="flex items-center gap-2">
                                                <div className={cn(
                                                    "w-2 h-2 rounded-full animate-pulse",
                                                    stage === 3 ? "bg-[hsl(var(--color-intent))]" : "bg-blue-500"
                                                )} />
                                                <span className="text-xs font-bold text-white uppercase tracking-widest">
                                                    {stage === 3 ? "JARVIS" : "ASSISTANT"}
                                                </span>
                                            </div>
                                            <button onClick={() => setIsRightDrawerOpen(false)} className="text-neutral-500 hover:text-white"><PanelRightClose className="w-4 h-4" /></button>
                                        </div>
                                        <div className="flex-1 overflow-hidden relative">
                                            {/* Simulated Audio Waveform for Jarvis */}
                                            {stage === 3 && (
                                                <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-black to-transparent z-10 pointer-events-none flex items-end justify-center pb-4 gap-1">
                                                    {[...Array(20)].map((_, i) => (
                                                        <motion.div 
                                                            key={i}
                                                            animate={{ height: [4, Math.random() * 24 + 4, 4] }}
                                                            transition={{ duration: 0.5, repeat: Infinity, delay: i * 0.05 }}
                                                            className="w-1 bg-[hsl(var(--color-intent))]/50 rounded-full"
                                                        />
                                                    ))}
                                                </div>
                                            )}
                                            <CodeAssistant mode="FULL" />
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </>
                )}
            </motion.div>
        </Wrapper>
    );
};

const ToolbarButton = ({ icon: Icon, label, isActive, onClick }) => (
    <TooltipProvider>
        <Tooltip>
            <TooltipTrigger asChild>
                <button 
                    onClick={onClick}
                    className={cn(
                        "w-10 h-10 rounded-xl border flex items-center justify-center shadow-lg transition-all active:scale-95 group relative overflow-hidden",
                        isActive 
                            ? "bg-[hsl(var(--color-intent))] border-[hsl(var(--color-intent))] text-black" 
                            : "bg-black/60 border-white/10 text-neutral-400 hover:text-white hover:bg-white/10 backdrop-blur-md"
                    )}
                >
                    <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                    <Icon className="w-4 h-4 relative z-10" />
                </button>
            </TooltipTrigger>
            <TooltipContent side="right" className="bg-black border-white/10 text-white ml-2 z-[202] text-xs font-mono uppercase tracking-widest">
                <p>{label}</p>
            </TooltipContent>
        </Tooltip>
    </TooltipProvider>
);