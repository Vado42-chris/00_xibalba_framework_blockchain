import React, { useState } from 'react';
import { 
  Folder, 
  FolderOpen, 
  FileCode, 
  FileJson, 
  File as FileIcon,
  ChevronRight,
  ChevronDown
} from 'lucide-react';
import { cn } from '@/components/ui/utils';

const FileItem = ({ name, type, depth = 0, active = false, expanded = false, onToggle, onSelect }) => {
  const Icon = type === 'folder' 
    ? (expanded ? FolderOpen : Folder)
    : (name.endsWith('.js') || name.endsWith('.jsx') ? FileCode 
      : name.endsWith('.json') ? FileJson : FileIcon);

  return (
    <div 
      onClick={(e) => {
        if (type === 'folder') {
          onToggle(e);
        } else {
          onSelect && onSelect(name);
        }
      }}
      className={cn(
        "flex items-center gap-1.5 px-2 py-1 cursor-pointer select-none transition-colors text-xs font-mono",
        active ? "bg-[hsl(var(--layer-state))] text-[hsl(var(--fg-intent))]" : "text-[hsl(var(--fg-orientation))] hover:text-[hsl(var(--fg-intent))] hover:bg-[hsl(var(--layer-orientation))]",
      )}
      style={{ paddingLeft: `${depth * 12 + 8}px` }}
    >
      {type === 'folder' && (
        <span className="text-[hsl(var(--fg-orientation))]">
          {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        </span>
      )}
      <Icon className={cn("w-3.5 h-3.5", 
        type === 'folder' ? "text-[hsl(var(--fg-orientation))]" : "text-[hsl(var(--color-active))]"
      )} />
      <span className="truncate">{name}</span>
    </div>
  );
};

export default function FileTree({ onSelect, activeFile, files = [] }) {
  const [expanded, setExpanded] = useState({});

  // Build tree structure from flat file list
  const tree = React.useMemo(() => {
    const root = {};
    files.forEach(file => {
      const parts = file.path.split('/');
      let current = root;
      parts.forEach((part, i) => {
        if (i === parts.length - 1) {
          current[part] = { _type: 'file', ...file };
        } else {
          current[part] = current[part] || { _type: 'folder', _children: {} };
          current = current[part]._children;
        }
      });
    });
    return root;
  }, [files]);

  // Auto-expand root folders initially
  React.useEffect(() => {
    if (Object.keys(expanded).length === 0 && files.length > 0) {
      const initialExpanded = {};
      Object.keys(tree).forEach(key => {
        if (tree[key]._type === 'folder') initialExpanded[key] = true;
      });
      setExpanded(initialExpanded);
    }
  }, [tree, files.length]);

  const toggle = (id) => {
    setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const renderTree = (node, depth = 0, pathPrefix = '') => {
    return Object.entries(node).map(([name, data]) => {
      const currentPath = pathPrefix ? `${pathPrefix}/${name}` : name;
      
      if (data._type === 'folder') {
        const isExpanded = expanded[currentPath];
        return (
          <React.Fragment key={currentPath}>
            <FileItem 
              name={name} 
              type="folder" 
              depth={depth} 
              expanded={isExpanded} 
              onToggle={() => toggle(currentPath)} 
            />
            {isExpanded && renderTree(data._children, depth + 1, currentPath)}
          </React.Fragment>
        );
      } else {
        return (
          <FileItem 
            key={currentPath}
            name={name} 
            type="file" 
            depth={depth} 
            active={activeFile?.path === data.path} 
            onSelect={() => onSelect(data)} 
          />
        );
      }
    });
  };

  return (
    <div className="flex flex-col h-full bg-[hsl(var(--void))] border-r border-[hsl(var(--layer-orientation))]">
      <div className="h-9 flex items-center px-4 border-b border-[hsl(var(--layer-orientation))] bg-[hsl(var(--layer-orientation))]">
        <span className="text-[10px] font-bold text-[hsl(var(--fg-orientation))] uppercase tracking-widest">Explorer</span>
      </div>
      <div className="flex-1 overflow-y-auto py-2 scrollbar-thin scrollbar-thumb-[hsl(var(--layer-orientation))]">
        {files.length === 0 ? (
           <div className="p-4 text-[10px] text-neutral-500 text-center opacity-50">No source files indexed</div>
        ) : (
           renderTree(tree)
        )}
      </div>
    </div>
  );
}