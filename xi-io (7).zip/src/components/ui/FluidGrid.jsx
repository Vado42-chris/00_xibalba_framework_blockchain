import React from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { cn } from "./utils";

export const FluidGrid = ({ left, right, className, panelClassName }) => {
    // Basic mobile detection (can be enhanced with a hook if needed, but CSS hiding is safer for SSR/hydration mismatch avoidance usually, 
    // though ResizablePanels needs JS. For now, we'll assume desktop-first for panels and fallback to stack on small screens via media query check if possible, 
    // or just render panels that stack? Panels don't stack automatically.
    // We'll use a simple CSS-based toggle or a JS check. 
    // Given the constraints, let's use a JS check for window width if we can, or just force panels.
    // However, Panels on mobile are bad.
    
    // Quick reliable mobile check for client-side interactions
    const [isMobile, setIsMobile] = React.useState(false);

    React.useEffect(() => {
        if (typeof window === 'undefined') return;
        const checkMobile = () => setIsMobile(window.innerWidth < 1024);
        checkMobile();
        window.addEventListener('resize', checkMobile);
        return () => window.removeEventListener('resize', checkMobile);
    }, []);

    // We no longer need separate logic as ResizablePanels with our new QuadrantGrid system handles adaptation internally
    // or through the Layout components.
    // However, FluidGrid is just a 2-pane wrapper.
    if (isMobile) {
        return (
            <div className={cn("w-full h-full p-[15px] flex flex-col gap-[15px] overflow-y-auto", className)}>
                <div className="flex-none">{left}</div>
                <div className="flex-none">{right}</div>
            </div>
        );
    }

    return (
        <div className={cn("w-full h-full", className)}>
            <PanelGroup direction="horizontal">
                <Panel defaultSize={30} minSize={20} className={cn("flex flex-col overflow-y-auto", panelClassName)}>
                    {left}
                </Panel>
                
                <PanelResizeHandle className="w-[1px] bg-white/5 hover:bg-[hsl(var(--color-intent))] transition-colors cursor-col-resize active:bg-[hsl(var(--color-execution))]" />
                
                <Panel defaultSize={70} minSize={40} className={cn("flex flex-col overflow-y-auto", panelClassName)}>
                    {right}
                </Panel>
            </PanelGroup>
        </div>
    );
};