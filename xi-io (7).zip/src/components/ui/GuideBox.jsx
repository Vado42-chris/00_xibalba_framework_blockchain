import React, { useState } from 'react';
import { Info, X, ChevronDown, ChevronUp, BookOpen } from 'lucide-react';
import { cn } from "@/components/ui/utils";
import { Button } from "@/components/ui/button";

export const GuideBox = ({ title, children, className, defaultOpen = true }) => {
    const [isOpen, setIsOpen] = useState(defaultOpen);

    if (!isOpen) {
        return (
            <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsOpen(true)}
                className={cn("text-xs text-neutral-500 hover:text-white flex items-center gap-2", className)}
            >
                <BookOpen className="w-3 h-3" />
                <span>Show Guide</span>
            </Button>
        );
    }

    return (
        <div className={cn("bg-neutral-900/50 border border-white/10 rounded-md p-4 mb-4 relative group animate-in fade-in slide-in-from-top-2 border-l-4 border-l-[hsl(var(--color-intent))]", className)}>
            <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2 text-[hsl(var(--color-execution))]">
                    <Info className="w-4 h-4" />
                    <span className="text-xs font-bold tracking-wider uppercase">{title || "Workflow Guide"}</span>
                </div>
                <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setIsOpen(false)}
                    className="h-5 w-5 -mr-1 -mt-1 text-neutral-500 hover:text-white"
                >
                    <X className="w-3 h-3" />
                </Button>
            </div>
            <div className="text-sm text-neutral-300 leading-relaxed font-light">
                {children}
            </div>
        </div>
    );
};

export const TermHelper = ({ term, definition }) => {
    return (
        <div className="group relative inline-block border-b border-dashed border-neutral-500 cursor-help">
            <span>{term}</span>
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-neutral-900 border border-white/10 rounded shadow-xl text-xs text-neutral-300 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                {definition}
            </div>
        </div>
    );
};