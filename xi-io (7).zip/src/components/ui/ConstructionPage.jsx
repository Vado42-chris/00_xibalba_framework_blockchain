import React from 'react';
import { OrientingText, IntentText, StateText, QuadrantGrid, Quadrant } from '@/components/ui/design-system/SystemDesign';
import { Construction } from 'lucide-react';
import { LoadingLab } from '@/components/ui/design-system/Curiosity';

export default function ConstructionPage({ title = "Module Pending", description = "This system is currently under development." }) {
    return (
        <QuadrantGrid>
            <Quadrant type="orientation" className="flex flex-col justify-center items-center">
                <div className="p-8 border border-dashed border-white/10 rounded-lg text-center relative overflow-hidden bg-neutral-900/30">
                    <Construction className="w-12 h-12 text-neutral-600 mb-4 mx-auto" />
                    <OrientingText className="mb-2 uppercase tracking-widest">{title}</OrientingText>
                    <IntentText className="text-xl max-w-md mx-auto">{description}</IntentText>
                    <div className="mt-8 flex justify-center">
                        <div className="w-64 h-24 relative">
                            <LoadingLab active={true} cause="Development" duration="Unknown" />
                        </div>
                    </div>
                </div>
            </Quadrant>
        </QuadrantGrid>
    );
}