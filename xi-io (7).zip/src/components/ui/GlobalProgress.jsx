import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { cn } from '@/components/ui/utils';

export const GlobalProgress = () => {
    const location = useLocation();
    const [progress, setProgress] = useState(0);
    const [visible, setVisible] = useState(false);

    useEffect(() => {
        // Start progress on route change
        setVisible(true);
        setProgress(0);

        const interval = setInterval(() => {
            setProgress(prev => {
                // Slower progress as it gets higher, never reaching 100% until complete
                const increment = Math.max(0, (90 - prev) / 10); 
                return prev + increment;
            });
        }, 100);

        // Simulate completion after a short delay (since we don't have real router events for load completion in this setup)
        const completeTimeout = setTimeout(() => {
            setProgress(100);
            clearInterval(interval);
            setTimeout(() => setVisible(false), 500); // Fade out
        }, 800);

        return () => {
            clearInterval(interval);
            clearTimeout(completeTimeout);
        };
    }, [location.pathname]);

    if (!visible) return null;

    return (
        <div className="fixed top-0 left-0 right-0 z-[100] h-0.5 bg-transparent pointer-events-none">
            <div 
                className={cn(
                    "h-full bg-[hsl(var(--color-intent))] shadow-[0_0_10px_hsl(var(--color-intent))] transition-all duration-300 ease-out",
                    progress === 100 ? "opacity-0" : "opacity-100"
                )}
                style={{ width: `${progress}%` }}
            />
        </div>
    );
};