import React, { useState, useEffect } from 'react';
import { Command } from 'cmdk';
import { Search, FileCode, Users, Box, Terminal, ArrowRight, Globe, ShoppingBag, CircuitBoard, Server, Cloud } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { base44 } from "@/api/base44Client";
import { cn } from '@/components/ui/utils';
import { OrientingText, IntentText, StateText, SemanticDot } from '@/components/ui/design-system/System';
import { LoadingLab } from '@/components/ui/design-system/Curiosity';
import { useSiteContext } from '@/components/identity/SiteContext';

export const GlobalSearch = ({ open, onOpenChange }) => {
  const navigate = useNavigate();
  const { domainData, currentDomain } = useSiteContext();
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  
  // Advanced Filters
  const [filterType, setFilterType] = useState('all');
  const [filterTime, setFilterTime] = useState('all');

  // Real-time indexing of system entities
  useEffect(() => {
    if (open) {
        setLoading(true);
        setSearchResults([]); 

        const fetchData = async () => {
            try {
                // Determine time cutoff
                let timeFilter = null;
                const now = new Date();
                if (filterTime === '24h') timeFilter = new Date(now.setDate(now.getDate() - 1));
                if (filterTime === 'week') timeFilter = new Date(now.setDate(now.getDate() - 7));
                if (filterTime === 'month') timeFilter = new Date(now.setMonth(now.getMonth() - 1));

                // Helper to check time filter if entity has timestamp
                const checkTime = (item) => {
                    if (!timeFilter) return true;
                    const date = item.created_date || item.timestamp || item.updated_date;
                    if (!date) return true; // Keep if no date
                    return new Date(date) >= timeFilter;
                };

                const [customers, products, assets, logs, files] = await Promise.all([
                    (filterType === 'all' || filterType === 'contact') ? (base44.entities.Customer?.list({ limit: 10 }) || []) : [],
                    (filterType === 'all' || filterType === 'product') ? (base44.entities.Product?.list({ limit: 10 }) || []) : [],
                    (filterType === 'all' || filterType === 'asset') ? (base44.entities.Asset?.list({ limit: 10 }) || []) : [],
                    (filterType === 'all' || filterType === 'log') ? (base44.entities.Log?.list({ limit: 10 }) || []) : [],
                    (filterType === 'all' || filterType === 'code') ? (base44.entities.SourceFile?.list({ limit: 20 }) || []) : []
                ]);

                let results = [
                    ...customers.map(c => ({ id: c.id, type: 'contact', title: c.name, subtitle: `Customer • ${c.company || 'Unknown'}`, path: 'CRM', timestamp: c.created_date })),
                    ...products.map(p => ({ id: p.id, type: 'product', title: p.name, subtitle: `Product • ${p.sku}`, path: 'Commerce', timestamp: p.created_date })),
                    ...assets.map(a => ({ id: a.id, type: 'asset', title: a.name, subtitle: `Asset • ${a.symbol}`, path: 'Finance', timestamp: a.updated_date })),
                    ...logs.map(l => ({ id: l.id, type: 'log', title: l.type.toUpperCase(), subtitle: `Log • ${new Date(l.timestamp).toLocaleTimeString()}`, path: 'Console', timestamp: l.timestamp })),
                    ...files.map(f => ({ id: f.id, type: 'code', title: f.path.split('/').pop(), subtitle: `Source • ${f.path}`, path: 'ContentManager', timestamp: f.updated_date }))
                ];

                // Apply Time Filtering
                if (timeFilter) {
                    results = results.filter(checkTime);
                }

                setSearchResults(results);
            } catch (error) {
                console.error("Search indexing failed:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }
  }, [open, filterType, filterTime]);

  const handleSelect = (item) => {
    onOpenChange(false);
    
    if (typeof item === 'object' && item.type === 'search') {
         navigate(createPageUrl('SearchResults') + `?q=${encodeURIComponent(query)}`);
         return;
    }

    const path = typeof item === 'string' ? item : item.path;
    navigate(createPageUrl(path));
  };

  return (
    <div className={cn(
        "fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm transition-all duration-300",
        open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
    )}>
        <div className="fixed top-[20%] left-1/2 -translate-x-1/2 w-full max-w-2xl bg-black/80 backdrop-blur-xl border border-white/10 shadow-[0_0_50px_-10px_rgba(0,0,0,0.8)] rounded-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-300 ring-1 ring-white/5">
            {loading ? (
                <div className="h-[300px] relative">
                    <LoadingLab 
                        active={true}
                        cause="Indexing Reality"
                        duration="~1.5s"
                        scenarios={[
                            {
                                setup: `Scanning ${domainData?.name || 'System'} Context...`,
                                math: `Vectorizing ${domainData?.categories?.length || 42} user categories...`,
                                human: `Adapting interface for ${domainData?.intent || 'Human'}...`,
                                resolution: "Context Loaded."
                            }
                        ]}
                    />
                </div>
            ) : (
                <Command className="w-full bg-transparent">
                    <div className="flex items-center border-b border-white/5 px-4">
                        <Search className="w-5 h-5 text-neutral-500" />
                        <Command.Input 
                            value={query}
                            onValueChange={setQuery}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    handleSelect({ type: 'search' });
                                }
                            }}
                            placeholder="Search modules, assets, or system events..."
                            className="flex h-14 w-full bg-transparent px-4 py-3 text-lg outline-none text-white placeholder:text-neutral-500 font-light"
                            autoFocus
                        />
                        <div className="flex items-center gap-2 text-[10px] text-neutral-500 font-mono border border-white/5 px-2 py-1 rounded">
                            <span>ESC</span> TO CLOSE
                        </div>
                    </div>

                    {/* Advanced Filters Toolbar */}
                    <div className="flex items-center gap-2 px-4 py-2 border-b border-white/5 bg-white/[0.02]">
                         <select 
                            value={filterType}
                            onChange={(e) => setFilterType(e.target.value)}
                            className="bg-neutral-900 border border-white/10 text-[10px] text-neutral-300 rounded px-2 py-1 focus:outline-none focus:border-[hsl(var(--color-intent))]"
                         >
                             <option value="all">All Types</option>
                             <option value="contact">Contacts</option>
                             <option value="product">Products</option>
                             <option value="asset">Assets</option>
                             <option value="code">Code</option>
                             <option value="log">Logs</option>
                         </select>

                         <select 
                            value={filterTime}
                            onChange={(e) => setFilterTime(e.target.value)}
                            className="bg-neutral-900 border border-white/10 text-[10px] text-neutral-300 rounded px-2 py-1 focus:outline-none focus:border-[hsl(var(--color-intent))]"
                         >
                             <option value="all">Any Time</option>
                             <option value="24h">Last 24 Hours</option>
                             <option value="week">Last 7 Days</option>
                             <option value="month">Last 30 Days</option>
                         </select>

                         <div className="flex-1" />
                         <span className="text-[9px] text-neutral-600 font-mono">{searchResults.length} RESULTS</span>
                    </div>

                    <Command.List className="max-h-[60vh] overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-white/5">
                        <Command.Empty className="py-12 text-center text-sm text-neutral-500">
                            <OrientingText>No results found in this timeline.</OrientingText>
                        </Command.Empty>

                        {/* Command Execution / Unified Search */}
                        {query && (
                            <>
                                <Command.Group heading={<OrientingText className="px-2 py-2 text-[10px] opacity-50 uppercase tracking-widest">Global Search</OrientingText>}>
                                    <Command.Item 
                                        onSelect={() => handleSelect({ type: 'search' })}
                                        className="flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer hover:bg-white/5 group aria-selected:bg-white/5"
                                    >
                                        <div className="w-8 h-8 rounded bg-neutral-900 border border-white/5 flex items-center justify-center border-[hsl(var(--color-intent))]">
                                            <Search className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                        </div>
                                        <div className="flex-1">
                                            <IntentText className="text-sm font-medium">Search Local for "{query}"</IntentText>
                                            <StateText className="text-xs opacity-50">View all matches in Global Index</StateText>
                                        </div>
                                        <ArrowRight className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                    </Command.Item>

                                    <Command.Item 
                                        onSelect={() => {
                                            onOpenChange(false);
                                            navigate(createPageUrl('SearchResults') + `?q=${encodeURIComponent(query)}&scope=web`);
                                        }}
                                        className="flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer hover:bg-white/5 group aria-selected:bg-white/5"
                                    >
                                        <div className="w-8 h-8 rounded bg-neutral-900 border border-white/5 flex items-center justify-center border-blue-500">
                                            <Globe className="w-4 h-4 text-blue-500" />
                                        </div>
                                        <div className="flex-1">
                                            <IntentText className="text-sm font-medium">Search Web for "{query}"</IntentText>
                                            <StateText className="text-xs opacity-50">Scan external networks via Dreamcatcher</StateText>
                                        </div>
                                        <ArrowRight className="w-4 h-4 text-blue-500" />
                                    </Command.Item>
                                </Command.Group>

                                {/* Execute Command Option */}
                                <Command.Group heading={<OrientingText className="px-2 py-2 text-[10px] opacity-50 uppercase tracking-widest">System Execution</OrientingText>}>
                                    <Command.Item 
                                        onSelect={() => {
                                            onOpenChange(false);
                                            navigate(createPageUrl('Console') + `?cmd=${encodeURIComponent(query)}`);
                                        }}
                                        className="flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer hover:bg-white/5 group aria-selected:bg-white/5"
                                    >
                                        <div className="w-8 h-8 rounded bg-neutral-900 border border-white/5 flex items-center justify-center border-[hsl(var(--color-execution))]">
                                            <Terminal className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                        </div>
                                        <div className="flex-1">
                                            <IntentText className="text-sm font-medium">Run "{query}"</IntentText>
                                            <StateText className="text-xs opacity-50">Execute command in root terminal</StateText>
                                        </div>
                                        <ArrowRight className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                    </Command.Item>
                                </Command.Group>

                                <Command.Group heading={<OrientingText className="px-2 py-2 text-[10px] opacity-50 uppercase tracking-widest">Global Index Results</OrientingText>}>
                                    {searchResults
                                        .filter(item => item.title.toLowerCase().includes(query.toLowerCase()))
                                        .map(item => (
                                        <Command.Item
                                            key={item.id}
                                            onSelect={() => handleSelect(item.path)}
                                            className="flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer hover:bg-white/5 group aria-selected:bg-white/5"
                                        >
                                            <div className="w-8 h-8 rounded bg-neutral-900 border border-white/5 flex items-center justify-center">
                                                <Search className="w-4 h-4 text-neutral-500" />
                                            </div>
                                            <div className="flex-1">
                                                <IntentText className="text-sm font-medium">{item.title}</IntentText>
                                                <StateText className="text-xs opacity-50">{item.subtitle}</StateText>
                                            </div>
                                            <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-50 -translate-x-2 group-hover:translate-x-0 transition-all text-neutral-500" />
                                        </Command.Item>
                                    ))}
                                </Command.Group>
                            </>
                        )}

                        <Command.Group heading={<OrientingText className="px-2 py-2 text-[10px] opacity-50 uppercase tracking-widest">Modules • {domainData?.family?.toUpperCase()}</OrientingText>}>
                            {[
                                { name: 'Studio', icon: Box, path: 'Studio', desc: 'Creative Matrix', families: ['Xibalba', 'XI-IO'] },
                                { name: 'Communications', icon: Users, path: 'Communications', desc: 'Global Message Matrix', families: ['XI-IO', 'Numerical'] },
                                { name: 'Content Manager', icon: FileCode, path: 'ContentManager', desc: 'Site Builder', families: ['Xibalba', 'Veilrift'] },
                                { name: 'Console', icon: Terminal, path: 'Console', desc: 'System Control', families: ['Veilrift', 'XI-IO'] },
                                { name: 'Identity', icon: Users, path: 'Identity', desc: 'Credentials & Trust', families: ['XI-IO'] },
                                { name: 'User Profile', icon: Users, path: 'UserProfile', desc: 'Personal Preferences', families: ['Xibalba', 'Veilrift', 'XI-IO', 'Numerical'] },
                                { name: 'Network', icon: Globe, path: 'Network', desc: 'Node Topology & Health', families: ['XI-IO', 'Veilrift'] },
                                { name: 'Marketplace', icon: ShoppingBag, path: 'Marketplace', desc: 'System Extensions', families: ['Xibalba', 'XI-IO'] },
                                { name: 'Automation', icon: CircuitBoard, path: 'Automation', desc: 'Workflow Orchestration', families: ['Veilrift', 'XI-IO'] },
                                { name: 'MVP Control', icon: Server, path: 'ControlPanel', desc: 'External Integration', families: ['XI-IO'] },
                            ]
                            .sort((a, b) => {
                                // Prioritize modules that match the current family
                                const aMatch = a.families?.includes(domainData?.family) ? 1 : 0;
                                const bMatch = b.families?.includes(domainData?.family) ? 1 : 0;
                                return bMatch - aMatch;
                            })
                            .map((item) => (
                                <Command.Item
                                    key={item.path}
                                    onSelect={() => handleSelect(item.path)}
                                    className="flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer hover:bg-white/5 group aria-selected:bg-white/5"
                                >
                                    <div className="w-8 h-8 rounded bg-neutral-900 border border-white/5 flex items-center justify-center group-hover:border-[hsl(var(--color-active))] transition-colors">
                                        <item.icon className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                    </div>
                                    <div className="flex-1">
                                        <IntentText className="text-sm font-medium">{item.name}</IntentText>
                                        <StateText className="text-xs opacity-50">{item.desc}</StateText>
                                    </div>
                                    <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-50 -translate-x-2 group-hover:translate-x-0 transition-all text-neutral-500" />
                                </Command.Item>
                            ))}
                        </Command.Group>

                        <Command.Group heading={<OrientingText className="px-2 py-2 text-[10px] opacity-50 uppercase tracking-widest">System Actions</OrientingText>}>
                            <Command.Item className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer hover:bg-white/5 opacity-50">
                                <SemanticDot type="warning" />
                                <StateText>Purge Cache (Requires Admin)</StateText>
                            </Command.Item>
                            <Command.Item className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer hover:bg-white/5 opacity-50">
                                <SemanticDot type="error" />
                                <StateText>Emergency Lockdown</StateText>
                            </Command.Item>
                        </Command.Group>
                    </Command.List>
                </Command>
            )}
        </div>
    </div>
  );
};