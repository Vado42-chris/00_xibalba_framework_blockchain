// components/ui/HallbergGraph.js
import React from 'react';
import { theme } from './design-system/design-tokens';

// Generate smooth Bézier curve path
const generateSmoothPath = (points) => {
  if (points.length < 2) return '';
  
  let path = `M ${points[0].x},${points[0].y}`;
  
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1];
    const curr = points[i];
    const next = points[i + 1];
    
    if (next) {
      // Smooth curve using control points
      const cp1x = prev.x + (curr.x - prev.x) * 0.5;
      const cp1y = prev.y;
      const cp2x = curr.x - (next.x - curr.x) * 0.5;
      const cp2y = curr.y;
      
      path += ` C ${cp1x},${cp1y} ${cp2x},${cp2y} ${curr.x},${curr.y}`;
    } else {
      path += ` L ${curr.x},${curr.y}`;
    }
  }
  
  return path;
};

export const HallbergGraph = ({
  data = [],
  width = 800,
  height = 300,
  color = theme.colors['accent-secondary'],
  showArea = true,
  className = '',
}) => {
  if (!data || data.length === 0) return null;

  // Normalize data to fit within dimensions
  const maxX = Math.max(...data.map(d => d.x));
  const maxY = Math.max(...data.map(d => d.y));
  const minY = Math.min(...data.map(d => d.y));
  
  const normalizedData = data.map((point) => ({
    ...point,
    x: (point.x / (maxX || 1)) * width,
    y: height - ((point.y - minY) / ((maxY - minY) || 1)) * height * 0.8 - height * 0.1,
  }));

  const pathData = generateSmoothPath(normalizedData);
  const areaPath = showArea 
    ? `${pathData} L ${normalizedData[normalizedData.length - 1].x},${height} L ${normalizedData[0].x},${height} Z`
    : '';

  return (
    <svg
      width="100%"
      height="100%"
      viewBox={`0 0 ${width} ${height}`}
      preserveAspectRatio="none"
      className={`hallberg-graph ${className}`}
      style={{
        background: 'transparent',
      }}
    >
      {/* Area fill */}
      {showArea && (
        <path
          d={areaPath}
          fill={color}
          opacity="0.2"
        />
      )}
      
      {/* Main curve */}
      <path
        d={pathData}
        fill="none"
        stroke={color}
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      
      {/* Data points */}
      {normalizedData.map((point, index) => (
        <g key={index}>
          <circle
            cx={point.x}
            cy={point.y}
            r="4"
            fill={color}
            style={{ cursor: 'pointer' }}
          />
          {point.label && (
            <text
              x={point.x}
              y={point.y - 10}
              textAnchor="middle"
              fill={theme.colors['text-primary']}
              fontSize="10"
            >
              {point.label}
            </text>
          )}
        </g>
      ))}
    </svg>
  );
};