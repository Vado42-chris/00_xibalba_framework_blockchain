// components/ui/FluidFlowContainer.js
import React, { useMemo, useState, useEffect, useRef } from 'react';
import { theme } from './design-system/design-tokens';

// Hallberg Maths layout algorithm
const calculateFluidLayout = (items, containerWidth, containerHeight) => {
  const PHI = 1.618033988749895;
  
  return items.map((item, index) => {
    const importance = item.importance ?? 0.5;
    const sizeMultiplier = item.size === 'large' ? 1.5 : item.size === 'small' ? 0.75 : 1;
    
    // Calculate position using golden ratio spacing
    const goldenAngle = (index * PHI * 180) % 360;
    // Scale radius by importance and container size, reduced base radius for better packing
    const radius = (importance * 0.2 + 0.1) * Math.min(containerWidth, containerHeight);
    
    const centerX = containerWidth / 2;
    const centerY = containerHeight / 2;
    
    const x = centerX + radius * Math.cos((goldenAngle * Math.PI) / 180);
    const y = centerY + radius * Math.sin((goldenAngle * Math.PI) / 180);
    
    // Size based on importance and size prop
    const baseSize = 200;
    const width = baseSize * sizeMultiplier * (0.7 + importance * 0.6);
    const height = width * (1 / PHI); // Maintain golden ratio aspect
    
    // Clamp to boundaries
    const safeX = Math.max(0, Math.min(x - width / 2, containerWidth - width));
    const safeY = Math.max(0, Math.min(y - height / 2, containerHeight - height));

    return {
      ...item,
      position: { x: safeX, y: safeY },
      size: { width, height },
    };
  });
};

export const FluidFlowContainer = ({
  items = [],
  className = '',
  style = {},
}) => {
  const [containerSize, setContainerSize] = useState({ width: 1200, height: 800 });
  const containerRef = useRef(null);

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
            setContainerSize({ width: rect.width, height: rect.height });
        }
      }
    };
    
    updateSize();
    const observer = new ResizeObserver(updateSize);
    if (containerRef.current) observer.observe(containerRef.current);
    
    return () => observer.disconnect();
  }, []);

  const layout = useMemo(
    () => calculateFluidLayout(items, containerSize.width, containerSize.height),
    [items, containerSize]
  );

  return (
    <div
      ref={containerRef}
      className={`fluid-flow-container ${className}`}
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        minHeight: '600px',
        overflow: 'hidden',
        ...style,
      }}
    >
      {layout.map((item) => (
        <div
          key={item.id}
          style={{
            position: 'absolute',
            left: `${item.position.x}px`,
            top: `${item.position.y}px`,
            width: `${item.size.width}px`,
            height: `${item.size.height}px`,
            transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
            zIndex: item.importance ? Math.floor(item.importance * 10) : 1
          }}
        >
          {item.content}
        </div>
      ))}
    </div>
  );
};