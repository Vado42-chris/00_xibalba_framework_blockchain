import React from 'react';
import { useAuthority } from '@/components/useAuthority';
import { Shield } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function AuthorityChip() {
  const { role, scope, assumeAuthority, releaseAuthority } = useAuthority();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="hidden lg:flex items-center gap-4 px-4 border-l border-white/5 select-none hover:bg-white/5 transition-colors h-full">
          <div className="flex flex-col items-start">
             <span className="text-[9px] text-neutral-500 uppercase tracking-widest leading-none mb-0.5">Acting As</span>
             <span className={`text-[10px] font-bold uppercase tracking-wider ${role === 'OBSERVER' ? 'text-[hsl(var(--color-warning))]' : 'text-[hsl(var(--color-execution))]'}`}>
                {role}
             </span>
          </div>
          <div className="flex flex-col items-start">
             <span className="text-[9px] text-neutral-500 uppercase tracking-widest leading-none mb-0.5">Scope</span>
             <span className="text-[10px] text-neutral-200 font-bold uppercase tracking-wider">{scope}</span>
          </div>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56 bg-black/80 backdrop-blur-xl border-white/10 text-neutral-200 shadow-2xl">
        <DropdownMenuLabel className="text-[10px] uppercase tracking-widest text-neutral-500 font-bold px-2 py-2">Identity Context</DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-white/10" />
        <DropdownMenuItem onClick={() => assumeAuthority('ROOT_ADMIN', 'HOME_CORE')} className="text-xs font-mono focus:bg-[hsl(var(--color-execution))]/10 focus:text-[hsl(var(--color-execution))] cursor-pointer py-2">
          <Shield className="w-3 h-3 mr-2 text-[hsl(var(--color-execution))]" />
          <span className="font-bold">Assume Root</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => assumeAuthority('SYS_AUDITOR', 'READ_ALL')} className="text-xs font-mono focus:bg-white/5 focus:text-white cursor-pointer py-2">
          <Shield className="w-3 h-3 mr-2 text-neutral-500" />
          Assume Auditor
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-white/10" />
        <DropdownMenuItem onClick={releaseAuthority} className="text-xs font-mono focus:bg-[hsl(var(--color-error))]/10 focus:text-[hsl(var(--color-error))] cursor-pointer text-[hsl(var(--color-warning))] py-2">
          Release Authority
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}