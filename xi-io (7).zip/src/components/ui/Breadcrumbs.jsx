import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { cn } from '@/components/ui/utils';
import { createPageUrl } from '@/utils';
import { BookmarkToggle } from '@/components/features/BookmarkSystem';

export function Breadcrumbs() {
    const location = useLocation();
    const pathnames = location.pathname.split('/').filter((x) => x);
    const currentPageName = pathnames.length > 0 
        ? pathnames[pathnames.length - 1].charAt(0).toUpperCase() + pathnames[pathnames.length - 1].slice(1)
        : 'Home';

    // Color Mapping System
    const getSectionColor = (path) => {
        const p = path.toLowerCase();
        if (p.includes('household')) return 'text-emerald-500';
        if (p.includes('finance')) return 'text-amber-500';
        if (p.includes('health')) return 'text-rose-500';
        if (p.includes('entertainment')) return 'text-purple-500';
        if (p.includes('workroom')) return 'text-blue-500';
        if (p.includes('legal')) return 'text-slate-400';
        if (p.includes('crm')) return 'text-blue-400';
        if (p.includes('intelligence')) return 'text-violet-500';
        if (p.includes('commerce')) return 'text-orange-500';
        if (p.includes('communications')) return 'text-yellow-500';
        if (p.includes('studio')) return 'text-pink-500';
        if (p.includes('automation')) return 'text-cyan-500';
        if (p.includes('marketplace')) return 'text-rose-600';
        if (p.includes('reaperspace')) return 'text-purple-600';
        return 'text-neutral-200'; // Default
    };

    const sectionColor = pathnames.length > 0 ? getSectionColor(pathnames[0]) : 'text-white';
    
    // Sample Context Tags based on Section
    const getContextTags = (section) => {
        const s = (section || '').toLowerCase();
        if (s === 'marketplace') return ['Modules', 'Packs', 'Services', 'AI'];
        if (s === 'finance') return ['Crypto', 'Fiat', 'Stocks', 'Banks'];
        if (s === 'crm') return ['Customers', 'Leads', 'Tickets', 'Pipeline'];
        if (s === 'agents') return ['Active', 'Idle', 'Training', 'Logs'];
        return null;
    };
    
    const currentTags = getContextTags(pathnames[0]);

    return (
        <div className="w-full border-b border-white/5 mb-6 bg-neutral-900/20">
            <div className="px-6 py-3 flex items-center justify-between text-xs font-mono animate-in fade-in slide-in-from-top-2 duration-500">
                <div className="flex items-center gap-2">
                    <Link 
                        to={createPageUrl('Home')} 
                        className="flex items-center gap-2 text-neutral-600 hover:text-white transition-colors group"
                    >
                        <div className="p-1 rounded bg-neutral-900 border border-white/5 group-hover:border-white/20 transition-colors">
                            <Home className="w-3 h-3" />
                        </div>
                        <span className="opacity-50 group-hover:opacity-100 transition-opacity">ROOT</span>
                    </Link>
                    
                    {pathnames.map((value, index) => {
                        const to = `/${pathnames.slice(0, index + 1).join('/')}`;
                        const isLast = index === pathnames.length - 1;
                        const name = value.charAt(0).toUpperCase() + value.slice(1);
                        const isRootSection = index === 0;

                        return (
                            <div key={to} className="flex items-center">
                                <ChevronRight className="w-3 h-3 mx-1 text-neutral-700" />
                                {isLast ? (
                                    <div className={cn(
                                        "px-2 py-0.5 rounded border bg-neutral-900/50 backdrop-blur-sm uppercase tracking-wider font-bold shadow-sm flex items-center gap-2",
                                        "border-white/10",
                                        sectionColor
                                    )}>
                                        {isRootSection && <div className={cn("w-1.5 h-1.5 rounded-full animate-pulse", sectionColor.replace('text-', 'bg-'))} />}
                                        {name}
                                    </div>
                                ) : (
                                    <Link 
                                        to={to} 
                                        className={cn(
                                            "hover:text-white transition-colors uppercase tracking-wider px-1",
                                            isRootSection ? sectionColor : "text-neutral-500"
                                        )}
                                    >
                                        {name}
                                    </Link>
                                )}
                            </div>
                        );
                    })}
                </div>
                
                {pathnames.length > 0 && (
                    <div className="flex items-center gap-4">
                         {/* Prominent Tags Display */}
                         {currentTags && (
                             <div className="hidden xl:flex items-center gap-2 mr-4 border-r border-white/5 pr-4">
                                 {currentTags.map(tag => (
                                     <div key={tag} className="px-2 py-0.5 rounded-full bg-white/5 border border-white/5 text-[10px] text-neutral-500 hover:text-white hover:border-white/20 cursor-pointer transition-colors">
                                         {tag}
                                     </div>
                                 ))}
                             </div>
                         )}

                        <div className="hidden md:flex items-center gap-2 text-[10px] text-neutral-600">
                            <span>PATH:</span>
                            <span className="text-neutral-500">/root/{pathnames.join('/')}</span>
                        </div>
                        <div className="h-3 w-px bg-white/10" />
                        <div className="scale-110">
                            <BookmarkToggle title={currentPageName} />
                        </div>
                    </div>
                )}
            </div>
            {/* Visual Separator Line (Gradient) */}
            <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-white/10 to-transparent" />
        </div>
    );
}