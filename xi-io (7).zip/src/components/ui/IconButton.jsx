import React from 'react';
import { Button } from "@/components/ui/button";
import { cn } from "@/components/ui/utils";
import { 
    Tooltip,
    TooltipContent,
    TooltipProvider,
    TooltipTrigger,
} from "@/components/ui/tooltip";

export const IconButton = React.forwardRef(({ 
    icon: Icon, 
    label, 
    onClick, 
    className, 
    variant = "ghost",
    size = "icon",
    active = false,
    badge,
    ...props 
}, ref) => {
    if (!Icon) return null;

    return (
        <TooltipProvider>
            <Tooltip delayDuration={300}>
                <TooltipTrigger asChild>
                    <Button
                        ref={ref}
                        variant={variant}
                        size={size}
                        onClick={onClick}
                        className={cn(
                            "relative transition-all duration-200",
                            active && "text-[hsl(var(--color-active))] bg-[hsl(var(--color-active))]/10 border-white/10",
                            className
                        )}
                        aria-label={label}
                        {...props}
                    >
                        <Icon className={cn(
                            "w-4 h-4",
                            active && "animate-pulse" // Subtle pulse when active
                        )} />
                        {badge && (
                            <span className="absolute -top-1 -right-1 flex h-3 w-3 items-center justify-center rounded-full bg-[hsl(var(--color-notification))] text-[8px] text-white">
                                {badge}
                            </span>
                        )}
                    </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="text-xs bg-neutral-900 border-white/10 text-neutral-300">
                    {label}
                </TooltipContent>
            </Tooltip>
        </TooltipProvider>
    );
});

IconButton.displayName = "IconButton";