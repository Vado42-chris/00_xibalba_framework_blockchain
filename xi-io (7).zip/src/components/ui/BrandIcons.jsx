import React from 'react';
import { 
    Github, Slack, Figma, Instagram, Youtube, 
    Twitter, Linkedin, Facebook, Disc, 
    Box, Cloud, Command, Cpu, CreditCard, 
    Database, Globe, Layout, Mail, MessageSquare, 
    Music, ShoppingBag, ShoppingCart, Terminal, 
    Video, Zap 
} from 'lucide-react';

export const BrandIcon = ({ id, className, ...props }) => {
    // Map IDs to specific SVG paths (Simple Icons / Brand Vectors)
    const icons = {
        google_calendar: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M19 4h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z"/>
            </svg>
        ),
        google_drive: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M7.71 3.5L1.15 15l3.43 6h13.72l-3.43-6H7.71zm8.58 6l-3.43 6H5.15L8.58 9.5h7.71zm-1.15 2L12 17.5 15.15 12h-3.01z" fillRule="evenodd" clipRule="evenodd"/>
                <path d="M7.71 3.5L1.15 15l3.43 6h13.72l-3.43-6H7.71z" fill="none" stroke="currentColor" strokeWidth="2"/>
            </svg>
        ),
        notion: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M4.021 21.995l-1.01-1.028L3 5.37l1.328-.33 2.502.553v11.7l6.634-11.37 1.258-.337 5.727.61v15.06l.943.918-.028 1.83-5.203.37-.962-.976V8.655l-6.722 11.87-1.328.322-5.127-.523.028-1.328h-.028z"/>
            </svg>
        ),
        salesforce: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M16.1 9c.6 0 1.1-.2 1.6-.5.9-1.5.7-3.5-.6-4.7-1.3-1.2-3.3-1.3-4.7-.2-.5-.3-1-.4-1.6-.4-2.1 0-3.9 1.6-4.1 3.7-.3 0-.6-.1-1-.1-2.2 0-4 1.8-4 4s1.8 4 4 4c.3 0 .6 0 .9-.1.5 1.7 2.3 2.9 4.4 2.9 1.9 0 3.6-1.1 4.3-2.6.4.1.8.2 1.2.2 2.2 0 4-1.8 4-4s-1.8-4-4-4z"/>
            </svg>
        ),
        hubspot: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M19.5 6.75c1.24 0 2.25 1.01 2.25 2.25s-1.01 2.25-2.25 2.25-2.25-1.01-2.25-2.25 1.01-2.25 2.25-2.25zM4.5 18c1.24 0 2.25 1.01 2.25 2.25S5.74 22.5 4.5 22.5 2.25 21.49 2.25 20.25 3.26 18 4.5 18zm7.5-6c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 1.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5zm7.5 3c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5zm-15 1.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5z"/>
            </svg>
        ),
        shopify: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M20.7 7.7l-1.4-4.8c-.1-.4-.6-.7-1-.5l-5.6 2.4L9.4 3.1c-.2-.3-.6-.4-1-.2L2.7 5.6c-.4.1-.6.6-.5 1l2.4 11.9c.2.9 1 1.5 1.9 1.5h10.9c.9 0 1.7-.6 1.9-1.5l1.9-9.3c.1-.4-.2-.9-.6-1zM12 16c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2z"/>
            </svg>
        ),
        woocommerce: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M21.6 12.2c.1-1.3-.3-2.6-1.1-3.7-.8-1-1.9-1.7-3.2-2-1.3-.2-2.6.1-3.7.9-.6.4-1.1.9-1.5 1.5-.4-.6-.9-1.1-1.5-1.5-1.1-.8-2.4-1.1-3.7-.9-1.3.2-2.4 1-3.2 2-.8 1.1-1.2 2.4-1.1 3.7.1 1.3.6 2.5 1.5 3.4l.4.4c.1.1.2.1.4.1.3 0 .5-.2.5-.5 0-.1-.1-.3-.2-.4-.7-.7-1.1-1.6-1.2-2.6-.1-1 .2-2 .8-2.8.6-.8 1.5-1.3 2.5-1.5 1-.1 2 .1 2.8.7.4.3.7.7 1 1.2.1.2.2.3.4.3s.3-.1.4-.3c.3-.5.6-.9 1-1.2.8-.6 1.8-.9 2.8-.7 1 .1 1.9.7 2.5 1.5.6.8.9 1.8.8 2.8-.1 1-.5 1.9-1.2 2.6-.1.1-.2.3-.2.4 0 .3.2.5.5.5.1 0 .3-.1.4-.1.9-.9 1.4-2.1 1.5-3.4z"/>
            </svg>
        ),
        adobe: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M15.1 2H22v20h-6.9L15.1 2zM8.9 2H2v20h6.9L8.9 2zM12 9.6L9.6 15h4.8L12 9.6zM12 2l-2.9 6.4h5.8L12 2z"/>
            </svg>
        ),
        linear: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v10h-2z"/>
            </svg>
        ),
        aws: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M16.2 13.7c-.5.9-1.2 1.6-2.1 2.1-1.1.6-2.4.7-3.7.3-1.3-.4-2.4-1.4-3-2.6-.6-1.2-.6-2.6-.1-3.8.5-1.2 1.5-2.1 2.8-2.6 1.3-.5 2.7-.4 3.9.2.9.5 1.7 1.3 2.1 2.3l-1.6 1c-.3-.6-.8-1-1.4-1.2-.7-.3-1.5-.3-2.2 0-.7.3-1.2.8-1.5 1.5-.3.7-.3 1.5 0 2.2.3.7.8 1.2 1.5 1.5.7.3 1.5.3 2.2 0 .5-.2.9-.6 1.2-1.1l1.9.2zM19.1 17.6c-1.4 1.1-3 1.9-4.8 2.2-1.8.3-3.6.2-5.3-.3-1.7-.5-3.3-1.4-4.6-2.6l1.2-1.2c1.1 1 2.4 1.7 3.8 2.1 1.4.4 2.9.5 4.3.2 1.4-.3 2.8-.9 3.9-1.8l1.5 1.4z"/>
            </svg>
        ),
        vercel: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M12 1L24 22H0L12 1z"/>
            </svg>
        ),
        stripe: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M13.9 10.3c0-.8-.7-1.3-2.1-1.3-3.2 0-3.3 2.2-1.1 2.5 2.5.4 2.7 2.6.3 2.9-3.7.4-3.7-2.7-1.2-2.9v-2c-2.7.3-3.7 2.6-3.7 4.7 0 3 2.7 4.2 5.5 3.8 3.5-.5 3.5-3.1 1.1-3.4-2.2-.3-2.5-2.2-.3-2.5 3.2-.4 3.2 2.3 1.2 2.5v2c2.9-.4 3.7-2.5 3.7-4.5 0-2.8-2.6-4.1-5.4-3.7z"/>
            </svg>
        ),
        quickbooks: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h-2v-2h2v2zm4 0h-2v-6h2v6zm-4-4h-2V7h2v6z"/>
            </svg>
        ),
        xero: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2"/>
                <path d="M16 8l-8 8M8 8l8 8" stroke="currentColor" strokeWidth="2"/>
            </svg>
        ),
        openai: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M20.9 10.2c-.3-1.6-1.4-3-2.9-3.7-.1-.6-.3-1.2-.6-1.7-.9-1.6-2.5-2.6-4.3-2.8-1.8-.2-3.6.5-4.9 1.8-.5-.2-1.1-.3-1.7-.3-1.8.1-3.5 1-4.6 2.5-.3.4-.5.9-.7 1.4-1.6.3-3 1.4-3.7 2.9-.6 1.4-.5 3 .3 4.3-.2.5-.3 1.1-.3 1.7.1 1.8 1 3.5 2.5 4.6.4.3.9.5 1.4.7.3 1.6 1.4 3 2.9 3.7.6.3 1.2.4 1.8.4 1.6 0 3.1-.8 4-2.1.5.2 1.1.3 1.7.3 1.8-.1 3.5-1 4.6-2.5.3-.4.5-.9.7-1.4 1.6-.3 3-1.4 3.7-2.9.7-1.4.6-3-.2-4.3.2-.5.3-1.1.3-1.7-.2-1.8-1.1-3.5-2.6-4.6zM13.6 17.5c-.7.9-1.7 1.5-2.8 1.6-1.1.1-2.2-.3-3.1-1.1l1.1-1.9c.5.5 1.1.7 1.8.6.6-.1 1.2-.4 1.6-.9l1.4 1.7zm-2.8-2.9c-.4.2-.9.2-1.3-.1-.4-.2-.6-.6-.6-1.1 0-.4.2-.9.6-1.1.4-.2.9-.2 1.3.1.4.2.6.6.6 1.1 0 .4-.2.9-.6 1.1zm-4.5-2.3c-.9-.7-1.5-1.7-1.6-2.8-.1-1.1.3-2.2 1.1-3.1l1.9 1.1c-.5.5-.7 1.1-.6 1.8.1.6.4 1.2.9 1.6l-1.7 1.4zm5.7-5.7c.7-.9 1.7-1.5 2.8-1.6 1.1-.1 2.2.3 3.1 1.1l-1.1 1.9c-.5-.5-1.1-.7-1.8-.6-.6.1-1.2.4-1.6.9l-1.4-1.7zm4.5 2.3c.9.7 1.5 1.7 1.6 2.8.1 1.1-.3 2.2-1.1 3.1l-1.9-1.1c.5-.5.7-1.1.6-1.8-.1-.6-.4-1.2-.9-1.6l1.7-1.4z"/>
            </svg>
        ),
        anthropic: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M18.5 3h-13C4.1 3 3 4.1 3 5.5v13C3 19.9 4.1 21 5.5 21h13c1.4 0 2.5-1.1 2.5-2.5v-13C21 4.1 19.9 3 18.5 3zM7 16l3-8 3 8H7z"/>
            </svg>
        ),
        discord: (
            <svg viewBox="0 0 24 24" fill="currentColor" className={className} {...props}>
                <path d="M19.2 5.6c-.9-.4-1.9-.7-2.9-.9 0 0-.2.4-.4.8-1-.1-2.1-.1-3.1 0-.2-.4-.4-.8-.4-.8-1 .2-2 .5-2.9.9-1.9 2.8-2.4 5.5-2.4 8.2 1.2 1 2.3 1.5 3.5 1.9.3-.4.6-.8.8-1.2-1.3-.4-1.7-1.1-1.7-1.1.1.1.3.1.4.2 2.6 1.2 5.4 1.2 7.9 0 .1-.1.2-.1.4-.2 0 0-.5.7-1.7 1.1.3.4.5.8.8 1.2 1.1-.3 2.3-.9 3.5-1.9.1-3.2-.4-5.9-2.2-8.2zM8.5 14.3c-.7 0-1.3-.6-1.3-1.4 0-.8.6-1.4 1.3-1.4.8 0 1.3.6 1.3 1.4 0 .8-.6 1.4-1.3 1.4zm7 0c-.7 0-1.3-.6-1.3-1.4 0-.8.6-1.4 1.3-1.4.8 0 1.3.6 1.3 1.4 0 .8-.6 1.4-1.3 1.4z"/>
            </svg>
        ),
        // Fallbacks using Lucide for some
        slack: <Slack className={className} {...props} />,
        github: <Github className={className} {...props} />,
        figma: <Figma className={className} {...props} />,
        instagram: <Instagram className={className} {...props} />,
        youtube: <Youtube className={className} {...props} />,
        twitter: <Twitter className={className} {...props} />,
        linkedin: <Linkedin className={className} {...props} />,
        
        // Generics as fallback or for unlisted
        default: <Zap className={className} {...props} />
    };

    return icons[id] || icons.default;
};