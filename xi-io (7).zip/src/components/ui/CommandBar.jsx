// components/ui/CommandBar.js
import React, { useState, useEffect, useRef } from 'react';
import { GlassPanel } from './GlassPanel';
import { theme } from './design-system/design-tokens';

export const CommandBar = ({
  isOpen,
  onClose,
  onExecute,
  results = [],
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef(null);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (!isOpen) {
        if (e.key === '/' && !e.ctrlKey && !e.metaKey && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
          e.preventDefault();
          // Trigger open (handled by parent usually, but this is a global listener)
          // For now we rely on parent passing isOpen=true
        }
        return;
      }

      switch (e.key) {
        case 'Escape':
          onClose();
          break;
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex((prev) => Math.min(prev + 1, (results.length > 0 ? results.length : 0) - 1));
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex((prev) => Math.max(prev - 1, 0));
          break;
        case 'Enter':
          e.preventDefault();
          if (results[selectedIndex]) {
            results[selectedIndex].action();
            onClose();
          } else if (query.trim() && onExecute) {
            onExecute(query);
            onClose();
          }
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, query, selectedIndex, onClose, onExecute, results]);

  const filteredResults = results.filter((result) =>
    result.title.toLowerCase().includes(query.toLowerCase()) ||
    (result.description && result.description.toLowerCase().includes(query.toLowerCase()))
  );

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: '20%',
        left: '50%',
        transform: 'translateX(-50%)',
        width: '600px',
        maxWidth: '90vw',
        zIndex: theme.zIndex['command-bar'],
      }}
    >
      <GlassPanel variant="heavy" padding="md">
        <div style={{ display: 'flex', flexDirection: 'column', gap: theme.spacing.md }}>
          {/* Search Input */}
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Type a command, search, or ask AI..."
            style={{
              width: '100%',
              padding: `${theme.spacing.sm} ${theme.spacing.md}`,
              background: 'rgba(255, 255, 255, 0.03)',
              border: `1px solid ${theme.colors['glass-border-light']}`,
              borderRadius: theme.rounding.pill,
              color: theme.colors['text-primary'],
              fontFamily: theme.typography['font-family'],
              fontSize: theme.typography['size-base'],
              outline: 'none',
              transition: theme.motion.fast,
            }}
            onFocus={(e) => {
              e.target.style.borderColor = theme.colors['accent-primary'];
              e.target.style.boxShadow = theme.shadows['glow-primary'];
            }}
            onBlur={(e) => {
              e.target.style.borderColor = theme.colors['glass-border-light'];
              e.target.style.boxShadow = 'none';
            }}
          />

          {/* Results List */}
          {filteredResults.length > 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: theme.spacing.xs }}>
              {filteredResults.slice(0, 8).map((result, index) => (
                <div
                  key={result.id}
                  onClick={() => {
                    result.action();
                    onClose();
                  }}
                  style={{
                    padding: theme.spacing.md,
                    background: index === selectedIndex 
                      ? 'rgba(138, 92, 246, 0.15)' 
                      : 'transparent',
                    borderRadius: theme.rounding.medium,
                    cursor: 'pointer',
                    transition: theme.motion.fast,
                    border: index === selectedIndex 
                      ? `1px solid ${theme.colors['accent-primary']}` 
                      : '1px solid transparent',
                  }}
                  onMouseEnter={() => setSelectedIndex(index)}
                >
                  <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: theme.spacing.sm 
                  }}>
                    {result.icon && (
                      <span style={{ fontSize: theme.typography['size-md'] }}>
                        {result.icon}
                      </span>
                    )}
                    <div style={{ flex: 1 }}>
                      <div style={{ 
                        color: theme.colors['text-primary'],
                        fontWeight: theme.typography['weight-medium'],
                      }}>
                        {result.title}
                      </div>
                      {result.description && (
                        <div style={{ 
                          color: theme.colors['text-secondary'],
                          fontSize: theme.typography['size-sm'],
                          marginTop: theme.spacing.xs,
                        }}>
                          {result.description}
                        </div>
                      )}
                    </div>
                    <div style={{ 
                      color: theme.colors['text-accent'],
                      fontSize: theme.typography['size-xs'],
                      textTransform: 'uppercase',
                    }}>
                      {result.type}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* AI Prompt Hint */}
          {query.trim() && filteredResults.length === 0 && (
            <div style={{
              padding: theme.spacing.md,
              color: theme.colors['text-secondary'],
              fontSize: theme.typography['size-sm'],
              textAlign: 'center',
            }}>
              Press Enter to send as AI prompt
            </div>
          )}
        </div>
      </GlassPanel>
    </div>
  );
};