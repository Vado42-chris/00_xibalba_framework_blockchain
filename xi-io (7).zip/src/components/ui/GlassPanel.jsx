// components/ui/GlassPanel.js
import React from 'react';
import { theme, hallbergProfiles } from './design-system/design-tokens';

export const GlassPanel = ({
  children,
  variant = 'medium',
  padding = 'md',
  profile,
  className = '',
  onClick,
  style = {},
  ...props
}) => {
  const glasnostStyle = theme.glasnost[variant] || theme.glasnost.medium;
  const paddingValue = theme.spacing[padding] || theme.spacing.md;
  
  // Use Hallberg profile if specified, otherwise use variant's default
  const borderRadius = profile 
    ? hallbergProfiles[profile]
    : glasnostStyle.borderRadius;

  const baseStyle = {
    ...glasnostStyle,
    padding: paddingValue,
    borderRadius,
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    cursor: onClick ? 'pointer' : 'default',
    ...style,
  };

  return (
    <div
      className={`glass-panel glass-panel-${variant} ${className}`}
      style={baseStyle}
      onClick={onClick}
      onMouseEnter={(e) => {
        if (onClick) {
          e.currentTarget.style.transform = 'translateY(-2px)';
          e.currentTarget.style.boxShadow = theme.shadows['glass-heavy'];
        }
      }}
      onMouseLeave={(e) => {
        if (onClick) {
          e.currentTarget.style.transform = 'translateY(0)';
          e.currentTarget.style.boxShadow = glasnostStyle.boxShadow;
        }
      }}
      {...props}
    >
      {children}
    </div>
  );
};