// components/ui/GraphicalIntelligenceDashboard.js
import React, { useState, useRef, useEffect } from 'react';
import { GlassPanel } from './GlassPanel';
import { theme } from './design-system/design-tokens';

export const GraphicalIntelligenceDashboard = ({
  nodes = [],
  edges = [],
  focusNodeId,
  onNodeClick,
  className = '',
}) => {
  const svgRef = useRef(null);
  const [viewBox, setViewBox] = useState({ x: 0, y: 0, width: 1200, height: 800 });

  // Calculate node positions using a simple layout (circular)
  const layoutNodes = (nodes, edges) => {
    const centerX = viewBox.width / 2;
    const centerY = viewBox.height / 2;
    const radius = Math.min(viewBox.width, viewBox.height) * 0.3;
    
    return nodes.map((node, index) => {
      if (node.x !== undefined && node.y !== undefined) {
        return node; // Use provided position
      }
      
      const angle = (index / (nodes.length || 1)) * 2 * Math.PI;
      return {
        ...node,
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      };
    });
  };

  const layoutedNodes = layoutNodes(nodes, edges);

  const getNodeColor = (type) => {
    const colors = {
      person: theme.colors['accent-secondary'],
      project: theme.colors['accent-primary'],
      file: theme.colors['accent-info'],
      concept: theme.colors['accent-warning'],
      company: theme.colors['accent-success'],
    };
    return colors[type] || theme.colors['text-secondary'];
  };

  const getEdgeColor = (type) => {
    const colors = {
      collaborates: theme.colors['accent-secondary'],
      depends: theme.colors['accent-warning'],
      references: theme.colors['accent-info'],
      contains: theme.colors['accent-primary'],
    };
    return colors[type] || theme.colors['text-secondary'];
  };

  return (
    <GlassPanel variant="heavy" padding="none" className={className}>
      <div style={{ width: '100%', height: '600px', position: 'relative' }}>
        <svg
          ref={svgRef}
          viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.width} ${viewBox.height}`}
          style={{
            width: '100%',
            height: '100%',
            background: 'transparent',
          }}
        >
          {/* Render Edges */}
          {edges.map((edge) => {
            const fromNode = layoutedNodes.find(n => n.id === edge.from);
            const toNode = layoutedNodes.find(n => n.id === edge.to);
            if (!fromNode || !toNode || fromNode.x == null || toNode.x == null) return null;

            return (
              <line
                key={edge.id}
                x1={fromNode.x}
                y1={fromNode.y}
                x2={toNode.x}
                y2={toNode.y}
                stroke={getEdgeColor(edge.type)}
                strokeWidth={2 * (edge.strength || 0.5)}
                opacity={0.4 + (edge.strength || 0.5) * 0.4}
                strokeDasharray={edge.type === 'depends' ? '5,5' : 'none'}
              />
            );
          })}

          {/* Render Nodes */}
          {layoutedNodes.map((node) => {
            if (node.x == null || node.y == null) return null;
            const isFocused = node.id === focusNodeId;
            const nodeColor = getNodeColor(node.type);

            return (
              <g key={node.id}>
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={isFocused ? 20 : 12}
                  fill={nodeColor}
                  opacity={isFocused ? 1 : 0.7}
                  style={{ cursor: 'pointer', transition: 'all 0.3s ease' }}
                  onClick={() => onNodeClick?.(node.id)}
                />
                <text
                  x={node.x}
                  y={node.y + 25}
                  textAnchor="middle"
                  fill={theme.colors['text-primary']}
                  fontSize="12"
                  style={{ pointerEvents: 'none', fontFamily: theme.typography['font-family'] }}
                >
                  {node.label}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
    </GlassPanel>
  );
};