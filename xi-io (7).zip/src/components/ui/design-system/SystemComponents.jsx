import React from 'react';
import { cn } from "@/components/ui/utils";
import { 
    IntentText, StateText, SemanticDot, 
    OrientingText
} from '@/components/ui/design-system/SystemDesign';
import { ActionDock } from '@/components/ui/design-system/ActionDock';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { createPageUrl } from '@/utils';

/* -------------------------------------------------------------------------- */
/*                            SYSTEM LIST CARD                                */
/* -------------------------------------------------------------------------- */

export const SystemCard = ({ 
    title, 
    subtitle, 
    icon: Icon, 
    status, 
    metric,
    active = false,
    onClick,
    className,
    children,
    primaryAction,
    secondaryActions = []
}) => {
    return (
        <div 
            onClick={onClick}
            className={cn(
                "group relative p-3 rounded-md border transition-all duration-200 cursor-pointer overflow-hidden flex flex-col",
                active 
                    ? "bg-black/40 backdrop-blur-md border-[hsl(var(--color-intent))] shadow-[0_0_15px_-5px_hsl(var(--color-intent)/0.3)] z-10" 
                    : "bg-black/20 backdrop-blur-sm border-white/5 hover:bg-black/40 hover:border-white/10",
                className
            )}
        >
            {active && <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-[hsl(var(--color-intent))]" />}

            <div className="flex justify-between items-start mb-1 relative z-10">
                <div className="flex items-center gap-3 min-w-0">
                    {Icon && (
                        <div className={cn(
                            "w-8 h-8 rounded flex items-center justify-center shrink-0 transition-colors",
                            active ? "bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))]" : "bg-black/40 text-neutral-500 group-hover:text-neutral-300"
                        )}>
                            <Icon className="w-4 h-4" />
                        </div>
                    )}
                    <div className="min-w-0">
                        <IntentText className={cn("text-sm font-bold truncate", active && "text-[hsl(var(--color-intent))]")}>
                            {title}
                        </IntentText>
                        {subtitle && (
                            <StateText className="text-[10px] opacity-60 truncate">
                                {subtitle}
                            </StateText>
                        )}
                    </div>
                </div>
                
                <div className="flex flex-col items-end shrink-0">
                    {status && <SemanticDot type={status} />}
                    {metric && (
                        <StateText className="text-[10px] font-mono opacity-50 mt-1">
                            {metric}
                        </StateText>
                    )}
                </div>
            </div>

            {children && (
                <div className="mt-2 pl-11 relative z-10 flex-1">
                    {children}
                </div>
            )}

            {(primaryAction || secondaryActions.length > 0) && (
                <div className="mt-auto pl-11 relative z-10">
                    <ActionDock 
                        primaryAction={primaryAction} 
                        secondaryActions={secondaryActions}
                        className="mt-2 pt-2 border-white/5"
                    />
                </div>
            )}

            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none" />
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                            SYSTEM NAV LIST                                 */
/* -------------------------------------------------------------------------- */

export const SystemNav = ({ 
    items = [], 
    activeId, 
    onSelect,
    className 
}) => {
    return (
        <div className={cn("space-y-1", className)}>
            {items.map((item) => {
                const isActive = activeId === item.id;
                const Icon = item.icon;
                
                return (
                    <div 
                        key={item.id}
                        onClick={() => onSelect(item.id)}
                        className={cn(
                            "flex items-center justify-between p-3 rounded-sm border cursor-pointer transition-all group",
                            isActive 
                                ? "bg-black/40 backdrop-blur-md border-white/10" 
                                : "bg-transparent border-transparent hover:bg-black/20 hover:backdrop-blur-sm hover:border-white/5"
                        )}
                    >
                        <div className="flex items-center gap-3">
                            {Icon && (
                                <Icon className={cn(
                                    "w-4 h-4 transition-colors", 
                                    isActive ? "text-white" : "text-neutral-500 group-hover:text-neutral-400"
                                )} />
                            )}
                            <StateText className={cn(
                                "text-xs transition-colors",
                                isActive ? "text-white" : "text-neutral-400 group-hover:text-neutral-300"
                            )}>
                                {item.label}
                            </StateText>
                        </div>
                        
                        <div className="flex items-center gap-3">
                            {item.count !== undefined && (
                                <span className="text-[9px] font-mono text-neutral-600">
                                    {item.count}
                                </span>
                            )}
                            <SemanticDot type={isActive ? 'active' : (item.type || 'settled')} />
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                            SYSTEM DETAIL HEADER                            */
/* -------------------------------------------------------------------------- */

export const SystemDetailHeader = ({ 
    title, 
    subtitle, 
    icon: Icon, 
    category,
    className,
    children,
    addonContext // Pass 'finance', 'crm', etc. to enable "+ Addon" button
}) => {
    return (
        <div className={cn("flex items-start gap-4 mb-6 p-6 border-b border-white/5 bg-neutral-900/20", className)}>
            {Icon && (
                <div className="w-12 h-12 rounded-lg bg-neutral-900 border border-white/10 flex items-center justify-center shadow-lg shrink-0">
                    <Icon className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                </div>
            )}
            <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                    <IntentText className="text-2xl font-light text-white truncate">
                        {title}
                    </IntentText>
                    {category && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded border border-white/10 text-neutral-500 uppercase tracking-wider">
                            {category}
                        </span>
                    )}
                </div>
                <StateText className="text-xs opacity-50">
                    {subtitle}
                </StateText>
            </div>
            <div className="flex items-center gap-2 shrink-0">
                {addonContext && (
                    <Link to={createPageUrl('Marketplace') + `?category=${addonContext}`}>
                        <Button variant="ghost" size="sm" className="h-8 border border-dashed border-white/20 text-neutral-500 hover:text-white hover:bg-white/5 text-[10px] gap-1.5">
                            <Plus className="w-3 h-3" /> Addon
                        </Button>
                    </Link>
                )}
                {children}
            </div>
        </div>
    );
};