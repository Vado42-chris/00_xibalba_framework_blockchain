import React from 'react';
import { cn } from "@/components/ui/utils";

/**
 * Standard Dashboard Layout with Fixed Sidebar
 * Used for pages like Communications, Intelligence, etc.
 * Enforces consistent 280px sidebar and full-height scrollable content.
 */
export const SidebarLayout = ({ sidebar, content, className }) => {
    return (
        <div className={cn("h-full w-full bg-transparent overflow-hidden flex", className)}>
            <div className="w-[280px] border-r border-white/5 flex flex-col bg-black/20 backdrop-blur-lg shrink-0 transition-colors duration-300 hover:bg-black/30">
                {sidebar}
            </div>
            <div className="flex-1 min-w-0 bg-transparent relative flex flex-col">
                {content}
            </div>
        </div>
    );
};

/**
 * Alternative Layout with Right-Side Panel (e.g. for detail views)
 */
export const MasterDetailLayout = ({ master, detail, className }) => {
     return (
        <div className={cn("h-full w-full bg-transparent overflow-hidden flex", className)}>
            <div className="w-[350px] border-r border-white/5 flex flex-col bg-black/10 backdrop-blur-md shrink-0 transition-colors duration-300 hover:bg-black/20">
                {master}
            </div>
            <div className="flex-1 min-w-0 bg-transparent relative flex flex-col">
                {detail}
            </div>
        </div>
    );
};