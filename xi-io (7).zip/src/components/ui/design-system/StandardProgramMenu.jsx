import React from 'react';
import { 
    Menu, 
    MoreHorizontal, 
    Save, 
    FolderOpen, 
    Settings, 
    HelpCircle, 
    LogOut,
    Printer,
    Share2,
    Command,
    ChevronRight,
    Search,
    Undo,
    Redo,
    Maximize,
    Minimize
} from 'lucide-react';
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuLabel, 
    DropdownMenuSeparator, 
    DropdownMenuTrigger,
    DropdownMenuSub,
    DropdownMenuSubTrigger,
    DropdownMenuSubContent,
    DropdownMenuShortcut
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { cn } from "@/components/ui/utils";

/**
 * STANDARD XIBALBA PROGRAM MENU
 * 
 * Provides a consistent "Hamburger" or "Context" menu for all Xibalba apps.
 * 
 * Composition:
 * 1. System Context (App Identity, Version)
 * 2. File Operations (Save, Open, Export)
 * 3. Edit Operations (Undo/Redo - often context specific)
 * 4. View Operations (Zoom, Theme, Layout)
 * 5. App-Specific Actions (Injected via props)
 * 6. Help & System (Docs, Shortcuts, About)
 */
export default function StandardProgramMenu({ 
    appName = "Application", 
    appVersion = "1.0.0",
    onSave,
    onOpen,
    onExport,
    onSettings,
    customItems = [],
    className
}) {
    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button 
                    variant="ghost" 
                    size="icon" 
                    className={cn("h-8 w-8 data-[state=open]:bg-white/10", className)}
                >
                    <Menu className="h-4 w-4" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-64 bg-black/95 border-white/10 text-neutral-200 backdrop-blur-xl">
                
                {/* IDENTITY SECTION */}
                <div className="px-2 py-1.5 text-[10px] font-mono text-neutral-500 flex justify-between uppercase tracking-wider border-b border-white/5 mb-1">
                    <span>{appName}</span>
                    <span>v{appVersion}</span>
                </div>

                {/* PRIMARY ACTIONS */}
                <DropdownMenuLabel>File System</DropdownMenuLabel>
                <DropdownMenuItem onClick={onSave}>
                    <Save className="mr-2 h-3.5 w-3.5" />
                    <span>Save State</span>
                    <DropdownMenuShortcut>⌘S</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onOpen}>
                    <FolderOpen className="mr-2 h-3.5 w-3.5" />
                    <span>Open...</span>
                    <DropdownMenuShortcut>⌘O</DropdownMenuShortcut>
                </DropdownMenuItem>
                
                <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                        <Share2 className="mr-2 h-3.5 w-3.5" />
                        <span>Export / Share</span>
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent className="bg-black/90 border-white/10 text-neutral-200">
                        <DropdownMenuItem onClick={() => onExport?.('pdf')}>Export to PDF</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onExport?.('json')}>Export JSON</DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-white/10" />
                        <DropdownMenuItem>Share Link...</DropdownMenuItem>
                    </DropdownMenuSubContent>
                </DropdownMenuSub>

                <DropdownMenuSeparator className="bg-white/10" />

                {/* EDIT ACTIONS */}
                <DropdownMenuLabel>Edit</DropdownMenuLabel>
                <DropdownMenuItem>
                    <Undo className="mr-2 h-3.5 w-3.5" />
                    <span>Undo</span>
                    <DropdownMenuShortcut>⌘Z</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuItem>
                    <Redo className="mr-2 h-3.5 w-3.5" />
                    <span>Redo</span>
                    <DropdownMenuShortcut>⇧⌘Z</DropdownMenuShortcut>
                </DropdownMenuItem>

                {/* DYNAMIC APP SPECIFIC ITEMS */}
                {customItems.length > 0 && (
                    <>
                        <DropdownMenuSeparator className="bg-white/10" />
                        <DropdownMenuLabel>App Actions</DropdownMenuLabel>
                        {customItems.map((item, idx) => (
                            <DropdownMenuItem key={idx} onClick={item.action} disabled={item.disabled}>
                                {item.icon && <item.icon className="mr-2 h-3.5 w-3.5" />}
                                <span>{item.label}</span>
                                {item.shortcut && <DropdownMenuShortcut>{item.shortcut}</DropdownMenuShortcut>}
                            </DropdownMenuItem>
                        ))}
                    </>
                )}

                <DropdownMenuSeparator className="bg-white/10" />

                {/* VIEW & WINDOW */}
                <DropdownMenuLabel>Window</DropdownMenuLabel>
                <DropdownMenuItem>
                    <Maximize className="mr-2 h-3.5 w-3.5" />
                    <span>Toggle Fullscreen</span>
                    <DropdownMenuShortcut>F11</DropdownMenuShortcut>
                </DropdownMenuItem>
                
                <DropdownMenuSeparator className="bg-white/10" />
                
                {/* SYSTEM & HELP */}
                <DropdownMenuItem onClick={onSettings}>
                    <Settings className="mr-2 h-3.5 w-3.5" />
                    <span>Preferences</span>
                    <DropdownMenuShortcut>⌘,</DropdownMenuShortcut>
                </DropdownMenuItem>
                <DropdownMenuItem>
                    <HelpCircle className="mr-2 h-3.5 w-3.5" />
                    <span>Documentation</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                    <Command className="mr-2 h-3.5 w-3.5" />
                    <span>Keyboard Shortcuts</span>
                </DropdownMenuItem>

            </DropdownMenuContent>
        </DropdownMenu>
    );
}