import React, { useState, useEffect, useRef } from 'react';
import { cn } from "@/components/ui/utils";
import { 
    IntentText, StateText,
} from '@/components/ui/design-system/SystemDesign';
import { Terminal, Activity } from 'lucide-react';
import { Label } from "@/components/ui/label";

/* -------------------------------------------------------------------------- */
/*                              SYSTEM TERMINAL                               */
/* -------------------------------------------------------------------------- */

export const SystemTerminal = ({ 
    initialLines = [], 
    onCommand, 
    className, 
    prompt = "root@system:~$",
    title = "TERMINAL",
    actions
}) => {
    const [lines, setLines] = useState(initialLines);
    const [input, setInput] = useState("");
    const scrollRef = useRef(null);

    useEffect(() => {
        if (initialLines.length > 0) setLines(initialLines);
    }, [initialLines]);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [lines]);

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            const cmd = input.trim();
            if (!cmd) return;
            
            setLines(prev => [...prev, { type: 'input', content: cmd }]);
            setInput("");
            
            if (onCommand) {
                onCommand(cmd, (response) => {
                    setLines(prev => [...prev, { type: 'output', content: response }]);
                });
            }
        }
    };

    return (
        <div className={cn("flex flex-col h-full min-h-0 w-full bg-[#0d1117] font-mono text-xs overflow-hidden rounded-md border border-white/5 shadow-inner relative isolate", className)}>
            <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/5 shrink-0 z-10">
                <div className="flex items-center gap-2">
                    <Terminal className="w-3 h-3 text-neutral-500" />
                    <span className="text-neutral-500 uppercase tracking-wider">{title}</span>
                </div>
                <div className="flex items-center gap-2">
                    {actions ? actions : (
                        <div className="flex gap-1.5">
                            <div className="w-2 h-2 rounded-full bg-red-500/20" />
                            <div className="w-2 h-2 rounded-full bg-yellow-500/20" />
                            <div className="w-2 h-2 rounded-full bg-green-500/20" />
                        </div>
                    )}
                </div>
            </div>
            <div 
                ref={scrollRef}
                className="flex-1 min-h-0 p-3 overflow-y-auto space-y-1 overscroll-contain" 
                onClick={() => document.getElementById('sys-term-input')?.focus()}
            >
                {lines.map((line, i) => (
                    <div key={i} className={cn("break-all", line.type === 'input' ? "text-white flex gap-2" : line.color || "text-neutral-400")}>
                        {line.type === 'input' && <span className="text-[hsl(var(--color-execution))] shrink-0">{prompt}</span>}
                        <span>{line.content}</span>
                    </div>
                ))}
                <div className="flex gap-2 text-white">
                    <span className="text-[hsl(var(--color-execution))] shrink-0">{prompt}</span>
                    <input 
                        id="sys-term-input"
                        className="bg-transparent border-none outline-none flex-1 text-white caret-[hsl(var(--color-execution))]"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        autoComplete="off"
                    />
                </div>
            </div>
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                                SYSTEM STATS                                */
/* -------------------------------------------------------------------------- */

export const SystemStats = ({ stats = [], className }) => {
    return (
        <div className={cn("grid grid-cols-2 md:grid-cols-4 gap-3", className)}>
            {stats.map((stat, i) => (
                <div 
                    key={i} 
                    onClick={stat.onClick}
                    className={cn(
                        "p-3 bg-neutral-900/50 rounded border border-white/5 relative overflow-hidden group hover:border-white/10 transition-colors",
                        stat.onClick && "cursor-pointer hover:bg-neutral-900 hover:border-[hsl(var(--color-intent))]"
                    )}
                >
                    <div className="flex justify-between items-start mb-2 relative z-10">
                        {stat.icon ? <stat.icon className={cn("w-4 h-4", stat.color || "text-[hsl(var(--color-execution))]")} /> : <Activity className="w-4 h-4 text-neutral-500" />}
                        <span className="font-mono text-lg text-white font-bold">{stat.value}</span>
                    </div>
                    <StateText className="text-[10px] uppercase opacity-60 relative z-10">{stat.label}</StateText>
                    {stat.progress !== undefined && (
                        <div className="absolute bottom-0 left-0 w-full h-1 bg-neutral-800">
                            <div 
                                className={cn("h-full transition-all duration-500", stat.color ? `bg-current ${stat.color}` : "bg-[hsl(var(--color-execution))]")} 
                                style={{ width: `${stat.progress}%` }} 
                            />
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                                SYSTEM FORM                                 */
/* -------------------------------------------------------------------------- */

export const SystemForm = ({ children, title, description, actions, className }) => {
    return (
        <div className={cn("space-y-6", className)}>
            {(title || description) && (
                <div className="mb-6">
                    {title && <IntentText className="text-lg mb-1">{title}</IntentText>}
                    {description && <StateText className="opacity-50">{description}</StateText>}
                </div>
            )}
            
            <div className="space-y-4">
                {children}
            </div>

            {actions && (
                <div className="pt-6 border-t border-white/5 flex justify-end gap-3 mt-6">
                    {actions}
                </div>
            )}
        </div>
    );
};

export const SystemField = ({ label, children, helper, error }) => (
    <div className="space-y-1.5">
        <Label className="text-xs font-bold text-neutral-300 uppercase tracking-wider">{label}</Label>
        {children}
        {helper && <p className="text-[10px] text-neutral-500">{helper}</p>}
        {error && <p className="text-[10px] text-[hsl(var(--color-error))]">{error}</p>}
    </div>
);

/* -------------------------------------------------------------------------- */
/*                                SYSTEM LOG                                  */
/* -------------------------------------------------------------------------- */

export const SystemLog = ({ logs = [], onSelect, selectedId, className }) => {
    return (
        <div className={cn("space-y-1 font-mono text-xs h-full overflow-y-auto pr-2", className)}>
            {logs.length === 0 && (
                <div className="text-neutral-500 italic p-4 text-center border border-dashed border-white/5 rounded">No system logs available.</div>
            )}
            {logs.map((log, i) => (
                <div 
                    key={log.id || i}
                    onClick={() => onSelect && onSelect(log)}
                    className={cn(
                        "flex items-start gap-3 p-2 rounded border transition-colors cursor-pointer group",
                        selectedId === log.id 
                            ? "bg-white/10 border-white/20 text-white" 
                            : "bg-transparent border-transparent hover:bg-white/5 text-neutral-400 hover:text-neutral-300"
                    )}
                >
                    <div className={cn(
                        "w-1 h-1 rounded-full mt-1.5 shrink-0 transition-all",
                        log.status === 'error' || log.status === 'blocked' ? "bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]" :
                        log.status === 'warning' ? "bg-yellow-500 shadow-[0_0_8px_rgba(234,179,8,0.5)]" :
                        log.type === 'security' ? "bg-red-500" :
                        "bg-blue-500/50"
                    )} />
                    <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-baseline mb-0.5">
                            <span className={cn("font-bold truncate opacity-80", selectedId === log.id ? "text-white" : "text-neutral-500 group-hover:text-neutral-400")}>
                                {log.type?.toUpperCase()}
                            </span>
                            <span className="opacity-40 text-[9px]">{new Date(log.timestamp).toLocaleTimeString()}</span>
                        </div>
                        <div className="truncate opacity-70">{log.content}</div>
                    </div>
                </div>
            ))}
        </div>
    );
};