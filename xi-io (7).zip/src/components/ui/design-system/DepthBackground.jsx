import React, { useEffect, useRef } from 'react';
import { useSiteContext } from '@/components/identity/SiteContext';

// Color Mapping for Tailwind Classes to RGB for Canvas
const THEME_COLORS = {
    'indigo-500': '99, 102, 241',
    'blue-400': '96, 165, 250',
    'sky-500': '14, 165, 233',
    'violet-500': '139, 92, 246',
    'blue-500': '59, 130, 246',
    'yellow-500': '234, 179, 8',
    'orange-500': '249, 115, 22',
    'emerald-500': '16, 185, 129',
    'emerald-700': '4, 120, 87',
    'slate-500': '100, 116, 139',
    'blue-600': '37, 99, 235',
    'cyan-500': '6, 182, 212',
    'fuchsia-500': '217, 70, 239',
    'purple-500': '168, 85, 247',
    'rose-500': '244, 63, 94',
    'stone-500': '120, 113, 108',
    'pink-500': '236, 72, 153',
    'teal-500': '20, 184, 166',
    'amber-500': '245, 158, 11',
    'violet-400': '167, 139, 250',
    'orange-400': '251, 146, 60',
    'indigo-400': '129, 140, 248',
    'lime-500': '132, 204, 22',
    'neutral-600': '82, 82, 82',
    'purple-600': '147, 51, 234',
    'zinc-600': '82, 82, 91',
    'slate-400': '148, 163, 184',
    'red-500': '239, 68, 68',
    'emerald-400': '52, 211, 153',
    'cyan-400': '34, 211, 238',
    'stone-400': '168, 162, 158'
};

export default function DepthBackground({ theme = 'cyan-500' }) {
    const canvasRef = useRef(null);
    const bgRef = useRef(null);
    const { reducedMotion } = useSiteContext();
    
    // Convert theme class to RGB, fallback to cyan if missing
    const activeColor = THEME_COLORS[theme] || '6, 182, 212';
    
    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        let animationFrameId;
        let width = window.innerWidth;
        let height = window.innerHeight;
        let time = 0;

        // If reduced motion is on, just render a static glow and exit
        if (reducedMotion) {
            ctx.clearRect(0, 0, width, height);
            
            // Static Ambient Glow
            const glow = ctx.createRadialGradient(width/2, height/2, 0, width/2, height/2, width * 0.8);
            glow.addColorStop(0, `rgba(${activeColor}, 0.15)`); // Core
            glow.addColorStop(0.5, `rgba(${activeColor}, 0.05)`); // Mid
            glow.addColorStop(1, `rgba(0, 0, 0, 0)`); // Fade
            
            ctx.fillStyle = glow;
            ctx.fillRect(0,0,width,height);
            return;
        }
        
        // Mouse State for Parallax
        let currentMouse = { x: 0, y: 0 };
        let targetMouse = { x: 0, y: 0 };

        // Particle System for "Dust"
        const particles = Array.from({ length: 300 }, () => ({
            x: Math.random() * width,
            y: Math.random() * height,
            size: Math.random() * 2,
            speedX: (Math.random() - 0.5) * 0.2,
            speedY: (Math.random() - 0.5) * 0.2,
            opacity: Math.random() * 0.5 + 0.1
        }));

        const resize = () => {
            width = window.innerWidth;
            height = window.innerHeight;
            canvas.width = width;
            canvas.height = height;
        };
        window.addEventListener('resize', resize);
        resize();

        const handleMouseMove = (e) => {
            const rect = canvas.getBoundingClientRect();
            // Normalized coordinates (-1 to 1)
            targetMouse = {
                x: (e.clientX - rect.left - width / 2) / (width / 2),
                y: (e.clientY - rect.top - height / 2) / (height / 2)
            };
        };
        window.addEventListener('mousemove', handleMouseMove);

        const render = () => {
            // Smooth mouse interpolation (Heavy smoothing for "underwater" feel)
            currentMouse.x += (targetMouse.x - currentMouse.x) * 0.02;
            currentMouse.y += (targetMouse.y - currentMouse.y) * 0.02;

            time += 0.005;

            // 1. UPDATE PARALLAX BACKGROUND
            // We sway the background image gently opposite to the mouse
            if (bgRef.current) {
                const shiftX = currentMouse.x * -40; 
                const shiftY = currentMouse.y * -30;
                // Add a slow, organic breathe scale
                const breathe = 1.3 + Math.sin(time * 0.5) * 0.02;
                // Add a very subtle rotation tilt based on X
                const tilt = currentMouse.x * 15; 
                
                bgRef.current.style.transform = `
                    scale(${breathe}) 
                    translate3d(${shiftX}px, ${shiftY}px, 0) 
                    rotate(${tilt}deg)
                `;
            }

            ctx.clearRect(0, 0, width, height);

            // 2. RENDER LIQUID LIGHT (Organic, Breathing Atmosphere)
            // We create multiple moving light orbs that blend together
            
            // Primary Orb (Mouse Influence) - Now with Core Hotspot
            const orb1X = width/2 + (currentMouse.x * 250) + Math.sin(time * 0.5) * 50;
            const orb1Y = height/2 + (currentMouse.y * 200) + Math.cos(time * 0.4) * 50;
            const orb1Pulse = 0.15 + Math.sin(time * 0.8) * 0.05;
            
            const glow1 = ctx.createRadialGradient(orb1X, orb1Y, 0, orb1X, orb1Y, width * 0.8);
            glow1.addColorStop(0, `rgba(${activeColor}, ${orb1Pulse})`);
            glow1.addColorStop(0.5, `rgba(${activeColor}, ${orb1Pulse * 0.3})`);
            glow1.addColorStop(1, 'transparent');
            
            ctx.fillStyle = glow1;
            ctx.fillRect(0, 0, width, height);

            // "Hotspot" Highlight - Follows mouse perfectly for responsiveness
            // This creates the feeling that the user is holding a light source
            const mousePxX = (targetMouse.x * width / 2) + width / 2;
            const mousePxY = (targetMouse.y * height / 2) + height / 2;
            
            const highlight = ctx.createRadialGradient(mousePxX, mousePxY, 0, mousePxX, mousePxY, 150);
            highlight.addColorStop(0, `rgba(255, 255, 255, 0.08)`);
            highlight.addColorStop(1, 'transparent');
            
            ctx.globalCompositeOperation = 'overlay';
            ctx.fillStyle = highlight;
            ctx.fillRect(0, 0, width, height);
            ctx.globalCompositeOperation = 'source-over';

            // Secondary Orb (Orbiting Counter-weight)
            // Moves in a slow figure-8 pattern independent of mouse
            const orb2X = width/2 + Math.cos(time * 0.3) * (width * 0.3);
            const orb2Y = height/2 + Math.sin(time * 0.2) * (height * 0.2);
            const orb2Pulse = 0.1 + Math.cos(time * 0.5) * 0.03;

            const glow2 = ctx.createRadialGradient(orb2X, orb2Y, 0, orb2X, orb2Y, width * 0.6);
            glow2.addColorStop(0, `rgba(${activeColor}, ${orb2Pulse * 0.8})`); // Slightly dimmer
            glow2.addColorStop(1, 'transparent');

            ctx.globalCompositeOperation = 'screen'; // Blend modes for "light" feel
            ctx.fillStyle = glow2;
            ctx.fillRect(0, 0, width, height);

            // Tertiary "Deep" Glow (Bottom Anchor)
            // Anchors the bottom of the screen with a stable glow
            const deepGlow = ctx.createLinearGradient(0, height, 0, height * 0.5);
            deepGlow.addColorStop(0, `rgba(${activeColor}, 0.1)`);
            deepGlow.addColorStop(1, 'transparent');
            ctx.fillStyle = deepGlow;
            ctx.fillRect(0, 0, width, height);

            ctx.globalCompositeOperation = 'source-over'; // Reset

            // 3. RENDER FLOATING PARTICLES (Interactive Stardust)
            // Particles react to the mouse "energy field"
            ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
            
            // Mouse position in pixels for physics (Used from above)
            particles.forEach(p => {
                // Base movement + Parallax
                p.x += p.speedX + (currentMouse.x * -0.8); 
                p.y += p.speedY + (currentMouse.y * -0.8);

                // Mouse Repulsion Physics
                const dx = p.x - mousePxX;
                const dy = p.y - mousePxY;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const interactionRadius = 200;

                if (dist < interactionRadius) {
                    const force = (interactionRadius - dist) / interactionRadius;
                    const angle = Math.atan2(dy, dx);
                    p.x += Math.cos(angle) * force * 2;
                    p.y += Math.sin(angle) * force * 2;
                }

                // Wrap around screen
                if (p.x < -50) p.x = width + 50;
                if (p.x > width + 50) p.x = -50;
                if (p.y < -50) p.y = height + 50;
                if (p.y > height + 50) p.y = -50;

                // Twinkle effect
                const sizePulse = p.size * (0.8 + Math.sin(time * 3 + p.x) * 0.4);
                
                // Draw Particle with glow
                const pAlpha = p.opacity * (0.5 + Math.sin(time + p.y * 0.01) * 0.3);
                ctx.globalAlpha = Math.max(0, Math.min(1, pAlpha));
                
                ctx.beginPath();
                ctx.arc(p.x, p.y, sizePulse, 0, Math.PI * 2);
                ctx.fill();
                
                // Subtle connection lines if close to mouse (Neural network vibe)
                if (dist < 100) {
                    ctx.strokeStyle = `rgba(${activeColor}, ${0.2 * (1 - dist/100)})`;
                    ctx.lineWidth = 0.5;
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(mousePxX, mousePxY);
                    ctx.stroke();
                }
            });
            ctx.globalAlpha = 1;

            animationFrameId = requestAnimationFrame(render);
        };

        render();

        return () => {
            window.removeEventListener('resize', resize);
            window.removeEventListener('mousemove', handleMouseMove);
            cancelAnimationFrame(animationFrameId);
        };
    }, [reducedMotion, activeColor]); // Re-run when theme color changes

    return (
        <>
            {/* 0. Base Background - The Obsidian Void */}
            {/* We keep the image but overlay the canvas color on top */}
            <div 
                ref={bgRef}
                className="absolute inset-0 z-0 pointer-events-none bg-cover bg-center transition-transform duration-100 ease-out will-change-transform"
                style={{ 
                    backgroundImage: 'url("https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693dffcccab0bea12e1e7952/7d133412d_blue-bg.png")',
                    // Darken the image significantly so the color glow pops
                    filter: 'grayscale(100%) brightness(0.25) contrast(1.1)' 
                }}
            />

            {/* 1. Canvas Layer - The Ambient Light & Dust */}
            <canvas 
                ref={canvasRef}
                className="absolute inset-0 z-0 pointer-events-none"
                style={{ mixBlendMode: 'screen' }} 
            />

            {/* 2. Vignette - Depth Focus (Enhanced Shadow) */}
            {/* This pushes the edges back, framing the center content */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,rgba(0,0,0,0.5)_60%,rgba(0,0,0,0.95)_100%)] pointer-events-none z-0" />
            
            {/* 3. Film Grain - Tactile Texture (Removes Banding) */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none z-0 mix-blend-overlay" 
                 style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }} 
            />

            {/* 4. Scanlines - Subtle Tech Feel */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,6px_100%] pointer-events-none z-0 opacity-10" />
        </>
    );
}