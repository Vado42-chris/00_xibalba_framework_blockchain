import React from 'react';
import { 
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, CheckCircle2, XCircle, ArrowRight } from 'lucide-react';
import { IntentText, StateText, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { cn } from "@/components/ui/utils";

export function SystemConfirmation({ 
    open, 
    onOpenChange, 
    title = "Confirm Action", 
    description = "This action cannot be undone.",
    onConfirm,
    onCancel,
    confirmText = "Confirm",
    cancelText = "Cancel",
    variant = "default" // default, destructive, success
}) {
    const variantStyles = {
        default: {
            icon: AlertTriangle,
            color: "text-[hsl(var(--color-warning))]",
            btn: "bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90",
            border: "border-[hsl(var(--color-warning))]/20"
        },
        destructive: {
            icon: XCircle,
            color: "text-[hsl(var(--color-error))]",
            btn: "bg-[hsl(var(--color-error))] text-white hover:bg-[hsl(var(--color-error))]/90",
            border: "border-[hsl(var(--color-error))]/20"
        },
        success: {
            icon: CheckCircle2,
            color: "text-[hsl(var(--color-execution))]",
            btn: "bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90",
            border: "border-[hsl(var(--color-execution))]/20"
        }
    };

    const style = variantStyles[variant] || variantStyles.default;
    const Icon = style.icon;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className={cn("sm:max-w-[425px] bg-[#09090b] border border-white/10 p-0 overflow-hidden gap-0", style.border)}>
                <div className="p-6 bg-black/40">
                    <div className="flex items-start gap-4">
                        <div className={cn("p-2 rounded-full bg-white/5 shrink-0", style.color)}>
                            <Icon className="w-6 h-6" />
                        </div>
                        <div className="space-y-1">
                            <IntentText className="text-lg">{title}</IntentText>
                            <StateText className="opacity-70 leading-relaxed">
                                {description}
                            </StateText>
                        </div>
                    </div>
                </div>
                
                <div className="p-4 bg-white/5 border-t border-white/5 flex justify-end gap-3">
                    <Button 
                        variant="ghost" 
                        onClick={() => {
                            if (onCancel) onConfirm();
                            onOpenChange(false);
                        }}
                        className="text-xs hover:bg-white/10 text-neutral-400 hover:text-white"
                    >
                        {cancelText}
                    </Button>
                    <Button 
                        onClick={() => {
                            if (onConfirm) onConfirm();
                            onOpenChange(false);
                        }}
                        className={cn("text-xs font-bold px-6", style.btn)}
                    >
                        {confirmText}
                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    );
}

export function SystemCompletion({ 
    open, 
    onOpenChange, 
    title = "Process Complete", 
    description = "The operation finished successfully.",
    stats = [], // [{ label, value }]
    actions 
}) {
    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[500px] bg-[#09090b] border border-[hsl(var(--color-execution))]/30 p-0 overflow-hidden gap-0">
                <div className="relative p-8 text-center overflow-hidden">
                    <div className="absolute inset-0 bg-[hsl(var(--color-execution))]/5" />
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-1 bg-[hsl(var(--color-execution))]" />
                    
                    <div className="relative z-10 flex flex-col items-center">
                        <div className="w-16 h-16 rounded-full bg-[hsl(var(--color-execution))]/10 flex items-center justify-center mb-6 border border-[hsl(var(--color-execution))]/20 shadow-[0_0_20px_-5px_hsl(var(--color-execution))]">
                            <CheckCircle2 className="w-8 h-8 text-[hsl(var(--color-execution))]" />
                        </div>
                        
                        <IntentText className="text-2xl mb-2">{title}</IntentText>
                        <StateText className="opacity-60 max-w-sm mx-auto">{description}</StateText>
                    </div>
                </div>

                {stats.length > 0 && (
                    <div className="grid grid-cols-2 divide-x divide-white/5 border-y border-white/5 bg-black/20">
                        {stats.map((stat, i) => (
                            <div key={i} className="p-4 text-center">
                                <OrientingText className="text-[9px] mb-1 opacity-50">{stat.label}</OrientingText>
                                <IntentText className="text-lg">{stat.value}</IntentText>
                            </div>
                        ))}
                    </div>
                )}

                <div className="p-6 bg-white/5 flex justify-center gap-3">
                    {actions || (
                        <Button 
                            onClick={() => onOpenChange(false)}
                            className="bg-white text-black hover:bg-neutral-200 font-bold min-w-[120px]"
                        >
                            Done
                        </Button>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}