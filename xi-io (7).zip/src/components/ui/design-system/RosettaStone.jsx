import React from 'react';
import { BookOpen, ArrowRightLeft, MessageSquare, Info } from 'lucide-react';
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/SystemDesign';
import { cn } from '@/components/ui/utils';
import { useLanguage } from '@/components/identity/LanguageContext';
import { TRANSLATION_MATRIX } from '@/components/identity/TranslationMatrix';
import {
    HoverCard,
    HoverCardContent,
    HoverCardTrigger,
} from "@/components/ui/hover-card";

export const RosettaStone = ({ 
    technical, 
    human, 
    generational, 
    context, 
    className,
    isPaper = false
}) => {
    // Auto-lookup if only technical is provided
    let lookedUp = {};
    if (technical && typeof technical === 'string' && !human && !context) {
        const entry = TRANSLATION_MATRIX[technical.toUpperCase()];
        if (entry) {
            lookedUp = {
                human: entry.human,
                generational: entry.generational,
                context: entry.context
            };
        }
    }

    const finalHuman = human || lookedUp.human || "Translation unavailable";
    const finalGen = generational || lookedUp.generational;
    const finalContext = context || lookedUp.context;

    return (
        <div className={cn(
            "rounded-lg overflow-hidden", 
            isPaper ? "bg-[#f5f5f0] text-neutral-900 shadow-md" : "bg-neutral-900/50 border border-white/5",
            className
        )}>
            <div className={cn(
                "px-4 py-2 flex items-center justify-between",
                isPaper ? "bg-black/5 border-b border-black/5" : "bg-white/5 border-b border-white/5"
            )}>
                <div className="flex items-center gap-2">
                    <BookOpen className={cn("w-3 h-3", isPaper ? "text-neutral-600" : "text-[hsl(var(--color-intent))]")} />
                    <span className={cn("text-[10px] font-sans tracking-wide uppercase", isPaper ? "text-neutral-500" : "text-neutral-400")}>
                        TRANSLATION MATRIX
                    </span>
                </div>
            </div>
            <div className="p-4 grid gap-4">
                <div className="grid grid-cols-[1fr_auto_1fr] gap-4 items-center">
                    <div>
                        <div className={cn("text-[9px] uppercase tracking-wider mb-1", isPaper ? "text-neutral-400" : "text-neutral-500")}>System Speak</div>
                        <div className={cn("text-sm font-bold", isPaper ? "text-neutral-900" : "text-white")}>{technical}</div>
                    </div>
                    <ArrowRightLeft className={cn("w-4 h-4", isPaper ? "text-neutral-400" : "text-neutral-600")} />
                    <div>
                        <div className={cn("text-[9px] uppercase tracking-wider mb-1", isPaper ? "text-neutral-400" : "text-neutral-500")}>Plain Speak</div>
                        <span className={cn("text-sm font-medium font-serif italic", isPaper ? "text-emerald-700" : "text-emerald-400")}>{finalHuman}</span>
                    </div>
                </div>
                
                {finalGen && (
                    <div className={cn("pt-4 border-t", isPaper ? "border-black/5" : "border-white/5")}>
                        <div className={cn("text-[9px] uppercase tracking-wider mb-1", isPaper ? "text-neutral-400" : "text-neutral-500")}>Gen Z / Slang</div>
                        <p className={cn("text-xs", isPaper ? "text-neutral-600" : "text-neutral-300")}>"{finalGen}"</p>
                    </div>
                )}

                {finalContext && (
                    <div className={cn("p-3 rounded text-xs leading-relaxed", isPaper ? "bg-black/5 text-neutral-700" : "bg-black/20 text-neutral-400")}>
                        <span className={cn("font-bold mr-2", isPaper ? "text-neutral-900" : "text-[hsl(var(--color-intent))]")}>CONTEXT:</span>
                        {finalContext}
                    </div>
                )}
            </div>
        </div>
    );
};

export const Explainable = ({ children, technical, human, generational, className }) => {
    const { mode } = useLanguage();
    
    const techTerm = technical || (typeof children === 'string' ? children : null);
    
    // Auto-lookup for render content if needed
    let lookedUp = {};
    if (techTerm && typeof techTerm === 'string') {
        const entry = TRANSLATION_MATRIX[techTerm.toUpperCase()];
        if (entry) {
            lookedUp = {
                human: entry.human,
                generational: entry.generational
            };
        }
    }

    const humanTerm = human || lookedUp.human;
    
    // Determine what to display based on mode
    let content = techTerm;
    if (mode === 'human' && humanTerm) content = humanTerm;
    // We generally don't render Generational as primary text unless requested, but sticking to Human/Technical for now.

    return (
        <HoverCard openDelay={200}>
            <HoverCardTrigger asChild>
                <span className={cn(
                    "cursor-help border-b border-dotted border-white/20 transition-all hover:text-[hsl(var(--color-intent))]",
                    mode === 'human' ? "border-emerald-500/50 text-emerald-50 text-shadow-sm" : "border-white/20",
                    className
                )}>
                    {content}
                </span>
            </HoverCardTrigger>
            <HoverCardContent 
                className="w-[300px] bg-[#f5f5f0] text-neutral-900 border-none shadow-xl p-0 z-50 animate-in fade-in slide-in-from-bottom-2 duration-200"
                sideOffset={10}
            >
                <RosettaStone 
                    technical={techTerm} 
                    human={human}
                    generational={generational}
                    className="border-0 bg-transparent text-neutral-900"
                    isPaper={true}
                />
            </HoverCardContent>
        </HoverCard>
    );
};