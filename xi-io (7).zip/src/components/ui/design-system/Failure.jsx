import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { OrientingText, IntentText, StateText, SemanticDot } from './SystemDesign';
import { cn } from "@/lib/utils";
import { AlertTriangle, XCircle, ShieldAlert, Check } from 'lucide-react';
import { Button } from "@/components/ui/button";

/* -------------------------------------------------------------------------- */
/*                        SECTION 2: BASE-3 FAILURE                           */
/* -------------------------------------------------------------------------- */

export const FailureState = ({ 
    error, 
    impact = "No data lost. Task remains active.", 
    truth = "You can retry or modify parameters.",
    domain = "system", // execution, validation, network
    className 
}) => {
    // Domain colors
    const colorClass = {
        execution: "border-[hsl(var(--color-active))]", // Green/Blue
        validation: "border-[hsl(var(--color-warning))]", // Amber
        network: "border-neutral-700", // Neutral
        system: "border-neutral-800"
    }[domain] || "border-neutral-800";

    const Icon = {
        execution: AlertTriangle,
        validation: AlertTriangle,
        network: AlertTriangle,
        system: AlertTriangle
    }[domain] || AlertTriangle;

    return (
        <div className={cn("border-l-2 p-4 bg-neutral-950/50 backdrop-blur-sm", colorClass, className)}>
            <div className="flex gap-4 items-start">
                <div className="pt-0.5 opacity-50">
                    <Icon className="w-4 h-4" />
                </div>
                <div className="space-y-3">
                    {/* Layer 1: WHAT FAILED (Factual) */}
                    <div>
                        <OrientingText className="text-[hsl(var(--fg-intent))] opacity-100 mb-0.5">FAILURE DETECTED</OrientingText>
                        <IntentText className="font-mono text-sm">{error || "Unknown system anomaly"}</IntentText>
                    </div>

                    {/* Layer 2: WHY IT MATTERS (Impact) */}
                    <div>
                         <OrientingText>IMPACT ASSESSMENT</OrientingText>
                         <StateText className="opacity-70">{impact}</StateText>
                    </div>

                    {/* Layer 3: WHAT IS STILL TRUE (Stability) */}
                    <div className="pt-2 border-t border-neutral-800/50">
                         <StateText className="text-[hsl(var(--color-active))]">{truth}</StateText>
                    </div>
                </div>
            </div>
        </div>
    );
};


/* -------------------------------------------------------------------------- */
/*                        SECTION 5: IRREVERSIBILITY                          */
/* -------------------------------------------------------------------------- */

export const IrreversibleAction = ({ 
    trigger, 
    action, 
    label = "CONFIRM", 
    onConfirm, 
    onCancel,
    className 
}) => {
    const [stage, setStage] = useState('idle'); // idle, armed

    if (stage === 'idle') {
        return (
            <div onClick={() => setStage('armed')} className={cn("cursor-pointer", className)}>
                {trigger}
            </div>
        );
    }

    return (
        <div className={cn("bg-[hsl(var(--color-error))]/5 border border-[hsl(var(--color-error))]/20 rounded p-4 animate-in fade-in zoom-in-95 duration-200", className)}>
            <div className="flex gap-4 items-start">
                 <div className="p-2 bg-[hsl(var(--color-error))]/10 rounded border border-[hsl(var(--color-error))]/20 text-[hsl(var(--color-error))]">
                     <ShieldAlert className="w-5 h-5" />
                 </div>
                 <div className="flex-1 space-y-4">
                     <div>
                        <div className="text-[hsl(var(--color-error))] font-bold tracking-widest text-xs uppercase mb-1">Irreversible Action</div>
                        <IntentText className="text-white">{action}</IntentText>
                     </div>
                     
                     <div className="flex gap-3 pt-2">
                        <Button 
                            size="sm" 
                            variant="ghost" 
                            className="text-[hsl(var(--fg-orientation))] hover:text-white hover:bg-white/5 border border-transparent"
                            onClick={(e) => {
                                e.stopPropagation();
                                setStage('idle');
                                onCancel && onCancel();
                            }}
                        >
                            RETURN
                        </Button>
                        <Button 
                            size="sm" 
                            className="bg-[hsl(var(--color-error))] hover:bg-[hsl(var(--color-error))]/80 text-white border border-[hsl(var(--color-error))]/50"
                            onClick={(e) => {
                                e.stopPropagation();
                                onConfirm();
                                setStage('idle');
                            }}
                        >
                            {label}
                        </Button>
                     </div>
                 </div>
            </div>
        </div>
    );
};