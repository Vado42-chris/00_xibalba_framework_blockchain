import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { OrientingText } from './SystemDesign';
import { cn } from "@/components/ui/utils";

const LOADING_MESSAGES = [
    "Reticulating splines...",
    "Summoning the pixels...",
    "Asking the server nicely...",
    "Charging flux capacitors...",
    "Realigning energy crystals...",
    "Downloading more RAM...",
    "Convincing the AI not to take over...",
    "Warming up the tubes...",
    "Spinning up the hamster wheel...",
    "Translating binary to human...",
    "Locating the any key...",
    "Generating witty loading text...",
    "Compressing time and space...",
    "Polishing the user interface...",
    "Shuffling the deck...",
    "Checking for updates... just kidding.",
    "Loading... please wait while we calibrate the fun.",
    "Initializing awesomeness...",
    "Decrypting the matrix...",
    "Feeding the bit-bucket...",
    "Optimizing for maximum cool...",
    "Waiting for the stars to align...",
    "Consulting the machine spirit...",
    "Performing percussive maintenance...",
    "Reverse-engineering alien artifacts...",
    "Calibrating the reality distortion field...",
    "Ensuring safety protocols (optional)...",
    "Loading funny cat video... error, switching to work.",
];

export const HumorousLoader = ({ children, className, delay = 1500, loading: forcedLoading }) => {
    const [loading, setLoading] = useState(true);
    const [message, setMessage] = useState("");

    useEffect(() => {
        // Pick a random message
        setMessage(LOADING_MESSAGES[Math.floor(Math.random() * LOADING_MESSAGES.length)]);
        
        const timer = setTimeout(() => {
            setLoading(false);
        }, delay);
        return () => clearTimeout(timer);
    }, [delay]);

    const isLoading = forcedLoading !== undefined ? forcedLoading : loading;

    return (
        <div className={cn("relative h-full w-full", className)}>
            <AnimatePresence mode="popLayout">
                {isLoading && (
                    <motion.div 
                        initial={{ opacity: 1 }}
                        exit={{ opacity: 0, scale: 0.95, filter: "blur(10px)" }}
                        transition={{ duration: 0.5 }}
                        className="absolute inset-0 z-50 flex flex-col items-center justify-center p-8 bg-neutral-950/80 backdrop-blur-md"
                    >
                         <div className="w-full max-w-[200px] space-y-4">
                            <div className="h-[2px] w-full bg-neutral-800 overflow-hidden relative">
                                <motion.div 
                                    className="absolute inset-y-0 left-0 bg-[hsl(var(--color-intent))]"
                                    initial={{ width: "0%" }}
                                    animate={{ width: "100%" }}
                                    transition={{ duration: delay / 1000, ease: "easeInOut" }}
                                />
                            </div>
                            <OrientingText className="text-center text-[10px] uppercase tracking-widest opacity-70 animate-pulse text-[hsl(var(--color-intent))]">
                                {message}
                            </OrientingText>
                         </div>
                    </motion.div>
                )}
            </AnimatePresence>
            <motion.div
                initial={false}
                animate={{ opacity: isLoading ? 0 : 1 }}
                className="h-full w-full"
            >
                {children}
            </motion.div>
        </div>
    );
};