import React from 'react';
import { cn } from "@/components/ui/utils";
import { Button } from "@/components/ui/button";
import { ArrowRight, MoreHorizontal } from 'lucide-react';

/**
 * ActionDock - A standardized "Next Step" container for any component.
 * 
 * Usage:
 * <ActionDock 
 *    primaryAction={{ label: "Deploy", onClick: handleDeploy }}
 *    secondaryActions={[
 *      { label: "Edit", onClick: handleEdit },
 *      { label: "Share", onClick: handleShare }
 *    ]}
 * />
 */
export const ActionDock = ({ 
    primaryAction, 
    secondaryActions = [], 
    className 
}) => {
    if (!primaryAction && secondaryActions.length === 0) return null;

    return (
        <div className={cn(
            "flex items-center justify-between mt-4 pt-3 border-t border-white/5",
            className
        )}>
            <div className="flex items-center gap-2">
                {secondaryActions.map((action, i) => (
                    <Button
                        key={i}
                        variant="ghost"
                        size="sm"
                        onClick={action.onClick}
                        className="h-7 text-[10px] text-neutral-500 hover:text-white px-2"
                    >
                        {action.icon && <action.icon className="w-3 h-3 mr-1.5" />}
                        {action.label}
                    </Button>
                ))}
            </div>

            {primaryAction && (
                <Button
                    size="sm"
                    onClick={primaryAction.onClick}
                    className="h-7 text-[10px] bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold px-3 shadow-[0_0_10px_-4px_hsl(var(--color-intent))]"
                >
                    {primaryAction.label}
                    {primaryAction.icon ? <primaryAction.icon className="w-3 h-3 ml-1.5" /> : <ArrowRight className="w-3 h-3 ml-1.5" />}
                </Button>
            )}
        </div>
    );
};