import { CheckCircle2, Activity, Shield, AlertTriangle, RefreshCw, Lock, Zap } from 'lucide-react';

/* 
   FORMALIZED HERO STATUS CONFIGURATION
   Restricting system states to a fixed set to prevent scope creep.
   This acts as the "Truth Layer" definition for the entire application.
*/

export const HERO_STATUS = {
    NOMINAL: 'nominal',
    DEGRADED: 'degraded',
    CRITICAL: 'critical',
    MAINTENANCE: 'maintenance',
    INITIALIZING: 'initializing'
};

export const STATUS_CONFIG = {
    [HERO_STATUS.NOMINAL]: {
        technical: "NOMINAL",
        human: "Everything looks good",
        generational: "VIBES IMMACULATE",
        message: {
            technical: "All Systems Nominal",
            human: "You're all set.",
            generational: "We chilling."
        },
        color: "text-emerald-500",
        bg: "bg-emerald-500/10",
        border: "border-emerald-500/20",
        icon: CheckCircle2,
        trustSignal: "Encrypted & Verified",
        pulse: true
    },
    [HERO_STATUS.DEGRADED]: {
        technical: "DEGRADED",
        human: "Minor Issues",
        generational: "KINDA SUS",
        message: {
            technical: "Performance Degraded",
            human: "Things are a bit slow.",
            generational: "Lagging fr."
        },
        color: "text-amber-500",
        bg: "bg-amber-500/10",
        border: "border-amber-500/20",
        icon: Activity,
        trustSignal: "Investigating",
        pulse: true
    },
    [HERO_STATUS.CRITICAL]: {
        technical: "CRITICAL",
        human: "System Failure",
        generational: "COOKED",
        message: {
            technical: "Critical Failure Detected",
            human: "Action required immediately.",
            generational: "It's over."
        },
        color: "text-rose-500",
        bg: "bg-rose-500/10",
        border: "border-rose-500/20",
        icon: Shield,
        trustSignal: "Contained",
        pulse: true
    },
    [HERO_STATUS.MAINTENANCE]: {
        technical: "MAINTENANCE",
        human: "Updating",
        generational: "GLOW UP",
        message: {
            technical: "Scheduled Maintenance",
            human: "Improving the system.",
            generational: "Brb fixing stuff."
        },
        color: "text-blue-500",
        bg: "bg-blue-500/10",
        border: "border-blue-500/20",
        icon: RefreshCw,
        trustSignal: "Safe Mode",
        pulse: true
    },
    [HERO_STATUS.INITIALIZING]: {
        technical: "INITIALIZING",
        human: "Starting Up",
        generational: "WAKING UP",
        message: {
            technical: "System Initialization",
            human: "Warming up engines.",
            generational: "Let him cook."
        },
        color: "text-neutral-400",
        bg: "bg-neutral-500/10",
        border: "border-white/10",
        icon: Zap,
        trustSignal: "Booting...",
        pulse: true
    }
};