import React, { useState, useEffect } from 'react';
import { cn } from "@/components/ui/utils";
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { useLanguage } from '@/components/identity/LanguageContext';
import { ChevronRight, ArrowDown } from 'lucide-react';

/* -------------------------------------------------------------------------- */
/*                               TYPOGRAPHY SYSTEM                            */
/* -------------------------------------------------------------------------- */

export const OrientingText = ({ children, className, human, ...props }) => {
  const { mode } = useLanguage();
  return (
      <div className={cn("mode-orientation", className)} {...props}>
          {mode === 'human' && human ? human : children}
      </div>
  );
};

export const IntentText = ({ children, className, human, ...props }) => {
  const { mode } = useLanguage();
  return (
      <div className={cn("mode-intent", className)} {...props}>
          {mode === 'human' && human ? human : children}
      </div>
  );
};

export const StateText = ({ children, className, human, ...props }) => {
  const { mode } = useLanguage();
  return (
      <div className={cn("mode-state", className)} {...props}>
          {mode === 'human' && human ? human : children}
      </div>
  );
};

export const AtomicParagraph = ({ children, className, ...props }) => {
    return (
        <p className={cn("atomic-paragraph mode-orientation", className)} {...props}>
            {children}
        </p>
    );
};


/* -------------------------------------------------------------------------- */
/*                         CONSTRUCTION PAPER LAYERS                          */
/* -------------------------------------------------------------------------- */

export const Layer = React.forwardRef(({ level = 'state', className, children, ...props }, ref) => {
    // 5 Layers (Construction Paper Physics)
    // Spacing Rules: x1=3px, x2=9px, x3=27px, x4=81px
    // Padding logic: State=12px (4*3), Intent=15px (5*3), Intervention=27px (9*3)
    const layerClass = {
        // L1: Top - Intervention (Dialogs, Alerts) - LARGE (12px)
        intervention: "bg-black/60 border-white/10 text-white shadow-2xl rounded-xl p-[27px] backdrop-blur-xl z-40",
        
        // L2: Middle-Top - Intent (Active Workspace) - MEDIAN (6px)
        intent: "bg-black/40 border-white/10 shadow-lg text-neutral-200 rounded-md p-[15px] backdrop-blur-md z-30",
        
        // L3: Middle-Bottom - State (Persistent Truth) - SMALL (2px)
        state: "bg-black/30 border-white/10 text-neutral-400 rounded-sm p-[12px] backdrop-blur-sm z-20",
        
        // L4: Bottom - Orientation (Foundation) - SMALL (2px)
        orientation: "bg-black/20 border-none text-neutral-500 rounded-sm p-[9px] backdrop-blur-sm z-10",
        
        // L5: Void - Field
        void: "bg-transparent z-0"
    }[level] || "bg-black/30 border-white/10 text-neutral-400 rounded-sm p-[12px] backdrop-blur-sm z-20";

    return (
        <div ref={ref} className={cn(layerClass, className)} {...props}>
            {children}
        </div>
    );
});
Layer.displayName = "Layer";


/* -------------------------------------------------------------------------- */
/*                            QUADRANT PHYSICS                                */
/* -------------------------------------------------------------------------- */
/* 
   Quadrants are forces, not boxes.
   TL: Aspirational Intent (Identity/Scope)
   TR: System Execution (Intent/Controls)
   BL: Personal History (State/Logs)
   BR: Consequence/Outcome (Results/Diffs)
*/

export const QuadrantGrid = ({ children, className, layout = 'auto' }) => {
    const [isMobile, setIsMobile] = useState(false);

    useEffect(() => {
        if (typeof window === 'undefined') return;
        const checkMobile = () => setIsMobile(window.innerWidth < 1024);
        checkMobile();
        window.addEventListener('resize', checkMobile);
        return () => window.removeEventListener('resize', checkMobile);
    }, []);

    const childArray = React.Children.toArray(children);

    // MODE 1: VERTICAL STACK (Forces vertical stacking of all children)
    if (layout === 'stack' || isMobile) {
        return (
            <div className={cn("w-full flex flex-col gap-[27px] p-[27px]", className)}>
                {childArray.map((child, i) => (
                    <div key={i} className="flex-1 min-h-0 min-w-0">
                        {child}
                    </div>
                ))}
            </div>
        );
    }

    // MODE 2: AUTO / 2-COLUMN (Standard Dashboard Layout)
    // Replaced Resizable Panels with Responsive Flex/Grid logic ("Fractal Dashboards")
    // Left/Right groupings still respected, but they now flow/stack instead of resize/scroll.

    let leftChildren = [];
    let rightChildren = [];

    if (childArray.length > 0) leftChildren.push(childArray[0]); // TL
    if (childArray.length > 1) rightChildren.push(childArray[1]); // TR
    if (childArray.length > 2) leftChildren.push(childArray[2]); // BL
    if (childArray.length > 3) rightChildren.push(childArray[3]); // BR

    return (
        <div className={cn("w-full h-auto p-[27px] flex flex-wrap gap-[27px]", className)}>
             
            {/* LEFT COLUMN GROUP */}
            {leftChildren.length > 0 && (
                <div className="flex-1 flex flex-col gap-[27px] min-w-[350px]">
                    {leftChildren.map((child, i) => (
                        <div key={`left-${i}`} className="flex-1 min-h-0">
                            {child}
                        </div>
                    ))}
                </div>
            )}

            {/* RIGHT COLUMN GROUP */}
            {rightChildren.length > 0 && (
                <div className="flex-[2] flex flex-col gap-[27px] min-w-[350px]">
                    {rightChildren.map((child, i) => (
                        <div key={`right-${i}`} className="flex-1 min-h-0">
                            {child}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export const Quadrant = ({ 
    type = 'state', 
    dominance = 'supporting', // dominant, supporting, latent
    collapsed = false,
    step, // New: Workflow Step Number
    title, // New: Workflow Step Title
    scrollable = false, // UPDATED: Default to false to enforce "stack vs scroll" logic
    children, 
    className 
}) => {
    // SECTION 6: QUADRANT GRAVITY
    
    const baseStyles = {
        orientation: "bg-black/20 border-white/10 backdrop-blur-md",
        intent: "bg-black/20 border-white/10 backdrop-blur-md",
        state: "bg-black/10 border-white/10 backdrop-blur-sm",
        void: "bg-transparent border-none"
    };

    // SECTION 9: COLLAPSE BEHAVIOR
    const isCollapsed = collapsed || dominance === 'latent';

    const dominanceStyles = {
        dominant: "shadow-2xl z-20 scale-[1.01] border-opacity-100 ring-1 ring-white/5",
        supporting: "z-10 opacity-100",
        latent: "z-0 opacity-60 grayscale-[0.8] scale-95 origin-center pointer-events-none"
    };

    return (
        <div className={cn(
            "relative flex flex-col gap-[15px] h-auto w-full transition-all duration-500 ease-out min-h-[200px]", 
            baseStyles[type] || baseStyles.state,
            dominanceStyles[dominance] || dominanceStyles.supporting,
            type === 'orientation' ? "p-[15px] border-r border-b lg:border-b-0" : "p-[15px] border rounded-sm",
            // Enforce rounding based on type if needed, otherwise fallback to rounded-sm (2px) for quadrants
            type === 'intent' && "rounded-md", // Median for Intent quadrants
            className
        )}>
             {/* Implicit Label & Gravity Indicator */}
             <div className="flex justify-between items-center mb-[9px] select-none pointer-events-none shrink-0">
                <div className="flex items-center gap-2">
                    {step && (
                        <div className="flex items-center justify-center w-4 h-4 rounded-full bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))] text-[9px] font-bold border border-[hsl(var(--color-intent))]/20">
                            {step}
                        </div>
                    )}
                    <OrientingText className={cn(
                        "text-[9px] tracking-widest uppercase transition-all", 
                        isCollapsed ? "opacity-30" : "opacity-50"
                    )}>
                        {title || type}
                    </OrientingText>
                </div>
                
                {/* Gravity Marker */}
                <div className={cn(
                    "w-[3px] h-[3px] rounded-full transition-all",
                    dominance === 'dominant' ? "bg-[hsl(var(--color-intent))]" : "bg-[hsl(var(--layer-orientation))]"
                )} />
             </div>

             <div className={cn(
                 "flex flex-col gap-[15px] flex-1 min-h-0", 
                 scrollable ? "overflow-y-auto scrollbar-thin" : "overflow-hidden",
                 isCollapsed && "opacity-50 blur-[1px]"
             )}>
                {children}
             </div>
        </div>
    );
};


/* -------------------------------------------------------------------------- */
/*                            SEMANTIC 7 SYSTEM                               */
/* -------------------------------------------------------------------------- */

export const SemanticDot = ({ type = 'settled', className }) => {
  const colorMap = {
    // SEMANTIC 7
    orientation: 'bg-[hsl(var(--color-orientation))]',
    intent: 'bg-[hsl(var(--color-intent))]',
    execution: 'bg-[hsl(var(--color-execution))]',
    review: 'bg-[hsl(var(--color-review))]',
    settled: 'bg-[hsl(var(--color-settled))]',
    warning: 'bg-[hsl(var(--color-warning))]',
    system: 'bg-[hsl(var(--color-system))]',

    // ALIASES
    identity: 'bg-[hsl(var(--color-orientation))]',
    active: 'bg-[hsl(var(--color-execution))]',
    pending: 'bg-[hsl(var(--color-review))]',
    error: 'bg-[hsl(var(--color-warning))]',
    
    // QUESTIONS
    where: 'bg-[hsl(var(--color-orientation))]',
    what: 'bg-[hsl(var(--color-intent))]',
    how: 'bg-[hsl(var(--color-execution))]',
    when: 'bg-[hsl(var(--color-review))]',
    why: 'bg-[hsl(var(--color-warning))]',
    
    unknown: 'bg-[hsl(var(--layer-orientation))]',
  };
  
  return (
    <div className={cn("w-[6px] h-[6px] rounded-full shadow-[0_0_8px_currentColor] opacity-80", colorMap[type] || colorMap.settled, className)} />
  );
};


/* -------------------------------------------------------------------------- */
/*                            CHART PHYSICS                                   */
/* -------------------------------------------------------------------------- */

export const ChartFrame = ({ children, label, metric, trend, category = 'execution' }) => {
    const metricColorClass = {
        // SEMANTIC 7
        orientation: 'text-[hsl(var(--color-orientation))]',
        intent: 'text-[hsl(var(--color-intent))]',
        execution: 'text-[hsl(var(--color-execution))]',
        review: 'text-[hsl(var(--color-review))]',
        settled: 'text-[hsl(var(--color-settled))]',
        warning: 'text-[hsl(var(--color-warning))]',
        system: 'text-[hsl(var(--color-system))]',

        // ALIASES
        identity: 'text-[hsl(var(--color-orientation))]',
        active: 'text-[hsl(var(--color-execution))]',
        pending: 'text-[hsl(var(--color-review))]',
        error: 'text-[hsl(var(--color-warning))]',
        
        // QUESTIONS
        who: 'text-[hsl(var(--color-orientation))]',
        what: 'text-[hsl(var(--color-intent))]',
        how: 'text-[hsl(var(--color-execution))]',
        when: 'text-[hsl(var(--color-review))]',
        state: 'text-[hsl(var(--color-settled))]',
        why: 'text-[hsl(var(--color-warning))]',
        
        unknown: 'text-neutral-500'
    }[category] || 'text-[hsl(var(--color-settled))]';

    return (
        <div className="w-full h-full flex flex-col relative z-0">
            {/* Orientation Layer: Labels */}
            <div className="flex justify-between items-end mb-[9px] px-[3px] relative z-20 shrink-0">
                <OrientingText className="uppercase tracking-wider text-[10px] opacity-70">{label}</OrientingText>
                <div className="text-right">
                    <StateText className={cn("font-medium text-xs mode-numeric", metricColorClass)}>{metric}</StateText>
                    {trend && <StateText className="opacity-50 text-[9px]">{trend}</StateText>}
                </div>
            </div>
            
            {/* State Layer: Graph Surface */}
            <div className="flex-1 border-l border-b border-white/10 relative bg-neutral-900/50 overflow-hidden rounded-sm min-h-0">
                <div className="absolute inset-0 z-10">
                    {children}
                </div>
                {/* Field Layer: Grid hint */}
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none z-0 opacity-30" />
            </div>
        </div>
    );
};