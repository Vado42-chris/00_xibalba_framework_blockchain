// components/ui/design-system/design-tokens.js
// The Obsidian OS Design System ("Hallberg Maths" Implementation)

// Mathematical constants for Hallberg Maths
const PHI = 1.618033988749895; // Golden ratio
const E = 2.718281828459045; // Euler's number
const PI = 3.141592653589793; // Pi

// Pre-defined Hallberg Profiles (organic border-radius shapes)
export const hallbergProfiles = {
  subtle: '30% 70% 70% 30% / 30% 30% 70% 70%',
  moderate: '40% 60% 70% 30% / 30% 40% 60% 70%',
  prominent: '50% 50% 60% 40% / 40% 50% 50% 60%',
  fluid: '60% 40% 50% 50% / 50% 60% 40% 50%',
  organic: '45% 55% 65% 35% / 35% 45% 55% 65%',
};

export const theme = {
  name: 'obsidian',
  
  // --- Color Palette (Obsidian Dark Theme) ---
  colors: {
    // Backgrounds
    'bg-primary': '#0A0A0F',      // Main canvas background
    'bg-secondary': '#14141A',     // Panel/card background
    'bg-tertiary': '#1E1E26',     // Nested elements
    'bg-glass': 'rgba(15, 15, 25, 0.7)', // Base for glassmorphism
    'bg-glass-light': 'rgba(255, 255, 255, 0.05)',
    'bg-glass-heavy': 'rgba(255, 255, 255, 0.08)',

    // Text
    'text-primary': '#F0F0F6',    // Main text
    'text-secondary': '#B0B0C5',   // Subtitles, muted text
    'text-accent': '#7D7D95',      // Captions, hints
    'text-disabled': '#4A4A5A',    // Disabled text

    // Accent & Interactive
    'accent-primary': '#8A5CF6',   // Primary brand color (purple)
    'accent-secondary': '#2DD4BF', // Secondary brand color (cyan)
    'accent-danger': '#EF4444',    // Destructive actions
    'accent-warning': '#F59E0B',   // Warnings
    'accent-success': '#10B981',   // Success states
    'accent-info': '#3B82F6',      // Informational

    // Glassmorphism Borders & Glows
    'glass-border-light': 'rgba(255, 255, 255, 0.1)',
    'glass-border-medium': 'rgba(255, 255, 255, 0.15)',
    'glass-border-heavy': 'rgba(255, 255, 255, 0.25)',
    'glass-glow': 'rgba(138, 92, 246, 0.25)', // Purple glow
    'glass-glow-cyan': 'rgba(45, 212, 191, 0.2)', // Cyan glow
  },

  // --- Spacing & Layout (8px Grid System with Hallberg Maths) ---
  spacing: {
    'xs': '0.25rem',   // 4px
    'sm': '0.5rem',    // 8px
    'md': '1rem',      // 16px (base unit)
    'lg': `${1 * PHI}rem`, // ~26px (16 * 1.618)
    'xl': `${2 * PHI}rem`, // ~52px (32 * 1.618)
    'xxl': `${3 * PHI}rem`, // ~78px (48 * 1.618)
    // Hallberg Maths spacing (irrational multipliers)
    'phi-sm': `${0.5 * PHI}rem`, // ~13px
    'phi-md': `${1 * PHI}rem`,   // ~26px
    'phi-lg': `${2 * PHI}rem`,   // ~52px
    'e-sm': `${0.5 * E}rem`,     // ~14px
    'e-md': `${1 * E}rem`,       // ~27px
  },

  // --- Standardized Rounding (Corner Radius) ---
  rounding: {
    'none': '0',
    'small': '0.375rem',   // 6px - For buttons, inputs
    'medium': '0.5rem',    // 8px - For cards, panels
    'large': '1rem',       // 16px - For main containers, modals
    'xl': `${1 * PHI}rem`, // ~26px - For large containers
    'pill': '9999px',      // For pill-shaped elements
    'full': '9999px',      // For circles
    // Hallberg Profiles (organic shapes)
    'organic-subtle': hallbergProfiles.subtle,
    'organic-moderate': hallbergProfiles.moderate,
    'organic-prominent': hallbergProfiles.prominent,
    'organic-fluid': hallbergProfiles.fluid,
  },

  // --- Shadows & Depth ---
  shadows: {
    'none': 'none',
    'sm': '0 1px 2px 0 rgba(0, 0, 0, 0.05), 0 1px 2px 0 rgba(0, 0, 0, 0.06)',
    'md': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
    'lg': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
    'xl': '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
    'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.15)', // For glass panels
    'glass-heavy': '0 12px 40px 0 rgba(31, 38, 135, 0.2)',
    'glow-primary': `0 0 20px rgba(138, 92, 246, 0.3)`,
    'glow-secondary': `0 0 20px rgba(45, 212, 191, 0.3)`,
  },

  // --- Typography (Hallberg Maths Scale) ---
  typography: {
    'font-family': "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    'font-mono': "'JetBrains Mono', 'Fira Code', 'Cascadia Code', monospace",
    // Font sizes using Hallberg Maths (irrational multipliers)
    'size-xs': '0.75rem',           // 12px
    'size-sm': '0.875rem',          // 14px
    'size-base': '1rem',            // 16px (base)
    'size-md': `${1 * PHI}rem`,     // ~26px (16 * 1.618)
    'size-lg': `${1.5 * PHI}rem`,   // ~39px
    'size-xl': `${2 * PHI}rem`,     // ~52px
    'size-2xl': `${2.5 * PHI}rem`,  // ~65px
    'size-3xl': `${3 * PHI}rem`,    // ~78px
    // Line heights (harmonious ratios)
    'line-height-tight': '1.25',
    'line-height-normal': '1.5',
    'line-height-relaxed': `${PHI}`, // 1.618
    'line-height-loose': '2',
    // Font weights
    'weight-light': '300',
    'weight-normal': '400',
    'weight-medium': '500',
    'weight-semibold': '600',
    'weight-bold': '700',
  },

  // --- Glasnost (Glassmorphism) Component Styles ---
  // Pre-built, reusable style objects for glass effects
  glasnost: {
    // Light Glass (for subtle panels)
    'light': {
      background: 'rgba(255, 255, 255, 0.05)',
      backdropFilter: 'blur(16px) saturate(180%)',
      WebkitBackdropFilter: 'blur(16px) saturate(180%)',
      border: '1px solid rgba(255, 255, 255, 0.1)',
      borderRadius: '0.5rem',
      boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.15)',
    },
    // Medium Glass (for standard panels)
    'medium': {
      background: 'rgba(255, 255, 255, 0.06)',
      backdropFilter: 'blur(20px) saturate(180%)',
      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      border: '1px solid rgba(255, 255, 255, 0.15)',
      borderRadius: '0.5rem',
      boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.15)',
    },
    // Heavy Glass (for prominent panels)
    'heavy': {
      background: 'rgba(255, 255, 255, 0.08)',
      backdropFilter: 'blur(24px) saturate(180%)',
      WebkitBackdropFilter: 'blur(24px) saturate(180%)',
      border: '1px solid rgba(255, 255, 255, 0.25)',
      borderRadius: '1rem',
      boxShadow: '0 12px 40px 0 rgba(31, 38, 135, 0.2)',
    },
    // Organic Glass (with Hallberg profile)
    'organic': {
      background: 'rgba(255, 255, 255, 0.06)',
      backdropFilter: 'blur(20px) saturate(180%)',
      WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      border: '1px solid rgba(255, 255, 255, 0.15)',
      borderRadius: hallbergProfiles.moderate,
      boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.15)',
    },
  },

  // --- Motion & Transitions ---
  motion: {
    'fast': '150ms ease',
    'normal': '250ms ease',
    'slow': '350ms ease',
    'bounce': '400ms cubic-bezier(0.68, -0.55, 0.265, 1.55)',
    'smooth': '300ms cubic-bezier(0.4, 0, 0.2, 1)',
  },

  // --- Z-Index Scale ---
  zIndex: {
    'base': 0,
    'elevated': 10,
    'dropdown': 100,
    'sticky': 200,
    'fixed': 300,
    'modal-backdrop': 400,
    'modal': 500,
    'popover': 600,
    'tooltip': 700,
    'command-bar': 800,
    'notification': 900,
    'max': 9999,
  },
};

export default theme;