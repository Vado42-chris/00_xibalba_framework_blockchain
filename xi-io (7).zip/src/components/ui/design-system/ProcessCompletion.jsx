import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Download, Share2, Globe, FileText, ArrowRight } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/SystemDesign';
import { cn } from '@/lib/utils';

export default function ProcessCompletion({ 
    title = "Process Complete",
    subtitle = "Artifacts generated successfully.",
    artifacts = [], // [{ name, type, url, size }]
    actions = [], // [{ label, icon, onClick, primary }]
    onClose
}) {
    return (
        <Layer level="intervention" className="flex flex-col items-center justify-center p-8 space-y-8 animate-in fade-in zoom-in-95 duration-500 max-w-2xl mx-auto">
            {/* Success Icon */}
            <div className="relative">
                <div className="absolute inset-0 bg-[hsl(var(--color-execution))]/20 blur-xl rounded-full animate-pulse" />
                <div className="w-20 h-20 bg-[hsl(var(--color-execution))]/10 rounded-full flex items-center justify-center border border-[hsl(var(--color-execution))]/30 relative z-10">
                    <CheckCircle2 className="w-10 h-10 text-[hsl(var(--color-execution))]" />
                </div>
            </div>

            {/* Header */}
            <div className="text-center space-y-2 max-w-md">
                <IntentText className="text-3xl text-[hsl(var(--color-execution))]">{title}</IntentText>
                <StateText className="text-lg opacity-80">{subtitle}</StateText>
            </div>

            {/* Artifacts List */}
            {artifacts.length > 0 && (
                <div className="w-full bg-black/40 border border-white/10 rounded-lg overflow-hidden shadow-2xl">
                    <div className="bg-white/5 px-4 py-2 border-b border-white/5 flex justify-between items-center">
                        <OrientingText className="text-[10px]">GENERATED ARTIFACTS</OrientingText>
                        <StateText className="text-[10px] opacity-50">{artifacts.length} FILES</StateText>
                    </div>
                    <div className="divide-y divide-white/5">
                        {artifacts.map((artifact, i) => (
                            <div key={i} className="p-4 flex items-center justify-between group hover:bg-white/5 transition-colors">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 rounded bg-neutral-900 border border-white/10 text-neutral-400">
                                        <FileText className="w-4 h-4" />
                                    </div>
                                    <div>
                                        <div className="text-sm font-medium text-neutral-200">{artifact.name}</div>
                                        <div className="text-[10px] text-neutral-500 font-mono">{artifact.size} • {artifact.type}</div>
                                    </div>
                                </div>
                                <Button size="sm" variant="ghost" className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-[hsl(var(--color-intent))]/20 hover:text-[hsl(var(--color-intent))]">
                                    <Download className="w-4 h-4" />
                                </Button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Action Grid */}
            <div className="grid grid-cols-2 gap-4 w-full">
                {actions.map((action, i) => (
                    <Button 
                        key={i}
                        onClick={action.onClick}
                        variant={action.primary ? 'default' : 'outline'}
                        className={cn(
                            "h-12 border-white/10 transition-all active:scale-95",
                            action.primary 
                                ? "bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 shadow-[0_0_20px_-5px_hsl(var(--color-execution))]" 
                                : "hover:bg-white/5 text-neutral-300 hover:text-white"
                        )}
                    >
                        {action.icon && <action.icon className="w-4 h-4 mr-2" />}
                        {action.label}
                    </Button>
                ))}
                {onClose && (
                    <Button 
                        onClick={onClose}
                        variant="ghost" 
                        className="col-span-2 text-neutral-500 hover:text-white h-8 text-xs hover:bg-transparent"
                    >
                        Close & Return
                    </Button>
                )}
            </div>
        </Layer>
    );
}