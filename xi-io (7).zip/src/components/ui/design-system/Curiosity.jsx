import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { OrientingText, StateText, SemanticDot, IntentText } from './SystemDesign';
import { Sparkles, Brain, Calculator, Hourglass, Atom, ChevronDown, ChevronRight, Check, Loader2 } from 'lucide-react';
import { cn } from "@/components/ui/utils";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

/* -------------------------------------------------------------------------- */
/*                        SECTION 4: MICRO-LABS (LOADERS)                     */
/* -------------------------------------------------------------------------- */


// SECTION 4: HALLBERG MATHS (HUMOR ENGINE)
const HALLBERG_SCENARIOS = [
    {
        setup: "If this task finishes in under 3 seconds, it violates at least two known laws of computation.",
        math: "Given current entropy, expected duration = 7–11 seconds.",
        human: "You checked your phone anyway.",
        resolution: "Agent still working. You're doing great."
    },
    {
        setup: "Calculating the cost of this operation in photon-seconds.",
        math: "Light travels 300,000 km/s. This request traveled 4cm.",
        human: "The bottleneck is physics, not code.",
        resolution: "Physics negotiated. Proceeding."
    },
    {
        setup: "Attempting to reverse-engineer time for faster loading.",
        math: "Probability of causality violation: 0.00001%",
        human: "It felt longer than it was.",
        resolution: "Time direction confirmed: Forward."
    }
];

// SECTION 5: CURIOSITY WINDOWS (ROTATING INSIGHTS)
const CURIOSITY_INSIGHTS = [
    "This agent is reasoning across 42 possible paths.",
    "Most failures happen because humans interrupt too early.",
    "This task has already saved you ~14 keystrokes.",
    "Waiting is just data moving at the speed of light.",
    "Your patience prevents a retry loop.",
    "The system is currently winning an argument with a database.",
    "73% of loading time is just the handshake."
];

export const LoadingLab = ({ 
    active, 
    className,
    cause = "Processing Task", // Layer 1: CAUSE
    duration = "Unknown",      // Layer 2: TIME SCALE
    scenarios = HALLBERG_SCENARIOS, // Context-aware override
    insights = CURIOSITY_INSIGHTS,   // Context-aware override
    role = "user" // New: Role-based complexity
}) => {
    // 4 Phases for Hallberg Maths: Setup -> Math -> Human -> Resolution
    const [phase, setPhase] = useState(0); 
    const [scenarioIndex, setScenarioIndex] = useState(0);
    const [insightIndex, setInsightIndex] = useState(0);
    const [isOpen, setIsOpen] = useState(false);
    const [progressState, setProgressState] = useState("Initialized"); // Layer 5: 3->5->7 Loop

    useEffect(() => {
        if (!active) {
            setPhase(0);
            setProgressState("Initialized");
            return;
        }

        // Pick random content
        setScenarioIndex(Math.floor(Math.random() * scenarios.length));
        setInsightIndex(Math.floor(Math.random() * insights.length));

        // Cycle phases (Hallberg Maths) & Progress States
        // 3 -> 5 -> 7 Loop
        
        // 0s: Initialized / Setup
        const t1 = setTimeout(() => { 
            setPhase(1); // Math
            setProgressState("Prepared"); 
        }, 2000); 
        
        const t2 = setTimeout(() => { 
            setPhase(2); // Human
            setProgressState("Executing"); 
        }, 4500); 
        
        const t3 = setTimeout(() => { 
            setPhase(3); // Resolution
            setProgressState("Finalizing"); 
        }, 7000);

        const t4 = setTimeout(() => {
            setProgressState("Settled");
        }, 9000);

        return () => {
            [t1, t2, t3, t4].forEach(clearTimeout);
        };
    }, [active]);

    if (!active) return null;

    const scenario = scenarios[scenarioIndex];
    
    // Role-based complexity adjustment
    let text = [scenario.setup, scenario.math, scenario.human, scenario.resolution][phase] || scenario.resolution;
    
    if (role === 'admin' && phase === 1) {
        // Admins get more technical "Math"
        text = text.replace("expected duration", "latency P99").replace("seconds", "ms");
    } else if (role === 'developer' && phase === 1) {
        // Developers get debug info
        text = `Debug: ${text} | Heap: 45MB`;
    }
    
    const Icon = phase === 0 ? Calculator : phase === 1 ? Atom : phase === 2 ? Hourglass : Sparkles;

    return (
        <div className={cn("flex flex-col items-center justify-center p-8 space-y-6 w-full h-full bg-neutral-950/95 backdrop-blur-md absolute inset-0 z-50", className)}>
            
            {/* Layer 1: CAUSE & TIME SCALE */}
            <div className="absolute top-4 left-4 right-4 flex justify-between items-start opacity-70">
                <div className="flex flex-col text-left">
                     <OrientingText className="text-[9px] uppercase tracking-widest text-[hsl(var(--color-active))]">CAUSE</OrientingText>
                     <StateText className="text-xs">{cause}</StateText>
                </div>
                <div className="flex flex-col text-right">
                     <OrientingText className="text-[9px] uppercase tracking-widest text-[hsl(var(--color-active))]">EST. TIME</OrientingText>
                     <StateText className="text-xs font-mono">{duration}</StateText>
                </div>
            </div>

            {/* Layer 5: MICRO-PROGRESS STATES */}
            <div className="absolute top-4 flex justify-center w-full pointer-events-none">
                 <div className="px-3 py-1 rounded-full bg-[hsl(var(--color-active))]/10 border border-[hsl(var(--color-active))]/20 backdrop-blur-sm">
                    <StateText className="text-[9px] uppercase tracking-widest text-[hsl(var(--color-active))]">{progressState}</StateText>
                 </div>
            </div>

            {/* MAIN ANIMATION & HALLBERG MATHS */}
            <div className="relative">
                <div className="absolute inset-0 bg-[hsl(var(--color-active))] blur-3xl opacity-10 animate-pulse" />
                <Icon className={cn("w-10 h-10 text-[hsl(var(--color-active))] transition-all duration-700", phase % 2 === 0 ? "scale-100" : "scale-110 rotate-180")} />
            </div>
            
            <AnimatePresence mode="wait">
                <motion.div
                    key={phase}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.4 }}
                    className="text-center max-w-md relative z-10"
                >
                    <StateText className="text-lg font-light tracking-wide text-[hsl(var(--fg-intent))]">"{text}"</StateText>
                    
                    <div className="flex items-center justify-center gap-2 mt-4 opacity-40">
                        <span className="h-px w-8 bg-[hsl(var(--color-active))]" />
                        <OrientingText className="text-[9px] uppercase tracking-widest text-[hsl(var(--color-active))]">
                            {["SETUP", "MATHS", "TRUTH", "RESULT"][phase]}
                        </OrientingText>
                        <span className="h-px w-8 bg-[hsl(var(--color-active))]" />
                    </div>
                </motion.div>
            </AnimatePresence>
            
            <div className="flex gap-2 mt-2">
                {[0,1,2,3].map(i => (
                    <div key={i} className={cn("w-1.5 h-1.5 rounded-full transition-all duration-500", phase >= i ? "bg-[hsl(var(--color-active))]" : "bg-[hsl(var(--layer-orientation))]")} />
                ))}
            </div>

            {/* Layer 6: INTERACTIVE & Layer 7: CURIOSITY WINDOWS */}
            <Collapsible open={isOpen} onOpenChange={setIsOpen} className="w-full max-w-sm absolute bottom-8 z-50">
                <div className="flex justify-center mb-2">
                    <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="text-neutral-500 h-6 text-[10px] hover:bg-white/5 gap-1">
                            {isOpen ? "MINIMIZE CURIOSITY" : "OPEN CURIOSITY WINDOW"} {isOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                        </Button>
                    </CollapsibleTrigger>
                </div>
                <CollapsibleContent className="space-y-2 animate-in slide-in-from-bottom-2 fade-in">
                    <div className="bg-neutral-900 border border-white/10 p-4 rounded text-left shadow-2xl">
                        <div className="flex items-center gap-2 mb-2">
                             <Brain className="w-3 h-3 text-[hsl(var(--color-active))]" />
                             <OrientingText className="text-[9px] uppercase tracking-widest">SYSTEM INSIGHT</OrientingText>
                        </div>
                        <StateText className="text-xs leading-relaxed opacity-90 italic">
                            "{insights[insightIndex]}"
                        </StateText>
                        
                        {progressState === 'Settled' && (
                             <div className="mt-3 pt-2 border-t border-white/5 text-[hsl(var(--color-active))] text-xs flex items-center gap-2">
                                <Check className="w-3 h-3" />
                                <span>You avoided a retry loop.</span>
                             </div>
                        )}
                    </div>
                </CollapsibleContent>
            </Collapsible>
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                        SECTION 6: EDUCATIONAL TIPS                         */
/* -------------------------------------------------------------------------- */

export const InsightTip = ({ type = "observation", title, children, className }) => {
    // Types: observation (cosmic), mirror (user reflection), experiment (ridiculous)
    
    const iconMap = {
        observation: Brain,
        mirror: Hourglass,
        experiment: Atom
    };
    
    const Icon = iconMap[type] || Brain;

    return (
        <div className={cn("group relative pl-4 border-l-2 border-[hsl(var(--color-pending))] bg-neutral-900/30 rounded-r-lg p-3 max-w-sm transition-all hover:bg-neutral-900/50", className)}>
            <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-[hsl(var(--color-pending))]" />
            <div className="flex gap-3 items-start">
                <Icon className="w-4 h-4 text-[hsl(var(--color-pending))] mt-0.5 shrink-0 opacity-70 group-hover:opacity-100 transition-opacity" />
                <div className="space-y-1">
                     {title && <OrientingText className="text-[9px] uppercase tracking-widest text-neutral-500">{title}</OrientingText>}
                     <StateText className="text-white leading-relaxed text-xs">
                        {children}
                     </StateText>
                </div>
            </div>
        </div>
    )
}