import React from 'react';
import { 
    // Navigation
    Home, Search, Menu, ArrowLeft, ArrowRight, ChevronDown, ChevronRight,
    ExternalLink, X, Maximize2, Minimize2, Grid, List, MoreHorizontal,
    
    // Actions
    Plus, Trash2, Edit2, Save, Download, Upload, Share2, Copy, 
    RefreshCw, Settings, LogOut, Lock, Unlock, Eye, EyeOff,
    
    // Objects/Entities
    User, Users, File, Folder, Image, Mail, Calendar, 
    CreditCard, Box, Package, Database, Server, Smartphone, Monitor,
    
    // Status/Feedback
    Check, AlertCircle, AlertTriangle, Info, HelpCircle, 
    Loader2, Activity, Zap, Shield, Bell,
    
    // Domain Specific
    Code, Terminal, Cpu, GitBranch, GitMerge, GitPullRequest,
    PenTool, Mic, Camera, Video, Music, Sparkles,
    Briefcase, Building2, ShoppingBag, Scale, Gavel
} from 'lucide-react';
import { cn } from "@/components/ui/utils";

// --- THE ICON REGISTRY ---
// A centralized index of all system icons categorized by semantic intent.

export const SYSTEM_ICONS = {
    NAVIGATION: {
        Home, Search, Menu, Back: ArrowLeft, Forward: ArrowRight, 
        Expand: ChevronDown, Next: ChevronRight, External: ExternalLink,
        Close: X, Maximize: Maximize2, Minimize: Minimize2,
        Grid, List, More: MoreHorizontal
    },
    ACTION: {
        Add: Plus, Delete: Trash2, Edit: Edit2, Save, 
        Download, Upload, Share: Share2, Copy, Refresh: RefreshCw,
        Settings, Logout: LogOut, Lock, Unlock, View: Eye, Hide: EyeOff
    },
    ENTITY: {
        User, Users, File, Folder, Image, Mail, Calendar,
        Card: CreditCard, Box, Product: Package, Database, 
        Server, Device: Smartphone, Desktop: Monitor
    },
    STATUS: {
        Success: Check, Error: AlertCircle, Warning: AlertTriangle, 
        Info, Help: HelpCircle, Loading: Loader2, 
        Active: Activity, Power: Zap, Secure: Shield, Notification: Bell
    },
    DOMAIN: {
        Code, Terminal, Processor: Cpu, Branch: GitBranch, 
        Merge: GitMerge, PR: GitPullRequest,
        Design: PenTool, Audio: Mic, Photo: Camera, Video, 
        Music, Magic: Sparkles, Business: Briefcase, 
        Company: Building2, Shop: ShoppingBag, Legal: Scale, Justice: Gavel
    }
};

// --- COMPONENT ---

export const SystemIcon = ({ 
    name, // "Add", "Home", "User" - lookup key
    category, // Optional: "ACTION", "NAVIGATION" - optimization
    icon, // Direct component override
    className,
    ...props 
}) => {
    // 1. Direct Icon Prop
    if (icon) {
        const IconComp = icon;
        return <IconComp className={cn("w-4 h-4", className)} {...props} />;
    }

    // 2. Lookup by Name
    let ResolvedIcon = null;
    
    if (category && SYSTEM_ICONS[category]) {
        ResolvedIcon = SYSTEM_ICONS[category][name];
    } else {
        // Search all categories
        for (const cat of Object.values(SYSTEM_ICONS)) {
            if (cat[name]) {
                ResolvedIcon = cat[name];
                break;
            }
        }
    }

    if (!ResolvedIcon) {
        console.warn(`SystemIcon: Icon "${name}" not found.`);
        return <HelpCircle className={cn("w-4 h-4 opacity-50", className)} {...props} />;
    }

    return <ResolvedIcon className={cn("w-4 h-4", className)} {...props} />;
};