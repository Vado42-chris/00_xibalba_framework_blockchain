import React from 'react';
import { cn } from "@/components/ui/utils";
import { OrientingText, StateText } from '@/components/ui/design-system/SystemDesign';
import { 
  LineChart, Line, BarChart, Bar, 
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Cell
} from 'recharts';

/* -------------------------------------------------------------------------- */
/*                    XI-IO / DREAMCATCHER VISUALIZATION                      */
/* -------------------------------------------------------------------------- */
/* 
   SECTION 1: GRAPHICS ARE STATE, NOT STORY
   A graph answers: "What is the state of this system relative to itself?"
   
   SECTION 2: THE 3-LAYER VISUAL STACK
   1. FRAME (Orientation): Boundary, Axes, Scale. Quiet, Neutral.
   2. SIGNAL (Intent): What moved? Dominant, Active.
   3. TRACE (State): What happened? Muted, Thin, Persistent.

   SECTION 3: ALLOWED TYPES
   Allowed: Line (Time), Bar (Compare), Step (State), Heat band (Density), Node-link.
   FORBIDDEN: Pie, 3D, Exploded Views, Marketing Aesthetics.
*/

const THEME = {
  colors: {
    // Semantic Roles
    signal: 'hsl(var(--color-intent))',  // Active Change
    trace: 'hsl(var(--fg-orientation))', // History/Memory
    frame: 'hsl(var(--layer-orientation))', // Boundary
    
    // Categories
    who: 'hsl(var(--color-orientation))',
    what: 'hsl(var(--color-intent))',
    where: 'hsl(var(--color-orientation))',
    when: 'hsl(var(--color-review))',
    why: 'hsl(var(--color-intent))',
    how: 'hsl(var(--color-execution))',
    state: 'hsl(var(--color-settled))',
  },
  grid: 'rgba(255,255,255,0.03)', // "Visible but quiet"
  text: '#a3a3a3' // neutral-400
};

/* -------------------------------------------------------------------------- */
/*                            A. LINE GRAPHS (TIME)                           */
/* -------------------------------------------------------------------------- */
/* 
   Purpose: Change over time.
   Rules: Left->Right only. Max 2 secondary lines. No smoothing.
*/

export const TimeGraph = ({ 
  data, 
  dataKey, 
  category = 'state', 
  height = 200, 
  traceKeys = [], // "TRACE" Layer: History/Context
  secondaryKeys = [] // Backward compatibility
}) => {
  const primaryColor = THEME.colors[category] || THEME.colors.state;
  const traces = [...traceKeys, ...secondaryKeys];

  return (
    <div className="w-full select-none" style={{ height }}>
      {/* FRAME LAYER: Orientation */}
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
          <CartesianGrid stroke={THEME.grid} vertical={false} />
          <XAxis 
            dataKey="t" 
            stroke={THEME.text} 
            fontSize={9} 
            tickLine={false} 
            axisLine={false}
            fontFamily="monospace"
            opacity={0.5}
          />
          <YAxis 
            stroke={THEME.text} 
            fontSize={9} 
            tickLine={false} 
            axisLine={false}
            fontFamily="monospace"
            opacity={0.5}
            domain={['auto', 'auto']} // Section 4: Scale Honesty (auto but constrained)
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#171717', // neutral-900
              borderColor: 'rgba(255,255,255,0.1)',
              fontSize: '10px',
              fontFamily: 'monospace',
              boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
            }}
            itemStyle={{ color: '#fff' }}
            cursor={{ stroke: '#525252', strokeWidth: 1 }}
            formatter={(value) => [value, '']} // Factual, no labels if possible
          />
          
          {/* TRACE LAYER: Memory (Muted, Thin, Persistent) */}
          {traces.map((key, idx) => (
             <Line 
                key={key}
                type="linear" // No smoothing
                dataKey={key}
                stroke={THEME.colors.trace}
                strokeWidth={1}
                dot={false}
                opacity={0.3} // "Muted"
                isAnimationActive={false} // "Trace is memory, not drama"
             />
          ))}

          {/* SIGNAL LAYER: Intent (Dominant, Active) */}
          <Line 
            type="linear" 
            dataKey={dataKey} 
            stroke={primaryColor} 
            strokeWidth={2} // Dominant signal
            dot={false}
            activeDot={{ r: 3, fill: primaryColor, stroke: 'hsl(var(--void))' }}
            isAnimationActive={true}
            animationDuration={800}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};


/* -------------------------------------------------------------------------- */
/*                            B. BAR GRAPHS (COMPARISON)                      */
/* -------------------------------------------------------------------------- */
/* 
   Purpose: Compare settled states.
   Rules: Vertical preferred. No "infographic bars". Baseline always visible.
*/

export const CompareGraph = ({ 
  data, 
  dataKey, 
  category = 'what',
  height = 150 
}) => {
  const barColor = THEME.colors[category] || THEME.colors.state;

  return (
    <div className="w-full select-none" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
          <CartesianGrid stroke={THEME.grid} vertical={false} />
          <XAxis 
            dataKey="name" 
            stroke={THEME.text} 
            fontSize={9} 
            tickLine={false} 
            axisLine={false}
            fontFamily="monospace"
            opacity={0.5}
          />
          <YAxis 
            stroke={THEME.text} 
            fontSize={9} 
            tickLine={false} 
            axisLine={false}
            fontFamily="monospace"
            opacity={0.5}
          />
          <Tooltip 
             cursor={{ fill: THEME.colors.trace, opacity: 0.1 }}
             contentStyle={{ 
                backgroundColor: '#171717', // neutral-900
                border: '1px solid rgba(255,255,255,0.1)',
                fontSize: '10px',
                fontFamily: 'monospace',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
             }}
             formatter={(value) => [value, '']}
          />
          {/* SIGNAL LAYER: Single Dominant Signal */}
          <Bar 
             dataKey={dataKey} 
             fill={barColor} 
             radius={[1, 1, 0, 0]}
             isAnimationActive={true}
             animationDuration={300}
             barSize={20} // Discrete comparison, consistent width
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/*                            C. PROGRESS LATTICE                             */
/* -------------------------------------------------------------------------- */
/* 
   Purpose: System State / Capacity.
   Rules: Uniform grid. Color = state.
*/

export const ProgressLattice = ({ total = 100, value = 0, category = 'how' }) => {
   const cells = Array.from({ length: 20 }); // 20 cells represents 100% (5% each)
   const activeCells = Math.ceil((value / 100) * 20);
   const colorClass = {
      who: 'bg-[hsl(var(--color-orientation))]',
      what: 'bg-[hsl(var(--color-intent))]',
      where: 'bg-[hsl(var(--color-orientation))]',
      when: 'bg-[hsl(var(--color-review))]',
      why: 'bg-[hsl(var(--color-intent))]',
      how: 'bg-[hsl(var(--color-execution))]',
      state: 'bg-[hsl(var(--color-settled))]',
   }[category] || 'bg-[hsl(var(--color-settled))]';

   return (
      <div className="flex gap-0.5 w-full">
         {cells.map((_, i) => (
            <div 
               key={i} 
               className={cn(
                  "h-2 flex-1 rounded-[1px] transition-all duration-300",
                  i < activeCells ? colorClass : "bg-[hsl(var(--layer-intent))]"
               )}
               style={{
                  opacity: i < activeCells ? 1 : 0.3
               }}
            />
         ))}
      </div>
   );
};

/* -------------------------------------------------------------------------- */
/*                            D. STATE BARS                                   */
/* -------------------------------------------------------------------------- */
/*
   Purpose: Progress / Lifecycle.
   Rules: Segmented by 5-state model. Color intensity increases with commitment.
*/

export const StateBar = ({ value, max = 100, label, category = 'state' }) => {
   const percentage = (value / max) * 100;
   
   // 5 segments representing the 5 states of commitment
   const segments = [20, 40, 60, 80, 100];
   
   const getColor = (threshold) => {
       if (percentage < threshold - 20) return '#0a0a0a'; // neutral-950
       const baseColor = THEME.colors[category] || THEME.colors.state;
       return baseColor;
   };

   return (
       <div className="w-full space-y-1">
           {label && (
               <div className="flex justify-between text-[10px] font-mono text-neutral-500">
                   <span>{label}</span>
                   <span>{Math.round(percentage)}%</span>
               </div>
           )}
           <div className="flex gap-1 h-1.5 w-full">
               {segments.map((threshold, i) => (
                   <div 
                       key={threshold}
                       className="flex-1 rounded-[1px] bg-neutral-950 overflow-hidden"
                   >
                       <div 
                           className="h-full transition-all duration-500"
                           style={{ 
                               width: percentage >= threshold ? '100%' : percentage > threshold - 20 ? `${(percentage % 20) * 5}%` : '0%',
                               backgroundColor: getColor(threshold),
                               opacity: 0.2 + (i * 0.2) // Increasing intensity
                           }}
                       />
                   </div>
               ))}
           </div>
       </div>
   );
};

/* -------------------------------------------------------------------------- */
/*                            E. BLOCK MAPS                                   */
/* -------------------------------------------------------------------------- */
/*
   Purpose: Phases / Systems / Ownership.
   Rules: Blocks represent state, not size. Spacing implies separation.
*/

export const BlockMap = ({ items, categoryKey = 'status' }) => {
    // items: { id, label, status }
    
    const getStatusColor = (status) => {
        switch(status) {
            case 'active': return 'bg-[hsl(var(--color-active))]';
            case 'pending': return 'bg-[hsl(var(--color-pending))]';
            case 'error': return 'bg-[hsl(var(--color-error))]';
            case 'settled': return 'bg-[hsl(var(--color-settled))]';
            default: return 'bg-[hsl(var(--layer-orientation))]';
        }
    };

    return (
        <div className="flex flex-wrap gap-2">
            {items.map((item) => (
                <div 
                    key={item.id} 
                    className="flex flex-col gap-1 min-w-[80px] flex-1 p-2 rounded border border-[hsl(var(--layer-orientation))] bg-[hsl(var(--layer-orientation))]"
                >
                    <div className={cn("h-1 w-full rounded-full", getStatusColor(item[categoryKey]))} />
                    <span className="text-[10px] font-mono text-[hsl(var(--fg-intent))] truncate">
                        {item.label}
                    </span>
                </div>
            ))}
        </div>
    );
};


/* -------------------------------------------------------------------------- */
/*                            F. DIFF VIEW (DELTA)                            */
/* -------------------------------------------------------------------------- */
/* 
   Purpose: What changed, exactly.
   Rules: Mono font. Visual distinction. No commentary.
*/

export const DeltaDiff = ({ original, modified }) => {
   // Simple line diff logic visualization
   return (
      <div className="font-mono text-[10px] leading-relaxed w-full bg-[hsl(var(--layer-state))] p-2 rounded border border-[hsl(var(--layer-orientation))]">
         <div className="flex justify-between items-center text-[hsl(var(--fg-orientation))] border-b border-[hsl(var(--layer-orientation))] pb-1 mb-1">
            <span>DELTA</span>
            <span>SHA: 8A2F...</span>
         </div>
         {original && (
            <div className="flex gap-2 opacity-50 text-[hsl(var(--color-warning))]">
               <span className="select-none w-4">-</span>
               <span className="line-through">{original}</span>
            </div>
         )}
         {modified && (
            <div className="flex gap-2 text-[hsl(var(--color-intent))] font-bold">
               <span className="select-none w-4">+</span>
               <span>{modified}</span>
            </div>
         )}
      </div>
   );
};

export const ChartFrame = ({ children, label, metric, trend, category = 'execution' }) => {
    const metricColorClass = {
        // SEMANTIC 7
        orientation: 'text-[hsl(var(--color-orientation))]',
        intent: 'text-[hsl(var(--color-intent))]',
        execution: 'text-[hsl(var(--color-execution))]',
        review: 'text-[hsl(var(--color-review))]',
        settled: 'text-[hsl(var(--color-settled))]',
        warning: 'text-[hsl(var(--color-warning))]',
        system: 'text-[hsl(var(--color-system))]',

        // ALIASES
        identity: 'text-[hsl(var(--color-orientation))]',
        active: 'text-[hsl(var(--color-execution))]',
        pending: 'text-[hsl(var(--color-review))]',
        error: 'text-[hsl(var(--color-warning))]',
        
        // QUESTIONS
        who: 'text-[hsl(var(--color-orientation))]',
        what: 'text-[hsl(var(--color-intent))]',
        how: 'text-[hsl(var(--color-execution))]',
        when: 'text-[hsl(var(--color-review))]',
        state: 'text-[hsl(var(--color-settled))]',
        why: 'text-[hsl(var(--color-warning))]',
        
        unknown: 'text-[hsl(var(--fg-orientation))]'
    }[category] || 'text-[hsl(var(--color-settled))]';

    return (
        <div className="w-full h-full flex flex-col relative z-0">
            {/* Orientation Layer: Labels */}
            <div className="flex justify-between items-end mb-[9px] px-[3px] relative z-20">
                <OrientingText className="uppercase tracking-wider text-[10px] opacity-70">{label}</OrientingText>
                <div className="text-right">
                    <StateText className={cn("font-medium text-xs mode-numeric", metricColorClass)}>{metric}</StateText>
                    {trend && <StateText className="opacity-50 text-[9px]">{trend}</StateText>}
                </div>
            </div>
            
            {/* State Layer: Graph Surface */}
            <div className="flex-1 border-l border-b border-[hsl(var(--layer-orientation))] relative bg-state overflow-hidden rounded-sm">
                <div className="absolute inset-0 z-10">
                    {children}
                </div>
                {/* Field Layer: Grid hint */}
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none z-0 opacity-30" />
            </div>
        </div>
    );
};