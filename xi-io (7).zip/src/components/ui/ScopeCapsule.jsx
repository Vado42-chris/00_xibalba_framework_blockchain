import React from 'react';
import { OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/System';
import { AlertTriangle, Clock, RotateCcw, ArrowRight } from 'lucide-react';

export default function ScopeCapsule({ 
  target = "Unknown Target",
  environment = "Production",
  duration = "Permanent",
  reversibility = "Irreversible",
  impact = "High",
  children
}) {
  const isDestructive = impact === "High" || impact === "Critical";
  const themeColor = isDestructive ? 'var(--color-error)' : 'var(--color-warning)';

  return (
    <Layer level="intervention" className={`border-l-4 ${isDestructive ? 'border-l-[hsl(var(--color-error))]' : 'border-l-[hsl(var(--color-warning))]'} my-4`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" style={{ color: `hsl(${themeColor})` }} />
          <OrientingText className="text-xs font-bold tracking-widest uppercase" style={{ color: `hsl(${themeColor})` }}>
            Scope of Action
          </OrientingText>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 text-xs font-mono">
        <div>
          <StateText className="block mb-1 opacity-50">Target</StateText>
          <IntentText className="flex items-center gap-1">
            <ArrowRight className="w-3 h-3" /> {target}
          </IntentText>
        </div>
        <div>
          <StateText className="block mb-1 opacity-50">Environment</StateText>
          <IntentText>{environment}</IntentText>
        </div>
        <div>
          <StateText className="block mb-1 opacity-50">Duration</StateText>
          <IntentText className="flex items-center gap-1">
            <Clock className="w-3 h-3" /> {duration}
          </IntentText>
        </div>
        <div>
          <StateText className="block mb-1 opacity-50">Reversibility</StateText>
          <span className={`flex items-center gap-1 ${reversibility.toLowerCase().includes('irrev') ? 'text-[hsl(var(--color-error))]' : 'text-[hsl(var(--color-execution))]'}`}>
            <RotateCcw className="w-3 h-3" /> {reversibility}
          </span>
        </div>
      </div>

      {children && (
        <div className="pt-4 mt-4 border-t border-white/5">
          {children}
        </div>
      )}
    </Layer>
  );
}