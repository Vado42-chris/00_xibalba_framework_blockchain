import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Terminal, Sparkles, AlertTriangle, RefreshCw, Copy, Check, ChevronRight, Bug, Zap, Wrench } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from '@/components/ui/utils';
import { toast } from 'sonner';

export const SmartErrorAnalyzer = ({ error, componentStack }) => {
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [isRepairing, setIsRepairing] = useState(false);
    const [analysis, setAnalysis] = useState(null);
    const [lastFixedFileId, setLastFixedFileId] = useState(null);

    const handleRepair = async () => {
        setIsRepairing(true);
        try {
            const res = await base44.functions.invoke('autoFix', {
                error: error?.toString(),
                stack: componentStack,
                diagnosis: analysis.diagnosis,
                fix: analysis.fix
            });
            
            if (res.data?.success) {
                setLastFixedFileId(res.data.fileId);
                toast.success("Repair Successful", { 
                    description: `Fixed ${res.data.file}. Rebooting in 3s...`,
                    action: {
                        label: "Undo",
                        onClick: () => handleRollback(res.data.fileId)
                    }
                });
                // Delay reload slightly longer to allow undo
                setTimeout(() => window.location.reload(), 3000);
            } else {
                toast.error("Repair Failed", { description: res.data?.message || "Could not apply fix." });
            }
        } catch (e) {
            toast.error("Repair Failed", { description: e.message });
        } finally {
            setIsRepairing(false);
        }
    };

    const handleRollback = async (fileId) => {
        try {
            const res = await base44.functions.invoke('autoFix', {
                action: 'rollback',
                fileId: fileId
            });
            if (res.data?.success) {
                toast.success("Rollback Successful", { description: "Restored previous version. Reloading..." });
                setTimeout(() => window.location.reload(), 1000);
            } else {
                toast.error("Rollback Failed", { description: res.data?.message });
            }
        } catch(e) {
            toast.error("Rollback Failed", { description: e.message });
        }
    };

    const handleAnalyze = async () => {
        setIsAnalyzing(true);
        try {
            const result = await base44.integrations.Core.InvokeLLM({
                prompt: `You are the "Healer" protocol of an advanced AI operating system. 
                A critical frontend error has occurred. Analyze the traceback and provide a solution.
                
                ERROR: ${error?.toString()}
                STACK: ${componentStack}

                Return a JSON object with:
                - diagnosis: A clear, non-technical explanation of what went wrong (1 sentence).
                - technical_details: The likely technical cause (e.g. "Missing import", "Undefined variable").
                - fix: The specific code change needed (e.g. "Import Shield from lucide-react").
                - confidence: number (0-100).
                `,
                response_json_schema: {
                    type: "object",
                    properties: {
                        diagnosis: { type: "string" },
                        technical_details: { type: "string" },
                        fix: { type: "string" },
                        confidence: { type: "integer" }
                    }
                }
            });
            setAnalysis(result);
        } catch (e) {
            setAnalysis({
                diagnosis: "Connection to Healer protocol failed.",
                technical_details: "Network or API error.",
                fix: "Check internet connection or API keys.",
                confidence: 0
            });
        } finally {
            setIsAnalyzing(false);
        }
    };

    return (
        <div className="mt-6 space-y-4">
            {!analysis && (
                <Button 
                    onClick={handleAnalyze}
                    disabled={isAnalyzing}
                    className="w-full bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 font-mono tracking-wider text-xs uppercase h-12"
                >
                    {isAnalyzing ? (
                        <>
                            <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                            Establishing Uplink...
                        </>
                    ) : (
                        <>
                            <Bug className="w-4 h-4 mr-2" />
                            Initiate AI Diagnostics
                        </>
                    )}
                </Button>
            )}

            {analysis && (
                <div className="rounded-lg bg-neutral-950 border border-white/10 overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-500">
                    <div className="bg-neutral-900/50 px-4 py-2 border-b border-white/5 flex items-center justify-between">
                        <div className="flex items-center gap-2 text-[10px] uppercase font-bold text-emerald-500 tracking-wider">
                            <Terminal className="w-3 h-3" />
                            Healer Protocol
                        </div>
                        <div className="text-[10px] text-neutral-500 font-mono">
                            Confidence: {analysis.confidence}%
                        </div>
                    </div>
                    
                    <div className="p-4 space-y-4">
                        <div className="space-y-1">
                            <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wide">Diagnosis</h4>
                            <p className="text-sm text-neutral-400 leading-relaxed">{analysis.diagnosis}</p>
                        </div>

                        <div className="p-3 bg-neutral-900 rounded border border-white/5 space-y-2">
                            <h4 className="text-xs font-bold text-neutral-300 uppercase tracking-wide flex items-center gap-2">
                                <Zap className="w-3 h-3 text-yellow-500" />
                                Recommended Fix
                            </h4>
                            <code className="block text-xs font-mono text-emerald-400 bg-black/30 p-2 rounded">
                                {analysis.fix}
                            </code>
                            <Button 
                                onClick={handleRepair} 
                                disabled={isRepairing}
                                size="sm"
                                className="w-full mt-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20"
                            >
                                {isRepairing ? (
                                    <>
                                        <RefreshCw className="w-3 h-3 mr-2 animate-spin" />
                                        Applying Fix...
                                    </>
                                ) : (
                                    <>
                                        <Wrench className="w-3 h-3 mr-2" />
                                        Auto-Repair Code
                                    </>
                                )}
                            </Button>
                        </div>

                        <div className="pt-2 border-t border-white/5">
                             <p className="text-[10px] text-neutral-600 font-mono">
                                Technical: {analysis.technical_details}
                             </p>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export class SmartErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("SmartErrorBoundary caught:", error, errorInfo);
    this.setState({ errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex items-center justify-center min-h-screen bg-neutral-950 text-white p-6 font-sans">
            <div className="w-full max-w-2xl">
                <div className="relative w-full overflow-hidden rounded-xl border-l-4 bg-neutral-900/50 backdrop-blur-sm p-8 border-l-rose-500 border-rose-500/20 shadow-2xl">
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none opacity-20" />
                    
                    <div className="relative z-10 flex flex-col gap-6">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase border bg-rose-500/10 text-rose-500 border-rose-500/20">
                                    <div className="w-2 h-2 rounded-full bg-current animate-pulse" />
                                    <span>CRITICAL FAILURE</span>
                                </div>
                                <span className="text-[10px] text-neutral-500 font-mono">Code: 0xDEAD</span>
                            </div>
                            <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => window.location.reload()}
                                className="text-[10px] text-neutral-500 hover:text-white uppercase tracking-widest"
                            >
                                <RefreshCw className="w-3 h-3 mr-2" />
                                Reboot
                            </Button>
                        </div>

                        <div className="space-y-2">
                            <h1 className="text-4xl font-light tracking-tight text-white leading-tight">
                                System Unstable.
                            </h1>
                            <p className="text-lg text-neutral-400 font-light leading-relaxed max-w-lg">
                                An unrecoverable error has occurred in the interface layer. Core data remains secure.
                            </p>
                        </div>

                        <div className="bg-black/40 rounded-lg border border-white/5 font-mono text-xs text-rose-300 overflow-hidden">
                            <div className="px-4 py-2 border-b border-white/5 bg-white/5 text-neutral-500 text-[10px] uppercase tracking-wider flex justify-between items-center">
                                <span>Stack Trace</span>
                                <button 
                                    onClick={() => {
                                        navigator.clipboard.writeText(this.state.error?.toString() + "\n" + this.state.errorInfo?.componentStack);
                                        toast.success("Error copied to clipboard");
                                    }}
                                    className="hover:text-white transition-colors"
                                >
                                    <Copy className="w-3 h-3" />
                                </button>
                            </div>
                            <ScrollArea className="h-32 w-full">
                                <div className="p-4">
                                    <div className="font-bold mb-2">{this.state.error?.toString()}</div>
                                    <div className="opacity-50 whitespace-pre-wrap">{this.state.errorInfo?.componentStack}</div>
                                </div>
                            </ScrollArea>
                        </div>
                        
                        <SmartErrorAnalyzer 
                            error={this.state.error} 
                            componentStack={this.state.errorInfo?.componentStack} 
                        />
                        
                    </div>
                </div>
            </div>
        </div>
      );
    }

    return this.props.children;
  }
}