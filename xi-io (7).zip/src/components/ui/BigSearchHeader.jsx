import React, { useState } from 'react';
import { Search, Command, ArrowRight } from 'lucide-react';
import { cn } from '@/components/ui/utils';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export function BigSearchHeader({ onClick }) {
    const navigate = useNavigate();
    const [query, setQuery] = useState('');

    const handleSearch = (e) => {
        if (e.key === 'Enter' && query.trim()) {
            navigate(createPageUrl('SearchResults') + `?q=${encodeURIComponent(query)}`);
        }
    };

    return (
        <div className="w-full mb-0 px-6 pt-8 pb-8 bg-gradient-to-b from-neutral-900/50 to-transparent border-b border-white/5">
            <div className="flex items-center gap-0 w-full">
                {/* Left Column: Brand/Logo - Aligned with 280px Sidebar (280px - 24px padding = 256px) */}
                <div className="shrink-0 w-[256px] flex justify-center opacity-80 hover:opacity-100 transition-opacity">
                     <img 
                       src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693dffcccab0bea12e1e7952/a02aa7415_logo.png" 
                       alt="System Logo" 
                       className="h-32 w-auto object-contain"
                     />
                </div>

                {/* Right Column: Search - Aligned with Content */}
                <div className="flex-1 pl-4">
                    <div 
                        className="w-full group relative flex items-center gap-4 bg-neutral-900/50 hover:bg-neutral-900 border border-white/10 hover:border-[hsl(var(--color-intent))]/50 px-6 py-2 rounded-xl transition-all duration-300 shadow-lg hover:shadow-[hsl(var(--color-intent))]/5"
                    >
                        <Search className="w-6 h-6 text-neutral-500 group-hover:text-[hsl(var(--color-intent))] transition-colors" />
                        <div className="flex-1">
                            <input 
                                type="text"
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                onKeyDown={handleSearch}
                                placeholder="Cast your net into the Dreamcatcher Web..."
                                className="w-full bg-transparent border-none outline-none text-lg font-light text-white placeholder:text-neutral-500 h-12"
                            />
                        </div>
                        <button 
                            onClick={onClick}
                            className="hidden md:flex items-center gap-2 px-2 py-1 bg-neutral-950 rounded border border-white/10 text-xs font-mono text-neutral-500 hover:text-white cursor-pointer hover:border-white/20 transition-all"
                            title="Open Global Command Palette"
                        >
                            <Command className="w-3 h-3" />
                            <span>K</span>
                        </button>
                    </div>
                    <div className="flex justify-center gap-8 mt-3 text-[10px] uppercase tracking-widest text-neutral-600 font-mono">
                        <span>Total Records: 84.2M</span>
                        <span>Index Latency: 12ms</span>
                        <span className="flex items-center gap-1.5 text-blue-500/50">
                            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                            Web Uplink: Ready
                        </span>
                    </div>
                </div>
            </div>
            
        </div>
    );
}