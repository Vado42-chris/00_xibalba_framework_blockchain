import React, { useState, useEffect } from 'react';
import { cn } from "@/lib/utils";
import { useSiteContext } from '@/components/identity/SiteContext';

export const BrandLogo = ({ className, size = "default", variant = "full" }) => {
    // size: "default" | "large" | "small"
    // variant: "full" | "icon"
    
    const { systemConfig } = useSiteContext();
    const hardcodedSrc = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693dffcccab0bea12e1e7952/a02aa7415_logo.png";
    const logoSrc = systemConfig?.logo_url || hardcodedSrc;
    const [hasError, setHasError] = useState(false);

    useEffect(() => {
        setHasError(false);
    }, [logoSrc]);

    return (
        <div className={cn("flex items-center justify-center select-none", className)}>
            {!hasError ? (
                <img 
                    src={logoSrc} 
                    alt="Brand Logo"
                    className={cn(
                        "object-contain transition-all",
                        size === "large" ? "h-32 md:h-40" : size === "small" ? "h-8" : "h-16"
                    )}
                    onError={() => setHasError(true)}
                />
            ) : (
                /* Fallback Placeholder (Shown if image fails) */
                <div className="flex flex-col items-center justify-center">
                    <div className={cn(
                        "relative flex items-center justify-center font-serif tracking-tighter text-white",
                        size === "large" ? "text-8xl gap-6" : size === "small" ? "text-2xl gap-2" : "text-5xl gap-4"
                    )}>
                        {/* Icon Mark */}
                        <div className={cn(
                            "relative flex items-center justify-center rounded-full bg-gradient-to-tr from-[hsl(var(--color-intent))] to-[hsl(var(--color-execution))] animate-pulse-slow",
                            size === "large" ? "w-24 h-24 shadow-[0_0_60px_-10px_hsl(var(--color-intent))]" : size === "small" ? "w-8 h-8" : "w-16 h-16 shadow-[0_0_30px_-5px_hsl(var(--color-intent))]"
                        )}>
                            {/* Orbital Ring */}
                            <div className="absolute -inset-1 border border-white/20 rounded-full animate-spin-slower" style={{ animationDuration: '10s' }} />
                            
                            <div className="absolute inset-[15%] bg-black rounded-full flex items-center justify-center z-10">
                                <div className={cn("rounded-full bg-white shadow-[0_0_10px_white] animate-pulse", size === "large" ? "w-4 h-4" : size === "small" ? "w-1.5 h-1.5" : "w-2 h-2")} />
                            </div>
                        </div>

                        {/* Text Mark */}
                        {variant === "full" && (
                            <span className="font-bold bg-clip-text text-transparent bg-gradient-to-b from-white to-neutral-400">
                                XIBALBA
                            </span>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};