import React from 'react';
import { cn } from "@/lib/utils";

// Mapping of product IDs to their "periodic table" style codes and colors
export const PRODUCT_CONFIG = {
    web: { code: 'Wa', name: 'Web Architect', gradient: 'from-blue-500 to-indigo-600' },
    mobile: { code: 'Af', name: 'App Forge', gradient: 'from-sky-500 to-blue-600' },
    document: { code: 'Os', name: 'Office Suite', gradient: 'from-blue-600 to-blue-800' },
    sheet: { code: 'Og', name: 'Office Grid', gradient: 'from-green-500 to-emerald-700' },
    layout: { code: 'Mp', name: 'Magazine Pro', gradient: 'from-pink-500 to-rose-500' },
    sound: { code: 'Al', name: 'Audio Lab', gradient: 'from-amber-500 to-orange-600' },
    cinema: { code: 'Cn', name: 'Cinema Node', gradient: 'from-red-500 to-red-700' },
    '3d': { code: 'Vf', name: 'Voxel Forge', gradient: 'from-purple-500 to-pink-600' },
    cad: { code: 'Cc', name: 'CAD Construct', gradient: 'from-cyan-500 to-blue-600' },
    vector: { code: 'Vc', name: 'Vector Curve', gradient: 'from-yellow-500 to-orange-600' },
    store: { code: 'Sb', name: 'Store Builder', gradient: 'from-blue-600 to-indigo-700' },
    blog: { code: 'Bs', name: 'Blog Studio', gradient: 'from-neutral-500 to-neutral-700' },
    browser: { code: 'Bf', name: 'Browser Forge', gradient: 'from-purple-600 to-violet-800' },
    database: { code: 'Da', name: 'Data Architect', gradient: 'from-cyan-600 to-blue-700' },
    mail: { code: 'Ms', name: 'Mail Studio', gradient: 'from-indigo-500 to-purple-500' },
    architect: { code: 'Ca', name: 'Code Architect', gradient: 'from-slate-900 to-slate-800 border border-white/10' },
    chat: { code: 'Ai', name: 'Neural Chat', gradient: 'from-violet-600 to-purple-600' },
    agents: { code: 'Ag', name: 'Agent Grid', gradient: 'from-emerald-600 to-teal-600' },
    
    // FILE TYPES
    pdf: { code: 'Pdf', name: 'Document', gradient: 'from-red-500 to-red-600' },
    doc: { code: 'Doc', name: 'Word', gradient: 'from-blue-500 to-blue-700' },
    xls: { code: 'Xls', name: 'Sheet', gradient: 'from-green-500 to-green-700' },
    ppt: { code: 'Ppt', name: 'Slide', gradient: 'from-orange-500 to-red-500' },
    zip: { code: 'Zip', name: 'Archive', gradient: 'from-yellow-500 to-amber-600' },
    code: { code: 'Dev', name: 'Source', gradient: 'from-slate-700 to-slate-900' },
    image: { code: 'Img', name: 'Image', gradient: 'from-purple-500 to-fuchsia-600' },
    video: { code: 'Vid', name: 'Video', gradient: 'from-pink-500 to-rose-600' },
    audio: { code: 'Aud', name: 'Audio', gradient: 'from-cyan-500 to-teal-600' },
    txt: { code: 'Txt', name: 'Text', gradient: 'from-neutral-400 to-neutral-600' },
    exe: { code: 'Exe', name: 'App', gradient: 'from-indigo-600 to-violet-700' },
    sys: { code: 'Sys', name: 'System', gradient: 'from-gray-700 to-black' },
    
    // LINUX / SYSTEM
    terminal: { code: 'Tm', name: 'Terminal', gradient: 'from-black to-slate-800 border border-green-500/20' },
    settings: { code: 'St', name: 'Settings', gradient: 'from-neutral-600 to-neutral-800' },
    monitor: { code: 'Mo', name: 'Monitor', gradient: 'from-emerald-800 to-green-900' },
    files: { code: 'Fs', name: 'Files', gradient: 'from-yellow-400 to-yellow-600' },
    
    // DEV / TECH
    react: { code: 'Rc', name: 'React', gradient: 'from-blue-400 to-cyan-500' },
    node: { code: 'Nd', name: 'Node.js', gradient: 'from-green-600 to-emerald-700' },
    python: { code: 'Py', name: 'Python', gradient: 'from-blue-500 to-yellow-500' },
    rust: { code: 'Rs', name: 'Rust', gradient: 'from-orange-700 to-red-900' },
    docker: { code: 'Dk', name: 'Docker', gradient: 'from-blue-600 to-sky-700' },
    git: { code: 'Gt', name: 'Git', gradient: 'from-orange-600 to-red-600' },
    aws: { code: 'Aw', name: 'Cloud', gradient: 'from-orange-400 to-amber-500' },
    
    // CREATIVE / MEDIA
    ps: { code: 'Ps', name: 'Photo', gradient: 'from-blue-800 to-blue-900' },
    ai: { code: 'Ai', name: 'Vector', gradient: 'from-orange-600 to-orange-700' },
    pr: { code: 'Pr', name: 'Video', gradient: 'from-purple-800 to-purple-900' },
    ae: { code: 'Ae', name: 'Motion', gradient: 'from-indigo-800 to-purple-900' },
    figma: { code: 'Fg', name: 'Design', gradient: 'from-pink-500 to-purple-600' },
    blender: { code: 'Bl', name: '3D', gradient: 'from-orange-500 to-orange-600' },
    
    // OFFICE / DOCS
    word: { code: 'Wd', name: 'Writer', gradient: 'from-blue-600 to-blue-800' },
    excel: { code: 'Xl', name: 'Calc', gradient: 'from-green-600 to-green-800' },
    powerpoint: { code: 'Pp', name: 'Preso', gradient: 'from-orange-600 to-red-700' },
    notion: { code: 'Nt', name: 'Notes', gradient: 'from-neutral-800 to-neutral-900' },
    slack: { code: 'Sl', name: 'Chat', gradient: 'from-purple-600 to-rose-600' },
    
    // FILE EXTENSIONS
    mp4: { code: 'Mp4', name: 'Video', gradient: 'from-purple-600 to-indigo-600' },
    mov: { code: 'Mov', name: 'Movie', gradient: 'from-indigo-500 to-blue-600' },
    jpg: { code: 'Jpg', name: 'Image', gradient: 'from-pink-500 to-rose-500' },
    png: { code: 'Png', name: 'Image', gradient: 'from-rose-500 to-red-500' },
    gif: { code: 'Gif', name: 'Anim', gradient: 'from-green-500 to-teal-500' },
    svg: { code: 'Svg', name: 'Vector', gradient: 'from-orange-400 to-yellow-500' },
    mp3: { code: 'Mp3', name: 'Audio', gradient: 'from-cyan-500 to-blue-500' },
    wav: { code: 'Wav', name: 'Wave', gradient: 'from-blue-400 to-indigo-500' },
    json: { code: 'Js', name: 'JSON', gradient: 'from-yellow-400 to-yellow-600' },
    xml: { code: 'Xm', name: 'XML', gradient: 'from-orange-400 to-orange-600' },
    sql: { code: 'Sql', name: 'DB', gradient: 'from-blue-500 to-blue-700' },
    css: { code: 'Css', name: 'Style', gradient: 'from-blue-400 to-sky-500' },
    html: { code: 'Ht', name: 'Web', gradient: 'from-orange-500 to-red-500' },
    js: { code: 'Js', name: 'Script', gradient: 'from-yellow-300 to-yellow-500' },
    ts: { code: 'Ts', name: 'Type', gradient: 'from-blue-500 to-blue-700' },
    jsx: { code: 'Rx', name: 'React', gradient: 'from-cyan-400 to-blue-500' },
    vue: { code: 'Vu', name: 'Vue', gradient: 'from-emerald-400 to-green-500' },
    env: { code: 'Env', name: 'Config', gradient: 'from-slate-600 to-slate-800' },
    md: { code: 'Md', name: 'Doc', gradient: 'from-neutral-200 to-neutral-400' },
};

export default function ProductIcon({ id, size = 'md', className, active }) {
    const config = PRODUCT_CONFIG[id] || { code: '??', gradient: 'from-gray-500 to-gray-700' };
    
    const sizeClasses = {
        xs: 'w-6 h-6 text-[8px] rounded-md',
        sm: 'w-8 h-8 text-[10px] rounded-lg',
        md: 'w-12 h-12 text-lg rounded-xl',
        lg: 'w-16 h-16 text-xl rounded-2xl',
        xl: 'w-24 h-24 text-3xl rounded-3xl'
    };

    return (
        <div className={cn(
            "relative flex items-center justify-center overflow-hidden shadow-inner transition-all duration-300",
            "bg-gradient-to-br",
            config.gradient,
            sizeClasses[size],
            active && "ring-2 ring-white ring-offset-2 ring-offset-black",
            className
        )}>
             {/* Glossy Overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent pointer-events-none" />
            
            {/* Inner Text */}
            <span className="font-bold text-white tracking-tighter drop-shadow-md z-10 font-mono">
                {config.code}
            </span>

             {/* Xibalba Watermark */}
            <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693dffcccab0bea12e1e7952/fc2510794_logo.png" 
                className="absolute -bottom-2 -right-2 w-[80%] h-[80%] opacity-20 object-contain pointer-events-none mix-blend-overlay"
                alt=""
            />
        </div>
    );
}