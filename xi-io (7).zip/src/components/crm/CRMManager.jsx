import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer, ChartFrame 
} from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { 
    Users, User, Briefcase, Mail, Phone, Tag, 
    Search, Filter, Plus, ArrowUpRight, MoreHorizontal,
    Building2, DollarSign, Calendar, Edit2, Zap,
    MessageSquare, CheckCircle2, AlertTriangle, Activity
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useSiteContext } from '@/components/identity/SiteContext';
import CustomerModal from '@/components/crm/CustomerModal';
import TicketManager from '@/components/crm/TicketManager';
import { toast } from "sonner";
import { cn } from '@/lib/utils';
import { LineChart, Line, ResponsiveContainer, Tooltip } from 'recharts';

/* -------------------------------------------------------------------------- */
/*                                SUB-COMPONENTS                              */
/* -------------------------------------------------------------------------- */

const CustomerList = ({ customers, selectedId, onSelect, onNew, filter, setFilter, contactTerm }) => {
    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b border-white/5 space-y-4">
                <div className="flex justify-between items-center">
                    <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">CLIENTELE</OrientingText>
                    <Button size="sm" onClick={onNew} className="h-6 text-[10px] bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black gap-1 font-bold">
                        <Plus className="w-3 h-3" /> NEW {contactTerm.toUpperCase()}
                    </Button>
                </div>
                <div className="relative">
                    <Search className="absolute left-2 top-2 w-4 h-4 text-neutral-500" />
                    <Input 
                        placeholder={`Search ${contactTerm.toLowerCase()}s...`}
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                        className="pl-8 bg-neutral-900 border-white/10 h-8 text-xs"
                    />
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin scrollbar-thumb-white/10">
                {customers.map(customer => (
                    <SystemCard
                        key={customer.id}
                        title={customer.name}
                        subtitle={customer.company || customer.email}
                        metric={`$${customer.lifetime_value?.toLocaleString() || '0'}`}
                        status={customer.status === 'vip' ? 'active' : customer.status === 'churned' ? 'warning' : 'settled'}
                        active={selectedId === customer.id}
                        onClick={() => onSelect(customer)}
                        icon={customer.company ? Building2 : User}
                    />
                ))}
            </div>
        </div>
    );
};

const AICustomerAnalysis = ({ customer }) => {
    return (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
            {/* Sentiment & Risk */}
            <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-neutral-900/50 border border-white/5 rounded-lg space-y-2">
                    <div className="flex items-center gap-2">
                        <Activity className="w-4 h-4 text-green-500" />
                        <OrientingText>ENGAGEMENT SCORE</OrientingText>
                    </div>
                    <div className="text-2xl font-bold text-white">8.4<span className="text-sm text-neutral-500 font-normal">/10</span></div>
                    <StateText className="opacity-50">High interaction rate on recent campaigns.</StateText>
                </div>
                <div className="p-4 bg-neutral-900/50 border border-white/5 rounded-lg space-y-2">
                    <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-orange-500" />
                        <OrientingText>CHURN PROBABILITY</OrientingText>
                    </div>
                    <div className="text-2xl font-bold text-white">12<span className="text-sm text-neutral-500 font-normal">%</span></div>
                    <StateText className="opacity-50">Stable. Last contact was within 14 days.</StateText>
                </div>
            </div>

            {/* Next Best Action */}
            <div className="p-4 bg-[hsl(var(--color-intent))]/5 border border-[hsl(var(--color-intent))]/20 rounded-lg">
                <div className="flex items-center gap-2 mb-3 text-[hsl(var(--color-intent))]">
                    <Zap className="w-4 h-4" />
                    <IntentText className="font-bold">Suggested Intervention</IntentText>
                </div>
                <StateText className="opacity-80 leading-relaxed mb-4">
                    Based on {customer.name}'s recent interest in <strong>Automation Modules</strong>, recommend scheduling a technical demo of the new V2 Agent Swarm architecture.
                </StateText>
                <div className="flex gap-2">
                    <Button size="sm" className="bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white">
                        <MessageSquare className="w-3 h-3 mr-2" /> Draft Outreach
                    </Button>
                    <Button size="sm" variant="outline" className="border-[hsl(var(--color-intent))]/30 hover:bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))]">
                        Ignore
                    </Button>
                </div>
            </div>

            {/* LTV Projection */}
             <div className="h-48 w-full bg-neutral-900/30 rounded border border-white/5 p-2">
                 <ChartFrame label="LTV Projection" metric="$142k" trend="+15%" category="intent">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={[
                            {v: 100}, {v: 110}, {v: 108}, {v: 125}, {v: 130}, {v: 138}, {v: 142}
                        ]}>
                            <Line type="monotone" dataKey="v" stroke="hsl(var(--color-intent))" strokeWidth={2} dot={false} />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#171717', border: '1px solid #333' }}
                                itemStyle={{ color: '#fff' }}
                            />
                        </LineChart>
                    </ResponsiveContainer>
                 </ChartFrame>
            </div>
        </div>
    );
};

const CustomerDetails = ({ customer, onEdit }) => {
    return (
        <div className="space-y-6 animate-in fade-in duration-300">
            {/* Header */}
            <SystemDetailHeader
                title={customer.name}
                subtitle={customer.company || "Independent"}
                category={customer.status.toUpperCase()}
                icon={User}
            >
                <div className="flex gap-2">
                    {customer.tags?.map(tag => (
                        <Badge key={tag} variant="outline" className="text-[9px] border-white/10 text-neutral-500">#{tag}</Badge>
                    ))}
                    <Button size="icon" variant="ghost" className="text-neutral-500 hover:text-white h-8 w-8" onClick={onEdit}>
                        <Edit2 className="w-4 h-4" />
                    </Button>
                </div>
            </SystemDetailHeader>

            {/* Stats */}
            <SystemStats 
                className="grid-cols-2"
                stats={[
                    { label: "Lifetime Value", value: `$${customer.lifetime_value?.toLocaleString()}`, icon: DollarSign, color: "text-green-500" },
                    { label: "Last Contact", value: customer.last_contact ? new Date(customer.last_contact).toLocaleDateString() : 'Never', icon: Calendar, color: "text-blue-500" }
                ]}
            />

            {/* Contact Info */}
            <div className="space-y-2">
                <OrientingText>CONTACT METHODS</OrientingText>
                <div className="p-3 bg-neutral-900/50 border border-white/5 rounded space-y-3">
                    <div className="flex items-center gap-3 hover:text-white transition-colors cursor-pointer group">
                        <Mail className="w-4 h-4 text-neutral-500 group-hover:text-blue-400" />
                        <StateText className="flex-1 font-mono text-xs">{customer.email}</StateText>
                        <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100" />
                    </div>
                    {customer.phone && (
                        <div className="flex items-center gap-3 hover:text-white transition-colors cursor-pointer group">
                            <Phone className="w-4 h-4 text-neutral-500 group-hover:text-green-400" />
                            <StateText className="flex-1 font-mono text-xs">{customer.phone}</StateText>
                            <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100" />
                        </div>
                    )}
                </div>
            </div>


        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                                MAIN COMPONENT                              */
/* -------------------------------------------------------------------------- */

export default function CRMManager({ category = 'all' }) {
    if (category === 'tickets') {
        return <TicketManager />;
    }

    const { domainData } = useSiteContext();
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [filter, setFilter] = useState('');
    const [viewMode, setViewMode] = useState('ai'); // ai, activity, notes
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState(null);

    const { data: customers = [] } = useQuery({
        queryKey: ['customers'],
        queryFn: () => base44.entities.Customer.list(),
        initialData: []
    });

    const contactTerm = domainData.family === 'Xibalba' ? 'Patron' : domainData.family === 'Veilrift' ? 'User' : 'Contact';

    const filteredCustomers = customers.filter(c => {
        const matchesSearch = c.name.toLowerCase().includes(filter.toLowerCase()) || 
                              c.email.toLowerCase().includes(filter.toLowerCase()) ||
                              (c.company && c.company.toLowerCase().includes(filter.toLowerCase()));
        
        const matchesCategory = category === 'all' || c.status === category;
        
        return matchesSearch && matchesCategory;
    });

    // Reset selection if category changes and selected customer is no longer in list?
    // Optional, but good UX.
    // useEffect(() => { setSelectedCustomer(null) }, [category]); 

    const handleSelect = (customer) => {
        setSelectedCustomer(customer);
        setViewMode('details');
    };

    return (
        <div className="h-full w-full bg-neutral-950 overflow-hidden">
            <PanelGroup direction="horizontal">
                {/* COLUMN 1: CLIENT LIST */}
                <Panel defaultSize={25} minSize={20} maxSize={30} className="border-r border-white/5 bg-neutral-900/20">
                    <HumorousLoader delay={500} className="h-full">
                        <Quadrant type="state" dominance="dominant" className="h-full p-0 border-none rounded-none bg-transparent">
                            <CustomerList 
                                customers={filteredCustomers}
                                selectedId={selectedCustomer?.id}
                                onSelect={handleSelect}
                                onNew={() => { setEditingCustomer(null); setIsModalOpen(true); }}
                                filter={filter}
                                setFilter={setFilter}
                                contactTerm={contactTerm}
                            />
                        </Quadrant>
                    </HumorousLoader>
                </Panel>
                
                <PanelResizeHandle className="w-[1px] bg-white/5 hover:bg-[hsl(var(--color-intent))] transition-colors" />
                
                {/* COLUMN 2: PROFILE DETAILS */}
                <Panel defaultSize={45} minSize={30}>
                    <HumorousLoader delay={800} className="h-full">
                         <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col border-none rounded-none bg-neutral-950/40">
                            {selectedCustomer ? (
                                <>
                                    <div className="h-14 border-b border-white/5 bg-neutral-900/30 flex items-center justify-between px-6 shrink-0 backdrop-blur-sm">
                                        <div className="flex items-center gap-2 text-neutral-400">
                                            <User className="w-4 h-4" />
                                            <StateText className="font-mono text-xs">PROFILE ID: {selectedCustomer.id.slice(0,8)}</StateText>
                                        </div>
                                        <Badge variant="outline" className="text-[10px] border-white/10 text-neutral-500">
                                            PRIMARY RECORD
                                        </Badge>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-8">
                                        <CustomerDetails 
                                            customer={selectedCustomer} 
                                            onEdit={() => { setEditingCustomer(selectedCustomer); setIsModalOpen(true); }}
                                        />
                                    </div>
                                </>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center opacity-30 p-8 text-center space-y-4">
                                    <Users className="w-16 h-16 stroke-1 text-neutral-500" />
                                    <div>
                                        <IntentText className="text-xl font-light">CRM Matrix</IntentText>
                                        <StateText>Select a {contactTerm.toLowerCase()} from the list.</StateText>
                                    </div>
                                </div>
                            )}
                        </Quadrant>
                    </HumorousLoader>
                </Panel>

                {selectedCustomer && (
                    <>
                        <PanelResizeHandle className="w-[1px] bg-white/5 hover:bg-[hsl(var(--color-intent))] transition-colors" />

                        {/* COLUMN 3: INTELLIGENCE & CONTEXT */}
                        <Panel defaultSize={30} minSize={20}>
                            <HumorousLoader delay={1100} className="h-full">
                                <Quadrant type="orientation" className="h-full p-0 flex flex-col border-none rounded-none bg-neutral-900/10">
                                    <div className="h-14 border-b border-white/5 bg-neutral-900/30 flex items-center px-4 shrink-0 backdrop-blur-sm">
                                        <Tabs value={viewMode} onValueChange={setViewMode} className="w-full">
                                            <TabsList className="w-full bg-neutral-950/50 border border-white/5 h-9 p-0.5">
                                                <TabsTrigger value="ai" className="flex-1 text-[10px] h-7 data-[state=active]:bg-neutral-800">
                                                    <Zap className="w-3 h-3 mr-1.5" /> Intelligence
                                                </TabsTrigger>
                                                <TabsTrigger value="activity" className="flex-1 text-[10px] h-7 data-[state=active]:bg-neutral-800">
                                                    <Activity className="w-3 h-3 mr-1.5" /> Activity
                                                </TabsTrigger>
                                                <TabsTrigger value="notes" className="flex-1 text-[10px] h-7 data-[state=active]:bg-neutral-800">
                                                    <Edit2 className="w-3 h-3 mr-1.5" /> Notes
                                                </TabsTrigger>
                                            </TabsList>
                                        </Tabs>
                                    </div>
                                    <div className="flex-1 overflow-y-auto p-4 bg-neutral-950/30">
                                        {viewMode === 'ai' && <AICustomerAnalysis customer={selectedCustomer} />}
                                        {viewMode === 'activity' && (
                                            <div className="flex flex-col items-center justify-center h-full opacity-50 space-y-2">
                                                <Activity className="w-8 h-8" />
                                                <StateText>No recent activity logs found.</StateText>
                                            </div>
                                        )}
                                        {viewMode === 'notes' && (
                                            <div className="space-y-4">
                                                <div className="p-3 bg-neutral-900/50 border border-white/5 rounded min-h-[200px]">
                                                    <StateText className="opacity-70 leading-relaxed text-sm">
                                                        {selectedCustomer.notes || "No notes recorded."}
                                                    </StateText>
                                                </div>
                                                <Button size="sm" variant="outline" className="w-full">Add Note</Button>
                                            </div>
                                        )}
                                    </div>
                                </Quadrant>
                            </HumorousLoader>
                        </Panel>
                    </>
                )}
            </PanelGroup>

            <CustomerModal 
                open={isModalOpen} 
                onOpenChange={setIsModalOpen} 
                customer={editingCustomer} 
            />
        </div>
    );
}