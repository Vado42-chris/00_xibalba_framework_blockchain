import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { 
    Quadrant, OrientingText, IntentText, StateText, SemanticDot 
} from '@/components/ui/design-system/System';
import { HumorousLoader } from '@/components/ui/design-system/HumorousLoader';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
    Ticket, Search, Filter, MessageSquare, CheckCircle2, 
    Clock, AlertTriangle, ArrowRight, User
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

export default function TicketManager() {
    const [selectedTicket, setSelectedTicket] = useState(null);
    const [filter, setFilter] = useState('');
    const queryClient = useQueryClient();

    const { data: tickets = [] } = useQuery({
        queryKey: ['tickets'],
        queryFn: () => base44.entities.SupportTicket.list(),
        initialData: []
    });

    const updateTicketMutation = useMutation({
        mutationFn: async ({ id, data }) => {
            await base44.entities.SupportTicket.update(id, data);
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['tickets']);
            toast.success("Ticket updated");
        }
    });

    const filteredTickets = tickets.filter(t => 
        t.subject.toLowerCase().includes(filter.toLowerCase()) || 
        t.description.toLowerCase().includes(filter.toLowerCase())
    );

    const statusColors = {
        open: "text-blue-400 border-blue-400/30 bg-blue-400/10",
        in_progress: "text-orange-400 border-orange-400/30 bg-orange-400/10",
        resolved: "text-green-400 border-green-400/30 bg-green-400/10",
        closed: "text-neutral-500 border-neutral-500/30 bg-neutral-500/10"
    };

    const priorityColors = {
        low: "text-neutral-400",
        medium: "text-blue-400",
        high: "text-orange-400",
        critical: "text-red-500"
    };

    return (
        <div className="h-full w-full bg-neutral-950 overflow-hidden">
            <PanelGroup direction="horizontal">
                {/* LIST */}
                <Panel defaultSize={30} minSize={20} className="border-r border-white/5 bg-neutral-900/20">
                    <HumorousLoader delay={500} className="h-full">
                        <Quadrant type="state" dominance="dominant" className="h-full p-0 border-none rounded-none bg-transparent">
                            <div className="flex flex-col h-full">
                                <div className="p-4 border-b border-white/5 space-y-4">
                                    <div className="flex justify-between items-center">
                                        <OrientingText className="tracking-widest font-bold text-[hsl(var(--color-execution))]">SERVICE DESK</OrientingText>
                                        <Badge variant="outline" className="text-[10px] border-white/10">{tickets.length} TICKETS</Badge>
                                    </div>
                                    <div className="relative">
                                        <Search className="absolute left-2 top-2 w-4 h-4 text-neutral-500" />
                                        <Input 
                                            placeholder="Search tickets..."
                                            value={filter}
                                            onChange={(e) => setFilter(e.target.value)}
                                            className="pl-8 bg-neutral-900 border-white/10 h-8 text-xs"
                                        />
                                    </div>
                                </div>
                                <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin scrollbar-thumb-white/10">
                                    {filteredTickets.map(ticket => (
                                        <div 
                                            key={ticket.id}
                                            onClick={() => setSelectedTicket(ticket)}
                                            className={cn(
                                                "p-3 rounded border flex flex-col gap-2 cursor-pointer transition-all group relative overflow-hidden",
                                                selectedTicket?.id === ticket.id 
                                                    ? "bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))]/50" 
                                                    : "bg-neutral-900/50 border-white/5 hover:border-white/20 hover:bg-neutral-900"
                                            )}
                                        >
                                            {selectedTicket?.id === ticket.id && <div className="absolute left-0 top-0 bottom-0 w-1 bg-[hsl(var(--color-execution))]" />}
                                            <div className="flex justify-between items-start gap-2">
                                                <IntentText className={cn("font-medium line-clamp-1", selectedTicket?.id === ticket.id ? "text-white" : "text-neutral-300")}>
                                                    {ticket.subject}
                                                </IntentText>
                                                <SemanticDot type={ticket.status === 'resolved' ? 'active' : ticket.priority === 'critical' ? 'warning' : 'settled'} />
                                            </div>
                                            <div className="flex justify-between items-center">
                                                <div className="flex items-center gap-2">
                                                    <Badge variant="outline" className={cn("text-[9px] h-4 uppercase", statusColors[ticket.status])}>
                                                        {ticket.status.replace('_', ' ')}
                                                    </Badge>
                                                    <span className={cn("text-[10px] uppercase font-bold", priorityColors[ticket.priority])}>{ticket.priority}</span>
                                                </div>
                                                <StateText className="text-[9px] opacity-40">
                                                    {new Date(ticket.created_date || Date.now()).toLocaleDateString()}
                                                </StateText>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </Quadrant>
                    </HumorousLoader>
                </Panel>

                <PanelResizeHandle className="w-[1px] bg-white/5 hover:bg-[hsl(var(--color-intent))] transition-colors" />

                {/* DETAILS */}
                <Panel defaultSize={70} minSize={40}>
                    <HumorousLoader delay={800} className="h-full">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col border-none rounded-none bg-neutral-950/40">
                            {selectedTicket ? (
                                <>
                                    <div className="h-16 border-b border-white/5 bg-neutral-900/30 flex items-center justify-between px-6 shrink-0 backdrop-blur-sm">
                                        <div>
                                            <div className="flex items-center gap-2 mb-1">
                                                <Ticket className="w-4 h-4 text-neutral-400" />
                                                <StateText className="font-mono text-xs text-neutral-500">TICKET ID: {selectedTicket.id.slice(0,8)}</StateText>
                                            </div>
                                            <IntentText className="text-lg font-medium text-white">{selectedTicket.subject}</IntentText>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <Select 
                                                value={selectedTicket.priority} 
                                                onValueChange={(v) => updateTicketMutation.mutate({ id: selectedTicket.id, data: { priority: v } })}
                                            >
                                                <SelectTrigger className="w-24 h-8 text-xs bg-neutral-900 border-white/10">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="low">Low</SelectItem>
                                                    <SelectItem value="medium">Medium</SelectItem>
                                                    <SelectItem value="high">High</SelectItem>
                                                    <SelectItem value="critical">Critical</SelectItem>
                                                </SelectContent>
                                            </Select>

                                            <Select 
                                                value={selectedTicket.status} 
                                                onValueChange={(v) => updateTicketMutation.mutate({ id: selectedTicket.id, data: { status: v } })}
                                            >
                                                <SelectTrigger className={cn("w-32 h-8 text-xs border-white/10 uppercase font-bold", statusColors[selectedTicket.status].split(' ')[0])}>
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="open">Open</SelectItem>
                                                    <SelectItem value="in_progress">In Progress</SelectItem>
                                                    <SelectItem value="resolved">Resolved</SelectItem>
                                                    <SelectItem value="closed">Closed</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div className="flex-1 overflow-y-auto p-8 space-y-8">
                                        <div className="grid grid-cols-3 gap-6">
                                            <div className="col-span-2 space-y-6">
                                                <div className="space-y-2">
                                                    <OrientingText className="opacity-50">DESCRIPTION</OrientingText>
                                                    <div className="p-4 bg-neutral-900/50 border border-white/5 rounded-lg">
                                                        <StateText className="text-sm leading-relaxed whitespace-pre-wrap text-neutral-300">
                                                            {selectedTicket.description}
                                                        </StateText>
                                                    </div>
                                                </div>

                                                <div className="space-y-4">
                                                    <OrientingText className="opacity-50">ACTIVITY LOG</OrientingText>
                                                    <div className="relative pl-4 border-l border-white/5 space-y-6">
                                                        <div className="relative">
                                                            <div className="absolute -left-[21px] top-0 w-3 h-3 rounded-full bg-neutral-800 border border-white/10" />
                                                            <div className="text-xs text-neutral-500 mb-1">
                                                                {new Date(selectedTicket.created_date).toLocaleString()}
                                                            </div>
                                                            <div className="text-sm text-neutral-300">Ticket created by {selectedTicket.user_email}</div>
                                                        </div>
                                                        {selectedTicket.comments?.map((comment, i) => (
                                                            <div key={i} className="relative">
                                                                <div className="absolute -left-[21px] top-0 w-3 h-3 rounded-full bg-[hsl(var(--color-intent))]" />
                                                                <div className="text-xs text-neutral-500 mb-1">
                                                                    {new Date(comment.timestamp).toLocaleString()} • {comment.author}
                                                                </div>
                                                                <div className="p-3 bg-neutral-900/50 border border-white/5 rounded text-sm text-neutral-300">
                                                                    {comment.message}
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                    
                                                    <div className="pt-4 flex gap-2">
                                                        <Textarea placeholder="Add a comment..." className="bg-neutral-900 border-white/10 min-h-[80px]" />
                                                        <Button className="h-auto bg-[hsl(var(--color-execution))] text-black self-end">Post</Button>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="space-y-6">
                                                <div className="p-4 bg-neutral-900/30 border border-white/5 rounded-lg space-y-4">
                                                    <OrientingText className="opacity-50">REQUESTER</OrientingText>
                                                    <div className="flex items-center gap-3">
                                                        <div className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center">
                                                            <User className="w-5 h-5 text-neutral-400" />
                                                        </div>
                                                        <div className="overflow-hidden">
                                                            <div className="text-sm font-medium text-white truncate">{selectedTicket.user_email}</div>
                                                            <div className="text-xs text-neutral-500">Customer</div>
                                                        </div>
                                                    </div>
                                                    <Button variant="outline" size="sm" className="w-full text-xs h-8 border-white/10">View Profile</Button>
                                                </div>

                                                <div className="p-4 bg-neutral-900/30 border border-white/5 rounded-lg space-y-4">
                                                    <OrientingText className="opacity-50">METADATA</OrientingText>
                                                    <div className="space-y-2">
                                                        <div className="flex justify-between text-xs">
                                                            <span className="text-neutral-500">Category</span>
                                                            <span className="text-neutral-300 capitalize">{selectedTicket.category?.replace('_', ' ')}</span>
                                                        </div>
                                                        <div className="flex justify-between text-xs">
                                                            <span className="text-neutral-500">Source</span>
                                                            <span className="text-neutral-300">Marketplace</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center opacity-30 p-8 text-center space-y-4">
                                    <Ticket className="w-16 h-16 stroke-1 text-neutral-500" />
                                    <div>
                                        <IntentText className="text-xl font-light">Ticket Matrix</IntentText>
                                        <StateText>Select a ticket to view details and manage request.</StateText>
                                    </div>
                                </div>
                            )}
                        </Quadrant>
                    </HumorousLoader>
                </Panel>
            </PanelGroup>
        </div>
    );
}