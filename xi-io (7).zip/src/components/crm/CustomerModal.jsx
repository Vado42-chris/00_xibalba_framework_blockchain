import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function CustomerModal({ open, onOpenChange, customer }) {
    const queryClient = useQueryClient();
    const { register, handleSubmit, reset, setValue } = useForm();

    useEffect(() => {
        if (customer) {
            setValue('name', customer.name);
            setValue('email', customer.email);
            setValue('phone', customer.phone);
            setValue('company', customer.company);
            setValue('status', customer.status);
            setValue('notes', customer.notes);
        } else {
            reset({ status: 'lead' });
        }
    }, [customer, open, setValue, reset]);

    const mutation = useMutation({
        mutationFn: (data) => {
            if (customer) {
                return base44.entities.Customer.update(customer.id, data);
            }
            return base44.entities.Customer.create(data);
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['customers']);
            toast.success(customer ? "Contact updated" : "Contact created");
            onOpenChange(false);
            reset();
        }
    });

    const onSubmit = (data) => mutation.mutate(data);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border border-white/10 text-white sm:max-w-[500px] shadow-2xl backdrop-blur-xl">
                <DialogHeader className="border-b border-white/5 pb-4">
                    <DialogTitle className="text-xl font-light tracking-wide flex items-center gap-2">
                        {customer ? (
                            <>
                                <span className="w-2 h-2 rounded-full bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.5)]"></span>
                                EDIT PROFILE
                            </>
                        ) : (
                            <>
                                <span className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.5)]"></span>
                                NEW ENTRY
                            </>
                        )}
                    </DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-5 py-2">
                    <div className="grid grid-cols-2 gap-5">
                        <div className="space-y-1.5">
                            <Label className="text-[10px] uppercase tracking-widest text-neutral-500">Identity</Label>
                            <Input {...register('name', { required: true })} className="bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-intent))]" placeholder="Full Name" />
                        </div>
                        <div className="space-y-1.5">
                            <Label className="text-[10px] uppercase tracking-widest text-neutral-500">Classification</Label>
                            <Select onValueChange={(v) => setValue('status', v)} defaultValue={customer?.status || 'lead'}>
                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                    <SelectValue placeholder="Status" />
                                </SelectTrigger>
                                <SelectContent className="bg-neutral-900 border-white/10">
                                    <SelectItem value="lead">Lead</SelectItem>
                                    <SelectItem value="active">Active</SelectItem>
                                    <SelectItem value="vip">VIP</SelectItem>
                                    <SelectItem value="churned">Churned</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    
                    <div className="space-y-1.5">
                        <Label className="text-[10px] uppercase tracking-widest text-neutral-500">Digital Contact</Label>
                        <Input {...register('email')} className="bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-intent))]" placeholder="email@example.com" />
                    </div>

                    <div className="grid grid-cols-2 gap-5">
                        <div className="space-y-1.5">
                            <Label className="text-[10px] uppercase tracking-widest text-neutral-500">Signal</Label>
                            <Input {...register('phone')} className="bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-intent))]" placeholder="+1..." />
                        </div>
                        <div className="space-y-1.5">
                            <Label className="text-[10px] uppercase tracking-widest text-neutral-500">Affiliation</Label>
                            <Input {...register('company')} className="bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-intent))]" placeholder="Organization" />
                        </div>
                    </div>

                    <div className="space-y-1.5">
                        <Label className="text-[10px] uppercase tracking-widest text-neutral-500">Intelligence / Notes</Label>
                        <Textarea {...register('notes')} className="bg-neutral-950 border-white/10 min-h-[100px] resize-none focus:border-[hsl(var(--color-intent))]" placeholder="Additional context..." />
                    </div>

                    <DialogFooter className="pt-4 border-t border-white/5">
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} className="text-neutral-500 hover:text-white">Cancel</Button>
                        <Button type="submit" className="bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black font-bold">
                            {customer ? 'SAVE CHANGES' : 'CREATE RECORD'}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}