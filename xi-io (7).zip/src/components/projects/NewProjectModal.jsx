import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Layout, Code, Megaphone, User, Check, 
  ArrowRight, Loader2, Sparkles 
} from 'lucide-react';
import { 
  OrientingText, IntentText, StateText, SemanticDot, AtomicParagraph 
} from '@/components/ui/design-system/System';
import { cn } from '@/lib/utils';
import { toast } from "sonner";

export default function NewProjectModal({ open, onOpenChange }) {
  const [step, setStep] = useState(1); // 1: Template, 2: Details
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [formData, setFormData] = useState({ name: '', description: '' });
  const queryClient = useQueryClient();

  // Fetch Templates
  const { data: templates = [] } = useQuery({
    queryKey: ['projectTemplates'],
    queryFn: () => base44.entities.ProjectTemplate.list(),
    initialData: []
  });

  const createProjectMutation = useMutation({
    mutationFn: async () => {
      // 1. Create Project
      const project = await base44.entities.Project.create({
        name: formData.name,
        description: formData.description,
        status: 'active',
        start_date: new Date().toISOString(),
        tech_stack: selectedTemplate?.tech_stack || []
      });

      // 2. Create Tasks from Template
      if (selectedTemplate?.tasks?.length) {
        // Ensure we only take valid task fields
        const tasksToCreate = selectedTemplate.tasks.map(t => ({
          title: t.title,
          description: t.description || '',
          priority: t.priority || 'medium',
          status: 'todo',
          project_id: project.id
        }));

        for (const task of tasksToCreate) {
             try {
                await base44.entities.Task.create(task);
             } catch (e) {
                console.error("Failed to create task template", task, e);
             }
        }
      }

      return project;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['projects']);
      toast.success("Project initialized successfully");
      onOpenChange(false);
      resetForm();
    },
    onError: (err) => {
        toast.error("Failed to initialize project");
        console.error(err);
    }
  });

  const resetForm = () => {
    setStep(1);
    setSelectedTemplate(null);
    setFormData({ name: '', description: '' });
  };

  const handleNext = () => {
    if (step === 1 && selectedTemplate) setStep(2);
  };

  const handleSubmit = () => {
    if (!formData.name) return;
    createProjectMutation.mutate();
  };

  const getIcon = (category) => {
    switch(category) {
      case 'software': return Code;
      case 'marketing': return Megaphone;
      case 'personal': return User;
      default: return Layout;
    }
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { onOpenChange(val); if(!val) resetForm(); }}>
      <DialogContent className="max-w-3xl bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-intent))] p-0 overflow-hidden flex flex-col h-[600px] max-h-[85vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-[hsl(var(--layer-orientation))] bg-[hsl(var(--layer-orientation))]">
            <DialogTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                <span className="font-light tracking-wide">INITIALIZE PROJECT</span>
            </DialogTitle>
            <div className="flex items-center gap-2 mt-2">
                <div className={cn("h-1 w-8 rounded-full transition-colors", step >= 1 ? "bg-[hsl(var(--color-intent))]" : "bg-[hsl(var(--layer-orientation))]")} />
                <div className={cn("h-1 w-8 rounded-full transition-colors", step >= 2 ? "bg-[hsl(var(--color-intent))]" : "bg-[hsl(var(--layer-orientation))]")} />
            </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-[hsl(var(--void))]">
            {step === 1 ? (
                <div className="space-y-6">
                    <div className="text-center space-y-2 mb-8">
                        <OrientingText>SELECT BLUEPRINT</OrientingText>
                        <IntentText className="text-xl">Choose a foundation for your project.</IntentText>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div 
                            onClick={() => setSelectedTemplate({ id: 'blank', name: 'Blank Canvas', description: 'Start from scratch with a clean slate.' })}
                            className={cn(
                                "p-4 rounded border cursor-pointer transition-all hover:border-[hsl(var(--color-intent))]/50 group relative",
                                selectedTemplate?.id === 'blank' ? "bg-[hsl(var(--layer-intent))] border-[hsl(var(--color-intent))]" : "bg-[hsl(var(--layer-orientation))] border-[hsl(var(--layer-orientation))]"
                            )}
                        >
                             <div className="flex justify-between items-start mb-2">
                                <Layout className="w-6 h-6 text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--color-intent))]" />
                                {selectedTemplate?.id === 'blank' && <Check className="w-4 h-4 text-[hsl(var(--color-intent))]" />}
                             </div>
                             <IntentText className="font-bold">Blank Canvas</IntentText>
                             <StateText className="opacity-60 mt-1">Empty project structure.</StateText>
                        </div>

                        {templates.map(template => {
                            const Icon = getIcon(template.category);
                            return (
                                <div 
                                    key={template.id}
                                    onClick={() => setSelectedTemplate(template)}
                                    className={cn(
                                        "p-4 rounded border cursor-pointer transition-all hover:border-[hsl(var(--color-intent))]/50 group relative",
                                        selectedTemplate?.id === template.id ? "bg-[hsl(var(--layer-intent))] border-[hsl(var(--color-intent))]" : "bg-[hsl(var(--layer-orientation))] border-[hsl(var(--layer-orientation))]"
                                    )}
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <Icon className="w-6 h-6 text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--color-intent))]" />
                                        {selectedTemplate?.id === template.id && <Check className="w-4 h-4 text-[hsl(var(--color-intent))]" />}
                                    </div>
                                    <IntentText className="font-bold">{template.name}</IntentText>
                                    <StateText className="opacity-60 mt-1">{template.description}</StateText>
                                    {template.tasks?.length > 0 && (
                                        <div className="mt-3 pt-3 border-t border-[hsl(var(--layer-orientation))]/50 flex gap-2">
                                            <span className="text-[10px] bg-[hsl(var(--layer-state))] px-1.5 py-0.5 rounded text-[hsl(var(--fg-orientation))] font-mono">
                                                {template.tasks.length} TASKS
                                            </span>
                                            {template.tech_stack?.slice(0, 2).map(stack => (
                                                <span key={stack} className="text-[10px] bg-[hsl(var(--layer-state))] px-1.5 py-0.5 rounded text-[hsl(var(--fg-orientation))] font-mono">
                                                    {stack}
                                                </span>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            ) : (
                <div className="max-w-md mx-auto space-y-6 py-8">
                    <div className="text-center space-y-2 mb-8">
                        <OrientingText>CONFIGURE PARAMETERS</OrientingText>
                        <IntentText className="text-xl">Define your project identity.</IntentText>
                    </div>

                    <div className="space-y-4">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-[hsl(var(--fg-orientation))] uppercase tracking-wider">Project Name</label>
                            <Input 
                                autoFocus
                                placeholder="e.g. Project Orion"
                                value={formData.name}
                                onChange={e => setFormData({...formData, name: e.target.value})}
                                className="bg-[hsl(var(--layer-state))] border-[hsl(var(--layer-orientation))] h-12 text-lg"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-[hsl(var(--fg-orientation))] uppercase tracking-wider">Description</label>
                            <Textarea 
                                placeholder="Brief mission statement..."
                                value={formData.description}
                                onChange={e => setFormData({...formData, description: e.target.value})}
                                className="bg-[hsl(var(--layer-state))] border-[hsl(var(--layer-orientation))] min-h-[100px]"
                            />
                        </div>
                        
                        <div className="pt-4 p-4 rounded bg-[hsl(var(--layer-orientation))] border border-[hsl(var(--layer-orientation))]">
                             <div className="flex items-center gap-2 mb-2">
                                <SemanticDot type="active" />
                                <StateText className="font-bold">Template Summary</StateText>
                             </div>
                             <AtomicParagraph className="text-[10px] opacity-70">
                                Based on <span className="text-[hsl(var(--color-intent))]">{selectedTemplate?.name}</span>. 
                                {selectedTemplate?.tasks?.length ? ` Will initialize with ${selectedTemplate.tasks.length} tasks.` : ' Starting with empty task list.'}
                             </AtomicParagraph>
                        </div>
                    </div>
                </div>
            )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-[hsl(var(--layer-orientation))] bg-[hsl(var(--layer-orientation))] flex justify-between">
            {step === 2 ? (
                <Button variant="ghost" onClick={() => setStep(1)} className="text-[hsl(var(--fg-orientation))] hover:text-[hsl(var(--fg-intent))]">Back</Button>
            ) : (
                <div />
            )}
            
            {step === 1 ? (
                <Button 
                    onClick={handleNext} 
                    disabled={!selectedTemplate}
                    className="bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white w-32"
                >
                    Next <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
            ) : (
                <Button 
                    onClick={handleSubmit} 
                    disabled={createProjectMutation.isPending || !formData.name}
                    className="bg-[hsl(var(--color-active))] hover:bg-[hsl(var(--color-active))]/90 text-black font-bold w-32"
                >
                    {createProjectMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Launch'}
                </Button>
            )}
        </div>

      </DialogContent>
    </Dialog>
  );
}