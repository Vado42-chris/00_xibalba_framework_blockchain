import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Plus, Folder, Trash2, Edit2, MoreVertical, Globe, Calendar, Brain, TrendingUp, AlertTriangle, Clock } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/System';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ProjectDashboard() {
    const queryClient = useQueryClient();
    const [isCreateOpen, setIsCreateOpen] = useState(false);
    const [newProjectName, setNewProjectName] = useState('');
    const [newProjectDesc, setNewProjectDesc] = useState('');

    const { data: projects = [], isLoading } = useQuery({
        queryKey: ['projects'],
        queryFn: () => base44.entities.Project.list('-updated_date')
    });

    const createMutation = useMutation({
        mutationFn: (data) => base44.entities.Project.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries(['projects']);
            setIsCreateOpen(false);
            setNewProjectName('');
            setNewProjectDesc('');
            toast.success("Project initialized");
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.Project.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries(['projects']);
            toast.success("Project archived");
        }
    });

    // AI Insights Fetcher
    const { data: aiInsights, refetch: refreshInsights, isFetching: isAiLoading } = useQuery({
        queryKey: ['project_insights'],
        queryFn: async () => {
            const { data } = await base44.functions.invoke('aiGenerate', {
                intent: 'analyze_project_risks',
                context: { projectData: { projects: projects.length, active: projects.filter(p => p.status === 'active').length } }
            });
            return data.output;
        },
        enabled: projects.length > 0,
        staleTime: 60000 // Cache for 1 min
    });

    const handleCreate = () => {
        if (!newProjectName) return;
        createMutation.mutate({
            name: newProjectName,
            description: newProjectDesc,
            status: 'active',
            start_date: new Date().toISOString()
        });
    };

    return (
        <div className="space-y-6 p-6">
            <div className="flex justify-between items-end border-b border-white/10 pb-4">
                <div>
                    <OrientingText className="text-[hsl(var(--color-execution))]">WORKSPACE</OrientingText>
                    <IntentText className="text-2xl">Mission Control</IntentText>
                </div>
                <Button onClick={() => setIsCreateOpen(true)} className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90">
                    <Plus className="w-4 h-4 mr-2" /> New Project
                </Button>
            </div>

            {/* AI Insights Panel */}
            {aiInsights && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 animate-in slide-in-from-top-4">
                    <Card className="bg-gradient-to-br from-indigo-900/20 to-purple-900/10 border-indigo-500/20">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-xs font-bold text-indigo-400 flex items-center gap-2">
                                <Clock className="w-3 h-3" /> TIMELINE PREDICTION
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-neutral-200">{aiInsights.completion_prediction || "On track for Q4 release based on current velocity."}</p>
                        </CardContent>
                    </Card>
                    <Card className="bg-gradient-to-br from-amber-900/20 to-orange-900/10 border-amber-500/20">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-xs font-bold text-amber-400 flex items-center gap-2">
                                <AlertTriangle className="w-3 h-3" /> RISK ANALYSIS
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <ul className="text-xs text-neutral-300 list-disc list-inside space-y-1">
                                {(aiInsights.risks || ["Resource bottleneck detected in frontend team."]).map((risk, i) => (
                                    <li key={i}>{risk}</li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                    <Card className="bg-gradient-to-br from-emerald-900/20 to-teal-900/10 border-emerald-500/20">
                        <CardHeader className="pb-2">
                            <CardTitle className="text-xs font-bold text-emerald-400 flex items-center gap-2">
                                <Brain className="w-3 h-3" /> OPTIMIZATION
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-xs text-neutral-300 leading-relaxed">
                                {aiInsights.resource_recommendations?.[0] || "Suggest reallocating 2 devs to API integration task."}
                            </p>
                        </CardContent>
                    </Card>
                </div>
            )}

            {isLoading ? (
                <div className="text-neutral-500 text-sm">Loading telemetry...</div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {projects.map(project => (
                        <Card key={project.id} className="bg-white/5 border-white/10 hover:border-[hsl(var(--color-intent))] transition-colors group">
                            <CardHeader className="flex flex-row items-start justify-between pb-2">
                                <div className="flex items-center gap-3">
                                    <div className="p-2 rounded bg-black/40 border border-white/10 text-[hsl(var(--color-execution))]">
                                        <Folder className="w-4 h-4" />
                                    </div>
                                    <div>
                                        <Link to={`${createPageUrl('WorkRoom')}?projectId=${project.id}`} className="hover:underline">
                                            <CardTitle className="text-sm font-bold text-white">{project.name}</CardTitle>
                                        </Link>
                                        <div className="text-[10px] text-neutral-500 flex items-center gap-1">
                                            <Calendar className="w-3 h-3" />
                                            {new Date(project.created_date).toLocaleDateString()}
                                        </div>
                                    </div>
                                </div>
                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <MoreVertical className="w-3 h-3" />
                                        </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end" className="bg-black border-white/10">
                                        <DropdownMenuItem className="text-xs" onClick={() => window.location.href = `${createPageUrl('WorkRoom')}?projectId=${project.id}`}>
                                            <Edit2 className="w-3 h-3 mr-2" /> Open Workspace
                                        </DropdownMenuItem>
                                        <DropdownMenuItem className="text-xs text-red-500 focus:text-red-500" onClick={() => deleteMutation.mutate(project.id)}>
                                            <Trash2 className="w-3 h-3 mr-2" /> Delete
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>
                            </CardHeader>
                            <CardContent>
                                <p className="text-xs text-neutral-400 line-clamp-2 min-h-[2.5em]">
                                    {project.description || "No description provided."}
                                </p>
                            </CardContent>
                            <CardFooter className="pt-0 flex gap-2">
                                <div className="text-[10px] px-2 py-1 rounded-full bg-white/5 border border-white/5 text-neutral-400">
                                    {project.status}
                                </div>
                                {project.repo_url && (
                                    <a href={project.repo_url} target="_blank" rel="noreferrer" className="text-[10px] px-2 py-1 rounded-full bg-white/5 border border-white/5 text-blue-400 hover:bg-blue-500/10 hover:border-blue-500/20 flex items-center gap-1">
                                        <Globe className="w-3 h-3" /> Repo
                                    </a>
                                )}
                            </CardFooter>
                        </Card>
                    ))}
                    
                    {projects.length === 0 && (
                        <div className="col-span-full py-12 text-center border border-dashed border-white/10 rounded-xl bg-white/5">
                            <Folder className="w-12 h-12 mx-auto text-neutral-600 mb-3" />
                            <h3 className="text-neutral-400 font-medium">No Active Projects</h3>
                            <p className="text-neutral-600 text-sm mb-4">Initialize a new directive to begin.</p>
                            <Button variant="outline" onClick={() => setIsCreateOpen(true)}>Initialize</Button>
                        </div>
                    )}
                </div>
            )}

            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                <DialogContent className="bg-neutral-950 border-white/10">
                    <DialogHeader>
                        <DialogTitle>Initialize Project</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-neutral-500">PROJECT NAME</label>
                            <Input 
                                value={newProjectName} 
                                onChange={(e) => setNewProjectName(e.target.value)} 
                                placeholder="e.g. Apollo Phase II"
                                className="bg-black/40 border-white/10"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-neutral-500">DESCRIPTION</label>
                            <Input 
                                value={newProjectDesc} 
                                onChange={(e) => setNewProjectDesc(e.target.value)} 
                                placeholder="Brief objective summary..."
                                className="bg-black/40 border-white/10"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="ghost" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
                        <Button 
                            onClick={handleCreate} 
                            disabled={createMutation.isPending}
                            className="bg-[hsl(var(--color-execution))] text-black"
                        >
                            {createMutation.isPending ? "Creating..." : "Create Project"}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}