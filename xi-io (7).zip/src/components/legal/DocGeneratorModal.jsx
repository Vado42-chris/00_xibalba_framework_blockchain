import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { FileText, Loader2, Download } from 'lucide-react';
import { toast } from "sonner";
import { Label } from "@/components/ui/label";
import { StateText } from "@/components/ui/design-system/System";

export default function DocGeneratorModal({ open, onOpenChange, category = 'business' }) {
    const [docType, setDocType] = useState('nda');
    const [title, setTitle] = useState('');
    const [partyName, setPartyName] = useState('');
    const queryClient = useQueryClient();
    
    // Reset docType when category changes
    React.useEffect(() => {
        if (category === 'home') setDocType('will');
        else if (category === 'nonprofit') setDocType('bylaws');
        else setDocType('nda');
    }, [category]);

    const generateMutation = useMutation({
        mutationFn: async () => {
            const generatedContent = await base44.integrations.Core.InvokeLLM({
                prompt: `Draft a legal document.
                Category: ${category.toUpperCase()} LAW
                Type: ${docType}
                Subject/Counterparty: ${partyName}
                
                Create a professional, formatted ${docType}.
                Context:
                - If Business: Tech/Software industry standard.
                - If Personal (Home): Family law, asset protection, estate planning.
                - If Nonprofit: 501(c)(3) compliance, grant writing standards.
                
                Include standard clauses, placeholders for dates/signatures, and ensure formatting is clean markdown.`,
                add_context_from_internet: false
            });

            return base44.entities.LegalDoc.create({
                title: title || `${docType.toUpperCase()} - ${partyName}`,
                type: docType,
                category: category,
                status: 'draft',
                content: generatedContent
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['legal_docs']);
            toast.success("Document generated successfully");
            onOpenChange(false);
            setPartyName('');
            setTitle('');
        }
    });

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border-white/10 text-white sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-[hsl(var(--color-active))]" />
                        <span className="font-light tracking-wide">AI DOCUMENT DRAFTER</span>
                    </DialogTitle>
                    <StateText className="text-[10px] opacity-60">Generate legal templates customized for your project.</StateText>
                </DialogHeader>

                <div className="space-y-4 py-4">
                    <div className="space-y-2">
                        <Label>Document Type ({category.toUpperCase()})</Label>
                        <Select value={docType} onValueChange={setDocType}>
                            <SelectTrigger className="bg-neutral-950 border-white/10">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {category === 'business' && (
                                    <>
                                        <SelectItem value="nda">Non-Disclosure Agreement (NDA)</SelectItem>
                                        <SelectItem value="contract">Service Contract</SelectItem>
                                        <SelectItem value="patent_draft">Provisional Patent Draft</SelectItem>
                                        <SelectItem value="incorporation">Incorporation Docs</SelectItem>
                                        <SelectItem value="partnership">Partnership Agreement</SelectItem>
                                    </>
                                )}
                                {category === 'home' && (
                                    <>
                                        <SelectItem value="will">Last Will & Testament</SelectItem>
                                        <SelectItem value="trust">Revocable Living Trust</SelectItem>
                                        <SelectItem value="poa">Power of Attorney</SelectItem>
                                        <SelectItem value="prenup">Prenuptial Agreement</SelectItem>
                                        <SelectItem value="asset_protection">Asset Protection Plan</SelectItem>
                                    </>
                                )}
                                {category === 'nonprofit' && (
                                    <>
                                        <SelectItem value="bylaws">Nonprofit Bylaws</SelectItem>
                                        <SelectItem value="conflict_policy">Conflict of Interest Policy</SelectItem>
                                        <SelectItem value="grant_proposal">Grant Proposal Draft</SelectItem>
                                        <SelectItem value="donor_agreement">Donor Gift Agreement</SelectItem>
                                        <SelectItem value="volunteer_waiver">Volunteer Waiver</SelectItem>
                                    </>
                                )}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="space-y-2">
                        <Label>Counterparty / Subject Name</Label>
                        <Input 
                            value={partyName}
                            onChange={(e) => setPartyName(e.target.value)}
                            placeholder="e.g. John Doe, Project X..."
                            className="bg-neutral-950 border-white/10"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label>Document Title (Optional)</Label>
                        <Input 
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="Custom title..."
                            className="bg-neutral-950 border-white/10"
                        />
                    </div>

                    <div className="pt-4 flex justify-end gap-2">
                        <Button variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button 
                            onClick={() => generateMutation.mutate()}
                            disabled={generateMutation.isPending || !partyName}
                            className="bg-[hsl(var(--color-intent))] text-white"
                        >
                            {generateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Sparkles className="w-4 h-4 mr-2" />}
                            Generate Draft
                        </Button>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}
import { Sparkles } from 'lucide-react';