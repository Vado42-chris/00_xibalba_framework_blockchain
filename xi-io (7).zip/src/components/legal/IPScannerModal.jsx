import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Sparkles, Scan, ArrowRight, CheckCircle2, AlertTriangle, Lightbulb, Users, Info } from 'lucide-react';
import { 
    OrientingText, IntentText, StateText, AtomicParagraph 
} from '@/components/ui/design-system/System';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

export default function IPScannerModal({ open, onOpenChange }) {
    const [step, setStep] = useState('idle'); // idle, scanning, results
    const [findings, setFindings] = useState([]);
    const queryClient = useQueryClient();

    // Mock scanning real project data
    const { data: projects = [] } = useQuery({
        queryKey: ['projects_scan'],
        queryFn: () => base44.entities.Project.list(),
        enabled: open
    });

    const scanMutation = useMutation({
        mutationFn: async () => {
            const projectContext = projects.map(p => `Project: ${p.name}\nDescription: ${p.description || 'No description'}`).join('\n\n');
            
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `Analyze the following projects for potential Intellectual Property (Patents, Trademarks, Trade Secrets). 
                
                Projects:
                ${projectContext}
                
                Return a JSON object with a 'findings' array.`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        findings: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    title: { type: "string" },
                                    type: { type: "string", enum: ["patent", "trademark", "trade_secret"] },
                                    source: { type: "string" },
                                    description: { type: "string" },
                                    score: { type: "number", description: "Likelihood score 0-1" },
                                    contributors: { type: "array", items: { type: "string" } },
                                    reasoning: { type: "string" }
                                },
                                required: ["title", "type", "description", "score", "contributors", "reasoning"]
                            }
                        }
                    }
                }
            });

            return response.findings || [];
        },
        onSuccess: (data) => {
            setFindings(data);
            setStep('results');
        }
    });

    const saveAssetMutation = useMutation({
        mutationFn: (asset) => base44.entities.IPAsset.create({
            title: asset.title,
            type: asset.type,
            description: asset.description,
            status: 'detected',
            likelihood_score: asset.score,
            project_id: 'auto_scan',
            contributors: asset.contributors,
            ai_reasoning: asset.reasoning
        }),
        onSuccess: () => {
            queryClient.invalidateQueries(['ip_assets']);
            toast.success("Asset added to registry");
        }
    });

    const startScan = () => {
        setStep('scanning');
        scanMutation.mutate();
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border-white/10 text-white sm:max-w-[600px] h-[500px] flex flex-col">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Scan className="w-5 h-5 text-[hsl(var(--color-active))]" />
                        <span className="font-light tracking-wide">SAM ENGINE // SCANNER</span>
                    </DialogTitle>
                </DialogHeader>

                <div className="flex-1 flex flex-col p-4">
                    {step === 'idle' && (
                        <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6">
                            <div className="w-32 h-32 rounded-full border border-dashed border-white/20 flex items-center justify-center">
                                <Lightbulb className="w-12 h-12 text-[hsl(var(--color-intent))]" />
                            </div>
                            <div>
                                <IntentText className="text-xl mb-2">Ready to Scan Projects</IntentText>
                                <AtomicParagraph className="max-w-xs mx-auto opacity-70 mb-4">
                                    Our AI agent (SAM) will read through your {projects.length} active projects to identify code and content that should be protected as Intellectual Property.
                                </AtomicParagraph>
                                <div className="text-xs text-neutral-500 bg-neutral-950 p-3 rounded border border-white/5 text-left">
                                    <span className="font-bold block mb-1">What we look for:</span>
                                    <ul className="list-disc list-inside space-y-1">
                                        <li>Unique algorithms (Patents)</li>
                                        <li>Distinctive branding (Trademarks)</li>
                                        <li>Proprietary methods (Trade Secrets)</li>
                                    </ul>
                                </div>
                            </div>
                            <Button 
                                size="lg" 
                                onClick={startScan}
                                className="bg-[hsl(var(--color-active))] text-black hover:bg-[hsl(var(--color-active))]/90"
                            >
                                Start SAM Analysis
                            </Button>
                        </div>
                    )}

                    {step === 'scanning' && (
                        <div className="flex-1 flex flex-col items-center justify-center space-y-8">
                            <div className="relative w-32 h-32">
                                <div className="absolute inset-0 border-4 border-white/10 rounded-full" />
                                <div className="absolute inset-0 border-4 border-t-[hsl(var(--color-active))] rounded-full animate-spin" />
                                <div className="absolute inset-0 flex items-center justify-center font-mono text-xs animate-pulse">
                                    ANALYZING
                                </div>
                            </div>
                            <div className="w-full max-w-sm space-y-2 text-center">
                                <IntentText>Scanning Codebase...</IntentText>
                                <StateText className="opacity-50">Identifying potential assets and checking against public databases.</StateText>
                                <div className="pt-4">
                                     <Progress value={45} className="h-1 bg-neutral-800" indicatorClassName="bg-[hsl(var(--color-active))]" />
                                </div>
                            </div>
                        </div>
                    )}

                    {step === 'results' && (
                        <div className="flex-1 flex flex-col overflow-hidden">
                            <div className="mb-4">
                                <IntentText className="text-lg">Scan Complete</IntentText>
                                <StateText className="text-[hsl(var(--color-active))]">{findings.length} Potential Assets Identified</StateText>
                            </div>
                            
                            <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-thin scrollbar-thumb-white/5">
                                {findings.map((finding, idx) => (
                                    <div key={idx} className="p-4 bg-neutral-950 border border-white/10 rounded-lg group">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center gap-2">
                                                <Badge variant="outline" className="border-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))]">
                                                    {finding.type.toUpperCase()}
                                                </Badge>
                                                <IntentText className="font-bold">{finding.title}</IntentText>
                                            </div>
                                            <StateText className="text-[hsl(var(--color-active))]">{Math.round(finding.score * 100)}% Match</StateText>
                                        </div>
                                        <AtomicParagraph className="text-xs mb-3">{finding.description}</AtomicParagraph>
                                        
                                        <div className="flex flex-col gap-2 mt-3 p-2 bg-white/5 rounded">
                                            <div className="flex items-center gap-2">
                                                <Users className="w-3 h-3 text-neutral-400" />
                                                <StateText className="text-[10px] uppercase tracking-wider opacity-70">Attribution:</StateText>
                                                <div className="flex gap-1">
                                                    {finding.contributors.map((c, i) => (
                                                        <Badge key={i} variant="outline" className="text-[9px] h-4 px-1 border-white/10 text-neutral-300">{c}</Badge>
                                                    ))}
                                                </div>
                                            </div>
                                            <div className="flex items-start gap-2">
                                                <Info className="w-3 h-3 text-[hsl(var(--color-active))] mt-0.5 shrink-0" />
                                                <StateText className="text-[10px] italic text-[hsl(var(--color-active))]/80">{finding.reasoning}</StateText>
                                            </div>
                                        </div>

                                        <div className="flex justify-between items-center mt-3 border-t border-white/5 pt-2">
                                            <StateText className="text-[10px] opacity-50">Source: {finding.source}</StateText>
                                            <Button 
                                                size="sm" 
                                                variant="secondary" 
                                                className="h-7 text-xs"
                                                onClick={(e) => {
                                                    e.target.innerText = "Saved";
                                                    e.target.disabled = true;
                                                    saveAssetMutation.mutate(finding);
                                                }}
                                            >
                                                Add to Registry
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="mt-4 flex justify-end">
                                <Button variant="ghost" onClick={() => onOpenChange(false)}>Close</Button>
                            </div>
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}