import React, { useState } from 'react';
import { 
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Briefcase, Calendar, DollarSign, Loader2, FileCheck } from "lucide-react";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import { SystemCompletion } from '@/components/ui/design-system/SystemDialogs';

export default function ServiceRequestModal({ open, onOpenChange, item, type = 'integration' }) {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [ticketId, setTicketId] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        try {
            const formData = new FormData(e.target);
            const user = await base44.auth.me().catch(() => ({ email: 'anonymous@xi-io.com' }));
            
            await base44.entities.SupportTicket.create({
                subject: `Service Request: ${item.name} (${type})`,
                description: `
Type: ${type}
Price: ${item.price || 'Custom'}
Priority: ${formData.get('priority') || 'standard'}
Budget: ${formData.get('budget') || 'standard'}

Requirements:
${formData.get('requirements')}
                `.trim(),
                category: 'service_request',
                priority: formData.get('priority') === 'urgent' ? 'high' : 'medium',
                user_email: user.email,
                status: 'open'
            });

            setTicketId(`SR-${Math.floor(Math.random() * 10000)}`);
            setIsSuccess(true);
            toast.success("Request received!");
        } catch (error) {
            toast.error("Failed to submit request: " + error.message);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleClose = () => {
        onOpenChange(false);
        setTimeout(() => {
            setIsSuccess(false);
        }, 300);
    };

    if (!item) return null;

    if (isSuccess) {
        return (
            <SystemCompletion 
                open={open}
                onOpenChange={handleClose}
                title="Request Received"
                description="Our automation architects are reviewing your requirements. Expect a proposal within 24 hours."
                stats={[
                    { label: "Ticket ID", value: ticketId },
                    { label: "Priority", value: "Standard" }
                ]}
            />
        );
    }

    return (
        <Dialog open={open} onOpenChange={handleClose}>
            <DialogContent className="sm:max-w-[600px] bg-neutral-900 border-white/10 text-neutral-200 p-0 overflow-hidden gap-0">
                <>
                    <div className="p-6 bg-neutral-950 border-b border-white/5">
                            <div className="flex items-start justify-between mb-4">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <Badge variant="outline" className="border-[hsl(var(--color-execution))]/30 text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/5">
                                            {type === 'bundle' ? 'VALUE PACK' : type === 'concierge' ? 'DIVINE INTERVENTION' : 'INTEGRATION REQUEST'}
                                        </Badge>
                                        <Badge variant="secondary" className="bg-neutral-800 text-neutral-400">
                                            {item.price || 'Custom Quote'}
                                        </Badge>
                                    </div>
                                    <DialogTitle className="text-xl font-bold text-white">{item.name}</DialogTitle>
                                    <DialogDescription className="mt-1">
                                        {type === 'concierge' 
                                            ? "Tell us about your business goals. We'll design the perfect architecture for you."
                                            : `Tell us about your requirements for this ${type === 'bundle' ? 'bundle' : 'integration'}.`
                                        }
                                    </DialogDescription>
                                </div>
                                <div className="p-3 rounded-lg bg-neutral-900 border border-white/10">
                                    <Briefcase className="w-6 h-6 text-neutral-400" />
                                </div>
                            </div>
                        </div>

                        <form onSubmit={handleSubmit} className="p-6 space-y-6">
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label>Timeline Priority</Label>
                                    <Select name="priority" defaultValue="standard">
                                        <SelectTrigger className="bg-neutral-950 border-white/10">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="urgent">Urgent (&lt; 1 week)</SelectItem>
                                            <SelectItem value="standard">Standard (1-2 weeks)</SelectItem>
                                            <SelectItem value="flexible">Flexible</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label>Budget Range</Label>
                                    <Select name="budget" defaultValue="standard">
                                        <SelectTrigger className="bg-neutral-950 border-white/10">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="starter">$500 - $1,000</SelectItem>
                                            <SelectItem value="standard">$1,000 - $5,000</SelectItem>
                                            <SelectItem value="enterprise">$5,000+</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div className="space-y-2">
                                <Label>Specific Requirements</Label>
                                <Textarea 
                                    name="requirements"
                                    required
                                    placeholder="Describe your current setup and what you need this automation to do..."
                                    className="h-32 bg-neutral-950 border-white/10 resize-none"
                                />
                            </div>

                            <div className="flex items-center gap-2 p-4 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs">
                                <CheckCircle2 className="w-4 h-4 shrink-0" />
                                <p>Includes implementation, security audit, and 30 days of support.</p>
                            </div>

                            <DialogFooter className="gap-2 sm:gap-0">
                                <Button type="button" variant="ghost" onClick={handleClose}>Cancel</Button>
                                <Button 
                                    type="submit" 
                                    className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                                    disabled={isSubmitting}
                                >
                                    {isSubmitting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                                    Submit Request
                                </Button>
                            </DialogFooter>
                        </form>
                </>
            </DialogContent>
        </Dialog>
    );
}