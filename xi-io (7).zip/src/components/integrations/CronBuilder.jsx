// Placeholder for CronBuilder
export default function CronBuilder() {
    return null;
}