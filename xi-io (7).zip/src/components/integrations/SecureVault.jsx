import React, { useState } from 'react';
import { Lock, RefreshCw, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { OrientingText, StateText } from '@/components/ui/design-system/System';

export default function SecureVault({ 
    encryptedCredentials, 
    vaultKeyId, 
    isCreating, 
    onRotateStart 
}) {
    const [showRotation, setShowRotation] = useState(false);
    
    // If we are creating, we always show inputs (handled by parent logic typically, but we can encapsulate UI here)
    // If editing existing integration, we show "Encrypted" state by default.

    const handleRotate = () => {
        setShowRotation(true);
        if (onRotateStart) onRotateStart();
    };

    return (
        <div className="space-y-3 p-4 border border-white/10 rounded bg-neutral-900/50 relative overflow-hidden group">
            {/* Security Hologram Effect */}
            <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                <ShieldCheck className="w-12 h-12" />
            </div>

            <div className="flex justify-between items-start mb-2 relative z-10">
                <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-[hsl(var(--color-warning))]/10 rounded-full">
                        <Lock className="w-3 h-3 text-[hsl(var(--color-warning))]" />
                    </div>
                    <div>
                        <OrientingText className="text-[hsl(var(--color-warning))] font-bold tracking-widest">SECURE VAULT</OrientingText>
                        <StateText className="text-[9px] opacity-60">AES-256-GCM / Hardware Backed</StateText>
                    </div>
                </div>
                
                {encryptedCredentials && !isCreating && (
                    <Badge variant="outline" className="text-[9px] bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))] border-[hsl(var(--color-execution))]/20 flex gap-1 items-center">
                        <ShieldCheck className="w-2 h-2" />
                        Encrypted & Active
                    </Badge>
                )}
            </div>
            
            <div className="space-y-3 relative z-10">
                {encryptedCredentials && !isCreating && !showRotation ? (
                    <div className="flex flex-col gap-3 animate-in fade-in slide-in-from-bottom-2">
                        <div className="flex items-center justify-between p-3 bg-neutral-950 rounded border border-white/10 shadow-inner">
                            <div className="flex items-center gap-3">
                                <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))] shadow-[0_0_8px_hsl(var(--color-execution))]" />
                                <div>
                                    <StateText className="font-mono text-[10px] text-neutral-500">KEY ID</StateText>
                                    <StateText className="font-mono text-xs">{vaultKeyId || 'UNKNOWN_KEY_REF'}</StateText>
                                </div>
                            </div>
                            <StateText className="font-mono text-xs opacity-30 tracking-[0.2em]">••••••••••••••••</StateText>
                        </div>
                        
                        <Button 
                            type="button" 
                            variant="outline" 
                            size="sm" 
                            onClick={handleRotate} 
                            className="w-full text-xs h-8 border-white/10 hover:bg-white/5"
                        >
                            <RefreshCw className="w-3 h-3 mr-2" /> Rotate Credentials
                        </Button>
                    </div>
                ) : (
                    <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2">
                         {showRotation && (
                            <div className="p-2 bg-[hsl(var(--color-warning))]/10 border border-[hsl(var(--color-warning))]/20 rounded mb-2">
                                <StateText className="text-[hsl(var(--color-warning))] text-[10px]">
                                    Entering new credentials will generate a new encryption key and invalidate the old one.
                                </StateText>
                            </div>
                         )}

                        <div className="space-y-1">
                            <Input 
                                type="password" 
                                name="cred_secret" 
                                placeholder="API Secret / Private Key / Token" 
                                className="bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-warning))]" 
                                autoFocus={showRotation}
                            />
                        </div>
                        <div className="space-y-1">
                            <Input 
                                type="text" 
                                name="cred_key" 
                                placeholder="Key ID / Client ID / Username (Optional)" 
                                className="bg-neutral-950 border-white/10" 
                            />
                        </div>
                        
                        {showRotation && (
                            <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => setShowRotation(false)} 
                                className="w-full h-6 text-[10px] text-neutral-500 hover:text-white"
                            >
                                Cancel Rotation
                            </Button>
                        )}
                    </div>
                )}
            </div>

            <div className="mt-3 pt-2 border-t border-white/10 flex justify-between items-center">
                <StateText className="text-[9px] opacity-40">Zero-knowledge architecture simulated.</StateText>
            </div>
        </div>
    );
}