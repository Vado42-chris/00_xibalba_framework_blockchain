import React, { useState } from 'react';
import { Play, Sparkles, Terminal, Loader2, ChevronRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from '@/api/base44Client';
import { OrientingText, StateText, IntentText } from '@/components/ui/design-system/System';

export default function ApiPlayground() {
    const [entity, setEntity] = useState('Integration');
    const [method, setMethod] = useState('list');
    const [params, setParams] = useState('{}');
    const [response, setResponse] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [aiPrompt, setAiPrompt] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);

    const entities = ['Integration', 'IntegrationLog', 'IntegrationMapping', 'Campaign', 'Log', 'Task', 'User'];
    const methods = ['list', 'get', 'create', 'update', 'delete', 'count'];

    const executeRequest = async () => {
        setIsLoading(true);
        setResponse(null);
        try {
            let result;
            const args = JSON.parse(params);
            
            if (!base44.entities[entity]) throw new Error(`Entity ${entity} not found`);
            if (!base44.entities[entity][method]) throw new Error(`Method ${method} not found on ${entity}`);

            if (method === 'list') {
                result = await base44.entities[entity].list(args.sort, args.limit, args.skip);
            } else if (method === 'get') {
                result = await base44.entities[entity].get(args.id);
            } else if (method === 'create') {
                result = await base44.entities[entity].create(args.data);
            } else if (method === 'update') {
                result = await base44.entities[entity].update(args.id, args.data);
            } else if (method === 'delete') {
                result = await base44.entities[entity].delete(args.id);
            }

            setResponse(result);
        } catch (e) {
            setResponse({ error: e.message });
        } finally {
            setIsLoading(false);
        }
    };

    const handleAiAssist = () => {
        if (!aiPrompt) return;
        setIsAiLoading(true);
        // Simulating AI generation of API params
        setTimeout(() => {
            if (aiPrompt.toLowerCase().includes('fail')) {
                setEntity('IntegrationLog');
                setMethod('list');
                setParams(JSON.stringify({ query: { status: 'failure' }, limit: 10 }, null, 2));
            } else if (aiPrompt.toLowerCase().includes('user')) {
                setEntity('User');
                setMethod('list');
                setParams(JSON.stringify({ limit: 5 }, null, 2));
            } else {
                setParams(JSON.stringify({ limit: 5 }, null, 2));
            }
            setIsAiLoading(false);
        }, 1000);
    };

    return (
        <div className="flex flex-col h-full bg-neutral-950 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-3 border-b border-white/10 bg-neutral-900 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-[hsl(var(--color-active))]" />
                    <OrientingText>API CONSOLE</OrientingText>
                </div>
                <div className="flex items-center gap-2">
                    <div className="relative">
                        <Input 
                            value={aiPrompt}
                            onChange={(e) => setAiPrompt(e.target.value)}
                            placeholder="AI Assist: 'Show failed logs'..." 
                            className="h-7 w-64 text-xs bg-neutral-950 border-white/10 pr-8"
                        />
                        <button 
                            onClick={handleAiAssist}
                            disabled={isAiLoading}
                            className="absolute right-1 top-1 text-[hsl(var(--color-active))]"
                        >
                            {isAiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                        </button>
                    </div>
                </div>
            </div>

            <div className="flex-1 flex flex-col p-4 gap-4 overflow-y-auto">
                <div className="flex gap-2">
                    <Select value={entity} onValueChange={setEntity}>
                        <SelectTrigger className="h-8 bg-neutral-900 border-white/10 w-40"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {entities.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Select value={method} onValueChange={setMethod}>
                        <SelectTrigger className="h-8 bg-neutral-900 border-white/10 w-32"><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {methods.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Button size="sm" onClick={executeRequest} disabled={isLoading} className="h-8 bg-[hsl(var(--color-active))] text-black ml-auto">
                        {isLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3 mr-1" />}
                        Run
                    </Button>
                </div>

                <div className="flex-1 grid grid-rows-2 gap-4 min-h-0">
                    <div className="flex flex-col gap-1">
                        <StateText className="text-[10px] uppercase opacity-50">Parameters (JSON)</StateText>
                        <Textarea 
                            value={params}
                            onChange={(e) => setParams(e.target.value)}
                            className="flex-1 font-mono text-xs bg-neutral-900 border-white/10 resize-none p-2 leading-relaxed"
                        />
                    </div>
                    <div className="flex flex-col gap-1 relative">
                        <StateText className="text-[10px] uppercase opacity-50">Response</StateText>
                        <div className="flex-1 bg-black border border-white/10 rounded p-2 overflow-auto relative">
                            {response ? (
                                <pre className={`font-mono text-xs ${response.error ? 'text-[hsl(var(--color-error))]' : 'text-[hsl(var(--color-execution))]'}`}>
                                    {JSON.stringify(response, null, 2)}
                                </pre>
                            ) : (
                                <div className="absolute inset-0 flex items-center justify-center opacity-20">
                                    <StateText>Waiting for execution...</StateText>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}