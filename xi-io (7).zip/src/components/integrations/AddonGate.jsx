import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Loader2, Lock, Download, Plug, AlertCircle } from "lucide-react";
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { IntentText, StateText } from '@/components/ui/design-system/System';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from "sonner";

/**
 * AddonGate
 * 
 * A wrapper component that restricts access to UI sections based on Addon installation 
 * and Integration connection status.
 * 
 * @param {string} addonName - The exact name of the MarketplaceItem (e.g. "Chronos Timekeeper")
 * @param {string} integrationType - The connector type (e.g. "googlecalendar")
 * @param {ReactNode} children - The content to show when fully authorized
 * @param {ReactNode} fallback - Optional custom fallback
 */
export const AddonGate = ({ addonName, integrationType, children, fallback, title, icon: Icon }) => {
    const navigate = useNavigate();
    const [role, setRole] = React.useState(null);

    React.useEffect(() => {
        base44.auth.me().then(u => setRole(u.role)).catch(() => {});
    }, []);

    // 1. Check if Addon is Installed
    const { data: installation, isLoading: loadingInstall } = useQuery({
        queryKey: ['addon_gate_install', addonName],
        queryFn: async () => {
            const items = await base44.entities.MarketplaceItem.list();
            const targetItem = items.find(i => i.name === addonName);
            if (!targetItem) return { status: 'missing_item' };

            const installs = await base44.entities.InstalledAddon.list();
            const userInstall = installs.find(i => i.addon_id === targetItem.id);
            
            return {
                status: userInstall ? 'installed' : 'not_installed',
                item: targetItem,
                install: userInstall
            };
        }
    });

    const requestAuth = async () => {
        try {
            await base44.integrations.requestOAuthAuthorization({
                integration_type: integrationType,
                reason: `To enable ${addonName} features in your dashboard.`,
                scopes: getScopesFor(integrationType)
            });
            // Force reload or query invalidation would happen here
            toast.success("Authorization Request Sent");
        } catch (error) {
            toast.error("Authorization Failed: " + error.message);
        }
    };

    if (loadingInstall) {
        return (
            <div className="h-full flex flex-col items-center justify-center p-8 space-y-4">
                <Loader2 className="w-8 h-8 animate-spin text-[hsl(var(--color-execution))]" />
                <div className="text-center">
                    <IntentText className="text-sm font-bold text-[hsl(var(--color-execution))] animate-pulse">VERIFYING ENTITLEMENT</IntentText>
                    <StateText className="text-xs opacity-50 mt-1">Checking cryptographic license signature...</StateText>
                </div>
            </div>
        );
    }

    // State 1: Addon Not Installed in System
    const isDemoMode = typeof window !== 'undefined' && localStorage.getItem('demo_mode') === 'true';
    const isSuperAdmin = role === 'ROOT_ADMIN';
    const isBypassed = isDemoMode || isSuperAdmin;
    
    if (!isBypassed && (installation?.status === 'not_installed' || installation?.status === 'missing_item')) {
        if (fallback) return fallback;
        
        return (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center border border-white/10 rounded-xl bg-gradient-to-b from-neutral-900/50 to-black relative overflow-hidden group">
                {/* Cyberpunk Grid Background */}
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none opacity-20" />
                
                {/* Lock Icon with Glow */}
                <div className="relative mb-6">
                    <div className="absolute inset-0 bg-[hsl(var(--color-execution))] blur-xl opacity-20" />
                    <div className="w-20 h-20 bg-black border border-[hsl(var(--color-execution))]/30 rounded-2xl flex items-center justify-center relative z-10 shadow-[0_0_15px_-5px_hsl(var(--color-execution))] group-hover:scale-105 transition-transform duration-500">
                        {Icon ? <Icon className="w-8 h-8 text-[hsl(var(--color-execution))]" /> : <Lock className="w-8 h-8 text-[hsl(var(--color-execution))]" />}
                    </div>
                    <div className="absolute -bottom-2 -right-2 bg-black border border-white/10 px-2 py-0.5 rounded text-[9px] font-mono text-neutral-400 z-20">
                        LOCKED
                    </div>
                </div>

                <IntentText className="text-2xl font-light mb-2">{title || addonName}</IntentText>
                <StateText className="max-w-xs mx-auto mb-8 text-neutral-400 leading-relaxed">
                    This capability requires the <span className="text-white font-medium">{addonName}</span> module. Upgrade your kernel to access advanced features.
                </StateText>

                <div className="flex gap-3 relative z-10">
                    <Button 
                        onClick={() => navigate(createPageUrl('Marketplace') + `?filter=${encodeURIComponent(addonName)}`)}
                        className="bg-[hsl(var(--color-execution))] text-black font-bold tracking-wide hover:bg-[hsl(var(--color-execution))]/90 shadow-[0_0_20px_-10px_hsl(var(--color-execution))]"
                    >
                        <Download className="w-4 h-4 mr-2" />
                        ACQUIRE MODULE
                    </Button>
                </div>
            </div>
        );
    }

    // State 2: Installed - Render with Entry Animation & License Verification Badge
    return (
        <div className="relative h-full animate-in fade-in zoom-in-95 duration-500 flex flex-col">
            {/* Flash Effect for "Just Installed" feel */}
            <div className="absolute inset-0 bg-[hsl(var(--color-execution))] pointer-events-none opacity-0 animate-[ping_1s_ease-out_1] z-50" />
            
            {/* License Verified Header (Subtle) */}
            <div className="absolute top-2 right-2 z-40 pointer-events-none">
                 <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/20 backdrop-blur-md">
                    <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))]" />
                    <span className="text-[9px] font-mono font-bold text-[hsl(var(--color-execution))] tracking-wider">
                        {isSuperAdmin ? 'ROOT ACCESS' : (isDemoMode ? 'DEMO MODE' : 'LICENSE VERIFIED')}
                    </span>
                 </div>
            </div>

            {children}
        </div>
    );
};

// Helper to get scopes (simplified)
function getScopesFor(type) {
    const scopes = {
        'googlecalendar': ['https://www.googleapis.com/auth/calendar.readonly', 'https://www.googleapis.com/auth/calendar.events'],
        'slack': ['channels:read', 'chat:write'],
        'salesforce': ['full'], // Example
        'notion': ['read_content'] // Example
    };
    return scopes[type] || [];
}