import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { BrandIcon } from "@/components/ui/BrandIcons";
import { cn } from "@/components/ui/utils";
import { RefreshCw, Plus, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from "sonner";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export function useIntegrations(category) {
    const { data: integrations = [] } = useQuery({
        queryKey: ['integrations'],
        queryFn: () => base44.entities.Integration.list(),
        initialData: []
    });

    if (!category) return integrations;
    return integrations.filter(i => i.category === category || (Array.isArray(category) && category.includes(i.category)));
}

export function IntegrationStatus({ category, className }) {
    const integrations = useIntegrations(category);
    const active = integrations.filter(i => i.status === 'active');

    if (active.length === 0) return null;

    return (
        <div className={cn("flex items-center gap-2", className)}>
            {active.map(int => (
                <div key={int.id} className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-neutral-900 border border-white/10 text-[10px] font-mono text-neutral-400">
                    <BrandIcon id={int.provider === 'custom' ? int.name.toLowerCase() : int.provider} className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                    <span className="hidden sm:inline">{int.name}</span>
                    <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))]" />
                </div>
            ))}
        </div>
    );
}

export function SyncButton({ category, onSync, className }) {
    const integrations = useIntegrations(category);
    const hasActive = integrations.some(i => i.status === 'active');
    const [isSyncing, setIsSyncing] = React.useState(false);

    const handleSync = async () => {
        setIsSyncing(true);
        // Simulate sync
        await new Promise(resolve => setTimeout(resolve, 2000));
        setIsSyncing(false);
        toast.success("Data synchronized successfully");
        if (onSync) onSync();
    };

    if (!hasActive) return null;

    return (
        <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleSync}
            disabled={isSyncing}
            className={cn("h-7 text-[10px] gap-2 text-neutral-500 hover:text-white", className)}
        >
            <RefreshCw className={cn("w-3 h-3", isSyncing && "animate-spin")} />
            {isSyncing ? 'SYNCING...' : 'SYNC'}
        </Button>
    );
}

export function ConnectPrompt({ category, title, description, className }) {
    const integrations = useIntegrations(category);
    const hasActive = integrations.some(i => i.status === 'active');

    if (hasActive) return null;

    return (
        <div className={cn("p-6 rounded border border-dashed border-white/10 bg-neutral-900/20 flex flex-col items-center text-center", className)}>
            <div className="flex -space-x-2 mb-3">
                {['salesforce', 'hubspot', 'stripe', 'linear'].map(id => (
                    <div key={id} className="w-8 h-8 rounded-full bg-neutral-800 border border-white/10 flex items-center justify-center relative z-0 first:z-10">
                         <BrandIcon id={id} className="w-4 h-4 text-neutral-500" />
                    </div>
                ))}
            </div>
            <h4 className="text-sm font-medium text-white mb-1">{title || "Connect Tools"}</h4>
            <p className="text-xs text-neutral-500 mb-4 max-w-xs">{description || "Integrate with external providers to populate this view automatically."}</p>
            <Link to={createPageUrl('Integrations')}>
                <Button size="sm" variant="secondary" className="h-8 text-xs">
                    <Plus className="w-3 h-3 mr-2" /> Connect Integration
                </Button>
            </Link>
        </div>
    );
}