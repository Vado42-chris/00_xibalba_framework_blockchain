import React from 'react';
import { Plus, Trash2, ArrowRight, Settings2, Sparkles, Loader2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { StateText, OrientingText } from '@/components/ui/design-system/System';

export default function DataMapper({ mappings, onChange, className }) {
    const [isAutoMapping, setIsAutoMapping] = React.useState(false);

    const addRule = () => {
        onChange([...mappings, { source: '', target: '', transform: 'direct', transform_args: '' }]);
    };

    const handleAutoMap = async () => {
        setIsAutoMapping(true);
        try {
            // Mocking context for AI - in a real app we'd pass schema definitions
            const context = `
                Existing mappings: ${JSON.stringify(mappings)}
                Goal: Map fields from a generic source to our internal schema.
                Common fields: title, description, status, priority, due_date, assignee.
            `;
            
            // This would be a real call to base44.integrations.Core.InvokeLLM
            // Simulating response for UI feel
            setTimeout(() => {
                const newRules = [
                    { source: 'summary', target: 'description', transform: 'direct', transform_args: '' },
                    { source: 'state', target: 'status', transform: 'lowercase', transform_args: '' },
                    { source: 'owner', target: 'assignee', transform: 'direct', transform_args: '' }
                ];
                onChange([...mappings, ...newRules]);
                setIsAutoMapping(false);
            }, 1500);
        } catch (e) {
            setIsAutoMapping(false);
        }
    };

    const removeRule = (index) => {
        const newMappings = [...mappings];
        newMappings.splice(index, 1);
        onChange(newMappings);
    };

    const updateRule = (index, field, value) => {
        const newMappings = [...mappings];
        newMappings[index] = { ...newMappings[index], [field]: value };
        onChange(newMappings);
    };

    return (
        <div className={className}>
            <div className="flex justify-between items-center mb-4">
                <Label className="text-xs uppercase tracking-widest text-neutral-500">Field Transformation Rules</Label>
                <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={handleAutoMap} disabled={isAutoMapping} className="h-6 text-[10px] border-[hsl(var(--color-active))]/30 text-[hsl(var(--color-active))] hover:bg-[hsl(var(--color-active))]/10">
                        {isAutoMapping ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Sparkles className="w-3 h-3 mr-1" />}
                        Auto-Map
                    </Button>
                    <Button size="sm" variant="outline" onClick={addRule} className="h-6 text-[10px] border-white/10 text-neutral-400 hover:text-white hover:bg-white/5">
                        <Plus className="w-3 h-3 mr-1" /> Add Rule
                    </Button>
                </div>
            </div>

            <div className="space-y-2">
                {mappings.length === 0 && (
                    <div className="p-4 border border-dashed border-white/10 rounded text-center opacity-50">
                        <StateText>No mapping rules defined.</StateText>
                    </div>
                )}
                
                {mappings.map((rule, idx) => (
                    <div key={idx} className="p-3 bg-neutral-900 border border-white/10 rounded flex flex-col gap-3 group hover:border-white/30 transition-colors">
                        <div className="flex items-center gap-2">
                            <div className="flex-1">
                                <OrientingText className="mb-1 text-[9px]">SOURCE FIELD</OrientingText>
                                <Input 
                                    value={rule.source} 
                                    onChange={(e) => updateRule(idx, 'source', e.target.value)}
                                    placeholder="e.g. title"
                                    className="h-8 text-xs bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-active))]"
                                />
                            </div>
                            
                            <div className="flex flex-col items-center justify-end h-full pt-4">
                                <ArrowRight className="w-3 h-3 text-neutral-500" />
                            </div>

                            <div className="flex-1">
                                <OrientingText className="mb-1 text-[9px]">TARGET FIELD</OrientingText>
                                <Input 
                                    value={rule.target} 
                                    onChange={(e) => updateRule(idx, 'target', e.target.value)}
                                    placeholder="e.g. external_title"
                                    className="h-8 text-xs bg-neutral-950 border-white/10 focus:border-[hsl(var(--color-active))]"
                                />
                            </div>

                            <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => removeRule(idx)}
                                className="h-8 w-8 mt-4 text-neutral-500 hover:text-[hsl(var(--color-error))]"
                            >
                                <Trash2 className="w-3 h-3" />
                            </Button>
                        </div>

                        {/* Transformation Logic */}
                        <div className="flex items-center gap-2 pl-2 border-l-2 border-white/10">
                            <Settings2 className="w-3 h-3 text-neutral-500" />
                            <Select value={rule.transform} onValueChange={(val) => updateRule(idx, 'transform', val)}>
                                <SelectTrigger className="h-7 text-[10px] w-32 bg-transparent border-none text-neutral-300">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="direct">Direct Copy</SelectItem>
                                    <SelectItem value="uppercase">Uppercase</SelectItem>
                                    <SelectItem value="lowercase">Lowercase</SelectItem>
                                    <SelectItem value="date_iso">Date (ISO)</SelectItem>
                                    <SelectItem value="static">Static Value</SelectItem>
                                    <SelectItem value="concat">Concatenate</SelectItem>
                                </SelectContent>
                            </Select>
                            
                            {(rule.transform === 'static' || rule.transform === 'concat') && (
                                <Input 
                                    value={rule.transform_args} 
                                    onChange={(e) => updateRule(idx, 'transform_args', e.target.value)}
                                    placeholder={rule.transform === 'concat' ? "Suffix..." : "Value..."}
                                    className="h-7 text-[10px] flex-1 bg-transparent border-b border-white/10 rounded-none px-0 focus-visible:ring-0 focus-visible:border-[hsl(var(--color-active))]"
                                />
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}