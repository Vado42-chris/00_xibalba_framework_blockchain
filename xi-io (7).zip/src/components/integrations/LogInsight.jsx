import React, { useState } from 'react';
import { Activity, AlertTriangle, CheckCircle2, Loader2, Sparkles } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { OrientingText, StateText, IntentText } from '@/components/ui/design-system/System';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function LogInsight({ logs }) {
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysis, setAnalysis] = useState(null);
    const [isOpen, setIsOpen] = useState(false);

    const handleAnalyze = () => {
        setIsAnalyzing(true);
        setIsOpen(true);
        // Simulate AI Analysis
        setTimeout(() => {
            const failureCount = logs.filter(l => l.status === 'failure').length;
            setAnalysis({
                status: failureCount > 0 ? 'attention' : 'nominal',
                summary: failureCount > 0 
                    ? `Detected ${failureCount} failures in the last 24h cycle. Potential API rate limiting observed on 'Salesforce CRM'. Suggest increasing backoff interval.`
                    : "All systems operating within nominal parameters. No anomalies detected in execution patterns.",
                confidence: 98
            });
            setIsAnalyzing(false);
        }, 2000);
    };

    return (
        <>
            <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleAnalyze}
                className="h-6 text-[10px] text-[hsl(var(--color-active))] hover:bg-[hsl(var(--color-active))]/10 border border-[hsl(var(--color-active))]/20"
            >
                <Sparkles className="w-3 h-3 mr-1" /> Analyze
            </Button>

            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent className="bg-neutral-950 border-white/10 text-white max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-sm font-mono uppercase tracking-widest">
                            <Activity className="w-4 h-4 text-[hsl(var(--color-active))]" />
                            System Intelligence
                        </DialogTitle>
                    </DialogHeader>
                    
                    <div className="py-4">
                        {isAnalyzing ? (
                            <div className="flex flex-col items-center justify-center py-8 space-y-4">
                                <Loader2 className="w-8 h-8 text-[hsl(var(--color-active))] animate-spin" />
                                <StateText className="animate-pulse">Processing telemetry vectors...</StateText>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                <div className={`p-4 rounded border ${
                                    analysis?.status === 'attention' 
                                    ? 'bg-[hsl(var(--color-warning))]/10 border-[hsl(var(--color-warning))]/30' 
                                    : 'bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))]/30'
                                }`}>
                                    <div className="flex items-center gap-2 mb-2">
                                        {analysis?.status === 'attention' ? (
                                            <AlertTriangle className="w-4 h-4 text-[hsl(var(--color-warning))]" />
                                        ) : (
                                            <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                                        )}
                                        <IntentText className="font-bold">
                                            {analysis?.status === 'attention' ? 'ANOMALIES DETECTED' : 'SYSTEM NOMINAL'}
                                        </IntentText>
                                    </div>
                                    <StateText className="text-xs leading-relaxed opacity-90">
                                        {analysis?.summary}
                                    </StateText>
                                </div>
                                <div className="flex justify-between items-center text-[10px] text-neutral-500">
                                    <span>Analysis Confidence: {analysis?.confidence}%</span>
                                    <span>Model: Cortex-V4</span>
                                </div>
                            </div>
                        )}
                    </div>
                </DialogContent>
            </Dialog>
        </>
    );
}