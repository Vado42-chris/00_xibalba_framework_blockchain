import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, SemanticDot, Layer } from '@/components/ui/design-system/SystemDesign';
import { SystemMonitor } from '@/components/agents/SystemMonitor';
import { InsightEngine } from '@/components/agents/InsightEngine';
import { Palette, Image, Video, Layers, PenTool, Disc } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function XibalbaDashboard() {
    return (
        <QuadrantGrid>
            <Quadrant type="orientation">
                <div className="flex items-center gap-3 mb-6">
                    <Palette className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                    <div>
                        <OrientingText className="tracking-widest font-bold">XIBALBA</OrientingText>
                        <IntentText className="text-lg font-light">Creative Studio</IntentText>
                    </div>
                </div>
                
                <SystemMonitor domainFamily="Xibalba" />
            </Quadrant>

            <Quadrant type="intent" dominance="dominant">
                <div className="flex justify-between items-center mb-6">
                    <OrientingText>PROJECT MATRIX</OrientingText>
                    <Link to={createPageUrl('Studio')}>
                        <Button size="sm" className="h-7 text-xs bg-[hsl(var(--color-intent))] text-white">New Project</Button>
                    </Link>
                </div>

                {/* NEW USER ONBOARDING TASK */}
                <div className="mb-6 p-4 rounded-lg bg-gradient-to-r from-[hsl(var(--color-intent))]/10 to-transparent border border-[hsl(var(--color-intent))]/20 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-[hsl(var(--color-intent))] flex items-center justify-center text-white">
                            <PenTool className="w-5 h-5" />
                        </div>
                        <div>
                            <div className="text-sm font-bold text-white">System Task: Architect Your OS</div>
                            <div className="text-xs text-neutral-400">Design and mint your custom Linux distribution.</div>
                        </div>
                    </div>
                    <Link to={createPageUrl('DistroBuilder')}>
                        <Button size="sm" className="bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90">
                            Start Wizard
                        </Button>
                    </Link>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {['Neon Dreams', 'Void Identity', 'Cyber Editorial'].map((p, i) => (
                        <div key={i} className="group relative aspect-video bg-black/40 backdrop-blur-md rounded-lg overflow-hidden border border-white/10 hover:border-[hsl(var(--color-intent))] transition-all">
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                            <div className="absolute bottom-3 left-3">
                                <IntentText className="font-medium group-hover:text-[hsl(var(--color-intent))] transition-colors">{p}</IntentText>
                                <StateText className="text-[10px] opacity-60">Last edited 2d ago</StateText>
                            </div>
                            <div className="absolute top-3 right-3">
                                <SemanticDot type={i === 0 ? "active" : "settled"} />
                            </div>
                        </div>
                    ))}
                </div>
            </Quadrant>

            <Quadrant type="state">
                <InsightEngine context="creative" />
                
                <div className="mt-6 space-y-4">
                    <OrientingText>ASSET LIBRARY</OrientingText>
                    <div className="grid grid-cols-2 gap-2">
                        <Link to={createPageUrl('ContentManager')} className="p-3 bg-black/40 backdrop-blur-md rounded flex flex-col items-center justify-center gap-2 border border-white/5 hover:bg-white/5 cursor-pointer transition-colors group">
                            <Image className="w-5 h-5 text-neutral-500 group-hover:text-white" />
                            <StateText>Images</StateText>
                        </Link>
                        <Link to={createPageUrl('ContentManager')} className="p-3 bg-black/40 backdrop-blur-md rounded flex flex-col items-center justify-center gap-2 border border-white/5 hover:bg-white/5 cursor-pointer transition-colors group">
                            <Video className="w-5 h-5 text-neutral-500 group-hover:text-white" />
                            <StateText>Motion</StateText>
                        </Link>
                    </div>
                </div>
            </Quadrant>
        </QuadrantGrid>
    );
}