import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import { LayoutTemplate, Plus, X } from 'lucide-react';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { SystemForm, SystemField } from '@/components/ui/design-system/SystemContent';

const WIDGET_REGISTRY = [
    { id: 'PerformanceWidget', name: 'Performance Metrics', category: 'Executive' },
    { id: 'GlobalFeedWidget', name: 'Global Feed', category: 'Monitoring' },
    { id: 'InboxWidget', name: 'Unified Inbox', category: 'Communication' },
    { id: 'BusinessPortfolioWidget', name: 'Business Portfolio', category: 'Operations' },
    { id: 'DistributionWidget', name: 'Distribution Map', category: 'Operations' },
    { id: 'BankingWidget', name: 'Banking & Cash Flow', category: 'Finance' },
    { id: 'CryptoWalletWidget', name: 'Crypto Assets', category: 'Finance' },
    { id: 'BusinessPlanWidget', name: 'Strategy Goals', category: 'Executive' },
    { id: 'InsightEngine', name: 'AI Insight Engine', category: 'Intelligence' },
    { id: 'SystemMonitor', name: 'System Health', category: 'Monitoring' },
];

export function DashboardBuilderModal({ open, onOpenChange, onLayoutCreated }) {
    const [name, setName] = useState("");
    const [q2Widgets, setQ2Widgets] = useState([]);
    const [q3Widgets, setQ3Widgets] = useState([]);
    const [q4Widgets, setQ4Widgets] = useState([]);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async () => {
        if (!name) {
            toast.error("Please enter a layout name");
            return;
        }

        try {
            setIsSubmitting(true);
            await base44.entities.DashboardLayout.create({
                name,
                q2_widgets: q2Widgets,
                q3_widgets: q3Widgets,
                q4_widgets: q4Widgets
            });
            toast.success("Dashboard layout created");
            onOpenChange(false);
            if (onLayoutCreated) onLayoutCreated();
            
            // Reset form
            setName("");
            setQ2Widgets([]);
            setQ3Widgets([]);
            setQ4Widgets([]);
        } catch (error) {
            console.error(error);
            toast.error("Failed to create layout");
        } finally {
            setIsSubmitting(false);
        }
    };

    const WidgetSelector = ({ title, selected, setSelected, description }) => (
        <div className="space-y-3 p-4 border border-white/10 rounded-lg bg-neutral-900/50">
            <div className="flex justify-between items-start">
                <div>
                    <Label className="text-sm font-medium text-white">{title}</Label>
                    <p className="text-[10px] text-neutral-500 mt-1">{description}</p>
                </div>
                <div className="text-[10px] px-2 py-0.5 rounded bg-white/5 border border-white/5 text-neutral-400">
                    {selected.length} Selected
                </div>
            </div>
            
            <ScrollArea className="h-32 pr-2">
                <div className="space-y-2">
                    {WIDGET_REGISTRY.map((widget) => (
                        <div key={widget.id} className="flex items-center space-x-2 p-1.5 rounded hover:bg-white/5 transition-colors">
                            <Checkbox 
                                id={`${title}-${widget.id}`}
                                checked={selected.includes(widget.id)}
                                onCheckedChange={(checked) => {
                                    if (checked) {
                                        setSelected([...selected, widget.id]);
                                    } else {
                                        setSelected(selected.filter(id => id !== widget.id));
                                    }
                                }}
                                className="border-white/20 data-[state=checked]:bg-[hsl(var(--color-intent))] data-[state=checked]:border-[hsl(var(--color-intent))]"
                            />
                            <label 
                                htmlFor={`${title}-${widget.id}`} 
                                className="text-xs text-neutral-300 cursor-pointer flex-1 flex justify-between"
                            >
                                <span>{widget.name}</span>
                                <span className="text-[9px] opacity-50 uppercase">{widget.category}</span>
                            </label>
                        </div>
                    ))}
                </div>
            </ScrollArea>
        </div>
    );

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl bg-neutral-950 border border-white/10 text-white p-0 overflow-hidden">
                <div className="p-6 border-b border-white/10 bg-neutral-900">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <LayoutTemplate className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                            Dashboard Layout Architect
                        </DialogTitle>
                        <DialogDescription className="text-neutral-400">
                            Compose a custom command center view by assigning widgets to the available display quadrants.
                        </DialogDescription>
                    </DialogHeader>
                </div>

                <div className="p-6 max-h-[70vh] overflow-y-auto">
                    <SystemForm
                        title="Configuration"
                        description="Define the structure and content of your new dashboard view."
                    >
                        <SystemField label="Layout Name" helper="A unique identifier for this dashboard configuration.">
                            <Input 
                                id="layout-name" 
                                value={name} 
                                onChange={(e) => setName(e.target.value)}
                                placeholder="e.g., Supply Chain Monitor, Crypto Operations..." 
                                className="bg-neutral-900 border-white/10 text-white placeholder:text-neutral-600"
                            />
                        </SystemField>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                            <WidgetSelector 
                                title="Quadrant 2 (Top Right)"
                                description="Dominant Intent Layer. Best for high-level metrics and KPIs."
                                selected={q2Widgets}
                                setSelected={setQ2Widgets}
                            />
                            <WidgetSelector 
                                title="Quadrant 3 (Bottom Left)"
                                description="State Layer. Best for feeds, lists, and logs."
                                selected={q3Widgets}
                                setSelected={setQ3Widgets}
                            />
                            <WidgetSelector 
                                title="Quadrant 4 (Bottom Right)"
                                description="Supporting Intent. Best for insights, strategies, or secondary data."
                                selected={q4Widgets}
                                setSelected={setQ4Widgets}
                            />
                        </div>
                    </SystemForm>
                </div>

                <DialogFooter className="p-6 border-t border-white/10 bg-neutral-900">
                    <Button variant="ghost" onClick={() => onOpenChange(false)} className="text-neutral-400 hover:text-white">Cancel</Button>
                    <Button 
                        onClick={handleSubmit} 
                        disabled={isSubmitting}
                        className="bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90"
                    >
                        {isSubmitting ? "Creating..." : "Create Layout"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}