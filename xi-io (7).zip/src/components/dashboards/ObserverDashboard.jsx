import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
    Activity, Shield, PlayCircle, Layers, 
    ShoppingBag, Terminal, Monitor, Eye 
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import { 
    QuadrantGrid, Quadrant, 
    OrientingText, IntentText, StateText 
} from '@/components/ui/design-system/System';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { GuideBox } from '@/components/ui/GuideBox';
import { Button } from "@/components/ui/button";
import { PersonaCard } from '@/components/identity/PersonaCard';
import { Badge } from "@/components/ui/badge";

export default function ObserverDashboard() {
    const navigate = useNavigate();

    return (
        <QuadrantGrid>
            {/* Q1: IDENTITY & ORIENTATION */}
            <Quadrant type="orientation">
                <div className="flex flex-col h-full justify-between">
                    <div>
                        <div className="flex items-center gap-3 mb-6">
                            <Eye className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                            <div>
                                <OrientingText className="tracking-[0.2em] text-[10px] uppercase opacity-70">OBSERVER NODE</OrientingText>
                                <IntentText className="text-xl font-light tracking-tight">Tech Demo Control</IntentText>
                            </div>
                        </div>

                        <PersonaCard className="mb-6" />

                        <GuideBox title="Mission: Sovereignty" defaultOpen={true}>
                            <p className="mb-2">
                                You are currently an <strong>Observer</strong>. You have read-access to the Xibalba network.
                            </p>
                            <p className="mb-2">
                                Your goal is to build your own platform using our tools, then "Hard Fork" away from us to become a <strong>Sovereign</strong>.
                            </p>
                            <div className="mt-4 flex gap-2">
                                <Badge variant="outline" className="border-white/10 bg-white/5 text-neutral-400">Step 1: Observe</Badge>
                                <Badge variant="outline" className="border-white/10 bg-white/5 text-neutral-400">Step 2: Build</Badge>
                                <Badge variant="outline" className="border-[hsl(var(--color-intent))]/30 bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))]">Step 3: Fork</Badge>
                            </div>
                        </GuideBox>
                    </div>

                    <div className="space-y-2">
                        <OrientingText>SYSTEM STATUS</OrientingText>
                        <div className="flex items-center justify-between p-3 rounded bg-neutral-900/50 border border-white/5">
                            <span className="text-xs text-neutral-400">Seed 001 Uplink</span>
                            <span className="text-xs text-green-500 font-mono flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                                CONNECTED
                            </span>
                        </div>
                    </div>
                </div>
            </Quadrant>

            {/* Q2: THE WORKSHOP (TOOLS) */}
            <Quadrant type="intent" dominance="dominant" className="p-0 border-none bg-transparent">
                <div className="flex flex-col h-full p-8 space-y-8 overflow-y-auto">
                    <div>
                        <div className="flex items-center justify-between mb-4">
                            <IntentText className="text-2xl font-light">The Workshop</IntentText>
                            <StateText className="text-xs opacity-50">Build your white-label platform</StateText>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <SystemCard
                                title="Design Studio"
                                subtitle="Visual DNA Configuration"
                                icon={Layers}
                                status="active"
                                onClick={() => navigate(createPageUrl('Studio'))}
                                className="h-full"
                            >
                                <p className="text-xs text-neutral-400 mt-2">Configure system aesthetics and UI components.</p>
                            </SystemCard>

                            <SystemCard
                                title="Site Builder"
                                subtitle="Frontend Assembly"
                                icon={Monitor}
                                status="execution"
                                onClick={() => navigate(createPageUrl('ContentManager'))}
                                className="h-full"
                            >
                                <p className="text-xs text-neutral-400 mt-2">WYSIWYG editor for public-facing content.</p>
                            </SystemCard>

                            <SystemCard
                                title="Distro Forge"
                                subtitle="Kernel Architect"
                                icon={Terminal}
                                status="review"
                                onClick={() => navigate(createPageUrl('DistroBuilder'))}
                                className="h-full"
                            >
                                <p className="text-xs text-neutral-400 mt-2">Build your custom OS distribution manifest.</p>
                            </SystemCard>

                            <SystemCard
                                title="Marketplace"
                                subtitle="Module Acquisition"
                                icon={ShoppingBag}
                                status="settled"
                                onClick={() => navigate(createPageUrl('Marketplace'))}
                                className="h-full"
                            >
                                <p className="text-xs text-neutral-400 mt-2">Buy and sell system modules.</p>
                            </SystemCard>
                        </div>
                    </div>

                    {/* HERO ACTION: SIMULATION */}
                    <div className="p-8 rounded-2xl bg-gradient-to-r from-neutral-900 to-black border border-white/10 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-[hsl(var(--color-intent))] blur-[100px] opacity-10 group-hover:opacity-20 transition-opacity" />
                        
                        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
                            <div className="flex-1 space-y-4">
                                <Badge className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]">READY FOR LAUNCH</Badge>
                                <h2 className="text-3xl font-bold text-white">The Sovereign Simulation</h2>
                                <p className="text-sm text-neutral-400 max-w-md">
                                    Experience the "Hard Fork" moment. Simulate the deployment of your custom node to a local server environment. See your Persona Card evolve.
                                </p>
                                <Button 
                                    size="lg" 
                                    className="font-bold bg-white text-black hover:bg-neutral-200"
                                    onClick={() => navigate(createPageUrl('Simulation'))} // To be built next
                                >
                                    <PlayCircle className="w-5 h-5 mr-2" />
                                    LAUNCH SIMULATION
                                </Button>
                            </div>
                            <div className="shrink-0">
                                <Activity className="w-32 h-32 text-neutral-800 group-hover:text-neutral-700 transition-colors" />
                            </div>
                        </div>
                    </div>
                </div>
            </Quadrant>

            {/* Q3: FEED (Empty for now/System Logs) */}
            <Quadrant type="state">
                <OrientingText className="mb-4">RECENT ACTIVITY</OrientingText>
                <div className="space-y-2 opacity-50">
                    <div className="text-xs text-neutral-500 font-mono">[SYSTEM] Observer Session Initialized</div>
                    <div className="text-xs text-neutral-500 font-mono">[NETWORK] Connected to Seed 001</div>
                    <div className="text-xs text-neutral-500 font-mono">[AUTH] Guest Mode Active</div>
                </div>
            </Quadrant>

            {/* Q4: INSIGHTS (Empty for now) */}
            <Quadrant type="intent" dominance="supporting">
                <div className="h-full flex items-center justify-center opacity-30">
                    <div className="text-center">
                        <Shield className="w-8 h-8 mx-auto mb-2" />
                        <StateText>Awaiting Input</StateText>
                    </div>
                </div>
            </Quadrant>
        </QuadrantGrid>
    );
}