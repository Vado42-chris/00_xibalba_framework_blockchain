import React from 'react';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, SemanticDot, Layer } from '@/components/ui/design-system/SystemDesign';
import { SystemMonitor } from '@/components/agents/SystemMonitor';
import { InsightEngine } from '@/components/agents/InsightEngine';
import { FlaskConical, Atom, Binary, Network } from 'lucide-react';
import { LoadingLab } from '@/components/ui/design-system/Curiosity';

export default function NumericalDashboard() {
    return (
        <QuadrantGrid>
            <Quadrant type="orientation">
                <div className="flex items-center gap-3 mb-6">
                    <FlaskConical className="w-6 h-6 text-[hsl(var(--color-warning))]" />
                    <div>
                        <OrientingText className="tracking-widest font-bold">NUMERICAL</OrientingText>
                        <IntentText className="text-lg font-light">Experimental Labs</IntentText>
                    </div>
                </div>
                
                <SystemMonitor domainFamily="Numerical" />
            </Quadrant>

            <Quadrant type="intent" dominance="dominant" className="relative overflow-hidden">
                <div className="absolute inset-0 opacity-5 pointer-events-none">
                    <LoadingLab active={true} cause="Simulation" />
                </div>
                
                <div className="relative z-10">
                    <OrientingText className="mb-6">ACTIVE EXPERIMENTS</OrientingText>
                    
                    <div className="space-y-4">
                        <div className="p-4 bg-black/40 backdrop-blur-xl rounded border border-[hsl(var(--color-warning))]/30">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                    <Atom className="w-4 h-4 text-[hsl(var(--color-warning))]" />
                                    <IntentText>Agent Swarm V2</IntentText>
                                </div>
                                <div className="px-2 py-0.5 bg-[hsl(var(--color-warning))]/10 rounded text-[9px] text-[hsl(var(--color-warning))] uppercase">Running</div>
                            </div>
                            <div className="w-full bg-black/50 h-1.5 rounded-full overflow-hidden">
                                <div className="h-full bg-[hsl(var(--color-warning))] w-[65%]" />
                            </div>
                            <StateText className="mt-2 text-xs opacity-60">Training cycle 452/1000. Loss: 0.024</StateText>
                        </div>

                        <div className="p-4 bg-black/20 backdrop-blur-md rounded border border-white/5 opacity-60 grayscale">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                    <Binary className="w-4 h-4 text-neutral-500" />
                                    <IntentText>Quantum Encryption</IntentText>
                                </div>
                                <div className="px-2 py-0.5 bg-neutral-800 rounded text-[9px] text-neutral-500 uppercase">Paused</div>
                            </div>
                             <div className="w-full bg-black/50 h-1.5 rounded-full overflow-hidden">
                                <div className="h-full bg-neutral-700 w-[12%]" />
                            </div>
                        </div>
                    </div>
                </div>
            </Quadrant>

            <Quadrant type="state">
                <InsightEngine context="research" />
                
                <div className="mt-6">
                    <Layer level="state" className="p-4 border border-dashed border-white/20">
                        <OrientingText className="mb-2">LAB NOTES</OrientingText>
                        <p className="font-mono text-xs text-neutral-400 leading-relaxed">
                            &gt; Subject 8-42s showing improved reasoning capabilities.<br/>
                            &gt; Anomaly detected in sector 7 during stress test.<br/>
                            &gt; Recommendation: Increase memory allocation for next run.
                        </p>
                    </Layer>
                </div>
            </Quadrant>
        </QuadrantGrid>
    );
}