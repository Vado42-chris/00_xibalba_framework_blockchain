import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Activity, Shield, Zap, RefreshCw, Download, Play, 
    AlertTriangle, CheckCircle2, Workflow, Users, Clock
} from 'lucide-react';
import { 
    Quadrant, OrientingText, IntentText, StateText, Layer 
} from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { format } from 'date-fns';

export function PostLaunchMonitorWidget() {
    const queryClient = useQueryClient();
    const [lastUpdated, setLastUpdated] = useState(new Date());

    // 1. Fetch Active Agents
    const { data: agents = [] } = useQuery({
        queryKey: ['monitor_agents'],
        queryFn: () => base44.entities.Agent.list(),
        refetchInterval: 30000 // 30s
    });

    // 2. Fetch Recent Tasks (Chains)
    const { data: tasks = [] } = useQuery({
        queryKey: ['monitor_tasks'],
        queryFn: () => base44.entities.Task.list(), // In real app, filter by date
        refetchInterval: 30000
    });

    // 3. Fetch Alerts (Logs with type 'error' or 'warning' or specific anomaly logs)
    const { data: logs = [] } = useQuery({
        queryKey: ['monitor_logs'],
        queryFn: () => base44.entities.Log.list(),
        refetchInterval: 30000
    });

    // Process Data
    const activeAgents = agents.filter(a => a.status === 'executing' || a.status === 'analyzing');
    const recentChains = tasks
        .filter(t => t.chainId)
        .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
        .slice(0, 5);
        
    const recentAlerts = logs
        .filter(l => l.status === 'error' || l.type === 'security' || (l.content && l.content.toLowerCase().includes('anomaly')))
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        .slice(0, 5);

    const queuedTasks = tasks.filter(t => t.status === 'queued').length;
    const handoffs = tasks.filter(t => t.handoffTo).length;

    // Simulation Mutation
    const simulateMutation = useMutation({
        mutationFn: () => base44.functions.invoke('healer', { 
            action: 'dispatch', 
            anomaly: { text: 'Simulated Service Failure', source: 'Manual Test', node: 'Node-Test-01' } 
        }),
        onSuccess: () => {
            queryClient.invalidateQueries(['monitor_tasks']);
            queryClient.invalidateQueries(['monitor_logs']);
        }
    });

    const handleRefresh = () => {
        queryClient.invalidateQueries();
        setLastUpdated(new Date());
    };

    const handleExport = () => {
        const data = {
            timestamp: new Date().toISOString(),
            agents: agents,
            activeChains: recentChains,
            alerts: recentAlerts,
            stats: {
                queuedTasks,
                handoffs,
                activeAgents: activeAgents.length
            }
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `post-launch-report-${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="flex flex-col h-full bg-neutral-900/50 rounded-sm border border-white/10 overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-white/10 bg-neutral-900">
                <div className="flex items-center gap-3">
                    <Activity className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                    <div>
                        <OrientingText className="text-[10px] tracking-widest uppercase opacity-70">POST-LAUNCH MONITOR</OrientingText>
                        <IntentText className="text-sm font-medium">Live Validation Stream</IntentText>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[9px] font-mono border-white/10 text-neutral-500">
                        Updated: {format(lastUpdated, 'HH:mm:ss')}
                    </Badge>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={handleRefresh}>
                        <RefreshCw className="w-3 h-3" />
                    </Button>
                </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-4 gap-px bg-white/5">
                <div className="bg-neutral-900 p-3 flex flex-col items-center justify-center text-center">
                    <Users className="w-4 h-4 text-neutral-500 mb-1" />
                    <StateText className="text-lg font-bold text-[hsl(var(--color-intent))]">{activeAgents.length}/{agents.length}</StateText>
                    <span className="text-[9px] text-neutral-500 uppercase tracking-wider">Active Agents</span>
                </div>
                <div className="bg-neutral-900 p-3 flex flex-col items-center justify-center text-center">
                    <Workflow className="w-4 h-4 text-neutral-500 mb-1" />
                    <StateText className="text-lg font-bold text-[hsl(var(--color-execution))]">{queuedTasks}</StateText>
                    <span className="text-[9px] text-neutral-500 uppercase tracking-wider">Queue Depth</span>
                </div>
                <div className="bg-neutral-900 p-3 flex flex-col items-center justify-center text-center">
                    <AlertTriangle className="w-4 h-4 text-neutral-500 mb-1" />
                    <StateText className={`text-lg font-bold ${recentAlerts.length > 0 ? 'text-[hsl(var(--color-warning))]' : 'text-neutral-400'}`}>
                        {recentAlerts.length}
                    </StateText>
                    <span className="text-[9px] text-neutral-500 uppercase tracking-wider">Anomalies</span>
                </div>
                <div className="bg-neutral-900 p-3 flex flex-col items-center justify-center text-center">
                    <CheckCircle2 className="w-4 h-4 text-neutral-500 mb-1" />
                    <StateText className="text-lg font-bold text-[hsl(var(--color-active))]">{handoffs}</StateText>
                    <span className="text-[9px] text-neutral-500 uppercase tracking-wider">Handoffs</span>
                </div>
            </div>

            {/* Content Lists */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {/* Active Chains */}
                <div>
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] uppercase tracking-wider text-neutral-500">Recent Chains</span>
                    </div>
                    <div className="space-y-2">
                        {recentChains.length === 0 ? (
                            <div className="text-xs text-neutral-600 italic py-2">No active chains detected.</div>
                        ) : (
                            recentChains.map(task => (
                                <div key={task.id} className="flex items-center justify-between p-2 bg-neutral-950 rounded border border-white/5">
                                    <div className="flex flex-col gap-0.5">
                                        <div className="flex items-center gap-2">
                                            <span className="text-xs font-medium text-neutral-300 truncate max-w-[180px]">{task.title}</span>
                                            {task.autoRemediation && <Badge variant="outline" className="text-[9px] h-3.5 px-1 border-purple-500/30 text-purple-400">Auto</Badge>}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="text-[9px] text-neutral-500 font-mono">{task.chainId?.slice(0, 8)}...</span>
                                            {task.handoffTo && <span className="text-[9px] text-[hsl(var(--color-intent))]">→ {task.handoffTo}</span>}
                                        </div>
                                    </div>
                                    <Badge className={`text-[9px] h-4 px-1 ${
                                        task.status === 'done' ? 'bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20' :
                                        task.status === 'failed' ? 'bg-red-500/10 text-red-500 hover:bg-red-500/20' :
                                        'bg-neutral-800 text-neutral-400 hover:bg-neutral-700'
                                    }`}>
                                        {task.status}
                                    </Badge>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                {/* Recent Alerts */}
                <div>
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] uppercase tracking-wider text-neutral-500">Recent Alerts</span>
                    </div>
                    <div className="space-y-2">
                        {recentAlerts.length === 0 ? (
                            <div className="text-xs text-neutral-600 italic py-2">System nominal. No alerts.</div>
                        ) : (
                            recentAlerts.map(alert => (
                                <div key={alert.id} className="p-2 bg-neutral-950 rounded border-l-2 border-l-red-500/50 border-y border-r border-white/5">
                                    <div className="flex justify-between items-start">
                                        <span className="text-xs text-neutral-300">{alert.content}</span>
                                        <span className="text-[9px] text-neutral-600 font-mono ml-2 whitespace-nowrap">
                                            {format(new Date(alert.timestamp), 'HH:mm')}
                                        </span>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>

            {/* Actions Footer */}
            <div className="p-3 border-t border-white/10 bg-neutral-900 grid grid-cols-2 gap-2">
                <Button 
                    variant="outline" 
                    size="sm" 
                    className="h-8 text-[10px] border-white/10 hover:bg-white/5"
                    onClick={handleExport}
                >
                    <Download className="w-3 h-3 mr-2" />
                    Export Log
                </Button>
                <Button 
                    variant="default" 
                    size="sm" 
                    className="h-8 text-[10px] bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black"
                    onClick={() => simulateMutation.mutate()}
                    disabled={simulateMutation.isPending}
                >
                    <Play className="w-3 h-3 mr-2" />
                    {simulateMutation.isPending ? 'Simulating...' : 'Simulate Test'}
                </Button>
            </div>
        </div>
    );
}