import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Globe, Truck, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';
import { SystemStats, SystemLog } from '@/components/ui/design-system/SystemContent';
// import { Badge } from "@/components/ui/badge";

export const DistributionWidget = () => {
    const { data: orders = [] } = useQuery({
        queryKey: ['widget_distribution'],
        queryFn: () => base44.entities.Order.list({ sort: { order_date: -1 }, limit: 10 }),
        initialData: []
    });

    const issues = orders.filter(o => o.status === 'delayed' || o.status === 'problem');
    const active = orders.filter(o => o.status === 'processing' || o.status === 'shipped');

    return (
        <div className="flex flex-col h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <IntentText className="font-bold">DISTRIBUTION</IntentText>
                </div>
                {issues.length > 0 && (
                    <div className="flex items-center gap-1 text-[hsl(var(--color-warning))] text-[10px] font-bold animate-pulse">
                        <AlertTriangle className="w-3 h-3" /> {issues.length} ISSUES
                    </div>
                )}
            </div>

            <div className="p-4 border-b border-white/5">
                <SystemStats 
                    className="grid-cols-2"
                    stats={[
                        { label: "Active Shipments", value: active.length, icon: Truck, color: "text-[hsl(var(--color-execution))]" },
                        { label: "Avg Delivery", value: "2.4d", icon: Clock, color: "text-white" }
                    ]}
                />
            </div>
            
            <div className="flex-1 overflow-hidden p-2">
                {issues.length > 0 ? (
                    <SystemLog 
                        logs={issues.map(order => ({
                            type: 'ISSUE',
                            content: `Order #${order.id.slice(0,6)} delayed at distribution center`,
                            status: 'error',
                            timestamp: order.order_date
                        }))}
                        className="h-full"
                    />
                ) : (
                    active.length > 0 ? (
                        <SystemLog 
                            logs={active.map(order => ({
                                type: 'TRANSIT',
                                content: `Order #${order.id.slice(0,6)} to ${order.customer_name || 'Customer'}`,
                                status: 'active',
                                timestamp: order.order_date
                            }))}
                            className="h-full"
                        />
                    ) : (
                        <div className="p-4 text-center">
                            <CheckCircle2 className="w-8 h-8 text-[hsl(var(--color-execution))] mx-auto mb-2 opacity-50" />
                            <StateText className="text-xs opacity-50">All systems operational.</StateText>
                        </div>
                    )
                )}
            </div>
        </div>
    );
};