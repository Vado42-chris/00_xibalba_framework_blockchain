import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { MessageSquare, ArrowRight } from 'lucide-react';
import { IntentText } from '@/components/ui/design-system/SystemDesign';
import { SystemLog } from '@/components/ui/design-system/SystemContent';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { Badge } from "@/components/ui/badge";
import { createPageUrl } from '@/utils';

export const InboxWidget = () => {
    const { data: messages = [] } = useQuery({
        queryKey: ['widget_inbox'],
        queryFn: () => base44.entities.Log.list({ 
            sort: { timestamp: -1 }, 
            limit: 5,
            filter: { type: 'sms' } 
        }),
        initialData: []
    });

    return (
        <div className="flex flex-col h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-[hsl(var(--color-review))]" />
                    <IntentText className="font-bold">INBOX STREAM</IntentText>
                </div>
                <div className="px-2 py-0.5 rounded bg-[hsl(var(--color-review))]/20 text-[hsl(var(--color-review))] text-[10px] font-mono">
                    {messages.length} NEW
                </div>
            </div>
            
            <div className="flex-1 overflow-hidden p-2">
                <SystemLog 
                    logs={messages.map(msg => ({
                        id: msg.id,
                        type: msg.remote_identity || 'UNKNOWN',
                        status: 'active',
                        content: msg.content || 'No content',
                        timestamp: msg.timestamp
                    }))}
                    className="h-full"
                />
            </div>
            
            <div className="p-2 border-t border-white/5 bg-neutral-950/30">
                <Link to={createPageUrl('Communications')}>
                    <Button variant="ghost" className="w-full text-xs h-8 text-neutral-400 hover:text-white justify-between group">
                        View All Messages <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    </Button>
                </Link>
            </div>
        </div>
    );
};