import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Wallet, TrendingUp, Bitcoin } from 'lucide-react';
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
// import { Badge } from "@/components/ui/badge";

export const CryptoWalletWidget = () => {
    const { data: assets = [] } = useQuery({
        queryKey: ['widget_crypto'],
        queryFn: () => base44.entities.Asset.list({ filter: { type: 'crypto' } }),
        initialData: []
    });

    const totalValue = assets.reduce((acc, a) => acc + (a.value_usd || 0), 0);

    return (
        <div className="flex flex-col h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Bitcoin className="w-4 h-4 text-orange-500" />
                    <IntentText className="font-bold">BLOCKCHAIN ASSETS</IntentText>
                </div>
                <div className="font-mono text-xs text-orange-500">LIVE</div>
            </div>

            <div className="p-4 border-b border-white/5">
                <SystemStats 
                    className="grid-cols-1"
                    stats={[
                        { label: "Total Portfolio Value", value: `$${totalValue.toLocaleString()}`, icon: Wallet, color: "text-white" }
                    ]}
                />
            </div>
            
            <div className="flex-1 p-2 space-y-2 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
                {assets.length === 0 && (
                    <div className="text-center opacity-50 text-xs py-4">No crypto assets connected</div>
                )}
                {assets.map((asset, i) => (
                    <SystemCard
                        key={i}
                        title={asset.name}
                        subtitle={asset.symbol}
                        icon={Bitcoin}
                        status="active"
                        metric={`$${(asset.value_usd || 0).toLocaleString()}`}
                    >
                        <div className="text-[10px] text-green-500 font-mono flex items-center justify-end gap-1 mt-1">
                            <TrendingUp className="w-3 h-3" /> +2.4%
                        </div>
                    </SystemCard>
                ))}
            </div>
        </div>
    );
};