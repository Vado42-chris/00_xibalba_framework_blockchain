import React, { useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
// import { Badge } from "@/components/ui/badge";

export default function SystemStatusSimple() {
  const [status, setStatus] = useState('Loading...');

  useEffect(() => {
    // Implementing Frontend Team's First Task
    const checkHealth = async () => {
        try {
            const response = await base44.functions.invoke('health');
            setStatus(response.data.status);
        } catch (err) {
            setStatus('Error');
        }
    };
    
    checkHealth();
  }, []);

  return (
    <div className="p-4 bg-white/5 border border-white/10 rounded shadow backdrop-blur-sm">
      <h3 className="text-lg font-bold text-white mb-2">System Status</h3>
      <p className="text-neutral-300">Status: <strong className="text-emerald-400">{status}</strong></p>
    </div>
  );
}