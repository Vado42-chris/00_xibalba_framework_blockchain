import React, { useState, useEffect } from 'react';
import { RefreshCw, Lock } from 'lucide-react';
// import { Badge } from "@/components/ui/badge";
import { Explainable } from '@/components/ui/design-system/RosettaStone';
import { cn } from '@/lib/utils';
import { STATUS_CONFIG, HERO_STATUS } from '@/components/ui/design-system/StatusConfig';

export const SystemStatusHero = ({ 
    status = HERO_STATUS.NOMINAL, 
    message, // Optional override
    subMessage = "Network synchronization active. No anomalies detected.",
    metrics = [],
    uptime = "4h 12m",
    agentCount = 3,
    agentStatus = "aligned"
}) => {
    const [lastSync, setLastSync] = useState(new Date());

    useEffect(() => {
        const interval = setInterval(() => setLastSync(new Date()), 5000);
        return () => clearInterval(interval);
    }, []);

    // 1. Formalize Status (Gatekeeper)
    const config = STATUS_CONFIG[status] || STATUS_CONFIG[HERO_STATUS.NOMINAL];
    const Icon = config.icon;

    // Use config message if no override provided
    const displayMessage = message || config.message.technical;

    return (
        <div className={cn(
            "relative w-full overflow-hidden rounded-xl border-l-4 bg-neutral-900/50 backdrop-blur-sm p-6 md:p-8 transition-all duration-500",
            config.border, // Use the pre-defined border class from config
            // Fallback border color if config.border is missing or specific color needed
            status === HERO_STATUS.NOMINAL && "border-l-emerald-500",
            status === HERO_STATUS.WARNING && "border-l-amber-500",
            status === HERO_STATUS.CRITICAL && "border-l-red-500"
        )}>
            {/* Background Pattern */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none opacity-20" />
            
            {/* 3. Mobile Hero Pattern: Stack vertically on mobile, row on desktop */}
            <div className="relative z-10 flex flex-col md:flex-row gap-6 md:gap-8 items-start md:items-center justify-between">
                
                {/* Primary Narrative */}
                <div className="flex-1 space-y-3 md:space-y-4 w-full">
                    <div className="flex flex-wrap items-center gap-3 mb-2">
                        <div className={cn(
                            "flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase border",
                            config.bg,
                            config.color,
                            config.border
                        )}>
                            <div className={cn("w-2 h-2 rounded-full bg-current", config.pulse && "animate-pulse")} />
                            <Explainable 
                                technical={config.technical} 
                                human={config.human} 
                                generational={config.generational}
                            />
                        </div>
                        <div className="flex items-center gap-3 text-[10px] text-neutral-500 font-mono">
                            <div className="flex items-center gap-1">
                                <RefreshCw className="w-3 h-3" />
                                <span className="hidden sm:inline">Synced</span> 
                                <span>{lastSync.toLocaleTimeString()}</span>
                            </div>
                            <span className="text-neutral-700">|</span>
                            <span>{status === HERO_STATUS.NOMINAL ? `Nominal for ${uptime}` : `Duration: ${uptime}`}</span>
                        </div>
                    </div>

                    <h1 className="text-3xl md:text-5xl font-light tracking-tight text-white leading-tight">
                        <Explainable 
                            technical={displayMessage} 
                            human={config.message.human}
                        />
                    </h1>
                    
                    <p className="text-base md:text-lg text-neutral-400 max-w-2xl font-light leading-relaxed">
                        {subMessage}
                    </p>
                    
                    {/* Agent Collaboration Signal */}
                    <div className="flex items-center gap-2 pt-2 opacity-60 hover:opacity-100 transition-opacity cursor-help" title="Agent Consensus Protocol Active">
                        <div className="flex -space-x-1">
                            {[...Array(Math.min(agentCount, 3))].map((_, i) => (
                                <div key={i} className="w-4 h-4 rounded-full bg-neutral-800 border border-neutral-700 flex items-center justify-center">
                                    <div className={cn("w-1.5 h-1.5 rounded-full", status === HERO_STATUS.NOMINAL ? "bg-emerald-500/50" : "bg-amber-500/50")} />
                                </div>
                            ))}
                        </div>
                        <span className="text-xs text-neutral-500 font-mono">
                            {agentCount} agents monitoring · <span className={cn(status === HERO_STATUS.NOMINAL ? "text-emerald-500/80" : "text-amber-500/80")}>{agentStatus}</span>
                        </span>
                    </div>
                </div>

                {/* Trust Signals / Key Metrics - 3. Mobile Constraint: Collapses below narrative */}
                <div className="flex flex-row md:flex-col gap-2 md:gap-4 w-full md:w-auto md:min-w-[200px] overflow-x-auto pb-2 md:pb-0">
                    <div className="bg-black/20 rounded-lg p-3 md:p-4 border border-white/5 backdrop-blur-md min-w-[140px] flex-1 md:flex-none">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-[10px] uppercase tracking-widest text-neutral-500">Security</span>
                            <Lock className={cn("w-3 h-3", config.color)} />
                        </div>
                        <div className={cn("text-xl md:text-2xl font-mono", config.color)}>100%</div>
                        <div className={cn("text-[10px] mt-1 opacity-50", config.color)}>{config.trustSignal}</div>
                    </div>

                    {metrics.map((m, i) => (
                         <div key={i} className="bg-black/20 rounded-lg p-3 md:p-4 border border-white/5 backdrop-blur-md min-w-[140px] flex-1 md:flex-none">
                            <div className="flex items-center justify-between mb-2">
                                <span className="text-[10px] uppercase tracking-widest text-neutral-500">{m.label}</span>
                                {m.trend === 'up' && <Icon className={cn("w-3 h-3", config.color)} />}
                            </div>
                            <div className="text-xl md:text-2xl font-mono text-white">{m.value}</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};