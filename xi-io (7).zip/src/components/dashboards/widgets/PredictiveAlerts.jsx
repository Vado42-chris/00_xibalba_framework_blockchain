import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, AlertTriangle, CheckCircle2, TrendingUp, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function PredictiveAlerts() {
    const [alerts, setAlerts] = useState([]);
    const [systemScore, setSystemScore] = useState(98);

    useEffect(() => {
        // Simulate predictive analysis
        const mockAnalysis = [
            { id: 1, type: 'prediction', severity: 'medium', message: 'Traffic spike predicted at 14:00 UTC based on historical patterns.', time: 'In 2 hours' },
            { id: 2, type: 'maintenance', severity: 'low', message: 'Database optimization recommended. Query latency increasing slightly.', time: 'Next 24h' },
            { id: 3, type: 'security', severity: 'high', message: 'Unusual login attempts detected from Region EU-West.', time: 'Just now' }
        ];
        setAlerts(mockAnalysis);

        // In a real app, this would use base44.entities.Log.list() and analysis logic
    }, []);

    return (
        <Card className="bg-neutral-900/50 border-white/10 h-full">
            <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="text-lg font-bold text-white flex items-center gap-2">
                            <Zap className="w-5 h-5 text-yellow-500" />
                            Predictive Sentinel
                        </CardTitle>
                        <CardDescription>AI-driven system forecasts and alerts.</CardDescription>
                    </div>
                    <div className="flex flex-col items-end">
                        <span className="text-2xl font-bold text-white">{systemScore}%</span>
                        <span className="text-[10px] text-green-400 font-mono uppercase">Health Score</span>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                    <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0" />
                    <div>
                        <p className="text-sm font-medium text-white">System Nominal</p>
                        <p className="text-xs text-neutral-400">AI projection shows stable performance for next 12h.</p>
                    </div>
                </div>

                <div className="space-y-2">
                    <h4 className="text-xs font-medium text-neutral-500 uppercase tracking-wider px-1">Forecasted Events</h4>
                    {alerts.map(alert => (
                        <div key={alert.id} className="group flex items-start gap-3 p-3 rounded-lg bg-black/40 border border-white/5 hover:border-white/10 transition-colors">
                            {alert.severity === 'high' ? (
                                <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                            ) : alert.severity === 'medium' ? (
                                <TrendingUp className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                            ) : (
                                <Activity className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                            )}
                            <div className="flex-1 min-w-0">
                                <p className="text-sm text-neutral-200 leading-snug">{alert.message}</p>
                                <div className="flex items-center gap-2 mt-1.5">
                                    <Badge variant="outline" className="text-[9px] h-4 px-1 py-0 border-white/10 text-neutral-500">
                                        {alert.type}
                                    </Badge>
                                    <span className="text-[9px] text-neutral-600 font-mono">{alert.time}</span>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
}