import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Target, CheckCircle2 } from 'lucide-react';
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

export const BusinessPlanWidget = () => {
    const { data: goals = [] } = useQuery({
        queryKey: ['widget_goals'],
        queryFn: () => base44.entities.BusinessGoal.list(),
        initialData: []
    });

    return (
        <div className="flex flex-col h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    <IntentText className="font-bold">STRATEGY EXECUTION</IntentText>
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-2 scrollbar-thin scrollbar-thumb-white/10">
                {goals.length === 0 && (
                    <div className="text-center opacity-50 text-xs py-4">No active business goals</div>
                )}
                {goals.map((goal, i) => (
                    <SystemCard
                        key={i}
                        title={goal.title}
                        subtitle={goal.strategy_pillar?.toUpperCase()}
                        icon={Target}
                        status={goal.progress === 100 ? 'settled' : 'active'}
                        metric={`${goal.progress}%`}
                    >
                        <div className="mt-2">
                            <Progress value={goal.progress} className="h-1.5 bg-neutral-800" indicatorClassName="bg-[hsl(var(--color-execution))]" />
                            <div className="flex justify-between text-[10px] opacity-40 mt-1">
                                <span>Target: {goal.target_date}</span>
                            </div>
                        </div>
                    </SystemCard>
                ))}
            </div>
        </div>
    );
};