import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Activity, Wallet, Truck, MessageSquare } from 'lucide-react';
import { IntentText, ChartFrame } from '@/components/ui/design-system/SystemDesign';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { TimeGraph } from '@/components/ui/design-system/Infographics';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Badge } from "@/components/ui/badge";

export const PerformanceWidget = () => {
    const navigate = useNavigate();
    const { data: orders = [] } = useQuery({ queryKey: ['dash_ord'], queryFn: () => base44.entities.Order.list(), initialData: [] });
    const { data: assets = [] } = useQuery({ queryKey: ['dash_asset'], queryFn: () => base44.entities.Asset.list(), initialData: [] });
    const { data: messages = [] } = useQuery({ queryKey: ['dash_msg'], queryFn: () => base44.entities.Log.list(), initialData: [] });

    const totalRevenue = orders.reduce((acc, o) => acc + (o.total || 0), 0);
    const portfolioValue = assets.reduce((acc, a) => acc + (a.value_usd || 0), 0);
    const activeOrders = orders.filter(o => o.status !== 'completed').length;

    return (
        <div className="flex flex-col h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
             <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    <IntentText className="font-bold">PERFORMANCE AT A GLANCE</IntentText>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-neutral-500">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                    LIVE
                </div>
            </div>

            <div className="p-4 border-b border-white/5">
                <SystemStats 
                    className="grid-cols-1 md:grid-cols-3 gap-4"
                    stats={[
                        { 
                            label: "Total Assets", 
                            value: `$${portfolioValue.toLocaleString()}`, 
                            icon: Wallet, 
                            color: "text-green-500",
                            onClick: () => navigate(createPageUrl('Finance'))
                        },
                        { 
                            label: "Revenue (YTD)", 
                            value: `$${totalRevenue.toLocaleString()}`, 
                            icon: Truck, 
                            color: "text-[hsl(var(--color-intent))]",
                            onClick: () => navigate(createPageUrl('Commerce'))
                        },
                        { 
                            label: "Communications", 
                            value: `${messages.length} Unread`, 
                            icon: MessageSquare, 
                            color: "text-[hsl(var(--color-review))]",
                            onClick: () => navigate(createPageUrl('Communications'))
                        }
                    ]}
                />
            </div>

            <div className="p-4 bg-black/20 h-40">
                <ChartFrame label="Growth Velocity" metric="+12.5%" trend="Projected" category="execution">
                     <TimeGraph 
                        data={[
                            {t: 'Jan', v: 40}, {t: 'Feb', v: 55}, {t: 'Mar', v: 50}, 
                            {t: 'Apr', v: 75}, {t: 'May', v: 85}, {t: 'Jun', v: 100},
                            {t: 'Jul', v: 110}, {t: 'Aug', v: 105}, {t: 'Sep', v: 125}
                        ]}
                        dataKey="v"
                        category="execution"
                    />
                </ChartFrame>
            </div>
        </div>
    );
};