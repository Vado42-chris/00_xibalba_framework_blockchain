import React from 'react';
import RavensFeed from '@/components/activity/RavensFeed';
import { Badge } from "@/components/ui/badge";

export const GlobalFeedWidget = () => {
    return (
        <RavensFeed className="h-full border-0 rounded-none bg-transparent" />
    );
};