import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Wallet, Landmark, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';
import { SystemStats, SystemLog } from '@/components/ui/design-system/SystemContent';
import { Badge } from "@/components/ui/badge";

export const BankingWidget = () => {
    const { data: assets = [] } = useQuery({
        queryKey: ['widget_fiat'],
        queryFn: () => base44.entities.Asset.list({ filter: { type: 'fiat' } }),
        initialData: []
    });

    const totalFiat = assets.reduce((acc, a) => acc + (a.value_usd || 0), 0);

    return (
        <div className="flex flex-col h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Landmark className="w-4 h-4 text-emerald-500" />
                    <IntentText className="font-bold">BANKING & CASH FLOW</IntentText>
                </div>
            </div>

            <div className="p-4 border-b border-white/5">
                <SystemStats 
                    className="grid-cols-1"
                    stats={[
                        { label: "Total Liquidity", value: `$${totalFiat.toLocaleString()}`, icon: Wallet, color: "text-emerald-500" }
                    ]}
                />
            </div>
            
            <div className="flex-1 p-4 flex flex-col gap-4">
                 <SystemStats 
                    className="grid-cols-2"
                    stats={[
                        { label: "Inflow (MTD)", value: "$42,500", icon: ArrowUpRight, color: "text-emerald-500" },
                        { label: "Outflow (MTD)", value: "$18,200", icon: ArrowDownRight, color: "text-red-500" }
                    ]}
                 />
                 
                 <div className="flex-1 min-h-0 flex flex-col">
                    <StateText className="text-[10px] uppercase opacity-50 pl-1 mb-2">Recent Transactions</StateText>
                    <SystemLog 
                        logs={[1,2,3].map(i => ({
                            type: 'INCOME',
                            content: 'Stripe Payout: +$1,250.00',
                            status: 'nominal',
                            timestamp: new Date().toISOString()
                        }))}
                        className="flex-1"
                    />
                 </div>
            </div>
        </div>
    );
};