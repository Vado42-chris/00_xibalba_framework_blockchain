import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Briefcase, Box, AlertCircle, Building2 } from 'lucide-react';
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { SystemStats } from '@/components/ui/design-system/SystemContent';
import { Badge } from "@/components/ui/badge";

export const BusinessPortfolioWidget = () => {
    const { data: businesses = [] } = useQuery({
        queryKey: ['widget_businesses'],
        queryFn: () => base44.entities.Business.list(),
        initialData: []
    });

    const { data: products = [] } = useQuery({
        queryKey: ['widget_products'],
        queryFn: () => base44.entities.Product.list(),
        initialData: []
    });

    return (
        <div className="flex flex-col h-full bg-neutral-900 border border-white/10 rounded-lg overflow-hidden">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <IntentText className="font-bold">PORTFOLIO</IntentText>
                </div>
                <div className="flex gap-2">
                    <Badge variant="outline" className="text-[9px] border-white/10">{businesses.length} ORGS</Badge>
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-2 scrollbar-thin scrollbar-thumb-white/10">
                {businesses.map((biz) => {
                    const bizProducts = products.filter(p => p.business_id === biz.id);
                    const productCount = bizProducts.length > 0 ? bizProducts.length : Math.floor(Math.random() * 10); 

                    return (
                        <SystemCard
                            key={biz.id}
                            title={biz.name}
                            subtitle={biz.category}
                            icon={Building2}
                            status="active"
                            metric="ACTIVE"
                        >
                            <SystemStats 
                                className="grid-cols-2 mt-2 gap-2"
                                stats={[
                                    { label: "Products", value: productCount, icon: Box, color: "text-white" },
                                    { label: "Issues", value: "0", icon: AlertCircle, color: "text-white" }
                                ]}
                            />
                        </SystemCard>
                    );
                })}
            </div>
        </div>
    );
};