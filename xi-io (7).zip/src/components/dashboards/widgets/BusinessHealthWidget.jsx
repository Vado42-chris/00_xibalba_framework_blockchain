import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, TrendingUp, Users, DollarSign, Activity } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

export default function BusinessHealthWidget() {
    const { data: orders = [] } = useQuery({
        queryKey: ['orders'],
        queryFn: () => base44.entities.Order.list(),
        initialData: []
    });

    const { data: customers = [] } = useQuery({
        queryKey: ['customers'],
        queryFn: () => base44.entities.Customer.list(),
        initialData: []
    });

    const totalRevenue = orders.reduce((acc, order) => acc + (order.total || 0), 0);
    const revenueGrowth = 12.5; // Placeholder for growth calculation

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {/* Revenue Card */}
            <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-neutral-400">Total Revenue</CardTitle>
                    <DollarSign className="h-4 w-4 text-emerald-500" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-white">${totalRevenue.toLocaleString()}</div>
                    <p className="text-xs text-emerald-500 flex items-center mt-1">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        +{revenueGrowth}% from last month
                    </p>
                </CardContent>
            </Card>

            {/* Active Users Card */}
            <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-neutral-400">Active Customers</CardTitle>
                    <Users className="h-4 w-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-white">{customers.length.toLocaleString()}</div>
                    <p className="text-xs text-neutral-500 mt-1">
                        Total Registered
                    </p>
                </CardContent>
            </Card>

            {/* System Health Card */}
            <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-colors">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-neutral-400">Platform Health</CardTitle>
                    <Activity className="h-4 w-4 text-rose-500" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-white">99.9%</div>
                    <p className="text-xs text-neutral-500 mt-1">
                        All systems operational
                    </p>
                </CardContent>
            </Card>

            {/* Action Card */}
            <Card className="bg-[hsl(var(--color-intent))] border-none">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-bold text-black">Quick Action</CardTitle>
                    <ArrowUpRight className="h-4 w-4 text-black" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold text-black">Grow Now</div>
                    <Button variant="ghost" size="sm" className="mt-2 w-full bg-black/10 hover:bg-black/20 text-black border-none justify-start p-0 px-2 h-7">
                        Launch Campaign →
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}