import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { cn } from "@/lib/utils";

export default function SystemStatusWidget({ className }) {
    const [status, setStatus] = useState('Loading...');
    const [details, setDetails] = useState(null);
    const [lastChecked, setLastChecked] = useState(null);

    const checkHealth = async () => {
        try {
            const response = await base44.functions.invoke('systemHealth');
            setStatus(response.data.status); // Should be 'OK'
            setDetails(response.data);
            setLastChecked(new Date(response.data.timestamp).toLocaleTimeString());
        } catch (error) {
            setStatus('Error');
        }
    };

    useEffect(() => {
        checkHealth();
        // Poll every 30 seconds
        const interval = setInterval(checkHealth, 30000);
        return () => clearInterval(interval);
    }, []);

    return (
        <Card className={cn("bg-black/40 border-white/10 backdrop-blur-sm", className)}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-neutral-400">System Heartbeat</CardTitle>
                <Activity className={cn("h-4 w-4", status === 'OK' ? "text-emerald-500" : "text-neutral-500")} />
            </CardHeader>
            <CardContent>
                <div className="flex items-center gap-3">
                    {status === 'Loading...' ? (
                        <Loader2 className="h-6 w-6 text-neutral-500 animate-spin" />
                    ) : status === 'OK' ? (
                        <CheckCircle2 className="h-6 w-6 text-emerald-500" />
                    ) : (
                        <XCircle className="h-6 w-6 text-red-500" />
                    )}
                    <div>
                        <div className="text-2xl font-bold tracking-tight text-white">
                            {status === 'OK' ? 'ONLINE' : status}
                        </div>
                        <p className="text-xs text-neutral-500 font-mono">
                            {lastChecked ? `LAST PING: ${lastChecked}` : 'CONNECTING...'}
                        </p>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}