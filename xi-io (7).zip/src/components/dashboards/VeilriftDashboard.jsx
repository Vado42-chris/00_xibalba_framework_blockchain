import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText, SemanticDot, Layer } from '@/components/ui/design-system/SystemDesign';
import { SystemMonitor } from '@/components/agents/SystemMonitor';
import { InsightEngine } from '@/components/agents/InsightEngine';
import { Activity, Shield, Code, Terminal, Zap, Cpu } from 'lucide-react';
import { Button } from "@/components/ui/button";

export default function VeilriftDashboard() {
    return (
        <QuadrantGrid>
            <Quadrant type="orientation">
                <div className="flex items-center gap-3 mb-6">
                    <Terminal className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                    <div>
                        <OrientingText className="tracking-widest font-bold">VEILRIFT</OrientingText>
                        <IntentText className="text-lg font-light">Development Operations</IntentText>
                    </div>
                </div>
                
                <div className="space-y-4">
                    <SystemMonitor domainFamily="Veilrift" />
                    
                    <Layer level="orientation" className="p-4 border-l-2 border-l-[hsl(var(--color-intent))]">
                        <OrientingText>ACTIVE DEPLOYMENTS</OrientingText>
                        <div className="grid grid-cols-2 gap-4 mt-2">
                            <div>
                                <StateText className="text-2xl font-mono text-white">4</StateText>
                                <StateText className="opacity-50 text-[10px]">Microservices</StateText>
                            </div>
                            <div>
                                <StateText className="text-2xl font-mono text-white">12</StateText>
                                <StateText className="opacity-50 text-[10px]">Edge Nodes</StateText>
                            </div>
                        </div>
                    </Layer>
                </div>
            </Quadrant>

            <Quadrant type="intent" dominance="dominant" className="overflow-hidden flex flex-col">
                <div className="flex justify-between items-center mb-6">
                    <OrientingText>ENVIRONMENT CONTROL</OrientingText>
                    <div className="flex gap-2">
                        <Link to={createPageUrl('Audit')}>
                            <Button size="sm" variant="outline" className="h-7 text-xs border-white/10 text-neutral-400">View Logs</Button>
                        </Link>
                        <Link to={createPageUrl('Automation')}>
                            <Button size="sm" className="h-7 text-xs bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90">Deploy</Button>
                        </Link>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 overflow-y-auto">
                    <div className="p-4 bg-black/40 rounded border border-white/10 backdrop-blur-md">
                        <div className="flex items-center gap-2 mb-4">
                            <Code className="w-4 h-4 text-neutral-500" />
                            <IntentText>API Gateway</IntentText>
                        </div>
                        <div className="font-mono text-xs text-neutral-400 space-y-1">
                            <div className="flex justify-between"><span>Status:</span> <span className="text-emerald-500">Online</span></div>
                            <div className="flex justify-between"><span>Latency:</span> <span>24ms</span></div>
                            <div className="flex justify-between"><span>Requests:</span> <span>1.2k/s</span></div>
                        </div>
                    </div>
                    
                    <div className="p-4 bg-black/40 rounded border border-white/10 backdrop-blur-md">
                        <div className="flex items-center gap-2 mb-4">
                            <Cpu className="w-4 h-4 text-neutral-500" />
                            <IntentText>Compute Cluster</IntentText>
                        </div>
                        <div className="font-mono text-xs text-neutral-400 space-y-1">
                            <div className="flex justify-between"><span>Load:</span> <span className="text-yellow-500">78%</span></div>
                            <div className="flex justify-between"><span>Pods:</span> <span>12/16</span></div>
                            <div className="flex justify-between"><span>Memory:</span> <span>64GB</span></div>
                        </div>
                    </div>
                </div>
            </Quadrant>

            <Quadrant type="state" className="overflow-y-auto">
                <InsightEngine context="dev" />
                
                <div className="mt-6 space-y-2">
                    <OrientingText>RECENT COMMITS</OrientingText>
                    {[1,2,3].map(i => (
                        <div key={i} className="flex items-center gap-3 p-2 border-b border-white/5 last:border-0">
                            <div className="font-mono text-[10px] text-[hsl(var(--color-execution))]">a4f2b{i}</div>
                            <div className="flex-1 text-xs text-neutral-400 truncate">refactor: optimize grid rendering logic</div>
                            <div className="text-[10px] text-neutral-600">2h ago</div>
                        </div>
                    ))}
                </div>
            </Quadrant>
        </QuadrantGrid>
    );
}