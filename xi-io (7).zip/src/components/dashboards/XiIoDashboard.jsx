import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
  Activity, Users, BarChart3, Shield, LayoutTemplate,
  CheckCircle2, Plus, Brain, TrendingUp, Inbox as InboxIcon, Calendar
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  QuadrantGrid, Quadrant, 
  OrientingText, IntentText, StateText
} from '@/components/ui/design-system/SystemDesign';
import { SystemStatusHero } from './widgets/SystemStatusHero';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { GuideBox } from '@/components/ui/GuideBox';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SystemMonitor } from '@/components/agents/SystemMonitor';
import { InsightEngine } from '@/components/agents/InsightEngine';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AddonGate } from '@/components/integrations/AddonGate';
// Imports consolidated above

// Widgets
import { InboxWidget } from './widgets/InboxWidget';
import { BusinessPortfolioWidget } from './widgets/BusinessPortfolioWidget';
import { DistributionWidget } from './widgets/DistributionWidget';
import { CryptoWalletWidget } from './widgets/CryptoWalletWidget';
import { BankingWidget } from './widgets/BankingWidget';
import { BusinessPlanWidget } from './widgets/BusinessPlanWidget';
import { PerformanceWidget } from './widgets/PerformanceWidget';
import { GlobalFeedWidget } from './widgets/GlobalFeedWidget';

// Addon Widgets
import NeuroLinkViz from '@/components/addons/official/NeuroLinkViz';
import LedgerQuant from '@/components/addons/official/LedgerQuant';
import PipelineWidget from '@/components/addons/official/PipelineWidget';
import NexusWidget from '@/components/addons/official/NexusWidget';
import ChronosWidget from '@/components/addons/official/ChronosWidget';

// Custom Builder
import { DashboardBuilderModal } from './DashboardBuilderModal';

// Widget Map for Dynamic Rendering
const WIDGET_MAP = {
    'PerformanceWidget': PerformanceWidget,
    'GlobalFeedWidget': GlobalFeedWidget,
    'InboxWidget': InboxWidget,
    'BusinessPortfolioWidget': BusinessPortfolioWidget,
    'DistributionWidget': DistributionWidget,
    'BankingWidget': BankingWidget,
    'CryptoWalletWidget': CryptoWalletWidget,
    'BusinessPlanWidget': BusinessPlanWidget,
    'InsightEngine': ({ context }) => <InsightEngine context={context || "general"} />,
    'SystemMonitor': SystemMonitor,
    'NeuroLinkViz': NeuroLinkViz,
    'LedgerQuant': LedgerQuant,
    'PipelineWidget': PipelineWidget,
    'NexusWidget': NexusWidget,
    'ChronosWidget': ChronosWidget
};

export default function XiIoDashboard() {
  const [currentView, setCurrentView] = useState('executive');
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const { data: customers = [] } = useQuery({
    queryKey: ['dashboard_customers'],
    queryFn: () => base44.entities.Customer.list(),
    initialData: []
  });

  const { data: customLayouts = [] } = useQuery({
    queryKey: ['dashboard_layouts'],
    queryFn: () => base44.entities.DashboardLayout.list(),
    initialData: []
  });

  // Dynamic Widget Renderer
  const renderWidgets = (widgetIds) => {
    if (!widgetIds || widgetIds.length === 0) return null;
    return (
        <div className={`flex flex-col gap-4 h-full ${widgetIds.length > 1 ? 'overflow-y-auto' : ''}`}>
            {widgetIds.map((id, index) => {
                const Widget = WIDGET_MAP[id];
                return Widget ? (
                    <div key={index} className="flex-1 min-h-0">
                        <Widget />
                    </div>
                ) : null;
            })}
        </div>
    );
  };

  // View Configuration
  const renderView = () => {
    // Custom views rendering
    const customLayout = customLayouts.find(l => l.id === currentView);
    if (customLayout) {
        return (
            <>
                <Quadrant type="intent" step="2" title="Primary" dominance="dominant" className="p-0 border-none bg-transparent">
                    {renderWidgets(customLayout.q2_widgets)}
                </Quadrant>
                <Quadrant type="state" step="3" title="Secondary" className="p-0 border-none bg-transparent">
                    {renderWidgets(customLayout.q3_widgets)}
                </Quadrant>
                <Quadrant type="intent" step="4" title="Tertiary" dominance="supporting" className="p-0 border-none bg-transparent">
                    {renderWidgets(customLayout.q4_widgets)}
                </Quadrant>
            </>
        );
    }


    // Default Views
    switch(currentView) {
        case 'executive':
            return (
                <>
                    {/* Q2: Top Right - Performance */}
                    <Quadrant type="intent" step="2" title="Executive" dominance="dominant" className="p-0 border-none bg-transparent flex flex-col gap-6">
                        <SystemStatusHero 
                            status="nominal" 
                            message="Empire Nominal" 
                            subMessage="All automated systems are functioning within expected parameters. Revenue streams are active and secure."
                            uptime="12d 4h"
                            agentCount={4}
                            agentStatus="consensus verified"
                        />
                        <div className="flex-1 min-h-0">
                            <PerformanceWidget />
                        </div>
                    </Quadrant>
                    {/* Q3: Bottom Left - Global Feed */}
                    <Quadrant type="state" step="3" title="Feed" className="p-0 border-none bg-transparent">
                        <GlobalFeedWidget />
                    </Quadrant>
                    {/* Q4: Bottom Right - Insights & Strategy */}
                    <Quadrant type="intent" step="4" title="Strategy" dominance="supporting" className="p-0 border-none bg-transparent flex flex-col gap-4">
                        <div className="h-1/2">
                            <BusinessPlanWidget />
                        </div>
                        <div className="h-1/2 relative overflow-hidden rounded-lg border border-white/5">
                            <AddonGate
                                addonName="Neuro-Link Analytics"
                                title="Neural Viz"
                                icon={Brain}
                                fallback={<InsightEngine context="general" />}
                            >
                                <NeuroLinkViz />
                            </AddonGate>
                        </div>
                    </Quadrant>
                </>
            );
        case 'financial':
            return (
                <>
                    <Quadrant type="intent" step="2" title="Treasury" dominance="dominant" className="p-0 border-none bg-transparent flex flex-col gap-6">
                        <SystemStatusHero 
                            status="nominal"
                            message="Financial Overview"
                            subMessage="Liquidity pools stable. Transaction volume within expected range."
                            metrics={[
                                { label: 'Liquidity', value: '$2.4M', trend: 'up' },
                                { label: 'Burn Rate', value: '-4%', trend: 'down' }
                            ]}
                        />
                        <div className="flex-1 min-h-0">
                            <BankingWidget />
                        </div>
                    </Quadrant>
                    <Quadrant type="state" step="3" title="Assets" className="p-0 border-none bg-transparent">
                        <CryptoWalletWidget />
                    </Quadrant>
                    <Quadrant type="intent" step="4" title="Analysis" dominance="supporting" className="p-0 border-none bg-transparent relative overflow-hidden rounded-lg">
                        <AddonGate
                            addonName="Ledger Quant"
                            title="Quant Analysis"
                            icon={TrendingUp}
                            fallback={<PerformanceWidget />}
                        >
                            <LedgerQuant />
                        </AddonGate>
                    </Quadrant>
                </>
            );
         case 'operational':
            return (
                <>
                    <Quadrant type="intent" dominance="dominant" className="p-0 border-none bg-transparent flex flex-col gap-6">
                         <SystemStatusHero 
                            status="nominal"
                            message="Operations Center"
                            subMessage="Supply chain active. Inventory levels optimized."
                            metrics={[
                                { label: 'Orders', value: '142', trend: 'up' },
                                { label: 'Fulfillment', value: '98%', trend: 'stable' }
                            ]}
                        />
                        <div className="flex-1 min-h-0 flex flex-col gap-4">
                            <div className="h-1/2"><BusinessPortfolioWidget /></div>
                            <div className="h-1/2"><DistributionWidget /></div>
                        </div>
                    </Quadrant>
                    <Quadrant type="state" className="p-0 border-none bg-transparent relative overflow-hidden rounded-lg">
                         <AddonGate
                            addonName="Pipeline Hologram"
                            title="CRM Pipeline"
                            icon={Users}
                            fallback={<InboxWidget />}
                         >
                            <PipelineWidget className="bg-transparent" />
                         </AddonGate>
                    </Quadrant>
                    <Quadrant type="intent" dominance="supporting" className="p-0 border-none bg-transparent">
                        <GlobalFeedWidget />
                    </Quadrant>
                </>
            );
        case 'work':
            return (
                <>
                    {/* Work: Focus on execution, inbox, and portfolio */}
                    <Quadrant type="intent" dominance="dominant" className="p-0 border-none bg-transparent flex flex-col gap-4">
                         <div className="h-2/3 relative overflow-hidden rounded-lg border border-white/5">
                            <AddonGate
                                addonName="Nexus Comms"
                                title="Unified Inbox"
                                icon={InboxIcon}
                                fallback={<InboxWidget />}
                            >
                                <NexusWidget />
                            </AddonGate>
                         </div>
                         <div className="h-1/3"><PerformanceWidget /></div>
                    </Quadrant>
                    <Quadrant type="state" className="p-0 border-none bg-transparent">
                        <BusinessPortfolioWidget />
                    </Quadrant>
                    <Quadrant type="intent" dominance="supporting" className="p-0 border-none bg-transparent">
                        <BusinessPlanWidget />
                    </Quadrant>
                </>
            );
        case 'home':
            return (
                <>
                    {/* Home: Focus on personal finance, lifestyle feed, and crypto */}
                    <Quadrant type="intent" dominance="dominant" className="p-0 border-none bg-transparent flex flex-col gap-6">
                         <SystemStatusHero 
                            status="nominal" 
                            message="Welcome Home" 
                            subMessage="Domestic systems online. Energy usage is optimal. No security alerts."
                            metrics={[
                                { label: 'Air Quality', value: '98 AQI', trend: 'stable' },
                                { label: 'Power', value: '1.2 kW', trend: 'down' }
                            ]}
                         />
                         <div className="flex-1 min-h-0 relative overflow-hidden rounded-lg border border-white/5">
                            <AddonGate
                                addonName="Chronos Timekeeper"
                                title="Smart Calendar"
                                icon={Calendar}
                                fallback={<GlobalFeedWidget />}
                            >
                                <ChronosWidget />
                            </AddonGate>
                         </div>
                    </Quadrant>
                    <Quadrant type="state" className="p-0 border-none bg-transparent flex flex-col gap-4">
                        <div className="h-1/2"><BankingWidget /></div>
                        <div className="h-1/2"><CryptoWalletWidget /></div>
                    </Quadrant>
                    <Quadrant type="intent" dominance="supporting" className="p-0 border-none bg-transparent">
                        <InsightEngine context="personal" />
                    </Quadrant>
                </>
            );
        default:
            return null;
    }
  };

  return (
      <QuadrantGrid>
        {/* Q1: ORIENTATION - Global Status & Navigation (Fixed) */}
        <Quadrant type="orientation" step="1" title="Command">
           <div className="flex flex-col h-full justify-between">
              <div>
                 <div className="flex items-center justify-between mb-6">
                     <div className="flex items-center gap-3">
                        <Shield className="w-6 h-6 text-[hsl(var(--color-execution))]" />
                        <div>
                            <OrientingText className="tracking-[0.2em] text-[10px] uppercase opacity-70">XI-IO EMPIRE</OrientingText>
                            <IntentText className="text-xl font-light tracking-tight">Enterprise Control</IntentText>
                        </div>
                     </div>
                     <div className="flex items-center gap-2">
                        <div className="w-32">
                            <Select value={currentView} onValueChange={setCurrentView}>
                                <SelectTrigger className="h-7 text-xs bg-neutral-900 border-white/10">
                                    <SelectValue placeholder="View" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="executive">Executive</SelectItem>
                                    <SelectItem value="financial">Financial</SelectItem>
                                    <SelectItem value="operational">Operational</SelectItem>
                                    <SelectItem value="work">Work</SelectItem>
                                    <SelectItem value="home">Home</SelectItem>
                                    {customLayouts.length > 0 && <div className="h-px bg-white/10 my-1" />}
                                    {customLayouts.map(layout => (
                                        <SelectItem key={layout.id} value={layout.id}>{layout.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <button 
                            onClick={() => setIsBuilderOpen(true)}
                            className="h-7 px-2 rounded bg-neutral-900 border border-white/10 hover:bg-white/5 text-[10px] text-[hsl(var(--color-intent))] transition-colors flex items-center gap-1"
                        >
                            <Plus className="w-3 h-3" /> New Layout
                        </button>
                     </div>
                 </div>

                 <div className="space-y-4">
                    <GuideBox title="Welcome to Base44" defaultOpen={false}>
                        <p className="mb-2">
                            This is your Command Center. From here, you can monitor your entire digital empire.
                        </p>
                        <ul className="list-disc list-inside space-y-1 opacity-80">
                            <li><strong>Orientation</strong>: (Top Left) System status and quick actions.</li>
                            <li><strong>Intent</strong>: (Top Right) High-level metrics and goals.</li>
                            <li><strong>Feed</strong>: (Bottom Left) Real-time event stream.</li>
                        </ul>
                    </GuideBox>

                    <SystemMonitor domainFamily="XI-IO" />

                    <div className="grid grid-cols-2 gap-2">
                        <SystemCard
                            title="Intelligence"
                            subtitle="99.9% Uptime"
                            icon={BarChart3}
                            status="active"
                            metric=""
                            className="p-3"
                            onClick={() => navigate(createPageUrl('Intelligence'))}
                        />
                        <SystemCard
                            title="CRM"
                            subtitle={`${customers.length} Contacts`}
                            icon={Users}
                            status="active"
                            metric=""
                            className="p-3"
                            onClick={() => navigate(createPageUrl('CRM'))}
                        />
                    </div>
                 </div>
              </div>

              <div className="pt-6 border-t border-white/5">
                 <div className="flex justify-between items-center mb-2">
                    <OrientingText>QUICK ACTIONS</OrientingText>
                    {currentView !== 'executive' && currentView !== 'financial' && currentView !== 'operational' && (
                        <span className="text-[9px] text-[hsl(var(--color-intent))] opacity-70">Custom Layout Active</span>
                    )}
                 </div>
                 <div className="flex gap-2">
                    <Link to={createPageUrl('WorkRoom')}>
                        <Button size="sm" className="bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90 text-xs h-8 w-full">
                            <Plus className="w-3 h-3 mr-1" /> New Project
                        </Button>
                    </Link>
                 </div>
              </div>
           </div>
        </Quadrant>

        {renderView()}

        <DashboardBuilderModal 
            open={isBuilderOpen} 
            onOpenChange={setIsBuilderOpen}
            onLayoutCreated={() => queryClient.invalidateQueries(['dashboard_layouts'])}
        />
      </QuadrantGrid>
  );
}