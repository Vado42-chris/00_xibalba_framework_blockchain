import React from 'react';
import { 
    Shield, Crown, TrendingUp, CheckCircle2, 
    MessageSquare, ArrowRight, Activity, Calendar
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { QuadrantGrid, Quadrant, OrientingText, IntentText, StateText } from '@/components/ui/design-system/SystemDesign';
import { SystemStatusHero } from '@/components/dashboards/widgets/SystemStatusHero';
import { SystemCard } from '@/components/ui/design-system/SystemComponents';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';

export default function ConciergeDashboard() {
    // 1. Fetch System Health
    const { data: health } = useQuery({
        queryKey: ['concierge_health'],
        queryFn: async () => {
            const res = await base44.functions.invoke('concierge', { url: '/api/v1/concierge/status', method: 'GET' });
            return res.data?.data || { system_status: 'nominal', uptime_percentage: '100', active_workflows: 0 };
        }
    });

    // 2. Fetch Interventions
    const { data: interventions = [] } = useQuery({
        queryKey: ['concierge_interventions'],
        queryFn: async () => {
            const res = await base44.functions.invoke('concierge', { url: '/api/v1/concierge/interventions', method: 'GET' });
            return res.data?.data || [];
        }
    });

    // Mock calculations for ROI (in real app, this would be computed backend)
    const hoursSaved = interventions.reduce((acc, curr) => acc + (curr.impact_score || 0), 0) * 2; // Mock multiplier
    const taskCount = health?.active_workflows * 124; // Mock daily multiplier

    return (
        <QuadrantGrid>
            {/* Q1: ORIENTATION - SYSTEM HEALTH */}
            <Quadrant type="orientation">
                <div className="flex flex-col h-full justify-between">
                    <div>
                        <div className="flex items-center gap-3 mb-6">
                            <Crown className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                            <div>
                                <OrientingText className="tracking-[0.2em] text-[10px] uppercase opacity-70">VALHALLA CONCIERGE</OrientingText>
                                <IntentText className="text-xl font-light tracking-tight">Managed Sovereign Cloud</IntentText>
                            </div>
                        </div>

                        <SystemStatusHero 
                            status={health?.system_status || 'nominal'}
                            message={health?.system_status === 'degraded' ? 'Optimization In Progress' : 'All Systems Optimal'}
                            subMessage="Your digital empire is fully operational. No user intervention required."
                            uptime={`${health?.uptime_percentage || 99.9}%`}
                            agentStatus="managed"
                        />
                    </div>

                    <div className="mt-6 p-4 rounded bg-[hsl(var(--color-intent))]/10 border border-[hsl(var(--color-intent))]/20">
                        <div className="flex items-start gap-3">
                            <div className="w-10 h-10 rounded-full bg-[hsl(var(--color-intent))] flex items-center justify-center shrink-0">
                                <Shield className="w-5 h-5 text-black" />
                            </div>
                            <div>
                                <h4 className="text-sm font-bold text-white mb-1">Your Architect is Active</h4>
                                <p className="text-xs text-neutral-400 mb-3">
                                    Last check-in: 2 hours ago. 
                                    <br/>Running routine optimization protocols.
                                </p>
                                <Button size="sm" className="h-7 text-xs bg-white text-black hover:bg-neutral-200">
                                    <MessageSquare className="w-3 h-3 mr-2" /> Message Architect
                                </Button>
                            </div>
                        </div>
                    </div>
                </div>
            </Quadrant>

            {/* Q2: INTENT - VALUE & ROI */}
            <Quadrant type="intent" dominance="dominant" className="p-0 border-none bg-transparent">
                <div className="h-full flex flex-col p-6 overflow-y-auto">
                    <div className="flex justify-between items-center mb-6">
                        <OrientingText>PERFORMANCE REPORT</OrientingText>
                        <StateText className="text-[10px]">This Month</StateText>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mb-6">
                        <div className="p-4 bg-black/40 rounded border border-white/10 backdrop-blur-md">
                            <div className="flex items-center gap-2 mb-2">
                                <TrendingUp className="w-4 h-4 text-emerald-500" />
                                <span className="text-xs text-neutral-400">Hours Saved</span>
                            </div>
                            <div className="text-3xl font-light text-white">{hoursSaved.toFixed(1)}h</div>
                            <div className="text-[10px] text-emerald-500">+12% vs last month</div>
                        </div>
                        <div className="p-4 bg-black/40 rounded border border-white/10 backdrop-blur-md">
                            <div className="flex items-center gap-2 mb-2">
                                <Activity className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                <span className="text-xs text-neutral-400">Tasks Automated</span>
                            </div>
                            <div className="text-3xl font-light text-white">{taskCount.toLocaleString()}</div>
                            <div className="text-[10px] text-[hsl(var(--color-intent))]">100% Success Rate</div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <OrientingText>ACTIVE WORKFLOWS ({health?.active_workflows})</OrientingText>
                        <SystemCard 
                            title="Sales Pipeline Sync"
                            subtitle="HubSpot ↔ Slack ↔ Airtable"
                            status="active"
                            icon={Activity}
                            metric="Real-time"
                            className="bg-neutral-900/50"
                        />
                        {/* Placeholder logic for now, in real app map through health.workflows */}
                        <SystemCard 
                            title="Automated Invoicing"
                            subtitle="Stripe → Xero → Email"
                            status="active"
                            icon={CheckCircle2}
                            metric="Daily"
                            className="bg-neutral-900/50"
                        />
                    </div>
                </div>
            </Quadrant>

            {/* Q3: STATE - RECENT ACTIONS (TRANSPARENCY) */}
            <Quadrant type="state" className="overflow-y-auto">
                <div className="flex justify-between items-center mb-4">
                    <OrientingText>DIVINE INTERVENTIONS</OrientingText>
                    <StateText className="text-[10px]">Log</StateText>
                </div>

                <div className="space-y-4 relative">
                    <div className="absolute top-2 bottom-2 left-2 w-px bg-white/5" />
                    
                    {interventions.length === 0 ? (
                        <div className="pl-6 text-xs text-neutral-500 italic">No interventions recorded yet.</div>
                    ) : (
                        interventions.map((log, i) => (
                            <div key={i} className="relative pl-6">
                                <div className={`absolute left-0 top-1.5 w-4 h-4 rounded-full border-2 border-black ${
                                    log.category === 'optimization' ? 'bg-[hsl(var(--color-intent))]' : 'bg-neutral-800'
                                }`} />
                                <div className="flex justify-between items-start">
                                    <h5 className="text-sm font-medium text-white">{log.title}</h5>
                                    <span className="text-[10px] text-neutral-500">
                                        {format(new Date(log.created_date || new Date()), 'MMM d, h:mm a')}
                                    </span>
                                </div>
                                <p className="text-xs text-neutral-400 mt-1">{log.summary}</p>
                            </div>
                        ))
                    )}
                </div>
            </Quadrant>

            {/* Q4: STRATEGY - UPCOMING */}
            <Quadrant type="intent" dominance="supporting">
                <div className="flex flex-col h-full">
                    <OrientingText className="mb-4">NEXT STEPS</OrientingText>
                    
                    <div className="flex-1 space-y-3">
                         <div className="p-3 rounded border border-dashed border-white/10 bg-white/5">
                            <div className="flex items-center gap-2 mb-1">
                                <Calendar className="w-3 h-3 text-neutral-400" />
                                <span className="text-xs font-bold text-white">Q3 Strategy Call</span>
                            </div>
                            <p className="text-[10px] text-neutral-500">Scheduled for Oct 15th with Senior Architect.</p>
                         </div>
                         
                         <div className="p-3 rounded border border-dashed border-white/10 bg-white/5 opacity-50">
                            <div className="flex items-center gap-2 mb-1">
                                <Crown className="w-3 h-3 text-neutral-400" />
                                <span className="text-xs font-bold text-white">AI Agent Deployment</span>
                            </div>
                            <p className="text-[10px] text-neutral-500">Pending approval of data policy.</p>
                         </div>
                    </div>

                    <Button variant="outline" className="w-full mt-4 border-white/10 hover:bg-white/5 text-xs">
                        View Roadmap <ArrowRight className="w-3 h-3 ml-2" />
                    </Button>
                </div>
            </Quadrant>
        </QuadrantGrid>
    );
}