# Instructions for Base44 Team

**To:** Base44 Engineering / AI Agent  
**From:** Project Lead  
**Subject:** Permanent Fix for Badge ReferenceError

## The Issue
The application crashes with `ReferenceError: Badge is not defined` because components use the `<Badge />` UI element without importing it.

## The Solution
Every file containing `<Badge` **MUST** include this import:
`import { Badge } from "@/components/ui/badge";`

## Priority File List
Check these files immediately:
1. `pages/Dashboard.js` (CRITICAL)
2. `components/home/GatewayLanding.js`
3. `components/dashboards/XiIoDashboard.js`
4. `layout/Layout.js`
5. `components/ui/design-system/DashboardLayout.js`
6. Any file in `components/dashboards/widgets/`

## Execution Steps
1. Search codebase for string `<Badge`
2. For each result, verify `import { Badge }` exists at the top.
3. If missing, add: `import { Badge } from "@/components/ui/badge";`
4. Save and Deploy.

## Verification
- Load the app.
- Check Browser Console for errors.
- Ensure all dashboards render.