/**
 * BASE44 AUTOMATED BADGE FIX SCRIPT
 * 
 * This script is designed to run in a Node.js environment to automatically
 * find and fix missing Badge imports in a Base44 project.
 * 
 * Usage: node BASE44_AUTOMATED_BADGE_FIX.js
 */

const fs = require('fs');
const path = require('path');

// Configuration
const TARGET_DIRS = ['pages', 'components', 'layout'];
const SEARCH_STRING = '<Badge';
const IMPORT_STATEMENT = 'import { Badge } from "@/components/ui/badge";';

// Stats
let filesScanned = 0;
let filesFixed = 0;
let errors = 0;

function walkDir(dir, callback) {
    if (!fs.existsSync(dir)) return;
    
    fs.readdirSync(dir).forEach(f => {
        let dirPath = path.join(dir, f);
        let isDirectory = fs.statSync(dirPath).isDirectory();
        if (isDirectory) {
            walkDir(dirPath, callback);
        } else {
            callback(path.join(dir, f));
        }
    });
}

console.log('--- STARTING BASE44 BADGE FIX ---');

TARGET_DIRS.forEach(dir => {
    console.log(`Scanning /${dir}...`);
    walkDir(dir, (filePath) => {
        if (!filePath.endsWith('.js') && !filePath.endsWith('.jsx')) return;
        
        filesScanned++;
        
        try {
            let content = fs.readFileSync(filePath, 'utf8');
            
            // Check if file uses Badge
            if (content.includes(SEARCH_STRING)) {
                // Check if file already imports Badge
                if (!content.includes('import { Badge }') && !content.includes('import {Badge}')) {
                    console.log(`[FIXING] Missing import in: ${filePath}`);
                    
                    // Add import after the last import or at the top
                    const lines = content.split('\n');
                    let lastImportIdx = -1;
                    
                    for (let i = 0; i < lines.length; i++) {
                        if (lines[i].trim().startsWith('import ')) {
                            lastImportIdx = i;
                        }
                    }
                    
                    if (lastImportIdx !== -1) {
                        lines.splice(lastImportIdx + 1, 0, IMPORT_STATEMENT);
                    } else {
                        lines.unshift(IMPORT_STATEMENT);
                    }
                    
                    fs.writeFileSync(filePath, lines.join('\n'));
                    filesFixed++;
                } else {
                    // console.log(`[OK] ${filePath}`);
                }
            }
        } catch (err) {
            console.error(`[ERROR] processing ${filePath}:`, err);
            errors++;
        }
    });
});

console.log('--- SCAN COMPLETE ---');
console.log(`Files Scanned: ${filesScanned}`);
console.log(`Files Fixed:   ${filesFixed}`);
console.log(`Errors:        ${errors}`);
console.log('---------------------');