# Quick Fix Guide

**Symptoms:** White screen, red error in console mentioning "Badge".
**Cure:** Add import.

## Quick Actions
1. **Search** your codebase for `<Badge`.
2. **Open** each file found.
3. **Check** top of file for `import { Badge } ...`.
4. **Paste** if missing: `import { Badge } from "@/components/ui/badge";`.

## Common Culprits
- `Dashboard.js`
- `Layout.js`
- Widget files