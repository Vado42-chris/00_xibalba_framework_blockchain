# Base44 Badge Error: Complete Fix Guide

**Systematic approach to resolving UI crashes.**

## 1. Diagnosis
The error `ReferenceError: Badge is not defined` occurs when React tries to render a `<Badge>` component but cannot find the definition. This usually happens when the import statement is missing, deleted, or commented out.

## 2. Comprehensive Checklist
Run through this list to ensure total system health.

### Core Pages
- [ ] `pages/Dashboard.js`
- [ ] `pages/Home.js`
- [ ] `pages/Settings.js`
- [ ] `pages/Audit.js`

### Layouts
- [ ] `layout/Layout.js`
- [ ] `components/ui/design-system/DashboardLayout.js`

### Key Components
- [ ] `components/home/GatewayLanding.js`
- [ ] `components/dashboards/XiIoDashboard.js`
- [ ] `components/dashboards/widgets/BusinessHealthWidget.js`
- [ ] `components/dashboards/widgets/SystemStatusHero.js`

## 3. The Fix Pattern
**Bad:**
```javascript
import React from 'react';
// Badge is missing!

export default function Widget() {
  return <Badge>Error</Badge>;
}
```

**Good:**
```javascript
import React from 'react';
import { Badge } from "@/components/ui/badge"; // <--- ADD THIS

export default function Widget() {
  return <Badge>Success</Badge>;
}
```

## 4. Troubleshooting
If adding the import doesn't work:
1. **Check Path:** Ensure it is `@/components/ui/badge` (lowercase 'b' in filename usually).
2. **Check Typo:** Ensure it is `Badge`, not `Bage`.
3. **Check Export:** Verify `components/ui/badge.js` actually exports `Badge`.
4. **Restart:** Sometimes a hard refresh is needed to clear cache.