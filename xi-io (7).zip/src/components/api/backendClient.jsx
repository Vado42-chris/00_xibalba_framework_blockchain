import { base44 } from '@/api/base44Client';

export const backendClient = {
    createCheckoutSession: async ({ items, success_url, cancel_url }) => {
        try {
            // Invokes the 'stripe' backend function with the 'create_checkout' action
            // Adapting parameters to match functions/stripe.js expectation of 'returnUrl'
            // We use success_url as the base for returnUrl
            const returnUrl = success_url ? success_url.split('?')[0] : window.location.href;

            const response = await base44.functions.invoke('stripe', {
                action: 'create_checkout',
                returnUrl: returnUrl,
                items // Passing items, though current backend might use a fixed price ID
            });
            
            if (response.data && response.data.error) {
                throw new Error(response.data.error);
            }
            
            return response.data;
        } catch (error) {
            throw error;
        }
    }
};