// Local Base44 Client Mock for Offline/Containerized Development
// This replaces the SDK to prevent redirects to the production platform

export const base44 = {
    auth: {
        me: async () => {
            // Return a mock admin user to bypass login
            return { 
                id: 'local-dev-user', 
                email: 'dev@localhost', 
                full_name: 'Local Admin',
                role: 'ROOT_ADMIN' 
            };
        },
        redirectToLogin: () => {
            console.warn("Base44 Auth Redirect Intercepted (Local Mode)");
            window.location.href = '/'; // Stay on home
        },
        updateMe: async () => ({}),
        isAuthenticated: async () => true,
        logout: async () => {
            window.location.reload();
        }
    },
    
    // Dynamic proxy for entities
    entities: new Proxy({}, {
        get: (target, entityName) => ({
            list: async () => [],
            filter: async () => [],
            get: async () => null,
            create: async () => ({}),
            update: async () => ({}),
            delete: async () => {},
            bulkCreate: async () => []
        })
    }),

    // Mock functions (or proxy to local /api if backend is ready)
    functions: {
        invoke: async (functionName, payload) => {
            console.log(`[LocalClient] Invoking function: ${functionName}`, payload);
            
            // Return mock responses for critical system functions
            if (functionName === 'systemHealth') {
                return { 
                    data: { 
                        status: 'OK', 
                        timestamp: new Date().toISOString(),
                        services: {
                            database: 'connected',
                            redis: 'connected',
                            api: 'online'
                        }
                    } 
                };
            }
            
            return { data: { success: true, message: "Local mock response" } };
        }
    },

    // Agents
    agents: {
        createConversation: async () => ({ id: 'mock-conv', messages: [] }),
        listConversations: async () => [],
        getConversation: async () => ({ messages: [] }),
        addMessage: async () => ({}),
        subscribeToConversation: () => () => {},
        getWhatsAppConnectURL: () => '#'
    },

    // Integrations
    integrations: new Proxy({}, {
        get: () => new Proxy({}, {
            get: () => async () => ({})
        })
    })
};