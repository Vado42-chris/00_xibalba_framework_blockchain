import { base44 } from '@/api/base44Client';
import { getAuthHeaders } from '../control-panel/auth';

const API_BASE = 'http://localhost:3000/api'; // Local Dev Target

/**
 * XI-STUDIO SERVICE LAYER
 * 
 * This module abstracts all direct backend interactions.
 * UI Components should import from here, NOT from @/api/base44Client directly.
 * This prepares us for the "Headless" architecture shift.
 */

// --- 1. CORE & AUTH ---

export const getSystemInit = async () => {
    const user = await base44.auth.me();
    // In a real headless API, this would be a single fetch. 
    // Here we compose it from our existing SDK for now (The Bridge).
    const config = await base44.entities.SystemConfig.list();
    
    return {
        user,
        config: config[0] || {},
        timestamp: Date.now()
    };
};

// --- 2. PROJECT MANAGEMENT ---

export const getProjects = async () => {
    return await base44.entities.Project.list('-updated_date');
};

export const getActiveSprint = async () => {
    const sprints = await base44.entities.Sprint.list();
    return sprints.find(s => s.status === 'active') || null;
};

// --- 3. STUDIO & FILES ---

export const saveFileRecord = async (fileData) => {
    // Abstraction for creating/updating files
    if (fileData.id) {
        return await base44.entities.FileRecord.update(fileData.id, fileData);
    }
    return await base44.entities.FileRecord.create(fileData);
};

export const getRecentFiles = async (limit = 5) => {
    return await base44.entities.FileRecord.list('-updated_date', limit);
};

// --- 4. MARKETPLACE & COMPONENTS ---

export const searchMarketplace = async (query) => {
    // Future: Call a dedicated search endpoint
    // Current: Filter entities locally or via basic query
    if (!query) return await base44.entities.MarketplaceItem.list();
    // Simple mock filter for now, would be a real search query
    const all = await base44.entities.MarketplaceItem.list();
    return all.filter(i => i.name.toLowerCase().includes(query.toLowerCase()));
};

export const installAddon = async (addonId) => {
    return await base44.entities.InstalledAddon.create({
        addon_id: addonId,
        status: 'active',
        installation_log: [`Installed at ${new Date().toISOString()}`]
    });
};

// --- 5. GAMIFICATION & OBSERVER ---

export const logUserAction = async (actionType, metadata = {}) => {
    // This feeds the "Observer" layer
    try {
        await base44.entities.TimelineEvent.create({
            type: 'user',
            text: `Action: ${actionType}`,
            severity: 'nominal',
            metadata: JSON.stringify(metadata),
            timestamp: new Date().toISOString()
        });
        
        // Potential: Trigger XP update here
    } catch (e) {
        console.warn("Failed to log observer event", e);
    }
};

const api = {
    getSystemInit,
    getProjects,
    getActiveSprint,
    saveFileRecord,
    getRecentFiles,
    searchMarketplace,
    installAddon,
    logUserAction,
    
    // --- 6. DEPLOYMENT & ODIN BRIDGE ---
    
    uploadBundle: async (file) => {
        // Option A: Direct to Local Backend (Fastest for Local Dev)
        try {
            const formData = new FormData();
            formData.append('bundle', file);
            
            const response = await fetch(`${API_BASE}/deploy/upload`, {
                method: 'POST',
                headers: { 
                    ...getAuthHeaders(),
                    // Content-Type is auto-set by fetch for FormData
                },
                body: formData
            });
            if (response.ok) {
                const data = await response.json();
                return { jobId: data.jobId, direct: true };
            }
        } catch (e) {
            console.warn("Local backend upload failed, falling back to Base44 Storage", e);
        }

        // Option B: Fallback to Base44 Storage (Remote/Bridge)
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return { file_url, direct: false };
    },

    executeDeploy: async (jobIdOrUrl) => {
        // Option A: Direct Local Execution
        if (typeof jobIdOrUrl === 'object' && jobIdOrUrl.direct) {
             const response = await fetch(`${API_BASE}/deploy/execute`, {
                method: 'POST',
                headers: getAuthHeaders(),
                body: JSON.stringify({ jobId: jobIdOrUrl.jobId })
            });
            return await response.json();
        }

        // Option B: Bridge via Base44 Function
        // In a real local setup, this might fetch('http://localhost:3000/api/deploy/execute')
        // Here we use the Base44 Function bridge
        const { data } = await base44.functions.invoke('deploySite', { 
            file_url: jobIdOrUrl, // We pass the URL as the "Job ID" for simplicity in this bridge
            environment: 'production' 
        });
        return data;
    }
};

export default api;