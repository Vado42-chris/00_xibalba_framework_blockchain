import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Activity, Clock, Users, AlertTriangle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const MOCK_DATA = Array.from({ length: 7 }, (_, i) => ({
    name: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
    activeUsers: Math.floor(Math.random() * 500) + 100,
    errors: Math.floor(Math.random() * 20),
    avgSession: Math.floor(Math.random() * 15) + 5
}));

export default function LiveUserActivity() {
    return (
        <Card className="bg-neutral-900/50 border-white/10 h-full">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <div>
                        <CardTitle className="text-lg font-bold text-white flex items-center gap-2">
                            <Activity className="w-5 h-5 text-emerald-500" />
                            Live System Pulse
                        </CardTitle>
                        <CardDescription>Real-time usage and health metrics</CardDescription>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-full animate-pulse">
                        <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                        LIVE
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="p-4 rounded-lg bg-black/40 border border-white/5">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-xs text-neutral-400 uppercase tracking-wider">Active Users</span>
                            <Users className="w-4 h-4 text-blue-500" />
                        </div>
                        <div className="text-2xl font-bold text-white">1,248</div>
                        <p className="text-xs text-green-400 mt-1">↑ 12% vs last hour</p>
                    </div>
                    <div className="p-4 rounded-lg bg-black/40 border border-white/5">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-xs text-neutral-400 uppercase tracking-wider">Avg Session</span>
                            <Clock className="w-4 h-4 text-purple-500" />
                        </div>
                        <div className="text-2xl font-bold text-white">18m 32s</div>
                        <p className="text-xs text-neutral-500 mt-1">Stable</p>
                    </div>
                    <div className="p-4 rounded-lg bg-black/40 border border-white/5">
                        <div className="flex items-center justify-between mb-2">
                            <span className="text-xs text-neutral-400 uppercase tracking-wider">Error Rate</span>
                            <AlertTriangle className="w-4 h-4 text-rose-500" />
                        </div>
                        <div className="text-2xl font-bold text-white">0.4%</div>
                        <p className="text-xs text-rose-400 mt-1">↓ 0.1% vs yesterday</p>
                    </div>
                </div>

                <div className="h-[200px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={MOCK_DATA}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                            <XAxis dataKey="name" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '8px' }}
                                itemStyle={{ color: '#fff' }}
                            />
                            <Line type="monotone" dataKey="activeUsers" stroke="#3b82f6" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                            <Line type="monotone" dataKey="avgSession" stroke="#a855f7" strokeWidth={2} dot={false} />
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </CardContent>
        </Card>
    );
}