import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
    LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar 
} from 'recharts';
import { Activity, Users, Globe, AlertTriangle, ArrowUpRight, ArrowDownRight, Zap } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

const MOCK_DATA = {
    users: [
        { date: 'Mon', value: 120 }, { date: 'Tue', value: 132 }, { date: 'Wed', value: 101 },
        { date: 'Thu', value: 134 }, { date: 'Fri', value: 190 }, { date: 'Sat', value: 230 }, { date: 'Sun', value: 210 }
    ],
    apiCalls: [
        { date: '00:00', value: 400 }, { date: '04:00', value: 300 }, { date: '08:00', value: 550 },
        { date: '12:00', value: 800 }, { date: '16:00', value: 950 }, { date: '20:00', value: 600 }
    ],
    errors: [
        { name: '404', value: 40 }, { name: '500', value: 15 }, { name: '403', value: 10 }, { name: 'Timeout', value: 5 }
    ]
};

const StatCard = ({ title, value, change, icon: Icon, trend }) => (
    <Card className="bg-neutral-900/50 border-white/10">
        <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
                <div className="p-2 bg-white/5 rounded-lg">
                    <Icon className="w-5 h-5 text-neutral-400" />
                </div>
                {trend === 'up' ? (
                    <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">
                        <ArrowUpRight className="w-3 h-3 mr-1" /> {change}
                    </Badge>
                ) : (
                    <Badge className="bg-rose-500/10 text-rose-500 border-rose-500/20">
                        <ArrowDownRight className="w-3 h-3 mr-1" /> {change}
                    </Badge>
                )}
            </div>
            <div className="space-y-1">
                <p className="text-sm text-neutral-500 font-medium uppercase tracking-wide">{title}</p>
                <h3 className="text-3xl font-bold text-white">{value}</h3>
            </div>
        </CardContent>
    </Card>
);

export default function AnalyticsDashboard() {
    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-white mb-2">Analytics Command Center</h2>
                    <p className="text-neutral-400">Real-time telemetry and performance insights.</p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" className="border-white/10">Last 24h</Button>
                    <Button variant="outline" className="border-white/10">7 Days</Button>
                    <Button className="bg-white text-black hover:bg-neutral-200">Export Report</Button>
                </div>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard title="Active Users" value="2,543" change="12.5%" icon={Users} trend="up" />
                <StatCard title="API Requests" value="142.5k" change="8.2%" icon={Zap} trend="up" />
                <StatCard title="Deployments" value="24" change="3" icon={Globe} trend="up" />
                <StatCard title="Error Rate" value="0.4%" change="0.1%" icon={AlertTriangle} trend="down" />
            </div>

            {/* Charts Area */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Main Traffic Chart */}
                <Card className="lg:col-span-2 bg-neutral-900/50 border-white/10">
                    <CardHeader>
                        <CardTitle>Traffic Overview</CardTitle>
                        <CardDescription>User sessions vs API load</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="h-[300px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={MOCK_DATA.users}>
                                    <defs>
                                        <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                            <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                                            <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                                        </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                                    <XAxis dataKey="date" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                                    <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                                    <Tooltip 
                                        contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '8px' }}
                                        itemStyle={{ color: '#fff' }}
                                    />
                                    <Area type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} fillOpacity={1} fill="url(#colorValue)" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    </CardContent>
                </Card>

                {/* Error Distribution */}
                <Card className="bg-neutral-900/50 border-white/10">
                    <CardHeader>
                        <CardTitle>System Health</CardTitle>
                        <CardDescription>Error distribution by type</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="h-[300px] w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={MOCK_DATA.errors} layout="vertical">
                                    <CartesianGrid strokeDasharray="3 3" stroke="#333" horizontal={true} vertical={false} />
                                    <XAxis type="number" stroke="#666" fontSize={12} hide />
                                    <YAxis dataKey="name" type="category" stroke="#666" fontSize={12} width={60} tickLine={false} axisLine={false} />
                                    <Tooltip 
                                        cursor={{fill: 'rgba(255,255,255,0.05)'}}
                                        contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '8px' }}
                                    />
                                    <Bar dataKey="value" fill="#f43f5e" radius={[0, 4, 4, 0]} barSize={20} />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                        <div className="mt-4 grid grid-cols-2 gap-4">
                            <div className="bg-black/40 p-3 rounded border border-white/5">
                                <div className="text-xs text-neutral-500 mb-1">Uptime</div>
                                <div className="text-lg font-mono text-emerald-500">99.99%</div>
                            </div>
                            <div className="bg-black/40 p-3 rounded border border-white/5">
                                <div className="text-xs text-neutral-500 mb-1">Avg Latency</div>
                                <div className="text-lg font-mono text-blue-500">42ms</div>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}