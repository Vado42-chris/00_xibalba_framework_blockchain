import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { cn } from "@/lib/utils";
import { 
    PanelRightOpen, PanelRightClose,
    Wrench, GripVertical, Bot, Star, Bookmark,
    Grid, Terminal
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
    GLOBAL_TOOLS, getToolsForPath 
} from '@/components/tools/ToolRegistry';
import { OrientingText, IntentText, Layer, StateText } from '@/components/ui/design-system/System';
import { useGamification, XPBar } from '@/components/features/GamificationSystem';
import { BookmarkToggle } from '@/components/features/BookmarkSystem';
import { Button } from "@/components/ui/button";
import DockChat from '@/components/tools/DockChat';
import QuestLog from '@/components/features/QuestLog';
import DesktopTools from '@/components/tools/DesktopTools';

const ToolItem = ({ tool, isOpen, isActive, onClick, onAction }) => {
    return (
        <div className="group relative">
            {/* Tool Header / Icon */}
            <div 
                onClick={onClick}
                className={cn(
                    "flex items-center transition-all duration-200 min-h-[48px] border-l-2 cursor-pointer relative",
                    isActive && isOpen
                        ? "px-4 py-3 bg-neutral-900/60 border-[hsl(var(--color-intent))]" 
                        : isOpen 
                            ? "px-4 py-3 border-transparent hover:bg-neutral-900/40 hover:border-white/10"
                            : "justify-center py-3 border-transparent hover:bg-neutral-800 hover:border-white/20"
            )}>
                <tool.icon className={cn(
                    "w-4 h-4 shrink-0 transition-colors",
                    isActive && isOpen ? "text-[hsl(var(--color-intent))]" : 
                    "text-neutral-500 group-hover:text-white"
                )} />
                
                {isOpen && (
                    <span className={cn(
                        "ml-3 text-xs font-bold transition-colors flex-1",
                        isActive ? "text-white" : "text-neutral-400 group-hover:text-neutral-200"
                    )}>{tool.label}</span>
                )}

                {/* Hover Actions (Bookmark) */}
                {isOpen && (
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute right-2 flex items-center" onClick={(e) => e.stopPropagation()}>
                        <BookmarkToggle 
                            id={`tool-${tool.id}`} 
                            title={tool.label} 
                            type="tool" 
                            className="h-6 w-6 hover:bg-white/10"
                        />
                    </div>
                )}
            </div>

            {/* Tool Body (Only when expanded and active) */}
            {isOpen && isActive && (
                <div className="px-4 pb-4 pt-1 animate-in slide-in-from-right-2 duration-200">
                    <div className="p-3 bg-neutral-900/50 border border-white/5 rounded-md shadow-inner relative">
                        {/* XP Trigger wrapper for tracking interaction */}
                        <div onClick={() => onAction(tool.id)}>
                            <tool.component />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const SectionAgent = ({ agent, isOpen, onChatStart }) => {
    if (!agent) return null;

    return (
        <div className={cn(
            "border-t border-white/10 bg-neutral-900/80 backdrop-blur-md transition-all duration-300",
            isOpen ? "p-4" : "p-2"
        )}>
            <div className={cn(
                "flex items-center gap-3",
                !isOpen && "justify-center flex-col gap-1"
            )}>
                <div className={cn(
                    "h-10 w-10 rounded-full border border-white/10 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(0,0,0,0.5)]",
                    "bg-gradient-to-br from-neutral-800 to-neutral-950"
                )}>
                    <agent.icon className={cn("w-5 h-5", agent.color)} />
                </div>
                
                {isOpen ? (
                    <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                            <h4 className="text-sm font-bold text-white truncate">{agent.name}</h4>
                            <span className="flex h-2 w-2 relative">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                            </span>
                        </div>
                        <p className="text-[10px] text-neutral-400 truncate">{agent.role}</p>
                    </div>
                ) : (
                    <div className="h-1.5 w-1.5 rounded-full bg-green-500 shadow-[0_0_5px_currentColor]" />
                )}
            </div>
            
            {isOpen && (
                <div className="mt-3">
                    <Button 
                        onClick={(e) => {
                            e.stopPropagation();
                            onChatStart();
                        }}
                        variant="outline" 
                        size="sm" 
                        className="w-full text-[10px] h-7 border-white/10 bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white"
                    >
                        Message {agent.name}...
                    </Button>
                </div>
            )}
        </div>
    );
};

export default function ToolDock() {
    const [isOpen, setIsOpen] = useState(false);
    const [activeToolId, setActiveToolId] = useState(null);
    const [showAgentChat, setShowAgentChat] = useState(false);
    const location = useLocation();
    
    // Hooks
    const { awardXP } = useGamification() || { awardXP: () => {} }; // Safe fallback
    
    const { tools: contextTools, agent: sectionAgent } = getToolsForPath(location.pathname);

    // Reset chat when path changes
    useEffect(() => {
        setShowAgentChat(false);
    }, [location.pathname]);
    
    // Organize tools by category
    const globalTools = [
        {
            id: 'desktop-tools',
            label: 'Desktop Config',
            icon: Grid,
            component: DesktopTools,
            category: 'global'
        },
        ...GLOBAL_TOOLS,
        // QUICK LAUNCH PADS (Per "OmniDrawer" Spec)
        {
            id: 'dev-pad',
            label: 'Dev Pad',
            icon: Terminal,
            component: () => (
                <div className="p-2 space-y-2">
                    <div className="text-[10px] text-neutral-500 font-bold tracking-widest">QUICK ACTIONS</div>
                    <div className="grid grid-cols-2 gap-2">
                        <Button size="sm" variant="outline" className="h-8 text-[10px] border-white/10 hover:bg-white/5">NPM RUN DEV</Button>
                        <Button size="sm" variant="outline" className="h-8 text-[10px] border-white/10 hover:bg-white/5">BUILD</Button>
                        <Button size="sm" variant="outline" className="h-8 text-[10px] border-white/10 hover:bg-white/5">LINT</Button>
                        <Button size="sm" variant="outline" className="h-8 text-[10px] border-white/10 hover:bg-white/5">TEST</Button>
                    </div>
                </div>
            ),
            category: 'global'
        },
        { 
            id: 'quest-log', 
            label: 'Quest Log', 
            icon: Star, 
            component: QuestLog,
            category: 'global'
        }
    ];
    const interactionTools = contextTools.filter(t => t.category === 'interaction');
    const automationTools = contextTools.filter(t => t.category === 'automation');
    const otherTools = contextTools.filter(t => !t.category || (t.category !== 'interaction' && t.category !== 'automation'));
    
    const hasInteraction = interactionTools.length > 0 || otherTools.length > 0;
    const hasAutomation = automationTools.length > 0;

    const toggleTool = (toolId) => {
        if (!isOpen) {
            setIsOpen(true);
            setActiveToolId(toolId);
        } else {
            if (activeToolId === toolId) {
                setIsOpen(false);
                setActiveToolId(null);
            } else {
                setActiveToolId(toolId);
            }
        }
    };

    const handleDockToggle = () => {
        if (isOpen) {
            setIsOpen(false);
            setActiveToolId(null);
        } else {
            setIsOpen(true);
            if (!activeToolId && globalTools.length > 0) {
                setActiveToolId(globalTools[0].id);
            }
        }
    };

    const handleToolAction = (toolId) => {
        // Debounced XP award logic could go here
        // For now, just trigger a small XP bump for engaging with tools
        awardXP(5, `Used Tool: ${toolId}`);
    };

    return (
        <Layer 
            level="orientation"
            className={cn(
                "h-screen border-l border-white/5 flex shrink-0 transition-all duration-300 ease-out relative z-30 shadow-[5px_0_30px_-10px_rgba(0,0,0,0.5)] p-0",
                isOpen ? "w-72" : "w-14"
            )}
        >
            {/* Toggle Handle */}
            <button 
                onClick={handleDockToggle}
                className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-12 bg-black/40 backdrop-blur-xl border border-white/10 rounded-l-md flex items-center justify-center text-neutral-500 hover:text-white hover:bg-black/60 transition-colors z-40 shadow-[0_0_15px_-5px_rgba(0,0,0,0.5)]"
                title={isOpen ? "Collapse Tools" : "Expand Tools"}
            >
                {isOpen ? <PanelRightClose className="w-3 h-3" /> : <PanelRightOpen className="w-3 h-3" />}
            </button>

            {/* DOCK CONTENT */}
            {showAgentChat && isOpen ? (
            <DockChat 
                agent={sectionAgent} 
                onClose={() => setShowAgentChat(false)} 
            />
            ) : (
            <div className="flex flex-col w-full h-full overflow-hidden">

                {/* Header with XP Bar */}
                <div className="shrink-0 bg-white/5 border-b border-white/5 backdrop-blur-sm">
                    <div 
                        onClick={handleDockToggle}
                        className={cn(
                        "h-14 flex items-center transition-all cursor-pointer hover:bg-white/5",
                        isOpen ? "px-4 justify-between" : "justify-center"
                    )}>
                        {isOpen ? (
                            <div className="flex items-center gap-2">
                                <Wrench className="w-4 h-4 text-[hsl(var(--color-execution))] drop-shadow-[0_0_5px_currentColor]" />
                                <OrientingText className="font-bold tracking-widest text-[hsl(var(--color-execution))] drop-shadow-sm">TOOLKIT</OrientingText>
                            </div>
                        ) : (
                            <Wrench className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
                        )}
                    </div>
                    {/* Integrated XP Bar when open */}
                    {isOpen && (
                         <div className="px-0 pb-2">
                            <XPBar />
                         </div>
                    )}
                </div>

                {/* Tool List Area - Pushes Agent to Bottom */}
                <div className="flex-1 overflow-y-auto flex flex-col min-h-0">

                    {/* SECTION 1: GLOBAL (ABOVE THE LINE) */}
                    <div className="flex flex-col gap-px pt-2">
                        {globalTools.map(tool => (
                            <ToolItem 
                                key={tool.id} 
                                tool={tool} 
                                isOpen={isOpen} 
                                isActive={activeToolId === tool.id} 
                                onClick={() => toggleTool(tool.id)} 
                                onAction={handleToolAction}
                            />
                        ))}
                    </div>

                    {/* SEPARATOR 1: BETWEEN GLOBAL AND INTERACTION */}
                    {hasInteraction && (
                        <div className="w-full h-px bg-white/5 my-3 shrink-0" />
                    )}

                    {/* SECTION 2: INTERACTION (BETWEEN THE LINES) */}
                    <div className="flex flex-col gap-px">
                        {[...interactionTools, ...otherTools].map(tool => (
                            <ToolItem 
                                key={tool.id} 
                                tool={tool} 
                                isOpen={isOpen} 
                                isActive={activeToolId === tool.id} 
                                onClick={() => toggleTool(tool.id)} 
                                onAction={handleToolAction}
                            />
                        ))}
                    </div>

                    {/* SEPARATOR 2: BETWEEN INTERACTION AND AUTOMATION */}
                    {hasAutomation && (
                        <div className="w-full h-px bg-white/5 my-3 shrink-0" />
                    )}

                    {/* SECTION 3: AUTOMATION (BELOW THE LINE) */}
                    <div className="flex flex-col gap-px pb-4">
                        {automationTools.map(tool => (
                            <ToolItem 
                                key={tool.id} 
                                tool={tool} 
                                isOpen={isOpen} 
                                isActive={activeToolId === tool.id} 
                                onClick={() => toggleTool(tool.id)} 
                                onAction={handleToolAction}
                            />
                        ))}
                    </div>

                </div>

                {/* Bottom Section: Store & Agent */}
                <div className="shrink-0 mt-auto flex flex-col gap-px border-t border-white/5">
                    
                    {/* Store Button */}
                    <Link to={createPageUrl('Marketplace')}>
                        <div className={cn(
                            "flex items-center transition-all duration-200 cursor-pointer relative hover:bg-neutral-800 hover:border-white/20 border-l-2 border-transparent",
                            isOpen ? "px-4 py-3" : "justify-center py-3"
                        )}>
                            <Grid className="w-4 h-4 shrink-0 text-[hsl(var(--color-execution))]" />
                            
                            {isOpen && (
                                <span className="ml-3 text-xs font-bold text-neutral-300 group-hover:text-white flex-1">
                                    Addon Store
                                </span>
                            )}
                            
                            {isOpen && (
                                <div className="bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] text-[9px] px-1.5 py-0.5 rounded font-bold">
                                    NEW
                                </div>
                            )}
                        </div>
                    </Link>

                    {/* Agent Section */}
                    <div 
                        className={cn("transition-colors", !isOpen && "cursor-pointer hover:bg-white/5")}
                        onClick={() => !isOpen && handleDockToggle()}
                    >
                    {sectionAgent ? (
                        <SectionAgent 
                            agent={sectionAgent} 
                            isOpen={isOpen} 
                            onChatStart={() => setShowAgentChat(true)}
                        />
                    ) : isOpen ? (
                    <div className="p-4 text-center text-[10px] text-neutral-600 border-t border-white/5">
                        NO ACTIVE AGENT LINKED
                    </div>
                    ) : null}
                    </div>
                    </div>

            </div>
            )}
        </Layer>
    );
}