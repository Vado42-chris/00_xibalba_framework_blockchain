import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { BrandLogo } from '@/components/brand/BrandLogo';
import { 
    Globe, Shield, Scale, Mail, MapPin, Phone, 
    Github, Twitter, Linkedin, ExternalLink, Heart
} from 'lucide-react';

export function SiteFooter() {
    const currentYear = new Date().getFullYear();

    const linkGroups = [
        {
            title: "Empire",
            links: [
                { label: "Gateway", path: "Home" },
                { label: "Dashboard", path: "Dashboard" },
                { label: "Intelligence", path: "Intelligence" },
                { label: "Commerce", path: "Commerce" },
                { label: "Finance", path: "Finance" }
            ]
        },
        {
            title: "Strategy",
            links: [
                { label: "Business Plan", path: "BusinessPlan" },
                { label: "Enterprise", path: "Enterprise" },
                { label: "Marketplace", path: "Marketplace" },
                { label: "Integrations", path: "Integrations" }
            ]
        },
        {
            title: "Operations",
            links: [
                { label: "Work Room", path: "WorkRoom" },
                { label: "Studio", path: "Studio" },
                { label: "Network", path: "Network" },
                { label: "Nodes", path: "Nodes" }
            ]
        },
        {
            title: "Legal & Compliance",
            links: [
                { label: "Privacy Policy", path: "Legal" },
                { label: "Terms of Service", path: "Legal" },
                { label: "Data Governance", path: "Audit" },
                { label: "Security", path: "Settings" }
            ]
        }
    ];

    return (
        <footer className="w-full bg-black/60 backdrop-blur-xl border-t border-white/5 pt-16 pb-8 mt-24 relative z-20">
            {/* Top Glow Line */}
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            
            <div className="max-w-7xl mx-auto px-8">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12 mb-16">
                    {/* Brand Column */}
                    <div className="lg:col-span-2 space-y-6">
                        <BrandLogo size="large" variant="full" />
                        <p className="text-neutral-400 text-sm leading-relaxed max-w-xs drop-shadow-sm">
                            Architecting the future of digital sovereignty. 
                            Xibalba Studio provides the infrastructure for autonomous operations, 
                            intelligence synthesis, and creative execution.
                        </p>
                        <div className="flex items-center gap-4">
                            <a href="#" className="p-2 bg-white/5 rounded-full hover:bg-white/20 hover:shadow-[0_0_10px_rgba(255,255,255,0.2)] text-neutral-400 hover:text-white transition-all duration-300">
                                <Twitter className="w-4 h-4" />
                            </a>
                            <a href="#" className="p-2 bg-white/5 rounded-full hover:bg-white/20 hover:shadow-[0_0_10px_rgba(255,255,255,0.2)] text-neutral-400 hover:text-white transition-all duration-300">
                                <Github className="w-4 h-4" />
                            </a>
                            <a href="#" className="p-2 bg-white/5 rounded-full hover:bg-white/20 hover:shadow-[0_0_10px_rgba(255,255,255,0.2)] text-neutral-400 hover:text-white transition-all duration-300">
                                <Linkedin className="w-4 h-4" />
                            </a>
                        </div>
                    </div>

                    {/* Link Columns */}
                    {linkGroups.map((group, idx) => (
                        <div key={idx} className="space-y-4">
                            <h4 className="text-xs font-bold uppercase tracking-widest text-white/40">{group.title}</h4>
                            <ul className="space-y-2">
                                {group.links.map((link, lIdx) => (
                                    <li key={lIdx}>
                                        <Link 
                                            to={createPageUrl(link.path)}
                                            className="text-sm text-neutral-500 hover:text-[hsl(var(--color-intent))] transition-colors flex items-center gap-2 group"
                                        >
                                            <span className="w-1 h-1 rounded-full bg-transparent group-hover:bg-[hsl(var(--color-intent))] transition-colors" />
                                            {link.label}
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>

                {/* Legal & Contact Info */}
                <div className="border-t border-white/5 pt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="space-y-4">
                        <h4 className="text-xs font-bold uppercase tracking-widest text-white/40 flex items-center gap-2">
                            <Shield className="w-3 h-3" />
                            Compliance Statements
                        </h4>
                        <div className="text-xs text-neutral-600 space-y-2 max-w-xl">
                            <p>
                                <strong>GDPR & CCPA:</strong> We are committed to data sovereignty. Your data resides on nodes you control. 
                                We perform no unauthorized telemetry.
                            </p>
                            <p>
                                <strong>AI Ethics:</strong> All autonomous agents operate within the bounds of the 
                                <Link to={createPageUrl('Legal')} className="text-neutral-400 hover:underline ml-1">Xibalba Safety Protocol v2</Link>.
                            </p>
                        </div>
                    </div>

                    <div className="space-y-4 lg:text-right">
                        <h4 className="text-xs font-bold uppercase tracking-widest text-white/40 flex items-center gap-2 lg:justify-end">
                            <MapPin className="w-3 h-3" />
                            Operations Center
                        </h4>
                        <div className="text-xs text-neutral-500 space-y-1">
                            <p>Xibalba Studio HQ</p>
                            <p>1001 Cybernetics Blvd, Sector 7</p>
                            <p>Neo-Tokyo, NT 90210</p>
                            <p className="pt-2 flex items-center gap-2 lg:justify-end text-neutral-400">
                                <Mail className="w-3 h-3" /> contact@xibalba.io
                                <span className="opacity-30">|</span>
                                <Phone className="w-3 h-3" /> +1 (800) 555-0199
                            </p>
                        </div>
                    </div>
                </div>

                {/* Bottom Bar */}
                <div className="border-t border-white/5 mt-8 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] text-neutral-600 font-mono">
                    <div>
                        © {currentYear} Xibalba Studio. All Rights Reserved. System Version 2.4.1
                    </div>
                    <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            Systems Nominal
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                            Made with <Heart className="w-2 h-2 text-rose-500 fill-rose-500" /> by Humans & Machines
                        </span>
                    </div>
                </div>
            </div>
        </footer>
    );
}