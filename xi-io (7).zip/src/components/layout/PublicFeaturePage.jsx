import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Lock } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';

export default function PublicFeaturePage({ 
    title, 
    subtitle, 
    description, 
    features = [], 
    icon: Icon,
    screenshot // Optional: URL or Component
}) {
    const handleLogin = () => {
        base44.auth.redirectToLogin();
    };

    return (
        <div className="min-h-screen bg-black text-white selection:bg-[hsl(var(--color-intent))] selection:text-black font-sans flex flex-col">
            
            {/* PUBLIC NAVIGATION */}
            <nav className="fixed top-0 left-0 right-0 z-50 h-16 border-b border-white/5 bg-black/50 backdrop-blur-xl px-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link to="/" className="w-8 h-8 bg-white/10 rounded flex items-center justify-center font-bold font-mono text-white hover:bg-white/20 transition-colors">B44</Link>
                    <div className="hidden md:flex gap-6 text-sm font-medium text-neutral-400">
                        <span className="text-white cursor-default">{title}</span>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <Button variant="ghost" className="text-sm font-mono text-neutral-400 hover:text-white" onClick={handleLogin}>
                        LOG IN
                    </Button>
                    <Button className="bg-[hsl(var(--color-intent))] text-black font-bold hover:bg-[hsl(var(--color-intent))]/90" onClick={handleLogin}>
                        GET ACCESS
                    </Button>
                </div>
            </nav>

            {/* HERO */}
            <main className="flex-1 pt-32 pb-20 px-6">
                <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
                    
                    {/* LEFT: COPY */}
                    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-[hsl(var(--color-intent))]">
                            <Icon className="w-3 h-3" />
                            <span>MODULE: {title.toUpperCase()}</span>
                        </div>
                        
                        <h1 className="text-5xl md:text-7xl font-light tracking-tight text-white leading-[1.1]">
                            {subtitle}
                        </h1>
                        
                        <p className="text-xl text-neutral-400 leading-relaxed max-w-xl">
                            {description}
                        </p>

                        <ul className="space-y-4 pt-4">
                            {features.map((feature, i) => (
                                <li key={i} className="flex items-start gap-3 text-sm text-neutral-300">
                                    <CheckCircle2 className="w-5 h-5 text-[hsl(var(--color-execution))] shrink-0" />
                                    <span>{feature}</span>
                                </li>
                            ))}
                        </ul>

                        <div className="pt-8 flex flex-wrap gap-4">
                            <Button 
                                className="h-14 px-8 text-base bg-white text-black hover:bg-neutral-200 font-bold"
                                onClick={handleLogin}
                            >
                                START USING {title.toUpperCase()} <ArrowRight className="w-5 h-5 ml-2" />
                            </Button>
                            <Button 
                                variant="outline" 
                                className="h-14 px-8 text-base border-white/10 hover:bg-white/5"
                                onClick={handleLogin}
                            >
                                VIEW DEMO
                            </Button>
                        </div>
                    </div>

                    {/* RIGHT: PREVIEW (THE MIRROR) */}
                    <div className="relative group animate-in fade-in slide-in-from-right-8 duration-1000 delay-200">
                        {interactiveComponent ? (
                            <div className="relative aspect-[4/3] rounded-xl bg-neutral-900 border border-white/10 overflow-hidden shadow-2xl ring-1 ring-white/5 group-hover:ring-[hsl(var(--color-intent))]/50 transition-all">
                                {interactiveComponent}
                                {/* Subtle overlay to indicate it's a demo */}
                                <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/60 backdrop-blur text-[9px] text-white/50 rounded pointer-events-none uppercase tracking-widest">
                                    Interactive Demo
                                </div>
                            </div>
                        ) : (
                            <div className="relative aspect-[4/3] rounded-xl bg-neutral-900 border border-white/10 overflow-hidden shadow-2xl">
                                <div className="absolute inset-0 bg-gradient-to-br from-[hsl(var(--color-intent))]/5 to-transparent" />
                                
                                {/* Locked UI Overlay */}
                                <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10">
                                    <Lock className="w-12 h-12 text-white mb-4" />
                                    <p className="text-white font-mono text-sm uppercase tracking-widest">Login to Access Interface</p>
                                </div>

                                {/* UI Mockup */}
                                <div className="p-6 h-full flex flex-col opacity-60 group-hover:opacity-30 transition-opacity duration-500">
                                    <div className="h-8 w-1/3 bg-white/10 rounded mb-8" />
                                    <div className="flex-1 grid grid-cols-2 gap-4">
                                        <div className="bg-white/5 rounded border border-white/5" />
                                        <div className="bg-white/5 rounded border border-white/5" />
                                        <div className="col-span-2 bg-white/5 rounded border border-white/5" />
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Decor */}
                        <div className="absolute -top-10 -right-10 w-64 h-64 bg-[hsl(var(--color-intent))] rounded-full blur-[100px] opacity-20 -z-10" />
                    </div>
                </div>
            </main>

            {/* FOOTER */}
            <footer className="py-12 border-t border-white/5 text-center text-neutral-600 text-sm">
                <p>Base44 Systems • {title} Module • Public Preview</p>
            </footer>
        </div>
    );
}