import React from 'react';
import { SiteHeader } from '@/components/site/SiteHeader';
import { SiteFooter } from '@/components/layout/SiteFooter';
import DepthBackground from '@/components/ui/design-system/DepthBackground';
import { cn } from '@/lib/utils';

export default function PublicLayout({ children, theme = 'cyan-500', className }) {
    return (
        <div className="min-h-screen bg-black text-neutral-200 font-sans selection:bg-[hsl(var(--color-intent))]/30 relative overflow-hidden flex flex-col">
            {/* Global Background */}
            <div className="absolute inset-0 z-0">
                <DepthBackground theme={theme} />
            </div>

            {/* Content Overlay */}
            <div className="relative z-10 flex flex-col min-h-screen">
                <SiteHeader />
                
                <main className={cn("flex-1", className)}>
                    {children}
                </main>

                <SiteFooter />
            </div>
        </div>
    );
}