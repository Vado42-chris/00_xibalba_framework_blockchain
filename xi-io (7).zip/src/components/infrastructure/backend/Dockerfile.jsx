# BASE IMAGE
FROM node:18-alpine

# WORKDIR
WORKDIR /app

# DEPENDENCIES
COPY package*.json ./
RUN npm install --production

# SOURCE CODE
COPY . .

# ENVIRONMENT
ENV NODE_ENV=production
ENV SERVICE_TYPE=deployment

# START
CMD ["npm", "run", "start:deployment"]