version: '3.8'

services:
  # Load Balancer & Static File Server
  obsidian-os-nginx:
    container_name: xibalba-frontend
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl.conf:/etc/nginx/ssl.conf:ro
      # - ./certs:/etc/nginx/certs:ro # Commented out until certs exist
      - base44_frontend:/usr/share/nginx/html:ro
    depends_on:
      - obsidian-os-backend
      - obsidian-os-ai
      - obsidian-os-collab
    networks:
      - obsidian-net

  # Main Backend API
  obsidian-os-backend:
    container_name: xibalba-backend
    build:
      context: ./backend
      dockerfile: Dockerfile
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgres://postgres:password@obsidian-os-postgres:5432/obsidian
      - REDIS_URL=redis://obsidian-os-redis:6379
    depends_on:
      - obsidian-os-postgres
      - obsidian-os-redis
    networks:
      - obsidian-net

  # AI & Analytics Service
  obsidian-os-ai:
    container_name: xibalba-analytics
    build:
      context: ./backend
      dockerfile: Dockerfile.analytics
    environment:
      - SERVICE_TYPE=ai
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    depends_on:
      - obsidian-os-redis
    networks:
      - obsidian-net

  # Real-Time Collaboration Service
  obsidian-os-collab:
    container_name: xibalba-collab
    build:
      context: ./backend
      dockerfile: Dockerfile.collaboration
    environment:
      - SERVICE_TYPE=collab
    depends_on:
      - obsidian-os-redis
    networks:
      - obsidian-net

  # WebSocket Gateway
  obsidian-os-ws-gateway:
    container_name: xibalba-ws-gateway
    build:
      context: ./backend
      dockerfile: Dockerfile.ws-gateway
    environment:
      - SERVICE_TYPE=ws-gateway
    networks:
      - obsidian-net

  # Deployment Agent
  obsidian-os-deployment:
    container_name: xibalba-deployment
    build:
      context: ./backend
      dockerfile: Dockerfile.deployment
    environment:
      - SERVICE_TYPE=deployment
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock # Needs docker access
    networks:
      - obsidian-net

  # Database
  obsidian-os-postgres:
    image: postgres:14-alpine
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=obsidian
    volumes:
      - postgres_data:/var/lib/postgresql/data
    networks:
      - obsidian-net

  # Cache & Pub/Sub
  obsidian-os-redis:
    image: redis:alpine
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
    networks:
      - obsidian-net

volumes:
  postgres_data:
  redis_data:
  base44_frontend:

networks:
  obsidian-net:
    driver: bridge