# Local Development Instructions

To run the Obsidian OS locally and fix the Base44 404 error:

1.  **Build the Frontend**:
    ```bash
    cd "00_xibalba_alpaca/_incoming/dec_18_2025_baseline/xi-io (2)"
    npm install
    npx vite build
    ```

2.  **Update the Container**:
    ```bash
    docker cp dist/. xibalba-frontend:/usr/share/nginx/html
    docker restart xibalba-frontend
    ```

3.  **Verify**:
    Open http://localhost in your browser.

**Note**: The app is now using `components/api/LocalClient.js` to mock Base44 SDK calls, preventing redirects to the production platform.