#!/bin/bash

# Obsidian OS Backend Preparation Script
# Copies the backend source code into the build context

# Define paths
SOURCE_DIR="../../backend"
DEST_DIR="./backend"

echo "Preparing backend build context..."

# Check if source exists
if [ ! -d "$SOURCE_DIR" ]; then
  echo "Error: Backend source directory not found at $SOURCE_DIR"
  echo "Please ensure you are running this from components/infrastructure/ and the backend code is in the project root."
  exit 1
fi

# Clean and recreate destination
echo "Cleaning old build context..."
rm -rf "$DEST_DIR/src" "$DEST_DIR/package.json" "$DEST_DIR/package-lock.json" 2>/dev/null

echo "Copying source code..."
# Copy package files
cp "$SOURCE_DIR/package.json" "$DEST_DIR/"
cp "$SOURCE_DIR/package-lock.json" "$DEST_DIR/" 2>/dev/null

# Copy source directory
cp -r "$SOURCE_DIR"/* "$DEST_DIR/"

echo "✅ Backend build context prepared in $DEST_DIR"