bash
#!/bin/bash
# Build minimal immutable OS image

echo "🏗️ Building Xibalba Linux Image..."

docker build \
    -t obsidian-os:latest \
    -f components/infrastructure/Dockerfile.obsidian-os \
    .

echo "✅ Build complete."
