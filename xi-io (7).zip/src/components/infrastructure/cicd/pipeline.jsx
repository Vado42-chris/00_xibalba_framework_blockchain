yaml
name: Obsidian OS CI/CD

on:
  push:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Run Tests
      run: |
        docker-compose run --rm obsidian-os-backend npm test
        docker-compose run --rm obsidian-os-nginx npm test

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Build Xibalba Linux Image
      run: ./components/infrastructure/cicd/build-xibalba-linux.sh
    - name: Build Base44 Frontend
      run: docker-compose run --rm obsidian-os-nginx npm run build

  deploy-staging:
    needs: build
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Deploy to Staging
      run: ./components/infrastructure/cicd/deploy.sh staging

  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - name: Deploy to Production
      run: ./components/infrastructure/cicd/deploy.sh production
    - name: Monitor Health
      run: ./components/infrastructure/cicd/monitor.sh
    - name: Rollback on Failure
      if: failure()
      run: ./components/infrastructure/cicd/rollback.sh
