bash
#!/bin/bash
# Atomic Rollback Script

echo "🚨 INITIATING ROLLBACK..."

# 1. Identify previous image tag
PREV_TAG=$(git describe --abbrev=0 --tags HEAD^)

echo "Reverting to tag: $PREV_TAG"

# 2. Update docker-compose with previous tag
sed -i "s/obsidian-os:latest/obsidian-os:$PREV_TAG/g" components/infrastructure/docker-compose.yml

# 3. Force recreate containers
docker-compose up -d --force-recreate

echo "✅ Rollback complete. System restored to $PREV_TAG."
