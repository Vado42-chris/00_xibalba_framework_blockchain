bash
#!/bin/bash
# CI/CD Deployment Script

ENV=$1

if [ -z "$ENV" ]; then
    echo "Usage: ./deploy.sh [staging|production]"
    exit 1
fi

echo "🚀 Deploying to $ENV..."

# 1. Pull latest images
docker-compose pull

# 2. Backup Database
echo "💾 Backing up database..."
docker-compose exec -T obsidian-os-postgres pg_dump -U postgres obsidian > backup_$(date +%s).sql

# 3. Rolling Update
echo "🔄 Performing rolling update..."
docker-compose up -d --no-deps --scale obsidian-os-backend=2 --no-recreate obsidian-os-backend

# Wait for health check
sleep 10

# Remove old containers
docker-compose up -d --no-deps --scale obsidian-os-backend=1 --no-recreate obsidian-os-backend

echo "✅ Deployment to $ENV complete!"
