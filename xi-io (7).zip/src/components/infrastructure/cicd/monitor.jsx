bash
#!/bin/bash
# Health Monitor Script

echo "🩺 Monitoring System Health..."

MAX_RETRIES=5
COUNT=0

while [ $COUNT -lt $MAX_RETRIES ]; do
    HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" https://localhost/api/system/health)
    
    if [ "$HTTP_STATUS" == "200" ]; then
        echo "✅ System is Healthy!"
        exit 0
    fi
    
    echo "⚠️ Health check failed (Status: $HTTP_STATUS). Retrying in 5s..."
    sleep 5
    let COUNT=COUNT+1
done

echo "❌ System Unhealthy after $MAX_RETRIES attempts."
exit 1
