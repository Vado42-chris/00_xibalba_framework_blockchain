#!/bin/bash

# Obsidian OS Bootstrap Script
# v1.0.0 - Production Release - REAL EXECUTION

echo "Setting up Obsidian OS infrastructure..."

# 1. Start the stack (Actually run Docker)
echo "[+] Starting Docker Containers..."
docker-compose up -d

# 2. Wait for health
echo "Waiting for services to stabilize..."
sleep 5

# 3. Verify
echo "Checking running containers..."
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

# 4. Finalize
echo ""
echo "✅ Obsidian OS infrastructure is running."
echo "You can now run the 'docker cp' command to deploy your UI."