import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer, ChartFrame 
} from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { TimeGraph } from '@/components/ui/design-system/Infographics';
import { 
    Wallet, TrendingUp, ArrowUpRight, ArrowDownRight, 
    Bitcoin, RefreshCw, Plus, PieChart, Activity, Zap,
    ArrowRightLeft, Landmark
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { cn } from '@/lib/utils';
import AssetModal from '@/components/finance/AssetModal';

// Mock Data
const PRICE_DATA = [
    { t: '00:00', value: 42000 }, { t: '04:00', value: 42200 },
    { t: '08:00', value: 43500 }, { t: '12:00', value: 43800 },
    { t: '16:00', value: 44000 }, { t: '20:00', value: 45500 },
    { t: '24:00', value: 46100 },
];

/* -------------------------------------------------------------------------- */
/*                                SUB-COMPONENTS                              */
/* -------------------------------------------------------------------------- */

const AssetList = ({ assets, selectedId, onSelect, onNew }) => {
    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b border-white/5 space-y-4">
                <div className="flex justify-between items-center">
                    <OrientingText className="tracking-widest font-bold text-emerald-500">TREASURY</OrientingText>
                    <Button size="sm" onClick={onNew} className="h-6 text-[10px] bg-emerald-500 hover:bg-emerald-600 text-white gap-1">
                        <Plus className="w-3 h-3" /> ADD ASSET
                    </Button>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                    <div className="p-2 bg-neutral-900/50 rounded border border-white/5">
                        <StateText className="opacity-50 text-[9px]">Total Allocation</StateText>
                        <div className="text-white font-mono text-sm">${assets.reduce((a,c) => a + (c.value_usd||0), 0).toLocaleString()}</div>
                    </div>
                    <div className="p-2 bg-neutral-900/50 rounded border border-white/5">
                        <StateText className="opacity-50 text-[9px]">24h Change</StateText>
                        <div className="text-emerald-500 font-mono text-sm flex items-center gap-1">+2.4% <TrendingUp className="w-3 h-3" /></div>
                    </div>
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin scrollbar-thumb-white/10">
                {assets.map(asset => (
                    <SystemCard
                        key={asset.id}
                        title={asset.symbol}
                        subtitle={asset.name}
                        metric={`$${asset.value_usd?.toLocaleString()}`}
                        status="active"
                        active={selectedId === asset.id}
                        onClick={() => onSelect(asset)}
                        icon={Wallet}
                    >
                        <StateText className="text-[9px] opacity-50 text-right mt-1">{asset.balance} units</StateText>
                    </SystemCard>
                ))}
            </div>
        </div>
    );
};

const AIPortfolioManager = ({ assets }) => {
    return (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
             <div className="p-4 bg-[hsl(var(--color-execution))]/5 border border-[hsl(var(--color-execution))]/20 rounded-lg">
                <div className="flex items-center gap-2 mb-3 text-[hsl(var(--color-execution))]">
                    <Zap className="w-4 h-4" />
                    <IntentText className="font-bold">Portfolio Optimization</IntentText>
                </div>
                <StateText className="opacity-80 leading-relaxed mb-4">
                    Current allocation is heavily weighted towards <strong>Volatile Assets</strong>. 
                    Rebalancing 15% into Stablecoins would improve risk-adjusted returns by an estimated 4.2%.
                </StateText>
                <Button className="w-full bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black">
                    Execute Rebalance Strategy
                </Button>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <Layer level="state" className="p-3">
                     <OrientingText className="mb-2">MARKET SENTIMENT</OrientingText>
                     <div className="text-2xl font-bold text-emerald-500">BULLISH</div>
                     <StateText className="opacity-50">Score: 78/100</StateText>
                </Layer>
                <Layer level="state" className="p-3">
                     <OrientingText className="mb-2">EXPOSURE RISK</OrientingText>
                     <div className="text-2xl font-bold text-orange-500">MODERATE</div>
                     <StateText className="opacity-50">Beta: 1.24</StateText>
                </Layer>
            </div>

            <div className="space-y-2">
                <OrientingText>PREDICTIVE FORECAST (7D)</OrientingText>
                 <div className="h-40 w-full bg-neutral-900/30 rounded border border-white/5 p-2">
                     <TimeGraph data={PRICE_DATA} dataKey="value" category="execution" height={140} />
                </div>
            </div>
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                                MAIN COMPONENT                              */
/* -------------------------------------------------------------------------- */

export default function FinanceManager() {
    const [selectedAsset, setSelectedAsset] = useState(null);
    const [viewMode, setViewMode] = useState('overview'); 
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingAsset, setEditingAsset] = useState(null);

    const { data: assets = [] } = useQuery({
        queryKey: ['assets'],
        queryFn: () => base44.entities.Asset.list(),
        initialData: []
    });

    const { data: serviceRequests = [] } = useQuery({
        queryKey: ['service_requests_finance'],
        queryFn: () => base44.entities.SupportTicket.filter({ category: 'service_request', status: 'open' }),
        initialData: []
    });

    // Extract price from description which has "Price: $1499" or "Price: Custom"
    const pendingCharges = serviceRequests.map(ticket => {
        const match = ticket.description.match(/Price: \$([\d,]+)/);
        return match ? parseFloat(match[1].replace(/,/g, '')) : 0;
    }).filter(p => p > 0);

    const totalPending = pendingCharges.reduce((a, b) => a + b, 0);

    const handleSelect = (asset) => {
        setSelectedAsset(asset);
        // Automatically switch to overview of selected asset if we were in portfolio mode
        if (viewMode === 'portfolio') setViewMode('overview');
    };

    return (
        <>
            <FluidGrid
                left={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="state" dominance="dominant" className="border-r border-white/5 h-full p-0">
                            <AssetList 
                                assets={assets}
                                selectedId={selectedAsset?.id}
                                onSelect={handleSelect}
                                onNew={() => { setEditingAsset(null); setIsModalOpen(true); }}
                            />
                        </Quadrant>
                    </QuadrantGrid>
                }
                right={
                    <QuadrantGrid className="p-0 h-full gap-0">
                        <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col">
                            {/* Header */}
                            <SystemDetailHeader
                                title={selectedAsset ? selectedAsset.name : 'Portfolio Overview'}
                                subtitle={selectedAsset ? selectedAsset.symbol : 'Global Assets'}
                                category="FINANCE"
                                icon={Wallet}
                            >
                                <Tabs value={viewMode} onValueChange={setViewMode}>
                                    <TabsList className="bg-neutral-950 border border-white/10 h-8">
                                        <TabsTrigger value="overview" className="text-xs h-6">Overview</TabsTrigger>
                                        <TabsTrigger value="swap" className="text-xs h-6">Trade</TabsTrigger>
                                        <TabsTrigger value="pending" className="text-xs h-6">
                                            Charges {totalPending > 0 && <span className="ml-1 w-2 h-2 rounded-full bg-orange-500" />}
                                        </TabsTrigger>
                                        <TabsTrigger value="ai" className="text-xs h-6 data-[state=active]:text-emerald-500">
                                            <Zap className="w-3 h-3 mr-1" /> Forecast
                                        </TabsTrigger>
                                    </TabsList>
                                </Tabs>
                            </SystemDetailHeader>

                            {/* Content */}
                            <div className="flex-1 overflow-y-auto p-6 bg-neutral-950/50">
                                {viewMode === 'overview' && (
                                    <div className="space-y-6 animate-in fade-in duration-300">
                                        <div className="h-64 w-full bg-neutral-900/30 rounded border border-white/5 p-4">
                                            <ChartFrame label="PRICE ACTION" metric={selectedAsset ? `$${selectedAsset.value_usd.toLocaleString()}` : "$46,100.00"} trend="+7.6%" category="execution">
                                                <TimeGraph data={PRICE_DATA} dataKey="value" category="execution" height={200} />
                                            </ChartFrame>
                                        </div>
                                        
                                        <div className="grid grid-cols-3 gap-4">
                                            <Layer level="state" className="p-3 text-center">
                                                <StateText className="opacity-50 text-[9px] uppercase tracking-wider">Volume (24h)</StateText>
                                                <IntentText className="font-mono">$1.2B</IntentText>
                                            </Layer>
                                            <Layer level="state" className="p-3 text-center">
                                                <StateText className="opacity-50 text-[9px] uppercase tracking-wider">Circulating</StateText>
                                                <IntentText className="font-mono">19.2M</IntentText>
                                            </Layer>
                                            <Layer level="state" className="p-3 text-center">
                                                <StateText className="opacity-50 text-[9px] uppercase tracking-wider">Market Cap</StateText>
                                                <IntentText className="font-mono">$840B</IntentText>
                                            </Layer>
                                        </div>
                                    </div>
                                )}

                                {viewMode === 'ai' && (
                                    <AIPortfolioManager assets={assets} />
                                )}

                                {viewMode === 'pending' && (
                                    <div className="space-y-6 animate-in fade-in duration-300">
                                        <div className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-lg flex items-center justify-between">
                                            <div>
                                                <div className="text-orange-400 font-bold mb-1">Pending Service Charges</div>
                                                <div className="text-xs text-orange-300/70">Estimated cost for active service requests.</div>
                                            </div>
                                            <div className="text-2xl font-mono text-orange-400 font-bold">
                                                ${totalPending.toLocaleString()}
                                            </div>
                                        </div>

                                        <div className="space-y-2">
                                            <StateText className="opacity-50 text-xs uppercase tracking-wider">Active Requests</StateText>
                                            {serviceRequests.length === 0 ? (
                                                <div className="text-center py-8 opacity-30 text-sm">No pending charges.</div>
                                            ) : (
                                                serviceRequests.map(req => {
                                                    const priceMatch = req.description.match(/Price: ([^\n]+)/);
                                                    const price = priceMatch ? priceMatch[1] : 'Custom';
                                                    return (
                                                        <div key={req.id} className="p-3 bg-neutral-900/50 border border-white/5 rounded flex justify-between items-center">
                                                            <div>
                                                                <div className="text-sm font-medium text-white">{req.subject.replace('Service Request: ', '')}</div>
                                                                <div className="text-xs text-neutral-500">Ticket #{req.id.slice(0,8)}</div>
                                                            </div>
                                                            <div className="font-mono text-white">{price}</div>
                                                        </div>
                                                    );
                                                })
                                            )}
                                        </div>
                                    </div>
                                )}

                                {viewMode === 'swap' && (
                                    <div className="max-w-md mx-auto space-y-4 animate-in slide-in-from-bottom-4 duration-300 mt-8">
                                        <div className="p-4 bg-neutral-900 border border-white/10 rounded-lg">
                                            <div className="flex justify-between mb-2">
                                                <StateText>Pay</StateText>
                                                <StateText className="font-mono">Balance: 2.4</StateText>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <Input className="text-2xl font-mono bg-transparent border-none h-auto p-0 focus-visible:ring-0" placeholder="0.00" />
                                                <div className="flex items-center gap-2 bg-neutral-800 px-3 py-1.5 rounded-full shrink-0">
                                                    <div className="w-5 h-5 rounded-full bg-orange-500"></div>
                                                    <span className="font-bold text-sm">BTC</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex justify-center -my-2 relative z-10">
                                            <div className="bg-neutral-800 p-2 rounded-full border border-white/10">
                                                <ArrowDownRight className="w-4 h-4" />
                                            </div>
                                        </div>

                                        <div className="p-4 bg-neutral-900 border border-white/10 rounded-lg">
                                            <div className="flex justify-between mb-2">
                                                <StateText>Receive</StateText>
                                                <StateText className="font-mono">Est: $0.00</StateText>
                                            </div>
                                            <div className="flex items-center gap-4">
                                                <Input className="text-2xl font-mono bg-transparent border-none h-auto p-0 focus-visible:ring-0" placeholder="0.00" />
                                                <div className="flex items-center gap-2 bg-neutral-800 px-3 py-1.5 rounded-full shrink-0">
                                                    <div className="w-5 h-5 rounded-full bg-blue-500"></div>
                                                    <span className="font-bold text-sm">USDC</span>
                                                </div>
                                            </div>
                                        </div>

                                        <Button className="w-full h-12 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-lg">
                                            SWAP
                                        </Button>
                                    </div>
                                )}
                            </div>
                        </Quadrant>
                    </QuadrantGrid>
                }
            />
            <AssetModal 
                open={isModalOpen} 
                onOpenChange={setIsModalOpen} 
                asset={editingAsset} 
            />
        </>
    );
}