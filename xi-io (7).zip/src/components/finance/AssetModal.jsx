import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function AssetModal({ open, onOpenChange, asset }) {
    const queryClient = useQueryClient();
    const { register, handleSubmit, reset, setValue } = useForm();

    useEffect(() => {
        if (asset) {
            setValue('name', asset.name);
            setValue('symbol', asset.symbol);
            setValue('type', asset.type);
            setValue('balance', asset.balance);
            setValue('value_usd', asset.value_usd);
        } else {
            reset({ type: 'crypto' });
        }
    }, [asset, open, setValue, reset]);

    const mutation = useMutation({
        mutationFn: (data) => {
            const payload = {
                ...data,
                balance: parseFloat(data.balance),
                value_usd: parseFloat(data.value_usd)
            };
            if (asset) {
                return base44.entities.Asset.update(asset.id, payload);
            }
            return base44.entities.Asset.create(payload);
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['assets']);
            toast.success(asset ? "Asset updated" : "Asset added");
            onOpenChange(false);
            reset();
        }
    });

    const onSubmit = (data) => mutation.mutate(data);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border-white/10 text-white sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>{asset ? 'Edit Asset' : 'Add Asset'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Name</Label>
                            <Input {...register('name', { required: true })} className="bg-neutral-950 border-white/10" placeholder="Bitcoin" />
                        </div>
                        <div className="space-y-2">
                            <Label>Symbol</Label>
                            <Input {...register('symbol', { required: true })} className="bg-neutral-950 border-white/10" placeholder="BTC" />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label>Type</Label>
                        <Select onValueChange={(v) => setValue('type', v)} defaultValue={asset?.type || 'crypto'}>
                            <SelectTrigger className="bg-neutral-950 border-white/10">
                                <SelectValue placeholder="Type" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="crypto">Crypto</SelectItem>
                                <SelectItem value="fiat">Fiat</SelectItem>
                                <SelectItem value="commodity">Commodity</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Balance</Label>
                            <Input type="number" step="any" {...register('balance', { required: true })} className="bg-neutral-950 border-white/10" placeholder="0.00" />
                        </div>
                        <div className="space-y-2">
                            <Label>Value (USD)</Label>
                            <Input type="number" step="any" {...register('value_usd', { required: true })} className="bg-neutral-950 border-white/10" placeholder="0.00" />
                        </div>
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button type="submit" className="bg-[hsl(var(--color-execution))] text-white">{asset ? 'Update' : 'Add'}</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}