import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Box, Image as ImageIcon, Video, Music, Smartphone, 
    Cpu, Layers, Command, Save, FolderOpen, Wand2,
    Settings, Share2, Maximize2, Sparkles, Database
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import MediaPreview from './MediaPreview';
import AssetDocket from './AssetDocket';
import AIAssistant from '@/components/assistants/AIAssistant';
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const FORGE_MODES = [
    { id: '3d', label: '3D Asset', icon: Box, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { id: 'image', label: 'Image', icon: ImageIcon, color: 'text-pink-500', bg: 'bg-pink-500/10' },
    { id: 'video', label: 'Video', icon: Video, color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { id: 'audio', label: 'Sound', icon: Music, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { id: 'app', label: 'Application', icon: Smartphone, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { id: 'code', label: 'Code', icon: Cpu, color: 'text-neutral-500', bg: 'bg-neutral-500/10' },
];

export default function ForgeHub() {
    const [activeMode, setActiveMode] = useState('3d');
    const [prompt, setPrompt] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);
    const [generatedAsset, setGeneratedAsset] = useState(null);
    const [showDocket, setShowDocket] = useState(false);
    
    // Generation Parameters
    const [params, setParams] = useState({
        quality: 'high',
        dimensions: '1024x1024',
        duration: 10,
        polyCount: 'mid',
        targetFramework: 'React'
    });

    const handleGenerate = async () => {
        if (!prompt.trim()) return;
        setIsGenerating(true);
        setGeneratedAsset(null);

        try {
            // Simulation of generation based on mode
            // In a real app, this would call specific endpoints
            
            await new Promise(r => setTimeout(r, 2000)); // Simulate work

            let result = {
                type: activeMode,
                timestamp: new Date().toISOString(),
                prompt: prompt,
            };

            if (activeMode === 'image') {
                const { url } = await base44.integrations.Core.GenerateImage({ prompt });
                result.url = url;
            } else if (activeMode === '3d') {
                // Simulate 3D generation result
                result.url = "https://threejs.org/examples/models/gltf/RobotExpressive/RobotExpressive.glb"; // Placeholder
                result.preview = "3d_model_viewer";
            } else if (activeMode === 'app' || activeMode === 'code') {
                 // Call AI Gateway for UI generation
                 const { data } = await base44.functions.invoke('aiGenerate', {
                     intent: 'generate_ui_code',
                     input: prompt,
                     context: { mode: activeMode, framework: params.targetFramework }
                 });
                 if (data.success && data.output) {
                     result.code = typeof data.output === 'string' ? data.output : JSON.stringify(data.output);
                     result.preview = 'code_preview';
                     result.url = "generated_code"; // Marker for MediaPreview
                 } else {
                     throw new Error("AI Code Generation failed");
                 }
            } else {
                // Generic fallback
                result.url = "https://source.unsplash.com/random/800x600/?abstract";
            }

            setGeneratedAsset(result);
            toast.success(`${FORGE_MODES.find(m => m.id === activeMode).label} Generated`);
        } catch (error) {
            toast.error("Generation failed: " + error.message);
        } finally {
            setIsGenerating(false);
        }
    };

    const handleSaveToDocket = () => {
        if (!generatedAsset) return;
        // Logic to save to AssetDocket would go here
        toast.success("Asset saved to Project Docket");
    };

    const ActiveIcon = FORGE_MODES.find(m => m.id === activeMode)?.icon || Box;

    return (
        <div className="flex h-full bg-black text-white overflow-hidden">
            
            {/* LEFT: CONTROLS & INPUT */}
            <div className="w-[400px] border-r border-white/10 flex flex-col bg-neutral-950/50 backdrop-blur-xl z-10">
                {/* Header */}
                <div className="p-4 border-b border-white/10 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Wand2 className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                        <span className="font-bold tracking-widest text-sm">PROMPT FORGE</span>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => setShowDocket(!showDocket)}>
                        <FolderOpen className={cn("w-4 h-4", showDocket ? "text-[hsl(var(--color-intent))]" : "text-neutral-500")} />
                    </Button>
                </div>

                {/* Mode Selector */}
                <div className="p-4 grid grid-cols-3 gap-2">
                    {FORGE_MODES.map(mode => (
                        <button
                            key={mode.id}
                            onClick={() => setActiveMode(mode.id)}
                            className={cn(
                                "flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-200 gap-2",
                                activeMode === mode.id 
                                    ? `bg-neutral-900 border-[hsl(var(--color-intent))] shadow-[0_0_15px_-5px_hsl(var(--color-intent))]` 
                                    : "bg-neutral-900/50 border-white/5 hover:bg-neutral-800 hover:border-white/10"
                            )}
                        >
                            <mode.icon className={cn("w-5 h-5", activeMode === mode.id ? "text-[hsl(var(--color-intent))]" : "text-neutral-500")} />
                            <span className={cn("text-[10px] font-medium uppercase", activeMode === mode.id ? "text-white" : "text-neutral-500")}>
                                {mode.label}
                            </span>
                        </button>
                    ))}
                </div>

                {/* Parameters Area */}
                <ScrollArea className="flex-1 px-4">
                    <div className="space-y-6 py-4">
                        {activeMode === 'code' ? (
                            <div className="space-y-2">
                                <label className="text-[10px] font-mono text-neutral-500 uppercase">AI Code Generator</label>
                                <AIAssistant mode={activeMode} onApplyPrompt={setPrompt} />
                            </div>
                        ) : (
                            <div className="space-y-2">
                                <label className="text-[10px] font-mono text-neutral-500 uppercase">Prompt Engineering</label>
                                <Textarea 
                                    placeholder={`Describe your ${activeMode} asset in detail...`}
                                    className="min-h-[120px] bg-neutral-900 border-white/10 text-sm resize-none focus:border-[hsl(var(--color-intent))]"
                                    value={prompt}
                                    onChange={(e) => setPrompt(e.target.value)}
                                />
                            </div>
                        )}

                        {/* Dynamic Controls based on Mode */}
                        <div className="space-y-4 border-t border-white/5 pt-4">
                            <label className="text-[10px] font-mono text-neutral-500 uppercase flex items-center gap-2">
                                <Settings className="w-3 h-3" /> Configuration
                            </label>
                            
                            {activeMode === '3d' && (
                                <>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-xs text-neutral-400">
                                            <span>Polygon Count</span>
                                            <span>{params.polyCount}</span>
                                        </div>
                                        <Tabs value={params.polyCount} onValueChange={v => setParams({...params, polyCount: v})}>
                                            <TabsList className="w-full bg-neutral-900">
                                                <TabsTrigger value="low" className="flex-1 text-[10px]">Low Poly</TabsTrigger>
                                                <TabsTrigger value="mid" className="flex-1 text-[10px]">Mid</TabsTrigger>
                                                <TabsTrigger value="high" className="flex-1 text-[10px]">High Res</TabsTrigger>
                                            </TabsList>
                                        </Tabs>
                                    </div>
                                </>
                            )}
                            
                            {activeMode === 'image' && (
                                <div className="space-y-2">
                                    <div className="flex justify-between text-xs text-neutral-400">
                                        <span>Aspect Ratio</span>
                                        <span>1:1</span>
                                    </div>
                                    <div className="grid grid-cols-3 gap-2">
                                        {['1:1', '16:9', '9:16'].map(r => (
                                            <button key={r} className="p-2 bg-neutral-900 border border-white/5 rounded text-xs hover:bg-neutral-800">{r}</button>
                                        ))}
                                    </div>
                                </div>
                            )}

                             {activeMode === 'video' && (
                                <div className="space-y-2">
                                    <div className="flex justify-between text-xs text-neutral-400">
                                        <span>Duration (sec)</span>
                                        <span>{params.duration}s</span>
                                    </div>
                                    <Slider 
                                        defaultValue={[10]} 
                                        max={60} 
                                        step={1} 
                                        onValueChange={(v) => setParams({...params, duration: v[0]})} 
                                        className="py-4"
                                    />
                                </div>
                            )}

                            {(activeMode === 'code' || activeMode === 'app') && (
                                <div className="space-y-2">
                                    <div className="flex justify-between text-xs text-neutral-400">
                                        <span>Target Framework</span>
                                        <span>{params.targetFramework}</span>
                                    </div>
                                    <div className="grid grid-cols-3 gap-2">
                                        {['React', 'Vue', 'Node.js'].map(fw => (
                                            <button 
                                                key={fw} 
                                                onClick={() => setParams({...params, targetFramework: fw})}
                                                className={`p-2 border rounded text-[10px] ${params.targetFramework === fw ? 'bg-[hsl(var(--color-intent))] text-black border-[hsl(var(--color-intent))]' : 'bg-neutral-900 border-white/10 hover:bg-neutral-800'}`}
                                            >
                                                {fw}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </ScrollArea>

                {/* Generate Button */}
                <div className="p-4 border-t border-white/10 bg-neutral-950">
                    <Button 
                        onClick={handleGenerate} 
                        disabled={isGenerating || !prompt}
                        className={cn(
                            "w-full h-12 text-sm font-bold tracking-wider uppercase transition-all",
                            isGenerating 
                                ? "bg-neutral-800 text-neutral-500" 
                                : "bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 hover:shadow-[0_0_20px_hsl(var(--color-intent))]"
                        )}
                    >
                        {isGenerating ? (
                            <span className="flex items-center gap-2">
                                <Sparkles className="w-4 h-4 animate-spin" /> Forging...
                            </span>
                        ) : (
                            <span className="flex items-center gap-2">
                                <Wand2 className="w-4 h-4" /> Forge Asset
                            </span>
                        )}
                    </Button>
                </div>
            </div>

            {/* RIGHT: PREVIEW & DOCKET */}
            <div className="flex-1 relative flex flex-col">
                {/* Main Preview Stage */}
                <div className="flex-1 bg-neutral-950 relative overflow-hidden flex items-center justify-center p-8">
                    <div className="absolute inset-0 opacity-20 pointer-events-none" 
                        style={{ backgroundImage: 'radial-gradient(circle at center, #333 1px, transparent 1px)', backgroundSize: '20px 20px' }} 
                    />
                    
                    <AnimatePresence mode="wait">
                        {generatedAsset ? (
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                exit={{ opacity: 0, scale: 1.1 }}
                                className="w-full h-full max-w-4xl max-h-[80vh] relative group"
                            >
                                <MediaPreview asset={generatedAsset} activeMode={activeMode} />
                                
                                {/* Overlay Actions */}
                                <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Button size="icon" variant="secondary" className="bg-black/50 backdrop-blur text-white border border-white/10">
                                        <Maximize2 className="w-4 h-4" />
                                    </Button>
                                    <Button size="icon" variant="secondary" className="bg-black/50 backdrop-blur text-white border border-white/10">
                                        <Share2 className="w-4 h-4" />
                                    </Button>
                                    <Button 
                                        size="icon" 
                                        variant="default" 
                                        onClick={handleSaveToDocket}
                                        className="bg-[hsl(var(--color-execution))] text-black"
                                    >
                                        <Save className="w-4 h-4" />
                                    </Button>
                                </div>
                            </motion.div>
                        ) : (
                            <motion.div 
                                initial={{ opacity: 0 }} 
                                animate={{ opacity: 1 }}
                                className="text-center space-y-4 opacity-30"
                            >
                                <div className="w-24 h-24 rounded-full border-2 border-dashed border-white flex items-center justify-center mx-auto">
                                    <ActiveIcon className="w-10 h-10 text-white" />
                                </div>
                                <p className="text-sm font-mono uppercase tracking-widest">
                                    Ready to Forge {FORGE_MODES.find(m => m.id === activeMode).label}
                                </p>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                {/* Docket Drawer */}
                <AnimatePresence>
                    {showDocket && (
                        <motion.div 
                            initial={{ y: "100%" }}
                            animate={{ y: 0 }}
                            exit={{ y: "100%" }}
                            transition={{ type: "spring", damping: 20 }}
                            className="h-64 border-t border-white/10 bg-neutral-900/80 backdrop-blur-xl absolute bottom-0 left-0 right-0 z-20 flex flex-col"
                        >
                            <div className="p-2 border-b border-white/5 flex items-center justify-between">
                                <div className="flex items-center gap-2 px-2">
                                    <Database className="w-4 h-4 text-[hsl(var(--color-active))]" />
                                    <span className="text-xs font-bold text-neutral-300">ASSET DOCKET</span>
                                </div>
                                <Button variant="ghost" size="sm" onClick={() => setShowDocket(false)} className="h-6 w-6 p-0 rounded-full hover:bg-white/10">
                                    <span className="sr-only">Close</span>
                                    ×
                                </Button>
                            </div>
                            <div className="flex-1 overflow-hidden">
                                <AssetDocket />
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
}