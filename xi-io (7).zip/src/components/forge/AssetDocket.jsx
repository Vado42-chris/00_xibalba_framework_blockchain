import React, { useEffect, useState } from 'react';
import { File, Box, Image, Video, Music, MoreVertical, Upload, Trash2 } from 'lucide-react';
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const TypeIcon = ({ type }) => {
    switch(type) {
        case '3d': return <Box className="w-4 h-4 text-blue-500" />;
        case 'image': return <Image className="w-4 h-4 text-pink-500" />;
        case 'video': return <Video className="w-4 h-4 text-purple-500" />;
        case 'audio': return <Music className="w-4 h-4 text-amber-500" />;
        default: return <File className="w-4 h-4 text-neutral-500" />;
    }
};

export default function AssetDocket({ projectId = 'current' }) {
    const [assets, setAssets] = useState([]);

    const fetchAssets = async () => {
        try {
            // In a real app, we'd fetch from FileRecord entity filtered by project
            // For now, we mock it or fetch a "FileRecord" list if available
            const files = await base44.entities.FileRecord.list('-created_date', 10);
            if (files.length > 0) {
                 setAssets(files.map(f => ({
                     id: f.id,
                     type: f.category || 'file',
                     name: f.name,
                     size: (f.size / 1024).toFixed(1) + 'KB',
                     date: new Date(f.updated_date).toLocaleTimeString()
                 })));
            } else {
                // Fallback Mock if empty
                setAssets([
                    { id: 1, type: '3d', name: 'Cyber_Helmet_v2.glb', size: '12MB', date: '2m ago' },
                    { id: 2, type: 'image', name: 'Neon_City_Concept.png', size: '4.2MB', date: '15m ago' }
                ]);
            }
        } catch (e) {
            console.error(e);
        }
    };

    // Real-time Sync for Assets
    useEffect(() => {
        fetchAssets(); // Initial load

        const interval = setInterval(async () => {
            try {
                const { data } = await base44.functions.invoke('collabSync', { projectId }, { method: 'GET', params: { projectId } });
                if (data.events) {
                    // Check for asset events
                    const assetEvents = data.events.filter(e => e.type === 'asset_update');
                    if (assetEvents.length > 0) {
                        // In a real app, we'd process the specific change. 
                        // Here we just re-fetch to stay in sync.
                        fetchAssets();
                    }
                }
            } catch (e) {}
        }, 5000); // Poll every 5s

        return () => clearInterval(interval);
    }, [projectId]);

    const handleUpload = async () => {
        // Simulation of upload + broadcast
        const newAsset = {
            name: `Asset_${Date.now()}.png`,
            category: 'image',
            size: 1024 * 500,
            url: 'http://placeholder',
            path: '/assets'
        };
        
        try {
            await base44.entities.FileRecord.create(newAsset);
            await base44.functions.invoke('collabSync', {
                project_id: projectId,
                type: 'asset_update',
                payload: { action: 'created', assetId: newAsset.name }
            });
            toast.success("Asset Uploaded");
            fetchAssets();
        } catch(e) {
            toast.error("Upload failed");
        }
    };

    return (
        <div className="w-full">
            <div className="flex items-center justify-between px-4 pb-2">
                <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest">Project Assets</span>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={handleUpload}>
                    <Upload className="w-3 h-3" />
                </Button>
            </div>
            <ScrollArea className="w-full whitespace-nowrap px-4 pb-4">
                <div className="flex w-max space-x-4">
                    {assets.map((asset) => (
                        <div 
                            key={asset.id} 
                            className="w-[200px] bg-neutral-950 border border-white/5 rounded-lg p-3 hover:border-white/20 transition-colors group cursor-pointer relative"
                        >
                            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                                <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-red-500/20 hover:text-red-500">
                                    <Trash2 className="w-3 h-3" />
                                </Button>
                            </div>
                            
                            <div className="flex flex-col gap-3">
                                <div className="w-full h-24 bg-neutral-900 rounded-md flex items-center justify-center overflow-hidden relative">
                                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/5 to-transparent" />
                                    <TypeIcon type={asset.type} />
                                </div>
                                <div>
                                    <h4 className="text-sm font-medium text-neutral-200 truncate">{asset.name}</h4>
                                    <div className="flex items-center justify-between mt-1 text-[10px] text-neutral-500 font-mono">
                                        <span>{asset.type.toUpperCase()}</span>
                                        <span>{asset.size}</span>
                                    </div>
                                    <div className="text-[9px] text-neutral-600 mt-1 truncate">
                                        {asset.date}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
                <ScrollBar orientation="horizontal" />
            </ScrollArea>
        </div>
    );
}