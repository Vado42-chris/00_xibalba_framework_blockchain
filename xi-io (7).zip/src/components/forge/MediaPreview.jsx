import React, { useRef, useEffect } from 'react';
import { Loader2, Play, Box } from 'lucide-react';
import * as THREE from 'three';

// A simple 3D viewer component
const ThreeViewer = ({ url }) => {
    const mountRef = useRef(null);

    useEffect(() => {
        if (!mountRef.current) return;

        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x111111);
        
        // Grid helper
        const gridHelper = new THREE.GridHelper(10, 10, 0x444444, 0x222222);
        scene.add(gridHelper);

        // Camera
        const camera = new THREE.PerspectiveCamera(75, mountRef.current.clientWidth / mountRef.current.clientHeight, 0.1, 1000);
        camera.position.z = 5;
        camera.position.y = 2;
        camera.lookAt(0, 0, 0);

        // Renderer
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
        mountRef.current.appendChild(renderer.domElement);

        // Simple Cube to represent the "generated model" since we don't have a real GLTF loader hooked up to an external URL in this demo
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const material = new THREE.MeshNormalMaterial({ wireframe: false });
        const cube = new THREE.Mesh(geometry, material);
        cube.position.y = 0.5;
        scene.add(cube);

        // Animation Loop
        const animate = () => {
            requestAnimationFrame(animate);
            cube.rotation.x += 0.01;
            cube.rotation.y += 0.01;
            renderer.render(scene, camera);
        };
        animate();

        // Cleanup
        return () => {
            if (mountRef.current) {
                mountRef.current.removeChild(renderer.domElement);
            }
        };
    }, [url]);

    return <div ref={mountRef} className="w-full h-full" />;
};

export default function MediaPreview({ asset, activeMode }) {
    if (!asset) return null;

    if (activeMode === '3d') {
        return (
            <div className="w-full h-full bg-black border border-white/10 rounded-xl overflow-hidden relative">
                <ThreeViewer url={asset.url} />
                <div className="absolute bottom-4 left-4 text-xs font-mono text-neutral-500 bg-black/50 px-2 py-1 rounded">
                    Interactive Preview
                </div>
            </div>
        );
    }

    if (activeMode === 'image') {
        return (
            <div className="w-full h-full flex items-center justify-center bg-black/50 rounded-xl border border-white/10">
                <img 
                    src={asset.url} 
                    alt={asset.prompt} 
                    className="max-w-full max-h-full object-contain rounded-lg shadow-2xl"
                />
            </div>
        );
    }

    if (activeMode === 'video') {
         return (
            <div className="w-full h-full flex items-center justify-center bg-black/50 rounded-xl border border-white/10 relative group">
                {/* Placeholder Video Player */}
                <div className="w-full h-full bg-neutral-900 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center backdrop-blur group-hover:bg-white/20 transition-colors cursor-pointer">
                        <Play className="w-6 h-6 text-white ml-1" />
                    </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                    <p className="text-sm font-medium text-white line-clamp-1">{asset.prompt}</p>
                </div>
            </div>
        );
    }

    if (activeMode === 'app') {
        return (
             <div className="w-full h-full flex items-center justify-center p-8">
                 <div className="w-[300px] h-[600px] bg-white rounded-[3rem] border-4 border-neutral-800 overflow-hidden shadow-2xl relative">
                     <div className="absolute top-0 left-0 right-0 h-6 bg-neutral-100 flex items-center justify-center z-10">
                        <div className="w-20 h-4 bg-black rounded-b-xl" />
                     </div>
                     <div className="w-full h-full pt-8 p-4 bg-neutral-50">
                         <div className="space-y-4 animate-pulse">
                             <div className="h-32 bg-neutral-200 rounded-xl" />
                             <div className="h-4 bg-neutral-200 rounded w-3/4" />
                             <div className="h-4 bg-neutral-200 rounded w-1/2" />
                             <div className="h-20 bg-neutral-200 rounded-xl" />
                         </div>
                     </div>
                 </div>
             </div>
        );
    }

    return (
        <div className="w-full h-full flex items-center justify-center text-neutral-500">
            Preview not available
        </div>
    );
}