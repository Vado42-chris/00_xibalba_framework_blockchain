export const API_CONFIG = {
  // Default to xi-io.com for development, or window.location.origin if hosted there
  baseURL: typeof window !== 'undefined' && window.location.hostname.includes('xi-io.com') 
    ? window.location.origin 
    : 'https://xi-io.com',
  endpoints: {
    health: '/health',
    login: '/api/login',
    register: '/api/register',
    projects: '/api/projects',
    sprints: '/api/sprints',
    tasks: '/api/sprints/tasks',
    dispatch: '/api/sprints/tasks',
    mcp: '/api/mcp/dispatches',
    keys: '/api/keys'
  }
};