import { API_CONFIG } from './config';
import { getAuthHeaders } from './auth';

async function apiCall(endpoint, options = {}) {
  const url = endpoint.startsWith('http') ? endpoint : `${API_CONFIG.baseURL}${endpoint}`;
  
  try {
      const response = await fetch(url, {
          ...options,
          headers: {
            ...getAuthHeaders(),
            ...options.headers,
          },
        }
      );
      
      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: 'Unknown error' }));
        throw new Error(error.error || `HTTP ${response.status}`);
      }
      
      return response.json();
  } catch (error) {
      console.error("API Call Failed:", error);
      throw error;
  }
}

export const api = {
  // Auth
  login: (username, password) =>
    apiCall('/api/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),
  
  register: (username, password, email) =>
    apiCall('/api/register', {
      method: 'POST',
      body: JSON.stringify({ username, password, email }),
    }),
  
  // Projects
  getProjects: () => apiCall('/api/projects'),
  createProject: (name) =>
    apiCall('/api/projects', {
      method: 'POST',
      body: JSON.stringify({ name }),
    }),
  getProjectStructure: (id) =>
    apiCall(`/api/projects/${id}/structure`),
  getProjectFiles: (id) =>
    apiCall(`/api/projects/${id}/files`),
  updateProjectFiles: (id, files) =>
    apiCall(`/api/projects/${id}/files`, {
      method: 'PUT',
      body: JSON.stringify({ files }),
    }),
  
  // Sprints
  getSprints: () => apiCall('/api/sprints'),
  createSprint: (name, projectId) =>
    apiCall('/api/sprints', {
      method: 'POST',
      body: JSON.stringify({ name, project_id: projectId }),
    }),
  getSprintTasks: (sprintId) =>
    apiCall(`/api/sprints/${sprintId}/tasks`),
  
  // Tasks
  getAllTasks: () => apiCall('/api/sprints/tasks'),
  createTask: (sprintId, title, description) =>
    apiCall('/api/sprints/tasks', {
      method: 'POST',
      body: JSON.stringify({ sprint_id: sprintId, title, description }),
    }),
  dispatchAgent: (taskId, agentType, dispatchTo = 'zed') =>
    apiCall(`/api/sprints/tasks/${taskId}/dispatch`, {
      method: 'POST',
      body: JSON.stringify({
        agent_type: agentType,
        dispatch_to: dispatchTo,
        execute_now: dispatchTo === 'web',
      }),
    }),
  
  // Dispatch Status
  getDispatches: (taskId) =>
    apiCall(`/api/mcp/dispatches${taskId ? `?task_id=${taskId}` : ''}`),
  
  // API Keys
  generateApiKey: (name = 'Zed Integration') =>
    apiCall('/api/keys/generate', {
      method: 'POST',
      body: JSON.stringify({ name }),
    }),
  getApiKeys: () => apiCall('/api/keys'),
  deleteApiKey: (id) =>
    apiCall(`/api/keys/${id}`, { method: 'DELETE' }),
};