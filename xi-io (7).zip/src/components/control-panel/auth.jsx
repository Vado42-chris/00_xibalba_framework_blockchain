export function getAuthHeaders() {
  const token = localStorage.getItem('xi_jwt');
  return {
    'Content-Type': 'application/json',
    ...(token && { 'Authorization': `Bearer ${token}` })
  };
}

export function setToken(token) {
  localStorage.setItem('xi_jwt', token);
}

export function clearToken() {
  localStorage.removeItem('xi_jwt');
}

export function isAuthenticated() {
    return !!localStorage.getItem('xi_jwt');
}