import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Search, Filter, Bird, Activity, Globe, Shield, FileCode, Zap, AlertTriangle } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { format } from 'date-fns';
import { InsightEngineModule } from '@/components/intelligence/InsightEngineModule';

const ActionIcon = ({ action, status }) => {
    if (status === 'failed') return <AlertTriangle className="w-4 h-4 text-red-500" />;
    
    switch (action) {
        case 'deploy': return <Globe className="w-4 h-4 text-blue-400" />;
        case 'api_call': return <Zap className="w-4 h-4 text-yellow-400" />;
        case 'create_file': return <FileCode className="w-4 h-4 text-green-400" />;
        case 'system_status_change': return <Activity className="w-4 h-4 text-orange-400" />;
        default: return <Bird className="w-4 h-4 text-neutral-400" />;
    }
};

export default function RavensFeed({ className }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterAction, setFilterAction] = useState('all');
    const [filterRealm, setFilterRealm] = useState('all');

    const { data: logs = [], isLoading } = useQuery({
        queryKey: ['activity_logs'],
        queryFn: async () => {
            const res = await base44.functions.invoke('activity', { method: 'GET', data: { limit: 50 } });
            // Backend returns { items: [...] }
            return res.data?.data?.items || [];
        },
        refetchInterval: 5000 
    });

    // Client-side filtering for immediate feedback
    const filteredLogs = logs.filter(log => {
        const detailsStr = typeof log.details === 'string' ? log.details : JSON.stringify(log.details || {});
        const matchesSearch = 
            detailsStr.toLowerCase().includes(searchTerm.toLowerCase()) || 
            (log.resource && log.resource.toLowerCase().includes(searchTerm.toLowerCase())) ||
            log.action?.toLowerCase().includes(searchTerm.toLowerCase());
        
        const matchesAction = filterAction === 'all' || log.action === filterAction;
        const matchesRealm = filterRealm === 'all' || log.realm === filterRealm;

        return matchesSearch && matchesAction && matchesRealm;
    });

    return (
        <div className={cn("flex flex-col h-full bg-neutral-950 border border-white/10 rounded-lg overflow-hidden", className)}>
            
            {/* AI Summary Section */}
            <div className="border-b border-white/5">
                <InsightEngineModule compact className="border-none bg-transparent rounded-none" />
            </div>

            {/* Header */}
            <div className="p-4 border-b border-white/5 bg-black/20 backdrop-blur-md">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                        <Bird className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                        <div>
                            <h3 className="text-sm font-bold text-white tracking-wide uppercase">The Ravens</h3>
                            <p className="text-[10px] text-neutral-500 font-mono">HUGINN & MUNINN • ACTIVITY FEED</p>
                        </div>
                    </div>
                    <Badge variant="outline" className="bg-[hsl(var(--color-execution))]/10 text-[hsl(var(--color-execution))] border-[hsl(var(--color-execution))]/20 text-[9px] h-5">
                        LIVE
                    </Badge>
                </div>

                {/* Filters */}
                <div className="flex gap-2">
                    <div className="relative flex-1">
                        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-neutral-500" />
                        <Input 
                            placeholder="Search logs..." 
                            className="h-8 pl-8 bg-black/40 border-white/10 text-xs"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <Select value={filterAction} onValueChange={setFilterAction}>
                        <SelectTrigger className="h-8 w-[100px] bg-black/40 border-white/10 text-xs">
                            <SelectValue placeholder="Action" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Actions</SelectItem>
                            <SelectItem value="deploy">Deploy</SelectItem>
                            <SelectItem value="api_call">API Call</SelectItem>
                            <SelectItem value="create_file">File Ops</SelectItem>
                            <SelectItem value="system_status_change">System</SelectItem>
                        </SelectContent>
                    </Select>
                    <Select value={filterRealm} onValueChange={setFilterRealm}>
                        <SelectTrigger className="h-8 w-[100px] bg-black/40 border-white/10 text-xs">
                            <SelectValue placeholder="Realm" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">All Realms</SelectItem>
                            <SelectItem value="valhalla">Valhalla</SelectItem>
                            <SelectItem value="olympus">Olympus</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>

            {/* Log List */}
            <div className="flex-1 overflow-y-auto p-2 space-y-1 xi-scroll">
                {isLoading ? (
                    <div className="p-4 text-center text-xs text-neutral-500">Summoning ravens...</div>
                ) : filteredLogs.length === 0 ? (
                    <div className="p-8 text-center text-xs text-neutral-600 border border-dashed border-white/5 rounded-lg m-2">
                        No activity found matching your criteria.
                    </div>
                ) : (
                    filteredLogs.map((log) => (
                        <div 
                            key={log.id} 
                            className="group flex gap-3 p-3 rounded-md hover:bg-white/5 border border-transparent hover:border-white/5 transition-all text-xs"
                        >
                            <div className="mt-0.5 shrink-0">
                                <ActionIcon action={log.action} status={log.status} />
                            </div>
                            
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start mb-0.5">
                                    <span className="font-medium text-neutral-200 truncate pr-2">
                                        {log.action.replace(/_/g, ' ').toUpperCase()}
                                    </span>
                                    <span className="text-[10px] text-neutral-600 font-mono shrink-0">
                                        {format(new Date(log.timestamp), 'HH:mm:ss')}
                                    </span>
                                </div>
                                
                                <p className="text-neutral-400 leading-relaxed break-words mb-1.5">
                                    {log.details}
                                </p>

                                <div className="flex items-center gap-2">
                                    <Badge variant="secondary" className="px-1.5 py-0 h-4 text-[9px] bg-white/5 text-neutral-500 font-normal">
                                        {log.realm}
                                    </Badge>
                                    <span className="text-[10px] text-neutral-600">
                                        • {log.resource}
                                    </span>
                                    <span className="text-[10px] text-neutral-600">
                                        • {log.severity}
                                    </span>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}