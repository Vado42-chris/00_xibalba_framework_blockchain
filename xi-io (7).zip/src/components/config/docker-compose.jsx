version: '3.8'

services:
  frontend:
    build:
      context: .
      dockerfile: components/infrastructure/Dockerfile.base44-frontend
    volumes:
      - ./dist:/usr/share/nginx/html
    ports:
      - "8080:80"

  backend:
    image: node:18-alpine
    working_dir: /app
    command: npm start
    environment:
      - PORT=3000
      - WS_PORT=3001
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}

  redis:
    image: redis:alpine

  postgres:
    image: postgres:14-alpine
    environment:
      POSTGRES_PASSWORD: ${DB_PASSWORD}