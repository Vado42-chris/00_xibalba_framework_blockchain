import React from 'react';
import AgentChatInterface from '@/components/agents/AgentChatInterface';
import { Button } from "@/components/ui/button";
import { ArrowLeft, Maximize2, Minimize2 } from 'lucide-react';
import { cn } from "@/lib/utils";
import { OrientingText } from '@/components/ui/design-system/System';

export default function DockChat({ agent, onClose, onExpand, isExpanded }) {
    if (!agent) return null;

    return (
        <div className="flex flex-col h-full w-full bg-neutral-950 animate-in slide-in-from-bottom-10 duration-300">
            {/* Header */}
            <div className="shrink-0 h-14 border-b border-white/5 flex items-center justify-between px-3 bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={onClose}
                        className="h-8 w-8 text-neutral-400 hover:text-white -ml-2"
                    >
                        <ArrowLeft className="w-4 h-4" />
                    </Button>
                    <div className="flex items-center gap-2">
                        <div className={cn("w-2 h-2 rounded-full", agent.color.replace('text-', 'bg-'))} />
                        <OrientingText className="font-bold tracking-wide">{agent.name}</OrientingText>
                    </div>
                </div>
                
                {onExpand && (
                    <Button
                        variant="ghost"
                        size="icon"
                        onClick={onExpand}
                        className="h-8 w-8 text-neutral-500 hover:text-white"
                        title={isExpanded ? "Collapse" : "Expand"}
                    >
                        {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                    </Button>
                )}
            </div>

            {/* Chat Area */}
            <div className="flex-1 min-h-0 bg-neutral-950/50">
                <AgentChatInterface 
                    agentName={agent.name}
                    context={{
                        role: agent.role,
                        location: 'tool_dock',
                        mode: 'specialized_assistant'
                    }}
                />
            </div>
        </div>
    );
}