import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
    StickyNote, Activity, Terminal, Sparkles, Scale,
    Calculator, Plus, Save, Trash2, Search, Mail,
    UserPlus, TrendingUp, DollarSign, Package, 
    GitBranch, GitCommit, RefreshCw, Send, BarChart2,
    CheckCircle2, ScrollText
} from 'lucide-react';
import { OrientingText, IntentText, StateText, SemanticDot } from '@/components/ui/design-system/System';
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";

// --- GLOBAL TOOLS ---

export const QuickNote = () => {
    const [note, setNote] = useState("");
    
    const handleSave = () => {
        if (!note.trim()) return;
        toast.success("Note saved to scratchpad");
        setNote("");
    };

    return (
        <div className="space-y-3">
            <Textarea 
                placeholder="Scratchpad..." 
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="min-h-[100px] bg-neutral-900/50 border-white/10 text-xs font-mono resize-none focus:border-[hsl(var(--color-execution))]"
            />
            <div className="flex justify-between">
                <Button variant="ghost" size="sm" onClick={() => setNote("")} className="h-6 text-[10px] text-neutral-500 hover:text-white">
                    Clear
                </Button>
                <Button size="sm" onClick={handleSave} className="h-6 text-[10px] bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 font-bold">
                    Save Note
                </Button>
            </div>
        </div>
    );
};

export const SystemHealth = () => {
    const [stats, setStats] = useState({ cpu: 12, mem: 44, net: 23 });

    useEffect(() => {
        const interval = setInterval(() => {
            setStats(prev => ({
                cpu: Math.min(100, Math.max(0, prev.cpu + (Math.random() * 10 - 5))),
                mem: Math.min(100, Math.max(0, prev.mem + (Math.random() * 6 - 3))),
                net: Math.min(100, Math.max(0, prev.net + (Math.random() * 20 - 10)))
            }));
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="space-y-2">
            <div className="flex items-center justify-between p-2 bg-neutral-900/50 rounded border border-white/5 hover:border-white/10 transition-colors">
                <div className="flex items-center gap-2">
                    <Activity className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                    <StateText className="text-[10px] text-neutral-400">CPU Load</StateText>
                </div>
                <span className="text-xs font-mono text-[hsl(var(--color-execution))]">{stats.cpu.toFixed(1)}%</span>
            </div>
            <div className="flex items-center justify-between p-2 bg-neutral-900/50 rounded border border-white/5 hover:border-white/10 transition-colors">
                <div className="flex items-center gap-2">
                    <Terminal className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                    <StateText className="text-[10px] text-neutral-400">Memory</StateText>
                </div>
                <span className="text-xs font-mono text-[hsl(var(--color-intent))]">{stats.mem.toFixed(1)}%</span>
            </div>
             <div className="flex items-center justify-between p-2 bg-neutral-900/50 rounded border border-white/5 hover:border-white/10 transition-colors">
                <div className="flex items-center gap-2">
                    <Activity className="w-3 h-3 text-[hsl(var(--color-review))]" />
                    <StateText className="text-[10px] text-neutral-400">Network</StateText>
                </div>
                <span className="text-xs font-mono text-[hsl(var(--color-review))]">{stats.net.toFixed(0)} mbps</span>
            </div>
        </div>
    );
};

// --- COMMUNICATIONS TOOLS ---

export const QuickCompose = () => {
    const [sending, setSending] = useState(false);
    
    const handleSend = () => {
        setSending(true);
        setTimeout(() => {
            setSending(false);
            toast.success("Draft sent to outbox");
        }, 1500);
    };

    return (
        <div className="space-y-2">
            <OrientingText className="opacity-50 text-[10px] font-bold tracking-wider">QUICK DRAFT</OrientingText>
            <Input placeholder="Recipient..." className="h-7 text-xs bg-neutral-900/50 border-white/10 focus:border-white/20" />
            <Textarea placeholder="Message..." className="h-20 text-xs bg-neutral-900/50 border-white/10 resize-none focus:border-white/20" />
            <div className="flex gap-2">
                <Button 
                    size="sm" 
                    onClick={handleSend} 
                    disabled={sending}
                    className="flex-1 h-7 text-[10px] bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90 font-bold"
                >
                    {sending ? <Activity className="w-3 h-3 animate-spin mr-1" /> : <Send className="w-3 h-3 mr-1" />}
                    {sending ? "Sending..." : "Send"}
                </Button>
            </div>
        </div>
    );
};

export const CampaignGen = () => {
    return (
        <div className="space-y-2">
            <StateText className="opacity-50 text-[10px]">AI IDEA GENERATOR</StateText>
            <Input placeholder="Topic / Goal..." className="h-7 text-xs bg-neutral-900 border-white/10" />
            <Button size="sm" variant="outline" className="w-full h-7 text-[10px] border-white/10">
                <Sparkles className="w-3 h-3 mr-1 text-[hsl(var(--color-intent))]" /> Generate Concepts
            </Button>
        </div>
    );
};

// --- CRM TOOLS ---

export const LeadScorer = () => {
    const [score, setScore] = useState(null);
    const [loading, setLoading] = useState(false);

    const analyze = () => {
        setLoading(true);
        setTimeout(() => {
            setScore(Math.floor(Math.random() * 40) + 60);
            setLoading(false);
        }, 1200);
    };

    return (
        <div className="space-y-2">
            <OrientingText className="opacity-50 text-[10px] font-bold tracking-wider">LEAD ANALYZER</OrientingText>
            <Input placeholder="Email / Domain..." className="h-7 text-xs bg-neutral-900/50 border-white/10" />
            
            {score !== null ? (
                <div className="p-3 bg-neutral-900/80 rounded border border-white/10 text-center animate-in zoom-in-95 shadow-lg">
                    <div className="text-[10px] text-neutral-400 mb-1 uppercase tracking-wider">Probability Score</div>
                    <div className="text-2xl font-bold text-[hsl(var(--color-execution))] font-mono">{score}/100</div>
                    <Button variant="ghost" size="sm" onClick={() => setScore(null)} className="h-5 text-[9px] mt-1 text-neutral-500 hover:text-white">Reset</Button>
                </div>
            ) : (
                <Button 
                    size="sm" 
                    onClick={analyze}
                    disabled={loading}
                    className="w-full h-7 text-[10px] bg-neutral-900 border border-white/10 hover:bg-neutral-800"
                >
                    {loading ? <Activity className="w-3 h-3 animate-spin" /> : "Calculate Score"}
                </Button>
            )}
        </div>
    );
};

export const QuickAddContact = () => {
    return (
        <div className="space-y-2">
            <Button variant="ghost" className="w-full justify-start h-8 text-xs text-neutral-400 hover:text-white">
                <UserPlus className="w-3 h-3 mr-2" /> Add from LinkedIn
            </Button>
            <Button variant="ghost" className="w-full justify-start h-8 text-xs text-neutral-400 hover:text-white">
                <Mail className="w-3 h-3 mr-2" /> Log Email
            </Button>
        </div>
    );
};

// --- COMMERCE TOOLS ---

export const InventoryForecaster = () => {
    return (
        <div className="space-y-2">
            <StateText className="opacity-50 text-[10px]">DEMAND PREDICTION</StateText>
            <div className="flex gap-2">
                <Input placeholder="SKU..." className="h-7 text-xs bg-neutral-900 border-white/10" />
                <Button size="icon" className="h-7 w-7 bg-neutral-800 border border-white/10">
                    <Activity className="w-3 h-3" />
                </Button>
            </div>
            <div className="p-2 bg-neutral-900 rounded border border-white/5 text-[10px] text-neutral-500">
                Select SKU to forecast...
            </div>
        </div>
    );
};

export const OrderQuickStatus = () => {
    return (
        <div className="space-y-2">
            <Input placeholder="Order ID #..." className="h-7 text-xs bg-neutral-900 border-white/10" />
            <Button size="sm" variant="outline" className="w-full h-7 text-[10px] border-white/10">
                <Search className="w-3 h-3 mr-1" /> Track Package
            </Button>
        </div>
    );
};

// --- FINANCE TOOLS ---

export const CurrencyConverter = () => {
    const [amount, setAmount] = useState("");
    const rate = 0.92; // Mock USD -> EUR

    return (
        <div className="space-y-2">
            <StateText className="opacity-50 text-[10px]">FX CALCULATOR (USD/EUR)</StateText>
            <div className="grid grid-cols-2 gap-2 items-center">
                <Input 
                    placeholder="USD" 
                    type="number"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="h-7 text-xs bg-neutral-900 border-white/10" 
                />
                <div className="h-7 flex items-center px-2 text-xs bg-neutral-800 rounded border border-white/10 text-neutral-300">
                    € {amount ? (parseFloat(amount) * rate).toFixed(2) : "0.00"}
                </div>
            </div>
            <Button size="sm" variant="ghost" className="w-full h-6 text-[10px] text-neutral-500">
                <RefreshCw className="w-3 h-3 mr-1" /> Rate: 1 USD = {rate} EUR
            </Button>
        </div>
    );
};

export const MarketAnalysis = () => {
    return (
        <div className="space-y-2">
             <Button variant="outline" className="w-full justify-start h-8 text-xs border-white/5 bg-neutral-900">
                <TrendingUp className="w-3 h-3 mr-2 text-green-500" /> Crypto Trends
            </Button>
             <Button variant="outline" className="w-full justify-start h-8 text-xs border-white/5 bg-neutral-900">
                <BarChart2 className="w-3 h-3 mr-2 text-blue-500" /> Stock Indices
            </Button>
        </div>
    );
};

// --- WORKROOM TOOLS ---

export const GitControls = () => {
    const [status, setStatus] = useState('idle'); // idle, working, success

    const handleAction = (type) => {
        setStatus('working');
        setTimeout(() => {
            setStatus('success');
            setTimeout(() => setStatus('idle'), 2000);
            toast.success(`${type} completed successfully`);
        }, 1500);
    };

    if (status === 'success') {
        return (
            <div className="h-20 flex flex-col items-center justify-center bg-green-500/10 border border-green-500/20 rounded animate-in fade-in">
                <CheckCircle2 className="w-8 h-8 text-green-500 mb-2" />
                <span className="text-[10px] text-green-400 font-bold tracking-widest">SUCCESS</span>
            </div>
        );
    }

    if (status === 'working') {
        return (
            <div className="h-20 flex flex-col items-center justify-center bg-neutral-900/50 border border-white/5 rounded">
                <RefreshCw className="w-6 h-6 text-[hsl(var(--color-execution))] animate-spin mb-2" />
                <span className="text-[10px] text-neutral-400 tracking-widest">PROCESSING...</span>
            </div>
        );
    }

    return (
        <div className="grid grid-cols-2 gap-2">
            <Button 
                onClick={() => handleAction('Commit')}
                variant="outline" 
                className="h-auto flex flex-col gap-1 py-3 border-white/5 bg-neutral-900/50 hover:bg-neutral-800 hover:border-white/10"
            >
                <GitCommit className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                <span className="text-[10px] font-bold">Commit</span>
            </Button>
            <Button 
                onClick={() => handleAction('Sync')}
                variant="outline" 
                className="h-auto flex flex-col gap-1 py-3 border-white/5 bg-neutral-900/50 hover:bg-neutral-800 hover:border-white/10"
            >
                <RefreshCw className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                <span className="text-[10px] font-bold">Sync</span>
            </Button>
        </div>
    );
};

// --- LEGAL & STUDIO EXISTING ---

export const LegalQuickAction = () => {
    return (
        <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" className="h-auto flex flex-col gap-1 py-3 border-white/5 bg-neutral-900 hover:bg-neutral-800">
                <Search className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                <span className="text-[10px] font-bold">IP Scan</span>
            </Button>
            <Button variant="outline" className="h-auto flex flex-col gap-1 py-3 border-white/5 bg-neutral-900 hover:bg-neutral-800">
                <Scale className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                <span className="text-[10px] font-bold">Draft NDA</span>
            </Button>
        </div>
    );
};

export const StudioPromptHelper = () => {
    const prompts = [
        "Cyberpunk cityscape, neon rain...",
        "Corporate memphis style illustration...",
        "Minimalist logo for tech startup..."
    ];

    return (
        <div className="space-y-2">
            <StateText className="opacity-50 text-[10px]">RECENT PROMPTS</StateText>
            {prompts.map((p, i) => (
                <div key={i} className="p-2 bg-neutral-900 rounded border border-white/5 text-[10px] text-neutral-400 truncate cursor-pointer hover:bg-neutral-800 transition-colors">
                    {p}
                </div>
            ))}
            <Button variant="ghost" className="w-full text-[10px] text-[hsl(var(--color-active))]">
                <Plus className="w-3 h-3 mr-1" /> New Template
            </Button>
        </div>
    );
};

export const ConsoleSnippets = () => {
    const snippets = [
        "sys_check --full",
        "net_trace -v",
        "deploy --prod"
    ];

    return (
        <div className="space-y-2">
             <StateText className="opacity-50 text-[10px]">QUICK COMMANDS</StateText>
             {snippets.map((s, i) => (
                <div key={i} className="flex items-center gap-2 p-2 bg-neutral-900 rounded border border-white/5 cursor-pointer hover:border-[hsl(var(--color-execution))] group transition-all">
                    <Terminal className="w-3 h-3 text-neutral-600 group-hover:text-[hsl(var(--color-execution))]" />
                    <code className="text-[10px] text-neutral-300 font-mono">{s}</code>
                </div>
             ))}
        </div>
    );
};

// --- INTEGRATION TOOLS ---

export const ApiPlaygroundTool = () => {
    const [method, setMethod] = useState('GET');
    const [status, setStatus] = useState(null);

    const handleSend = () => {
        setStatus('loading');
        setTimeout(() => setStatus(200), 1000);
    };

    return (
        <div className="space-y-3">
            <StateText className="opacity-50 text-[10px]">MINI POSTMAN</StateText>
            <div className="flex gap-2">
                <select 
                    value={method} 
                    onChange={(e) => setMethod(e.target.value)}
                    className="h-7 text-xs bg-neutral-900 border border-white/10 rounded px-1 text-[hsl(var(--color-execution))]"
                >
                    <option>GET</option>
                    <option>POST</option>
                </select>
                <Input placeholder="https://api.example.com/v1..." className="h-7 text-xs bg-neutral-900 border-white/10" />
            </div>
            <Textarea placeholder='{ "key": "value" }' className="h-20 text-xs font-mono bg-neutral-900 border-white/10 resize-none" />
            
            {status === 200 ? (
                <div className="p-2 bg-green-500/10 border border-green-500/20 rounded text-[10px] font-mono text-green-400 animate-in fade-in">
                    {"{"} "status": "success", "data": [...] {"}"}
                </div>
            ) : (
                <Button 
                    size="sm" 
                    onClick={handleSend}
                    disabled={status === 'loading'}
                    className="w-full h-7 text-[10px] bg-[hsl(var(--color-intent))] text-black"
                >
                    {status === 'loading' ? <Activity className="w-3 h-3 animate-spin" /> : "Send Request"}
                </Button>
            )}
        </div>
    );
};

export const ConnectorWizardTool = () => {
    return (
        <div className="space-y-3">
            <div className="p-3 bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/20 rounded">
                <h4 className="text-xs font-bold text-[hsl(var(--color-execution))] mb-1">Build Connector</h4>
                <p className="text-[10px] text-neutral-400 mb-2">Define a custom integration using our low-code JSON spec.</p>
                <Button size="sm" variant="outline" className="w-full h-6 text-[10px] border-[hsl(var(--color-execution))]/30 hover:bg-[hsl(var(--color-execution))]/20">
                    <Plus className="w-3 h-3 mr-1" /> Start Wizard
                </Button>
            </div>
            
            <div className="space-y-1">
                <StateText className="opacity-50 text-[10px]">RECENT DRAFTS</StateText>
                <div className="flex items-center justify-between p-2 bg-neutral-900 rounded border border-white/5 opacity-60">
                    <span className="text-[10px]">Custom CRM v1</span>
                    <span className="text-[9px] text-yellow-500">DRAFT</span>
                </div>
            </div>
        </div>
    );
};

// --- CONTENT MANAGER TOOLS ---

export const SeoAnalyzer = () => {
    const [analyzing, setAnalyzing] = useState(false);
    const [score, setScore] = useState(null);

    const checkSeo = () => {
        setAnalyzing(true);
        setTimeout(() => {
            setScore(85);
            setAnalyzing(false);
        }, 1500);
    };

    return (
        <div className="space-y-3">
            <StateText className="opacity-50 text-[10px]">SEO AUDIT</StateText>
            {score ? (
                <div className="p-3 bg-neutral-900 border border-white/10 rounded space-y-2 animate-in fade-in">
                    <div className="flex justify-between items-end">
                        <span className="text-xs font-bold text-white">Score</span>
                        <span className="text-xl font-mono text-green-500">{score}/100</span>
                    </div>
                    <div className="w-full bg-neutral-800 h-1 rounded-full overflow-hidden">
                        <div className="h-full bg-green-500 w-[85%]" />
                    </div>
                    <div className="text-[10px] text-neutral-400">
                        <div className="flex items-center gap-1 text-green-400"><CheckCircle2 className="w-3 h-3" /> Title Length (Optimal)</div>
                        <div className="flex items-center gap-1 text-green-400"><CheckCircle2 className="w-3 h-3" /> Meta Description</div>
                        <div className="flex items-center gap-1 text-yellow-500"><Activity className="w-3 h-3" /> Keyword Density</div>
                    </div>
                    <Button size="sm" variant="ghost" className="w-full h-6 text-[10px]" onClick={() => setScore(null)}>Re-scan</Button>
                </div>
            ) : (
                <Button 
                    onClick={checkSeo}
                    className="w-full bg-neutral-900 border border-white/10 hover:bg-neutral-800 text-xs h-8"
                    disabled={analyzing}
                >
                    {analyzing ? "Scanning..." : "Run SEO Check"}
                </Button>
            )}
        </div>
    );
};

export const QuickPublish = () => {
    const [status, setStatus] = useState('draft'); // draft, publishing, live

    const handlePublish = () => {
        setStatus('publishing');
        setTimeout(() => {
            setStatus('live');
            toast.success("Site deployed to Edge Network");
        }, 2000);
    };

    return (
        <div className="space-y-3">
            <div className="flex items-center justify-between">
                <StateText className="opacity-50 text-[10px]">DEPLOYMENT</StateText>
                {status === 'live' && <span className="text-[10px] text-green-500 flex items-center gap-1"><span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"/> LIVE</span>}
            </div>
            
            <div className="p-3 bg-neutral-900 border border-white/10 rounded">
                <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-neutral-300">Production</span>
                    <span className="text-[10px] font-mono text-neutral-500">v2.4.1</span>
                </div>
                <Button 
                    onClick={handlePublish}
                    disabled={status === 'publishing' || status === 'live'}
                    className={`w-full h-8 text-xs font-bold ${status === 'live' ? 'bg-green-500/20 text-green-500 hover:bg-green-500/30' : 'bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90'}`}
                >
                    {status === 'publishing' ? <RefreshCw className="w-3 h-3 animate-spin" /> : 
                     status === 'live' ? "Deployed" : "Publish Changes"}
                </Button>
            </div>
        </div>
    );
};

// --- STUDIO TOOLS ---

export const LicenseManager = () => {
    return (
        <div className="space-y-3">
            <StateText className="opacity-50 text-[10px]">MONETIZATION</StateText>
            <div className="p-3 bg-neutral-900 border border-white/10 rounded space-y-3">
                <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">License Type</label>
                    <select className="w-full bg-neutral-950 border border-white/10 rounded h-7 text-xs px-2 text-white">
                        <option>Personal Use (Free)</option>
                        <option>Commercial ($29)</option>
                        <option>Extended ($99)</option>
                        <option>Exclusive Rights</option>
                    </select>
                </div>
                <div>
                    <label className="text-[10px] text-neutral-400 block mb-1">Royalty %</label>
                    <div className="flex gap-2">
                        <Input className="h-7 text-xs bg-neutral-950 border-white/10" defaultValue="15%" />
                        <Button size="sm" className="h-7 text-[10px] bg-[hsl(var(--color-active))] text-black">Set</Button>
                    </div>
                </div>
            </div>
            <div className="text-[9px] text-neutral-500 text-center">
                Assets are automatically listed on the Marketplace when licensed.
            </div>
        </div>
    );
};

export const AssetMetadata = () => {
    return (
        <div className="space-y-2">
            <StateText className="opacity-50 text-[10px]">SMART TAGGING</StateText>
            <div className="flex flex-wrap gap-1">
                {['cyberpunk', 'neon', 'city', 'night', 'rain', '4k'].map(tag => (
                    <span key={tag} className="px-2 py-1 bg-neutral-900 rounded border border-white/5 text-[9px] text-neutral-400 flex items-center gap-1 cursor-pointer hover:bg-neutral-800 hover:text-white">
                        {tag} <span className="opacity-50">×</span>
                    </span>
                ))}
                <span className="px-2 py-1 border border-dashed border-white/10 rounded text-[9px] text-neutral-500 cursor-pointer hover:border-white/30 hover:text-neutral-300">+ Add</span>
            </div>
            <Button variant="ghost" size="sm" className="w-full h-6 text-[10px] text-[hsl(var(--color-intent))]">
                <Sparkles className="w-3 h-3 mr-1" /> AI Auto-Tag
            </Button>
        </div>
    );
};

// --- REAPER TOOLS ---

export const DeploymentLogViewer = () => {
    const logs = [
        { time: "10:42:01", level: "INFO", msg: "Building container image..." },
        { time: "10:42:15", level: "INFO", msg: "Pushing to registry..." },
        { time: "10:42:18", level: "SUCCESS", msg: "Deployment active: v2.4.2" },
    ];

    return (
        <div className="space-y-2 font-mono">
            <StateText className="opacity-50 text-[10px]">LIVE LOGS</StateText>
            <div className="bg-black/50 rounded p-2 h-32 overflow-y-auto text-[10px] space-y-1 border border-white/5">
                {logs.map((log, i) => (
                    <div key={i} className="flex gap-2">
                        <span className="text-neutral-600">{log.time}</span>
                        <span className={log.level === 'SUCCESS' ? 'text-green-500' : 'text-blue-500'}>{log.level}</span>
                        <span className="text-neutral-400">{log.msg}</span>
                    </div>
                ))}
                <div className="animate-pulse text-neutral-600">_</div>
            </div>
        </div>
    );
};