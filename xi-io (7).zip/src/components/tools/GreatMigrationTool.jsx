import React, { useState } from 'react';
import { 
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
    Database, ArrowRight, Upload, FileJson, CheckCircle2, 
    RefreshCw, ShieldCheck, Zap, Lock
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';

export const GreatMigrationTool = ({ open, onOpenChange }) => {
    const [mode, setMode] = useState('connect'); // connect, analyze, migrate
    const [connectedPlatform, setConnectedPlatform] = useState(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [migrating, setMigrating] = useState(false);
    
    // Mock data for found workflows
    const [foundWorkflows, setFoundWorkflows] = useState([]);

    const handleConnect = (platform) => {
        setConnectedPlatform(platform);
        // Simulate file input click if needed, or just show analyze state
        // For simulation, we assume user 'uploaded' their credentials/config file
        setAnalyzing(true);
        
        // Simulate complex parsing
        setTimeout(() => {
            setAnalyzing(false);
            // Simulate detection logic based on platform
            const mockResults = platform === 'Zapier' ? [
                { id: 1, name: "Lead -> Slack", triggers: "Webhook", actions: "Slack", complexity: "Low", ai_ready: true },
                { id: 2, name: "Form -> Sheet", triggers: "Typeform", actions: "Google Sheets", complexity: "Low", ai_ready: false }
            ] : [
                { id: 1, name: "Complex Router", triggers: "Custom API", actions: "Multiple", complexity: "High", ai_ready: true }
            ];
            
            setFoundWorkflows(mockResults);
            setMode('analyze');
        }, 2000);
    };

    // Simulated File Upload Handler
    const handleFileUpload = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        setConnectedPlatform("Imported File");
        setAnalyzing(true);
        
        // Enhanced parsing simulation
        const reader = new FileReader();
        reader.onload = (event) => {
            const content = event.target.result;
            // In a real app, we would parse JSON/YAML here
            // const parsed = JSON.parse(content);
            
            setTimeout(() => {
                setAnalyzing(false);
                // Advanced detection based on file content length/type (simulated)
                const isComplex = content.length > 500;
                
                setFoundWorkflows([
                    { 
                        id: 99, 
                        name: file.name.split('.')[0] || "Imported Workflow", 
                        triggers: "Detected Trigger", 
                        actions: isComplex ? "Multi-Step Logic" : "Single Action", 
                        complexity: isComplex ? "High" : "Low", 
                        ai_ready: true 
                    }
                ]);
                setMode('analyze');
                toast.success("Blueprint Parsed", { description: "Legacy architecture decoded." });
            }, 1500);
        };
        reader.readAsText(file);
    };

    const handleMigrate = async () => {
        setMigrating(true);
        try {
            // Signal the Concierge Team via the Backend
            await base44.functions.invoke('concierge', { 
                url: '/api/v1/concierge/interventions', 
                method: 'POST',
                data: {
                    title: `Migration Request: ${connectedPlatform}`,
                    summary: `User requested migration of ${foundWorkflows.length} workflows from ${connectedPlatform}.`,
                    category: 'migration',
                    impact_score: 10,
                    metadata: { platform: connectedPlatform, workflow_count: foundWorkflows.length }
                }
            });

            // Simulate the technical migration delay
            setTimeout(() => {
                setMigrating(false);
                setMode('complete');
                toast.success("Migration Signal Sent", {
                    description: "Valhalla Architects have been dispatched."
                });
            }, 2000);
        } catch (e) {
            setMigrating(false);
            toast.error("Signal Failed", { description: "Could not reach the Citadel." });
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl bg-[#0a0a0a] border-white/10 text-white p-0 gap-0 overflow-hidden h-[600px] flex flex-col">
                {/* Header */}
                <div className="p-6 border-b border-white/5 bg-neutral-900/50 flex justify-between items-center shrink-0">
                    <div>
                        <div className="flex items-center gap-3 mb-1">
                            <h2 className="text-xl font-bold tracking-tight">The Great Migration</h2>
                            <Badge className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]">BETA</Badge>
                        </div>
                        <p className="text-sm text-neutral-400">Import legacy workflows into the sovereign realm.</p>
                    </div>
                    {/* Progress Stepper */}
                    <div className="flex items-center gap-2 text-xs font-mono">
                        <span className={cn(mode === 'connect' ? "text-[hsl(var(--color-intent))]" : "text-neutral-500")}>01 CONNECT</span>
                        <span className="text-neutral-700">/</span>
                        <span className={cn(mode === 'analyze' ? "text-[hsl(var(--color-intent))]" : "text-neutral-500")}>02 ANALYZE</span>
                        <span className="text-neutral-700">/</span>
                        <span className={cn(mode === 'complete' ? "text-[hsl(var(--color-intent))]" : "text-neutral-500")}>03 LIBERATE</span>
                    </div>
                </div>

                {/* Content Area */}
                <div className="flex-1 overflow-y-auto p-8 relative">
                    
                    {/* STEP 1: CONNECT */}
                    {mode === 'connect' && (
                        <div className="max-w-2xl mx-auto space-y-8">
                            <div className="text-center space-y-2">
                                <h3 className="text-2xl font-light">Select Source Platform</h3>
                                <p className="text-neutral-400">Where are your workflows currently trapped?</p>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                {['Zapier', 'Make (Integromat)', 'Workato', 'Custom API'].map((platform) => (
                                    <button
                                        key={platform}
                                        onClick={() => handleConnect(platform)}
                                        className="p-6 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-[hsl(var(--color-intent))]/50 transition-all text-left group"
                                    >
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="font-bold text-lg">{platform}</span>
                                            {analyzing && connectedPlatform === platform ? (
                                                <RefreshCw className="w-4 h-4 animate-spin text-[hsl(var(--color-intent))]" />
                                            ) : (
                                                <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-[hsl(var(--color-intent))]" />
                                            )}
                                        </div>
                                        <div className="text-xs text-neutral-500">Connect via OAuth or API Key</div>
                                    </button>
                                ))}
                                
                                {/* JSON Import Option */}
                                <div className="col-span-2 relative p-6 rounded-xl border border-dashed border-white/10 bg-white/[0.02] hover:bg-white/[0.05] transition-all text-center">
                                    <input 
                                        type="file" 
                                        accept=".json,.yaml,.csv" 
                                        onChange={handleFileUpload}
                                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                    />
                                    <div className="flex flex-col items-center gap-2">
                                        <FileJson className="w-8 h-8 text-neutral-500" />
                                        <span className="font-medium text-neutral-300">Upload Workflow Export</span>
                                        <span className="text-xs text-neutral-500">Supports JSON, YAML from legacy platforms</span>
                                    </div>
                                </div>
                            </div>

                            {analyzing && (
                                <div className="text-center space-y-4 pt-8 animate-in fade-in">
                                    <div className="w-16 h-1 bg-white/10 rounded-full mx-auto overflow-hidden">
                                        <div className="h-full bg-[hsl(var(--color-intent))] animate-[progress_1s_ease-in-out_infinite]" style={{width: '50%'}} />
                                    </div>
                                    <p className="text-sm font-mono text-[hsl(var(--color-intent))]">SCANNING NEURAL PATHWAYS...</p>
                                </div>
                            )}
                        </div>
                    )}

                    {/* STEP 2: ANALYZE */}
                    {mode === 'analyze' && (
                        <div className="space-y-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h3 className="text-lg font-bold">Detected Workflows</h3>
                                    <p className="text-sm text-neutral-400">Found {foundWorkflows.length} active automations on {connectedPlatform}</p>
                                </div>
                                <Button onClick={handleMigrate} className="bg-[hsl(var(--color-intent))] text-black font-bold">
                                    Migrate All <Upload className="w-4 h-4 ml-2" />
                                </Button>
                            </div>

                            <div className="border border-white/10 rounded-lg overflow-hidden">
                                <table className="w-full text-sm text-left">
                                    <thead className="bg-white/5 text-neutral-400 border-b border-white/10">
                                        <tr>
                                            <th className="p-4 font-medium">Workflow Name</th>
                                            <th className="p-4 font-medium">Triggers</th>
                                            <th className="p-4 font-medium">Actions</th>
                                            <th className="p-4 font-medium">Migration Complexity</th>
                                            <th className="p-4 font-medium">Optimization</th>
                                            <th className="p-4 font-medium text-right">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-white/5">
                                        {foundWorkflows.map((wf) => (
                                            <tr key={wf.id} className="hover:bg-white/[0.02]">
                                                <td className="p-4 font-medium text-white">{wf.name}</td>
                                                <td className="p-4 text-neutral-400">{wf.triggers}</td>
                                                <td className="p-4 text-neutral-400">{wf.actions}</td>
                                                <td className="p-4">
                                                    <Badge variant="outline" className={cn(
                                                        "border-none bg-opacity-20",
                                                        wf.complexity === 'Low' ? "bg-green-500 text-green-500" :
                                                        wf.complexity === 'Medium' ? "bg-yellow-500 text-yellow-500" :
                                                        "bg-red-500 text-red-500"
                                                    )}>
                                                        {wf.complexity}
                                                    </Badge>
                                                </td>
                                                <td className="p-4">
                                                    {wf.ai_ready && (
                                                        <Badge variant="secondary" className="bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))] border-[hsl(var(--color-intent))]/20 text-[10px]">
                                                            <Zap className="w-3 h-3 mr-1" /> AI Ready
                                                        </Badge>
                                                    )}
                                                </td>
                                                <td className="p-4 text-right">
                                                    <Badge variant="outline" className="border-white/10 text-neutral-500">Ready</Badge>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {/* STEP 3: COMPLETE */}
                    {mode === 'complete' && (
                        <div className="text-center max-w-lg mx-auto space-y-8 pt-12">
                            <div className="w-24 h-24 bg-green-500/10 rounded-full flex items-center justify-center mx-auto border border-green-500/20 shadow-[0_0_30px_rgba(34,197,94,0.2)]">
                                <CheckCircle2 className="w-12 h-12 text-green-500" />
                            </div>
                            
                            <div>
                                <h3 className="text-3xl font-light text-white mb-2">Liberation Complete</h3>
                                <p className="text-neutral-400">
                                    Your workflows have been successfully imported into Valhalla. 
                                    They are now running in <span className="text-[hsl(var(--color-intent))]">Sovereign Mode</span>.
                                </p>
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-left">
                                <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                                    <div className="flex items-center gap-2 mb-2 text-emerald-400">
                                        <ShieldCheck className="w-4 h-4" />
                                        <span className="text-xs font-bold uppercase">ChainLedger</span>
                                    </div>
                                    <p className="text-xs text-neutral-500">Audit trails initialized for all 3 workflows.</p>
                                </div>
                                <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                                    <div className="flex items-center gap-2 mb-2 text-blue-400">
                                        <Zap className="w-4 h-4" />
                                        <span className="text-xs font-bold uppercase">AI Insight</span>
                                    </div>
                                    <p className="text-xs text-neutral-500">Optimization engine active.</p>
                                </div>
                            </div>

                            <div className="bg-neutral-900/50 p-4 rounded-lg border border-white/5 text-left">
                                <h4 className="text-sm font-bold mb-2">Migration Plan Generated</h4>
                                <p className="text-xs text-neutral-400 mb-4">
                                    We have generated a Sovereign Architecture Plan for your {foundWorkflows.length} workflows.
                                </p>
                                <div className="flex gap-2 text-xs font-mono text-neutral-500">
                                    <span>• {foundWorkflows.filter(w => w.ai_ready).length} workflows optimized with AI</span>
                                    <span>• 100% blockchain audit coverage</span>
                                </div>
                            </div>

                            <div className="flex gap-4 justify-center pt-8">
                                <Button variant="outline" onClick={() => onOpenChange(false)} className="border-white/10">
                                    Close
                                </Button>
                                <Button className="bg-white text-black hover:bg-neutral-200 font-bold">
                                    <FileJson className="w-4 h-4 mr-2" />
                                    Download Sovereign Plan
                                </Button>
                            </div>
                        </div>
                    )}

                    {/* Loading Overlay for Migration */}
                    {migrating && (
                        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center">
                             <div className="text-center space-y-4">
                                <div className="w-16 h-16 border-4 border-[hsl(var(--color-intent))] border-t-transparent rounded-full animate-spin mx-auto" />
                                <div className="text-[hsl(var(--color-intent))] font-mono text-lg animate-pulse">REWRITING REALITY...</div>
                            </div>
                        </div>
                    )}

                </div>
            </DialogContent>
        </Dialog>
    );
}