import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, Database, FileSpreadsheet, CheckCircle2, ArrowRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

export default function EasyMigrator() {
    const [step, setStep] = useState(1);
    const [file, setFile] = useState(null);
    const [fileUrl, setFileUrl] = useState(null);
    const [importing, setImporting] = useState(false);
    const [importedCount, setImportedCount] = useState(0);
    const fileInputRef = useRef(null);

    const handleFileChange = async (e) => {
        const selectedFile = e.target.files[0];
        if (!selectedFile) return;

        setFile(selectedFile);
        
        // Upload immediately to get URL
        try {
            toast.info("Uploading file...");
            const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedFile });
            setFileUrl(file_url);
            setStep(2);
            toast.success("File uploaded successfully");
        } catch (error) {
            toast.error("Upload failed: " + error.message);
            setFile(null);
        }
    };

    const handleImport = async () => {
        if (!fileUrl) return;
        setStep(3);
        setImporting(true);
        
        try {
            // Extract data
            const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
                file_url: fileUrl,
                json_schema: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            first_name: { type: "string" },
                            last_name: { type: "string" },
                            email: { type: "string" },
                            company: { type: "string" }
                        },
                        required: ["email"]
                    }
                }
            });

            if (result.status === 'success' && Array.isArray(result.output)) {
                // Bulk create Customers
                const customers = result.output.map(c => ({
                    first_name: c.first_name || 'Unknown',
                    last_name: c.last_name || '',
                    email: c.email,
                    company: c.company || '',
                    status: 'active'
                }));
                
                await base44.entities.Customer.bulkCreate(customers);
                setImportedCount(customers.length);
                setStep(4);
                toast.success(`Imported ${customers.length} records!`);
            } else {
                throw new Error("Failed to extract data properly");
            }
        } catch (error) {
            console.error(error);
            toast.error("Import failed: " + error.message);
            setStep(2); // Go back
        } finally {
            setImporting(false);
        }
    };

    return (
        <Card className="h-full border-white/10">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Database className="w-5 h-5 text-blue-500" />
                    Easy Switch Tool
                </CardTitle>
                <CardDescription>
                    Move your data from other platforms in seconds.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    onChange={handleFileChange} 
                    accept=".csv,.xlsx,.xls,.json"
                />
                
                {step === 1 && (
                    <div 
                        className="border-2 border-dashed border-white/20 rounded-xl p-8 text-center hover:bg-white/5 transition-colors cursor-pointer group"
                        onClick={() => fileInputRef.current?.click()}
                    >
                        <div className="w-16 h-16 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                            <Upload className="w-8 h-8 text-blue-500" />
                        </div>
                        <h3 className="text-lg font-medium text-white mb-2">Drop your CSV or Excel file here</h3>
                        <p className="text-sm text-neutral-400 mb-6">
                            We support exports from Salesforce, HubSpot, Notion, and Google Sheets.
                        </p>
                        <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                            Select File
                        </Button>
                    </div>
                )}

                {step === 2 && (
                    <div className="space-y-6">
                        <div className="flex items-center gap-4 p-4 rounded-lg bg-white/5 border border-white/10">
                            <FileSpreadsheet className="w-8 h-8 text-green-500" />
                            <div className="flex-1">
                                <h4 className="font-medium text-white">{file?.name}</h4>
                                <p className="text-xs text-neutral-400">{file?.size}</p>
                            </div>
                            <Button variant="ghost" size="sm" onClick={() => { setFile(null); setStep(1); }}>
                                Change
                            </Button>
                        </div>
                        
                        <div className="space-y-2">
                            <div className="flex justify-between text-sm text-neutral-400">
                                <span>Mapping Columns</span>
                                <span className="text-green-500">Auto-detected</span>
                            </div>
                            <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
                                <div className="h-full w-full bg-blue-500/50 animate-pulse"></div>
                            </div>
                        </div>

                        <Button className="w-full bg-green-600 hover:bg-green-700 text-white" onClick={handleImport}>
                            Start Import <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    </div>
                )}

                {step === 3 && (
                    <div className="py-12 text-center space-y-4">
                        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                        <div>
                            <h3 className="text-lg font-medium text-white">Importing Data...</h3>
                            <p className="text-neutral-400">Extracting and mapping your data to the Knowledge Graph.</p>
                        </div>
                    </div>
                )}

                {step === 4 && (
                    <div className="py-8 text-center space-y-6">
                        <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto">
                            <CheckCircle2 className="w-10 h-10 text-green-500" />
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-white">All Done!</h3>
                            <p className="text-neutral-400">Successfully imported {importedCount} records.</p>
                        </div>
                        <div className="flex gap-3">
                            <Button variant="outline" className="flex-1" onClick={() => { setStep(1); setFile(null); }}>Import More</Button>
                            <Button className="flex-1 bg-white text-black hover:bg-neutral-200" onClick={() => window.location.href='/CRM'}>View Data</Button>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}