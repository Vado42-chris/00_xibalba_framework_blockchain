import { 
    StickyNote, Activity, Terminal, Sparkles, Scale,
    Briefcase, Shield, Search, Mail, Users, Calculator,
    TrendingUp, Package, GitBranch, Folder, Bot, Brain,
    Plug, Globe, Tag, DollarSign, LayoutTemplate, Heart, Ghost, ScrollText, Target,
    CircuitBoard, Server, MessageSquare, Building2, Fingerprint, Download
} from 'lucide-react';
import { 
    QuickNote, SystemHealth, 
    LegalQuickAction, StudioPromptHelper, ConsoleSnippets,
    QuickCompose, CampaignGen, LeadScorer, QuickAddContact,
    InventoryForecaster, OrderQuickStatus, CurrencyConverter, MarketAnalysis,
    GitControls, ApiPlaygroundTool, ConnectorWizardTool,
    SeoAnalyzer, QuickPublish, LicenseManager, AssetMetadata, DeploymentLogViewer
} from './ToolSet';
import { ZedControls } from '@/components/development/DevTools';
import { CherryTools } from '@/components/studio/CherryTools';
import FileManager from '@/components/tools/FileManager';
import CollabPanel from '@/components/collaboration/CollabPanel';

// Tool Categories: 'global', 'interaction', 'automation'

export const GLOBAL_TOOLS = [
    {
        id: 'team',
        label: 'Team',
        icon: Users,
        component: CollabPanel,
        category: 'global'
    },
    {
        id: 'files',
        label: 'File System',
        icon: Folder,
        component: FileManager,
        category: 'global'
    },
    {
        id: 'notes',
        label: 'Scratchpad',
        icon: StickyNote,
        component: QuickNote,
        category: 'global'
    },
    {
        id: 'health',
        label: 'System Status',
        icon: Activity,
        component: SystemHealth,
        category: 'global'
    }
];

// Page Specific Tools & Agents
export const PAGE_TOOL_MAP = {
    'Marketplace': {
        tools: [
            {
                id: 'create_listing',
                label: 'Sell Item',
                icon: Package,
                component: () => (
                    <div className="space-y-2">
                        <div className="p-3 bg-neutral-900 border border-white/10 rounded">
                            <h4 className="text-xs font-bold text-white mb-1">Create Listing</h4>
                            <p className="text-[10px] text-neutral-400 mb-2">Publish your own modules or agents.</p>
                            <button onClick={() => window.location.href='/Marketplace?action=create'} className="w-full py-1.5 bg-[hsl(var(--color-execution))] text-black text-xs font-bold rounded">
                                New Listing
                            </button>
                        </div>
                    </div>
                ),
                category: 'interaction'
            }
        ],
        agent: {
            name: "Broker",
            role: "Market Analyst",
            icon: Briefcase,
            color: "text-amber-400"
        }
    },
    'Legal': {
        tools: [
            {
                id: 'legal_actions',
                label: 'Legal Actions',
                icon: Scale,
                component: LegalQuickAction,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Lex",
            role: "Legal Compliance Officer",
            icon: Scale,
            color: "text-blue-400"
        }
    },
    'Studio': {
        tools: [
            {
                id: 'visual_palette_toggle',
                label: 'Show/Hide Tools',
                icon: LayoutTemplate,
                component: () => (
                    <div className="p-3">
                        <button 
                            onClick={() => window.dispatchEvent(new Event('visual-forge-toggle-palette'))}
                            className="w-full flex items-center justify-center gap-2 py-2 bg-neutral-800 border border-white/10 rounded hover:bg-neutral-700 transition-colors text-xs font-bold text-white"
                        >
                            Toggle Palette
                        </button>
                        <p className="mt-2 text-[10px] text-neutral-500 text-center">
                            Spawns the floating tool palette for visual editing.
                        </p>
                    </div>
                ),
                category: 'interaction'
            },
            {
                id: 'prompt_helper',
                label: 'Prompt Assistant',
                icon: Sparkles,
                component: StudioPromptHelper,
                category: 'interaction'
            },
            {
                id: 'license_manager',
                label: 'Monetize',
                icon: DollarSign,
                component: LicenseManager,
                category: 'interaction'
            },
            {
                id: 'asset_meta',
                label: 'Metadata',
                icon: Tag,
                component: AssetMetadata,
                category: 'automation'
            }
        ],
        agent: {
            name: "Muse",
            role: "Creative Director",
            icon: Sparkles,
            color: "text-purple-400"
        }
    },
    'ContentManager': {
        tools: [
            {
                id: 'quick_publish',
                label: 'Go Live',
                icon: Globe,
                component: QuickPublish,
                category: 'interaction'
            },
            {
                id: 'seo_analyzer',
                label: 'SEO Check',
                icon: Search,
                component: SeoAnalyzer,
                category: 'automation'
            }
        ],
        agent: {
            name: "Scribe",
            role: "Content Editor",
            icon: LayoutTemplate,
            color: "text-orange-400"
        }
    },
    'Console': {
        tools: [
            {
                id: 'snippets',
                label: 'Snippets',
                icon: Terminal,
                component: ConsoleSnippets,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Root",
            role: "System Administrator",
            icon: Terminal,
            color: "text-green-400"
        }
    },
    'Integrations': {
        tools: [
            {
                id: 'api_tester',
                label: 'API Tester',
                icon: Terminal,
                component: ApiPlaygroundTool,
                category: 'interaction'
            },
            {
                id: 'connector_builder',
                label: 'Builder',
                icon: Plug,
                component: ConnectorWizardTool,
                category: 'automation'
            }
        ],
        agent: {
            name: "Link",
            role: "Integration Specialist",
            icon: Plug,
            color: "text-fuchsia-400"
        }
    },
    'WorkRoom': {
        tools: [
            {
                id: 'git_controls',
                label: 'Git Actions',
                icon: GitBranch,
                component: GitControls,
                category: 'interaction'
            },
            {
                id: 'zed_controls',
                label: 'Engineering',
                icon: Terminal,
                component: ZedControls,
                category: 'automation'
            }
        ],
        agent: {
            name: "Architect",
            role: "Lead Engineer",
            icon: Brain,
            color: "text-orange-400"
        }
    },
    'Communications': {
        tools: [
            {
                id: 'quick_compose',
                label: 'Quick Draft',
                icon: Mail,
                component: QuickCompose,
                category: 'interaction'
            },
            {
                id: 'campaign_gen',
                label: 'Campaign AI',
                icon: Sparkles,
                component: CampaignGen,
                category: 'automation'
            }
        ],
        agent: {
            name: "Mercury",
            role: "Comms Director",
            icon: Mail,
            color: "text-pink-400"
        }
    },
    'CRM': {
        tools: [
            {
                id: 'quick_add_contact',
                label: 'Add Contact',
                icon: Users,
                component: QuickAddContact,
                category: 'interaction'
            },
            {
                id: 'lead_scorer',
                label: 'Lead Scorer',
                icon: Calculator,
                component: LeadScorer,
                category: 'automation'
            }
        ],
        agent: {
            name: "Rolodex",
            role: "Sales Manager",
            icon: Users,
            color: "text-indigo-400"
        }
    },
    'Commerce': {
        tools: [
            {
                id: 'order_status',
                label: 'Track Order',
                icon: Package,
                component: OrderQuickStatus,
                category: 'interaction'
            },
            {
                id: 'inventory_forecast',
                label: 'Forecast',
                icon: TrendingUp,
                component: InventoryForecaster,
                category: 'automation'
            }
        ],
        agent: {
            name: "Ledger",
            role: "Supply Chain Ops",
            icon: Package,
            color: "text-emerald-400"
        }
    },
    'Finance': {
        tools: [
            {
                id: 'currency_converter',
                label: 'Converter',
                icon: Calculator,
                component: CurrencyConverter,
                category: 'interaction'
            },
            {
                id: 'market_analysis',
                label: 'Market AI',
                icon: TrendingUp,
                component: MarketAnalysis,
                category: 'automation'
            }
        ],
        agent: {
            name: "Quant",
            role: "Financial Analyst",
            icon: TrendingUp,
            color: "text-yellow-400"
        }
    },
    'Intelligence': {
        tools: [
             {
                id: 'prompt_helper',
                label: 'Prompt Guide',
                icon: Sparkles,
                component: StudioPromptHelper,
                category: 'interaction'
            },
            {
                id: 'market_analysis',
                label: 'Trend Watch',
                icon: TrendingUp,
                component: MarketAnalysis,
                category: 'automation'
            }
        ],
        agent: {
            name: "Oracle",
            role: "Data Scientist",
            icon: Brain,
            color: "text-cyan-400"
        }
    },
    'Dashboard': {
        tools: [
            {
                id: 'quick_compose',
                label: 'Quick Draft',
                icon: Mail,
                component: QuickCompose,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Overseer",
            role: "Operations Chief",
            icon: Activity,
            color: "text-white"
        }
    },
    'Settings': {
        tools: [
             {
                id: 'health',
                label: 'Diagnostics',
                icon: Activity,
                component: SystemHealth,
                category: 'automation'
            }
        ],
        agent: {
            name: "Admin",
            role: "System Config",
            icon: Scale,
            color: "text-neutral-400"
        }
    },
    'Lifestyle': {
        tools: [
            {
                id: 'notes',
                label: 'Journal',
                icon: StickyNote,
                component: QuickNote,
                category: 'interaction'
            },
            {
                id: 'health_metrics',
                label: 'Vitals',
                icon: Activity,
                component: SystemHealth,
                category: 'automation'
            }
        ],
        agent: {
            name: "Zen",
            role: "Wellness Coach",
            icon: Heart,
            color: "text-emerald-400"
        }
    },
    'ReaperSpace': {
        tools: [
             {
                id: 'deployment_logs',
                label: 'Deploy Logs',
                icon: ScrollText,
                component: DeploymentLogViewer,
                category: 'automation'
            }
        ],
        agent: {
            name: "Reaper",
            role: "Deployment Orchestrator",
            icon: Ghost,
            color: "text-purple-500"
        }
    },
    'Agents': {
        tools: [
             {
                id: 'agent_health',
                label: 'Swarm Health',
                icon: Activity,
                component: SystemHealth,
                category: 'global'
            }
        ],
        agent: {
            name: "Hive",
            role: "Swarm Manager",
            icon: Bot,
            color: "text-blue-500"
        }
    },
    'Network': {
        tools: [
             {
                id: 'ping_tool',
                label: 'Ping Node',
                icon: Activity,
                component: SystemHealth,
                category: 'interaction'
            }
        ],
        agent: {
            name: "NetOp",
            role: "Network Operator",
            icon: Globe,
            color: "text-cyan-500"
        }
    },
    'BusinessPlan': {
        tools: [
             {
                id: 'strategy_notes',
                label: 'Strategy',
                icon: Target,
                component: QuickNote,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Strategist",
            role: "Business Architect",
            icon: Briefcase,
            color: "text-indigo-500"
        }
    },
    'Archives': {
        tools: [
             {
                id: 'search_archives',
                label: 'Deep Search',
                icon: Search,
                component: FileManager,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Librarian",
            role: "Archivist",
            icon: Folder,
            color: "text-amber-600"
        }
    },
    'Automation': {
        tools: [
             {
                id: 'connector_builder',
                label: 'Builder',
                icon: Plug,
                component: ConnectorWizardTool,
                category: 'automation'
            }
        ],
        agent: {
            name: "Construct",
            role: "Automation Engineer",
            icon: CircuitBoard,
            color: "text-cyan-500"
        }
    },
    'IntegrationDashboard': {
        tools: [
             {
                id: 'api_tester',
                label: 'API Tester',
                icon: Terminal,
                component: ApiPlaygroundTool,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Bridge",
            role: "Connectivity Monitor",
            icon: Activity,
            color: "text-purple-500"
        }
    },
    'Nodes': {
        tools: [
             {
                id: 'ping_tool',
                label: 'Ping Node',
                icon: Activity,
                component: SystemHealth,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Grid",
            role: "Infrastructure Manager",
            icon: Server,
            color: "text-blue-600"
        }
    },
    'Community': {
        tools: [
             {
                id: 'quick_post',
                label: 'New Post',
                icon: MessageSquare,
                component: QuickCompose,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Unity",
            role: "Community Manager",
            icon: Users,
            color: "text-orange-500"
        }
    },
    'Enterprise': {
        tools: [
             {
                id: 'audit_log',
                label: 'Audit Log',
                icon: Shield,
                component: SystemHealth,
                category: 'automation'
            }
        ],
        agent: {
            name: "Executive",
            role: "Enterprise Admin",
            icon: Building2,
            color: "text-slate-200"
        }
    },
    'Identity': {
        tools: [
             {
                id: 'user_search',
                label: 'Find User',
                icon: Search,
                component: QuickAddContact,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Sentinel",
            role: "Identity Provider",
            icon: Fingerprint,
            color: "text-zinc-400"
        }
    },
    'Audit': {
        tools: [
             {
                id: 'sys_health',
                label: 'System Health',
                icon: Activity,
                component: SystemHealth,
                category: 'automation'
            }
        ],
        agent: {
            name: "Auditor",
            role: "Compliance Officer",
            icon: Shield,
            color: "text-red-500"
        }
    },
    'ServerControl': {
        tools: [
             {
                id: 'console',
                label: 'Terminal',
                icon: Terminal,
                component: ConsoleSnippets,
                category: 'interaction'
            }
        ],
        agent: {
            name: "SysAdmin",
            role: "Server Operator",
            icon: Server,
            color: "text-emerald-500"
        }
    },
    'DistroBuilder': {
        tools: [
             {
                id: 'build_log',
                label: 'Build Logs',
                icon: ScrollText,
                component: ConsoleSnippets,
                category: 'automation'
            }
        ],
        agent: {
            name: "Forge",
            role: "Systems Architect",
            icon: Package,
            color: "text-red-500"
        }
    },
    'SearchResults': {
        tools: [
             {
                id: 'search_filters',
                label: 'Filters',
                icon: Search,
                component: StudioPromptHelper,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Scout",
            role: "Research Assistant",
            icon: Search,
            color: "text-blue-400"
        }
    },
    'SearchLanding': {
        tools: [
             {
                id: 'search_filters',
                label: 'Filters',
                icon: Search,
                component: StudioPromptHelper,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Scout",
            role: "Research Assistant",
            icon: Search,
            color: "text-blue-400"
        }
    },
    'Settings': {
        tools: [
             {
                id: 'health',
                label: 'Diagnostics',
                icon: Activity,
                component: SystemHealth,
                category: 'automation'
            }
        ],
        agent: {
            name: "Admin",
            role: "System Config",
            icon: Scale,
            color: "text-neutral-400"
        }
    },
    'Finance': {
        tools: [
            {
                id: 'currency_converter',
                label: 'Converter',
                icon: Calculator,
                component: CurrencyConverter,
                category: 'interaction'
            },
            {
                id: 'market_analysis',
                label: 'Market AI',
                icon: TrendingUp,
                component: MarketAnalysis,
                category: 'automation'
            }
        ],
        agent: {
            name: "Quant",
            role: "Financial Analyst",
            icon: TrendingUp,
            color: "text-yellow-400"
        }
    },
    'Installer': {
        tools: [
             {
                id: 'install_logs',
                label: 'Install Logs',
                icon: Terminal,
                component: ConsoleSnippets,
                category: 'automation'
            }
        ],
        agent: {
            name: "Installer",
            role: "Deployment Agent",
            icon: Download,
            color: "text-cyan-400"
        }
    },
    'Docs': {
        tools: [
             {
                id: 'search_docs',
                label: 'Search Docs',
                icon: Search,
                component: StudioPromptHelper,
                category: 'interaction'
            }
        ],
        agent: {
            name: "Guide",
            role: "Documentation Bot",
            icon: ScrollText,
            color: "text-stone-400"
        }
    }
};

export const getToolsForPath = (pathname) => {
    // Normalize path to match keys (remove leading slash, handle empty for Home)
    let path = pathname.replace('/', '');
    if (!path || path === '') path = 'Dashboard'; // Default to Dashboard tools if root
    
    // Handle query params or exact matching
    const cleanPath = path.split('?')[0];

    if (PAGE_TOOL_MAP[cleanPath]) {
        return PAGE_TOOL_MAP[cleanPath];
    }
    
    // Default Fallback
    return PAGE_TOOL_MAP['Dashboard'] || { tools: [], agent: null };
};