import React from 'react';
import { useGrid } from '@/components/desktop/DesktopGridSystem';
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
    Layout, Plus, Music, Terminal, Calendar, 
    ListTodo, MessageSquare, Mail, Grid, ShoppingBag,
    Monitor, Activity, Globe, Clock, Shield,
    Layers, PlusCircle, Trash2, Save
} from 'lucide-react';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { useState } from 'react';
import {
    Accordion,
    AccordionContent,
    AccordionItem,
    AccordionTrigger,
} from "@/components/ui/accordion";

export default function DesktopTools() {
    const { 
        gridConfig, 
        toggleGridLines, 
        setGridSize, 
        setGridOpacity,
        handleAddWidget,
        workspaces,
        currentWorkspaceId,
        switchWorkspace,
        createWorkspace,
        deleteWorkspace
    } = useGrid();

    const [newWorkspaceName, setNewWorkspaceName] = useState("");
    const [isCreating, setIsCreating] = useState(false);

    const handleCreate = () => {
        if (newWorkspaceName.trim()) {
            createWorkspace(newWorkspaceName);
            setNewWorkspaceName("");
            setIsCreating(false);
        }
    };

    // Widget Categories
    const categories = [
        {
            id: 'essentials',
            title: 'Essentials',
            icon: Clock,
            items: [
                { id: 'calendar', label: 'Calendar', icon: Calendar },
                { id: 'planner', label: 'Agenda', icon: ListTodo },
                { id: 'email', label: 'Inbox', icon: Mail },
            ]
        },
        {
            id: 'monitoring',
            title: 'Monitoring',
            icon: Activity,
            items: [
                { id: 'node-monitor', label: 'Node Status', icon: Globe },
                { id: 'system-status', label: 'Security', icon: Shield },
                { id: 'code-pulse', label: 'Code Pulse', icon: Terminal },
            ]
        },
        {
            id: 'media',
            title: 'Media & Social',
            icon: Music,
            items: [
                { id: 'spotify', label: 'Sound Engine', icon: Music },
                { id: 'social', label: 'Social Feed', icon: MessageSquare },
            ]
        }
    ];

    return (
        <div className="space-y-6 text-neutral-200">
            {/* WORKSPACES SECTION */}
            <div className="space-y-4">
                <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <h3 className="text-sm font-bold tracking-wider">WORKSPACES</h3>
                </div>
                
                <div className="space-y-2">
                    {workspaces.map(ws => (
                        <div 
                            key={ws.id}
                            className={`group flex items-center justify-between p-2 rounded-md border transition-all ${
                                currentWorkspaceId === ws.id 
                                    ? "bg-[hsl(var(--color-intent))]/10 border-[hsl(var(--color-intent))]/30 text-white" 
                                    : "bg-white/5 border-white/5 text-neutral-400 hover:bg-white/10"
                            }`}
                        >
                            <button 
                                className="flex-1 text-left text-xs font-medium"
                                onClick={() => switchWorkspace(ws.id)}
                            >
                                {ws.name}
                            </button>
                            
                            {currentWorkspaceId === ws.id && (
                                <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-intent))]" />
                            )}
                            
                            {currentWorkspaceId !== ws.id && (
                                <button 
                                    onClick={(e) => { e.stopPropagation(); deleteWorkspace(ws.id); }}
                                    className="opacity-0 group-hover:opacity-100 hover:text-red-400 transition-opacity"
                                >
                                    <Trash2 className="w-3 h-3" />
                                </button>
                            )}
                        </div>
                    ))}
                    
                    {isCreating ? (
                        <div className="flex gap-2 animate-in fade-in slide-in-from-top-2">
                            <Input 
                                value={newWorkspaceName}
                                onChange={(e) => setNewWorkspaceName(e.target.value)}
                                placeholder="Save State As..."
                                className="h-8 text-xs bg-black/40 border-white/10"
                                autoFocus
                                onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                            />
                            <Button size="sm" onClick={handleCreate} className="h-8 w-8 p-0 bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90">
                                <Save className="w-4 h-4" />
                            </Button>
                        </div>
                    ) : (
                        <Button 
                            variant="ghost" 
                            className="w-full h-8 text-xs border border-dashed border-white/10 hover:border-white/20 hover:bg-white/5 text-neutral-500"
                            onClick={() => setIsCreating(true)}
                        >
                            <PlusCircle className="w-3 h-3 mr-2" />
                            Save New Workspace State
                        </Button>
                    )}
                </div>
            </div>

            <div className="w-full h-px bg-white/5" />

            {/* Grid Configuration Section */}
            <div className="space-y-4">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Layout className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                        <h3 className="text-sm font-bold tracking-wider">GRID CONFIG</h3>
                    </div>
                    <Switch 
                        checked={gridConfig.showGrid} 
                        onCheckedChange={toggleGridLines}
                    />
                </div>

                <div className="space-y-3 bg-white/5 p-3 rounded-lg border border-white/5">
                    <div className="space-y-2">
                        <div className="flex justify-between text-[10px] uppercase text-neutral-400 font-mono">
                            <span>Cell Size</span>
                            <span>{gridConfig.cellSize}px</span>
                        </div>
                        <Slider 
                            value={[gridConfig.cellSize]} 
                            min={32} 
                            max={128} 
                            step={8} 
                            onValueChange={([val]) => setGridSize(val)}
                            className="py-1"
                        />
                    </div>

                    <div className="space-y-2 pt-2 border-t border-white/5">
                        <div className="flex justify-between text-[10px] uppercase text-neutral-400 font-mono">
                            <span>Opacity</span>
                            <span>{Math.round(gridConfig.opacity * 100)}%</span>
                        </div>
                        <Slider 
                            value={[gridConfig.opacity]} 
                            min={0.05} 
                            max={1} 
                            step={0.05} 
                            onValueChange={([val]) => setGridOpacity(val)}
                            className="py-1"
                        />
                    </div>
                </div>
            </div>

            {/* Widget Library */}
            <div className="space-y-2">
                <div className="flex items-center gap-2 mb-2">
                    <Grid className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    <h3 className="text-sm font-bold tracking-wider">WIDGET LIBRARY</h3>
                </div>

                <Accordion type="single" collapsible className="w-full space-y-1">
                    {categories.map((cat) => (
                        <AccordionItem key={cat.id} value={cat.id} className="border-white/5 bg-white/5 rounded-lg px-2">
                            <AccordionTrigger className="text-xs font-medium py-2 hover:no-underline hover:text-[hsl(var(--color-execution))]">
                                <div className="flex items-center gap-2">
                                    <cat.icon className="w-3.5 h-3.5 text-neutral-400" />
                                    {cat.title}
                                </div>
                            </AccordionTrigger>
                            <AccordionContent className="pb-2 pt-1">
                                <div className="grid grid-cols-1 gap-2">
                                    {cat.items.map((w) => (
                                        <Button
                                            key={w.id}
                                            variant="ghost"
                                            className="justify-start h-8 px-2 text-[10px] text-neutral-300 hover:text-white hover:bg-white/10 w-full"
                                            onClick={() => handleAddWidget(w.id)}
                                        >
                                            <w.icon className="w-3.5 h-3.5 mr-2 opacity-70" />
                                            {w.label}
                                            <Plus className="w-3 h-3 ml-auto opacity-50" />
                                        </Button>
                                    ))}
                                </div>
                            </AccordionContent>
                        </AccordionItem>
                    ))}
                </Accordion>
                
                <Link to={createPageUrl('Marketplace')}>
                    <Button 
                        variant="outline" 
                        className="w-full mt-4 border-dashed border-[hsl(var(--color-intent))]/30 hover:border-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))] text-xs gap-2"
                    >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        Get More Widgets
                    </Button>
                </Link>
            </div>
        </div>
    );
}