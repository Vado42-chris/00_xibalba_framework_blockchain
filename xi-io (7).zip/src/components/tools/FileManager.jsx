import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Folder, File, Upload, Trash2, Download, 
    Search, Grid, List, MoreVertical, FileText, 
    Image, Film, Music, Box, RefreshCw
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
    DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { IntentText, StateText, OrientingText } from '@/components/ui/design-system/System';

const FILE_ICONS = {
    'image': Image,
    'video': Film,
    'audio': Music,
    'document': FileText,
    'archive': Box,
    'other': File
};

export default function FileManager() {
    const [viewMode, setViewMode] = useState('list'); // 'grid' | 'list'
    const [search, setSearch] = useState('');
    const queryClient = useQueryClient();
    const fileInputRef = React.useRef(null);

    // --- DATA ---
    const { data: files = [], isLoading } = useQuery({
        queryKey: ['files'],
        queryFn: () => base44.entities.FileRecord.list('-created_date'),
        initialData: []
    });

    // --- MUTATIONS ---
    const uploadMutation = useMutation({
        mutationFn: async (file) => {
            // 1. Upload to storage
            const { file_url } = await base44.integrations.Core.UploadFile({ file });
            
            // 2. Create FileRecord entity
            return await base44.entities.FileRecord.create({
                name: file.name,
                url: file_url,
                size: file.size,
                mime_type: file.type,
                category: file.type.startsWith('image') ? 'image' : 
                          file.type.startsWith('video') ? 'video' : 
                          'document',
                path: '/'
            });
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['files']);
            toast.success("File uploaded successfully");
        },
        onError: () => toast.error("Upload failed")
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.FileRecord.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries(['files']);
            toast.success("File deleted");
        }
    });

    // --- HANDLERS ---
    const handleFileUpload = (e) => {
        const file = e.target.files?.[0];
        if (file) {
            uploadMutation.mutate(file);
        }
    };

    const filteredFiles = files.filter(f => 
        f.name.toLowerCase().includes(search.toLowerCase())
    );

    const FileCard = ({ file }) => {
        const Icon = FILE_ICONS[file.category] || File;
        
        return (
            <div className={cn(
                "group relative border border-white/5 rounded p-3 hover:bg-neutral-800 transition-colors",
                viewMode === 'grid' ? "flex flex-col items-center text-center gap-2 aspect-square justify-center" : "flex items-center gap-3"
            )}>
                <div className={cn(
                    "flex items-center justify-center rounded bg-neutral-900",
                    viewMode === 'grid' ? "w-12 h-12" : "w-8 h-8"
                )}>
                    {file.category === 'image' ? (
                        <img src={file.url} alt={file.name} className="w-full h-full object-cover rounded opacity-80 group-hover:opacity-100" />
                    ) : (
                        <Icon className="w-1/2 h-1/2 text-neutral-400" />
                    )}
                </div>

                <div className={cn("flex-1 min-w-0", viewMode === 'grid' && "w-full")}>
                    <IntentText className="truncate text-xs font-medium w-full">{file.name}</IntentText>
                    <StateText className="text-[10px] opacity-50">{(file.size / 1024).toFixed(1)} KB</StateText>
                </div>

                <div className={cn(
                    "absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-black/50 rounded",
                    viewMode === 'list' && "static bg-transparent opacity-100"
                )}>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                                <MoreVertical className="w-3 h-3" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => window.open(file.url, '_blank')}>
                                <Download className="w-3 h-3 mr-2" /> Download
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-500" onClick={() => deleteMutation.mutate(file.id)}>
                                <Trash2 className="w-3 h-3 mr-2" /> Delete
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </div>
        );
    };

    return (
        <div className="h-full flex flex-col bg-neutral-950">
            {/* Header */}
            <div className="p-4 border-b border-white/10 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                    <OrientingText className="tracking-widest">FILE SYSTEM</OrientingText>
                    <input 
                        type="file" 
                        className="hidden" 
                        ref={fileInputRef} 
                        onChange={handleFileUpload} 
                    />
                    <Button 
                        size="sm" 
                        className="h-7 text-xs bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploadMutation.isPending}
                    >
                        {uploadMutation.isPending ? <RefreshCw className="w-3 h-3 animate-spin mr-2" /> : <Upload className="w-3 h-3 mr-2" />}
                        Upload
                    </Button>
                </div>

                <div className="flex gap-2">
                    <div className="relative flex-1">
                        <Search className="absolute left-2 top-1.5 w-3 h-3 text-neutral-500" />
                        <Input 
                            placeholder="Search files..." 
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="h-7 pl-7 text-xs bg-neutral-900 border-white/10"
                        />
                    </div>
                    <div className="flex border border-white/10 rounded overflow-hidden">
                        <button 
                            onClick={() => setViewMode('list')}
                            className={cn("p-1.5 hover:bg-white/5", viewMode === 'list' && "bg-white/10 text-white")}
                        >
                            <List className="w-3 h-3" />
                        </button>
                        <button 
                            onClick={() => setViewMode('grid')}
                            className={cn("p-1.5 hover:bg-white/5", viewMode === 'grid' && "bg-white/10 text-white")}
                        >
                            <Grid className="w-3 h-3" />
                        </button>
                    </div>
                </div>
            </div>

            {/* File List */}
            <div className="flex-1 overflow-y-auto p-4">
                {isLoading ? (
                    <div className="flex justify-center p-8"><RefreshCw className="w-4 h-4 animate-spin opacity-50" /></div>
                ) : filteredFiles.length === 0 ? (
                    <div className="text-center py-8 opacity-30">
                        <Folder className="w-8 h-8 mx-auto mb-2" />
                        <OrientingText>No files found</OrientingText>
                    </div>
                ) : (
                    <div className={cn(
                        "gap-2",
                        viewMode === 'grid' ? "grid grid-cols-3" : "flex flex-col"
                    )}>
                        {filteredFiles.map(file => (
                            <FileCard key={file.id} file={file} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}