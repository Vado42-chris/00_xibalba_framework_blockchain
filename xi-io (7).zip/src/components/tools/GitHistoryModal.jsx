import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { GitCommit, GitBranch, GitMerge, Clock, User, Hash } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

export default function GitHistoryModal({ open, onOpenChange }) {
    const commits = [
        { id: "7f3a9b", msg: "feat(deploy): implement drag-and-drop uploader", author: "Observer", time: "10m ago", type: "feat" },
        { id: "2c8e1d", msg: "fix(security): patch zip extraction vulnerability", author: "Sentinel", time: "45m ago", type: "fix" },
        { id: "9a4b2c", msg: "chore(deps): upgrade xi-core to v2.4.1", author: "System", time: "2h ago", type: "chore" },
        { id: "1d5e3f", msg: "style(ui): unify glasomorphism tokens", author: "Designer", time: "5h ago", type: "style" },
        { id: "6f2a8b", msg: "feat(vpn): add wireguard tunnel visualizer", author: "Observer", time: "1d ago", type: "feat" },
    ];

    const getTypeColor = (type) => {
        switch(type) {
            case 'feat': return "bg-green-500/10 text-green-500 border-green-500/20";
            case 'fix': return "bg-red-500/10 text-red-500 border-red-500/20";
            case 'style': return "bg-pink-500/10 text-pink-500 border-pink-500/20";
            default: return "bg-blue-500/10 text-blue-500 border-blue-500/20";
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl bg-neutral-950 border-white/10 p-0 overflow-hidden">
                <DialogHeader className="px-6 py-4 border-b border-white/5 bg-white/5">
                    <div className="flex items-center justify-between">
                        <DialogTitle className="flex items-center gap-2 text-sm font-mono uppercase tracking-widest">
                            <GitBranch className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                            Repository History
                        </DialogTitle>
                        <Badge variant="outline" className="font-mono text-[10px]">main</Badge>
                    </div>
                </DialogHeader>

                <ScrollArea className="h-[400px] p-6">
                    <div className="relative border-l border-white/10 ml-2 space-y-8">
                        {commits.map((commit, i) => (
                            <div key={commit.id} className="relative pl-6 group">
                                <div className="absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full bg-neutral-900 border border-white/20 group-hover:border-[hsl(var(--color-execution))] group-hover:bg-[hsl(var(--color-execution))] transition-colors" />
                                
                                <div className="flex justify-between items-start mb-1">
                                    <div className="flex items-center gap-2">
                                        <Badge variant="outline" className={`text-[9px] px-1 h-4 ${getTypeColor(commit.type)}`}>
                                            {commit.type}
                                        </Badge>
                                        <span className="text-sm font-medium text-white group-hover:text-[hsl(var(--color-execution))] transition-colors">
                                            {commit.msg}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-1 text-[10px] text-neutral-500 font-mono">
                                        <Hash className="w-3 h-3" />
                                        {commit.id}
                                    </div>
                                </div>

                                <div className="flex items-center gap-4 text-[10px] text-neutral-500">
                                    <div className="flex items-center gap-1.5">
                                        <User className="w-3 h-3" />
                                        {commit.author}
                                    </div>
                                    <div className="flex items-center gap-1.5">
                                        <Clock className="w-3 h-3" />
                                        {commit.time}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </ScrollArea>

                <div className="p-3 bg-neutral-900 border-t border-white/10 flex justify-between items-center text-[10px] text-neutral-500 font-mono px-6">
                    <span>HEAD -&gt; origin/main</span>
                    <span>Last sync: Just now</span>
                </div>
            </DialogContent>
        </Dialog>
    );
}