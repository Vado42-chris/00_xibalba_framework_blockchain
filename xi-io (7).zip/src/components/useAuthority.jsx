import { useState, useEffect } from 'react';
import { logAction } from '@/components/controlPlane';

// Simple event bus for cross-component updates without complex context
const listeners = new Set();

const notify = () => {
  listeners.forEach(l => l());
};

export function useAuthority() {
  // Default state matching the "launch" requirements
  const [authority, setAuthority] = useState({
    role: "ROOT_ADMIN",
    scope: "HOME_CORE",
    policy: "UNRESTRICTED"
  });

  // Role Definitions
  const PERMISSIONS = {
    'ROOT_ADMIN': ['*'],
    'Admin': ['*'],
    'Operator': ['read', 'execute', 'create'],
    'Editor': ['read', 'update', 'create'],
    'Viewer': ['read'],
    'OBSERVER': ['read']
  };

  const hasPermission = (action) => {
    const perms = PERMISSIONS[authority.role] || [];
    if (perms.includes('*')) return true;
    return perms.includes(action);
  };

  useEffect(() => {
    // Load from storage on mount
    const saved = localStorage.getItem('xi_authority_context');
    if (saved) {
      setAuthority(JSON.parse(saved));
    }

    // Subscribe to changes
    const listener = () => {
      const updated = localStorage.getItem('xi_authority_context');
      if (updated) {
        setAuthority(JSON.parse(updated));
      }
    };
    listeners.add(listener);
    return () => listeners.delete(listener);
  }, []);

  const assumeAuthority = async (role, scope = "HOME_CORE") => {
    const newAuth = { ...authority, role, scope };
    
    // Persist
    localStorage.setItem('xi_authority_context', JSON.stringify(newAuth));
    setAuthority(newAuth);
    notify();

    // Log to Control Plane
    await logAction({
      actor: { type: "USER", id: "xi-admin" },
      intent: `Assumed authority role: ${role}`,
      scope: { targets: ["session"], environment: "PRODUCTION" },
      authority: { role: "SYSTEM", policy: "ROOT_ELEVATION" }, // The authority used to *perform* the switch
      reversibility: { undoable: true, undo_window_seconds: 0 },
      requires_confirmation: false
    });
  };

  const releaseAuthority = async () => {
    const newAuth = { role: "OBSERVER", scope: "READ_ONLY", policy: "RESTRICTED" };
    
    localStorage.setItem('xi_authority_context', JSON.stringify(newAuth));
    setAuthority(newAuth);
    notify();

    await logAction({
      actor: { type: "USER", id: "xi-admin" },
      intent: "Released root authority",
      scope: { targets: ["session"], environment: "PRODUCTION" },
      authority: { role: authority.role, policy: "SELF_DEMOTION" },
      reversibility: { undoable: true, undo_window_seconds: 0 },
      requires_confirmation: false
    });
  };

  return {
    ...authority,
    assumeAuthority,
    releaseAuthority,
    hasPermission
  };
}