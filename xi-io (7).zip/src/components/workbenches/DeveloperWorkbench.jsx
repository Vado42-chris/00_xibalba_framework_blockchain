// components/workbenches/DeveloperWorkbench.js
import React, { useState } from 'react';
import { GlassPanel } from '../ui/GlassPanel';
import { ActivityStream } from '../ui/ActivityStream';
import { CommandBar } from '../ui/CommandBar';
import { theme } from '../ui/design-system/design-tokens';

export const DeveloperWorkbench = ({
  workspaceRoot = '/',
}) => {
  const [commandBarOpen, setCommandBarOpen] = useState(false);
  const [terminalOpen, setTerminalOpen] = useState(true);

  // Mock activity items (replace with real data from Base44 integrations)
  const activityItems = [
    {
      id: '1',
      source: 'github',
      type: 'commit',
      title: 'New commit in xi-os repo',
      description: 'Added GlassPanel component',
      timestamp: new Date(),
      relevanceScore: 0.9,
    },
    {
      id: '2',
      source: 'slack',
      type: 'message',
      title: 'Message in #dev-team',
      description: 'Code review requested for PR #42',
      timestamp: new Date(Date.now() - 3600000),
      relevanceScore: 0.7,
    },
  ];

  return (
    <div style={{
      width: '100%',
      height: '100%',
      display: 'grid',
      gridTemplateColumns: '1fr 350px',
      gridTemplateRows: '1fr auto',
      gap: theme.spacing.md,
      padding: theme.spacing.md,
      position: 'relative'
    }}>
      {/* Main Code Area */}
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: theme.spacing.md,
        height: '100%'
      }}>
        <GlassPanel variant="heavy" padding="lg" style={{ flex: 1 }}>
          <div style={{
            color: theme.colors['text-primary'],
            fontFamily: theme.typography['font-mono'],
            fontSize: theme.typography['size-sm'],
            height: '100%',
            display: 'flex',
            flexDirection: 'column'
          }}>
            <div style={{ padding: theme.spacing.md }}>
              <div style={{ color: theme.colors['text-secondary'], marginBottom: theme.spacing.md }}>
                Code Editor (Monaco Integration Placeholder)
              </div>
              <pre style={{ margin: 0, opacity: 0.7 }}>
{`// Example code
function GlassPanel({ children }) {
  return (
    <div className="glass-panel">
      {children}
    </div>
  )
}`}
              </pre>
            </div>
          </div>
        </GlassPanel>

        {/* Terminal */}
        {terminalOpen && (
          <GlassPanel variant="medium" padding="md" style={{ height: '200px' }}>
            <div style={{
              color: theme.colors['text-primary'],
              fontFamily: theme.typography['font-mono'],
              fontSize: theme.typography['size-sm'],
            }}>
              <div style={{ marginBottom: theme.spacing.sm }}>
                <span style={{ color: theme.colors['accent-secondary'] }}>$</span>{' '}
                <span style={{ color: theme.colors['text-secondary'] }}>npm run dev</span>
              </div>
              <div style={{ color: theme.colors['text-accent'] }}>
                Server running on http://localhost:3000
              </div>
            </div>
          </GlassPanel>
        )}
      </div>

      {/* Sidebar */}
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: theme.spacing.md,
      }}>
        {/* AI Pair Programmer */}
        <GlassPanel variant="medium" padding="md">
          <div style={{
            color: theme.colors['text-primary'],
            fontWeight: theme.typography['weight-semibold'],
            marginBottom: theme.spacing.sm,
          }}>
            AI Pair Programmer
          </div>
          <div style={{
            padding: theme.spacing.sm,
            background: 'rgba(255, 255, 255, 0.03)',
            borderRadius: theme.rounding.medium,
            color: theme.colors['text-secondary'],
            fontSize: theme.typography['size-sm'],
          }}>
            Ask: "Explain this function" or "Write tests for this"
          </div>
        </GlassPanel>

        {/* Activity Stream */}
        <GlassPanel variant="medium" padding="md" style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          <div style={{
            color: theme.colors['text-primary'],
            fontWeight: theme.typography['weight-semibold'],
            marginBottom: theme.spacing.md,
          }}>
            Activity Stream
          </div>
          <ActivityStream items={activityItems} maxItems={10} />
        </GlassPanel>
      </div>

      {/* Command Bar */}
      <CommandBar
        isOpen={commandBarOpen}
        onClose={() => setCommandBarOpen(false)}
        results={[
          {
            id: 'run-script',
            type: 'command',
            title: 'Run Script',
            description: 'Execute npm script',
            action: () => console.log('Run script'),
          },
          {
            id: 'open-terminal',
            type: 'command',
            title: 'Open Terminal',
            description: 'Toggle terminal visibility',
            action: () => setTerminalOpen(!terminalOpen),
          },
        ]}
      />
      
      {/* Floating Trigger for Command Bar */}
      {!commandBarOpen && (
        <button
            onClick={() => setCommandBarOpen(true)}
            style={{
                position: 'fixed',
                bottom: '30px',
                right: '30px',
                width: '50px',
                height: '50px',
                borderRadius: '50%',
                background: theme.colors['accent-primary'],
                color: 'white',
                border: 'none',
                boxShadow: theme.shadows['glow-primary'],
                fontSize: '24px',
                cursor: 'pointer',
                zIndex: theme.zIndex.fixed
            }}
        >
            /
        </button>
      )}
    </div>
  );
};