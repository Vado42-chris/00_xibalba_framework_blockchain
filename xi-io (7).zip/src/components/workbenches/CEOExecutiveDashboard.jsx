// components/workbenches/CEOExecutiveDashboard.js
import React from 'react';
import { GlassPanel } from '../ui/GlassPanel';
import { HallbergGraph } from '../ui/HallbergGraph';
import { theme } from '../ui/design-system/design-tokens';

export const CEOExecutiveDashboard = () => {
  // Mock KPI data
  const kpiData = [
    { label: 'MRR', value: '$125K', trend: '+12%', color: theme.colors['accent-success'] },
    { label: 'CAC', value: '$450', trend: '-8%', color: theme.colors['accent-info'] },
    { label: 'Churn', value: '2.1%', trend: '-0.5%', color: theme.colors['accent-warning'] },
  ];

  return (
    <div style={{
      width: '100%',
      height: '100%',
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gridTemplateRows: 'auto 1fr',
      gap: theme.spacing.lg,
      padding: theme.spacing.xl,
    }}>
      {/* KPI Cards */}
      {kpiData.map((kpi) => (
        <GlassPanel key={kpi.label} variant="medium" padding="lg">
          <div style={{
            color: theme.colors['text-secondary'],
            fontSize: theme.typography['size-sm'],
            marginBottom: theme.spacing.xs,
          }}>
            {kpi.label}
          </div>
          <div style={{
            color: theme.colors['text-primary'],
            fontSize: theme.typography['size-2xl'],
            fontWeight: theme.typography['weight-bold'],
            marginBottom: theme.spacing.xs,
          }}>
            {kpi.value}
          </div>
          <div style={{
            color: kpi.trend.startsWith('+') ? theme.colors['accent-success'] : theme.colors['accent-danger'],
            fontSize: theme.typography['size-sm'],
          }}>
            {kpi.trend}
          </div>
        </GlassPanel>
      ))}

      {/* Main Graph */}
      <GlassPanel variant="heavy" padding="lg" style={{
        gridColumn: '1 / -1',
        minHeight: '350px'
      }}>
        <div style={{
          color: theme.colors['text-primary'],
          fontWeight: theme.typography['weight-semibold'],
          marginBottom: theme.spacing.md,
        }}>
          Business Health Overview
        </div>
        <div style={{ height: '300px', width: '100%' }}>
            <HallbergGraph
            data={[
                { x: 0, y: 100, label: 'Jan' },
                { x: 1, y: 120, label: 'Feb' },
                { x: 2, y: 115, label: 'Mar' },
                { x: 3, y: 130, label: 'Apr' },
                { x: 4, y: 125, label: 'May' },
            ]}
            width={800}
            height={300}
            />
        </div>
      </GlassPanel>

      {/* Executive Briefing */}
      <GlassPanel variant="organic" padding="lg" style={{
        gridColumn: '1 / -1',
      }}>
        <div style={{
          color: theme.colors['text-primary'],
          fontWeight: theme.typography['weight-semibold'],
          marginBottom: theme.spacing.md,
        }}>
          Executive Briefing
        </div>
        <div style={{
          color: theme.colors['text-secondary'],
          lineHeight: theme.typography['line-height-relaxed'],
        }}>
          <div style={{ marginBottom: theme.spacing.md }}>
            <strong style={{ color: theme.colors['text-primary'] }}>Top Story:</strong> Competitor X launched a new product. Market sentiment is mixed.
          </div>
          <div style={{ marginBottom: theme.spacing.md }}>
            <strong style={{ color: theme.colors['text-primary'] }}>Finance:</strong> Q3 revenue exceeded projections by 5%. Key drivers were the new 'Enterprise' tier.
          </div>
          <div>
            <strong style={{ color: theme.colors['text-primary'] }}>People:</strong> 3 new senior hires this week, bringing total headcount to 150.
          </div>
        </div>
      </GlassPanel>
    </div>
  );
};