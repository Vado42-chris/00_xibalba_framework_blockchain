// components/workbenches/ProjectManagerWorkbench.js
import React from 'react';
import { GlassPanel } from '../ui/GlassPanel';
import { ActivityStream } from '../ui/ActivityStream';
import { GraphicalIntelligenceDashboard } from '../ui/GraphicalIntelligenceDashboard';
import { theme } from '../ui/design-system/design-tokens';

export const ProjectManagerWorkbench = () => {
  // Mock project graph data
  const projectNodes = [
    { id: 'p1', type: 'project', label: 'Project Phoenix' },
    { id: 't1', type: 'file', label: 'Frontend Tasks' },
    { id: 't2', type: 'file', label: 'Backend Tasks' },
    { id: 'u1', type: 'person', label: 'Sarah (PM)' },
  ];

  const projectEdges = [
    { id: 'e1', from: 'p1', to: 't1', type: 'contains', strength: 0.8 },
    { id: 'e2', from: 'p1', to: 't2', type: 'contains', strength: 0.8 },
    { id: 'e3', from: 'u1', to: 'p1', type: 'collaborates', strength: 1.0 },
  ];

  return (
    <div style={{
      width: '100%',
      height: '100%',
      display: 'grid',
      gridTemplateColumns: '2fr 1fr',
      gridTemplateRows: '1fr auto',
      gap: theme.spacing.lg,
      padding: theme.spacing.lg,
    }}>
      {/* Project Graph */}
      <GlassPanel variant="heavy" padding="lg">
        <div style={{
          color: theme.colors['text-primary'],
          fontWeight: theme.typography['weight-semibold'],
          marginBottom: theme.spacing.md,
        }}>
          Project Command Center
        </div>
        <GraphicalIntelligenceDashboard
          nodes={projectNodes}
          edges={projectEdges}
        />
      </GlassPanel>

      {/* Sidebar */}
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        gap: theme.spacing.md,
      }}>
        {/* Resource Timeline */}
        <GlassPanel variant="medium" padding="md">
          <div style={{
            color: theme.colors['text-primary'],
            fontWeight: theme.typography['weight-semibold'],
            marginBottom: theme.spacing.md,
          }}>
            Resource Timeline
          </div>
          <div style={{
            color: theme.colors['text-secondary'],
            fontSize: theme.typography['size-sm'],
          }}>
            Team workload visualization would go here
          </div>
        </GlassPanel>

        {/* Risk Radar */}
        <GlassPanel variant="medium" padding="md">
          <div style={{
            color: theme.colors['text-primary'],
            fontWeight: theme.typography['weight-semibold'],
            marginBottom: theme.spacing.md,
          }}>
            Risk Radar
          </div>
          <div style={{
            padding: theme.spacing.sm,
            background: 'rgba(239, 68, 68, 0.1)',
            borderRadius: theme.rounding.medium,
            border: `1px solid ${theme.colors['accent-danger']}`,
            color: theme.colors['accent-danger'],
            fontSize: theme.typography['size-sm'],
          }}>
            ⚠️ Frontend Development task is 2 weeks behind schedule
          </div>
        </GlassPanel>
      </div>
    </div>
  );
};