import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { toast } from 'sonner';

const InteractionContext = createContext(null);

export const useInteraction = () => {
    const context = useContext(InteractionContext);
    if (!context) {
        throw new Error('useInteraction must be used within an InteractionManager');
    }
    return context;
};

export const InteractionManager = ({ children, rules: propRules = [] }) => {
    // Registry of component iframes/windows: { [id]: Window }
    const [components, setComponents] = useState(new Map());
    
    // Internal Rules State (for rules added dynamically via addRule)
    const [internalRules, setInternalRules] = useState([]);

    // Combine prop rules (from saved items) and internal rules (from current session/palette)
    const rules = [...propRules, ...internalRules];

    // Register a component (called by SandboxedRenderer)
    const registerComponent = useCallback((id, componentWindow) => {
        setComponents(prev => {
            const next = new Map(prev);
            next.set(id, componentWindow);
            return next;
        });
        console.log(`[XI-KERNEL] Registered Satellite: ${id}`);
    }, []);

    const unregisterComponent = useCallback((id) => {
        setComponents(prev => {
            const next = new Map(prev);
            next.delete(id);
            return next;
        });
        console.log(`[XI-KERNEL] Unregistered Satellite: ${id}`);
    }, []);

    // Add a new rule
    const addRule = useCallback((rule) => {
        setInternalRules(prev => [...prev, { ...rule, id: `rule-${Date.now()}` }]);
        toast.success("Neural Link Established");
    }, []);

    const removeRule = useCallback((ruleId) => {
        setInternalRules(prev => prev.filter(r => r.id !== ruleId));
    }, []);

    // THE EVENT BUS (The Nervous System)
    useEffect(() => {
        const handleMessage = (event) => {
            const msg = event.data;
            
            // Only listen for Signals from Satellites
            if (msg?.type === 'XI_SIGNAL') {
                const { sourceId, eventName, payload } = msg;
                console.log(`[XI-SIGNAL] Received ${eventName} from ${sourceId}`, payload);

                // Find matching rules
                const matchingRules = rules.filter(r => r.sourceId === sourceId && r.event === eventName);

                if (matchingRules.length > 0) {
                    console.log(`[XI-KERNEL] Triggering ${matchingRules.length} reactions`);
                    
                    matchingRules.forEach(rule => {
                        const targetWindow = components.get(rule.targetId);
                        if (targetWindow) {
                            // Execute Command on Target
                            targetWindow.postMessage({
                                type: 'XI_COMMAND',
                                action: rule.action,
                                payload: rule.payload || payload // Pass original payload if no override
                            }, '*');
                        } else {
                            console.warn(`[XI-KERNEL] Target ${rule.targetId} not found or offline.`);
                        }
                    });
                }
            }
        };

        window.addEventListener('message', handleMessage);
        return () => window.removeEventListener('message', handleMessage);
    }, [rules, components]);

    return (
        <InteractionContext.Provider value={{ 
            registerComponent, 
            unregisterComponent, 
            rules, 
            addRule, 
            removeRule,
            components 
        }}>
            {children}
        </InteractionContext.Provider>
    );
};