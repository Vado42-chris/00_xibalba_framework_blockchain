import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from '@/api/base44Client';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { toast } from "sonner";
import { Minus, Plus, Trash2, CheckCircle2 } from 'lucide-react';
import { SystemCompletion } from '@/components/ui/design-system/SystemDialogs';

export default function CreateOrderModal({ open, onOpenChange }) {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [selectedItems, setSelectedItems] = useState([]); // Array of { item, quantity }
  const [showSuccess, setShowSuccess] = useState(false);
  const [orderId, setOrderId] = useState('');

  const { data: inventory = [] } = useQuery({
      queryKey: ['inventory'],
      queryFn: async () => {
          if (!base44.entities.InventoryItem) return [];
          return await base44.entities.InventoryItem.list();
      },
      initialData: []
  });

  // Calculate Total
  const total = selectedItems.reduce((sum, line) => sum + (line.item.price * line.quantity), 0);

  const addItem = (itemId) => {
      const item = inventory.find(i => i.id === itemId);
      if (!item) return;
      
      const existing = selectedItems.find(i => i.item.id === itemId);
      if (existing) {
          setSelectedItems(selectedItems.map(i => 
              i.item.id === itemId ? { ...i, quantity: i.quantity + 1 } : i
          ));
      } else {
          setSelectedItems([...selectedItems, { item, quantity: 1 }]);
      }
  };

  const removeItem = (itemId) => {
      setSelectedItems(selectedItems.filter(i => i.item.id !== itemId));
  };

  const handleClose = () => {
      setShowSuccess(false);
      setCustomerName('');
      setSelectedItems([]);
      onOpenChange(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (selectedItems.length === 0) {
        toast.error("Please add at least one item");
        return;
    }

    setLoading(true);
    try {
      // 1. Create Order
      const newOrder = await base44.entities.Order.create({
        customer_name: customerName,
        total: total,
        status: 'pending',
        items: selectedItems.map(line => ({
            id: line.item.id,
            name: line.item.name,
            price: line.item.price,
            quantity: line.quantity,
            sku: line.item.sku
        })),
        order_date: new Date().toISOString()
      });

      // 2. Decrement Inventory
      await Promise.all(selectedItems.map(line => 
          base44.entities.InventoryItem.update(line.item.id, {
              quantity: Math.max(0, line.item.quantity - line.quantity)
          })
      ));

      await queryClient.invalidateQueries({ queryKey: ['orders'] });
      await queryClient.invalidateQueries({ queryKey: ['inventory'] });
      
      setOrderId(newOrder.id);
      setShowSuccess(true);
    } catch (err) {
      console.error(err);
      toast.error("Failed to process order");
    } finally {
      setLoading(false);
    }
  };

  if (showSuccess) {
      return (
          <SystemCompletion 
              open={open}
              onOpenChange={handleClose}
              title="Order Confirmed"
              description="Transaction recorded on the ledger. Inventory has been updated."
              stats={[
                  { label: "Customer", value: customerName },
                  { label: "Total Value", value: `$${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}` },
                  { label: "Items", value: selectedItems.length }
              ]}
          />
      );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[hsl(var(--layer-orientation))] border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-intent))]">
        <DialogHeader>
          <DialogTitle>Create New Order</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
           {/* Customer Info */}
           <div className="space-y-2">
              <Label className="text-[hsl(var(--fg-orientation))] text-xs uppercase tracking-wider">Customer Identity</Label>
              <Input 
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                className="bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))] h-10"
                placeholder="Organization or Individual Name"
                required
              />
           </div>

           {/* Item Selection */}
           <div className="space-y-3">
              <div className="flex justify-between items-center">
                  <Label className="text-[hsl(var(--fg-orientation))] text-xs uppercase tracking-wider">Manifest</Label>
                  <Select onValueChange={addItem}>
                      <SelectTrigger className="w-[180px] h-8 text-xs bg-[hsl(var(--layer-orientation))] border-none">
                          <SelectValue placeholder="Add Item to Order" />
                      </SelectTrigger>
                      <SelectContent>
                          {inventory.map(item => (
                              <SelectItem key={item.id} value={item.id} disabled={item.quantity < 1}>
                                  {item.name} (${item.price})
                              </SelectItem>
                          ))}
                      </SelectContent>
                  </Select>
              </div>

              <div className="bg-[hsl(var(--layer-orientation))]/30 rounded border border-[hsl(var(--layer-orientation))] min-h-[150px] p-2 space-y-2">
                  {selectedItems.length === 0 && (
                      <div className="h-full flex flex-col items-center justify-center opacity-50 text-xs py-8">
                          No items added to manifest.
                      </div>
                  )}
                  {selectedItems.map((line, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-[hsl(var(--void))] border border-[hsl(var(--layer-orientation))] rounded">
                          <div>
                              <div className="text-sm font-bold text-[hsl(var(--fg-intent))]">{line.item.name}</div>
                              <div className="text-[10px] text-[hsl(var(--fg-orientation))] font-mono">{line.item.sku} • ${line.item.price}</div>
                          </div>
                          <div className="flex items-center gap-3">
                              <div className="font-mono text-sm">x{line.quantity}</div>
                              <Button size="icon" variant="ghost" className="h-6 w-6 text-[hsl(var(--color-warning))]" onClick={() => removeItem(line.item.id)}>
                                  <Trash2 className="w-3 h-3" />
                              </Button>
                          </div>
                      </div>
                  ))}
              </div>
           </div>

           {/* Summary */}
           <div className="flex justify-between items-end border-t border-[hsl(var(--layer-orientation))] pt-4">
              <div className="text-xs text-[hsl(var(--fg-orientation))]">
                  {selectedItems.length} line items
              </div>
              <div className="text-right">
                  <div className="text-[10px] text-[hsl(var(--fg-orientation))] uppercase tracking-wider">Total Value</div>
                  <div className="text-2xl font-bold text-[hsl(var(--color-active))] font-mono">
                      ${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
              </div>
           </div>

           <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" className="bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/80 text-black font-bold" disabled={loading}>
                 {loading ? "Processing..." : "Confirm Order"}
              </Button>
           </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}