import React, { useState } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle2, CreditCard, Lock, ArrowRight, ExternalLink } from "lucide-react";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";

export const StripeWizard = ({ open, onOpenChange, onConfigured }) => {
    const [step, setStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [config, setConfig] = useState({
        secretKey: '',
        publishableKey: '',
        webhookSecret: '',
        priceId: ''
    });

    const handleSubmit = async () => {
        setLoading(true);
        try {
            await base44.functions.invoke('configureStripe', { config });
            toast.success("Payment Gateway Initialized", {
                description: "Your sovereign commerce engine is ready."
            });
            onConfigured?.();
            onOpenChange(false);
        } catch (e) {
            toast.error("Configuration Failed", { description: e.message });
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl bg-[#0a0a0a] border-white/10 text-white p-0 overflow-hidden flex flex-col h-[500px]">
                {/* Header */}
                <div className="p-6 border-b border-white/10 bg-neutral-900/50 flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-light">Commerce Activation</h2>
                        <p className="text-xs text-neutral-400">Step {step} of 3: {
                            step === 1 ? "Gateway Credentials" : 
                            step === 2 ? "Product Configuration" : 
                            "Verification"
                        }</p>
                    </div>
                    <div className="flex gap-1">
                        {[1, 2, 3].map(i => (
                            <div key={i} className={`h-1 w-8 rounded-full transition-colors ${i <= step ? 'bg-[hsl(var(--color-intent))]' : 'bg-white/10'}`} />
                        ))}
                    </div>
                </div>

                {/* Body */}
                <div className="flex-1 p-8 overflow-y-auto">
                    {step === 1 && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                            <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg flex gap-3">
                                <Lock className="w-5 h-5 text-blue-400 shrink-0" />
                                <p className="text-xs text-blue-200">
                                    Your keys are encrypted with AES-256 before storage. 
                                    Valhalla does not share these credentials.
                                </p>
                            </div>

                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <Label>Stripe Secret Key (sk_...)</Label>
                                    <Input 
                                        type="password" 
                                        value={config.secretKey}
                                        onChange={e => setConfig({...config, secretKey: e.target.value})}
                                        placeholder="sk_live_..."
                                        className="font-mono bg-black/50"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label>Webhook Secret (whsec_...)</Label>
                                    <Input 
                                        type="password" 
                                        value={config.webhookSecret}
                                        onChange={e => setConfig({...config, webhookSecret: e.target.value})}
                                        placeholder="whsec_..."
                                        className="font-mono bg-black/50"
                                    />
                                </div>
                            </div>
                            
                            <a href="https://dashboard.stripe.com/apikeys" target="_blank" rel="noreferrer" className="text-xs text-[hsl(var(--color-intent))] flex items-center gap-1 hover:underline">
                                Get keys from Stripe Dashboard <ExternalLink className="w-3 h-3" />
                            </a>
                        </div>
                    )}

                    {step === 2 && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
                            <div className="text-center mb-8">
                                <div className="w-12 h-12 bg-[hsl(var(--color-intent))]/10 rounded-full flex items-center justify-center mx-auto mb-3">
                                    <CrownIcon className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                                </div>
                                <h3 className="text-lg font-bold">Concierge Service Plan</h3>
                                <p className="text-neutral-400 text-sm">Set the Price ID for your primary subscription offering.</p>
                            </div>

                            <div className="space-y-2">
                                <Label>Stripe Price ID (price_...)</Label>
                                <Input 
                                    value={config.priceId}
                                    onChange={e => setConfig({...config, priceId: e.target.value})}
                                    placeholder="price_123..."
                                    className="font-mono bg-black/50"
                                />
                                <p className="text-[10px] text-neutral-500">
                                    Found in Stripe Dashboard under Products &gt; Pricing.
                                </p>
                            </div>
                        </div>
                    )}

                    {step === 3 && (
                        <div className="text-center space-y-6 pt-8 animate-in fade-in slide-in-from-right-4">
                            <div className="relative w-20 h-20 mx-auto">
                                <div className="absolute inset-0 bg-[hsl(var(--color-intent))]/20 rounded-full animate-ping" />
                                <div className="relative bg-[hsl(var(--color-intent))]/10 rounded-full p-5 border border-[hsl(var(--color-intent))]/50">
                                    <CheckCircle2 className="w-full h-full text-[hsl(var(--color-intent))]" />
                                </div>
                            </div>
                            <div>
                                <h3 className="text-xl font-bold text-white">Ready to Initialize</h3>
                                <p className="text-neutral-400 max-w-xs mx-auto mt-2 text-sm">
                                    We will securely store your credentials and activate the Concierge payment flows.
                                </p>
                            </div>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="p-6 border-t border-white/10 bg-neutral-900/50 flex justify-between">
                    <Button 
                        variant="ghost" 
                        onClick={() => step > 1 ? setStep(step - 1) : onOpenChange(false)}
                        disabled={loading}
                    >
                        {step === 1 ? "Cancel" : "Back"}
                    </Button>
                    
                    {step < 3 ? (
                        <Button 
                            className="bg-white text-black hover:bg-neutral-200"
                            onClick={() => setStep(step + 1)}
                            disabled={
                                (step === 1 && (!config.secretKey || !config.webhookSecret)) || 
                                (step === 2 && !config.priceId)
                            }
                        >
                            Next <ArrowRight className="w-4 h-4 ml-2" />
                        </Button>
                    ) : (
                        <Button 
                            className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold"
                            onClick={handleSubmit}
                            disabled={loading}
                        >
                            {loading ? "Activating..." : "Activate Module"}
                        </Button>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
};

const CrownIcon = (props) => (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14" />
    </svg>
)