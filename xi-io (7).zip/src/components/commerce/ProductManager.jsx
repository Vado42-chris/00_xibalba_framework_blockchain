import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { base44 } from '@/api/base44Client';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { 
    QuadrantGrid, Quadrant, OrientingText, 
    IntentText, StateText, SemanticDot, Layer, ChartFrame 
} from '@/components/ui/design-system/System';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { 
    Database, Search, Plus, Trash2, Save, X, 
    Zap, Activity, Box, BarChart3, Wrench, ArrowRight
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { cn } from '@/lib/utils';
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis } from 'recharts';

/* -------------------------------------------------------------------------- */
/*                                SUB-COMPONENTS                              */
/* -------------------------------------------------------------------------- */

const ProductList = ({ items, selectedId, onSelect, onNew }) => {
    const [search, setSearch] = useState('');
    
    const filtered = items.filter(i => 
        i.name.toLowerCase().includes(search.toLowerCase()) || 
        i.sku.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b border-white/5 space-y-4">
                <div className="flex justify-between items-center">
                    <OrientingText className="tracking-widest font-bold text-orange-500">INVENTORY</OrientingText>
                    <Button size="sm" onClick={onNew} className="h-6 text-[10px] bg-orange-500 hover:bg-orange-600 text-white gap-1">
                        <Plus className="w-3 h-3" /> ADD NEW
                    </Button>
                </div>
                <div className="relative">
                    <Search className="absolute left-2 top-2 w-4 h-4 text-neutral-500" />
                    <Input 
                        placeholder="Search SKU or Name..." 
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        className="pl-8 bg-neutral-900 border-white/10 h-8 text-xs"
                    />
                </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {filtered.map(item => (
                    <SystemCard
                        key={item.id}
                        title={item.name}
                        subtitle={item.sku}
                        status={item.quantity < 10 ? 'warning' : 'settled'}
                        metric={`${item.quantity} units`}
                        active={selectedId === item.id}
                        onClick={() => onSelect(item)}
                        icon={Box}
                    >
                        <div className="flex justify-between items-center mt-1">
                            <Badge variant="outline" className="text-[9px] h-4 border-white/10 text-neutral-500">{item.category}</Badge>
                            <StateText className="text-[10px]">${item.price}</StateText>
                        </div>
                    </SystemCard>
                ))}
            </div>
        </div>
    );
};

const ProductEditor = ({ item, onSave, onCancel, onDelete }) => {
    const { register, handleSubmit, setValue, watch } = useForm({
        defaultValues: item || {
            name: '', sku: '', price: 0, quantity: 0,
            category: 'automation', distro_base: '', license_type: 'free_open'
        }
    });

    const category = watch('category');
    const license = watch('license_type');

    return (
        <form onSubmit={handleSubmit(onSave)} className="space-y-6 animate-in slide-in-from-right-4 duration-300">
            <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>Product Name</Label>
                        <Input {...register('name', { required: true })} className="bg-neutral-950 border-white/10" />
                    </div>
                    <div className="space-y-2">
                        <Label>SKU / Hash</Label>
                        <Input {...register('sku', { required: true })} className="bg-neutral-950 border-white/10 font-mono" />
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                        <Label>Category</Label>
                        <Select value={category} onValueChange={v => setValue('category', v)}>
                            <SelectTrigger className="bg-neutral-950 border-white/10"><SelectValue /></SelectTrigger>
                            <SelectContent className="bg-neutral-900 border-white/10">
                                <SelectItem value="automation">Automation</SelectItem>
                                <SelectItem value="training">Training</SelectItem>
                                <SelectItem value="inference">Inference</SelectItem>
                                <SelectItem value="analytics">Analytics</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>License Model</Label>
                        <Select value={license} onValueChange={v => setValue('license_type', v)}>
                            <SelectTrigger className="bg-neutral-950 border-white/10"><SelectValue /></SelectTrigger>
                            <SelectContent className="bg-neutral-900 border-white/10">
                                <SelectItem value="free_open">Open Source</SelectItem>
                                <SelectItem value="commercial_support">Commercial</SelectItem>
                                <SelectItem value="white_label">White Label</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2 col-span-2">
                        <Label>Base Distro</Label>
                        <Input {...register('distro_base')} className="bg-neutral-950 border-white/10" placeholder="e.g. Alpine Linux" />
                    </div>
                    <div className="space-y-2">
                        <Label>Units (Capacity)</Label>
                        <Input type="number" {...register('quantity')} className="bg-neutral-950 border-white/10" />
                    </div>
                </div>

                <div className="space-y-2">
                    <Label>Monthly Service Cost ($)</Label>
                    <div className="relative">
                        <span className="absolute left-3 top-2.5 text-neutral-500 text-xs">$</span>
                        <Input type="number" step="0.01" {...register('price')} className="pl-6 bg-neutral-950 border-white/10" />
                    </div>
                </div>
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-white/5">
                {item?.id ? (
                    <Button type="button" variant="ghost" onClick={onDelete} className="text-red-500 hover:text-red-400 hover:bg-red-500/10">
                        <Trash2 className="w-4 h-4 mr-2" /> Delete
                    </Button>
                ) : <div />}
                
                <div className="flex gap-2">
                    <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
                    <Button type="submit" className="bg-orange-500 hover:bg-orange-600 text-white">
                        <Save className="w-4 h-4 mr-2" /> Save Changes
                    </Button>
                </div>
            </div>
        </form>
    );
};

const AIDiagnostics = ({ item }) => {
    return (
        <div className="space-y-4 animate-in slide-in-from-right-4 duration-300">
            <div className="p-4 bg-[hsl(var(--color-intent))]/5 border border-[hsl(var(--color-intent))]/20 rounded-lg">
                <div className="flex items-center gap-2 mb-2 text-[hsl(var(--color-intent))]">
                    <Zap className="w-4 h-4" />
                    <IntentText className="font-bold">Optimization Analysis</IntentText>
                </div>
                <StateText className="opacity-70 leading-relaxed">
                    Based on current market demand for <strong>{item.category}</strong> modules, this unit is priced {item.price > 50 ? 'above' : 'below'} the efficiency curve. 
                    Recommended action: {item.price > 50 ? 'Consider bundling support hours to increase value proposition.' : 'Increase base capacity limit to drive higher volume.'}
                </StateText>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-neutral-950 border border-white/5 rounded">
                    <StateText className="opacity-50 mb-1">Predicted Demand</StateText>
                    <div className="text-lg font-bold text-green-500">+12% <span className="text-xs font-normal text-neutral-500">/ mo</span></div>
                </div>
                <div className="p-3 bg-neutral-950 border border-white/5 rounded">
                    <StateText className="opacity-50 mb-1">Churn Risk</StateText>
                    <div className="text-lg font-bold text-orange-500">Low <span className="text-xs font-normal text-neutral-500">(3.2%)</span></div>
                </div>
            </div>

            <div className="h-48 w-full bg-neutral-900/50 rounded border border-white/5 p-2">
                 <ChartFrame label="Market Trajectory" metric="Growth" trend="+4.5%" category="intent">
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={[
                            {v: 40}, {v: 30}, {v: 45}, {v: 50}, {v: 65}, {v: 60}, {v: 75}
                        ]}>
                            <Line type="monotone" dataKey="v" stroke="hsl(var(--color-intent))" strokeWidth={2} dot={false} />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#171717', border: '1px solid #333' }}
                                itemStyle={{ color: '#fff' }}
                            />
                        </LineChart>
                    </ResponsiveContainer>
                 </ChartFrame>
            </div>
            
            <Button className="w-full bg-neutral-800 hover:bg-neutral-700 text-white border border-white/10">
                <Wrench className="w-4 h-4 mr-2" /> Apply Auto-Optimization
            </Button>
        </div>
    );
};

/* -------------------------------------------------------------------------- */
/*                                MAIN COMPONENT                              */
/* -------------------------------------------------------------------------- */

export default function ProductManager() {
    const queryClient = useQueryClient();
    const [selectedItem, setSelectedItem] = useState(null);
    const [viewMode, setViewMode] = useState('details'); // details, edit, ai

    const { data: items = [] } = useQuery({
        queryKey: ['inventory'],
        queryFn: () => base44.entities.InventoryItem.list(),
        initialData: []
    });

    const mutation = useMutation({
        mutationFn: (data) => {
            const payload = { ...data, quantity: parseInt(data.quantity), price: parseFloat(data.price) };
            if (payload.id) return base44.entities.InventoryItem.update(payload.id, payload);
            return base44.entities.InventoryItem.create(payload);
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['inventory']);
            toast.success("Inventory Record Updated");
            setViewMode('details');
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (id) => base44.entities.InventoryItem.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries(['inventory']);
            setSelectedItem(null);
            toast.success("Item Removed");
        }
    });

    const handleNew = () => {
        const newItem = { name: 'New Item', sku: `NEW-${Math.floor(Math.random()*1000)}`, price: 0, quantity: 1, category: 'automation' };
        setSelectedItem(newItem);
        setViewMode('edit');
    };

    return (
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="state" dominance="dominant" className="border-r border-white/5 h-full p-0">
                        <ProductList 
                            items={items} 
                            selectedId={selectedItem?.id} 
                            onSelect={(item) => { setSelectedItem(item); setViewMode('details'); }}
                            onNew={handleNew}
                        />
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="h-full p-0 flex flex-col">
                        {selectedItem ? (
                            <>
                                {/* Header */}
                                <SystemDetailHeader
                                    title={selectedItem.name || 'New Item'}
                                    subtitle={selectedItem.sku}
                                    category="PRODUCT"
                                    icon={Box}
                                >
                                    <Tabs value={viewMode} onValueChange={setViewMode}>
                                        <TabsList className="bg-neutral-950 border border-white/10">
                                            <TabsTrigger value="details">Details</TabsTrigger>
                                            <TabsTrigger value="edit">Edit</TabsTrigger>
                                            <TabsTrigger value="ai" className="data-[state=active]:text-orange-500">
                                                <Zap className="w-3 h-3 mr-2" /> Analysis
                                            </TabsTrigger>
                                        </TabsList>
                                    </Tabs>
                                </SystemDetailHeader>

                                {/* Content */}
                                <div className="flex-1 overflow-y-auto p-6 bg-neutral-950/50">
                                    {viewMode === 'details' && (
                                        <div className="space-y-6 animate-in fade-in duration-300">
                                            <div className="grid grid-cols-2 gap-6">
                                                <Layer level="state" className="space-y-1">
                                                    <OrientingText>LICENSE TYPE</OrientingText>
                                                    <IntentText className="capitalize">{selectedItem.license_type?.replace('_', ' ') || 'Standard'}</IntentText>
                                                </Layer>
                                                <Layer level="state" className="space-y-1">
                                                    <OrientingText>BASE DISTRO</OrientingText>
                                                    <IntentText>{selectedItem.distro_base || 'Unknown'}</IntentText>
                                                </Layer>
                                                <Layer level="state" className="space-y-1">
                                                    <OrientingText>UNIT PRICE</OrientingText>
                                                    <IntentText className="text-xl font-mono text-orange-500">${selectedItem.price?.toFixed(2)}</IntentText>
                                                </Layer>
                                                <Layer level="state" className="space-y-1">
                                                    <OrientingText>AVAILABLE STOCK</OrientingText>
                                                    <IntentText className="text-xl font-mono">{selectedItem.quantity}</IntentText>
                                                </Layer>
                                            </div>
                                            
                                            <div className="p-4 border border-white/5 rounded bg-neutral-900/30">
                                                <div className="flex justify-between items-center mb-4">
                                                    <OrientingText>RECENT ACTIVITY</OrientingText>
                                                    <Button size="sm" variant="ghost" className="text-xs h-6">View Log</Button>
                                                </div>
                                                <div className="space-y-2">
                                                    <div className="flex justify-between text-xs p-2 bg-neutral-950/50 rounded">
                                                        <span className="text-neutral-400">Restock +50 units</span>
                                                        <span className="text-neutral-600 font-mono">2h ago</span>
                                                    </div>
                                                    <div className="flex justify-between text-xs p-2 bg-neutral-950/50 rounded">
                                                        <span className="text-neutral-400">Price adjustment</span>
                                                        <span className="text-neutral-600 font-mono">1d ago</span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div className="flex justify-end pt-4">
                                                 <Button onClick={() => setViewMode('edit')} className="bg-white/5 hover:bg-white/10 text-neutral-300">
                                                    <Wrench className="w-4 h-4 mr-2" /> Modify Configuration
                                                 </Button>
                                            </div>
                                        </div>
                                    )}

                                    {viewMode === 'edit' && (
                                        <ProductEditor 
                                            item={selectedItem} 
                                            onSave={(data) => mutation.mutate({ ...data, id: selectedItem.id })}
                                            onCancel={() => setViewMode('details')}
                                            onDelete={() => deleteMutation.mutate(selectedItem.id)}
                                        />
                                    )}

                                    {viewMode === 'ai' && (
                                        <AIDiagnostics item={selectedItem} />
                                    )}
                                </div>
                            </>
                        ) : (
                            <div className="h-full flex flex-col items-center justify-center text-center p-8 opacity-50 space-y-4">
                                <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center animate-pulse">
                                    <Activity className="w-8 h-8 text-neutral-500" />
                                </div>
                                <div>
                                    <IntentText className="text-xl font-light">Inventory Control</IntentText>
                                    <StateText>Select an item from the registry to manage specs, pricing, and optimization.</StateText>
                                </div>
                            </div>
                        )}
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    );
}