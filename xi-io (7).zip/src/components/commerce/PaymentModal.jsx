import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from 'sonner';
import { Loader2, CreditCard, Shield, Lock, CheckCircle2 } from 'lucide-react';
import { backendClient } from '@/components/api/backendClient';

export default function PaymentModal({ open, onOpenChange, item, type = 'product' }) {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Reset state when modal opens
    useEffect(() => {
        if (open) {
            setLoading(false);
            setError(null);
        }
    }, [open]);

    const handlePurchase = async () => {
        setLoading(true);
        setError(null);

        try {
            // 1. Create a checkout session using the backend API
            // Using backendClient which handles auth and connects to the backend function
            const response = await backendClient.createCheckoutSession({
                items: [
                    {
                        name: item.name,
                        amount: typeof item.price === 'string' 
                            ? parseInt(item.price.replace(/[^0-9]/g, '')) * 100 // Convert "$29" to 2900 cents
                            : 1000, // Default fallback
                        quantity: 1
                    }
                ],
                success_url: window.location.origin + '/Settings?session_id={CHECKOUT_SESSION_ID}&payment=success',
                cancel_url: window.location.href
            });

            // 2. Redirect to the Stripe Checkout URL provided by the backend
            if (response.url) {
                window.location.href = response.url;
            } else {
                throw new Error("No checkout URL returned from server");
            }

        } catch (err) {
            console.error("Payment initiation failed:", err);
            
            // Handle specific error cases
            if (err.message && err.message.includes("Stripe is not configured")) {
                setError("Payment system is currently in maintenance mode. Please try again later.");
            } else {
                setError("Failed to initiate secure checkout. Please try again.");
            }
            
            toast.error("Payment initialization failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-md bg-neutral-900 border-white/10 text-white">
                <DialogHeader>
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 rounded-lg bg-[hsl(var(--color-intent))]/10">
                            <CreditCard className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                        </div>
                        <div>
                            <DialogTitle>Secure Checkout</DialogTitle>
                            <DialogDescription className="text-neutral-400">
                                Powered by Stripe Payments
                            </DialogDescription>
                        </div>
                    </div>
                </DialogHeader>

                <div className="py-6 space-y-6">
                    {/* Order Summary */}
                    <div className="p-4 rounded-lg bg-white/5 border border-white/10 space-y-3">
                        <div className="flex justify-between items-center text-sm font-medium">
                            <span className="text-neutral-300">Item</span>
                            <span>{item?.name || 'Pro Subscription'}</span>
                        </div>
                        <div className="flex justify-between items-center text-sm font-medium">
                            <span className="text-neutral-300">Total</span>
                            <span className="text-xl font-bold text-white">{item?.price || '$0.00'}</span>
                        </div>
                        <div className="h-px bg-white/10 my-2" />
                        <div className="flex items-center gap-2 text-xs text-neutral-400">
                            <Shield className="w-3 h-3 text-emerald-500" />
                            <span>Encrypted & Secure Transaction</span>
                        </div>
                    </div>

                    {/* Error Message */}
                    {error && (
                        <div className="p-3 rounded bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center gap-2">
                            <Lock className="w-4 h-4" />
                            {error}
                        </div>
                    )}

                    {/* Action Button */}
                    <Button 
                        onClick={handlePurchase} 
                        disabled={loading}
                        className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold h-12"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Processing...
                            </>
                        ) : (
                            <>
                                Pay with Card
                            </>
                        )}
                    </Button>

                    <p className="text-center text-xs text-neutral-500">
                        You will be redirected to Stripe to complete your purchase securely.
                    </p>
                </div>
            </DialogContent>
        </Dialog>
    );
}