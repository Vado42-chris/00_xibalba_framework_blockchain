import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Package, User, Calendar, CreditCard } from 'lucide-react';

export default function OrderDetails({ order, open, onOpenChange }) {
  if (!order) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[hsl(var(--layer-orientation))] border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-intent))] sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex justify-between items-center">
            <span>Order #{order.id?.slice(0, 8) || 'Unknown'}</span>
            <Badge variant="outline" className="capitalize text-[hsl(var(--fg-orientation))] border-[hsl(var(--fg-orientation))]">{order.status}</Badge>
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-6 py-4">
          <div className="grid grid-cols-2 gap-4">
             <div className="space-y-1">
                <div className="text-xs text-[hsl(var(--fg-orientation))] uppercase flex items-center gap-1"><User className="w-3 h-3" /> Customer</div>
                <div className="font-bold text-[hsl(var(--fg-intent))]">{order.customer_name}</div>
             </div>
             <div className="space-y-1">
                <div className="text-xs text-[hsl(var(--fg-orientation))] uppercase flex items-center gap-1"><Calendar className="w-3 h-3" /> Date</div>
                <div className="font-mono text-sm text-[hsl(var(--fg-intent))]">{order.order_date ? new Date(order.order_date).toLocaleDateString() : 'Just now'}</div>
             </div>
          </div>

          <div className="border rounded-lg border-[hsl(var(--layer-orientation))] overflow-hidden">
             <div className="bg-[hsl(var(--layer-state))] px-4 py-2 text-xs font-bold text-[hsl(var(--fg-orientation))] uppercase">Items</div>
             <div className="divide-y divide-[hsl(var(--layer-orientation))]">
                {order.items?.map((item, i) => (
                   <div key={i} className="px-4 py-3 flex justify-between items-center bg-[hsl(var(--void))]">
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 rounded bg-[hsl(var(--layer-orientation))] flex items-center justify-center">
                            <Package className="w-4 h-4 text-[hsl(var(--fg-orientation))]" />
                         </div>
                         <span className="text-sm text-[hsl(var(--fg-intent))]">{item.name}</span>
                      </div>
                      <span className="font-mono text-sm text-[hsl(var(--fg-intent))]">${item.price?.toLocaleString()}</span>
                   </div>
                ))}
             </div>
             <div className="bg-[hsl(var(--layer-state))] px-4 py-3 flex justify-between items-center border-t border-[hsl(var(--layer-orientation))]">
                <span className="text-sm font-bold text-[hsl(var(--fg-orientation))]">Total</span>
                <span className="text-lg font-bold text-[hsl(var(--color-execution))]">${order.total?.toLocaleString()}</span>
             </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
           <Button variant="outline" onClick={() => onOpenChange(false)} className="border-[hsl(var(--fg-orientation))] text-[hsl(var(--fg-orientation))]">Close</Button>
           <Button className="bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/80 text-black">
              <CreditCard className="w-4 h-4 mr-2" /> Process Payment
           </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}