import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function InventoryModal({ open, onOpenChange, item }) {
    const queryClient = useQueryClient();
    const { register, handleSubmit, reset, setValue } = useForm();

    useEffect(() => {
        if (item) {
            setValue('name', item.name);
            setValue('sku', item.sku);
            setValue('category', item.category);
            setValue('quantity', item.quantity);
            setValue('price', item.price);
            setValue('distro_base', item.distro_base || 'linux-generic');
            setValue('license_type', item.license_type || 'free_open');
        } else {
            reset({ quantity: 1, distro_base: 'linux-generic', license_type: 'free_open' });
        }
    }, [item, open, setValue, reset]);

    const mutation = useMutation({
        mutationFn: (data) => {
            const payload = {
                ...data,
                quantity: parseInt(data.quantity),
                price: parseFloat(data.price)
            };
            if (item) {
                return base44.entities.InventoryItem.update(item.id, payload);
            }
            return base44.entities.InventoryItem.create(payload);
        },
        onSuccess: () => {
            queryClient.invalidateQueries(['inventory']);
            toast.success(item ? "Inventory updated" : "Item added");
            onOpenChange(false);
            reset();
        }
    });

    const onSubmit = (data) => mutation.mutate(data);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border-white/10 text-white sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>{item ? 'Edit SAM Model' : 'New SAM Model'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Model Name</Label>
                            <Input {...register('name', { required: true })} className="bg-neutral-950 border-white/10" placeholder="e.g. Vision-V2" />
                        </div>
                        <div className="space-y-2">
                            <Label>Version Hash / SKU</Label>
                            <Input {...register('sku', { required: true })} className="bg-neutral-950 border-white/10" />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Category</Label>
                            <Select onValueChange={(val) => setValue('category', val)} defaultValue={item?.category || 'automation'}>
                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                    <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="automation">Automation</SelectItem>
                                    <SelectItem value="training">Training</SelectItem>
                                    <SelectItem value="inference">Inference</SelectItem>
                                    <SelectItem value="analytics">Analytics</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Base Distro</Label>
                            <Input {...register('distro_base')} className="bg-neutral-950 border-white/10" placeholder="e.g. Alpine Linux" />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                         <div className="space-y-2">
                            <Label>License Type</Label>
                            <Select onValueChange={(val) => setValue('license_type', val)} defaultValue={item?.license_type || 'free_open'}>
                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="free_open">Free / Open Source</SelectItem>
                                    <SelectItem value="commercial_support">Commercial Support</SelectItem>
                                    <SelectItem value="white_label">White Label</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Monthly Service Cost ($)</Label>
                            <Input type="number" step="0.01" {...register('price', { required: true })} className="bg-neutral-950 border-white/10" />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <Label>Available Instances (Capacity)</Label>
                        <Input type="number" {...register('quantity', { required: true })} className="bg-neutral-950 border-white/10" />
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button type="submit" className="bg-[hsl(var(--color-active))] text-black">{item ? 'Update Model' : 'Register Model'}</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}