import React, { useState } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Crown, Zap } from "lucide-react";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";

export const UpgradeModal = ({ open, onOpenChange }) => {
    const [loading, setLoading] = useState(false);

    const handleSubscribe = async () => {
        setLoading(true);
        try {
            const res = await base44.functions.invoke('stripe', { 
                action: 'create_checkout',
                returnUrl: window.location.href 
            });
            
            if (res.data?.url) {
                window.location.href = res.data.url;
            } else {
                throw new Error("No checkout URL returned");
            }
        } catch (e) {
            toast.error("Subscription Error", { description: "Could not initialize checkout." });
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-3xl bg-[#0a0a0a] border-white/10 text-white p-0 overflow-hidden flex flex-col md:flex-row h-[500px]">
                
                {/* Left: DIY */}
                <div className="flex-1 p-8 border-r border-white/10 flex flex-col relative">
                    <div className="flex items-center gap-2 mb-4">
                        <Zap className="w-5 h-5 text-neutral-400" />
                        <h3 className="font-bold tracking-widest text-neutral-400">THE FORGE</h3>
                    </div>
                    <h2 className="text-2xl font-light mb-6">Build It Yourself</h2>
                    <ul className="space-y-4 flex-1">
                        <li className="flex gap-3 text-sm text-neutral-300">
                            <CheckCircle2 className="w-4 h-4 text-neutral-500 shrink-0" />
                            <span>Access to all standard connectors</span>
                        </li>
                        <li className="flex gap-3 text-sm text-neutral-300">
                            <CheckCircle2 className="w-4 h-4 text-neutral-500 shrink-0" />
                            <span>Visual Workflow Builder</span>
                        </li>
                        <li className="flex gap-3 text-sm text-neutral-300">
                            <CheckCircle2 className="w-4 h-4 text-neutral-500 shrink-0" />
                            <span>Community Support</span>
                        </li>
                    </ul>
                    <div className="mt-auto">
                        <Button variant="outline" className="w-full border-white/10" onClick={() => onOpenChange(false)}>
                            Continue Free
                        </Button>
                    </div>
                </div>

                {/* Right: Concierge */}
                <div className="flex-1 p-8 bg-[hsl(var(--color-intent))]/5 flex flex-col relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-[hsl(var(--color-intent))]/20 blur-[60px] rounded-full pointer-events-none" />
                    
                    <div className="flex items-center gap-2 mb-4 relative z-10">
                        <Crown className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                        <h3 className="font-bold tracking-widest text-[hsl(var(--color-intent))]">CONCIERGE</h3>
                    </div>
                    <h2 className="text-2xl font-light mb-2 relative z-10">Let The Gods Handle It</h2>
                    <p className="text-xs text-[hsl(var(--color-intent))] mb-6 relative z-10">
                        Starting at $299/mo
                    </p>

                    <ul className="space-y-4 flex-1 relative z-10">
                        <li className="flex gap-3 text-sm text-white">
                            <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-intent))] shrink-0" />
                            <span>We build & manage your workflows</span>
                        </li>
                        <li className="flex gap-3 text-sm text-white">
                            <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-intent))] shrink-0" />
                            <span>24/7 Monitoring & Optimization</span>
                        </li>
                        <li className="flex gap-3 text-sm text-white">
                            <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-intent))] shrink-0" />
                            <span>Priority "Red Phone" Support</span>
                        </li>
                        <li className="flex gap-3 text-sm text-white">
                            <CheckCircle2 className="w-4 h-4 text-[hsl(var(--color-intent))] shrink-0" />
                            <span>Monthly ROI Reports</span>
                        </li>
                    </ul>

                    <div className="mt-auto relative z-10">
                        <Button 
                            className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold"
                            onClick={handleSubscribe}
                            disabled={loading}
                        >
                            {loading ? "Processing..." : "Upgrade to Concierge"}
                        </Button>
                        <p className="text-[10px] text-center mt-3 text-neutral-500">
                            7-day money-back guarantee. Cancel anytime.
                        </p>
                    </div>
                </div>

            </DialogContent>
        </Dialog>
    );
};