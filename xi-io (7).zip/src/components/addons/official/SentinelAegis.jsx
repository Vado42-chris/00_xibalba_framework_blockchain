import React, { useState } from 'react';
import { Shield, Lock, Globe, Server, Activity, Radio, FileText, AlertTriangle } from 'lucide-react';
import { StateText, IntentText, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import TunnelTopology from '@/components/network/TunnelTopology';
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";

export default function SentinelAegis({ nodes, active }) {
    const [isGenerating, setIsGenerating] = useState(false);

    const handleGenerateReport = async () => {
        setIsGenerating(true);
        try {
            const reportContent = `
# SENTINEL AEGIS - THREAT ANALYSIS REPORT
DATE: ${new Date().toISOString()}
STATUS: SECURE
ENCRYPTION: AES-256-GCM

## ACTIVE NODE STATUS
${nodes.map(n => `- ${n.name}: ${n.status.toUpperCase()} (${n.ip_address})`).join('\n')}

## RECENT MITIGATIONS
- Blocked 142 port scan attempts from known bad actors.
- Rerouted traffic via [Node-04] due to latency spike.
- Identity obfuscation active.

## RECOMMENDATION
Maintain current posture. No immediate action required.
            `;

            await base44.entities.FileRecord.create({
                name: `Threat_Report_${Date.now()}.md`,
                path: '/Logs',
                mime_type: 'text/markdown',
                size: reportContent.length,
                url: '#', // In a real app, we'd upload this file content to storage
                category: 'document',
                is_private: true
            });

            toast.success("Artifact Generated: Threat Report archived to /Logs");
        } catch (error) {
            console.error(error);
            toast.error("Failed to generate report");
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="h-full flex flex-col relative overflow-hidden">
            {/* Aegis HUD */}
            <div className="absolute top-4 left-4 z-20 flex flex-col gap-2">
                <div className="flex items-center gap-2">
                    <Shield className="w-5 h-5 text-[hsl(var(--color-execution))]" />
                    <IntentText className="font-bold tracking-widest text-[hsl(var(--color-execution))]">SENTINEL AEGIS</IntentText>
                </div>
                <div className="flex gap-2">
                    <Badge variant="outline" className="bg-black/50 border-[hsl(var(--color-execution))]/30 text-[hsl(var(--color-execution))] text-[9px] backdrop-blur-md">
                        FIREWALL: ACTIVE
                    </Badge>
                    <Badge variant="outline" className="bg-black/50 border-blue-500/30 text-blue-400 text-[9px] backdrop-blur-md">
                        VPN: ENCRYPTED
                    </Badge>
                </div>
            </div>

            {/* Topology Viz */}
            <div className="flex-1 relative">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-[hsl(var(--color-execution))]/5 via-black/0 to-black/0 pointer-events-none" />
                <TunnelTopology nodes={nodes} active={true} />
            </div>

            {/* Controls */}
            <div className="absolute bottom-4 right-4 z-20 flex flex-col gap-2 w-48">
                <div className="p-3 bg-black/80 border border-[hsl(var(--color-execution))]/30 rounded-lg backdrop-blur-md">
                    <div className="flex justify-between items-center mb-2">
                        <StateText className="text-[hsl(var(--color-execution))]">THREAT LEVEL</StateText>
                        <span className="text-xs font-mono text-white">LOW</span>
                    </div>
                    <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-[hsl(var(--color-execution))]" style={{ width: '12%' }} />
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                    <Button 
                        onClick={() => toast.success("IP Address Rotated")}
                        className="w-full bg-[hsl(var(--color-execution))] text-black font-bold text-[10px] h-8 hover:bg-[hsl(var(--color-execution))]/90"
                    >
                        <Radio className="w-3 h-3 mr-1" />
                        ROTATE
                    </Button>
                    <Button 
                        onClick={handleGenerateReport}
                        disabled={isGenerating}
                        variant="outline"
                        className="w-full border-white/10 text-white font-bold text-[10px] h-8 bg-black/50 hover:bg-white/10"
                    >
                        {isGenerating ? <Activity className="w-3 h-3 animate-spin" /> : <FileText className="w-3 h-3 mr-1" />}
                        LOGS
                    </Button>
                </div>
            </div>
        </div>
    );
}