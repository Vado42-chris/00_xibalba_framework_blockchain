import React, { useState } from 'react';
import { 
    MessageSquare, Hash, AtSign, Search, 
    Bell, MoreVertical, Paperclip, Smile,
    Users, Radio, Command
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
// import { Badge } from "@/components/ui/badge";
import { StateText, IntentText, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { cn } from "@/components/ui/utils";
import UnifiedInbox from '@/components/communications/UnifiedInbox';

/**
 * NexusWidget
 * 
 * The specialized interface for the Nexus Comms addon.
 * Enhances the UnifiedInbox with a "Command Center" wrapper,
 * real-time channel monitoring, and quick-action shortcuts.
 */
export default function NexusWidget({ messages, onReply, onDraft, onArchive, onDelete }) {
    const [channelFilter, setChannelFilter] = useState('all');

    return (
        <div className="h-full flex flex-col bg-black/40 relative overflow-hidden rounded-lg border border-white/5">
            {/* Nexus HUD Header */}
            <div className="h-14 border-b border-white/5 bg-neutral-900/50 flex items-center justify-between px-4 shrink-0 z-20 backdrop-blur-md">
                <div className="flex items-center gap-3">
                    <div className="p-1.5 rounded bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/20">
                        <Radio className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    </div>
                    <div>
                        <IntentText className="font-bold tracking-wide">NEXUS UPLINK</IntentText>
                        <div className="flex items-center gap-2">
                            <StateText className="text-[10px] text-[hsl(var(--color-execution))]">LIVE STREAM</StateText>
                            <span className="w-1 h-1 rounded-full bg-[hsl(var(--color-execution))] animate-pulse" />
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <div className="hidden md:flex items-center gap-1 px-2 py-1 rounded bg-white/5 border border-white/5">
                        <Command className="w-3 h-3 text-neutral-500" />
                        <span className="text-[10px] text-neutral-500 font-mono">CMD+K</span>
                    </div>
                    <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-white/10">
                        <Bell className="w-4 h-4 text-neutral-400" />
                    </Button>
                </div>
            </div>

            {/* Channel Rail */}
            <div className="flex-1 flex overflow-hidden">
                <div className="w-12 border-r border-white/5 bg-neutral-900/30 flex flex-col items-center py-4 gap-4 shrink-0 z-10">
                    {[
                        { id: 'all', icon: MessageSquare, color: 'text-white' },
                        { id: 'slack', icon: Hash, color: 'text-[#ECB22E]' },
                        { id: 'discord', icon: Users, color: 'text-[#5865F2]' },
                        { id: 'mention', icon: AtSign, color: 'text-[hsl(var(--color-warning))]' },
                    ].map(chan => (
                        <button
                            key={chan.id}
                            onClick={() => setChannelFilter(chan.id)}
                            className={cn(
                                "w-8 h-8 rounded-lg flex items-center justify-center transition-all relative group",
                                channelFilter === chan.id ? "bg-white/10 shadow-lg" : "hover:bg-white/5"
                            )}
                        >
                            <chan.icon className={cn("w-4 h-4 transition-colors", chan.color)} />
                            {channelFilter === chan.id && (
                                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-[hsl(var(--color-execution))]" />
                            )}
                            {/* Tooltip */}
                            <div className="absolute left-10 px-2 py-1 bg-neutral-900 border border-white/10 rounded text-[9px] text-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-50">
                                {chan.id.toUpperCase()}
                            </div>
                        </button>
                    ))}
                </div>

                {/* Main Content Area */}
                <div className="flex-1 min-w-0 bg-neutral-950/30 relative">
                     {/* Overlay Grid Effect */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />
                    
                    <UnifiedInbox 
                        messages={messages.filter(m => channelFilter === 'all' || m.source.toLowerCase().includes(channelFilter) || (channelFilter === 'mention' && m.type === 'MENTION'))} 
                        onReply={onReply} 
                        onDraft={onDraft}
                        onArchive={onArchive}
                        onDelete={onDelete}
                        className="bg-transparent"
                    />
                </div>
            </div>
        </div>
    );
}