import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Brain, Zap, Activity, GitBranch } from 'lucide-react';
import { StateText, IntentText, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-black/90 border border-white/10 p-2 rounded text-xs font-mono shadow-xl">
                <div className="text-neutral-400 mb-1">{label}</div>
                <div className="text-[hsl(var(--color-intent))]">Load: {payload[0].value}%</div>
                <div className="text-purple-400">Memory: {payload[1].value}MB</div>
            </div>
        );
    }
    return null;
};

/**
 * NeuroLinkViz
 * 
 * High-fidelity visualization for the Neuro-Link Analytics addon.
 * Provides real-time cognitive load metrics and predictive caching stats.
 */
export default function NeuroLinkViz() {
    const [data, setData] = useState([]);

    useEffect(() => {
        // Initialize data
        const initialData = Array.from({ length: 20 }, (_, i) => ({
            time: `T-${20-i}s`,
            load: 30 + Math.random() * 20,
            memory: 120 + Math.random() * 50
        }));
        setData(initialData);

        // Real-time update simulation
        const interval = setInterval(() => {
            setData(prev => {
                const last = prev[prev.length - 1];
                const newPoint = {
                    time: 'Now',
                    load: Math.max(10, Math.min(95, last.load + (Math.random() - 0.5) * 20)),
                    memory: Math.max(100, Math.min(300, last.memory + (Math.random() - 0.5) * 40))
                };
                return [...prev.slice(1), newPoint];
            });
        }, 1000);

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="h-full flex flex-col space-y-4 p-1">
            {/* Header / HUD */}
            <div className="flex justify-between items-start mb-2">
                <div>
                    <OrientingText className="text-purple-400 mb-1">NEURAL INTERFACE</OrientingText>
                    <IntentText className="text-lg">Cognitive Telemetry</IntentText>
                </div>
                <div className="flex gap-2">
                    <Badge variant="outline" className="border-purple-500/30 text-purple-400 bg-purple-500/10 text-[9px] gap-1">
                        <Brain className="w-3 h-3" />
                        CONNECTED
                    </Badge>
                    <Badge variant="outline" className="border-blue-500/30 text-blue-400 bg-blue-500/10 text-[9px] gap-1">
                        <Zap className="w-3 h-3" />
                        PREDICTIVE
                    </Badge>
                </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-3 gap-3 mb-4">
                <Card className="bg-neutral-900/40 border-white/5 p-3 flex flex-col justify-between">
                    <div className="text-[10px] text-neutral-500 mb-1 flex items-center gap-1">
                        <Activity className="w-3 h-3" /> CURRENT LOAD
                    </div>
                    <div className="text-2xl font-light text-white">
                        {Math.round(data[data.length - 1]?.load || 0)}%
                    </div>
                </Card>
                <Card className="bg-neutral-900/40 border-white/5 p-3 flex flex-col justify-between">
                    <div className="text-[10px] text-neutral-500 mb-1 flex items-center gap-1">
                        <GitBranch className="w-3 h-3" /> CONTEXT WINDOW
                    </div>
                    <div className="text-2xl font-light text-white">
                        8.4k
                    </div>
                </Card>
                <Card className="bg-neutral-900/40 border-white/5 p-3 flex flex-col justify-between">
                    <div className="text-[10px] text-neutral-500 mb-1 flex items-center gap-1">
                        <Zap className="w-3 h-3" /> CACHE HITS
                    </div>
                    <div className="text-2xl font-light text-green-400">
                        94%
                    </div>
                </Card>
            </div>

            {/* Main Viz */}
            <div className="flex-1 bg-black/20 rounded-lg border border-white/5 p-2 relative overflow-hidden min-h-[200px]">
                <div className="absolute top-2 right-2 z-10 text-[9px] font-mono text-neutral-600">
                    REALTIME_STREAM_V2
                </div>
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data}>
                        <defs>
                            <linearGradient id="colorLoad" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="hsl(var(--color-intent))" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="hsl(var(--color-intent))" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorMem" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                        <XAxis dataKey="time" hide />
                        <YAxis hide domain={[0, 100]} />
                        <Tooltip content={<CustomTooltip />} />
                        <Area 
                            type="monotone" 
                            dataKey="load" 
                            stroke="hsl(var(--color-intent))" 
                            strokeWidth={2}
                            fillOpacity={1} 
                            fill="url(#colorLoad)" 
                            isAnimationActive={false}
                        />
                        <Area 
                            type="monotone" 
                            dataKey="memory" 
                            stroke="#a855f7" 
                            strokeWidth={2}
                            fillOpacity={1} 
                            fill="url(#colorMem)" 
                            isAnimationActive={false}
                        />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
            
            <div className="text-[10px] text-neutral-600 font-mono text-center">
                CORTEX SYSTEMS • NEURO-LINK ENGINE ACTIVE
            </div>
        </div>
    );
}