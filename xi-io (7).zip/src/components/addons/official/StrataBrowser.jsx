import React, { useState, useEffect } from 'react';
import { 
    FileText, Search, Database, ChevronRight, 
    ExternalLink, BookOpen, Clock, Tag 
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StateText, IntentText, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

/**
 * StrataBrowser
 * 
 * Integration interface for Strata Knowledge (Notion).
 * Displays external knowledge base content as if it were local.
 */
export default function StrataBrowser({ className }) {
    const [pages, setPages] = useState([]);
    const [query, setQuery] = useState('');

    useEffect(() => {
        // Mock Notion Data
        setPages([
            { id: 1, title: "Company Handbook", icon: "📘", updated: "2h ago", tags: ["Reference", "HR"] },
            { id: 2, title: "Q3 Engineering Goals", icon: "🎯", updated: "1d ago", tags: ["Engineering", "Strategy"] },
            { id: 3, title: "Brand Assets Guidelines", icon: "🎨", updated: "3d ago", tags: ["Design"] },
            { id: 4, title: "Deployment Protocols", icon: "🚀", updated: "5d ago", tags: ["DevOps", "Critical"] },
            { id: 5, title: "Meeting Notes: Sprint 42", icon: "📝", updated: "1w ago", tags: ["Meetings"] },
        ]);
    }, []);

    const filteredPages = pages.filter(p => p.title.toLowerCase().includes(query.toLowerCase()));

    return (
        <div className={cn("h-full flex flex-col", className)}>
            {/* Strata Header */}
            <div className="bg-neutral-900/50 border-b border-white/5 p-4">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                        <div className="p-1.5 rounded bg-neutral-800 border border-white/10">
                            <Database className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                        </div>
                        <div>
                            <IntentText className="text-sm font-bold">Strata Knowledge</IntentText>
                            <StateText className="text-[10px] opacity-60">Connected to Notion Workspace</StateText>
                        </div>
                    </div>
                    <Button size="sm" variant="outline" className="h-7 text-xs border-white/10">
                        <ExternalLink className="w-3 h-3 mr-2" /> Open Notion
                    </Button>
                </div>
                
                <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
                    <Input 
                        placeholder="Search external knowledge base..." 
                        className="pl-9 h-9 bg-black/20 border-white/10 text-xs"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />
                </div>
            </div>

            {/* Page List */}
            <div className="flex-1 overflow-y-auto p-2">
                <OrientingText className="px-2 mb-2 mt-2">RECENTLY SYNCED</OrientingText>
                <div className="space-y-1">
                    {filteredPages.map(page => (
                        <div 
                            key={page.id}
                            className="group flex items-center justify-between p-2 rounded-lg hover:bg-white/5 transition-colors cursor-pointer border border-transparent hover:border-white/5"
                        >
                            <div className="flex items-center gap-3">
                                <span className="text-lg">{page.icon}</span>
                                <div>
                                    <div className="text-sm text-neutral-200 group-hover:text-[hsl(var(--color-execution))] transition-colors">
                                        {page.title}
                                    </div>
                                    <div className="flex items-center gap-2 text-[10px] text-neutral-500">
                                        <Clock className="w-3 h-3" /> {page.updated}
                                        <span>•</span>
                                        {page.tags.map(tag => (
                                            <span key={tag} className="text-neutral-400">#{tag}</span>
                                        ))}
                                    </div>
                                </div>
                            </div>
                            <ChevronRight className="w-4 h-4 text-neutral-600 group-hover:text-white" />
                        </div>
                    ))}
                </div>
            </div>
            
            <div className="p-2 border-t border-white/5 bg-black/20 text-center">
                <StateText className="text-[10px] opacity-40">
                    Index updated 5m ago • {pages.length} Pages Synced
                </StateText>
            </div>
        </div>
    );
}