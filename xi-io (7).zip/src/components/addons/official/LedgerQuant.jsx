import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Wallet, ArrowUpRight, Activity, DollarSign, Lock } from 'lucide-react';
import { StateText, IntentText, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-black/90 border border-white/10 p-2 rounded text-xs font-mono shadow-xl">
                <div className="text-neutral-400 mb-1">{label}</div>
                <div className="text-[hsl(var(--color-execution))]">${payload[0].value.toLocaleString()}</div>
            </div>
        );
    }
    return null;
};

export default function LedgerQuant({ selectedAsset }) {
    // Simulated advanced data
    const data = [
        { name: 'Mon', value: 4000 },
        { name: 'Tue', value: 3000 },
        { name: 'Wed', value: 5000 },
        { name: 'Thu', value: 2780 },
        { name: 'Fri', value: 1890 },
        { name: 'Sat', value: 2390 },
        { name: 'Sun', value: 3490 },
    ];

    if (!selectedAsset) {
        return (
            <div className="h-full flex flex-col items-center justify-center p-8 opacity-50">
                <Wallet className="w-12 h-12 text-neutral-600 mb-4" />
                <StateText>Select an asset to analyze liquidity depth and volatility.</StateText>
            </div>
        );
    }

    return (
        <div className="h-full flex flex-col space-y-4">
            {/* Header */}
            <div className="flex justify-between items-start">
                <div>
                    <OrientingText className="text-[hsl(var(--color-execution))] mb-1">QUANT ENGINE</OrientingText>
                    <IntentText className="text-lg">{selectedAsset.name} Analysis</IntentText>
                </div>
                <Badge variant="outline" className="border-[hsl(var(--color-execution))]/30 text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10 text-[9px] gap-1">
                    <Activity className="w-3 h-3" />
                    LIVE FEED
                </Badge>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-3">
                <Card className="bg-neutral-900/40 border-white/5 p-3">
                    <div className="text-[10px] text-neutral-500 mb-1">VOLATILITY (24H)</div>
                    <div className="text-xl font-light text-white flex items-center gap-2">
                        4.2% <TrendingUp className="w-3 h-3 text-[hsl(var(--color-warning))]" />
                    </div>
                </Card>
                <Card className="bg-neutral-900/40 border-white/5 p-3">
                    <div className="text-[10px] text-neutral-500 mb-1">LIQUIDITY DEPTH</div>
                    <div className="text-xl font-light text-white">High</div>
                </Card>
                <Card className="bg-neutral-900/40 border-white/5 p-3">
                    <div className="text-[10px] text-neutral-500 mb-1">PROJECTED APY</div>
                    <div className="text-xl font-light text-[hsl(var(--color-execution))]">12.5%</div>
                </Card>
            </div>

            {/* Chart */}
            <div className="flex-1 bg-black/20 rounded-lg border border-white/5 p-2 relative overflow-hidden min-h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data}>
                        <defs>
                            <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="hsl(var(--color-execution))" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="hsl(var(--color-execution))" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                        <XAxis dataKey="name" hide />
                        <YAxis hide />
                        <Tooltip content={<CustomTooltip />} />
                        <Area 
                            type="monotone" 
                            dataKey="value" 
                            stroke="hsl(var(--color-execution))" 
                            strokeWidth={2}
                            fillOpacity={1} 
                            fill="url(#colorValue)" 
                        />
                    </AreaChart>
                </ResponsiveContainer>
            </div>

            <div className="flex gap-2">
                <Button className="flex-1 bg-[hsl(var(--color-execution))] text-black h-8 text-xs font-bold hover:bg-[hsl(var(--color-execution))]/90">
                    <DollarSign className="w-3 h-3 mr-2" /> BUY
                </Button>
                <Button variant="outline" className="flex-1 border-white/10 text-white h-8 text-xs font-bold">
                    <ArrowUpRight className="w-3 h-3 mr-2" /> SELL
                </Button>
            </div>
        </div>
    );
}