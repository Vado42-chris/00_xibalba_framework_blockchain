import React, { useState } from 'react';
import { 
    Search, Globe, BookOpen, Bookmark, 
    ArrowLeft, ArrowRight, RefreshCw, X,
    Maximize2, ExternalLink, History
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot 
} from '@/components/ui/design-system/System';

const MOCK_RESULTS = [
    { title: "Advanced Neural Interfaces", url: "scholar.xi-io.com/neural-interfaces", snippet: "Recent breakthroughs in direct-to-cortex telemetry...", source: "XI Scholar" },
    { title: "Quantum Entanglement in Data", url: "arxiv.org/quantum-data", snippet: "Using entanglement for instant state synchronization across nodes...", source: "ArXiv" },
    { title: "The Ethics of AI Autonomy", url: "wired.com/ai-ethics", snippet: "When agents begin to trade on their own behalf...", source: "Wired" },
    { title: "React Performance Patterns", url: "react.dev/optimization", snippet: "Optimizing render cycles in high-frequency dashboards...", source: "React Docs" },
];

export default function ResearchDeck() {
    const [url, setUrl] = useState('xi://scholar');
    const [isLoading, setIsLoading] = useState(false);
    const [history, setHistory] = useState(['xi://scholar']);
    const [bookmarks, setBookmarks] = useState([]);
    
    const handleNavigate = (e) => {
        e.preventDefault();
        setIsLoading(true);
        // Simulate loading
        setTimeout(() => {
            setIsLoading(false);
            if (!history.includes(url)) setHistory([...history, url]);
        }, 1500);
    };

    return (
        <div className="flex flex-col h-full bg-black/40 border border-white/10 rounded-lg overflow-hidden backdrop-blur-xl">
            {/* Browser Chrome */}
            <div className="h-12 bg-neutral-900/80 border-b border-white/5 flex items-center px-3 gap-3">
                <div className="flex items-center gap-1">
                    <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50" />
                    <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50" />
                </div>
                
                <div className="flex items-center gap-1 text-neutral-500">
                    <Button variant="ghost" size="icon" className="w-6 h-6 hover:text-white"><ArrowLeft className="w-3 h-3" /></Button>
                    <Button variant="ghost" size="icon" className="w-6 h-6 hover:text-white"><ArrowRight className="w-3 h-3" /></Button>
                    <Button variant="ghost" size="icon" className="w-6 h-6 hover:text-white"><RefreshCw className={cn("w-3 h-3", isLoading && "animate-spin")} /></Button>
                </div>

                <form onSubmit={handleNavigate} className="flex-1 flex items-center">
                    <div className="relative w-full">
                        <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-neutral-500" />
                        <input 
                            value={url}
                            onChange={(e) => setUrl(e.target.value)}
                            className="w-full bg-black/50 border border-white/10 rounded-full h-8 pl-9 pr-4 text-xs text-neutral-300 focus:outline-none focus:border-[hsl(var(--color-intent))] transition-colors font-mono"
                        />
                    </div>
                </form>

                <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="w-6 h-6 hover:text-[hsl(var(--color-warning))]">
                        <Bookmark className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="w-6 h-6 hover:text-white">
                        <Maximize2 className="w-3 h-3" />
                    </Button>
                </div>
            </div>

            {/* Browser Content Area */}
            <div className="flex-1 flex overflow-hidden relative">
                {isLoading && (
                    <div className="absolute inset-0 z-20 bg-black/50 backdrop-blur-sm flex items-center justify-center">
                        <div className="flex flex-col items-center gap-4">
                            <div className="w-12 h-12 rounded-full border-2 border-[hsl(var(--color-execution))] border-t-transparent animate-spin" />
                            <StateText className="animate-pulse">RESOLVING_HOST...</StateText>
                        </div>
                    </div>
                )}
                
                {/* Sidebar */}
                <div className="w-64 border-r border-white/5 bg-neutral-900/30 flex flex-col">
                    <div className="p-3 border-b border-white/5">
                        <OrientingText className="text-[10px] uppercase tracking-widest opacity-50">Active Session</OrientingText>
                    </div>
                    <ScrollArea className="flex-1 p-2">
                        <div className="space-y-4">
                            <div>
                                <div className="px-2 mb-2 flex items-center gap-2 text-neutral-500">
                                    <History className="w-3 h-3" />
                                    <span className="text-[10px] font-bold">RECENT</span>
                                </div>
                                {history.map((h, i) => (
                                    <div key={i} className="px-2 py-1.5 rounded hover:bg-white/5 cursor-pointer truncate text-[10px] text-neutral-400 font-mono">
                                        {h}
                                    </div>
                                ))}
                            </div>
                        </div>
                    </ScrollArea>
                </div>

                {/* Main Viewport */}
                <div className="flex-1 bg-neutral-950 p-8 overflow-y-auto">
                    <div className="max-w-3xl mx-auto space-y-8">
                        <div className="text-center space-y-4">
                            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))] border border-[hsl(var(--color-intent))]/20 mb-4">
                                <BookOpen className="w-8 h-8" />
                            </div>
                            <h1 className="text-3xl font-light text-white">XI Scholar</h1>
                            <p className="text-neutral-500 max-w-md mx-auto">
                                Access the decentralized academic index. Peer-reviewed knowledge, verified by the chain.
                            </p>
                        </div>

                        <div className="space-y-4">
                            {MOCK_RESULTS.map((res, i) => (
                                <div key={i} className="group p-4 rounded-lg border border-white/5 hover:border-[hsl(var(--color-execution))] hover:bg-white/5 transition-all cursor-pointer">
                                    <div className="flex items-start justify-between mb-2">
                                        <div className="space-y-1">
                                            <div className="text-[10px] text-[hsl(var(--color-execution))] font-mono uppercase">{res.source}</div>
                                            <h3 className="text-lg text-white group-hover:underline decoration-[hsl(var(--color-execution))] underline-offset-4">{res.title}</h3>
                                        </div>
                                        <ExternalLink className="w-4 h-4 text-neutral-600 group-hover:text-white" />
                                    </div>
                                    <p className="text-sm text-neutral-400">{res.snippet}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            
            {/* Status Bar */}
            <div className="h-6 bg-neutral-900 border-t border-white/5 flex items-center justify-between px-3 text-[10px] text-neutral-500 font-mono">
                <div className="flex items-center gap-4">
                    <span>TLS 1.3 SECURE</span>
                    <span>XI-NET: CONNECTED</span>
                </div>
                <div>
                    RENDER_TIME: 12ms
                </div>
            </div>
        </div>
    );
}