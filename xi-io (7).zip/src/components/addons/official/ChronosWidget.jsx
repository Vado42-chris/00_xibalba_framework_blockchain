import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, Video, MoreHorizontal, RefreshCw } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';
import { cn } from "@/lib/utils";

/**
 * ChronosWidget
 * 
 * The visual interface for the Chronos Timekeeper addon.
 * Simulates a bi-directional sync with Google Calendar.
 */
export default function ChronosWidget({ className }) {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Simulate fetching from Google Calendar API
        const fetchCalendar = async () => {
            setLoading(true);
            await new Promise(r => setTimeout(r, 1500)); // Network delay
            setEvents([
                { 
                    id: 1, 
                    title: "Deep Work: Core Systems", 
                    time: "09:00 - 11:30", 
                    location: "WorkRoom", 
                    type: "focus",
                    status: "current"
                },
                { 
                    id: 2, 
                    title: "Product Sync w/ Cortex", 
                    time: "13:00 - 14:00", 
                    location: "Zoom", 
                    type: "meeting",
                    status: "upcoming"
                },
                { 
                    id: 3, 
                    title: "Q4 Roadmap Review", 
                    time: "15:30 - 16:30", 
                    location: "Conference Hall A", 
                    type: "meeting",
                    status: "upcoming"
                },
                { 
                    id: 4, 
                    title: "System Maintenance", 
                    time: "23:00 - 23:30", 
                    location: "Server Cluster", 
                    type: "task",
                    status: "upcoming"
                }
            ]);
            setLoading(false);
        };
        
        fetchCalendar();
    }, []);

    if (loading) {
        return (
            <div className="h-full flex flex-col items-center justify-center space-y-3 opacity-50">
                <RefreshCw className="w-6 h-6 animate-spin text-[hsl(var(--color-execution))]" />
                <StateText className="text-xs">SYNCING G-CALENDAR...</StateText>
            </div>
        );
    }

    return (
        <div className={cn("h-full flex flex-col", className)}>
            <div className="flex items-center justify-between mb-4 px-1">
                <StateText className="text-xs opacity-50">TODAY'S AGENDA</StateText>
                <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 text-[10px] text-green-400">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                        LIVE SYNC
                    </div>
                </div>
            </div>

            <div className="space-y-3 flex-1 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/10">
                {events.map((event, i) => (
                    <div 
                        key={event.id}
                        className={cn(
                            "relative p-3 rounded-lg border transition-all hover:scale-[1.01] group",
                            event.status === 'current' 
                                ? "bg-[hsl(var(--color-intent))]/10 border-[hsl(var(--color-intent))]/30" 
                                : "bg-neutral-900/40 border-white/5 hover:border-white/10"
                        )}
                    >
                        {event.status === 'current' && (
                            <div className="absolute left-0 top-0 bottom-0 w-1 bg-[hsl(var(--color-intent))]" />
                        )}
                        
                        <div className="flex justify-between items-start mb-1">
                            <IntentText className={cn("font-medium", event.status === 'current' ? "text-white" : "text-neutral-300")}>
                                {event.title}
                            </IntentText>
                            {event.type === 'meeting' && <Video className="w-3 h-3 text-neutral-500" />}
                        </div>
                        
                        <div className="flex items-center gap-4 text-xs text-neutral-500 font-mono mt-2">
                            <div className="flex items-center gap-1.5">
                                <Clock className="w-3 h-3" />
                                {event.time}
                            </div>
                            <div className="flex items-center gap-1.5">
                                <MapPin className="w-3 h-3" />
                                {event.location}
                            </div>
                        </div>

                        {/* Hover Actions */}
                        <div className="absolute right-2 bottom-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                            <Button size="icon" variant="ghost" className="h-6 w-6 rounded-full hover:bg-white/10">
                                <MoreHorizontal className="w-3 h-3" />
                            </Button>
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="mt-4 pt-3 border-t border-white/5 flex justify-between items-center">
                <Button variant="ghost" size="sm" className="text-[10px] h-6 text-neutral-500 hover:text-white">
                    Open Calendar
                </Button>
                <Button size="sm" className="h-7 text-xs bg-white/5 hover:bg-white/10 text-white border border-white/10">
                    <Calendar className="w-3 h-3 mr-2" />
                    New Event
                </Button>
            </div>
        </div>
    );
}