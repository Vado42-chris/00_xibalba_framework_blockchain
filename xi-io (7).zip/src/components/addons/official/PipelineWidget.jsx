import React, { useState } from 'react';
import { 
    Kanban, Users, DollarSign, Activity, 
    ArrowRight, MoreHorizontal, Calendar, 
    TrendingUp, Filter
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StateText, IntentText, OrientingText } from '@/components/ui/design-system/SystemDesign';
import { cn } from "@/lib/utils";
import CRMManager from '@/components/crm/CRMManager';

/**
 * PipelineWidget
 * 
 * The specialized interface for the Pipeline Hologram (CRM) addon.
 * Wraps the CRMManager with a high-fidelity "Deal Flow" visualization
 * and predictive revenue metrics.
 */
export default function PipelineWidget({ category, className }) {
    const [viewMode, setViewMode] = useState('board'); // 'board' | 'list'
    const [isExporting, setIsExporting] = useState(false);

    const handleExportForecast = async () => {
        setIsExporting(true);
        try {
            // Simulate Report Generation
            const reportContent = `
# PIPELINE FORECAST REPORT
GENERATED: ${new Date().toISOString()}
SOURCE: SALESFORCE SYNC

## REVENUE PROJECTION
- Q3 Target: $2.4M
- Probability Weighted: $1.8M
- Velocity: +12% MoM

## TOP OPPORTUNITIES
1. Acme Corp - Enterprise License - $150k (90%)
2. Cyberdyne - AI Module Pack - $450k (60%)
3. Wayne Ent - Security Suite - $800k (40%)

## RISK ASSESSMENT
Low churn risk. Pipeline coverage ratio is 3.5x.
            `;

            // Create Artifact
            const { base44 } = await import('@/api/base44Client');
            await base44.entities.FileRecord.create({
                name: `Revenue_Forecast_${Date.now()}.md`,
                path: '/Contracts/Forecasts',
                mime_type: 'text/markdown',
                size: reportContent.length,
                url: '#',
                category: 'document',
                is_private: true
            });

            const { toast } = await import('sonner');
            toast.success("Forecast Report generated in /Contracts/Forecasts");
        } catch (e) {
            console.error(e);
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <div className={cn("h-full flex flex-col bg-black/40 relative overflow-hidden rounded-lg border border-white/5", className)}>
             {/* Pipeline Header */}
             <div className="h-14 border-b border-white/5 bg-neutral-900/50 flex items-center justify-between px-4 shrink-0 z-20 backdrop-blur-md">
                <div className="flex items-center gap-3">
                    <div className="p-1.5 rounded bg-blue-500/10 border border-blue-500/20">
                        <TrendingUp className="w-4 h-4 text-blue-400" />
                    </div>
                    <div>
                        <IntentText className="font-bold tracking-wide">PIPELINE HOLOGRAM</IntentText>
                        <div className="flex items-center gap-2">
                            <StateText className="text-[10px] text-blue-400">SYNC: SALESFORCE</StateText>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-3">
                     {/* Mini Metrics */}
                    <div className="hidden md:flex items-center gap-4 mr-4">
                        <div className="text-right">
                            <div className="text-[10px] text-neutral-500">FORECAST</div>
                            <div className="text-xs font-mono font-bold text-white">$2.4M</div>
                        </div>
                        <div className="w-px h-6 bg-white/10" />
                        <div className="text-right">
                            <div className="text-[10px] text-neutral-500">VELOCITY</div>
                            <div className="text-xs font-mono font-bold text-green-400">+12%</div>
                        </div>
                    </div>

                    <div className="flex p-1 bg-white/5 rounded border border-white/5">
                        <Button 
                            size="icon" 
                            variant="ghost" 
                            className={cn("h-6 w-6 rounded-sm", viewMode === 'board' ? "bg-white/10" : "")}
                            onClick={() => setViewMode('board')}
                        >
                            <Kanban className="w-3 h-3" />
                        </Button>
                        <Button 
                            size="icon" 
                            variant="ghost" 
                            className={cn("h-6 w-6 rounded-sm", viewMode === 'list' ? "bg-white/10" : "")}
                            onClick={() => setViewMode('list')}
                        >
                            <Users className="w-3 h-3" />
                        </Button>
                    </div>
                    
                    <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={handleExportForecast}
                        disabled={isExporting}
                        className="h-6 text-[9px] border-white/10 hover:bg-white/5 ml-2"
                    >
                        {isExporting ? 'EXPORTING...' : 'EXPORT FORECAST'}
                    </Button>
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 min-w-0 bg-neutral-950/30 relative overflow-hidden">
                {/* 3D Depth Effect Background */}
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/10 via-black/0 to-black/0 pointer-events-none" />
                
                <CRMManager category={category} className="bg-transparent h-full" />
            </div>
        </div>
    );
}