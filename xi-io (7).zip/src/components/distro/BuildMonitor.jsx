import React, { useState, useEffect, useRef } from 'react';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, CheckCircle2, Download, Terminal } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

export const BuildMonitor = ({ config, onComplete }) => {
    const [logs, setLogs] = useState([]);
    const [progress, setProgress] = useState(0);
    const [completed, setCompleted] = useState(false);
    const scrollRef = useRef(null);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [logs]);

    useEffect(() => {
        const steps = [
            { msg: "Initializing build environment...", duration: 800 },
            { msg: `Pulling base image: ${config.base}`, duration: 1500 },
            { msg: "Verifying kernel signatures...", duration: 1000 },
            { msg: "Mounting virtual filesystem...", duration: 800 },
            { msg: `Installing packages: ${config.packages.slice(0, 3).join(', ')}...`, duration: 2000 },
            { msg: "Configuring systemd units...", duration: 1200 },
            { msg: "Generating initramfs...", duration: 1500 },
            { msg: "Compressing filesystem (squashfs)...", duration: 2500 },
            { msg: "Writing ISO boot sector...", duration: 1000 },
            { msg: "Build successful.", duration: 500 }
        ];

        let currentStep = 0;
        let mounted = true;

        const runBuild = async () => {
            for (const step of steps) {
                if (!mounted) return;
                
                setLogs(prev => [...prev, { time: new Date().toLocaleTimeString(), msg: step.msg }]);
                
                // Animate progress
                const stepProgress = 100 / steps.length;
                setProgress(p => Math.min(p + stepProgress, 100));
                
                await new Promise(r => setTimeout(r, step.duration));
            }
            if (mounted) {
                setCompleted(true);
                if (onComplete) onComplete();
            }
        };

        runBuild();
        return () => { mounted = false; };
    }, []);

    if (completed) {
        return (
            <div className="h-full flex flex-col items-center justify-center space-y-6 animate-in fade-in zoom-in duration-300">
                <div className="w-20 h-20 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center">
                    <CheckCircle2 className="w-10 h-10 text-green-500" />
                </div>
                <div className="text-center space-y-1">
                    <h3 className="text-xl font-light text-white">ISO Ready</h3>
                    <p className="text-sm text-neutral-400 font-mono">{config.name}-v1.0.0-amd64.iso</p>
                </div>
                <Button className="bg-[hsl(var(--color-execution))] text-black font-bold">
                    <Download className="w-4 h-4 mr-2" /> Download Image (1.2GB)
                </Button>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full bg-black font-mono text-xs">
            <div className="p-3 border-b border-white/10 bg-white/5 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Loader2 className="w-3 h-3 animate-spin text-[hsl(var(--color-execution))]" />
                    <span className="text-neutral-300">Compiling {config.name}...</span>
                </div>
                <span className="text-[hsl(var(--color-execution))]">{Math.round(progress)}%</span>
            </div>
            
            <div className="h-0.5 w-full bg-neutral-900">
                <div 
                    className="h-full bg-[hsl(var(--color-execution))] transition-all duration-300 ease-out" 
                    style={{ width: `${progress}%` }}
                />
            </div>

            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                <div className="space-y-1">
                    {logs.map((log, i) => (
                        <div key={i} className="flex gap-2 text-neutral-400">
                            <span className="text-neutral-600 opacity-50 select-none">[{log.time}]</span>
                            <span className="text-neutral-300">{log.msg}</span>
                        </div>
                    ))}
                    <div className="flex gap-2 items-center text-[hsl(var(--color-execution))] animate-pulse mt-2">
                        <span className="select-none text-neutral-600">&gt;</span>
                        <span className="w-2 h-4 bg-[hsl(var(--color-execution))]" />
                    </div>
                </div>
            </ScrollArea>
        </div>
    );
};