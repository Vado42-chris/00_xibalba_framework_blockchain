import React, { useState } from 'react';
import { 
    GitBranch, GitCommit, GitMerge, RotateCcw, 
    Plus, Clock, ChevronRight, Check, Hash 
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { format } from 'date-fns';

export default function VersionControl({ config, onRestore, className }) {
    const [commits, setCommits] = useState([]);
    const [branches, setBranches] = useState(['main']);
    const [activeBranch, setActiveBranch] = useState('main');
    const [message, setMessage] = useState('');

    const handleCommit = () => {
        if (!message) return;
        
        const newCommit = {
            id: Math.random().toString(36).substring(7),
            message,
            timestamp: new Date(),
            branch: activeBranch,
            snapshot: { ...config } // Deep copy would be better in prod
        };

        setCommits([newCommit, ...commits]);
        setMessage('');
    };

    const handleRestore = (snapshot) => {
        onRestore(snapshot);
    };

    return (
        <div className={cn("flex flex-col h-full bg-transparent border-white/5", className)}>
            {/* Header */}
            <div className="p-4 border-b border-white/5 bg-transparent">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2 text-[hsl(var(--color-execution))]">
                        <GitBranch className="w-4 h-4" />
                        <span className="font-mono text-xs font-bold uppercase tracking-wider">
                            {activeBranch}
                        </span>
                    </div>
                    <Badge variant="outline" className="text-[10px] text-neutral-500 border-white/10">
                        {commits.length} COMMITS
                    </Badge>
                </div>

                <div className="flex gap-2">
                    <Input 
                        placeholder="Commit message..." 
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="h-8 text-xs bg-neutral-950 border-white/10"
                    />
                    <Button 
                        size="sm" 
                        onClick={handleCommit}
                        disabled={!message}
                        className="h-8 px-3 bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90"
                    >
                        <Plus className="w-3 h-3" />
                    </Button>
                </div>
            </div>

            {/* Commit History */}
            <div className="flex-1 overflow-y-auto p-0">
                {commits.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-40 text-neutral-600 space-y-2">
                        <GitCommit className="w-8 h-8 opacity-20" />
                        <span className="text-xs">No history recorded</span>
                    </div>
                ) : (
                    <div className="divide-y divide-white/5">
                        {commits.map((commit) => (
                            <div key={commit.id} className="p-3 hover:bg-white/5 transition-colors group">
                                <div className="flex items-start justify-between mb-1">
                                    <div className="flex items-center gap-2">
                                        <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))]" />
                                        <span className="text-xs font-medium text-neutral-200">
                                            {commit.message}
                                        </span>
                                    </div>
                                    <span className="text-[10px] font-mono text-neutral-600">
                                        {commit.id.substring(0, 6)}
                                    </span>
                                </div>
                                <div className="flex items-center justify-between mt-2">
                                    <span className="text-[10px] text-neutral-500 flex items-center gap-1">
                                        <Clock className="w-3 h-3" />
                                        {format(commit.timestamp, 'HH:mm:ss')}
                                    </span>
                                    <Button 
                                        variant="ghost" 
                                        size="sm"
                                        onClick={() => handleRestore(commit.snapshot)}
                                        className="h-6 text-[10px] opacity-0 group-hover:opacity-100 transition-opacity hover:text-white"
                                    >
                                        <RotateCcw className="w-3 h-3 mr-1" /> Revert
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}