import React from 'react';
import WidgetBase from './widgets/WidgetBase';
import { WIDGET_REGISTRY } from './WidgetRegistry';
import SandboxedRenderer from '@/components/content/SandboxedRenderer';

export default function WidgetLayer({ 
    widgets,
    customWidgets = [], // Array of installed addons passed from parent
    onMove,
    onToggleSize,
    onClose,
    onPin,
    onResize,
    onStackAction
}) {
    return (
        <div className="absolute inset-0 z-10 pointer-events-none">
            {widgets.map(widget => {
                // Handle Stacks
                if (widget.type === 'stack') {
                    const WidgetStack = require('./widgets/WidgetStack').default; 
                    return (
                        <WidgetStack 
                            key={widget.id}
                            id={widget.id}
                            widgets={widget.widgets}
                            activeWidgetId={widget.activeWidgetId}
                            onSetActive={(sId, wId) => onStackAction(sId, 'setActive', wId)}
                            position={widget.position}
                            size={widget.size}
                            w={widget.w}
                            h={widget.h}
                            onMove={onMove}
                            onResize={onResize}
                            onClose={onClose}
                            onPin={onPin}
                            className="pointer-events-auto"
                        />
                    );
                }

                // 1. Try Static Registry
                let config = WIDGET_REGISTRY[widget.type];
                let CustomComponent = null;

                // 2. Try Dynamic Addons
                if (!config) {
                    const addon = customWidgets.find(w => w.id === widget.type || w.addon_id === widget.type);
                    if (addon) {
                        // Found a custom installed widget
                        config = {
                            title: addon.name || 'Custom Widget',
                            defaultSize: 'md',
                            isDynamic: true,
                            code: addon.manifest?.code
                        };
                    }
                }

                if (!config) return null;

                const baseProps = {
                    key: widget.id,
                    id: widget.id,
                    position: widget.position,
                    size: widget.size || config.defaultSize || 'md',
                    w: widget.w,
                    h: widget.h,
                    title: widget.title || config.title, 
                    onMove: onMove,
                    onResize: onResize,
                    onToggleSize: onToggleSize,
                    onClose: onClose,
                    onPin: onPin,
                    className: "pointer-events-auto"
                };

                // Dynamic (Sandboxed) Widget
                if (config.isDynamic) {
                    return (
                        <WidgetBase key={widget.id} {...baseProps}>
                            <div className="w-full h-full overflow-hidden bg-neutral-900/50">
                                <SandboxedRenderer html={config.code} className="w-full h-full" />
                            </div>
                        </WidgetBase>
                    );
                }

                // Standard Static Widget
                const Component = config.component;
                if (config.customWrapper) {
                    return <Component key={widget.id} {...baseProps} />;
                }

                return (
                    <WidgetBase key={widget.id} {...baseProps}>
                        <Component />
                    </WidgetBase>
                );
            })}
        </div>
    );
}