import React, { useState } from 'react';
import { motion, useDragControls } from 'framer-motion';
import { PRODUCT_CONFIG } from '@/components/brand/ProductIcon';
import { cn } from "@/lib/utils";
import { Box, FolderOpen, FileText, Trash2, ExternalLink, Settings, Terminal, Activity, Globe } from 'lucide-react';
import { useGrid } from './DesktopGridSystem';
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger, ContextMenuSeparator } from "@/components/ui/context-menu";
import ProductIcon from '@/components/brand/ProductIcon';

const FileCard = ({ item, isSelected }) => (
    <div className={cn(
        "w-full h-full flex flex-col items-center justify-center relative transition-all duration-200",
        "bg-neutral-100 dark:bg-neutral-800",
        "border border-neutral-200 dark:border-neutral-700",
        "shadow-sm hover:shadow-md",
        "rounded-sm" // Sharp corners for files
    )}>
        {/* Paper Fold Effect */}
        <div className="absolute top-0 right-0 border-l-[12px] border-b-[12px] border-l-transparent border-b-neutral-200 dark:border-b-neutral-700 w-0 h-0" />
        
        <div className="flex-1 flex items-center justify-center w-full bg-white dark:bg-neutral-900 m-1 mt-3 mb-1 rounded-sm border border-dashed border-neutral-200 dark:border-neutral-800">
            <span className="text-[8px] font-mono text-neutral-400 font-bold uppercase">{item.id.split('.').pop().slice(0,3)}</span>
        </div>
        <div className="h-1/4 w-full bg-neutral-50 dark:bg-neutral-800 border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-center">
            <FileText className="w-3 h-3 text-neutral-400" />
        </div>
    </div>
);

const SystemIcon = ({ item, isSelected }) => {
    // Special handling for Trash
    if (item.id === 'RecycleBin') {
        return (
             <div className="w-full h-full flex items-center justify-center rounded-full bg-zinc-800 border-2 border-zinc-700 shadow-inner group-hover:border-zinc-500 transition-colors">
                <Trash2 className="w-1/2 h-1/2 text-zinc-400" />
             </div>
        );
    }
    
    // Default System App Style (Round)
    const Icon = item.icon || Settings;
    return (
        <div className={cn(
            "w-full h-full flex items-center justify-center rounded-full shadow-lg transition-transform hover:scale-105",
            "bg-gradient-to-b from-neutral-700 to-black border border-white/10"
        )}>
             {typeof item.icon === 'function' ? (
                 <item.icon className="w-1/2 h-1/2 text-white" />
             ) : (
                 <Icon className="w-1/2 h-1/2 text-white" />
             )}
        </div>
    );
};

const DraggableStackIcon = ({ item, onLaunch, onMove, onDelete, onRename, isSelected, onSelect }) => {
    const { snapToGrid, gridConfig } = useGrid();
    const controls = useDragControls();
    const [isRenaming, setIsRenaming] = useState(false);
    const [tempName, setTempName] = useState(item.name);
    
    const cellSize = gridConfig.cellSize;
    const gap = gridConfig.gap;
    const totalUnit = cellSize + gap;
    
    const containerStyle = {
        width: `${totalUnit}px`, 
        height: `${totalUnit}px`,
        padding: '12px'
    };
    
    // Determine Icon Type
    const isProduct = item.type === 'app' && PRODUCT_CONFIG[item.id];
    const isFile = item.type === 'file';
    const isFolder = item.type === 'folder';
    const isSystem = item.type === 'system' || (!isProduct && !isFile && !isFolder);

    const handleDragEnd = (event, info) => {
        const currentX = item.position?.x || 0;
        const currentY = item.position?.y || 0;
        const newX = currentX + info.offset.x;
        const newY = currentY + info.offset.y;
        const snapped = snapToGrid(newX, newY, totalUnit, totalUnit);
        onMove(item.id, snapped.x, snapped.y);
    };

    const handleLabelClick = (e) => {
        e.stopPropagation();
        if (isSelected && !isRenaming) {
            setIsRenaming(true);
        } else {
            onSelect && onSelect(item.id);
        }
    };

    return (
        <motion.div
            layout
            drag
            dragControls={controls}
            dragMomentum={false}
            dragElastic={0.1}
            onDragEnd={handleDragEnd}
            initial={{ opacity: 0, scale: 0.8, x: item.position?.x || 0, y: item.position?.y || 0 }}
            animate={{ opacity: 1, scale: 1, x: item.position?.x || 0, y: item.position?.y || 0 }}
            whileHover={{ scale: 1.05, zIndex: 50 }}
            whileTap={{ scale: 0.95 }}
            className={cn(
                "absolute flex flex-col items-center gap-2 cursor-pointer p-2 rounded-lg transition-colors",
                isSelected && !isRenaming ? "bg-white/10 ring-1 ring-white/20" : ""
            )}
            style={{ 
                x: item.position?.x, 
                y: item.position?.y,
                ...containerStyle
            }}
            onDoubleClick={() => onLaunch(item)}
            onPointerDown={(e) => {
                onSelect && onSelect(item.id);
                controls.start(e);
            }}
        >
            {/* ICON VISUAL */}
            <div className="relative flex-shrink-0 group" style={{ width: cellSize, height: cellSize }}>
                
                {isProduct ? (
                    <div className="w-full h-full shadow-2xl">
                        <ProductIcon id={item.id} size="md" />
                        {/* No shortcut arrow for products, they are "Apps" */}
                    </div>
                ) : isFile ? (
                    <div className="w-[80%] h-full mx-auto">
                        <FileCard item={item} />
                    </div>
                ) : isFolder ? (
                    <div className="w-full h-full flex items-center justify-center bg-white/5 border border-white/10 rounded-xl backdrop-blur-sm hover:bg-white/20 transition-colors">
                        {item.contents ? (
                             <div className="grid grid-cols-2 gap-1 p-2 w-full h-full">
                                {item.contents.slice(0, 4).map((sub, i) => (
                                    <div key={i} className="bg-neutral-800 rounded-sm w-full h-full flex items-center justify-center overflow-hidden">
                                        <div className={`w-2 h-2 rounded-full bg-${sub.theme || 'blue'}-500`} />
                                    </div>
                                ))}
                             </div>
                        ) : (
                            <FolderOpen className="w-1/2 h-1/2 text-yellow-500 fill-yellow-500/20" />
                        )}
                    </div>
                ) : (
                    <div className="w-full h-full p-2">
                        <SystemIcon item={item} />
                    </div>
                )}

                {/* Shortcut Overlay for Non-System/Non-Files */}
                {!isSystem && !isFile && !isFolder && item.type !== 'app' && (
                    <div className="absolute -bottom-1 -left-1 bg-black/60 rounded-full p-1 border border-white/10">
                        <ExternalLink className="w-3 h-3 text-white/80" />
                    </div>
                )}
            </div>

            {/* LABEL */}
            {isRenaming ? (
                <input 
                    autoFocus
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    onBlur={() => { setIsRenaming(false); onRename(item.id, tempName); }}
                    onKeyDown={(e) => { if (e.key === 'Enter') { setIsRenaming(false); onRename(item.id, tempName); }}}
                    className="w-full text-center bg-black/80 text-white border border-blue-500/50 rounded px-1 py-0.5 text-xs outline-none z-50 relative shadow-xl"
                    onPointerDown={(e) => e.stopPropagation()} 
                    onClick={(e) => e.stopPropagation()}
                />
            ) : (
                <span 
                    onClick={handleLabelClick}
                    className={cn(
                    "font-medium text-white text-center leading-tight px-2 py-1 rounded-sm select-none max-w-[140%] overflow-hidden text-ellipsis whitespace-nowrap transition-all",
                    "drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)] shadow-black", // Enhanced readability
                    cellSize < 48 ? 'text-[9px]' : 'text-xs',
                    isSelected ? "bg-[hsl(var(--color-intent))]/30 text-white ring-1 ring-[hsl(var(--color-intent))]/50" : "bg-black/20 hover:bg-black/60 hover:z-50 hover:whitespace-normal"
                )}>
                    {item.name}
                </span>
            )}
        </motion.div>
    );
};

export default function DesktopIconGrid({ apps, onLaunch, onMove, onDelete, onRename }) {
    const [selectedIds, setSelectedIds] = useState([]);
    const [selectionBox, setSelectionBox] = useState(null);
    const containerRef = React.useRef(null);
    const { gridConfig } = useGrid();

    // Marquee Selection Logic
    const handlePointerDown = (e) => {
        if (e.target !== containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const startX = e.clientX - rect.left;
        const startY = e.clientY - rect.top;
        
        setSelectionBox({
            startX, startY,
            currentX: startX, currentY: startY,
            isSelecting: true
        });
        setSelectedIds([]); // Clear on new selection start
    };

    const handlePointerMove = (e) => {
        if (!selectionBox?.isSelecting) return;
        
        const rect = containerRef.current.getBoundingClientRect();
        const currentX = e.clientX - rect.left;
        const currentY = e.clientY - rect.top;
        
        setSelectionBox(prev => ({ ...prev, currentX, currentY }));

        // Calculate intersection
        const left = Math.min(selectionBox.startX, currentX);
        const top = Math.min(selectionBox.startY, currentY);
        const width = Math.abs(currentX - selectionBox.startX);
        const height = Math.abs(currentY - selectionBox.startY);

        const newSelectedIds = apps.filter(app => {
            if (!app.position) return false;
            const appSize = gridConfig.cellSize + gridConfig.gap;
            // Simple box intersection
            return (
                left < app.position.x + appSize &&
                left + width > app.position.x &&
                top < app.position.y + appSize &&
                top + height > app.position.y
            );
        }).map(app => app.id);

        setSelectedIds(newSelectedIds);
    };

    const handlePointerUp = () => {
        if (selectionBox) {
            setSelectionBox(null);
        }
    };

    return (
        <div 
            ref={containerRef}
            className="absolute inset-0 z-10" 
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
        >
            {selectionBox && (
                <div 
                    className="absolute bg-blue-500/20 border border-blue-500/50 z-50 pointer-events-none"
                    style={{
                        left: Math.min(selectionBox.startX, selectionBox.currentX),
                        top: Math.min(selectionBox.startY, selectionBox.currentY),
                        width: Math.abs(selectionBox.currentX - selectionBox.startX),
                        height: Math.abs(selectionBox.currentY - selectionBox.startY)
                    }}
                />
            )}

            {apps.map((app) => (
                <div key={app.id} className="absolute inset-0 pointer-events-none">
                    <ContextMenu>
                        <ContextMenuTrigger>
                            <div className="pointer-events-auto">
                                <DraggableStackIcon 
                                    item={app} 
                                    onLaunch={onLaunch}
                                    onMove={onMove}
                                    onDelete={onDelete}
                                    onRename={onRename}
                                    isSelected={selectedIds.includes(app.id)}
                                    onSelect={(id) => setSelectedIds([id])}
                                />
                            </div>
                        </ContextMenuTrigger>
                        <ContextMenuContent className="bg-neutral-900 border-white/10 text-neutral-200 w-48">
                            <ContextMenuItem onClick={() => onLaunch(app)}>
                                <ExternalLink className="w-4 h-4 mr-2" /> Open
                            </ContextMenuItem>
                            <ContextMenuItem onClick={() => {
                                const newName = prompt("Rename to:", app.name);
                                if (newName) onRename(app.id, newName);
                            }}>
                                <FileText className="w-4 h-4 mr-2" /> Rename
                            </ContextMenuItem>
                            <ContextMenuSeparator className="bg-white/10" />
                            <ContextMenuItem className="text-red-500 focus:text-red-500 focus:bg-red-500/10" onClick={() => onDelete && onDelete(app.id)}>
                                <Trash2 className="w-4 h-4 mr-2" /> Delete
                            </ContextMenuItem>
                        </ContextMenuContent>
                    </ContextMenu>
                </div>
            ))}
        </div>
    );
}