import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { X, FolderOpen, ExternalLink } from 'lucide-react';
import { cn } from "@/lib/utils";
import ProductIcon, { PRODUCT_CONFIG } from '@/components/brand/ProductIcon';

export default function DesktopFolderExpanded({ folder, onClose, onLaunch, onExtract }) {
    const containerRef = useRef(null);

    if (!folder) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
            {/* Backdrop - Click to close */}
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                onClick={onClose}
            />

            {/* Folder Container */}
            <motion.div 
                ref={containerRef}
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative bg-[#1a1a1a]/90 border border-white/10 rounded-2xl p-6 w-[500px] min-h-[300px] shadow-2xl flex flex-col gap-4 z-10"
                onClick={(e) => e.stopPropagation()}
            >
                {/* Header */}
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                    <div className="flex items-center gap-3">
                        <FolderOpen className="w-5 h-5 text-neutral-400" />
                        <span className="text-lg font-medium text-neutral-200">{folder.name}</span>
                    </div>
                    <button 
                        onClick={onClose}
                        className="p-1 hover:bg-white/10 rounded-full transition-colors text-neutral-400 hover:text-white"
                    >
                        <X className="w-5 h-5" />
                    </button>
                </div>

                {/* Grid Content */}
                <div className="grid grid-cols-4 gap-4 flex-1 content-start">
                    {folder.contents?.map((app) => (
                        <FolderItem 
                            key={app.id} 
                            app={app} 
                            folderRef={containerRef}
                            onLaunch={() => {
                                onLaunch(app);
                                onClose();
                            }}
                            onExtract={(point) => onExtract(folder.id, app.id, point)}
                        />
                    ))}
                    
                    {(!folder.contents || folder.contents.length === 0) && (
                        <div className="col-span-4 h-32 flex items-center justify-center text-neutral-600 italic">
                            Folder is empty
                        </div>
                    )}
                </div>
            </motion.div>
        </div>
    );
}

function FolderItem({ app, folderRef, onLaunch, onExtract }) {
    const isProduct = !!PRODUCT_CONFIG[app.id];

    return (
        <motion.div
            drag
            dragMomentum={false}
            dragElastic={0.2}
            whileHover={{ scale: 1.05 }}
            whileDrag={{ scale: 1.1, zIndex: 100 }}
            onDragEnd={(e, info) => {
                const folderRect = folderRef.current?.getBoundingClientRect();
                const point = info.point;
                
                // Check if dropped OUTSIDE the folder container
                if (folderRect && (
                    point.x < folderRect.left - 50 || 
                    point.x > folderRect.right + 50 || 
                    point.y < folderRect.top - 50 || 
                    point.y > folderRect.bottom + 50
                )) {
                    onExtract(point);
                }
            }}
            className="flex flex-col items-center gap-2 cursor-pointer p-2 rounded-xl hover:bg-white/5 transition-colors group relative"
            onDoubleClick={onLaunch}
        >
            <div className="w-14 h-14 relative">
                {isProduct ? (
                    <ProductIcon id={app.id} size="md" className="shadow-lg" />
                ) : (
                    <div className="w-full h-full flex items-center justify-center bg-neutral-800 rounded-xl border border-white/5 group-hover:border-white/20">
                         {/* Fallback Icon */}
                         <div className="text-neutral-400 font-bold text-xs">{app.name[0]}</div>
                    </div>
                )}
            </div>
            <span className="text-xs text-neutral-300 text-center line-clamp-1 w-full group-hover:text-white">
                {app.name}
            </span>
        </motion.div>
    );
}