import React, { useState } from 'react';
import { Search, ChevronRight } from 'lucide-react';
import { BrandLogo } from '@/components/brand/BrandLogo';
import { createPageUrl } from '@/utils';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function DesktopHero() {
    const [searchTerm, setSearchTerm] = useState('');
    const navigate = useNavigate();

    const handleSearch = (e) => {
        e.preventDefault();
        if (searchTerm.trim()) {
            navigate(createPageUrl(`SearchResults?q=${encodeURIComponent(searchTerm)}`));
        }
    };

    return (
        <div className="absolute inset-0 z-0 flex flex-col items-center justify-center pointer-events-none">
            {/* THE PERSPECTIVE LINE (The Path) */}
            <div className="absolute top-1/2 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[hsl(var(--color-intent))]/50 to-transparent w-full blur-[1px]" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 w-[1px] h-[50vh] bg-gradient-to-b from-[hsl(var(--color-intent))]/50 to-transparent blur-[1px] origin-top transform perspective-1000 rotate-x-60" />

            {/* Floating Content */}
            <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, ease: "easeOut" }}
                className="relative z-10 flex flex-col items-center pointer-events-auto"
            >
                {/* Logo with Obsidian Glow */}
                <div className="relative mb-12 group cursor-pointer" onClick={() => navigate(createPageUrl('Home'))}>
                    <div className="absolute inset-0 bg-[hsl(var(--color-intent))] blur-[100px] opacity-10 rounded-full group-hover:opacity-30 transition-opacity duration-1000" />
                    
                    <div className="relative z-10 flex flex-col items-center">
                        <BrandLogo size="large" className="drop-shadow-[0_0_35px_rgba(0,0,0,1)]" />
                        <div className="mt-4 flex flex-col items-center space-y-1">
                            <span className="text-3xl font-bold tracking-[0.2em] text-white/90 font-sans">XI-IO STUDIO</span>
                            <span className="text-[10px] tracking-[0.5em] text-[hsl(var(--color-intent))] uppercase opacity-70 font-mono">xibalba xi-io: obsidian</span>
                        </div>
                    </div>
                </div>

                {/* The Scrying Pool (Search) */}
                <form onSubmit={handleSearch} className="relative w-[500px] group perspective-1000">
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-xl border border-white/10 rounded-full shadow-[0_10px_40px_-10px_rgba(0,0,0,0.8)] transition-all duration-500 group-hover:border-[hsl(var(--color-intent))]/40 group-hover:shadow-[0_0_50px_-10px_hsl(var(--color-intent))/20]" />
                    
                    <div className="relative flex items-center px-6 h-14">
                        <Search className="w-5 h-5 text-neutral-500 mr-4 group-hover:text-[hsl(var(--color-intent))] transition-colors duration-500" />
                        <input 
                            type="text" 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Summon application or search knowledge base..." 
                            className="bg-transparent border-none outline-none text-base text-white placeholder:text-neutral-600 flex-1 font-sans tracking-wide"
                        />
                        <button type="submit" className="p-2 hover:bg-white/5 rounded-full text-neutral-500 hover:text-white transition-colors">
                            <ChevronRight className="w-4 h-4" />
                        </button>
                    </div>
                </form>

                {/* Status Indicators */}
                <div className="absolute top-full mt-16 flex gap-12 opacity-40 text-[9px] font-mono tracking-widest text-neutral-400">
                    <span className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" /> SYSTEM NOMINAL
                    </span>
                    <span className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse delay-75" /> UPLINK SECURE
                    </span>
                </div>
            </motion.div>
        </div>
    );
}