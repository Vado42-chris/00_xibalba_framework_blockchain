import React from 'react';
import { motion } from 'framer-motion';
import { 
    Infinity, Bot, Terminal, Layout, 
    ChevronUp, Wifi, Battery, Search, X, Maximize2, Minimize2
} from 'lucide-react';
import { cn } from "@/lib/utils";
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger } from "@/components/ui/context-menu";

const DockItem = ({ icon: Icon, label, isOpen, isActive, onClick, onClose, onMaximize, color = "text-neutral-400" }) => (
    <ContextMenu>
        <ContextMenuTrigger>
            <motion.button
                whileHover={{ scale: 1.2, y: -10 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClick}
                className={cn(
                    "relative group p-3 rounded-2xl transition-all duration-300",
                    isActive 
                        ? "bg-white/20 text-white shadow-[0_0_20px_-5px_rgba(255,255,255,0.4)] border border-white/20" 
                        : isOpen 
                            ? "bg-white/5 text-white border border-white/5" 
                            : "hover:bg-white/5 text-neutral-400",
                    color
                )}
            >
                <Icon className="w-6 h-6" />
                
                {/* Open Indicator (Dot) */}
                {isOpen && (
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 flex flex-col gap-0.5">
                         <div className="w-1.5 h-1.5 bg-[hsl(var(--color-intent))] rounded-full shadow-[0_0_8px_hsl(var(--color-intent))]" />
                         {isActive && <div className="w-1.5 h-0.5 bg-white/50 rounded-full" />}
                    </div>
                )}

                {/* Tooltip */}
                <div className="absolute -top-14 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-black/80 backdrop-blur-md border border-white/10 rounded-lg text-[10px] text-white font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none translate-y-2 group-hover:translate-y-0 duration-200 shadow-xl z-50">
                    {label}
                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black/80 border-r border-b border-white/10 rotate-45" />
                </div>
            </motion.button>
        </ContextMenuTrigger>
        <ContextMenuContent className="bg-[#18181b] border-[#27272a] text-neutral-200">
            <ContextMenuItem onClick={onClick} className="text-xs focus:bg-[#27272a] focus:text-white cursor-pointer">
                <Layout className="w-3.5 h-3.5 mr-2" /> {isOpen ? (isActive ? 'Minimize' : 'Focus') : 'Open'}
            </ContextMenuItem>
            {isOpen && (
                <ContextMenuItem onClick={onClose} className="text-xs text-red-400 focus:bg-red-500/10 focus:text-red-400 cursor-pointer">
                    <X className="w-3.5 h-3.5 mr-2" /> Close Window
                </ContextMenuItem>
            )}
        </ContextMenuContent>
    </ContextMenu>
);

export default function InfinityDock({ apps, pinnedDockIds = [], onLaunch, onClose, openWindows, activeWindowId, onStartClick, isStartOpen, onSearch, domainData }) {
    
    // Filter apps for the dock: Pinned + Open Windows
    const dockItems = apps.filter(app => {
        const isPinned = pinnedDockIds.includes(app.id);
        const isOpen = openWindows.some(w => w.appId === app.id);
        return isPinned || isOpen;
    });

    // Helper for color sorting
    const getColorHue = (theme = '') => {
        const colorMap = {
            red: 0, orange: 30, amber: 45, yellow: 60, lime: 75,
            green: 120, emerald: 150, teal: 160, cyan: 180, sky: 200,
            blue: 240, indigo: 260, violet: 270, purple: 280, fuchsia: 300,
            pink: 330, rose: 345, slate: 900, gray: 900, zinc: 900, neutral: 900, stone: 900
        };
        const color = theme.split('-')[0];
        return colorMap[color] || 999;
    };

    // Sort: Pinned first (in order), then Open (non-pinned)
    // "Clean rainbow of color organized by color from left to right"
    // User wants ALL items organized by color? Or just the taskbar items?
    // "We want a clean rainbow of color organized by color from left to right the same width as the taskbar"
    // This implies disregarding "Pinned Order" in favor of Color Order.
    const sortedDockItems = dockItems.sort((a, b) => {
        return getColorHue(a.theme) - getColorHue(b.theme);
    });
    
    return (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-4 w-full max-w-5xl pointer-events-none">
            
            {/* THE DOCK */}
            <motion.div 
                initial={{ y: 100, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ type: "spring", damping: 20 }}
                className="pointer-events-auto h-24 px-6 bg-black/30 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] flex items-center gap-3 shadow-[0_20px_50px_-10px_rgba(0,0,0,0.5)]"
            >
                {/* OS IDENTITY */}
                <div className="flex flex-col items-end mr-4">
                    <span className="text-xs font-bold text-white tracking-widest uppercase">{domainData?.name || 'XI-OS'}</span>
                    <span className="text-[9px] text-neutral-500 font-mono">v3.0.0</span>
                </div>

                <div className="w-px h-10 bg-white/10 mx-2" />

                {/* START BUTTON */}
                <motion.button
                    whileHover={{ scale: 1.1, rotate: 180 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={onStartClick}
                    className={cn(
                        "w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 border",
                        isStartOpen 
                            ? "bg-[hsl(var(--color-intent))] text-black border-[hsl(var(--color-intent))] shadow-[0_0_30px_hsl(var(--color-intent))]" 
                            : "bg-white/5 text-white border-white/10 hover:bg-white/10 hover:border-white/20"
                    )}
                >
                    <Infinity className="w-7 h-7" />
                </motion.button>

                {/* SEARCH BUTTON */}
                <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={onSearch}
                    className="w-14 h-14 rounded-2xl flex items-center justify-center transition-all duration-300 border bg-white/5 text-white border-white/10 hover:bg-white/10 hover:border-white/20"
                    title="Global Search"
                >
                    <Search className="w-6 h-6" />
                </motion.button>

                <div className="w-px h-10 bg-white/10 mx-2" />

                {/* PINNED SUITES */}
                {sortedDockItems.map(app => {
                    const windowInfo = openWindows.find(w => w.appId === app.id);
                    const isOpen = !!windowInfo;
                    const isActive = windowInfo && windowInfo.id === activeWindowId;
                    
                    return (
                        <DockItem 
                            key={app.id}
                            icon={app.icon} 
                            label={app.name} 
                            color={`text-${app.theme}`} 
                            isOpen={isOpen}
                            isActive={isActive}
                            onClick={() => onLaunch(app)}
                            onClose={() => windowInfo && onClose && onClose(windowInfo.id)}
                            onMaximize={() => windowInfo && onLaunch(app)}
                        />
                    );
                })}

                <div className="w-px h-10 bg-white/10 mx-2" />

                {/* SYSTEM TRAY */}
                <div className="flex items-center gap-4 pl-2 pr-2">
                    <div className="flex flex-col gap-1">
                         <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_5px_currentColor]" />
                         <div className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_5px_currentColor] animate-pulse" />
                    </div>
                    <div className="text-[10px] font-mono text-neutral-500 leading-tight">
                        <div>NET: OK</div>
                        <div>CPU: 12%</div>
                    </div>
                </div>

            </motion.div>
        </div>
    );
}