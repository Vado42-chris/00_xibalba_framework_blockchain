import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

export default function AtmosphereLayer({ mode = 'nebula', accentColor = '255, 255, 255' }) {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        let animationFrameId;
        let particles = [];
        
        const resize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        
        window.addEventListener('resize', resize);
        resize();

        // Particle Class
        class Particle {
            constructor(type = 'standard') {
                this.type = type;
                this.reset(true);
            }

            reset(initial = false) {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.life = Math.random() * 100;
                this.maxLife = 100 + Math.random() * 100;
                this.twinkleOffset = Math.random() * 100;

                if (this.type === 'dust') {
                    this.size = Math.random() * 0.8; 
                    this.speedX = (Math.random() - 0.5) * 0.1; 
                    this.speedY = (Math.random() - 0.5) * 0.1;
                    this.opacity = Math.random() * 0.2 + 0.1;
                } else if (this.type === 'spark') {
                    this.size = Math.random() * 8 + 3;
                    this.speedX = (Math.random() - 0.5) * 2.5; 
                    this.speedY = (Math.random() - 0.5) * 2.5;
                    this.opacity = 0.9;
                    this.color = Math.random() > 0.6 ? '255, 220, 150' : '100, 220, 255';
                } else {
                    // Standard
                    this.size = Math.random() * 2.5;
                    this.speedX = (Math.random() - 0.5) * 0.6;
                    this.speedY = (Math.random() - 0.5) * 0.6;
                    this.opacity = Math.random() * 0.5 + 0.2;
                }
            }

            update() {
                this.x += this.speedX;
                this.y += this.speedY;
                this.life++;

                if (this.life > this.maxLife || 
                    this.x < 0 || this.x > canvas.width || 
                    this.y < 0 || this.y > canvas.height) {
                    this.reset();
                }
            }

            draw() {
                if (this.type === 'spark') {
                    ctx.save();
                    ctx.globalCompositeOperation = 'lighter'; 
                    ctx.beginPath();
                    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                    // Add pulsing glow
                    const pulse = 1 + 0.2 * Math.sin(this.life * 0.1);
                    ctx.fillStyle = `rgba(${this.color}, ${this.opacity * (1 - this.life/this.maxLife) * pulse})`;
                    ctx.fill();
                    ctx.restore();
                } else {
                    ctx.beginPath();
                    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                    // Twinkle effect
                    const twinkle = 0.7 + 0.3 * Math.sin(this.life * 0.15 + this.twinkleOffset);
                    ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity * (1 - this.life/this.maxLife) * twinkle})`;
                    ctx.fill();
                }
            }
        }

        // Initialize Standard Particles
        for (let i = 0; i < 800; i++) { 
            particles.push(new Particle('standard'));
        }
        
        // Add "Dust" Particles
        for (let i = 0; i < 1500; i++) {
            particles.push(new Particle('dust'));
        }

        // Add "Sparks"
        for (let i = 0; i < 300; i++) {
            particles.push(new Particle('spark'));
        }

        const render = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // 1. Background Fill based on Mode
            if (mode === 'void') {
                ctx.fillStyle = '#000000';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            } else if (mode === 'grid') {
                ctx.fillStyle = '#050505';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            } else {
                // Nebula / Default
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }

            // Heavy Vignette for Shadowy Depth (Always apply for depth)
            const gradient = ctx.createRadialGradient(
                canvas.width / 2, canvas.height / 2, 0,
                canvas.width / 2, canvas.height / 2, canvas.width * 0.9
            );
            gradient.addColorStop(0, 'rgba(0, 0, 0, 0.1)');
            gradient.addColorStop(0.5, 'rgba(0, 0, 0, 0.4)');
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0.95)'); 
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Drafting Table Grid Overlay (Conditional)
            if (mode !== 'void') {
                ctx.save();
                ctx.strokeStyle = mode === 'grid' ? `rgba(${accentColor}, 0.1)` : 'rgba(255, 255, 255, 0.03)';
                ctx.lineWidth = 1;
                const gridSize = 40;
                
                for (let x = 0; x <= canvas.width; x += gridSize) {
                    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
                }
                for (let y = 0; y <= canvas.height; y += gridSize) {
                    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
                }
                
                // Major Grid Lines
                ctx.strokeStyle = mode === 'grid' ? `rgba(${accentColor}, 0.2)` : 'rgba(255, 255, 255, 0.05)';
                ctx.lineWidth = 2;
                for (let x = 0; x <= canvas.width; x += gridSize * 4) {
                    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
                }
                for (let y = 0; y <= canvas.height; y += gridSize * 4) {
                    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
                }
                ctx.restore();
            }

            // Particles (Conditional)
            if (mode !== 'void' && mode !== 'grid') {
                particles.forEach(p => {
                    p.update();
                    p.draw();
                });
            }

            animationFrameId = requestAnimationFrame(render);
        };

        render();

        return () => {
            window.removeEventListener('resize', resize);
            cancelAnimationFrame(animationFrameId);
        };
    }, []);

    return (
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
            <canvas ref={canvasRef} className="absolute inset-0 opacity-40" />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/60 pointer-events-none" />
            {/* Vignette */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.6)_100%)] pointer-events-none" />
        </div>
    );
}