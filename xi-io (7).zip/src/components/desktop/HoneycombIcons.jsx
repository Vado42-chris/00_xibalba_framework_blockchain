import React, { useRef, useState } from 'react';
import { motion, useDragControls, AnimatePresence } from 'framer-motion';
import { cn } from "@/lib/utils";
import { Settings, Layers, Box, FolderOpen, Bot, LayoutGrid, LayoutList, Maximize } from 'lucide-react';

const Hexagon = ({ children, className, ...props }) => (
    <div 
        className={cn(
            "relative flex items-center justify-center clip-hex transition-all duration-300",
            className
        )}
        style={{ 
            clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" 
        }}
        {...props}
    >
        {children}
    </div>
);

const DesktopIcon = ({ item, onLaunch, onDragEnd, size = 'md' }) => {
    const dragControls = useDragControls();
    const isStack = item.type === 'stack';
    
    // Size variants
    const sizes = {
        sm: { hex: 'w-16 h-20', icon: 'w-6 h-6', text: 'hidden' },
        md: { hex: 'w-24 h-28', icon: 'w-8 h-8', text: 'text-[9px]' },
        lg: { hex: 'w-32 h-36', icon: 'w-10 h-10', text: 'text-xs' }
    };
    const s = sizes[size] || sizes.md;

    return (
        <motion.div
            drag
            dragControls={dragControls}
            dragMomentum={false}
            onDragEnd={(e, info) => onDragEnd(e, info, item)}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative group cursor-pointer z-10 hover:z-50"
            onDoubleClick={() => onLaunch(item)}
        >
            {/* Hexagon Container */}
            <div className={cn("relative flex items-center justify-center transition-all duration-300", s.hex)}>
                
                {/* Backplate */}
                <div className="absolute inset-0 bg-white/5 backdrop-blur-md clip-hex transition-all duration-300 group-hover:bg-white/10 group-hover:scale-105 border-t border-white/10"
                     style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }} 
                />
                
                {/* Stack Indicator Layer */}
                {isStack && (
                    <>
                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-16 h-4 bg-white/10 clip-hex opacity-50" />
                        <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-20 h-4 bg-white/20 clip-hex opacity-70" />
                    </>
                )}

                {/* Frontplate */}
                <div className={cn(
                        "absolute inset-[4px] bg-gradient-to-br from-white/10 to-transparent clip-hex border border-white/5 group-hover:border-[hsl(var(--color-intent))]/50 transition-colors duration-300",
                        isStack ? "border-t-2 border-t-[hsl(var(--color-intent))]" : ""
                    )}
                     style={{ clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)" }}
                >
                     {/* Inner Content */}
                     <div className="absolute inset-0 flex flex-col items-center justify-center p-2">
                        <div className={cn(
                            "rounded-full flex items-center justify-center mb-1 transition-transform group-hover:scale-110 group-active:scale-95 duration-200 shadow-lg",
                            isStack ? "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]" : `bg-${item.theme || 'neutral-500'}/20 text-${item.theme || 'neutral-500'}`,
                            s.icon
                        )}>
                            {isStack ? <Layers className="w-1/2 h-1/2" /> : (item.icon ? <item.icon className="w-1/2 h-1/2" /> : <Box className="w-1/2 h-1/2" />)}
                        </div>
                        
                        <span className={cn(
                            "font-bold text-neutral-300 tracking-wider text-center leading-tight group-hover:text-white transition-colors px-1 truncate w-full",
                            s.text
                        )}>
                            {item.name}
                        </span>

                        {isStack && (
                            <div className="absolute top-2 right-4 flex items-center justify-center w-4 h-4 rounded-full bg-[hsl(var(--color-intent))] text-black text-[8px] font-bold">
                                {item.items.length}
                            </div>
                        )}
                     </div>
                </div>

                {/* Active Indicator */}
                <div className="absolute bottom-0 w-12 h-1 bg-[hsl(var(--color-intent))] shadow-[0_0_10px_hsl(var(--color-intent))] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            
            {/* Context Menu / Assistant Trigger (Visible on Hover for Stacks) */}
            {isStack && (
                <div className="absolute -right-8 top-1/2 -translate-y-1/2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                    <button className="w-6 h-6 rounded-full bg-black/60 border border-white/20 flex items-center justify-center hover:bg-[hsl(var(--color-intent))] hover:text-black transition-colors" title="Stack Assistant">
                        <Bot className="w-3 h-3" />
                    </button>
                    <button className="w-6 h-6 rounded-full bg-black/60 border border-white/20 flex items-center justify-center hover:bg-white hover:text-black transition-colors" title="Open Stack">
                        <FolderOpen className="w-3 h-3" />
                    </button>
                </div>
            )}
        </motion.div>
    );
};

export default function HoneycombIcons({ apps, onLaunch, showGrid, activeTheme, onStack }) {
    // Size state
    const [size, setSize] = useState('md');

    // Handle dropping an item onto another
    const handleDragEnd = (e, info, draggedItem) => {
        // Simple proximity check - in a real app, use collision detection
        // For now, we simulate "if dropped in top-left area" or similar logic? 
        // Actually, without refs to other items, it's hard to detect collision in this component structure efficiently without a lot of state.
        // So I'll rely on the parent (DesktopEnvironment) to handle precise collision or just keep it visual for now.
        // But the user ASKED for stacking.
        // Let's implement a basic hit detection if we have coordinates.
        // Since we are using a grid layout, "drag end" might not give us target easily.
        
        // Simulating the "Create Stack" by dragging one icon onto another is tricky without a drop target system.
        // Instead, I'll add a "Combine Mode" button that when active, clicking two items groups them? 
        // No, drag is requested.
        
        // Use document.elementFromPoint to find target?
        const dropTarget = document.elementFromPoint(e.clientX, e.clientY);
        // Look for closest .desktop-icon parent
        const targetIcon = dropTarget?.closest('[data-icon-id]');
        
        if (targetIcon) {
            const targetId = targetIcon.getAttribute('data-icon-id');
            if (targetId && targetId !== draggedItem.id) {
                onStack(draggedItem.id, targetId);
            }
        }
    };

    return (
        <div className="absolute inset-0 z-10 pointer-events-none">
            {/* Grid Overlay */}
            {showGrid && (
                <motion.div 
                     initial={{ opacity: 0 }}
                     animate={{ opacity: 0.15 }}
                     className="absolute inset-0 pointer-events-none" 
                     style={{ 
                         backgroundImage: `
                            linear-gradient(30deg, ${activeTheme ? 'currentColor' : '#ffffff'} 12%, transparent 12.5%, transparent 87%, ${activeTheme ? 'currentColor' : '#ffffff'} 87.5%, ${activeTheme ? 'currentColor' : '#ffffff'}),
                            linear-gradient(150deg, ${activeTheme ? 'currentColor' : '#ffffff'} 12%, transparent 12.5%, transparent 87%, ${activeTheme ? 'currentColor' : '#ffffff'} 87.5%, ${activeTheme ? 'currentColor' : '#ffffff'}),
                            linear-gradient(30deg, ${activeTheme ? 'currentColor' : '#ffffff'} 12%, transparent 12.5%, transparent 87%, ${activeTheme ? 'currentColor' : '#ffffff'} 87.5%, ${activeTheme ? 'currentColor' : '#ffffff'}),
                            linear-gradient(150deg, ${activeTheme ? 'currentColor' : '#ffffff'} 12%, transparent 12.5%, transparent 87%, ${activeTheme ? 'currentColor' : '#ffffff'} 87.5%, ${activeTheme ? 'currentColor' : '#ffffff'}),
                            linear-gradient(60deg, ${activeTheme ? 'currentColor' : '#ffffff77'} 25%, transparent 25.5%, transparent 75%, ${activeTheme ? 'currentColor' : '#ffffff77'} 75%, ${activeTheme ? 'currentColor' : '#ffffff77'}),
                            linear-gradient(60deg, ${activeTheme ? 'currentColor' : '#ffffff77'} 25%, transparent 25.5%, transparent 75%, ${activeTheme ? 'currentColor' : '#ffffff77'} 75%, ${activeTheme ? 'currentColor' : '#ffffff77'})
                         `,
                         backgroundSize: '60px 105px',
                         backgroundPosition: '0 0, 0 0, 30px 52px, 30px 52px, 0 0, 30px 52px',
                         color: activeTheme ? 'hsl(var(--color-intent))' : 'white'
                     }} 
                />
            )}

            {/* Icon Grid Area - Pushed inwards to avoid widgets */}
            <div className="absolute top-48 left-16 right-16 bottom-32 pointer-events-auto flex flex-wrap content-start gap-6 p-4 overflow-visible">
                {apps.map((app, i) => (
                    <div 
                        key={app.id} 
                        data-icon-id={app.id} // Marker for hit detection
                        className={cn(
                            "transition-all duration-300",
                            i % 2 === 0 ? "mt-8" : "mt-0" // Honeycomb stagger effect
                        )}
                    >
                        <DesktopIcon 
                            item={app} 
                            onLaunch={onLaunch} 
                            onDragEnd={handleDragEnd}
                            size={size}
                        />
                    </div>
                ))}
            </div>

            {/* View Controls */}
            <div className="absolute bottom-32 right-8 pointer-events-auto flex flex-col gap-2">
                 <button onClick={() => setSize('sm')} className={cn("w-8 h-8 rounded bg-black/40 border border-white/10 flex items-center justify-center hover:bg-white/20 transition-colors", size==='sm' && "bg-white/20 border-white")}><LayoutGrid className="w-4 h-4" /></button>
                 <button onClick={() => setSize('md')} className={cn("w-8 h-8 rounded bg-black/40 border border-white/10 flex items-center justify-center hover:bg-white/20 transition-colors", size==='md' && "bg-white/20 border-white")}><LayoutList className="w-4 h-4" /></button>
                 <button onClick={() => setSize('lg')} className={cn("w-8 h-8 rounded bg-black/40 border border-white/10 flex items-center justify-center hover:bg-white/20 transition-colors", size==='lg' && "bg-white/20 border-white")}><Maximize className="w-4 h-4" /></button>
            </div>
        </div>
    );
}