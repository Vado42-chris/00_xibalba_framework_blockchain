import React from 'react';
import { motion } from 'framer-motion';
import { Search, Command } from 'lucide-react';
import { useGrid } from './DesktopGridSystem';

export default function DesktopCenterpiece({ onSearch }) {
    const { centralZone } = useGrid();
    const logoSrc = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693dffcccab0bea12e1e7952/a02aa7415_logo.png";

    // Dynamic Shadow Logic
    const [shadowStyle, setShadowStyle] = React.useState({ filter: 'drop-shadow(0 0 0 rgba(0,0,0,0))' });

    React.useEffect(() => {
        const handleMouseMove = (e) => {
            const centerX = window.innerWidth / 2;
            const centerY = window.innerHeight / 2;
            
            // Calculate vector from Mouse to Center (Light Source is Mouse)
            // Shadow falls in direction: Mouse -> Object -> Shadow
            // So vector is (Object - Mouse)
            const dx = (centerX - e.clientX) * 0.15; // 0.15 is the "depth" factor
            const dy = (centerY - e.clientY) * 0.15;
            
            // Blur increases with distance from center (simulating light diffusion)
            const dist = Math.sqrt(dx*dx + dy*dy);
            
            // Sharper when close, blurrier when far
            const blur = Math.max(4, Math.min(24, dist * 0.12));
            
            // Fades out as it gets further away (light falloff)
            // Base opacity 0.8, decreasing with distance
            const opacity = Math.max(0.2, 0.8 - (dist * 0.004));
            
            setShadowStyle({
                filter: `drop-shadow(${dx}px ${dy}px ${blur}px rgba(0,0,0,${opacity}))`
            });
        };

        window.addEventListener('mousemove', handleMouseMove);
        return () => window.removeEventListener('mousemove', handleMouseMove);
    }, []);

    return (
        <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center justify-center pointer-events-auto z-20"
            style={{ width: centralZone.width, height: centralZone.height }}
        >
            {/* OFFICIAL XIBALBA LOGO ONLY */}
            <div 
                className="flex flex-col items-center mb-16 group cursor-default"
                data-cursor-interact="logo"
            >
                {/* Dynamic Shadow Layer */}
                <motion.img 
                    src={logoSrc}
                    alt="XIBALBA"
                    className="h-64 object-contain transition-transform duration-700 group-hover:scale-105 relative z-10"
                    style={shadowStyle}
                />
                {/* Status Indicator only - No Text Name */}
                <div className="mt-8 flex items-center gap-3 text-[10px] font-mono text-neutral-500 tracking-widest uppercase opacity-50 group-hover:opacity-100 transition-opacity">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_#10b981]" />
                    System Online v2.5.0
                </div>
            </div>

            {/* Search Box */}
            <div className="relative w-full max-w-lg group">
                <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--color-intent))] via-purple-500 to-[hsl(var(--color-intent))] opacity-0 group-hover:opacity-20 blur-2xl transition-opacity duration-700 rounded-full" />
                <div 
                    className="relative h-14 bg-black/40 backdrop-blur-2xl border border-white/10 rounded-full flex items-center px-6 shadow-2xl transition-all duration-300 hover:border-[hsl(var(--color-intent))]/40 hover:bg-black/60 hover:shadow-[0_0_30px_-10px_rgba(0,0,0,0.5)] cursor-text group/search"
                    onClick={onSearch}
                >
                    <Search className="w-5 h-5 text-neutral-500 mr-4 group-hover/search:text-[hsl(var(--color-intent))] transition-colors" />
                    <input 
                        type="text" 
                        placeholder="Search system..." 
                        className="bg-transparent border-none outline-none text-base text-white placeholder:text-neutral-600 flex-1 font-medium tracking-wide"
                        readOnly // It triggers global search modal usually
                    />
                    <div className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-white/5 border border-white/5 text-[10px] font-bold text-neutral-500 group-hover/search:bg-white/10 group-hover/search:text-white transition-all">
                        <Command className="w-3 h-3" />
                        <span>K</span>
                    </div>
                </div>
            </div>

            {/* Perspective Lines - The Grid Anchor (Removed to prevent double grid) */}
            
            {/* Radial Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[hsl(var(--color-intent))] opacity-[0.03] blur-[100px] rounded-full -z-20 pointer-events-none" />
        </div>
    );
}