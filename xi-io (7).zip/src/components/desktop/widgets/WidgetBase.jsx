import React from 'react';
import { motion, useDragControls } from 'framer-motion';
import { X, GripVertical, Maximize2, Minimize2, Pin } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useGrid } from '../DesktopGridSystem';

export default function WidgetBase({ 
    id, 
    title, 
    children, 
    size = 'md', 
    position, 
    onMove, 
    onToggleSize, 
    onClose,
    onPin, // Add Pin Support
    className,
    ...props 
}) {
    const { snapToGrid } = useGrid();
    const dragControls = useDragControls();

    const sizes = {
        sm: 'w-64 h-32',
        md: 'w-80 h-64',
        lg: 'w-96 h-96',
        xl: 'w-[500px] h-[400px]' // For larger widgets like Terminal/Browser
    };

    const handleDragEnd = (event, info) => {
        const currentX = position?.x || 0;
        const currentY = position?.y || 0;
        
        const newX = currentX + info.offset.x;
        const newY = currentY + info.offset.y;

        // Snap logic would go here if we wanted strict grid snapping for widgets
        const snapped = snapToGrid(newX, newY, props.w || 320, props.h || 256); // Use actual dimensions if available
        
        if (onMove) {
            onMove(id, { x: snapped.x, y: snapped.y });
        }
    };

    // Resize Handlers
    const handleResize = (direction, e) => {
        e.stopPropagation();
        // This is a simplified resize implementation. 
        // In a real scenario, we'd listen to window mousemove events during drag.
        // For this demo, we'll assume the parent or a context handles the actual resize interaction
        // or we use framer-motion drag on the handles.
    };

    // We'll use framer-motion drag for resize handles
    const onResizeDrag = (direction, info) => {
        if (props.onResize) {
            props.onResize(id, direction, { x: info.delta.x, y: info.delta.y });
        }
    };

    const ResizeHandle = ({ dir, className }) => (
        <motion.div 
            drag
            dragMomentum={false}
            dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }} // Don't actually move the handle div
            dragElastic={0}
            onDrag={(e, info) => onResizeDrag(dir, info)}
            className={cn("absolute w-4 h-4 z-50 opacity-0 group-hover:opacity-100 transition-opacity bg-white/10 hover:bg-[hsl(var(--color-intent))]", className)} 
        />
    );

    return (
        <motion.div
            drag={!props.locked} // Disable drag if locked
            dragControls={dragControls}
            dragListener={false}
            dragMomentum={false}
            onDragEnd={handleDragEnd}
            initial={{ x: position?.x || 100, y: position?.y || 100, opacity: 0, scale: 0.9 }}
            animate={{ 
                x: position?.x || 100, 
                y: position?.y || 100, 
                width: props.w || undefined, // Use explicit width if provided
                height: props.h || undefined,
                opacity: 1, 
                scale: 1 
            }}
            className={cn(
                "absolute bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl flex flex-col overflow-hidden shadow-2xl group transition-colors hover:border-[hsl(var(--color-intent))]/30 hover:bg-black/60",
                !props.w && (sizes[size] || sizes.md), // Apply default class sizes only if no explicit dimension
                className
            )}
            style={{ zIndex: 10 }}
            {...props}
        >
            {/* Resize Handles */}
            {!props.locked && (
                <>
                    <ResizeHandle dir="se" className="bottom-0 right-0 cursor-se-resize rounded-tl-lg" />
                    <ResizeHandle dir="e" className="top-1/2 -translate-y-1/2 right-0 h-1/2 w-1 cursor-ew-resize" />
                    <ResizeHandle dir="s" className="bottom-0 left-1/2 -translate-x-1/2 w-1/2 h-1 cursor-ns-resize" />
                </>
            )}
            {/* Header / Controls */}
            <div 
                className="h-8 flex items-center justify-between px-3 border-b border-white/5 opacity-0 group-hover:opacity-100 transition-opacity absolute top-0 left-0 right-0 z-50 bg-black/20 backdrop-blur-sm cursor-grab active:cursor-grabbing"
                onPointerDown={(e) => dragControls.start(e)}
            >
                <div className="flex items-center gap-2">
                    <GripVertical className="w-3 h-3 text-neutral-500" />
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider">{title}</span>
                </div>
                <div className="flex items-center gap-1">
                    {onPin && (
                        <button 
                            onClick={() => onPin(id)} 
                            className={cn(
                                "p-1 rounded transition-colors",
                                props.locked 
                                    ? "bg-[hsl(var(--color-intent))] text-black shadow-[0_0_10px_hsl(var(--color-intent))]" 
                                    : "hover:bg-white/10 text-neutral-400 hover:text-white"
                            )}
                            title={props.locked ? "Unlock Widget" : "Lock Position"}
                        >
                            <Pin className={cn("w-3 h-3", props.locked && "fill-current")} />
                        </button>
                    )}
                    {onToggleSize && (
                        <button onClick={() => onToggleSize(id)} className="p-1 hover:bg-white/10 rounded text-neutral-400 hover:text-white transition-colors">
                            {size === 'lg' ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
                        </button>
                    )}
                    {onClose && (
                        <button onClick={() => onClose(id)} className="p-1 hover:bg-red-500/20 rounded text-neutral-400 hover:text-red-500 transition-colors">
                            <X className="w-3 h-3" />
                        </button>
                    )}
                </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden relative">
                {children}
            </div>
        </motion.div>
    );
}