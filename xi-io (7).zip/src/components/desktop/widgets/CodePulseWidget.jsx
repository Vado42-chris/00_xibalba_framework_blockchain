import React, { useState } from 'react';
import { GitCommit, GitPullRequest, Terminal, Activity, Zap, CheckCircle2, AlertCircle } from 'lucide-react';
import WidgetBase from './WidgetBase';
import { ScrollArea } from "@/components/ui/scroll-area";

export default function CodePulseWidget({ id, size, ...props }) {
    
    // Mock Data
    const commits = [
        { id: 'c1', msg: 'feat: glassmorphism updates', author: 'XI-AL', time: '2m ago', type: 'commit' },
        { id: 'c2', msg: 'fix: z-index layering on dock', author: 'XI-AL', time: '15m ago', type: 'commit' },
        { id: 'c3', msg: 'deploy: seed-001-beta', author: 'SYSTEM', time: '1h ago', type: 'deploy', status: 'success' },
        { id: 'c4', msg: 'refactor: widget base component', author: 'XI-AL', time: '2h ago', type: 'commit' },
        { id: 'c5', msg: 'docs: updated deployment manual', author: 'OBSERVER', time: '3h ago', type: 'doc' },
    ];

    // --- RENDER STATES ---

    // 1. IDLE (Small) - Heartbeat
    const renderSmall = () => (
        <div className="h-full flex flex-col items-center justify-center gap-1 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--color-execution))]/10 to-transparent opacity-50" />
            <div className="text-4xl font-black text-[hsl(var(--color-execution))] tracking-tighter drop-shadow-[0_0_10px_rgba(34,197,94,0.5)]">
                +12
            </div>
            <div className="text-[9px] font-mono text-neutral-400 uppercase tracking-widest">Commits Today</div>
            <Activity className="absolute bottom-2 w-full h-8 text-[hsl(var(--color-execution))]/20 opacity-50" />
        </div>
    );

    // 2. ACTIVE (Medium) - Mini Terminal
    const renderMedium = () => (
        <div className="h-full flex flex-col p-4 font-mono text-xs">
            <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/10">
                <Terminal className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                <span className="text-neutral-400">~/xi-io/core</span>
            </div>
            <div className="flex-1 space-y-2 overflow-hidden">
                {commits.slice(0, 3).map((c, i) => (
                    <div key={c.id} className="flex gap-2 items-start opacity-80 hover:opacity-100 transition-opacity">
                        <span className="text-[hsl(var(--color-execution))] shrink-0 mt-0.5">❯</span>
                        <div className="min-w-0">
                            <span className="text-white truncate block">{c.msg}</span>
                            <span className="text-[9px] text-neutral-500">{c.time} • {c.author}</span>
                        </div>
                    </div>
                ))}
            </div>
            <div className="mt-auto pt-2 flex items-center justify-between text-[9px] text-neutral-500">
                <span className="flex items-center gap-1"><GitPullRequest className="w-2 h-2" /> 2 Open</span>
                <span className="flex items-center gap-1 text-[hsl(var(--color-execution))]"><CheckCircle2 className="w-2 h-2" /> Build Passing</span>
            </div>
        </div>
    );

    // 3. FOCUS (Large) - Full Log & Metrics
    const renderLarge = () => (
        <div className="h-full flex flex-col">
            <div className="p-4 border-b border-white/10 bg-black/20 flex justify-between items-center">
                <div className="flex flex-col">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                        <GitCommit className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                        Project Activity
                    </h3>
                    <span className="text-[10px] text-neutral-500 font-mono">branch: main • v2.4.1</span>
                </div>
                <div className="flex gap-2">
                    <div className="px-2 py-1 rounded bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] text-[10px] font-bold">
                        98% COVERAGE
                    </div>
                </div>
            </div>

            <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                    {commits.map((c) => (
                        <div key={c.id} className="group flex items-start gap-3 p-2 rounded hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
                            <div className={cn(
                                "w-8 h-8 rounded flex items-center justify-center shrink-0 mt-0.5",
                                c.type === 'deploy' ? "bg-purple-500/20 text-purple-400" : "bg-neutral-800 text-neutral-400"
                            )}>
                                {c.type === 'deploy' ? <Zap className="w-4 h-4" /> : <GitCommit className="w-4 h-4" />}
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start">
                                    <span className="text-sm text-neutral-200 font-medium truncate">{c.msg}</span>
                                    <span className="text-[10px] text-neutral-500 whitespace-nowrap ml-2">{c.time}</span>
                                </div>
                                <div className="flex items-center gap-2 mt-1">
                                    <span className="text-[10px] bg-white/10 px-1.5 py-0.5 rounded text-neutral-400">{c.author}</span>
                                    {c.status && (
                                        <span className="text-[10px] flex items-center gap-1 text-[hsl(var(--color-execution))]">
                                            <CheckCircle2 className="w-3 h-3" /> {c.status.toUpperCase()}
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </ScrollArea>
            
            <div className="p-3 border-t border-white/10 bg-neutral-900/50 flex gap-2">
                <input type="text" placeholder="Filter activity..." className="flex-1 bg-black border border-white/10 rounded px-2 py-1 text-xs text-white" />
                <button className="px-3 py-1 bg-[hsl(var(--color-execution))] text-black text-xs font-bold rounded hover:opacity-90">SYNC</button>
            </div>
        </div>
    );

    return (
        <WidgetBase id={id} title="CODE PULSE" size={size} {...props}>
            {size === 'sm' && renderSmall()}
            {size === 'md' && renderMedium()}
            {size === 'lg' && renderLarge()}
        </WidgetBase>
    );
}