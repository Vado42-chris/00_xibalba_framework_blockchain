import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Play, Pause, SkipForward, SkipBack, Disc, Music, Mic2, Sparkles, Volume2, LogIn } from 'lucide-react';
import WidgetBase from './WidgetBase';
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function SpotifyWidget({ id, size, ...props }) {
    const [isConnected, setIsConnected] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTrack, setCurrentTrack] = useState({
        title: "Dreamcatcher (Original Mix)",
        artist: "Timecop1983",
        album: "Night Drive",
        cover: "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=300&auto=format&fit=crop"
    });
    const [aiPrompt, setAiPrompt] = useState("");

    const handleConnect = async () => {
        const toastId = toast.loading("Initiating Handshake...");
        try {
            const { data } = await base44.functions.invoke('spotify', { action: 'get_auth_url' });
            if (data?.url) {
                window.location.href = data.url;
            } else {
                throw new Error("Failed to get auth URL");
            }
        } catch (error) {
            toast.error("Connection Failed", { 
                id: toastId, 
                description: "Please check SPOTIFY_CLIENT_ID secret." 
            });
            console.error(error);
        }
    };

    // Check for existing token on mount
    React.useEffect(() => {
        const token = localStorage.getItem('spotify_access_token');
        const expiresAt = localStorage.getItem('spotify_expires_at');
        
        if (token && expiresAt > Date.now()) {
            setIsConnected(true);
        } else if (localStorage.getItem('spotify_refresh_token')) {
            // Try refresh
            // Implement refresh logic here or in a separate effect
            setIsConnected(true); // Optimistic for now
        }
    }, []);

    const handlePlayPause = () => {
        setIsPlaying(!isPlaying);
        toast.success(isPlaying ? "Music Paused" : "Resuming Playback");
    };

    const handleGenerate = () => {
        if (!aiPrompt) return;
        toast.info("Sound Engine Generating...", {
            description: `Analyzing mood: "${aiPrompt}"`
        });
        setAiPrompt("");
    };

    // --- RENDER STATES ---

    if (!isConnected) {
        return (
            <WidgetBase id={id} title="SOUND ENGINE" size={size} {...props}>
                <div className="h-full flex flex-col items-center justify-center p-6 text-center space-y-4 bg-gradient-to-br from-[#1DB954]/10 to-transparent">
                    <div className="w-16 h-16 rounded-full bg-[#1DB954] flex items-center justify-center shadow-[0_0_30px_#1DB95440] animate-pulse">
                        <Music className="w-8 h-8 text-black" />
                    </div>
                    <div>
                        <h3 className="text-lg font-bold text-white">Sound Engine</h3>
                        <p className="text-xs text-neutral-400 mt-1 max-w-[200px]">
                            Connect to synchronize your environment with adaptive audio.
                        </p>
                    </div>
                    <Button 
                        onClick={handleConnect}
                        className="bg-[#1DB954] hover:bg-[#1ed760] text-black font-bold rounded-full w-full max-w-[140px]"
                    >
                        <LogIn className="w-4 h-4 mr-2" />
                        Connect
                    </Button>
                </div>
            </WidgetBase>
        );
    }

    // 1. IDLE (Small) - Minimalist Player
    const renderSmall = () => (
        <div className="h-full flex items-center p-4 gap-4">
            <div className="relative w-12 h-12 rounded-lg overflow-hidden shrink-0 animate-[spin_10s_linear_infinite]" style={{ animationPlayState: isPlaying ? 'running' : 'paused' }}>
                <img src={currentTrack.cover} alt="Cover" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/20" />
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-3 h-3 bg-black rounded-full" />
                </div>
            </div>
            <div className="flex-1 min-w-0">
                <div className="truncate text-xs font-bold text-white">{currentTrack.title}</div>
                <div className="truncate text-[10px] text-neutral-400">{currentTrack.artist}</div>
            </div>
            <button onClick={handlePlayPause} className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 transition-transform">
                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3 ml-0.5" />}
            </button>
        </div>
    );

    // 2. ACTIVE (Medium) - Standard Player + Visuals
    const renderMedium = () => (
        <div className="h-full flex flex-col p-4 relative overflow-hidden">
            {/* Background Blur */}
            <div className="absolute inset-0 z-0 opacity-30 blur-xl" style={{ backgroundImage: `url(${currentTrack.cover})`, backgroundSize: 'cover' }} />
            
            <div className="relative z-10 flex flex-col h-full justify-between">
                <div className="flex gap-4">
                    <div className="w-20 h-20 rounded-lg shadow-2xl overflow-hidden shrink-0 border border-white/10 group relative">
                        <img src={currentTrack.cover} alt="Cover" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Disc className="w-8 h-8 text-white animate-spin" />
                        </div>
                    </div>
                    <div className="flex flex-col justify-center min-w-0">
                        <div className="text-sm font-bold text-white truncate leading-tight">{currentTrack.title}</div>
                        <div className="text-xs text-neutral-300 truncate">{currentTrack.artist}</div>
                        <div className="text-[10px] text-neutral-500 truncate mt-1">{currentTrack.album}</div>
                    </div>
                </div>

                <div className="space-y-3">
                    {/* Progress Bar */}
                    <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden group cursor-pointer">
                        <div className="h-full bg-green-500 w-1/3 group-hover:bg-green-400 transition-colors" />
                    </div>

                    {/* Controls */}
                    <div className="flex items-center justify-between px-2">
                        <button className="text-neutral-400 hover:text-white transition-colors"><SkipBack className="w-4 h-4" /></button>
                        <button onClick={handlePlayPause} className="w-10 h-10 rounded-full bg-green-500 text-black flex items-center justify-center hover:scale-105 hover:bg-green-400 transition-all shadow-[0_0_15px_rgba(34,197,94,0.4)]">
                            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                        </button>
                        <button className="text-neutral-400 hover:text-white transition-colors"><SkipForward className="w-4 h-4" /></button>
                    </div>
                </div>
            </div>
        </div>
    );

    // 3. FOCUS (Large) - AI Sound Engine
    const renderLarge = () => (
        <div className="h-full flex flex-col relative">
             {/* Player Section (Top) */}
             <div className="h-1/2 p-6 border-b border-white/5 relative overflow-hidden">
                <div className="absolute inset-0 z-0 opacity-20" style={{ backgroundImage: `url(${currentTrack.cover})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
                <div className="relative z-10 flex items-end gap-4 h-full">
                    <div className="w-32 h-32 rounded-xl shadow-2xl overflow-hidden shrink-0 border border-white/10 group cursor-pointer relative">
                        <img src={currentTrack.cover} alt="Cover" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="pb-2">
                        <h3 className="text-xl font-bold text-white mb-1">{currentTrack.title}</h3>
                        <p className="text-sm text-neutral-300 mb-4">{currentTrack.artist}</p>
                        <div className="flex items-center gap-3">
                            <button onClick={handlePlayPause} className="px-4 py-2 bg-green-500 text-black rounded-full font-bold text-xs hover:bg-green-400 transition-colors flex items-center gap-2 shadow-lg hover:shadow-[0_0_20px_rgba(34,197,94,0.4)]">
                                {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                                {isPlaying ? 'PAUSE' : 'PLAY'}
                            </button>
                            <button className="p-2 rounded-full border border-white/10 hover:bg-white/10 transition-colors"><Volume2 className="w-4 h-4 text-neutral-400" /></button>
                        </div>
                    </div>
                </div>
             </div>

             {/* Sound Engine AI (Bottom) */}
             <div className="h-1/2 p-6 bg-black/40 flex flex-col gap-4">
                <div className="flex items-center gap-2 text-xs font-bold text-neutral-400 tracking-widest">
                    <Mic2 className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                    XI-IO SOUND ENGINE
                </div>
                
                <div className="flex-1 space-y-2 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-white/10">
                    <p className="text-xs text-neutral-500">Generate a focus mix based on your current task.</p>
                    <div className="grid grid-cols-2 gap-2">
                        {['Deep Focus Coding', 'High Energy Deploy', 'Cyberpunk Ambient', 'Late Night Debug'].map(preset => (
                            <button key={preset} onClick={() => toast.success(`Generated: ${preset}`)} className="text-[10px] text-left p-2 rounded bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/20 transition-all text-neutral-300">
                                {preset}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={aiPrompt}
                        onChange={(e) => setAiPrompt(e.target.value)}
                        placeholder="e.g. 'Chill beats for writing documentation'..." 
                        className="flex-1 bg-black/50 border border-white/10 rounded px-3 text-xs text-white focus:outline-none focus:border-[hsl(var(--color-intent))] placeholder:text-neutral-600"
                    />
                    <Button size="sm" onClick={handleGenerate} className="h-8 bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/80 text-black text-xs font-bold">
                        GENERATE
                    </Button>
                </div>
             </div>
        </div>
    );

    return (
        <WidgetBase id={id} title="SOUND ENGINE" size={size} {...props}>
            {size === 'sm' && renderSmall()}
            {size === 'md' && renderMedium()}
            {size === 'lg' && renderLarge()}
        </WidgetBase>
    );
}