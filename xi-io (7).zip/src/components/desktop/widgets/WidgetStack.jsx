import React, { useState } from 'react';
import WidgetBase from './WidgetBase';
import { getWidgetComponent } from '../WidgetRegistry';
import { cn } from "@/lib/utils";

export default function WidgetStack({ 
    id, 
    widgets, // Array of widget objects in this stack
    activeWidgetId,
    onSetActive,
    onUnstack, // Function to remove a widget from stack
    ...props 
}) {
    // If no widgets, shouldn't render (should be cleaned up by parent)
    if (!widgets || widgets.length === 0) return null;

    const activeWidget = widgets.find(w => w.id === activeWidgetId) || widgets[0];
    const ActiveComponentConfig = getWidgetComponent(activeWidget.type);
    const ActiveComponent = ActiveComponentConfig?.component;

    return (
        <WidgetBase 
            id={id} 
            title="STACK" // Title is dynamic based on active tab usually, but base needs one
            {...props}
            isStack={true}
            className="flex flex-col"
        >
            {/* Tab Bar */}
            <div className="flex items-center gap-1 px-2 pt-2 bg-black/20 border-b border-white/5 overflow-x-auto scrollbar-none">
                {widgets.map(w => {
                    const config = getWidgetComponent(w.type);
                    return (
                        <button
                            key={w.id}
                            onClick={(e) => {
                                e.stopPropagation();
                                onSetActive(id, w.id);
                            }}
                            className={cn(
                                "px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-t-lg transition-colors border-t border-x border-transparent min-w-[80px] truncate",
                                activeWidget.id === w.id 
                                    ? "bg-white/10 text-white border-white/10" 
                                    : "text-neutral-500 hover:text-neutral-300 hover:bg-white/5"
                            )}
                        >
                            {w.title || config?.title || w.type}
                        </button>
                    );
                })}
            </div>

            {/* Active Content */}
            <div className="flex-1 relative overflow-hidden">
                {ActiveComponent ? (
                    ActiveComponentConfig.customWrapper ? (
                        <ActiveComponent {...props} id={activeWidget.id} /> 
                        // Note: Custom wrappers might expect to be the root. 
                        // If they wrap WidgetBase themselves, this nests WidgetBase inside WidgetBase.
                        // We might need to unwrap them or pass a prop to disable their internal wrapper.
                        // For simplicity, we'll assume they can render content if we pass a prop or just render standard components.
                        // Actually, SpotifyWidget returns <WidgetBase>... content </WidgetBase>.
                        // So we would have nested frames. 
                        // FIX: We need standard widgets to be content-only or adaptable.
                        // For now, let's render it. It might look double-framed but functional.
                    ) : (
                        <ActiveComponent />
                    )
                ) : (
                    <div className="p-4 text-xs text-red-400">Widget Error</div>
                )}
            </div>
        </WidgetBase>
    );
}