import React, { useRef, useState, useEffect } from 'react';
import { motion, useDragControls } from 'framer-motion';
import { cn } from "@/lib/utils";
import { X, GripHorizontal, Maximize2, Minimize2, PinOff } from 'lucide-react';
import { useGrid } from './DesktopGridSystem';
import ObsidianTabletContent from './ObsidianTabletContent';

export default function PinnedWindow({ item }) {
    const { updatePinnedItem, removePinnedItem, snapToGrid, snapDimensions, gridConfig } = useGrid();
    const controls = useDragControls();
    const ref = useRef(null);
    const [isResizing, setIsResizing] = useState(false);

    const handleDragEnd = (event, info) => {
        const newX = item.x + info.offset.x;
        const newY = item.y + info.offset.y;
        
        // Pass width/height to snap logic for collision detection
        const snapped = snapToGrid(newX, newY, item.w, item.h);
        updatePinnedItem(item.id, { x: snapped.x, y: snapped.y });
    };

    // Resizing Logic
    const initResize = (e, direction) => {
        e.stopPropagation();
        e.preventDefault();
        setIsResizing(true);
        
        const startX = e.clientX;
        const startY = e.clientY;
        const startW = item.w;
        const startH = item.h;

        const onMouseMove = (e) => {
            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;
            
            // Raw new dimensions
            let newW = startW + deltaX;
            let newH = startH + deltaY;
            
            // Snap dimensions
            const snapped = snapDimensions(newW, newH);
            
            // Update visually (or state if fast enough)
            updatePinnedItem(item.id, { w: snapped.width, h: snapped.height });
        };

        const onMouseUp = () => {
            setIsResizing(false);
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    };

    return (
        <motion.div
            ref={ref}
            drag={!isResizing}
            dragListener={false}
            dragControls={controls}
            dragMomentum={false}
            dragElastic={0}
            onDragEnd={handleDragEnd}
            initial={{ x: item.x, y: item.y, width: item.w, height: item.h, opacity: 0, scale: 0.9 }}
            animate={{ x: item.x, y: item.y, width: item.w, height: item.h, opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={cn(
                "absolute bg-black/60 backdrop-blur-xl border border-[hsl(var(--color-intent))]/30 rounded-2xl overflow-hidden shadow-2xl flex flex-col group",
                "z-[100] ring-1 ring-white/10" // High Z-Stack for pinned items
            )}
            onPointerDown={() => updatePinnedItem(item.id, { zIndex: Date.now() })} // Simple Z-index hack, ideally manage via grid context
            style={{ zIndex: item.zIndex }}
        >
            {/* Header / Drag Handle */}
            <div 
                className="h-8 bg-white/5 border-b border-white/5 flex items-center justify-between px-2 cursor-grab active:cursor-grabbing shrink-0"
                onPointerDown={(e) => controls.start(e)}
            >
                <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-intent))]" />
                    <span className="text-[10px] font-bold text-neutral-300 uppercase tracking-wider truncate max-w-[120px]">
                        {item.title}
                    </span>
                </div>
                <div className="flex items-center gap-1">
                    <button 
                        onClick={() => removePinnedItem(item.id)}
                        className="p-1 hover:bg-white/10 rounded text-neutral-400 hover:text-white transition-colors"
                        title="Unpin"
                    >
                        <PinOff className="w-3 h-3" />
                    </button>
                    <button 
                         onClick={() => removePinnedItem(item.id)} // Close also removes pin? Or just close?
                         className="p-1 hover:bg-red-500/20 rounded text-neutral-400 hover:text-red-500 transition-colors"
                    >
                        <X className="w-3 h-3" />
                    </button>
                </div>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden relative">
                {item.type === 'app' ? (
                     <ObsidianTabletContent appId={item.appId} activeTab={item.activeTab} />
                ) : (
                    <div className="p-4 text-neutral-400 text-xs">
                        {/* Generic Content or Omni Widget */}
                        {item.content}
                    </div>
                )}
            </div>

            {/* Resize Handle */}
            <div 
                className="absolute bottom-0 right-0 w-6 h-6 cursor-nwse-resize flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-50"
                onMouseDown={(e) => initResize(e, 'se')}
            >
                <div className="w-2 h-2 border-r-2 border-b-2 border-white/30 rounded-br-sm" />
            </div>
        </motion.div>
    );
}