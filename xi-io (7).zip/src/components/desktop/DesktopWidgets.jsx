import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Activity, Cpu, Shield, Zap } from 'lucide-react';
import { cn } from "@/lib/utils";

// --- WIDGET COMPONENTS ---

export const HoloClock = () => {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const t = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(t);
    }, []);

    const hours = time.getHours().toString().padStart(2, '0');
    const minutes = time.getMinutes().toString().padStart(2, '0');
    const seconds = time.getSeconds().toString().padStart(2, '0');

    return (
        <div className="group cursor-default select-none h-full flex flex-col justify-center items-center">
            <div className="flex items-baseline gap-2 font-black tracking-tighter text-5xl md:text-7xl text-transparent bg-clip-text bg-gradient-to-b from-white to-white/50 drop-shadow-2xl">
                <span>{hours}</span>
                <span className="animate-pulse">:</span>
                <span>{minutes}</span>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono text-neutral-400 mt-2 pl-2 border-l-2 border-[hsl(var(--color-intent))]">
                <span>{seconds}s</span>
                <span>•</span>
                <span className="uppercase tracking-widest">{time.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</span>
            </div>
        </div>
    );
};

export const NodeMonitor = () => {
    const [blocks, setBlocks] = useState([
        { id: 1, status: 'validated' },
        { id: 2, status: 'validated' },
        { id: 3, status: 'mining' },
    ]);

    useEffect(() => {
        const t = setInterval(() => {
            setBlocks(prev => {
                const next = [...prev];
                next.shift();
                next.push({ id: Date.now(), status: Math.random() > 0.5 ? 'validated' : 'mining' });
                return next;
            });
        }, 3000);
        return () => clearInterval(t);
    }, []);

    return (
        <div className="p-4 w-full h-full flex flex-col">
            <div className="flex items-center justify-between mb-3 shrink-0">
                <div className="flex items-center gap-2 text-xs font-bold text-neutral-400">
                    <Activity className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                    NODE STATUS
                </div>
                <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-execution))]" />
                    <span className="text-[10px] text-[hsl(var(--color-execution))]">SYNCED</span>
                </div>
            </div>
            
            <div className="flex-1 flex gap-2 justify-end items-center">
                {blocks.map((b, i) => (
                    <motion.div
                        key={b.id}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className={cn(
                            "w-8 h-12 rounded-sm border flex items-center justify-center relative overflow-hidden",
                            b.status === 'validated' 
                                ? "bg-[hsl(var(--color-execution))]/10 border-[hsl(var(--color-execution))]/30" 
                                : "bg-white/5 border-white/10"
                        )}
                    >
                        <div className={cn("w-1.5 h-1.5 rounded-full", b.status === 'validated' ? "bg-[hsl(var(--color-execution))]" : "bg-white/50 animate-pulse")} />
                        {b.status === 'mining' && <div className="absolute inset-0 bg-white/10 animate-pulse" />}
                    </motion.div>
                ))}
            </div>
            <div className="mt-3 flex justify-between text-[10px] font-mono text-neutral-500 shrink-0">
                <span>Height: 14,204,991</span>
                <span>24ms</span>
            </div>
        </div>
    );
};

export const AgentSwarm = () => {
    return (
        <div className="p-4 w-full h-full flex flex-col">
            <div className="flex items-center justify-between mb-3 shrink-0">
                <div className="flex items-center gap-2 text-xs font-bold text-neutral-400">
                    <Cpu className="w-3 h-3 text-purple-400" />
                    AGENT SWARM
                </div>
                <span className="text-[10px] text-neutral-500">3 ACTIVE</span>
            </div>
            
            <div className="flex-1 space-y-2 overflow-y-auto scrollbar-none">
                {['Security Sentinel', 'Market Observer', 'Code Auditor'].map((agent, i) => (
                    <div key={i} className="flex items-center gap-3 text-xs text-neutral-300 p-2 rounded hover:bg-white/5 transition-colors cursor-pointer group">
                        <div className="relative">
                            <div className="w-2 h-2 rounded-full bg-purple-500" />
                            <div className="absolute inset-0 rounded-full bg-purple-500 animate-ping opacity-50" style={{ animationDelay: `${i * 0.5}s` }} />
                        </div>
                        <span className="opacity-80 group-hover:opacity-100">{agent}</span>
                        <span className="ml-auto text-[10px] opacity-50 font-mono group-hover:text-purple-300">IDLE</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export const SystemStatus = () => {
    return (
        <div className="p-4 w-full h-full flex flex-col justify-center">
             <div className="flex items-center gap-2 text-[hsl(var(--color-intent))] mb-2">
                <Shield className="w-4 h-4" />
                <span className="text-xs font-bold tracking-widest">SYSTEM SECURE</span>
            </div>
            <p className="text-xs text-neutral-500 leading-relaxed font-mono">
                Encryption Layer: Double-Ratchet<br/>
                Identity: Verified (Sovereign)<br/>
                Session: Active
            </p>
            <div className="mt-2 flex gap-1">
                 <div className="h-1 w-full bg-neutral-800 rounded-full overflow-hidden">
                     <div className="h-full bg-[hsl(var(--color-intent))] w-[80%] animate-pulse" />
                 </div>
            </div>
        </div>
    );
};