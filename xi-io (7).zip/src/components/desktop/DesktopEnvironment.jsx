import React, { useState, useEffect } from 'react';
// Force rebuild
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import InfinityDock from './InfinityDock';
import AtmosphereLayer from './AtmosphereLayer';
import WidgetLayer from './WidgetLayer';
import DesktopIconGrid from './DesktopIconGrid';
import StartMenu from './StartMenu';
import WindowFrame from './WindowFrame';
import ObsidianTabletContent from './ObsidianTabletContent';
import PinnedWindow from './PinnedWindow';
import DesktopCenterpiece from './DesktopCenterpiece';
import { SystemCursor } from "@/components/ui/SystemCursor";
import { GridProvider, useGrid } from './DesktopGridSystem';
import { 
    Globe, Target, Layout, Coffee, Terminal, 
    Search, BarChart3, User, MessageSquare, Truck, Wallet, HardDrive, Shield,
    Building2, CircuitBoard, Plug, ShoppingBag,
    Disc, Palette, LayoutTemplate, Wand2, Cpu, Users, Activity,
    Ghost, Fingerprint, Settings, Server, Download, FileText, Layers, Plus, Box,
    FileSpreadsheet, FileIcon, Smartphone
} from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { ContextMenu, ContextMenuContent, ContextMenuItem, ContextMenuTrigger, ContextMenuSeparator, ContextMenuSub, ContextMenuSubTrigger, ContextMenuSubContent } from "@/components/ui/context-menu";
import { FolderPlus, FilePlus, RefreshCw, Monitor, Grid as GridIcon, X, Trash2 } from 'lucide-react';
import DesktopFolderExpanded from './DesktopFolderExpanded';
import ProductIcon, { PRODUCT_CONFIG } from '@/components/brand/ProductIcon';
import { useSiteContext } from '@/components/identity/SiteContext';
import { cn } from "@/lib/utils";
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { CommandBar } from '../ui/CommandBar';
import { DeveloperWorkbench } from '../workbenches/DeveloperWorkbench';
import { CEOExecutiveDashboard } from '../workbenches/CEOExecutiveDashboard';
import { ProjectManagerWorkbench } from '../workbenches/ProjectManagerWorkbench';
import { theme } from '../ui/design-system/design-tokens';

export default function DesktopEnvironment(props) {
    return (
        <DesktopContent {...props} />
    );
}

function DesktopContent({ onSearch }) {
    const { 
        pinnedItems, addPinnedItem, gridConfig, dimensions, snapToGrid, setDimensions,
        widgets, handleWidgetMove, handleWidgetResize, handleToggleWidgetSize,
        handleWidgetClose, handleStackAction, handleWidgetLock
    } = useGrid();
    
    // Container Ref for Resize Observer
    const containerRef = React.useRef(null);
    
    useEffect(() => {
        if (!containerRef.current) return;
        
        const observer = new ResizeObserver(entries => {
            for (const entry of entries) {
                const { width, height } = entry.contentRect;
                // Only update if significantly changed to avoid thrashing
                if (Math.abs(width - dimensions.width) > 10 || Math.abs(height - dimensions.height) > 10) {
                     setDimensions({ width, height });
                }
            }
        });
        
        observer.observe(containerRef.current);
        return () => observer.disconnect();
    }, [setDimensions, dimensions.width, dimensions.height]);
    
    // Fetch Installed Addons (Widgets & Custom Apps)
    const { data: installedWidgets = [] } = useQuery({
        queryKey: ['desktop_widgets'],
        queryFn: async () => {
            const installed = await base44.entities.InstalledAddon.list();
            const items = await base44.entities.MarketplaceItem.list();
            
            // Standard Marketplace Items
            const marketItems = items.filter(item => 
                installed.some(inst => inst.addon_id === item.id) && 
                item.category === 'module'
            );

            // "User Created" Apps (Simulated from DeploymentModal)
            // We look for installed addons that DON'T match a known marketplace item ID
            const customApps = installed
                .filter(inst => !items.find(i => i.id === inst.addon_id))
                .map(inst => ({
                    id: inst.addon_id,
                    name: inst.config?.name || 'Custom App',
                    description: `v${inst.config?.version || '1.0'}`,
                    category: 'app',
                    manifest: {
                        code: `<iframe src="${inst.config?.url || '#'}" class="w-full h-full border-none" />`
                    }
                }));

            return [...marketItems, ...customApps];
        },
        initialData: []
    });
    
    const { domainData } = useSiteContext();
    const [windows, setWindows] = useState([]);
    const [activeWindowId, setActiveWindowId] = useState(null);
    const [windowOrder, setWindowOrder] = useState([]);
    const [expandedFolder, setExpandedFolder] = useState(null); // ID of the folder currently open
    const [userRole, setUserRole] = useState('normal'); // 'normal', 'developer', 'ceo', 'pm'
    const [globalCommandOpen, setGlobalCommandOpen] = useState(false);
    const [wallpaperMode, setWallpaperMode] = useState('nebula'); // 'nebula', 'grid', 'void'

    // Global keyboard shortcut for CommandBar
    useEffect(() => {
        const handleKeyDown = (e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
                e.preventDefault();
                setGlobalCommandOpen(prev => !prev);
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, []);

    const bringToFront = (id) => {
        setWindowOrder(prev => {
            const without = prev.filter(wId => wId !== id);
            return [...without, id];
        });
        setActiveWindowId(id);
    };
    const [isStartOpen, setIsStartOpen] = useState(false);

    // PRODUCT APPS (From Studio)
    const productApps = Object.entries(PRODUCT_CONFIG).map(([key, config]) => ({
        id: key,
        name: config.name,
        description: 'Studio Application',
        icon: (props) => <ProductIcon id={key} size="xs" {...props} />, // Use ProductIcon component
        theme: config.gradient.split(' ')[0].replace('from-', ''), 
        type: 'app',
        tabs: [{ id: 'main', label: 'Main', icon: Layout }]
    }));

    // Pinned Apps (Default Dock Items)
    const [pinnedDockIds, setPinnedDockIds] = useState([
        'EmpireSuite', 'StrategySuite', 'OperationsHub', 'LifeSuite', 'ControlSuite',
        'architect', 'web', 'chat' 
    ]);

    // INITIAL APP CONFIG
    const systemApps = [
        { 
            id: 'RecycleBin',
            name: 'Recycle Bin',
            description: 'Trash and deleted items',
            icon: Trash2, // Use component directly for WindowFrame compatibility
            theme: 'zinc-500',
            type: 'system',
            tabs: [{ id: 'bin', label: 'Trash', icon: Trash2 }]
        },
        { 
            id: 'FileManager', 
            name: 'File System', 
            description: 'Browse, manage, and organize your files.',
            icon: FileText, 
            theme: 'yellow-500',
            tabs: [{ id: 'files', label: 'Files', icon: FolderPlus }]
        },
        {
            id: 'Terminal',
            name: 'Terminal',
            description: 'Command Line Interface',
            icon: Terminal,
            theme: 'slate-900',
            type: 'app',
            tabs: [{ id: 'main', label: 'Terminal', icon: Terminal }]
        },
        {
            id: 'SystemMonitor',
            name: 'System Monitor',
            description: 'View system resources and performance',
            icon: Activity,
            theme: 'emerald-600',
            type: 'app',
            tabs: [{ id: 'main', label: 'Monitor', icon: Activity }]
        },
        {
            id: 'Settings',
            name: 'Control Panel',
            description: 'System Configuration',
            icon: Settings,
            theme: 'neutral-600',
            type: 'app',
            tabs: [{ id: 'main', label: 'Settings', icon: Settings }]
        },
        { 
            id: 'EmpireSuite', 
            name: 'Empire OS', 
            description: 'Global command center. Intelligence, CRM, and Finance.',
            icon: Globe, 
            theme: 'indigo-500',
            tabs: [
                { id: 'Gateway', icon: Globe, label: 'Gateway' },
                { id: 'SearchResults', icon: Search, label: 'Search' },
                { id: 'Dashboard', icon: Layout, label: 'Overview' },
                { id: 'Intelligence', icon: BarChart3, label: 'Intelligence' },
                { id: 'CRM', icon: User, label: 'CRM' },
                { id: 'Communications', icon: MessageSquare, label: 'Comms' },
                { id: 'Commerce', icon: Truck, label: 'Commerce' },
                { id: 'Finance', icon: Wallet, label: 'Finance' },
                { id: 'Archives', icon: HardDrive, label: 'Archives' },
                { id: 'Legal', icon: Shield, label: 'Legal' },
            ]
        },
        { 
            id: 'StrategySuite', 
            name: 'Strategy Deck', 
            description: 'Business planning, enterprise architecture, and integrations.',
            icon: Target, 
            theme: 'blue-600',
            tabs: [
                { id: 'BusinessPlan', icon: Target, label: 'Business Plan' },
                { id: 'Enterprise', icon: Building2, label: 'Enterprise' },
                { id: 'Automation', icon: CircuitBoard, label: 'Automation' },
                { id: 'Integrations', icon: Plug, label: 'Integrations' },
                { id: 'Marketplace', icon: ShoppingBag, label: 'Marketplace' },
            ]
        },
        { 
            id: 'OperationsHub', 
            name: 'Operations Hub', 
            description: 'Project management, studio tools, and network operations.',
            icon: Layout, 
            theme: 'rose-500',
            tabs: [
                { id: 'WorkRoom', icon: Layout, label: 'Work Room' },
                { id: 'DistroBuilder', icon: Disc, label: 'Distro Builder' },
                { id: 'Studio', icon: Palette, label: 'Studio' },
                { id: 'ContentManager', icon: LayoutTemplate, label: 'Content' },
                { id: 'ComponentForge', icon: Wand2, label: 'Forge' },
                { id: 'Agents', icon: Cpu, label: 'Agents' },
                { id: 'Community', icon: Users, label: 'Community' },
                { id: 'Network', icon: Globe, label: 'Network' },
                { id: 'Nodes', icon: Activity, label: 'Nodes' },
            ]
        },
        { 
            id: 'LifeSuite', 
            name: 'Life OS', 
            description: 'Personal management, lifestyle, and wellbeing.',
            icon: Coffee, 
            theme: 'lime-500',
            tabs: [
                { id: 'Lifestyle', icon: Coffee, label: 'Lifestyle' },
            ]
        },
        { 
            id: 'ControlSuite', 
            name: 'System Control', 
            description: 'Admin console, security audit, and system configuration.',
            icon: Terminal, 
            theme: 'neutral-600',
            tabs: [
                { id: 'Console', icon: Terminal, label: 'Console' },
                { id: 'ReaperSpace', icon: Ghost, label: 'Reaper' },
                { id: 'Identity', icon: Fingerprint, label: 'Identity' },
                { id: 'Settings', icon: Settings, label: 'Config' },
                { id: 'Audit', icon: Shield, label: 'Audit' },
                { id: 'ServerControl', icon: Server, label: 'Servers' },
                { id: 'Installer', icon: Download, label: 'Installer' },
                { id: 'Docs', icon: FileText, label: 'Manual' },
            ]
        }
    ];

    // Merge System Apps with Installed "App" Modules
    // We treat installed modules as "Tools" unless specified otherwise
    const allApps = [
        ...productApps,
        ...systemApps,
        ...installedWidgets.map(widget => ({
            id: widget.id,
            name: widget.name,
            description: widget.description || 'Custom installed module',
            icon: widget.category === 'app' ? Globe : Box, // Icon diff for apps vs widgets
            theme: widget.category === 'app' ? 'blue-500' : 'emerald-500', 
            type: widget.category === 'app' ? 'app' : 'custom',
            tabs: widget.manifest?.tabs || [{ id: 'main', label: 'Main', icon: widget.category === 'app' ? Globe : Box }],
            manifest: widget.manifest 
        }))
    ];

    // Load/Save Desktop Apps with Positions
    const [desktopItems, setDesktopItems] = useState(() => {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem('xi_desktop_icons');
            if (saved) {
                try {
                    const parsed = JSON.parse(saved);
                    // Merge saved positions with current apps definition
                    // We map over allApps to ensure new system apps or installed apps appear
                    return allApps.map(app => {
                        const savedApp = parsed.find(p => p.id === app.id);
                        return savedApp ? { ...app, position: savedApp.position, name: savedApp.name || app.name } : app;
                    });
                } catch (e) { console.error("Failed to load icons", e); }
            }
        }
        return allApps;
    });

    const handleRename = (id, newName) => {
        setDesktopItems(prev => prev.map(item => 
            item.id === id ? { ...item, name: newName } : item
        ));
    };

    // Keep desktopItems in sync when installedWidgets changes
    useEffect(() => {
        setDesktopItems(prev => {
            const existingIds = new Set(prev.map(p => p.id));
            const newApps = allApps.filter(a => !existingIds.has(a.id));
            if (newApps.length === 0) return prev;
            return [...prev, ...newApps];
        });
    }, [installedWidgets.length]);

    useEffect(() => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('xi_desktop_icons', JSON.stringify(desktopItems.map(i => ({ id: i.id, position: i.position }))));
        }
    }, [desktopItems]);

    // Sort Desktop Items
    const sortDesktopItems = (criteria) => {
        if (criteria === 'type' || criteria === 'color' || criteria === 'name') {
        const u = gridConfig.cellSize + gridConfig.gap;
        const cols = Math.floor((dimensions.width - 100) / u);

        let sorted = [...desktopItems];

        if (criteria === 'type') {
            const products = desktopItems.filter(i => i.type === 'app' || !i.type).sort((a,b) => a.name.localeCompare(b.name));
            const files = desktopItems.filter(i => i.type === 'file' || i.type === 'folder').sort((a,b) => a.name.localeCompare(b.name));
            const system = desktopItems.filter(i => i.type === 'system').sort((a,b) => a.name.localeCompare(b.name));
            sorted = [...system, ...products, ...files];
        } else if (criteria === 'color') {
            sorted.sort((a, b) => getColorHue(a.theme) - getColorHue(b.theme));
        } else if (criteria === 'name') {
            sorted.sort((a, b) => a.name.localeCompare(b.name));
        }

        let currentIdx = 0;
        const newItems = sorted.map(item => {
                 // Standard grid flow: Left-to-Right, Top-to-Bottom
                 // Skip center forbidden zone
                 let x, y;
                 let found = false;
                 
                 while (!found) {
                     const c = currentIdx % cols;
                     const r = Math.floor(currentIdx / cols);
                     
                     // Avoid colliding with center
                     const tx = 64 + (c * u); // Left margin
                     const ty = 64 + (r * u); // Top margin
                     
                     // Check Center Forbidden
                     const centerX = dimensions.width / 2;
                     const centerY = dimensions.height / 2;
                     if (
                         tx > centerX - 300 && tx < centerX + 300 &&
                         ty > centerY - 150 && ty < centerY + 150
                     ) {
                         currentIdx++;
                         continue;
                     }
                     
                     // Check Dock Forbidden
                     if (ty > dimensions.height - 180) {
                          // Break or wrap? If screen full, stack?
                          // For now, allow but it might clip.
                          // Ideally we should scroll or error.
                     }

                     x = tx; 
                     y = ty;
                     found = true;
                     currentIdx++;
                 }
                 
                 return { ...item, position: { x, y } };
            });
            
            setDesktopItems(newItems);
            toast.success("Desktop Sorted by Type");
        }
    };

    // Helper for color sorting
    const getColorHue = (theme = '') => {
        const colorMap = {
            red: 0, orange: 30, amber: 45, yellow: 60, lime: 75,
            green: 120, emerald: 150, teal: 160, cyan: 180, sky: 200,
            blue: 240, indigo: 260, violet: 270, purple: 280, fuchsia: 300,
            pink: 330, rose: 345, slate: 900, gray: 900, zinc: 900, neutral: 900, stone: 900
        };
        const color = theme.split('-')[0];
        return colorMap[color] || 999;
    };

    // Optimized Layout Calculation & Rainbow Init
    useEffect(() => {
        if (dimensions.width > 0) {
            const u = gridConfig.cellSize + gridConfig.gap;
            
            // Check for unpositioned items
            const unpositioned = desktopItems.filter(i => !i.position);
            
            if (unpositioned.length > 0) {
                // Rainbow Layout for Initial Launch
                const sortedUnpositioned = [...unpositioned].sort((a, b) => getColorHue(a.theme) - getColorHue(b.theme));
                
                // Position Bottom Center - Just above Dock
                const rowY = dimensions.height - 200; 
                const totalRowWidth = sortedUnpositioned.length * u;
                let startX = (dimensions.width / 2) - (totalRowWidth / 2);
                
                const newItems = desktopItems.map(item => {
                    if (item.position) {
                        // Resnap existing
                        return { ...item, position: snapToGrid(item.position.x, item.position.y, gridConfig.cellSize, gridConfig.cellSize) };
                    }
                    
                    // Assign Rainbow Position
                    const pos = { x: startX, y: rowY };
                    startX += u;
                    return { ...item, position: snapToGrid(pos.x, pos.y, gridConfig.cellSize, gridConfig.cellSize) };
                });
                
                setDesktopItems(newItems);
            } else {
                // Just Resnap All (e.g. resize event)
                const resnapped = desktopItems.map(item => ({
                     ...item,
                     position: item.position ? snapToGrid(item.position.x, item.position.y, gridConfig.cellSize, gridConfig.cellSize) : undefined
                }));
                
                if (JSON.stringify(resnapped) !== JSON.stringify(desktopItems)) {
                     setDesktopItems(resnapped);
                }
            }
        }
    }, [dimensions.width, dimensions.height, gridConfig.cellSize, desktopItems.length]); // Added desktopItems.length to dependencies

    const handleIconMove = (id, x, y) => {
        setDesktopItems(prev => {
            const movedItem = prev.find(i => i.id === id);
            if (!movedItem) return prev;

            // Grouping Collision Threshold
            const HIT_THRESHOLD = gridConfig.cellSize * 0.5; 
            
            const targetItem = prev.find(item => 
                item.id !== id && 
                item.position && 
                Math.abs(item.position.x - x) < HIT_THRESHOLD && 
                Math.abs(item.position.y - y) < HIT_THRESHOLD
            );

            if (targetItem) {
                // Create Group Logic
                if (targetItem.type === 'folder') {
                    // Add to existing folder
                    const newContents = [...(targetItem.contents || []), movedItem];
                    return prev
                        .filter(i => i.id !== id)
                        .map(i => i.id === targetItem.id ? { ...i, contents: newContents } : i);
                } else {
                    // Create new folder with both items
                    const newFolder = {
                        id: `group-${Date.now()}`,
                        name: 'App Group',
                        type: 'folder',
                        icon: 'Folder', // Using string ref, rendered by DesktopIconGrid
                        position: targetItem.position,
                        contents: [targetItem, movedItem],
                        theme: 'neutral-500'
                    };
                    return [
                        ...prev.filter(i => i.id !== id && i.id !== targetItem.id),
                        newFolder
                    ];
                }
            }

            return prev.map(item => 
                item.id === id ? { ...item, position: { x, y } } : item
            );
        });
    };

    const createDesktopItem = (type, name) => {
        const { width, height } = dimensions;
        const u = gridConfig.cellSize + gridConfig.gap;
        const cols = Math.floor(width / u);

        // Find first free slot similar to layout logic
        let x = 48;
        let y = 48;
        let idx = 0;
        
        const isOccupied = (tx, ty) => desktopItems.some(i => 
            i.position && Math.abs(i.position.x - tx) < 10 && Math.abs(i.position.y - ty) < 10
        );

        while (isOccupied(x, y)) {
            idx++;
            const c = idx % cols;
            const r = Math.floor(idx / cols);
            x = 48 + (c * u);
            y = 48 + (r * u);
        }

        const newItem = {
            id: `${type}-${Date.now()}`,
            name: name || (type === 'folder' ? 'New Folder' : 'New File'),
            type: type,
            icon: type === 'folder' ? 'Folder' : 'FileText', // String ref for now, handled in Grid
            theme: 'neutral-500',
            position: { x, y },
            description: type === 'folder' ? 'File Folder' : 'Text Document'
        };

        setDesktopItems(prev => [...prev, newItem]);
        if (typeof window !== 'undefined') {
            localStorage.setItem('xi_desktop_icons', JSON.stringify([...desktopItems, newItem].map(i => ({ id: i.id, position: i.position }))));
        }
    };

    const deleteDesktopItem = (id) => {
        setDesktopItems(prev => prev.filter(i => i.id !== id));
    };

    // Ensure pinned items also respect grid changes
    useEffect(() => {
        // Optional: Re-snap pinned items if grid config changes?
        // For now, we trust the user or drag events.
    }, [gridConfig]);

    // WIDGET STATE MANAGED IN CONTEXT

    const launchApp = (app) => {
        setIsStartOpen(false);

        // If stack
        if (app.type === 'stack') {
            toast.success("Stack " + app.name + " Active");
            return; 
        }
        
        // Check if already open
        const existing = windows.find(w => w.appId === app.id);
        if (existing) {
            bringToFront(existing.id);
            if (existing.minimized) {
                toggleMinimize(existing.id);
            }
            return;
        }

        const newWindow = {
            id: Date.now(),
            appId: app.id,
            title: app.name,
            icon: app.icon,
            theme: app.theme,
            tabs: app.tabs,
            activeTab: app.tabs[0].id, // Default to first tab
            position: { x: 100 + (windows.length * 40), y: 80 + (windows.length * 40) },
            minimized: false
        };

        setWindows([...windows, newWindow]);
        setWindowOrder(prev => [...prev, newWindow.id]);
        setActiveWindowId(newWindow.id);
    };

    const closeWindow = (id) => {
        setWindows(windows.filter(w => w.id !== id));
        setWindowOrder(prev => prev.filter(wId => wId !== id));
        if (activeWindowId === id) {
            const remaining = windowOrder.filter(wId => wId !== id);
            setActiveWindowId(remaining[remaining.length - 1] || null);
        }
    };

    const toggleMinimize = (id) => {
        setWindows(windows.map(w => 
            w.id === id ? { ...w, minimized: !w.minimized } : w
        ));
    };

    const focusWindow = (id) => {
        bringToFront(id);
        const win = windows.find(w => w.id === id);
        if (win?.minimized) {
            toggleMinimize(id);
        }
    };

    const handleTabChange = (windowId, tabId) => {
        setWindows(windows.map(w => 
            w.id === windowId ? { ...w, activeTab: tabId } : w
        ));
    };

    return (
        <ContextMenu>
            <ContextMenuTrigger ref={containerRef} className="absolute inset-0 z-0 overflow-hidden block">
                <SystemCursor />

                {/* 1. CENTERPIECE (The Heart) */}
                <DesktopCenterpiece onSearch={onSearch} />
            </ContextMenuTrigger>
            
            <ContextMenuContent className="w-64 bg-black/80 backdrop-blur-xl border-white/10 text-neutral-200">
                <ContextMenuItem inset onSelect={() => createDesktopItem('folder', 'New Folder')}>
                    <FolderPlus className="w-4 h-4 mr-2" /> New Folder
                </ContextMenuItem>
                <ContextMenuItem inset onSelect={() => createDesktopItem('file', 'Text Document')}>
                    <FilePlus className="w-4 h-4 mr-2" /> New Text Document
                </ContextMenuItem>
                <ContextMenuSeparator className="bg-white/10" />
                <ContextMenuSub>
                    <ContextMenuSubTrigger inset>Sort by</ContextMenuSubTrigger>
                    <ContextMenuSubContent className="bg-black/90 border-white/10 text-neutral-200">
                        <ContextMenuItem onSelect={() => sortDesktopItems('name')}>Name</ContextMenuItem>
                        <ContextMenuItem onSelect={() => sortDesktopItems('type')}>Type</ContextMenuItem>
                        <ContextMenuItem onSelect={() => sortDesktopItems('color')}>Color Tonal Group</ContextMenuItem>
                    </ContextMenuSubContent>
                </ContextMenuSub>
                <ContextMenuItem inset onSelect={() => window.location.reload()}>
                    <RefreshCw className="w-4 h-4 mr-2" /> Refresh
                </ContextMenuItem>
                <ContextMenuSeparator className="bg-white/10" />
                <ContextMenuSub>
                    <ContextMenuSubTrigger inset>
                        <Monitor className="w-4 h-4 mr-2" /> Wallpaper
                    </ContextMenuSubTrigger>
                    <ContextMenuSubContent className="bg-black/90 border-white/10 text-neutral-200">
                        <ContextMenuItem onSelect={() => setWallpaperMode('nebula')}>
                            {wallpaperMode === 'nebula' && <span className="mr-2">●</span>} Nebula (Default)
                        </ContextMenuItem>
                        <ContextMenuItem onSelect={() => setWallpaperMode('grid')}>
                            {wallpaperMode === 'grid' && <span className="mr-2">●</span>} Technical Grid
                        </ContextMenuItem>
                        <ContextMenuItem onSelect={() => setWallpaperMode('void')}>
                            {wallpaperMode === 'void' && <span className="mr-2">●</span>} Void (Black)
                        </ContextMenuItem>
                    </ContextMenuSubContent>
                </ContextMenuSub>
                <ContextMenuItem inset onClick={() => toast.success("Icons Aligned")}>
                    <GridIcon className="w-4 h-4 mr-2" /> Align to Grid
                </ContextMenuItem>
                <ContextMenuSeparator className="bg-white/10" />
                <ContextMenuSub>
                    <ContextMenuSubTrigger inset>Workbenches (Roles)</ContextMenuSubTrigger>
                    <ContextMenuSubContent className="bg-black/90 border-white/10 text-neutral-200">
                        <ContextMenuItem onSelect={() => setUserRole('normal')}>
                            {userRole === 'normal' && <span className="mr-2">●</span>} Normal User
                        </ContextMenuItem>
                        <ContextMenuItem onSelect={() => setUserRole('developer')}>
                            {userRole === 'developer' && <span className="mr-2">●</span>} Developer
                        </ContextMenuItem>
                        <ContextMenuItem onSelect={() => setUserRole('ceo')}>
                            {userRole === 'ceo' && <span className="mr-2">●</span>} CEO / Exec
                        </ContextMenuItem>
                        <ContextMenuItem onSelect={() => setUserRole('pm')}>
                            {userRole === 'pm' && <span className="mr-2">●</span>} Project Manager
                        </ContextMenuItem>
                    </ContextMenuSubContent>
                </ContextMenuSub>
            </ContextMenuContent>

            {/* REST OF DESKTOP LAYERS */}

            {/* 1.0 ATMOSPHERE (Particles & Depth) */}
            <AtmosphereLayer mode={wallpaperMode} />

            {/* ROLE-BASED WORKBENCHES VS CLASSIC DESKTOP */}
            {userRole === 'normal' ? (
                <>
                    {/* 1.2 DYNAMIC WIDGET LAYER (User Configurable) */}
                    <WidgetLayer 
                        widgets={widgets}
                        customWidgets={installedWidgets}
                        onMove={handleWidgetMove}
                        onResize={handleWidgetResize}
                        onStackAction={handleStackAction}
                        onToggleSize={handleToggleWidgetSize}
                        onClose={handleWidgetClose}
                        onPin={(id) => {
                            handleWidgetLock(id);
                            const widget = widgets.find(w => w.id === id);
                            toast.success("Widget Lock Toggled");
                        }}
                    />
                    
                    {/* 1.5 DESKTOP ICONS GRID - FULLY INTERACTIVE */}
                    <DesktopIconGrid 
                        apps={desktopItems} 
                        onLaunch={(app) => {
                            if (app.type === 'folder') {
                                // Check if it's a real file system folder or an app group
                                if (app.contents) {
                                    setExpandedFolder(app);
                                } else {
                                    // Standard File Folder
                                    launchApp({
                                        id: 'FileManager',
                                        name: app.name,
                                        icon: app.icon,
                                        type: 'app',
                                        tabs: [{ id: 'files', label: 'Files', icon: FolderPlus }] 
                                    });
                                }
                            } else if (app.type === 'file') {
                                toast('Opening file: ' + app.name);
                            } else {
                                launchApp(app);
                            }
                        }} 
                        onMove={handleIconMove}
                        onDelete={deleteDesktopItem}
                        onRename={handleRename}
                    />

                    {/* CUSTOM FOLDER EXPANSION OVERLAY */}
                    <AnimatePresence>
                        {expandedFolder && (
                            <DesktopFolderExpanded 
                                folder={expandedFolder}
                                onClose={() => setExpandedFolder(null)}
                                onLaunch={launchApp}
                                onExtract={(folderId, itemId, point) => {
                                    // 1. Find the item
                                    const folder = desktopItems.find(i => i.id === folderId);
                                    const item = folder?.contents?.find(i => i.id === itemId);
                                    
                                    if (item) {
                                        // 2. Calculate New Position (Snapped)
                                        const snapped = snapToGrid(point.x, point.y, gridConfig.cellSize, gridConfig.cellSize);
                                        
                                        // 3. Update State
                                        setDesktopItems(prev => {
                                            const newItems = [];
                                            let extractedItem = null;

                                            prev.forEach(i => {
                                                if (i.id === folderId) {
                                                    const newContents = i.contents.filter(c => c.id !== itemId);
                                                    // If folder is empty, do not push it to newItems (Delete it)
                                                    if (newContents.length > 0) {
                                                        newItems.push({ ...i, contents: newContents });
                                                    } else {
                                                        if (expandedFolder?.id === folderId) setExpandedFolder(null); // Close if open
                                                    }
                                                } else {
                                                    newItems.push(i);
                                                }
                                            });

                                            if (item) {
                                                extractedItem = {
                                                    ...item,
                                                    position: { x: snapped.x, y: snapped.y }
                                                };
                                                newItems.push(extractedItem);
                                            }
                                            
                                            return newItems;
                                        });
                                        
                                        toast.success(`Extracted ${item.name}`);
                                    }
                                }}
                            />
                        )}
                    </AnimatePresence>
                </>
            ) : (
                <div className="absolute inset-0 z-10 pointer-events-auto" style={{ bottom: '80px', top: '56px' }}>
                    {userRole === 'developer' && <DeveloperWorkbench />}
                    {userRole === 'ceo' && <CEOExecutiveDashboard />}
                    {userRole === 'pm' && <ProjectManagerWorkbench />}
                </div>
            )}

            {/* 1.8 PINNED WINDOWS LAYER (Z-STACK TOP) */}
            <div className="absolute inset-0 pointer-events-none z-30">
                <AnimatePresence>
                    {pinnedItems.map(item => (
                        <div key={item.id} className="pointer-events-auto">
                            <PinnedWindow item={item} />
                        </div>
                    ))}
                </AnimatePresence>
            </div>

            {/* Desktop Controls moved to ToolDock */}

            {/* 2. WINDOW LAYER: Draggable Panes */}
            <div className="absolute inset-0 pointer-events-none z-20">
                <AnimatePresence>
                    {windows.map((win) => {
                        const zIndex = windowOrder.indexOf(win.id) + 10;
                        return !win.minimized && (
                            <div key={win.id} className="pointer-events-auto">
                            <WindowFrame
                                title={win.title}
                                icon={win.icon}
                                theme={win.theme}
                                tabs={win.tabs}
                                activeTab={win.activeTab}
                                onTabChange={(tabId) => handleTabChange(win.id, tabId)}
                                isActive={activeWindowId === win.id}
                                zIndex={zIndex}
                                onFocus={() => focusWindow(win.id)}
                                onClose={() => closeWindow(win.id)}
                                onMinimize={() => toggleMinimize(win.id)}
                                initialPosition={win.position}
                                onPin={() => {
                                    addPinnedItem({
                                        title: win.title,
                                        appId: win.appId,
                                        activeTab: win.activeTab,
                                        type: 'app',
                                        w: 600,
                                        h: 400
                                    });
                                    closeWindow(win.id);
                                    toast.success(`${win.title} Pinned to Desktop`);
                                }}
                            >
                                <ObsidianTabletContent 
                                    appId={win.appId} 
                                    activeTab={win.activeTab}
                                    manifest={allApps.find(a => a.id === win.appId)?.manifest}
                                />
                            </WindowFrame>
                            </div>
                        );
                    })}
                </AnimatePresence>
            </div>

            {/* 3. INTERFACE LAYER: Infinity Dock & Menus */}
            <InfinityDock 
                apps={allApps}
                pinnedDockIds={pinnedDockIds} 
                onLaunch={launchApp}
                onClose={closeWindow}
                onStartClick={() => setIsStartOpen(!isStartOpen)}
                openWindows={windows}
                activeWindowId={activeWindowId}
                isStartOpen={isStartOpen}
                onSearch={onSearch}
                domainData={domainData}
            />

            <StartMenu 
                isOpen={isStartOpen} 
                apps={allApps} 
                onLaunch={launchApp} 
                onClose={() => setIsStartOpen(false)} 
            />

            <CommandBar 
                isOpen={globalCommandOpen} 
                onClose={() => setGlobalCommandOpen(false)} 
                onExecute={(cmd) => {
                    toast.success(`Executed: ${cmd}`);
                    // Basic local command handling could go here
                    if (cmd.includes('dev')) setUserRole('developer');
                    if (cmd.includes('ceo')) setUserRole('ceo');
                    if (cmd.includes('normal')) setUserRole('normal');
                }}
            />
        </ContextMenu>
    );
}