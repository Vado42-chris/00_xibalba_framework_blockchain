import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';

const GridContext = createContext(null);

export const useGrid = () => {
    const context = useContext(GridContext);
    if (!context) throw new Error("useGrid must be used within a GridProvider");
    return context;
};

export const GridProvider = ({ children }) => {
    // Grid Configuration
    const [gridConfig, setGridConfig] = useState({
        cellSize: 96, // Larger base unit for touch/tablet
        gap: 32,      // Significant padding between icons
        showGrid: false,
        opacity: 0.2
    });

    // Pinned Items (Windows/Widgets pinned to desktop)
    // --- WORKSPACE MANAGEMENT SYSTEM ---
    
    const DEFAULT_WORKSPACES = [
        { 
            id: 'general', 
            name: 'General', 
            widgets: [
                { id: 'clock-main', type: 'clock', position: { x: 48, y: 48 }, size: 'md' },
                { id: 'system-status', type: 'system-status', position: { x: 48, y: 300 }, size: 'sm' }
            ], 
            pinnedItems: [] 
        },
        {
            id: 'dev',
            name: 'Development',
            widgets: [
                { id: 'clock-dev', type: 'clock', position: { x: 1200, y: 48 }, size: 'sm' },
                { id: 'code-pulse', type: 'code-pulse', position: { x: 48, y: 48 }, size: 'lg' },
                { id: 'node-monitor', type: 'node-monitor', position: { x: 1200, y: 200 }, size: 'sm' }
            ],
            pinnedItems: []
        },
        {
            id: 'creative',
            name: 'Creative Studio',
            widgets: [
                { id: 'spotify', type: 'spotify', position: { x: 48, y: 48 }, size: 'md' },
                { id: 'social', type: 'social', position: { x: 1200, y: 48 }, size: 'lg' }
            ],
            pinnedItems: []
        }
    ];

    // Initialize Workspaces
    const [workspaces, setWorkspaces] = useState(() => {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem('xi_workspaces');
            return saved ? JSON.parse(saved) : DEFAULT_WORKSPACES;
        }
        return DEFAULT_WORKSPACES;
    });

    const [currentWorkspaceId, setCurrentWorkspaceId] = useState(() => {
        if (typeof window !== 'undefined') {
            return localStorage.getItem('xi_current_workspace_id') || 'general';
        }
        return 'general';
    });

    // Pinned Items & Widgets (Initialized from Workspace)
    const [pinnedItems, setPinnedItems] = useState(() => {
        const ws = workspaces.find(w => w.id === currentWorkspaceId) || DEFAULT_WORKSPACES[0];
        return ws.pinnedItems || [];
    });

    const [widgets, setWidgets] = useState(() => {
        const ws = workspaces.find(w => w.id === currentWorkspaceId) || DEFAULT_WORKSPACES[0];
        return ws.widgets || [];
    });

    // Persistence & Sync
    useEffect(() => {
        if (typeof window !== 'undefined') {
            // Update the current workspace object in the array
            const updatedWorkspaces = workspaces.map(ws => 
                ws.id === currentWorkspaceId 
                    ? { ...ws, widgets, pinnedItems } 
                    : ws
            );
            
            // Only write to storage if something actually changed to avoid loops? 
            // Actually, React state updates are batched, so this is okay.
            // We need to keep 'workspaces' state in sync with widgets/pins for switching.
            // BUT calling setWorkspaces here might cause infinite loop if not careful.
            // Let's use a ref or just save to localStorage directly? 
            // Better: Update localStorage for "xi_workspaces" with the merged data.
            // AND update the 'workspaces' state only when switching?
            // No, 'workspaces' state needs to be current.
            
            // Let's just save to LocalStorage here for now to persist "Current State".
            // And we'll update the 'workspaces' state object when we switch AWAY or explicitly save?
            // "Auto-save" approach:
            
            const finalWorkspaces = updatedWorkspaces;
            localStorage.setItem('xi_workspaces', JSON.stringify(finalWorkspaces));
            localStorage.setItem('xi_current_workspace_id', currentWorkspaceId);
        }
    }, [widgets, pinnedItems, currentWorkspaceId]);

    // Update the 'workspaces' state when widgets/pins change so we don't lose progress when switching
    // This is the critical link.
    useEffect(() => {
        setWorkspaces(prev => prev.map(ws => 
            ws.id === currentWorkspaceId 
                ? { ...ws, widgets, pinnedItems } 
                : ws
        ));
    }, [widgets, pinnedItems]); // Remove currentWorkspaceId from dependency to avoid loop on switch


    const switchWorkspace = (id) => {
        const ws = workspaces.find(w => w.id === id);
        if (ws) {
            setCurrentWorkspaceId(id);
            setWidgets(ws.widgets || []);
            setPinnedItems(ws.pinnedItems || []);
            toast.success(`Workspace: ${ws.name}`);
        }
    };

    const createWorkspace = (name) => {
        // "Save State" behavior: Clone current state into new workspace
        const newId = name.toLowerCase().replace(/\s+/g, '-');
        
        // Check if exists to prevent duplicates or overwrite
        if (workspaces.some(w => w.id === newId)) {
            toast.error("Workspace with this name already exists");
            return;
        }

        const newWs = {
            id: newId,
            name,
            widgets: [...widgets],        // Clone current widgets
            pinnedItems: [...pinnedItems] // Clone current pinned items
        };
        
        setWorkspaces(prev => [...prev, newWs]);
        setCurrentWorkspaceId(newId); // Switch to it immediately
        toast.success(`Workspace state saved as "${name}"`);
    };

    const saveCurrentWorkspace = () => {
        setWorkspaces(prev => prev.map(ws => 
            ws.id === currentWorkspaceId 
                ? { ...ws, widgets, pinnedItems } 
                : ws
        ));
        toast.success("Workspace state saved");
    };
    
    const deleteWorkspace = (id) => {
        if (workspaces.length <= 1) {
            toast.error("Cannot delete last workspace");
            return;
        }
        const newWorkspaces = workspaces.filter(w => w.id !== id);
        setWorkspaces(newWorkspaces);
        if (currentWorkspaceId === id) {
            switchWorkspace(newWorkspaces[0].id);
        }
    };

    // Dimensions (Managed by consumer now via resize observer)
    const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

    // CENTRAL ZONE DEFINITION (Logo)
    const centralZone = {
        width: 600,
        height: 200
    };
    
    // DOCK ZONE (Bottom Taskbar)
    const dockZoneHeight = 120; // Taskbar area

    // Snap Logic
    const snapToGrid = useCallback((x, y, width = 0, height = 0) => {
        const { cellSize, gap } = gridConfig;
        const totalUnit = cellSize + gap;
        const centerX = dimensions.width / 2;
        const centerY = dimensions.height / 2;

        const deltaX = x - centerX;
        const deltaY = y - centerY;

        const col = Math.round(deltaX / totalUnit);
        const row = Math.round(deltaY / totalUnit);

        let snappedX = centerX + (col * totalUnit);
        let snappedY = centerY + (row * totalUnit);

        // FORBIDDEN ZONE CHECK
        const itemRect = {
            left: snappedX,
            right: snappedX + width,
            top: snappedY,
            bottom: snappedY + height
        };

        const forbiddenRect = {
            left: centerX - (centralZone.width / 2),
            right: centerX + (centralZone.width / 2),
            top: centerY - (centralZone.height / 2),
            bottom: centerY + (centralZone.height / 2)
        };

        // Check Central Zone Overlap
        const overlapsCenter = (
            itemRect.left < forbiddenRect.right &&
            itemRect.right > forbiddenRect.left &&
            itemRect.top < forbiddenRect.bottom &&
            itemRect.bottom > forbiddenRect.top
        );

        // Check Dock Overlap
        const overlapsDock = itemRect.bottom > (dimensions.height - dockZoneHeight);
        
        // Check Top Bar Overlap
        const topBarHeight = 64; // Standard header height
        const overlapsTop = itemRect.top < topBarHeight;

        if (overlapsCenter) {
            // Push logic (Away from center)
            const itemCenterX = snappedX + width / 2;
            const itemCenterY = snappedY + height / 2;
            
            if (Math.abs(itemCenterX - centerX) > Math.abs(itemCenterY - centerY)) {
                if (itemCenterX > centerX) {
                    snappedX = forbiddenRect.right + gap;
                } else {
                    snappedX = forbiddenRect.left - width - gap;
                }
            } else {
                if (itemCenterY > centerY) {
                    snappedY = forbiddenRect.bottom + gap;
                } else {
                    snappedY = forbiddenRect.top - height - gap;
                }
            }
            
            const newDeltaX = snappedX - centerX;
            const newDeltaY = snappedY - centerY;
            const newCol = Math.round(newDeltaX / totalUnit);
            const newRow = Math.round(newDeltaY / totalUnit);
            
            snappedX = centerX + (newCol * totalUnit);
            snappedY = centerY + (newRow * totalUnit);
        }
        
        // Prevent Dock Overlap (Push Up)
        if (overlapsDock) {
             const rowsFromBottom = Math.ceil((itemRect.bottom - (dimensions.height - dockZoneHeight)) / totalUnit);
             snappedY -= (rowsFromBottom * totalUnit);
        }

        // Prevent Top Bar Overlap (Push Down)
        if (overlapsTop) {
            snappedY = Math.max(snappedY, topBarHeight + gap);
        }

        return {
            x: snappedX,
            y: snappedY,
            col,
            row
        };
    }, [gridConfig, dimensions, centralZone]);

    const snapDimensions = useCallback((width, height) => {
        const { cellSize, gap } = gridConfig;
        const totalUnit = cellSize + gap;
        const cols = Math.round((width + gap) / totalUnit);
        const rows = Math.round((height + gap) / totalUnit);

        return {
            width: Math.max(1, cols) * totalUnit - gap,
            height: Math.max(1, rows) * totalUnit - gap,
            cols: Math.max(1, cols),
            rows: Math.max(1, rows)
        };
    }, [gridConfig]);

    // Widget Management Actions
    const handleWidgetMove = (id, newPos) => {
        setWidgets(prev => {
            const movedWidget = prev.find(w => w.id === id);
            if (!movedWidget) return prev;

            const target = prev.find(w => 
                w.id !== id && 
                w.type !== 'stack' && 
                Math.abs(w.position.x - newPos.x) < 50 && 
                Math.abs(w.position.y - newPos.y) < 50
            );

            if (target) {
                toast.success("Stack Created");
                const stackId = `stack-${Date.now()}`;
                const stack = {
                    id: stackId,
                    type: 'stack',
                    position: target.position,
                    size: target.size || 'md',
                    widgets: [target, { ...movedWidget, position: { x:0, y:0 } }],
                    activeWidgetId: target.id
                };
                return [
                    ...prev.filter(w => w.id !== id && w.id !== target.id),
                    stack
                ];
            }

            return prev.map(w => w.id === id ? { ...w, position: newPos } : w);
        });
    };

    const handleWidgetResize = (id, direction, delta) => {
        setWidgets(prev => prev.map(w => {
            if (w.id === id) {
                let currentW = w.w;
                let currentH = w.h;
                
                if (!currentW || !currentH) {
                    if (w.size === 'sm') { currentW = 256; currentH = 128; }
                    else if (w.size === 'lg') { currentW = 384; currentH = 384; }
                    else { currentW = 320; currentH = 256; }
                }

                return { 
                    ...w, 
                    w: Math.max(200, currentW + delta.x), 
                    h: Math.max(100, currentH + delta.y) 
                };
            }
            return w;
        }));
    };

    const handleToggleWidgetSize = (id) => {
        const sizes = ['sm', 'md', 'lg'];
        setWidgets(prev => prev.map(w => {
            if (w.id === id) {
                const currentIdx = sizes.indexOf(w.size);
                const nextSize = sizes[(currentIdx + 1) % sizes.length];
                return { ...w, size: nextSize, w: undefined, h: undefined };
            }
            return w;
        }));
    };

    const handleWidgetClose = (id) => {
        setWidgets(prev => prev.filter(w => w.id !== id));
    };

    const handleAddWidget = (type) => {
        const id = `${type}-${Date.now()}`;
        const position = { x: 200 + (widgets.length * 20), y: 200 + (widgets.length * 20) };
        setWidgets(prev => [...prev, { id, type, position, size: 'md' }]);
        toast.success(`Widget Added: ${type.toUpperCase()}`);
    };

    const handleStackAction = (stackId, action, payload) => {
        setWidgets(prev => prev.map(w => {
            if (w.id === stackId && w.type === 'stack') {
                if (action === 'setActive') {
                    return { ...w, activeWidgetId: payload };
                }
            }
            return w;
        }));
    };

    const handleWidgetLock = (id) => {
        setWidgets(prev => prev.map(w => w.id === id ? { ...w, locked: !w.locked } : w));
    };

    const addPinnedItem = (item) => {
        const { width, height } = dimensions;
        const defaultW = gridConfig.cellSize * 6 + gridConfig.gap * 5;
        const defaultH = gridConfig.cellSize * 4 + gridConfig.gap * 3;
        const startX = width / 2 + 400; 
        const startY = height / 2 - 300;
        const snapped = snapToGrid(startX, startY, defaultW, defaultH);
        const newItem = {
            id: `pin-${Date.now()}`,
            x: snapped.x,
            y: snapped.y,
            w: defaultW,
            h: defaultH, 
            zIndex: 10 + pinnedItems.length,
            ...item
        };
        setPinnedItems(prev => [...prev, newItem]);
    };

    const updatePinnedItem = (id, updates) => {
        setPinnedItems(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
    };

    const removePinnedItem = (id) => {
        setPinnedItems(prev => prev.filter(item => item.id !== id));
    };

    const toggleGridLines = () => {
        setGridConfig(prev => ({ ...prev, showGrid: !prev.showGrid }));
    };

    const setGridSize = (size) => {
        setGridConfig(prev => {
            const oldSize = prev.cellSize;
            const ratio = size / oldSize;
            
            // Re-scale widgets to maintain relative visual size/position
            // We defer the actual position update to the effect or do it here
            // But since 'widgets' is separate state, we should probably update widgets here too
            // However, updating two states in one go might be tricky if we don't have access to current widgets here easily due to closure
            // actually we do have access to 'widgets' from scope, but it might be stale? No, 'setGridSize' is recreated on render?
            // No, 'setGridSize' is defined in the component body, so it closes over current 'widgets'.
            // But 'widgets' changes often. 'setGridSize' isn't wrapped in useCallback? 
            // It is NOT wrapped in useCallback in the original file (lines 391-393).
            // So it has access to fresh 'widgets'.
            
            return { ...prev, cellSize: size };
        });
    };

    // Auto-scale items when grid size changes
    useEffect(() => {
        // We need to re-snap or re-scale items when cellSize changes
        // This effect runs when gridConfig changes
        
        const { cellSize, gap } = gridConfig;
        
        // Function to re-align items to the new grid
        const realignItems = () => {
            // Update Widgets
            setWidgets(prevWidgets => prevWidgets.map(w => {
                 // Calculate nearest grid slot based on current position
                 // Actually, if we just re-snap, they might jump.
                 // Ideally we want them to stay in the same 'column/row'.
                 // But we don't store col/row.
                 // So we just re-snap to the new grid.
                 const snapped = snapToGrid(w.position.x, w.position.y);
                 return { ...w, position: { x: snapped.x, y: snapped.y } };
            }));

            // Update Pinned Items
            setPinnedItems(prevPinned => prevPinned.map(p => {
                const snapped = snapToGrid(p.x, p.y, p.w, p.h);
                // Also scale dimensions if desired? 
                // The user said: "change size dynamically when it is scaled"
                // So we should try to scale the width/height too.
                // We can approximate by snapping dimensions to new grid units.
                
                // Estimate cols/rows from old dimensions (approximate)
                // This is hard without knowing the *previous* grid size exactly during this effect run
                // But we can just snap dimensions to nearest valid unit in NEW grid
                const snappedDims = snapDimensions(p.w, p.h);
                
                return { 
                    ...p, 
                    x: snapped.x, 
                    y: snapped.y,
                    w: snappedDims.width,
                    h: snappedDims.height
                };
            }));
        };

        // Run realignment
        realignItems();
        
    }, [gridConfig.cellSize, gridConfig.gap, snapToGrid, snapDimensions]); // Only run when grid metrics change

    const setGridOpacity = (opacity) => {
        setGridConfig(prev => ({ ...prev, opacity }));
    };

    return (
        <GridContext.Provider value={{
            gridConfig,
            pinnedItems,
            widgets,
            dimensions,
            snapToGrid,
            snapDimensions,
            addPinnedItem,
            updatePinnedItem,
            removePinnedItem,
            toggleGridLines,
            setGridSize,
            setGridOpacity,
            handleWidgetMove,
            handleWidgetResize,
            handleToggleWidgetSize,
            handleWidgetClose,
            handleAddWidget,
            handleStackAction,
            handleWidgetLock,
            centralZone,
            workspaces,
            currentWorkspaceId,
            switchWorkspace,
            createWorkspace,
            saveCurrentWorkspace, 
            deleteWorkspace,
            setDimensions // Export setDimensions for Container Observer
        }}>
            {children}
            {gridConfig.showGrid && (
                <div 
                    className="absolute inset-0 pointer-events-none z-[9999] transition-opacity duration-300"
                    style={{
                        opacity: gridConfig.opacity,
                        backgroundImage: `
                            linear-gradient(to right, #444 1px, transparent 1px),
                            linear-gradient(to bottom, #444 1px, transparent 1px)
                        `,
                        backgroundSize: `${gridConfig.cellSize + gridConfig.gap}px ${gridConfig.cellSize + gridConfig.gap}px`,
                        backgroundPosition: `center center`,
                        maskImage: 'radial-gradient(circle at center, transparent 300px, black 600px)'
                    }}
                />
            )}
        </GridContext.Provider>
    );
};