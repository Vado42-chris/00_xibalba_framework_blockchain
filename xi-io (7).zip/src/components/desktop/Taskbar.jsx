import React, { useState, useEffect } from 'react';
import { 
    Shield, Key, FileCheck, Search, Infinity, 
    Bot, Zap, Wifi, Battery, Calendar as CalendarIcon, 
    Bell, ChevronUp, Cpu, Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from "@/lib/utils";

// Clock Component
const SystemClock = () => {
    const [time, setTime] = useState(new Date());
    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);
    return (
        <div className="flex flex-col items-end leading-tight mr-4 cursor-pointer hover:text-white transition-colors">
            <span className="text-xs font-medium font-mono">{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            <span className="text-[10px] text-neutral-500">{time.toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
        </div>
    );
};

// Taskbar Icon Component
const TaskbarIcon = ({ icon: Icon, label, active, onClick, color = "text-neutral-400" }) => (
    <div className="relative group flex flex-col items-center">
        <button 
            onClick={onClick}
            className={cn(
                "p-2.5 rounded-xl transition-all duration-300 hover:bg-white/10 relative",
                active ? "bg-white/10 text-white" : color
            )}
        >
            <Icon className="w-5 h-5" />
            {active && (
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 bg-[hsl(var(--color-intent))] rounded-full shadow-[0_0_8px_hsl(var(--color-intent))]" />
            )}
        </button>
        {/* Tooltip */}
        <div className="absolute bottom-full mb-3 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-black/90 border border-white/10 rounded-lg text-[10px] text-white font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none backdrop-blur-md">
            {label}
            <div className="absolute bottom-[-4px] left-1/2 -translate-x-1/2 w-2 h-2 bg-black/90 border-r border-b border-white/10 rotate-45" />
        </div>
    </div>
);

export default function Taskbar({ onStartClick, openWindows, activeWindowId, onWindowClick, isStartOpen }) {
    return (
        <div className="absolute bottom-6 left-6 right-6 h-16 bg-black/60 backdrop-blur-2xl border border-white/10 rounded-2xl flex items-center justify-between px-6 z-50 shadow-2xl">
            
            {/* LEFT ZONE: Security & Blockchain */}
            <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 pr-4 border-r border-white/5 mr-2">
                    <TaskbarIcon icon={Shield} label="Identity Vault" color="text-emerald-400/80 hover:text-emerald-400" onClick={() => console.log('Identity')} />
                    <TaskbarIcon icon={FileCheck} label="Attestations" color="text-blue-400/80 hover:text-blue-400" onClick={() => console.log('Attestations')} />
                    <TaskbarIcon icon={Activity} label="Asset Integrity" color="text-rose-400/80 hover:text-rose-400" onClick={() => console.log('Integrity')} />
                </div>
                
                {/* Active Windows (Left side flow) */}
                <div className="flex items-center gap-2">
                    {openWindows.map(win => (
                        <button
                            key={win.id}
                            onClick={() => onWindowClick(win.id)}
                            className={cn(
                                "flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 border",
                                activeWindowId === win.id 
                                    ? "bg-white/10 border-white/10 text-white shadow-[0_0_15px_-5px_rgba(255,255,255,0.2)]" 
                                    : "bg-transparent border-transparent text-neutral-500 hover:bg-white/5 hover:text-neutral-300"
                            )}
                        >
                            {win.icon && <win.icon className="w-4 h-4" />}
                            <span className="text-xs font-medium max-w-[100px] truncate">{win.title}</span>
                        </button>
                    ))}
                </div>
            </div>

            {/* CENTER ZONE: The Infinite Start */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                <motion.button
                    whileHover={{ scale: 1.1, textShadow: "0 0 8px rgb(255,255,255)" }}
                    whileTap={{ scale: 0.95 }}
                    onClick={onStartClick}
                    className={cn(
                        "w-14 h-14 rounded-full flex items-center justify-center transition-all duration-500 border-2",
                        isStartOpen 
                            ? "bg-[hsl(var(--color-intent))] border-[hsl(var(--color-intent))] text-black shadow-[0_0_30px_-5px_hsl(var(--color-intent))]" 
                            : "bg-black/50 border-white/20 text-white hover:border-[hsl(var(--color-intent))] hover:text-[hsl(var(--color-intent))]"
                    )}
                >
                    <Infinity className="w-8 h-8" />
                </motion.button>
            </div>

            {/* RIGHT ZONE: AI & System */}
            <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 pl-4 border-l border-white/5 ml-2">
                    <TaskbarIcon icon={Bot} label="AI Provider Hub" color="text-purple-400/80 hover:text-purple-400" onClick={() => console.log('AI Hub')} />
                    <TaskbarIcon icon={Zap} label="Automation" color="text-yellow-400/80 hover:text-yellow-400" onClick={() => console.log('Automations')} />
                </div>

                <div className="h-8 w-px bg-white/10 mx-4" />

                {/* System Tray */}
                <div className="flex items-center gap-4 text-neutral-400">
                    <div className="flex items-center gap-2">
                        <Wifi className="w-4 h-4" />
                        <Battery className="w-4 h-4" />
                        <Bell className="w-4 h-4" />
                    </div>
                    <SystemClock />
                    <button className="p-1 hover:bg-white/10 rounded">
                        <ChevronUp className="w-4 h-4" />
                    </button>
                </div>
            </div>
        </div>
    );
}