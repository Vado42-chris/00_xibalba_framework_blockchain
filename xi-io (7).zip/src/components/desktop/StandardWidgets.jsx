import React, { useState } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { Check, Plus, Trash2, Mail, MessageSquare, Heart, Share2, MoreHorizontal, Bell, Search, Star } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { toast } from 'sonner';

// --- CALENDAR WIDGET ---
export function CalendarWidget() {
    const [date, setDate] = useState(new Date());

    return (
        <div className="h-full flex flex-col bg-neutral-900/50">
            <div className="flex-1 overflow-hidden p-2">
                <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    className="rounded-md border border-white/5 w-full h-full flex flex-col"
                    classNames={{
                        month: "space-y-4 w-full flex flex-col",
                        table: "w-full border-collapse space-y-1",
                        head_row: "flex w-full justify-between",
                        row: "flex w-full mt-2 justify-between",
                        cell: "text-center text-sm p-0 relative [&:has([aria-selected])]:bg-[hsl(var(--color-intent))]/20 first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
                        day: cn(
                            "h-8 w-8 p-0 font-normal aria-selected:opacity-100 hover:bg-white/10 rounded-full transition-colors text-neutral-300"
                        ),
                        day_selected:
                            "bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/80 focus:bg-[hsl(var(--color-intent))] focus:text-black",
                        day_today: "bg-white/10 text-white font-bold",
                    }}
                />
            </div>
            <div className="p-3 border-t border-white/5 bg-black/20 text-xs text-center font-mono text-neutral-500">
                {format(date, 'EEEE, MMMM do, yyyy')}
            </div>
        </div>
    );
}

// --- DAY PLANNER WIDGET ---
export function DayPlannerWidget() {
    const [tasks, setTasks] = useState([
        { id: 1, text: "Review System Logs", completed: false, priority: 'high' },
        { id: 2, text: "Update Node Configs", completed: true, priority: 'medium' },
        { id: 3, text: "Sync Agent Swarm", completed: false, priority: 'low' },
    ]);
    const [newTask, setNewTask] = useState("");

    const toggleTask = (id) => {
        setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
    };

    const addTask = (e) => {
        e.preventDefault();
        if (!newTask.trim()) return;
        setTasks([...tasks, { id: Date.now(), text: newTask, completed: false, priority: 'medium' }]);
        setNewTask("");
    };

    const removeTask = (id) => {
        setTasks(tasks.filter(t => t.id !== id));
    };

    return (
        <div className="h-full flex flex-col bg-neutral-900/50">
            <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin scrollbar-thumb-white/10">
                {tasks.map(task => (
                    <div key={task.id} className={cn(
                        "flex items-center gap-2 p-2 rounded border transition-all group",
                        task.completed ? "bg-white/5 border-transparent opacity-50" : "bg-black/40 border-white/5 hover:border-white/10"
                    )}>
                        <button 
                            onClick={() => toggleTask(task.id)}
                            className={cn(
                                "w-4 h-4 rounded-sm border flex items-center justify-center transition-colors",
                                task.completed ? "bg-green-500 border-green-500 text-black" : "border-neutral-500 hover:border-white"
                            )}
                        >
                            {task.completed && <Check className="w-3 h-3" />}
                        </button>
                        <span className={cn(
                            "flex-1 text-xs truncate",
                            task.completed ? "line-through text-neutral-500" : "text-neutral-200"
                        )}>
                            {task.text}
                        </span>
                        <div className={cn("w-1.5 h-1.5 rounded-full shrink-0", 
                            task.priority === 'high' ? 'bg-red-500' : 
                            task.priority === 'medium' ? 'bg-yellow-500' : 'bg-blue-500'
                        )} />
                        <button onClick={() => removeTask(task.id)} className="opacity-0 group-hover:opacity-100 text-neutral-500 hover:text-red-400">
                            <Trash2 className="w-3 h-3" />
                        </button>
                    </div>
                ))}
            </div>
            <form onSubmit={addTask} className="p-2 border-t border-white/5 bg-black/20 flex gap-2">
                <input 
                    className="flex-1 bg-transparent border-none text-xs text-white placeholder:text-neutral-600 focus:outline-none"
                    placeholder="Add new task..."
                    value={newTask}
                    onChange={(e) => setNewTask(e.target.value)}
                />
                <button type="submit" className="text-neutral-400 hover:text-[hsl(var(--color-intent))]">
                    <Plus className="w-4 h-4" />
                </button>
            </form>
        </div>
    );
}

// --- SOCIAL FEED WIDGET ---
export function SocialWidget() {
    const posts = [
        { id: 1, user: "System", handle: "@root", content: "Network optimization complete. Latency reduced by 14%. #infrastructure", time: "2m", likes: 42 },
        { id: 2, user: "DevOps", handle: "@builder", content: "New component library update pushed to main. Check the docs for changes.", time: "15m", likes: 128 },
        { id: 3, user: "Security", handle: "@sec_ops", content: "Intrusion attempt blocked on node 4. Reviewing logs.", time: "1h", likes: 8 },
    ];

    return (
        <div className="h-full flex flex-col bg-neutral-900/50">
            <div className="p-2 border-b border-white/5 flex justify-between items-center bg-black/20">
                <div className="flex gap-2">
                    <button className="text-[10px] font-bold text-white bg-white/10 px-2 py-0.5 rounded-full">Feed</button>
                    <button className="text-[10px] font-bold text-neutral-500 hover:text-white px-2 py-0.5 rounded-full">Mentions</button>
                </div>
                <button className="text-neutral-400 hover:text-white"><Bell className="w-3 h-3" /></button>
            </div>
            <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
                {posts.map(post => (
                    <div key={post.id} className="p-3 border-b border-white/5 hover:bg-white/5 transition-colors">
                        <div className="flex justify-between items-start mb-1">
                            <div className="flex items-center gap-1.5">
                                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500" />
                                <div>
                                    <div className="text-xs font-bold text-white leading-none">{post.user}</div>
                                    <div className="text-[10px] text-neutral-500 leading-none">{post.handle}</div>
                                </div>
                            </div>
                            <span className="text-[9px] text-neutral-600">{post.time}</span>
                        </div>
                        <p className="text-xs text-neutral-300 mt-1 mb-2 leading-relaxed">{post.content}</p>
                        <div className="flex items-center gap-4 text-neutral-500">
                            <button className="flex items-center gap-1 hover:text-white transition-colors"><Heart className="w-3 h-3" /> <span className="text-[9px]">{post.likes}</span></button>
                            <button className="flex items-center gap-1 hover:text-white transition-colors"><MessageSquare className="w-3 h-3" /></button>
                            <button className="flex items-center gap-1 hover:text-white transition-colors"><Share2 className="w-3 h-3" /></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

// --- EMAIL WIDGET ---
export function EmailWidget() {
    const emails = [
        { id: 1, from: "Director", subject: "Q4 Strategy Alignment", preview: "Please review the attached deck regarding...", time: "10:30 AM", unread: true },
        { id: 2, from: "Alerts", subject: "[CRITICAL] Server Load High", preview: "CPU usage exceeded 90% on cluster alpha...", time: "09:15 AM", unread: true },
        { id: 3, from: "Marketplace", subject: "New Widget Submission", preview: "User 'Neo' has submitted a new visual...", time: "Yesterday", unread: false },
        { id: 4, from: "HR", subject: "Onboarding Updates", preview: "Welcome to the new team members starting...", time: "Yesterday", unread: false },
    ];

    return (
        <div className="h-full flex flex-col bg-neutral-900/50">
            <div className="p-2 border-b border-white/5 flex gap-2 items-center bg-black/20">
                <div className="relative flex-1">
                    <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-neutral-500" />
                    <input className="w-full bg-black/40 border border-white/5 rounded-full py-1 pl-7 pr-2 text-[10px] text-white focus:outline-none focus:border-white/20" placeholder="Search..." />
                </div>
                <button className="text-neutral-400 hover:text-white"><MoreHorizontal className="w-3 h-3" /></button>
            </div>
            <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
                {emails.map(email => (
                    <div key={email.id} className={cn(
                        "p-3 border-b border-white/5 hover:bg-white/5 transition-colors cursor-pointer group relative",
                        email.unread ? "bg-white/[0.02]" : ""
                    )}>
                        {email.unread && <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-[hsl(var(--color-intent))]" />}
                        <div className="flex justify-between items-start mb-0.5">
                            <span className={cn("text-xs truncate", email.unread ? "font-bold text-white" : "text-neutral-400")}>{email.from}</span>
                            <span className="text-[9px] text-neutral-600 shrink-0 ml-2">{email.time}</span>
                        </div>
                        <div className={cn("text-xs truncate mb-1", email.unread ? "text-neutral-200" : "text-neutral-500")}>{email.subject}</div>
                        <div className="text-[10px] text-neutral-500 truncate group-hover:text-neutral-400 transition-colors">{email.preview}</div>
                    </div>
                ))}
            </div>
            <div className="p-2 border-t border-white/5 bg-black/20 flex justify-end">
                <button className="text-[10px] font-bold text-[hsl(var(--color-intent))] hover:underline flex items-center gap-1">
                    View All <Mail className="w-3 h-3" />
                </button>
            </div>
        </div>
    );
}