import React, { useState, useEffect } from 'react';
import { Search, Grid, Clock, ChevronRight, Power, Settings, User, Pin, Star, Layout, Box, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Enhanced App Card
const AppCard = ({ app, onClick, variant = "grid" }) => {
    if (variant === "list") {
        return (
            <button
                onClick={onClick}
                className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-white/10 transition-colors group text-left"
            >
                <div className={cn(
                    "w-8 h-8 rounded-md flex items-center justify-center shadow-md",
                    app.theme ? `bg-${app.theme}` : "bg-neutral-800"
                )}>
                    {app.icon ? <app.icon className="w-4 h-4 text-white" /> : <Grid className="w-4 h-4 text-white" />}
                </div>
                <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-neutral-200 group-hover:text-white truncate">{app.name}</div>
                    <div className="text-[10px] text-neutral-500 truncate">{app.description || "Application"}</div>
                </div>
            </button>
        );
    }

    return (
        <motion.button
            whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.08)' }}
            whileTap={{ scale: 0.98 }}
            onClick={onClick}
            className="flex flex-col items-center justify-center p-3 rounded-xl transition-all group relative border border-transparent hover:border-white/5"
        >
            <div className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center mb-2 shadow-lg transition-transform bg-gradient-to-br from-neutral-800 to-neutral-900 border border-white/10",
                app.theme ? `shadow-${app.theme}/20` : "",
                "group-hover:shadow-xl group-hover:translate-y-[-2px]"
            )}>
                {app.icon ? <app.icon className={cn("w-6 h-6", app.theme ? `text-${app.theme}` : "text-white")} /> : <Grid className="w-6 h-6 text-white" />}
            </div>
            <span className="text-[11px] font-medium text-neutral-300 group-hover:text-white text-center line-clamp-1 w-full px-1">
                {app.name}
            </span>
        </motion.button>
    );
};

export default function StartMenu({ isOpen, onClose, apps = [], onLaunch }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [viewMode, setViewMode] = useState('pinned'); // 'pinned' or 'all'

    // Separate apps into Pinned (favorites) and Recommended (recent)
    // For demo, we just slice the list
    const pinnedApps = apps.slice(0, 12);
    const recommendedApps = apps.slice(0, 6); // Mock recent

    const filteredApps = apps.filter(app => 
        app.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Sort apps: Pinned/Important first
    const sortedPinned = [...apps].sort((a, b) => {
        // Just a simple alphabetical sort for now, or custom logic
        return a.name.localeCompare(b.name);
    }).slice(0, 18); // Show more apps

    return (
        <AnimatePresence>
            {isOpen && (
                <>
                    {/* Backdrop - Click to close */}
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="fixed inset-0 z-[100] bg-transparent" // Transparent to simulate OS feel, click outside closes
                    />

                    {/* Start Menu Floating Panel */}
                    <motion.div
                        initial={{ opacity: 0, y: 12, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 12, scale: 0.98 }}
                        transition={{ duration: 0.2, ease: "easeOut" }}
                        className="fixed bottom-16 left-1/2 -translate-x-1/2 z-[101] w-[640px] h-[650px] bg-[#1a1a1a]/80 backdrop-blur-3xl border border-white/10 rounded-xl shadow-[0_0_50px_rgba(0,0,0,0.5)] flex flex-col overflow-hidden"
                    >
                        {/* Search Bar - Top */}
                        <div className="p-6 pb-2 shrink-0">
                            <div className="relative group">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 group-focus-within:text-[hsl(var(--color-execution))]" />
                                <input
                                    type="text"
                                    placeholder="Search apps, files, and settings..."
                                    className="w-full bg-[#2a2a2a]/50 hover:bg-[#2a2a2a] border border-transparent focus:border-[hsl(var(--color-execution))]/30 rounded-full pl-10 pr-4 py-3 text-sm text-white placeholder:text-neutral-500 focus:outline-none focus:ring-0 transition-all shadow-inner"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    autoFocus
                                />
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto xi-scroll px-6 py-2">
                            {searchTerm ? (
                                <div className="space-y-2">
                                    <div className="text-xs font-semibold text-neutral-500 mb-2">Search Results</div>
                                    {filteredApps.length > 0 ? (
                                        filteredApps.map((app, idx) => (
                                            <AppCard key={app.id || idx} app={app} onClick={() => { onLaunch(app); onClose(); }} variant="list" />
                                        ))
                                    ) : (
                                        <div className="text-center py-10 text-neutral-500">No results found.</div>
                                    )}
                                </div>
                            ) : (
                                <>
                                    {/* Pinned Section */}
                                    <div className="mb-8">
                                        <div className="flex items-center justify-between mb-3 px-2">
                                            <div className="text-xs font-bold text-neutral-400 flex items-center gap-2">
                                                Pinned <Pin className="w-3 h-3" />
                                            </div>
                                            <button 
                                                className="text-[10px] bg-white/5 hover:bg-white/10 px-2 py-1 rounded text-neutral-400 transition-colors flex items-center gap-1"
                                                onClick={() => setViewMode(viewMode === 'all' ? 'pinned' : 'all')}
                                            >
                                                {viewMode === 'all' ? 'Back' : 'All Apps'} <ChevronRight className="w-3 h-3" />
                                            </button>
                                        </div>
                                        
                                        {viewMode === 'pinned' ? (
                                            <div className="grid grid-cols-6 gap-2">
                                                {sortedPinned.map((app, idx) => (
                                                    <AppCard key={app.id || idx} app={app} onClick={() => { onLaunch(app); onClose(); }} />
                                                ))}
                                            </div>
                                        ) : (
                                            <div className="space-y-1">
                                                 {apps.map((app, idx) => (
                                                    <AppCard key={app.id || idx} app={app} onClick={() => { onLaunch(app); onClose(); }} variant="list" />
                                                ))}
                                            </div>
                                        )}
                                    </div>

                                    {/* Recommended Section */}
                                    <div className="mb-4">
                                        <div className="flex items-center justify-between mb-3 px-2">
                                            <div className="text-xs font-bold text-neutral-400 flex items-center gap-2">
                                                Recommended <Clock className="w-3 h-3" />
                                            </div>
                                            <button className="text-[10px] text-neutral-500 hover:text-white transition-colors">More</button>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4">
                                            {recommendedApps.map((app, idx) => (
                                                <button 
                                                    key={`rec-${idx}`}
                                                    onClick={() => { onLaunch(app); onClose(); }}
                                                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors group text-left"
                                                >
                                                    <div className="w-10 h-10 rounded bg-white/5 border border-white/5 flex items-center justify-center group-hover:bg-white/10">
                                                        {app.icon ? <app.icon className="w-5 h-5 text-neutral-300" /> : <Layout className="w-5 h-5 text-neutral-300" />}
                                                    </div>
                                                    <div className="min-w-0">
                                                        <div className="text-xs font-medium text-neutral-200 group-hover:text-white truncate">{app.name}</div>
                                                        <div className="text-[10px] text-neutral-500 truncate">Recently added</div>
                                                    </div>
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                </>
                            )}
                        </div>

                        {/* Footer Bar */}
                        <div className="h-16 bg-[#151515]/80 border-t border-white/5 flex items-center justify-between px-8 shrink-0 backdrop-blur-md">
                            <button className="flex items-center gap-3 hover:bg-white/5 -ml-2 px-3 py-2 rounded-lg transition-colors group">
                                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-600 to-blue-600 border border-white/10 flex items-center justify-center shadow-lg">
                                    <span className="font-bold text-xs text-white">XI</span>
                                </div>
                                <div className="text-left">
                                    <div className="text-xs font-medium text-white group-hover:text-purple-300 transition-colors">Admin User</div>
                                </div>
                            </button>

                            <div className="flex items-center gap-1">
                                <Button variant="ghost" size="icon" className="w-9 h-9 text-neutral-400 hover:text-white hover:bg-white/10 rounded-lg">
                                    <Settings className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="icon" className="w-9 h-9 text-neutral-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg ml-2">
                                    <Power className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    </motion.div>
                </>
            )}
        </AnimatePresence>
    );
}