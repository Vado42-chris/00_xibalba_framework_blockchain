import React, { useState, useEffect, useRef } from 'react';
import { motion, useDragControls } from 'framer-motion';
import { X, Minus, Maximize2, Minimize2, GripVertical, Settings, Layout, Command, Cpu, Database, Activity, GitBranch, Layers, Pin } from 'lucide-react';
import StandardProgramMenu from '@/components/ui/design-system/StandardProgramMenu';
import { cn } from "@/lib/utils";

// Rune Icons (Styled Lucide)
const Rune = ({ icon: Icon, active, color }) => (
    <div className={cn(
        "w-10 h-10 rounded-lg flex items-center justify-center transition-all duration-300 relative group cursor-pointer",
        active 
            ? "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))] shadow-[0_0_15px_-3px_hsl(var(--color-intent))]" 
            : "text-neutral-500 hover:text-neutral-200 hover:bg-white/5"
    )}>
        <Icon className="w-5 h-5 stroke-[1.5]" />
        {active && <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[hsl(var(--color-intent))] rounded-l-full shadow-[0_0_10px_hsl(var(--color-intent))]" />}
    </div>
);

export default function WindowFrame({ title, icon: Icon, theme, children, onClose, onMinimize, isActive, onFocus, initialPosition, ...props }) {
    const [isMaximized, setIsMaximized] = useState(false);
    const [size, setSize] = useState({ width: 1000, height: 700 });
    const dragControls = useDragControls();
    
    // Use internal state if no props provided, otherwise controllable
    const [internalActiveTab, setInternalActiveTab] = useState('main');
    
    // Props for tabs: tabs=[{ id: 'home', icon: Icon, label: 'Home' }]
    const currentTab = isActive ? (props.activeTab || internalActiveTab) : (internalActiveTab);
    const handleTabChange = (tabId) => {
        setInternalActiveTab(tabId);
        if (props.onTabChange) props.onTabChange(tabId);
    };

    const tabs = props.tabs || [
        { id: 'main', icon: Layers, label: 'Main' },
        { id: 'data', icon: Database, label: 'Data' },
        { id: 'git', icon: GitBranch, label: 'Version Control' },
        { id: 'cpu', icon: Cpu, label: 'System' }
    ];

    // Resize Logic
    const resizeRef = useRef(null);
    const isResizing = useRef(false);

    const startResize = (e, direction) => {
        e.preventDefault();
        e.stopPropagation();
        isResizing.current = true;
        
        const startX = e.clientX;
        const startY = e.clientY;
        const startWidth = size.width;
        const startHeight = size.height;

        // Create overlay to catch all mouse events during resize
        const overlay = document.createElement('div');
        overlay.style.position = 'fixed';
        overlay.style.top = '0';
        overlay.style.left = '0';
        overlay.style.right = '0';
        overlay.style.bottom = '0';
        overlay.style.zIndex = '9999';
        overlay.style.cursor = direction === 'right' ? 'e-resize' : direction === 'bottom' ? 's-resize' : 'se-resize';
        document.body.appendChild(overlay);

        const handleMouseMove = (moveEvent) => {
            if (!isResizing.current) return;
            
            let newWidth = startWidth;
            let newHeight = startHeight;

            if (direction.includes('right')) {
                newWidth = Math.max(400, startWidth + (moveEvent.clientX - startX));
            }
            if (direction.includes('bottom')) {
                newHeight = Math.max(300, startHeight + (moveEvent.clientY - startY));
            }
            
            setSize({ width: newWidth, height: newHeight });
        };

        const handleMouseUp = () => {
            isResizing.current = false;
            document.removeEventListener('mousemove', handleMouseMove);
            document.removeEventListener('mouseup', handleMouseUp);
            document.body.removeChild(overlay);
        };

        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
    };

    return (
        <motion.div
            drag={!isMaximized}
            dragControls={dragControls}
            dragMomentum={false}
            dragListener={false}
            initial={{ opacity: 0, scale: 0.9, x: initialPosition?.x || 100, y: initialPosition?.y || 100, rotateX: 5 }}
            animate={{ 
                opacity: 1, 
                scale: 1,
                rotateX: 0,
                width: isMaximized ? "100vw" : size.width,
                height: isMaximized ? "calc(100vh - 56px)" : size.height,
                x: isMaximized ? 0 : undefined,
                y: isMaximized ? 56 : undefined,
                zIndex: props.zIndex || (isActive ? 50 : 10),
                borderRadius: isMaximized ? 0 : 20
            }}
            exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
            onPointerDown={onFocus}
            className={cn(
                "absolute flex overflow-hidden backdrop-blur-3xl",
                "bg-[#050508]/80", 
                isActive 
                    ? cn("border shadow-[0_20px_60px_-20px_rgba(0,0,0,0.8),0_0_0_1px_rgba(255,255,255,0.05)]", theme ? `border-${theme}/50` : "border-[hsl(var(--color-intent))]/30")
                    : "border border-white/5 shadow-[0_20px_50px_-20px_rgba(0,0,0,0.8)] opacity-90 grayscale-[0.5]"
            )}
        >
            {/* RESIZE HANDLES - THICKER HIT AREA */}
            {!isMaximized && (
                <>
                    {/* Right Handle */}
                    <div 
                        className="absolute -right-1 top-0 bottom-4 w-4 cursor-e-resize z-50 hover:bg-blue-500/20 transition-colors" 
                        onMouseDown={(e) => startResize(e, 'right')} 
                    />
                    {/* Bottom Handle */}
                    <div 
                        className="absolute -bottom-1 left-0 right-4 h-4 cursor-s-resize z-50 hover:bg-blue-500/20 transition-colors" 
                        onMouseDown={(e) => startResize(e, 'bottom')} 
                    />
                    {/* Corner Handle */}
                    <div 
                        className="absolute right-0 bottom-0 w-6 h-6 cursor-se-resize z-50 hover:bg-blue-500/20 rounded-tl-lg bg-white/5 transition-colors" 
                        onMouseDown={(e) => startResize(e, 'right-bottom')} 
                    />
                </>
            )}

            {/* LEFT RAIL - THE GLYPH PANEL */}
            <div 
                className="w-16 border-r border-white/5 flex flex-col items-center py-6 gap-6 z-20 shrink-0 relative bg-black/20"
                onPointerDown={(e) => {
                    onFocus(e);
                    if (!isMaximized) dragControls.start(e);
                }}
            >
                {/* Drag Area - Colored */}
                <div className={cn(
                    "absolute inset-x-0 top-0 h-full cursor-grab active:cursor-grabbing transition-colors",
                    theme ? `bg-${theme}/5 hover:bg-${theme}/10` : "hover:bg-white/5"
                )} />

                {/* App Glyph */}
                <div className="mt-2 mb-4 relative group/glyph">
                    <div className={cn("absolute inset-0 blur-xl opacity-20", theme ? `bg-${theme}` : "bg-[hsl(var(--color-intent))]")} />
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-white/10 to-transparent border border-white/10 flex items-center justify-center text-white relative z-10 transition-transform group-hover/glyph:scale-110">
                        {Icon ? <Icon className="w-5 h-5" /> : <Layout className="w-5 h-5" />}
                    </div>
                    {/* Tooltip Title */}
                    <div className="absolute left-14 top-1/2 -translate-y-1/2 px-2 py-1 bg-black/90 border border-white/10 rounded text-xs font-bold text-white opacity-0 group-hover/glyph:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                        {title}
                    </div>
                </div>

                {/* Navigation Runes */}
                <div className="flex flex-col gap-2 w-full px-2">
                    {tabs.map(tab => (
                        <div key={tab.id} onClick={() => handleTabChange(tab.id)}>
                            <Rune 
                                icon={tab.icon} 
                                active={currentTab === tab.id} 
                                color={tab.color}
                            />
                        </div>
                    ))}
                </div>

                <div className="flex-1" />

                {/* Window Controls */}
                <div className="flex flex-col gap-3 w-full px-3 pb-4" onPointerDown={(e) => e.stopPropagation()}>
                    {props.onPin && (
                        <button onClick={props.onPin} className="w-10 h-10 rounded-full hover:bg-[hsl(var(--color-intent))]/10 flex items-center justify-center text-neutral-500 hover:text-[hsl(var(--color-intent))] transition-colors" title="Pin to Desktop">
                            <Pin className="w-4 h-4" />
                        </button>
                    )}
                    <button onClick={onMinimize} className="w-10 h-10 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-500 hover:text-white transition-colors" title="Minimize">
                        <Minus className="w-4 h-4" />
                    </button>
                    <button onClick={() => setIsMaximized(!isMaximized)} className="w-10 h-10 rounded-full hover:bg-white/10 flex items-center justify-center text-neutral-500 hover:text-white transition-colors" title={isMaximized ? "Restore" : "Maximize"}>
                        {isMaximized ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                    </button>
                    <button onClick={onClose} className="w-10 h-10 rounded-full hover:bg-red-500/20 flex items-center justify-center text-neutral-500 hover:text-red-500 transition-colors" title="Close">
                        <X className="w-4 h-4" />
                    </button>
                </div>
            </div>

            {/* MAIN CONTENT SURFACE */}
            <div className="flex-1 relative flex flex-col">
                {/* TOP DRAG HANDLE - INVISIBLE BUT FUNCTIONAL */}
                <div 
                    className="h-8 w-full absolute top-0 left-0 right-0 z-40 cursor-grab active:cursor-grabbing"
                    onPointerDown={(e) => {
                        onFocus(e);
                        if (!isMaximized) dragControls.start(e);
                    }}
                />

                {/* Top Shine */}
                <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-50" />
                
                {/* Standard App Menu Bar */}
                <div className="absolute top-2 right-2 z-50 pointer-events-auto">
                    <StandardProgramMenu 
                        appName={title}
                        onSave={() => console.log('Save triggered')}
                        onOpen={() => console.log('Open triggered')}
                        className="opacity-50 hover:opacity-100 transition-opacity"
                    />
                </div>

                {/* Content Container */}
                <div className="flex-1 overflow-hidden relative bg-gradient-to-br from-white/[0.02] to-transparent">
                    {children}
                </div>

                {/* Status Footer */}
                <div className="h-8 border-t border-white/5 bg-black/40 flex items-center px-4 justify-between text-[10px] font-mono text-neutral-600 uppercase tracking-widest select-none">
                    <div className="flex items-center gap-4">
                        <span className="flex items-center gap-2"><div className="w-1 h-1 bg-green-500 rounded-full" /> ONLINE</span>
                        <span>LATENCY: 12ms</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <span>SECURE CONTEXT</span>
                        <Settings className="w-3 h-3" />
                    </div>
                </div>
            </div>
        </motion.div>
    );
}