// Registry to map widget types to components
import { CalendarWidget, DayPlannerWidget, SocialWidget, EmailWidget } from './StandardWidgets';
import SpotifyWidget from './widgets/SpotifyWidget';
import CodePulseWidget from './widgets/CodePulseWidget';
import { HoloClock, NodeMonitor, AgentSwarm, SystemStatus } from './DesktopWidgets';
import WidgetBase from './widgets/WidgetBase';

export const WIDGET_REGISTRY = {
    'clock': { component: HoloClock, title: 'CHRONOS', defaultSize: 'md' },
    'node-monitor': { component: NodeMonitor, title: 'NODES', defaultSize: 'sm' },
    'agent-swarm': { component: AgentSwarm, title: 'SWARM', defaultSize: 'sm' },
    'system-status': { component: SystemStatus, title: 'STATUS', defaultSize: 'sm' },
    'spotify': { component: SpotifyWidget, title: 'SOUND ENGINE', defaultSize: 'sm', customWrapper: true },
    'code-pulse': { component: CodePulseWidget, title: 'CODE PULSE', defaultSize: 'md', customWrapper: true },
    'calendar': { component: CalendarWidget, title: 'CALENDAR', defaultSize: 'md' },
    'planner': { component: DayPlannerWidget, title: 'AGENDA', defaultSize: 'md' },
    'social': { component: SocialWidget, title: 'CONNECT', defaultSize: 'md' },
    'email': { component: EmailWidget, title: 'COMMUNICATIONS', defaultSize: 'md' },
};

export const getWidgetComponent = (type) => {
    return WIDGET_REGISTRY[type] || null;
};