import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shield, RefreshCcw, Layout } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import SandboxedRenderer from '@/components/content/SandboxedRenderer';

// --- EDITORS ---
import CodeArchitect from '@/components/studio/editors/CodeArchitect';
import ThreeDEditor from '@/components/studio/editors/ThreeDEditor';
import VideoEditor from '@/components/studio/editors/VideoEditor';
import DocumentEditor from '@/components/studio/editors/DocumentEditor';
import MobileAppEditor from '@/components/studio/editors/MobileAppEditor';
import SoundEditor from '@/components/studio/editors/SoundEditor';
import MagazineEditor from '@/components/studio/editors/MagazineEditor';
import SpreadsheetEditor from '@/components/studio/editors/SpreadsheetEditor';
import StoreEditor from '@/components/studio/editors/StoreEditor';
import BlogEditor from '@/components/studio/editors/BlogEditor';
import BrowserEditor from '@/components/studio/editors/BrowserEditor';
import DatabaseEditor from '@/components/studio/editors/DatabaseEditor';
import EmailDesigner from '@/components/studio/editors/EmailClient';
import UnifiedCanvas from '@/components/studio/UnifiedCanvas';
import ChatInterface from '@/components/studio/editors/code/ChatInterface';
import AgentOrchestrator from '@/components/studio/editors/code/AgentOrchestrator';
import { Box } from 'lucide-react';


// --- EMPIRE SUITE ---
import GatewayLanding from '@/pages/Home';
import SearchResults from '@/pages/SearchResults';
import Dashboard from '@/pages/Dashboard';
import Intelligence from '@/pages/Intelligence';
import CRM from '@/pages/CRM';
import Communications from '@/pages/Communications';
import Commerce from '@/pages/Commerce';
import Finance from '@/pages/Finance';
import Archives from '@/pages/Archives';
import Legal from '@/pages/Legal';

// --- STRATEGY SUITE ---
import BusinessPlan from '@/pages/BusinessPlan';
import Enterprise from '@/pages/Enterprise';
import Automation from '@/pages/Automation';
import Integrations from '@/pages/Integrations';
import Marketplace from '@/pages/Marketplace';

// --- OPERATIONS HUB ---
import WorkRoom from '@/pages/WorkRoom';
import DistroBuilder from '@/pages/DistroBuilder';
import Studio from '@/pages/Studio';
import ContentManager from '@/pages/ContentManager';
import ComponentForge from '@/pages/ComponentForge';
import Agents from '@/pages/Agents';
import Community from '@/pages/Community';
import Network from '@/pages/Network';
import Nodes from '@/pages/Nodes';

// --- LIFE OS ---
import Lifestyle from '@/pages/Lifestyle';

import FileManagerComponent from '@/components/tools/FileManager';

// --- SYSTEM CONTROL ---
import Console from '@/pages/Console';
import ReaperSpace from '@/pages/ReaperSpace';
import Identity from '@/pages/Identity';
import Settings from '@/pages/Settings';
import Audit from '@/pages/Audit';
import ServerControl from '@/pages/ServerControl';
import Installer from '@/pages/Installer';
import Docs from '@/pages/Docs';

// Map of Tab IDs to Components
const COMPONENT_MAP = {
    // Empire
    'Gateway': GatewayLanding,
    'SearchResults': SearchResults,
    'Dashboard': Dashboard,
    'Intelligence': Intelligence,
    'CRM': CRM,
    'Communications': Communications,
    'Commerce': Commerce,
    'Finance': Finance,
    'Archives': Archives,
    'Legal': Legal,

    // Strategy
    'BusinessPlan': BusinessPlan,
    'Enterprise': Enterprise,
    'Automation': Automation,
    'Integrations': Integrations,
    'Marketplace': Marketplace,

    // Operations
    'WorkRoom': WorkRoom,
    'DistroBuilder': DistroBuilder,
    'Studio': Studio,
    'ContentManager': ContentManager,
    'ComponentForge': ComponentForge,
    'Agents': Agents,
    'Community': Community,
    'Network': Network,
    'Nodes': Nodes,

    // Life
    'Lifestyle': Lifestyle,

    // Control
    'Console': Console,
    'ReaperSpace': ReaperSpace,
    'Identity': Identity,
    'Settings': Settings,
    'Audit': Audit,
    'ServerControl': ServerControl,
    'Installer': Installer,
    'Docs': Docs,
    'FileManager': FileManagerComponent // Add direct mapping
};

export default function ObsidianTabletContent({ appId, activeTab, manifest }) {
    // 1. Dynamic/Sandboxed App (from Forge)
    if (manifest?.code) {
        return (
            <div className="w-full h-full overflow-hidden bg-neutral-950">
                <SandboxedRenderer 
                    id={`app-${appId}`}
                    html={manifest.code} 
                    className="w-full h-full"
                />
            </div>
        );
    }

    // 2. Editors (Product IDs)
    const EDITOR_MAP = {
        'FileManager': FileManagerComponent,
        'web': () => <UnifiedCanvas items={[]} activeTool="select" scale={1} viewportWidth="100%" />,
        'architect': CodeArchitect,
        'mobile': MobileAppEditor,
        'document': DocumentEditor,
        'sheet': SpreadsheetEditor,
        'layout': MagazineEditor,
        'sound': SoundEditor,
        'video': VideoEditor,
        '3d': ThreeDEditor,
        'store': StoreEditor,
        'blog': BlogEditor,
        'browser': BrowserEditor,
        'database': DatabaseEditor,
        'mail': EmailDesigner,
        'chat': ChatInterface,
        'agents': AgentOrchestrator,
        'cad': () => <UnifiedCanvas items={[]} activeTool="select" scale={1} viewportWidth="100%" />,
        'vector': () => <UnifiedCanvas items={[]} activeTool="select" scale={1} viewportWidth="100%" />,
        // Legacy/Duplicate mappings for older config
        'Os': DocumentEditor,
        'Og': SpreadsheetEditor,
        'Mp': MagazineEditor,
        'Al': SoundEditor,
        'Cn': VideoEditor,
        'Vf': ThreeDEditor,
        'Af': MobileAppEditor,
        'Wa': () => <UnifiedCanvas items={[]} activeTool="select" scale={1} viewportWidth="100%" />
    };

    if (EDITOR_MAP[appId]) {
        const Component = EDITOR_MAP[appId];
        return (
            <div className="w-full h-full overflow-hidden bg-transparent">
                <Component file={{ name: 'Untitled Project', type: appId }} />
            </div>
        );
    }

    // 3. If we have an active tab (Sub-App Mode), render that
    if (activeTab && COMPONENT_MAP[activeTab]) {
        const Component = COMPONENT_MAP[activeTab];
        return (
            <div className="w-full h-full overflow-hidden bg-transparent">
                <Component />
            </div>
        );
    }

    // 4. Fallback for legacy appIds if any (Standard App Mode)
    if (COMPONENT_MAP[appId]) {
        const Component = COMPONENT_MAP[appId];
        return (
            <div className="w-full h-full overflow-hidden bg-transparent">
                <Component />
            </div>
        );
    }

    // 4. Last Resort
    return <LegacySummoner appId={appId} />;
}

// Keeping the old logic as fallback
function LegacySummoner({ appId }) {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const summon = async () => {
        setLoading(true);
        setError(null);
        try {
            const cleanId = appId.replace('/', '');
            const targetId = cleanId;

            // Mock response if function fails or for quick UI
            // In real app, this calls the backend
            // For now, let's just show a generic "Not Found" or try to map loosely
            
            // Simulating a fetch
            await new Promise(r => setTimeout(r, 500));
            
            // If we are here, it means it's an unknown app ID
            throw new Error(`Unknown Artifact: ${appId}`);

        } catch (e) {
            console.error("Summoning failed:", e);
            setError(e.message || "Failed to summon artifact");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        summon();
    }, [appId]);

    if (loading) {
        return (
            <div className="w-full h-full flex items-center justify-center">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-12 h-12 border-4 border-[hsl(var(--color-intent))] border-t-transparent rounded-full animate-spin" />
                    <span className="text-xs font-mono text-[hsl(var(--color-intent))] tracking-widest animate-pulse">SUMMONING ARTIFACT...</span>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="w-full h-full flex flex-col items-center justify-center text-red-500 gap-4">
                <Shield className="w-12 h-12" />
                <span className="font-mono uppercase tracking-widest">RITUAL FAILED</span>
                <span className="text-xs text-red-400/50">{error}</span>
                <button onClick={summon} className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 rounded border border-red-500/30 text-xs transition-colors flex items-center gap-2">
                    <RefreshCcw className="w-3 h-3" /> RETRY
                </button>
            </div>
        );
    }

    return null;
}