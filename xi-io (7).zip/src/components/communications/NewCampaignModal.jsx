import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from "sonner";
import { 
  Sparkles, ArrowRight, Check, Loader2, 
  Mail, MessageSquare, Megaphone, Share2 
} from 'lucide-react';
import { 
  OrientingText, IntentText, StateText, SemanticDot, AtomicParagraph 
} from '@/components/ui/design-system/SystemDesign';
import { cn } from '@/lib/utils';

export default function NewCampaignModal({ open, onOpenChange }) {
  const [step, setStep] = useState(1);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [formData, setFormData] = useState({ name: '', description: '', type: 'email' });
  
  const queryClient = useQueryClient();

  // Fetch Templates
  const { data: templates = [] } = useQuery({
    queryKey: ['campaignTemplates'],
    queryFn: async () => {
        try {
            if (base44.entities.CampaignTemplate) {
                return await base44.entities.CampaignTemplate.list();
            }
            return [];
        } catch (e) {
            console.error("Failed to fetch templates", e);
            return [];
        }
    },
    initialData: []
  });

  const createCampaignMutation = useMutation({
    mutationFn: async () => {
      return await base44.entities.Campaign.create({
        name: formData.name,
        type: formData.type,
        status: 'active',
        reach: Math.floor(Math.random() * 10000),
        conversion_rate: parseFloat((Math.random() * 5).toFixed(1))
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['campaigns']);
      toast.success("Campaign initialized successfully");
      onOpenChange(false);
      resetForm();
    },
    onError: () => {
      toast.error("Failed to initialize campaign");
    }
  });

  const resetForm = () => {
    setStep(1);
    setSelectedTemplate(null);
    setFormData({ name: '', description: '', type: 'email' });
  };

  const handleNext = () => {
    if (step === 1 && selectedTemplate) {
      setFormData(prev => ({
        ...prev,
        type: selectedTemplate.type === 'mixed' ? 'email' : selectedTemplate.type
      }));
      setStep(2);
    }
  };

  const getIcon = (type) => {
    switch(type) {
      case 'email': return Mail;
      case 'sms': return MessageSquare;
      case 'social': return Share2;
      case 'ad': return Megaphone;
      default: return Sparkles;
    }
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { onOpenChange(val); if(!val) resetForm(); }}>
      <DialogContent className="max-w-3xl bg-neutral-950 border-white/10 text-white p-0 overflow-hidden flex flex-col h-[600px] max-h-[85vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-white/10 bg-neutral-900">
            <DialogTitle className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                <span className="font-light tracking-wide">LAUNCH CAMPAIGN</span>
            </DialogTitle>
            <div className="flex items-center gap-2 mt-2">
                <div className={cn("h-1 w-8 rounded-full transition-colors", step >= 1 ? "bg-[hsl(var(--color-intent))]" : "bg-neutral-800")} />
                <div className={cn("h-1 w-8 rounded-full transition-colors", step >= 2 ? "bg-[hsl(var(--color-intent))]" : "bg-neutral-800")} />
            </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-neutral-950">
            {step === 1 ? (
                <div className="space-y-6">
                    <div className="text-center space-y-2 mb-8">
                        <OrientingText>SELECT STRATEGY</OrientingText>
                        <IntentText className="text-xl">Choose a campaign blueprint.</IntentText>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div 
                            onClick={() => setSelectedTemplate({ id: 'blank', name: 'Blank Canvas', description: 'Start from scratch.', type: 'email' })}
                            className={cn(
                                "p-4 rounded border cursor-pointer transition-all hover:border-[hsl(var(--color-intent))]/50 group relative",
                                selectedTemplate?.id === 'blank' ? "bg-neutral-800 border-[hsl(var(--color-intent))]" : "bg-neutral-900 border-white/5"
                            )}
                        >
                             <div className="flex justify-between items-start mb-2">
                                <Sparkles className="w-6 h-6 text-neutral-500 group-hover:text-[hsl(var(--color-intent))]" />
                                {selectedTemplate?.id === 'blank' && <Check className="w-4 h-4 text-[hsl(var(--color-intent))]" />}
                             </div>
                             <IntentText className="font-bold">Blank Canvas</IntentText>
                             <StateText className="opacity-60 mt-1">Empty campaign structure.</StateText>
                        </div>

                        {templates.map(template => {
                            const Icon = getIcon(template.type);
                            return (
                                <div 
                                    key={template.id}
                                    onClick={() => setSelectedTemplate(template)}
                                    className={cn(
                                        "p-4 rounded border cursor-pointer transition-all hover:border-[hsl(var(--color-intent))]/50 group relative",
                                        selectedTemplate?.id === template.id ? "bg-neutral-800 border-[hsl(var(--color-intent))]" : "bg-neutral-900 border-white/5"
                                    )}
                                >
                                    <div className="flex justify-between items-start mb-2">
                                        <Icon className="w-6 h-6 text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--color-intent))]" />
                                        {selectedTemplate?.id === template.id && <Check className="w-4 h-4 text-[hsl(var(--color-intent))]" />}
                                    </div>
                                    <IntentText className="font-bold">{template.name}</IntentText>
                                    <StateText className="opacity-60 mt-1">{template.description}</StateText>
                                </div>
                            );
                        })}
                    </div>
                </div>
            ) : (
                <div className="max-w-md mx-auto space-y-6 py-8">
                    <div className="text-center space-y-2 mb-8">
                        <OrientingText>CONFIGURE PARAMETERS</OrientingText>
                        <IntentText className="text-xl">Define your campaign identity.</IntentText>
                    </div>

                    <div className="space-y-4">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Campaign Name</label>
                            <Input 
                                autoFocus
                                placeholder="e.g. Q3 Product Launch"
                                value={formData.name}
                                onChange={e => setFormData({...formData, name: e.target.value})}
                                className="bg-neutral-900 border-white/10 h-12 text-lg"
                            />
                        </div>
                        
                        <div className="pt-4 p-4 rounded bg-neutral-900 border border-white/10">
                             <div className="flex items-center gap-2 mb-2">
                                <SemanticDot type="active" />
                                <StateText className="font-bold">Template Summary</StateText>
                             </div>
                             <AtomicParagraph className="text-[10px] opacity-70">
                                Based on <span className="text-[hsl(var(--color-intent))]">{selectedTemplate?.name}</span>. 
                                Default type set to <span className="font-mono uppercase">{formData.type}</span>.
                             </AtomicParagraph>
                        </div>
                    </div>
                </div>
            )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/10 bg-neutral-900 flex justify-between">
            {step === 2 ? (
                <Button variant="ghost" onClick={() => setStep(1)} className="text-neutral-500 hover:text-white">Back</Button>
            ) : (
                <div />
            )}
            
            {step === 1 ? (
                <Button 
                    onClick={handleNext} 
                    disabled={!selectedTemplate}
                    className="bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white w-32"
                >
                    Next <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
            ) : (
                <Button 
                    onClick={() => createCampaignMutation.mutate()} 
                    disabled={createCampaignMutation.isPending || !formData.name}
                    className="bg-[hsl(var(--color-active))] hover:bg-[hsl(var(--color-active))]/90 text-black font-bold w-32"
                >
                    {createCampaignMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Launch'}
                </Button>
            )}
        </div>

      </DialogContent>
    </Dialog>
  );
}