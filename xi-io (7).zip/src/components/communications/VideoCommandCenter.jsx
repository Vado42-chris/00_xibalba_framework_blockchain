import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Mic, MicOff, Video, VideoOff, PhoneOff, 
    Maximize2, Minimize2, MoreVertical, GripHorizontal,
    Users, Shield, Signal, Wifi, Activity,
    LayoutGrid, Layers, Square, Monitor, Move,
    Grid, Sidebar, Search, Cpu, Zap, FileText, Brain
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { OrientingText } from '@/components/ui/design-system/SystemDesign';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import DepthBackground from '@/components/ui/design-system/DepthBackground';
import { toast } from 'sonner';

const MOCK_PARTICIPANTS = [
    { id: 'p1', name: 'Ops Commander', role: 'Admin', status: 'active', audio: true, video: true, signal: 98, img: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&h=400&fit=crop' },
    { id: 'p2', name: 'Field Agent 7', role: 'Scout', status: 'active', audio: true, video: false, signal: 85, img: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=400&h=400&fit=crop' },
    { id: 'p3', name: 'Sarah Chen', role: 'Analyst', status: 'active', audio: false, video: true, signal: 92, img: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop' },
    { id: 'p4', name: 'Dev Team', role: 'Unit', status: 'active', audio: true, video: true, signal: 100, img: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=400&h=400&fit=crop' },
    { id: 'p5', name: 'Nexus AI', role: 'Bot', status: 'idle', audio: false, video: true, signal: 100, img: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=400&h=400&fit=crop' },
];

const VerticalChatStream = () => {
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        const interval = setInterval(() => {
            const newMsg = {
                id: Date.now(),
                user: ['Ops', 'Scout', 'Unit', 'AI'][Math.floor(Math.random() * 4)],
                text: [
                    "Sector 7 status update: Clear",
                    "Breach detected in Quadrant 4",
                    "Requesting immediate backup",
                    "Signal lost on channel 9",
                    "Rerouting power to grid",
                    "Data packet received",
                    "Encryption key rotation complete",
                    "Uplink stability at 99%"
                ][Math.floor(Math.random() * 8)]
            };
            setMessages(prev => [newMsg, ...prev].slice(0, 8)); 
        }, 2500);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="absolute left-8 top-20 bottom-20 w-80 pointer-events-none z-0 flex flex-col justify-start gap-6 overflow-hidden mask-image-linear-gradient-to-b">
             <AnimatePresence mode='popLayout'>
                {messages.map((msg, i) => (
                    <motion.div
                        key={msg.id}
                        layout
                        initial={{ opacity: 0, y: -50, scale: 0.9 }}
                        animate={{ opacity: 1 - (i * 0.1), y: 0, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                        className="flex flex-col gap-1"
                    >
                        <div className="flex items-center gap-2 text-[10px] font-mono opacity-50 text-white uppercase tracking-widest">
                            <span className="w-1.5 h-1.5 bg-white rounded-full" />
                            {msg.user} • {new Date(msg.id).toLocaleTimeString()}
                        </div>
                        <div className="text-xl font-light text-white leading-tight tracking-wide font-sans pl-3.5 border-l border-white/20">
                            {msg.text}
                        </div>
                    </motion.div>
                ))}
             </AnimatePresence>
        </div>
    );
};

const MOCK_SEARCH_RESULTS = [
    { id: 101, sourceId: 'p1', type: 'voice', sector: 7, title: "Command Override Authorization", content: "Verified command codes for sector 7 access. Signal integrity nominal. Requesting immediate perimeter sweep.", timestamp: "2025-12-15T14:30:00Z", confidence: 0.99 },
    { id: 102, sourceId: 'p2', type: 'video', sector: 9, title: "Perimeter Breach Detected", content: "Visual confirmation of anomaly in Sector 9. Unknown entities attempting bypass of firewall layer 3.", timestamp: "2025-12-15T14:32:15Z", confidence: 0.85 },
    { id: 103, sourceId: 'p5', type: 'signal', sector: 12, title: "Neural Link Calibration", content: "Automatic recalibration of uplink nodes. 98% efficiency achieved. Latency dropped to 12ms.", timestamp: "2025-12-15T14:35:00Z", confidence: 0.98 },
    { id: 104, sourceId: 'p3', type: 'text', sector: 4, title: "Data Packet Intercepted", content: "Encrypted packet intercepted from unregistered source. Decrypting... Pattern matches 'Black-Ice' protocol.", timestamp: "2025-12-15T14:40:45Z", confidence: 0.92 },
    { id: 105, sourceId: 'system', type: 'alert', sector: 0, title: "System Heartbeat Irregularity", content: "Minor fluctuation in core processor rhythm. Self-diagnostic running. No critical failures detected.", timestamp: "2025-12-15T14:45:00Z", confidence: 1.0 },
    { id: 106, sourceId: 'p4', type: 'code', sector: 2, title: "Hotfix Deployment", content: "Deploying hotfix v4.2.1 to patch render logic in visualizer. Grid stability increasing.", timestamp: "2025-12-15T14:50:10Z", confidence: 0.95 },
    { id: 107, sourceId: 'p1', type: 'voice', sector: 7, title: "Sector 7 Secure", content: "Sweep complete. Sector 7 clear. Resuming standard patrol patterns.", timestamp: "2025-12-15T15:00:00Z", confidence: 0.99 },
    { id: 108, sourceId: 'p2', type: 'video', sector: 9, title: "Artifact Recovered", content: "Recovered data shard from breach site. Uploading to secure vault for analysis.", timestamp: "2025-12-15T15:15:30Z", confidence: 0.88 },
];

const VideoWindow = ({ participant, mode = 'floating', zIndex, onFocus, onClose, className }) => {
    const isFloating = mode === 'floating';
    
    return (
        <motion.div
            drag={isFloating}
            dragMomentum={false}
            onPointerDown={isFloating ? onFocus : undefined}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            style={isFloating ? { zIndex } : {}}
            className={cn(
                "bg-neutral-900 overflow-hidden border border-white/10 shadow-2xl flex flex-col group/window",
                isFloating ? "absolute w-80 rounded-lg" : "relative w-full h-full rounded-sm",
                className
            )}
        >
            {/* Header / Drag Handle - Only show if floating */}
            {isFloating && (
                <div className="h-8 bg-neutral-800 border-b border-white/5 flex items-center justify-between px-3 cursor-grab active:cursor-grabbing group">
                    <div className="flex items-center gap-2">
                        <div className={cn("w-2 h-2 rounded-full", participant.status === 'active' ? "bg-green-500 animate-pulse" : "bg-yellow-500")} />
                        <span className="text-xs font-medium text-white">{participant.name}</span>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Signal className={cn("w-3 h-3", participant.signal > 90 ? "text-green-500" : "text-yellow-500")} />
                        <GripHorizontal className="w-4 h-4 text-neutral-500" />
                    </div>
                </div>
            )}

            {/* Video Content */}
            <div className="relative flex-1 bg-black group h-full">
                {participant.video ? (
                    <img src={participant.img} alt={participant.name} className="w-full h-full object-cover opacity-80 group-hover/window:opacity-100 transition-opacity" />
                ) : (
                    <div className="w-full h-full flex items-center justify-center bg-neutral-900">
                        <div className="w-16 h-16 rounded-full bg-neutral-800 flex items-center justify-center text-xl font-bold text-neutral-500">
                            {participant.name.charAt(0)}
                        </div>
                    </div>
                )}

                {/* Overlays */}
                <div className="absolute bottom-2 left-2 flex gap-1 z-10">
                    <div className="bg-black/50 backdrop-blur-sm px-1.5 py-0.5 rounded text-[10px] text-white flex items-center gap-1">
                        {participant.audio ? <Mic className="w-3 h-3" /> : <MicOff className="w-3 h-3 text-red-400" />}
                        {!isFloating && <span className="ml-1 max-w-[100px] truncate">{participant.name}</span>}
                    </div>
                </div>
                
                <div className="absolute top-2 right-2 opacity-0 group-hover/window:opacity-100 transition-opacity flex gap-1 z-10">
                    <button onClick={onClose} className="p-1 bg-red-500/80 hover:bg-red-500 text-white rounded">
                        <PhoneOff className="w-3 h-3" />
                    </button>
                </div>

                {/* HUD Elements */}
                <div className="absolute inset-0 border border-white/5 pointer-events-none">
                    <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-white/20" />
                    <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-white/20" />
                    <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-white/20" />
                    <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-white/20" />
                </div>
            </div>

            {/* Footer Stats - Only show if floating */}
            {isFloating && (
                <div className="px-3 py-2 bg-neutral-900 border-t border-white/5 flex justify-between items-center">
                    <Badge variant="outline" className="text-[9px] h-4 border-white/10 text-neutral-400">
                        {participant.role}
                    </Badge>
                    <div className="text-[9px] font-mono text-neutral-500">
                        {participant.signal}ms
                    </div>
                </div>
            )}
        </motion.div>
    );
};

export default function VideoCommandCenter() {
    const [participants, setParticipants] = useState(MOCK_PARTICIPANTS);
    const [zIndices, setZIndices] = useState({ 
        ...MOCK_PARTICIPANTS.reduce((acc, p) => ({ ...acc, [p.id]: 1 }), {}), 
        'search-dock': 2 
    });
    const [maxZ, setMaxZ] = useState(2);
    const [viewMode, setViewMode] = useState('floating'); // floating, grid, stack
    const [isFullScreen, setIsFullScreen] = useState(false);
    const [activeSpeakerId, setActiveSpeakerId] = useState(MOCK_PARTICIPANTS[0]?.id);
    const [searchMode, setSearchMode] = useState(false);
    const [activeTab, setActiveTab] = useState('all');
    const [searchQuery, setSearchQuery] = useState('');
    const [analyzingId, setAnalyzingId] = useState(null);
    const [selectedModelId, setSelectedModelId] = useState('default');
    const [showAnalysisModal, setShowAnalysisModal] = useState(false);
    const [analysisData, setAnalysisData] = useState(null);

    // Fetch AI Models
    const { data: aiModels = [] } = useQuery({
        queryKey: ['ai_models'],
        queryFn: async () => {
            const items = await base44.entities.MarketplaceItem.list();
            return items.filter(i => i.category === 'ai_model');
        },
        initialData: []
    });

    const filteredResults = MOCK_SEARCH_RESULTS.filter(item => {
        const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                              item.content.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesTab = activeTab === 'all' || item.sourceId === activeTab || (activeTab === 'all' && item.sourceId === 'system');
        return matchesSearch && matchesTab;
    });

    const handleAnalyze = (id) => {
        setAnalyzingId(id);
        const item = MOCK_SEARCH_RESULTS.find(r => r.id === id);
        const modelName = aiModels.find(m => m.id === selectedModelId)?.name || 'System Core';
        
        toast.info(`Initiating deep scan with ${modelName}...`);
        
        setTimeout(() => {
            setAnalyzingId(null);
            setAnalysisData({
                source: item,
                model: modelName,
                sentiment: Math.random() > 0.5 ? 'Negative' : 'Neutral',
                threatLevel: Math.floor(Math.random() * 100),
                keywords: ['Encryption', 'Protocol', 'Breach', 'Signal', 'Anomaly'].sort(() => 0.5 - Math.random()).slice(0, 3),
                summary: `AI analysis of "${item.title}" suggests correlated activity with sector ${item.sector}. Pattern matching indicates potential anomaly requiring manual review.`
            });
            setShowAnalysisModal(true);
        }, 2000);
    };

    const bringToFront = (id) => {
        if (viewMode !== 'floating') {
            setActiveSpeakerId(id); // In stack mode, clicking makes them active
            return;
        }
        const newMax = maxZ + 1;
        setMaxZ(newMax);
        setZIndices(prev => ({ ...prev, [id]: newMax }));
    };

    const removeParticipant = (id) => {
        setParticipants(prev => prev.filter(p => p.id !== id));
    };

    const addParticipant = () => {
        const id = `p_${Date.now()}`;
        const newP = {
            id,
            name: `Guest ${Math.floor(Math.random() * 100)}`,
            role: 'Guest',
            status: 'active',
            audio: true,
            video: false,
            signal: Math.floor(Math.random() * 50) + 50,
            img: ''
        };
        setParticipants(prev => [...prev, newP]);
        if (viewMode === 'floating') bringToFront(id);
    };

    const content = (
        <div className={cn(
            "bg-[#050505] flex flex-col transition-all duration-300",
            isFullScreen ? "fixed inset-0 z-[9999]" : "h-full relative"
        )}>
            {/* Background Grid */}
            <DepthBackground theme="emerald-500" settings={{ 'bg-grid-opacity': 10 }} />
            
            <VerticalChatStream />

            {/* Central Search & Branding - Only in Normal Mode */}
            {!searchMode && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <motion.div 
                        className="bg-[#111] border border-white/10 rounded-3xl p-12 shadow-2xl flex flex-col items-center gap-8 pointer-events-auto relative overflow-hidden"
                        style={{ zIndex: zIndices['search-dock'] || 10 }}
                        onPointerDown={() => bringToFront('search-dock')}
                        initial={{ scale: 0.9, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        whileHover={{ scale: 1.01 }}
                    >
                        {/* Cardboard texture overlay */}
                        <div className="absolute inset-0 opacity-5 bg-[url('https://www.transparenttextures.com/patterns/cardboard.png')] pointer-events-none" />
                        
                        {/* Logo */}
                        <div className="flex items-center gap-3 opacity-90 hover:opacity-100 transition-opacity duration-500 relative z-10">
                            <img 
                            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/693dffcccab0bea12e1e7952/a02aa7415_logo.png" 
                            alt="System Logo" 
                            className="h-24 w-auto object-contain"
                            />
                        </div>

                        {/* Search Box */}
                        <div className="relative group w-[400px] z-10">
                            <div className="absolute inset-0 bg-emerald-500/10 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                            <div className="relative flex items-center pointer-events-auto">
                                <Search className="absolute left-4 w-5 h-5 text-neutral-400 group-hover:text-emerald-500 transition-colors" />
                                <input 
                                    type="text"
                                    placeholder="Search active feeds, logs, or signals..."
                                    className="w-full h-12 bg-black/60 border border-white/20 rounded-full pl-12 pr-4 text-sm text-white placeholder:text-neutral-500 focus:outline-none focus:border-emerald-500/50 focus:bg-black/90 transition-all backdrop-blur-md cursor-text"
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter') {
                                            setSearchMode(true);
                                        }
                                    }}
                                />
                                <div className="absolute right-2 top-2 bottom-2 bg-white/5 rounded-full px-3 flex items-center border border-white/5">
                                    <span className="text-[10px] text-neutral-500 font-mono">CMD+K</span>
                                </div>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
            
            {/* Toolbar */}
            <div className="h-14 border-b border-white/10 bg-neutral-900/80 backdrop-blur-md flex items-center justify-between px-6 z-50 shrink-0 relative">
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <Activity className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                        <OrientingText className="font-bold hidden md:block">COMMAND GRID</OrientingText>
                    </div>
                    <div className="h-4 w-px bg-white/10 hidden md:block" />
                    
                    {/* View Modes */}
                    <div className="flex items-center bg-neutral-800 rounded-md p-0.5 border border-white/5">
                        <button 
                            onClick={() => setViewMode('grid')}
                            className={cn("p-1.5 rounded hover:bg-white/10 transition-colors", viewMode === 'grid' && "bg-neutral-700 text-white")}
                            title="Grid View"
                        >
                            <LayoutGrid className="w-4 h-4" />
                        </button>
                        <button 
                            onClick={() => setViewMode('stack')}
                            className={cn("p-1.5 rounded hover:bg-white/10 transition-colors", viewMode === 'stack' && "bg-neutral-700 text-white")}
                            title="Stack View"
                        >
                            <Sidebar className="w-4 h-4 transform rotate-180" />
                        </button>
                        <button 
                            onClick={() => setViewMode('floating')}
                            className={cn("p-1.5 rounded hover:bg-white/10 transition-colors", viewMode === 'floating' && "bg-neutral-700 text-white")}
                            title="Floating View"
                        >
                            <Layers className="w-4 h-4" />
                        </button>
                    </div>

                    <div className="h-4 w-px bg-white/10 hidden md:block" />
                    <div className="flex items-center gap-2 text-xs text-neutral-400 hidden sm:flex">
                        <Users className="w-3 h-3" />
                        <span>{participants.length} Active</span>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" className="h-8 gap-2 border-white/10 hidden sm:flex" onClick={addParticipant}>
                        <Users className="w-3 h-3" /> Invite
                    </Button>
                    <button 
                        onClick={() => setIsFullScreen(!isFullScreen)}
                        className="p-2 hover:bg-white/10 rounded text-neutral-400 hover:text-white transition-colors"
                        title={isFullScreen ? "Exit Fullscreen" : "Fullscreen"}
                    >
                        {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                    </button>
                    <Button size="sm" className="h-8 bg-red-600 hover:bg-red-700 text-white gap-2">
                        <PhoneOff className="w-3 h-3" /> <span className="hidden sm:inline">End Session</span>
                    </Button>
                </div>
            </div>

            {/* Canvas Area */}
            <div className={cn(
                "flex-1 relative overflow-hidden transition-all", 
                viewMode === 'floating' && !searchMode && "perspective-[1000px]",
                searchMode ? "flex" : "p-6"
            )}>
                {!searchMode ? (
                    <>
                        <AnimatePresence mode="popLayout">
                            {/* FLOATING MODE */}
                            {viewMode === 'floating' && participants.map((p, i) => (
                                <div key={p.id} className="absolute" style={{ 
                                    top: `${10 + (i * 5)}%`, 
                                    left: `${10 + (i * 10)}%` 
                                }}>
                                    <VideoWindow 
                                        mode="floating"
                                        participant={p} 
                                        zIndex={zIndices[p.id]}
                                        onFocus={() => bringToFront(p.id)}
                                        onClose={() => removeParticipant(p.id)}
                                    />
                                </div>
                            ))}

                            {/* GRID MODE */}
                            {viewMode === 'grid' && (
                                <motion.div 
                                    initial={{ opacity: 0 }} 
                                    animate={{ opacity: 1 }} 
                                    exit={{ opacity: 0 }}
                                    className="w-full h-full grid gap-4 auto-rows-fr"
                                    style={{ 
                                        gridTemplateColumns: `repeat(${Math.ceil(Math.sqrt(participants.length))}, minmax(0, 1fr))` 
                                    }}
                                >
                                    {participants.map((p) => (
                                        <VideoWindow 
                                            key={p.id}
                                            mode="grid"
                                            participant={p} 
                                            onClose={() => removeParticipant(p.id)}
                                        />
                                    ))}
                                </motion.div>
                            )}

                            {/* STACK MODE */}
                            {viewMode === 'stack' && (
                                <motion.div 
                                    initial={{ opacity: 0 }} 
                                    animate={{ opacity: 1 }} 
                                    exit={{ opacity: 0 }}
                                    className="w-full h-full flex gap-4"
                                >
                                    {/* Main Speaker */}
                                    <div className="flex-1 h-full">
                                        {participants.find(p => p.id === activeSpeakerId) && (
                                            <VideoWindow 
                                                mode="grid"
                                                participant={participants.find(p => p.id === activeSpeakerId)} 
                                                onClose={() => removeParticipant(activeSpeakerId)}
                                                className="h-full border-2 border-[hsl(var(--color-execution))]"
                                            />
                                        )}
                                    </div>
                                    {/* Sidebar List */}
                                    <div className="w-64 flex flex-col gap-4 overflow-y-auto pr-2">
                                        {participants.filter(p => p.id !== activeSpeakerId).map((p) => (
                                            <div key={p.id} onClick={() => setActiveSpeakerId(p.id)} className="h-40 shrink-0 cursor-pointer hover:ring-1 ring-white/20 rounded-sm transition-all">
                                                <VideoWindow 
                                                    mode="grid"
                                                    participant={p} 
                                                    onClose={() => removeParticipant(p.id)}
                                                    className="h-full"
                                                />
                                            </div>
                                        ))}
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {participants.length === 0 && (
                            <div className="absolute inset-0 flex items-center justify-center flex-col gap-4 text-neutral-600">
                                <Wifi className="w-12 h-12 opacity-20" />
                                <p className="font-mono text-sm">NO ACTIVE SIGNALS DETECTED</p>
                                <Button variant="outline" onClick={addParticipant}>Initialize Uplink</Button>
                            </div>
                        )}
                    </>
                ) : (
                    // SEARCH MODE LAYOUT
                    <>
                        {/* Main Content: Search Results */}
                        <div className="flex-1 flex flex-col min-w-0 bg-neutral-950/80 backdrop-blur-md">
                            {/* Search Header for Mode */}
                            <div className="p-6 border-b border-white/5 bg-neutral-900/50">
                                <div className="flex items-center gap-4 mb-6">
                                     <div className="relative flex-1">
                                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
                                        <input 
                                            type="text"
                                            placeholder="Refine search..."
                                            autoFocus
                                            value={searchQuery}
                                            onChange={(e) => setSearchQuery(e.target.value)}
                                            className="w-full h-10 bg-black/50 border border-emerald-500/30 rounded px-10 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors"
                                        />
                                        <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            onClick={() => setSearchMode(false)}
                                            className="absolute right-2 top-1/2 -translate-y-1/2 h-6 text-[10px] text-neutral-500 hover:text-white"
                                        >
                                            ESC
                                        </Button>
                                     </div>

                                    {/* AI Model Selector */}
                                    <div className="w-64">
                                        <Select value={selectedModelId} onValueChange={setSelectedModelId}>
                                            <SelectTrigger className="h-10 border-white/10 bg-black/50 text-xs">
                                                <div className="flex items-center gap-2">
                                                    <Cpu className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                                                    <SelectValue placeholder="Select Analysis Model" />
                                                </div>
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="default">System Core (v1.0)</SelectItem>
                                                {aiModels.map(m => (
                                                    <SelectItem key={m.id} value={m.id}>{m.name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                
                                {/* User Tabs */}
                                <div className="flex items-center gap-1 overflow-x-auto scrollbar-none pb-1">
                                    <button
                                        onClick={() => setActiveTab('all')}
                                        className={cn(
                                            "px-4 py-2 rounded text-xs font-medium transition-colors whitespace-nowrap",
                                            activeTab === 'all' 
                                                ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" 
                                                : "text-neutral-400 hover:bg-white/5 hover:text-white"
                                        )}
                                    >
                                        ALL SOURCES
                                    </button>
                                    {participants.map(p => (
                                        <button
                                            key={p.id}
                                            onClick={() => setActiveTab(p.id)}
                                            className={cn(
                                                "px-4 py-2 rounded text-xs font-medium transition-colors whitespace-nowrap flex items-center gap-2",
                                                activeTab === p.id 
                                                    ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" 
                                                    : "text-neutral-400 hover:bg-white/5 hover:text-white"
                                            )}
                                        >
                                            <div className="w-2 h-2 rounded-full bg-neutral-600" />
                                            {p.name}
                                        </button>
                                    ))}
                                </div>
                            </div>
                            
                            {/* Results Area */}
                            <div className="flex-1 overflow-y-auto p-6">
                                <div className="max-w-4xl mx-auto space-y-6">
                                    <OrientingText className="text-xs opacity-50 mb-4 uppercase tracking-widest">
                                        {activeTab === 'all' ? 'Global Search Synthesis' : `Uplink Data: ${participants.find(p => p.id === activeTab)?.name}`}
                                    </OrientingText>

                                    {/* Mock Results */}
                                    {filteredResults.length === 0 ? (
                                        <div className="text-center py-12 text-neutral-500">
                                            <Search className="w-8 h-8 mx-auto mb-2 opacity-20" />
                                            <p className="text-sm font-mono">NO RECORDS FOUND IN ARCHIVE</p>
                                        </div>
                                    ) : (
                                        filteredResults.map((item) => {
                                            const sourceName = participants.find(p => p.id === item.sourceId)?.name || 'System';
                                            return (
                                                <div key={item.id} className="p-4 rounded border border-white/5 bg-neutral-900/30 hover:bg-neutral-900/50 transition-all group relative overflow-hidden">
                                                    {analyzingId === item.id && (
                                                        <motion.div 
                                                            layoutId="scan-line"
                                                            className="absolute inset-0 bg-emerald-500/5 z-0"
                                                            initial={{ x: '-100%' }}
                                                            animate={{ x: '100%' }}
                                                            transition={{ duration: 1.5, repeat: Infinity }}
                                                        />
                                                    )}
                                                    <div className="flex items-start gap-4 relative z-10">
                                                        <div className="mt-1 shrink-0">
                                                            <Badge variant="outline" className={cn(
                                                                "font-mono text-[10px] px-2 py-0.5 border-opacity-20 bg-opacity-5",
                                                                item.type === 'alert' ? "border-red-500 text-red-500 bg-red-500" :
                                                                item.type === 'voice' ? "border-blue-500 text-blue-500 bg-blue-500" :
                                                                "border-emerald-500 text-emerald-500 bg-emerald-500"
                                                            )}>
                                                                {sourceName}
                                                            </Badge>
                                                        </div>
                                                        <div className="flex-1 space-y-2">
                                                            <div className="flex items-center justify-between">
                                                                <h3 className="text-sm font-medium text-white group-hover:text-emerald-400 transition-colors">
                                                                    Reference found in Sector {item.sector}: "{item.title}"
                                                                </h3>
                                                                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                                                                    <Button 
                                                                        size="sm" 
                                                                        variant="ghost" 
                                                                        className="h-6 text-[10px] text-emerald-500 hover:text-emerald-400 hover:bg-emerald-500/10"
                                                                        onClick={() => handleAnalyze(item.id)}
                                                                        disabled={analyzingId === item.id}
                                                                    >
                                                                        {analyzingId === item.id ? 'SCANNING...' : 'ANALYZE'}
                                                                    </Button>
                                                                </div>
                                                            </div>
                                                            <p className="text-xs text-neutral-400 leading-relaxed">
                                                                {item.content}
                                                                <span className="block mt-2 pt-2 border-t border-white/5 text-neutral-500 font-mono text-[10px] flex gap-4">
                                                                    <span>TS: {new Date(item.timestamp).toLocaleTimeString()}</span>
                                                                    <span>CONF: {(item.confidence * 100).toFixed(1)}%</span>
                                                                    <span>TYPE: {item.type.toUpperCase()}</span>
                                                                </span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                            </div>
                        </div>

                        {/* Right Sidebar: Video Grid & Lexicon */}
                        <div className="w-80 shrink-0 border-l border-white/10 bg-neutral-900/90 backdrop-blur-xl flex flex-col">
                            {/* Stacked Videos */}
                            <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[50%] border-b border-white/10 scrollbar-thin">
                                <OrientingText className="text-[10px] opacity-50 uppercase tracking-widest sticky top-0 bg-neutral-900/90 z-10 py-2">
                                    Active Uplinks
                                </OrientingText>
                                {participants.map((p) => (
                                    <div key={p.id} className="h-32 w-full rounded overflow-hidden ring-1 ring-white/10 relative">
                                         {/* Simple Video Preview */}
                                         <img src={p.img} alt={p.name} className="w-full h-full object-cover opacity-60" />
                                         <div className="absolute bottom-2 left-2 text-[10px] font-bold text-white bg-black/50 px-2 py-0.5 rounded">
                                            {p.name}
                                         </div>
                                         <div className="absolute top-2 right-2 flex gap-1">
                                            {p.audio ? <Mic className="w-3 h-3 text-white" /> : <MicOff className="w-3 h-3 text-red-500" />}
                                         </div>
                                    </div>
                                ))}
                            </div>

                            {/* Lexicon Area */}
                            <div className="flex-1 overflow-y-auto p-4">
                                <OrientingText className="text-[10px] opacity-50 uppercase tracking-widest sticky top-0 bg-neutral-900/90 z-10 py-2 mb-2">
                                    System Lexicon
                                </OrientingText>
                                <div className="space-y-4">
                                    <div className="p-3 rounded bg-white/5 border border-white/5">
                                        <div className="text-xs text-emerald-400 font-bold mb-1">DREAMCATCHER</div>
                                        <div className="text-[10px] text-neutral-400">
                                            Proprietary neural collection grid for capturing and analyzing stray data packets.
                                        </div>
                                    </div>
                                    <div className="p-3 rounded bg-white/5 border border-white/5">
                                        <div className="text-xs text-emerald-400 font-bold mb-1">XIBALBA</div>
                                        <div className="text-[10px] text-neutral-400">
                                            The place of fear. Secure underworld operating environment.
                                        </div>
                                    </div>
                                    <div className="p-3 rounded bg-white/5 border border-white/5">
                                        <div className="text-xs text-emerald-400 font-bold mb-1">UPLINK</div>
                                        <div className="text-[10px] text-neutral-400">
                                            Direct neural interface connection between operator and grid.
                                        </div>
                                    </div>
                                    <div className="p-3 rounded bg-white/5 border border-white/5">
                                        <div className="text-xs text-emerald-400 font-bold mb-1">REAPER</div>
                                        <div className="text-[10px] text-neutral-400">
                                            Automated code harvesting and deployment daemon.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* Bottom Status */}
            <div className="h-8 bg-black border-t border-white/10 flex items-center px-4 justify-between text-[10px] font-mono text-neutral-500 z-50 shrink-0">
                <div className="flex gap-4">
                    <span>ENCRYPTION: AES-256</span>
                    <span>LATENCY: 42ms</span>
                    <span>PROTOCOL: WebRTC/UDP</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                    SECURE CONNECTION
                </div>
            </div>
            {/* Analysis Modal */}
            <Dialog open={showAnalysisModal} onOpenChange={setShowAnalysisModal}>
                <DialogContent className="bg-neutral-900 border-white/10 text-white sm:max-w-2xl">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2 text-[hsl(var(--color-execution))]">
                            <Zap className="w-5 h-5" />
                            AI Analysis Report
                        </DialogTitle>
                        <DialogDescription className="text-neutral-400">
                            Generated by {analysisData?.model}
                        </DialogDescription>
                    </DialogHeader>

                    {analysisData && (
                        <div className="space-y-6 mt-4">
                            <div className="p-4 rounded bg-white/5 border border-white/10">
                                <div className="text-xs text-neutral-500 mb-2 font-mono uppercase">Source Data</div>
                                <div className="font-medium text-sm text-white mb-1">{analysisData.source.title}</div>
                                <div className="text-xs text-neutral-400 font-mono">{analysisData.source.content}</div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-3 rounded bg-neutral-950 border border-white/5 text-center">
                                    <div className="text-[10px] text-neutral-500 uppercase tracking-widest mb-1">Threat Level</div>
                                    <div className={cn("text-2xl font-bold font-mono", analysisData.threatLevel > 50 ? "text-red-500" : "text-green-500")}>
                                        {analysisData.threatLevel}%
                                    </div>
                                </div>
                                <div className="p-3 rounded bg-neutral-950 border border-white/5 text-center">
                                    <div className="text-[10px] text-neutral-500 uppercase tracking-widest mb-1">Sentiment</div>
                                    <div className="text-2xl font-bold text-white">{analysisData.sentiment}</div>
                                </div>
                            </div>

                            <div>
                                <div className="text-xs text-neutral-500 mb-2 font-mono uppercase flex items-center gap-2">
                                    <Brain className="w-3 h-3" />
                                    Model Insights
                                </div>
                                <div className="text-sm leading-relaxed text-neutral-300 bg-black/30 p-4 rounded border border-white/5 font-mono">
                                    {analysisData.summary}
                                </div>
                            </div>

                            <div className="flex gap-2">
                                {analysisData.keywords.map(k => (
                                    <Badge key={k} variant="outline" className="border-white/10 text-neutral-400">
                                        #{k}
                                    </Badge>
                                ))}
                            </div>
                        </div>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );

    if (isFullScreen && typeof document !== 'undefined') {
        return createPortal(content, document.body);
    }

    return content;
}