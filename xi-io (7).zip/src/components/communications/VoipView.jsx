import React, { useState, useEffect } from 'react';
import { 
  Phone, Mic, Volume2, MicOff, PhoneOff, 
  Clock, User, MoreVertical, Voicemail 
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/SystemDesign';
import { LoadingLab } from '@/components/ui/design-system/Curiosity';
import { cn } from "@/lib/utils";
import { FluidGrid } from '@/components/ui/FluidGrid';

const KeypadButton = ({ value, sub, onClick }) => (
    <button 
        onClick={() => onClick(value)}
        className="w-16 h-16 rounded-full bg-neutral-900 border border-white/5 hover:bg-neutral-800 hover:border-white/20 hover:scale-105 active:scale-95 transition-all flex flex-col items-center justify-center group"
    >
        <span className="text-2xl font-light text-white group-hover:text-[hsl(var(--color-active))] transition-colors">{value}</span>
        {sub && <span className="text-[9px] text-neutral-600 font-bold tracking-widest uppercase group-hover:text-neutral-400">{sub}</span>}
    </button>
);

export default function VoipView() {
    const [number, setNumber] = useState("");
    const [callState, setCallState] = useState("idle"); // idle, dialing, connected
    const [duration, setDuration] = useState(0);

    useEffect(() => {
        let interval;
        if (callState === 'connected') {
            interval = setInterval(() => setDuration(d => d + 1), 1000);
        } else {
            setDuration(0);
        }
        return () => clearInterval(interval);
    }, [callState]);

    const formatTime = (secs) => {
        const mins = Math.floor(secs / 60);
        const s = secs % 60;
        return `${mins}:${s.toString().padStart(2, '0')}`;
    };

    const handleCall = () => {
        if (!number) return;
        setCallState("dialing");
        setTimeout(() => setCallState("connected"), 2000);
    };

    const handleHangup = () => {
        setCallState("idle");
    };

    const simulateIncoming = () => {
        setNumber("Unknown Caller");
        setCallState("incoming");
    };

    return (
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="state" dominance="dominant" className="border-r border-white/5 flex flex-col p-0">
                        <div className="p-4 border-b border-white/10 shrink-0">
                            <div className="flex justify-between items-center mb-2">
                                <OrientingText>COMMUNICATIONS LOG</OrientingText>
                                <Button onClick={simulateIncoming} size="sm" variant="outline" className="h-6 text-[10px] border-green-500/20 text-green-500 hover:bg-green-500/10">
                                     Simulate Ring
                                </Button>
                            </div>
                            <div className="flex gap-2">
                                <Button variant="ghost" size="sm" className="h-7 text-xs bg-white/5 text-white">All</Button>
                                <Button variant="ghost" size="sm" className="h-7 text-xs text-neutral-500 hover:text-white">Missed</Button>
                                <Button variant="ghost" size="sm" className="h-7 text-xs text-neutral-500 hover:text-white">Voicemail</Button>
                            </div>
                        </div>
                        <div className="flex-1 overflow-y-auto p-2 space-y-1">
                            {[1,2,3,4,5,6].map(i => (
                                <div key={i} className="flex items-center justify-between p-3 rounded hover:bg-white/5 cursor-pointer group transition-colors">
                                    <div className="flex items-center gap-3">
                                        <div className="w-8 h-8 rounded-full bg-neutral-900 flex items-center justify-center border border-white/10 text-neutral-500">
                                            <User className="w-4 h-4" />
                                        </div>
                                        <div>
                                            <IntentText className="text-sm font-medium">Unknown Caller</IntentText>
                                            <StateText className="text-[10px] flex items-center gap-1">
                                                <Phone className="w-3 h-3" /> +1 (555) 000-000{i}
                                            </StateText>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <StateText className="text-[10px]">Yesterday</StateText>
                                        <Phone className="w-3 h-3 ml-auto mt-1 text-neutral-600 group-hover:text-white" />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="intent" dominance="dominant" className="flex-1 flex flex-col items-center justify-center p-6 relative">
                        {callState === 'idle' ? (
                            <div className="w-full max-w-sm flex flex-col items-center gap-8 animate-in zoom-in-95 duration-300">
                                <div className="w-full text-center space-y-2">
                                    <Input 
                                        value={number}
                                        onChange={(e) => setNumber(e.target.value)}
                                        className="text-center text-3xl font-light bg-transparent border-none focus-visible:ring-0 placeholder:text-neutral-800 h-16"
                                        placeholder="Enter Number"
                                    />
                                    {number && <StateText className="text-active">Ready to dial</StateText>}
                                </div>

                                <div className="grid grid-cols-3 gap-6">
                                    {[
                                        {v:'1', s:''}, {v:'2', s:'ABC'}, {v:'3', s:'DEF'},
                                        {v:'4', s:'GHI'}, {v:'5', s:'JKL'}, {v:'6', s:'MNO'},
                                        {v:'7', s:'PQRS'}, {v:'8', s:'TUV'}, {v:'9', s:'WXYZ'},
                                        {v:'*', s:''}, {v:'0', s:'+'}, {v:'#', s:''}
                                    ].map(k => (
                                        <KeypadButton 
                                            key={k.v} 
                                            value={k.v} 
                                            sub={k.s} 
                                            onClick={(val) => setNumber(n => n + val)} 
                                        />
                                    ))}
                                </div>

                                <Button 
                                    size="lg" 
                                    className="w-16 h-16 rounded-full bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-white shadow-[0_0_30px_hsl(var(--color-execution))]"
                                    onClick={handleCall}
                                >
                                    <Phone className="w-6 h-6" />
                                </Button>
                            </div>
                        ) : (
                            <div className="w-full max-w-md flex flex-col items-center justify-center gap-8 animate-in fade-in zoom-in-95 duration-500 relative">
                                {/* Pulse Effect */}
                                <div className={`absolute inset-0 bg-[hsl(var(--color-active))]/5 blur-3xl rounded-full ${callState === 'incoming' ? 'animate-[pulse_0.5s_infinite] bg-green-500/10' : 'animate-pulse'}`} />
                                
                                <div className="relative z-10 flex flex-col items-center">
                                    <div className={`w-32 h-32 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center shadow-2xl mb-6 relative ${callState === 'incoming' ? 'border-[hsl(var(--color-execution))]' : ''}`}>
                                        <div className={`absolute inset-0 rounded-full border border-[hsl(var(--color-active))] opacity-20 ${callState === 'incoming' ? 'animate-[ping_1s_infinite] border-[hsl(var(--color-execution))]' : 'animate-[ping_2s_infinite]'}`} />
                                        <User className="w-12 h-12 text-neutral-400" />
                                    </div>
                                    <IntentText className="text-3xl font-light mb-2">{number}</IntentText>
                                    <StateText className="text-[hsl(var(--color-active))] font-mono text-lg tracking-widest">
                                        {callState === 'dialing' ? 'CONNECTING...' : callState === 'incoming' ? 'INCOMING CALL...' : formatTime(duration)}
                                    </StateText>
                                </div>

                                {callState === 'connected' && (
                                    <div className="grid grid-cols-3 gap-4 w-full">
                                        <Button variant="outline" className="flex flex-col h-20 gap-2 border-white/10 bg-neutral-900/50 hover:bg-white/5">
                                            <MicOff className="w-5 h-5" />
                                            <span className="text-[10px] uppercase">Mute</span>
                                        </Button>
                                        <Button variant="outline" className="flex flex-col h-20 gap-2 border-white/10 bg-neutral-900/50 hover:bg-white/5">
                                            <Volume2 className="w-5 h-5" />
                                            <span className="text-[10px] uppercase">Speaker</span>
                                        </Button>
                                        <Button variant="outline" className="flex flex-col h-20 gap-2 border-white/10 bg-neutral-900/50 hover:bg-white/5">
                                            <Voicemail className="w-5 h-5" />
                                            <span className="text-[10px] uppercase">Record</span>
                                        </Button>
                                    </div>
                                )}
                                
                                {callState === 'incoming' ? (
                                    <div className="grid grid-cols-2 gap-4 w-full mt-4">
                                        <Button 
                                            size="lg" 
                                            className="w-full h-14 rounded-full bg-[hsl(var(--color-error))] hover:bg-[hsl(var(--color-error))]/90 text-white shadow-lg"
                                            onClick={handleHangup}
                                        >
                                            <PhoneOff className="w-5 h-5 mr-2" /> Decline
                                        </Button>
                                        <Button 
                                            size="lg" 
                                            className="w-full h-14 rounded-full bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-white shadow-[0_0_30px_hsl(var(--color-execution))]"
                                            onClick={() => setCallState('connected')}
                                        >
                                            <Phone className="w-5 h-5 mr-2" /> Accept
                                        </Button>
                                    </div>
                                ) : (
                                    <Button 
                                        size="lg" 
                                        className="w-full h-14 rounded-full bg-[hsl(var(--color-error))] hover:bg-[hsl(var(--color-error))]/90 text-white shadow-lg mt-8"
                                        onClick={handleHangup}
                                    >
                                        <PhoneOff className="w-5 h-5 mr-2" /> End Transmission
                                    </Button>
                                )}
                                
                                {callState === 'dialing' && (
                                    <div className="absolute top-full mt-4">
                                        <LoadingLab active={true} cause="Establishing uplink" duration="~2s" />
                                    </div>
                                )}
                            </div>
                        )}
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    );
}