import React from 'react';
import { 
  Twitter, Linkedin, Github, PenTool, 
  Heart, MessageCircle, Repeat, BarChart2,
  Globe, Hash, Link as LinkIcon
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';
import { FluidGrid } from '@/components/ui/FluidGrid';

const SocialPost = ({ platform, author, content, stats }) => (
    <Layer level="state" className="p-4 mb-4 bg-neutral-900 border-white/5 hover:border-white/10 transition-colors">
        <div className="flex justify-between items-start mb-3">
            <div className="flex items-center gap-3">
                <Avatar className="w-8 h-8 border border-white/10">
                    <AvatarFallback className="bg-neutral-800 text-xs">{author[0]}</AvatarFallback>
                </Avatar>
                <div>
                    <IntentText className="text-sm font-bold">{author}</IntentText>
                    <StateText className="text-[10px]">Just now • {platform}</StateText>
                </div>
            </div>
            {platform === 'Twitter' ? <Twitter className="w-4 h-4 text-blue-400" /> : <Linkedin className="w-4 h-4 text-blue-600" />}
        </div>
        <p className="text-neutral-300 text-sm leading-relaxed mb-4 font-light">
            {content}
        </p>
        <div className="flex items-center justify-between pt-3 border-t border-white/5">
            <div className="flex gap-4">
                <div className="flex items-center gap-1.5 text-neutral-500 hover:text-white transition-colors cursor-pointer text-xs">
                    <MessageCircle className="w-3.5 h-3.5" /> <span>{stats.comments}</span>
                </div>
                <div className="flex items-center gap-1.5 text-neutral-500 hover:text-green-500 transition-colors cursor-pointer text-xs">
                    <Repeat className="w-3.5 h-3.5" /> <span>{stats.reposts}</span>
                </div>
                <div className="flex items-center gap-1.5 text-neutral-500 hover:text-red-500 transition-colors cursor-pointer text-xs">
                    <Heart className="w-3.5 h-3.5" /> <span>{stats.likes}</span>
                </div>
                <div className="flex items-center gap-1.5 text-neutral-500 hover:text-blue-500 transition-colors cursor-pointer text-xs">
                    <BarChart2 className="w-3.5 h-3.5" /> <span>{stats.views}</span>
                </div>
            </div>
        </div>
    </Layer>
);

export default function SocialView({ onCompose, posts = [] }) {
    // Default posts combined with new ones
    const allPosts = [
        ...posts,
        { 
            id: 's1', platform: "Twitter", author: "Base44 System", 
            content: "Deploying the new architecture to the grid. The latency improvements are real. #shipping #dev", 
            stats: { comments: 12, reposts: 4, likes: 89, views: '1.2k' } 
        },
        { 
            id: 's2', platform: "LinkedIn", author: "Engineering Team", 
            content: "We're excited to announce our Series A funding round led by top tier investors. This will accelerate our mission to build the operating system for the future.", 
            stats: { comments: 45, reposts: 12, likes: 342, views: '15k' } 
        },
        { 
            id: 's3', platform: "Twitter", author: "User_404", 
            content: "Is anyone else seeing the new dashboard update? It looks sci-fi as hell.", 
            stats: { comments: 2, reposts: 0, likes: 14, views: '200' } 
        }
    ];

    return (
        <FluidGrid
            left={
                <QuadrantGrid className="p-0 h-full gap-0">
                    <Quadrant type="state" dominance="dominant" className="border-r border-white/5 flex flex-col p-0">
                        <div className="p-6 border-b border-white/10 flex justify-between items-center bg-neutral-900/30 shrink-0">
                            <OrientingText>GLOBAL FEED</OrientingText>
                            <div className="flex gap-2">
                                <Button size="sm" variant="ghost" className="text-xs bg-white/5 text-white">For You</Button>
                                <Button size="sm" variant="ghost" className="text-xs text-neutral-500">Following</Button>
                                <Button size="sm" variant="ghost" className="text-xs text-neutral-500">Mentions</Button>
                            </div>
                        </div>
                        <div className="flex-1 overflow-y-auto p-6 scrollbar-thin scrollbar-thumb-white/10">
                            <div className="max-w-2xl mx-auto flex flex-col gap-0">
                                {allPosts.map((post, i) => (
                                    <SocialPost 
                                        key={post.id || i}
                                        platform={post.platform}
                                        author={post.author}
                                        content={post.content}
                                        stats={post.stats}
                                    />
                                ))}
                            </div>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
            right={
                <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
                    <Quadrant type="intent" dominance="dominant" className="border-b flex items-center justify-center p-6">
                         <Button 
                            className="w-full bg-[hsl(var(--color-active))] text-black font-bold hover:bg-[hsl(var(--color-active))]/90"
                            onClick={onCompose}
                         >
                            <PenTool className="w-4 h-4 mr-2" /> New Transmission
                         </Button>
                    </Quadrant>
                    
                    <Quadrant type="orientation" className="border-t-0 rounded-t-none">
                        <div className="space-y-6">
                            <div>
                                <OrientingText className="mb-4">ACTIVE NODES</OrientingText>
                                <div className="space-y-3">
                                    <div className="flex items-center justify-between p-3 rounded bg-neutral-900 border border-white/5">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded bg-blue-500/10">
                                                <Twitter className="w-4 h-4 text-blue-400" />
                                            </div>
                                            <div>
                                                <IntentText className="text-sm">@base44_io</IntentText>
                                                <StateText className="text-[10px]">Connected</StateText>
                                            </div>
                                        </div>
                                        <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]" />
                                    </div>
                                    <div className="flex items-center justify-between p-3 rounded bg-neutral-900 border border-white/5">
                                        <div className="flex items-center gap-3">
                                            <div className="p-2 rounded bg-blue-700/10">
                                                <Linkedin className="w-4 h-4 text-blue-600" />
                                            </div>
                                            <div>
                                                <IntentText className="text-sm">Base44 Inc.</IntentText>
                                                <StateText className="text-[10px]">Connected</StateText>
                                            </div>
                                        </div>
                                        <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]" />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <OrientingText className="mb-4">TRENDING TOPICS</OrientingText>
                                <div className="flex flex-wrap gap-2">
                                    {['#AI', '#DeFi', '#Shipping', '#DesignSystem', '#React', '#Vercel'].map(tag => (
                                        <Badge key={tag} variant="secondary" className="bg-white/5 hover:bg-white/10 text-neutral-400 cursor-pointer">
                                            {tag}
                                        </Badge>
                                    ))}
                                </div>
                            </div>

                            <Layer level="orientation" className="p-4 space-y-2">
                                <div className="flex items-center gap-2">
                                    <Globe className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                    <OrientingText>NETWORK STATUS</OrientingText>
                                </div>
                                <StateText className="leading-relaxed">
                                    Social graph nodes are operating at 99.9% uptime. Sentiment analysis stream is active.
                                </StateText>
                            </Layer>
                        </div>
                    </Quadrant>
                </QuadrantGrid>
            }
        />
    );
}