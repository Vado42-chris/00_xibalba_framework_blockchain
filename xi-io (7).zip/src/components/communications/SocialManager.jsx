import React, { useState } from 'react';
import { 
  Twitter, Linkedin, PenTool, 
  Heart, MessageCircle, Repeat, BarChart2,
  Globe, Search
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/SystemDesign';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { cn } from "@/components/ui/utils";
import { Input } from "@/components/ui/input";

const SocialSidebar = ({ onCompose }) => {
    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b border-white/5">
                <Button 
                    className="w-full bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white font-bold"
                    onClick={onCompose}
                >
                    <PenTool className="w-4 h-4 mr-2" /> New Post
                </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
                <div>
                    <OrientingText className="mb-4">ACTIVE NODES</OrientingText>
                    <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 rounded bg-neutral-900 border border-white/5">
                            <div className="flex items-center gap-3">
                                <div className="p-2 rounded bg-[hsl(var(--color-intent))]/10">
                                    <Twitter className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                </div>
                                <div>
                                    <IntentText className="text-sm">@base44_io</IntentText>
                                    <StateText className="text-[10px]">Connected</StateText>
                                </div>
                            </div>
                            <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))] shadow-[0_0_8px_hsl(var(--color-execution))]" />
                        </div>
                        <div className="flex items-center justify-between p-3 rounded bg-neutral-900 border border-white/5">
                            <div className="flex items-center gap-3">
                                <div className="p-2 rounded bg-[hsl(var(--color-intent))]/10">
                                    <Linkedin className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                                </div>
                                <div>
                                    <IntentText className="text-sm">Base44 Inc.</IntentText>
                                    <StateText className="text-[10px]">Connected</StateText>
                                </div>
                            </div>
                            <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))] shadow-[0_0_8px_hsl(var(--color-execution))]" />
                        </div>
                    </div>
                </div>

                <div>
                    <OrientingText className="mb-4">TRENDING TOPICS</OrientingText>
                    <div className="flex flex-wrap gap-2">
                        {['#AI', '#DeFi', '#Shipping', '#DesignSystem', '#React', '#Vercel'].map(tag => (
                            <Badge key={tag} variant="secondary" className="bg-white/5 hover:bg-white/10 text-neutral-400 cursor-pointer">
                                {tag}
                            </Badge>
                        ))}
                    </div>
                </div>

                <Layer level="orientation" className="p-4 space-y-2">
                    <div className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                        <OrientingText>NETWORK STATUS</OrientingText>
                    </div>
                    <StateText className="leading-relaxed">
                        Social graph nodes are operating at 99.9% uptime. Sentiment analysis stream is active.
                    </StateText>
                </Layer>
            </div>
        </div>
    );
};

const SocialFeed = ({ posts }) => {
    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/30 shrink-0">
                <OrientingText>GLOBAL FEED</OrientingText>
                <div className="flex gap-2">
                    <Button size="sm" variant="ghost" className="text-xs bg-white/5 text-white">For You</Button>
                    <Button size="sm" variant="ghost" className="text-xs text-neutral-500">Following</Button>
                    <Button size="sm" variant="ghost" className="text-xs text-neutral-500">Mentions</Button>
                </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
                <div className="max-w-2xl mx-auto flex flex-col gap-4">
                    {posts.map((post, i) => (
                         <Layer key={post.id || i} level="state" className="p-4 bg-neutral-900 border-white/5 hover:border-white/10 transition-colors">
                            <div className="flex justify-between items-start mb-3">
                                <div className="flex items-center gap-3">
                                    <Avatar className="w-8 h-8 border border-white/10">
                                        <AvatarFallback className="bg-neutral-800 text-xs">{post.author[0]}</AvatarFallback>
                                    </Avatar>
                                    <div>
                                        <IntentText className="text-sm font-bold">{post.author}</IntentText>
                                        <StateText className="text-[10px]">Just now • {post.platform}</StateText>
                                    </div>
                                </div>
                                {post.platform === 'Twitter' ? <Twitter className="w-4 h-4 text-[hsl(var(--color-intent))]" /> : <Linkedin className="w-4 h-4 text-[hsl(var(--color-intent))]" />}
                            </div>
                            <p className="text-neutral-300 text-sm leading-relaxed mb-4 font-light">
                                {post.content}
                            </p>
                            <div className="flex items-center justify-between pt-3 border-t border-white/5">
                                <div className="flex gap-4">
                                    <div className="flex items-center gap-1.5 text-neutral-500 hover:text-white transition-colors cursor-pointer text-xs">
                                        <MessageCircle className="w-3.5 h-3.5" /> <span>{post.stats.comments}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5 text-neutral-500 hover:text-[hsl(var(--color-execution))] transition-colors cursor-pointer text-xs">
                                        <Repeat className="w-3.5 h-3.5" /> <span>{post.stats.reposts}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5 text-neutral-500 hover:text-[hsl(var(--color-error))] transition-colors cursor-pointer text-xs">
                                        <Heart className="w-3.5 h-3.5" /> <span>{post.stats.likes}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5 text-neutral-500 hover:text-[hsl(var(--color-intent))] transition-colors cursor-pointer text-xs">
                                        <BarChart2 className="w-3.5 h-3.5" /> <span>{post.stats.views}</span>
                                    </div>
                                </div>
                            </div>
                        </Layer>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default function SocialManager({ onCompose, posts = [] }) {
    // Default posts combined with new ones
    const allPosts = [
        ...posts,
        { 
            id: 's1', platform: "Twitter", author: "Base44 System", 
            content: "Deploying the new architecture to the grid. The latency improvements are real. #shipping #dev", 
            stats: { comments: 12, reposts: 4, likes: 89, views: '1.2k' } 
        },
        { 
            id: 's2', platform: "LinkedIn", author: "Engineering Team", 
            content: "We're excited to announce our Series A funding round led by top tier investors. This will accelerate our mission to build the operating system for the future.", 
            stats: { comments: 45, reposts: 12, likes: 342, views: '15k' } 
        },
        { 
            id: 's3', platform: "Twitter", author: "User_404", 
            content: "Is anyone else seeing the new dashboard update? It looks sci-fi as hell.", 
            stats: { comments: 2, reposts: 0, likes: 14, views: '200' } 
        }
    ];

    return (
        <div className="flex h-full w-full bg-neutral-950">
            <div className="w-[350px] shrink-0 border-r border-white/5 flex flex-col bg-neutral-900/30">
                <SocialSidebar onCompose={onCompose} />
            </div>
            <div className="flex-1 min-w-0 flex flex-col bg-neutral-950">
                <SocialFeed posts={allPosts} />
            </div>
        </div>
    );
}