import React, { useState } from 'react';
import { 
  BarChart, TrendingUp, Users, Target, Calendar,
  Mail, MessageSquare, ArrowUpRight, Plus, ExternalLink,
  PieChart
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant, ChartFrame
} from '@/components/ui/design-system/SystemDesign';
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { cn } from "@/components/ui/utils";

const CampaignList = ({ campaigns, selectedId, onSelect, onNew }) => {
    return (
        <div className="flex flex-col h-full">
            <div className="p-4 border-b border-white/5 flex justify-between items-center shrink-0">
                <OrientingText className="tracking-widest font-bold">INITIATIVES</OrientingText>
                <Button size="sm" onClick={onNew} className="h-6 text-[10px] bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white gap-1">
                    <Plus className="w-3 h-3" /> NEW
                </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
                {campaigns.length === 0 && (
                    <div className="p-4 text-center opacity-50">
                        <StateText>No active campaigns</StateText>
                    </div>
                )}
                {campaigns.map(c => (
                    <SystemCard
                        key={c.id}
                        title={c.name}
                        subtitle={`${c.reach?.toLocaleString()} Reach • ${c.conversion_rate}% Conv`}
                        status={c.status === 'active' ? 'execution' : 'settled'}
                        metric={c.type.toUpperCase()}
                        active={selectedId === c.id}
                        onClick={() => onSelect(c.id)}
                        icon={Target}
                    >
                        <Progress value={64} className="h-0.5 bg-neutral-900 mt-2" indicatorClassName="bg-[hsl(var(--color-intent))]" />
                    </SystemCard>
                ))}
            </div>
        </div>
    );
};

const CampaignWorkspace = ({ campaign }) => {
    if (!campaign) {
        return (
            <div className="flex-1 flex flex-col items-center justify-center text-neutral-500 bg-neutral-950/50">
                <Target className="w-16 h-16 stroke-1 text-neutral-700 mb-4" />
                <OrientingText>SELECT CAMPAIGN</OrientingText>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full animate-in fade-in duration-300">
            {/* Header */}
            <SystemDetailHeader
                title={campaign.name}
                subtitle={`ID: ${campaign.id}`}
                category={campaign.status}
                icon={Target}
            >
                <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="border-white/10">Edit</Button>
                    <Button size="sm" className="bg-[hsl(var(--color-intent))] text-white">View Analytics</Button>
                </div>
            </SystemDetailHeader>

            {/* Dashboard Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                <div className="grid grid-cols-3 gap-4">
                    <Layer level="state" className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <Users className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                            <StateText>Total Reach</StateText>
                        </div>
                        <IntentText className="text-2xl font-mono">{campaign.reach?.toLocaleString()}</IntentText>
                    </Layer>
                    <Layer level="state" className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <Target className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                            <StateText>Conversions</StateText>
                        </div>
                        <IntentText className="text-2xl font-mono text-[hsl(var(--color-execution))]">{(campaign.reach * (campaign.conversion_rate/100)).toFixed(0)}</IntentText>
                    </Layer>
                    <Layer level="state" className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <TrendingUp className="w-4 h-4 text-[hsl(var(--color-warning))]" />
                            <StateText>Conv. Rate</StateText>
                        </div>
                        <IntentText className="text-2xl font-mono text-[hsl(var(--color-warning))]">{campaign.conversion_rate}%</IntentText>
                    </Layer>
                </div>

                <div className="h-64 w-full bg-neutral-900/30 rounded border border-white/5 p-4">
                     <ChartFrame label="PERFORMANCE TREND" metric="+12.4%" trend="vs last week" category="active">
                        <div className="flex items-center justify-center h-full opacity-30">
                            <BarChart className="w-16 h-16 text-neutral-600" />
                        </div>
                     </ChartFrame>
                </div>
            </div>
        </div>
    );
};

export default function MarketingManager({ campaigns = [], onNewCampaign }) {
    const [selectedId, setSelectedId] = useState(null);
    const selectedCampaign = campaigns.find(c => c.id === selectedId);

    // Auto-select first if available and none selected
    React.useEffect(() => {
        if (campaigns.length > 0 && !selectedId) {
            setSelectedId(campaigns[0].id);
        }
    }, [campaigns, selectedId]);

    return (
        <div className="flex h-full w-full bg-neutral-950">
            <div className="w-[350px] shrink-0 border-r border-white/5 flex flex-col bg-neutral-900/30">
                <CampaignList 
                    campaigns={campaigns}
                    selectedId={selectedId}
                    onSelect={setSelectedId}
                    onNew={onNewCampaign}
                />
            </div>
            <div className="flex-1 min-w-0 flex flex-col bg-neutral-950">
                <CampaignWorkspace campaign={selectedCampaign} />
            </div>
        </div>
    );
}