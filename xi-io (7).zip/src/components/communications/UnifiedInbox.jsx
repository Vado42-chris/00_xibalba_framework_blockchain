import React, { useState } from 'react';
import { 
  Inbox, Search, Filter, Archive, Reply, Trash2, 
  MoreVertical, Star, User, Clock
} from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
    OrientingText, StateText, 
    Layer, SemanticDot 
} from '@/components/ui/design-system/SystemDesign';
import { InsightTip } from '@/components/ui/design-system/Curiosity';
import { cn } from "@/lib/utils";
import { SystemCard, SystemDetailHeader } from '@/components/ui/design-system/SystemComponents';
import { FluidGrid } from '@/components/ui/FluidGrid';
import { QuadrantGrid, Quadrant } from '@/components/ui/design-system/SystemDesign';

const InboxList = ({ 
    messages, selectedId, onSelect, 
    searchTerm, setSearchTerm, 
    filter, setFilter, 
    sourceFilter, setSourceFilter, 
    sources 
}) => {
    return (
        <div className="flex flex-col h-full">
            {/* Header / Search */}
            <div className="p-3 border-b border-white/10 shrink-0">
                <div className="space-y-3">
                    <div className="relative">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-neutral-500" />
                        <Input 
                            placeholder="Search transmissions..." 
                            className="pl-8 bg-neutral-950 border-white/10 h-9 text-xs focus:border-[hsl(var(--color-intent))]"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex flex-col gap-2">
                        {/* Status Filters */}
                        <div className="flex flex-wrap gap-2">
                            {['all', 'unread', 'flagged'].map(f => (
                                <button
                                    key={f}
                                    onClick={() => setFilter(f)}
                                    className={cn(
                                        "px-3 py-1 text-[10px] uppercase tracking-wider rounded-full border transition-colors whitespace-nowrap",
                                        filter === f 
                                            ? "bg-[hsl(var(--color-active))]/10 border-[hsl(var(--color-active))] text-[hsl(var(--color-active))]" 
                                            : "bg-transparent border-white/10 text-neutral-500 hover:bg-white/5"
                                    )}
                                >
                                    {f}
                                </button>
                            ))}
                        </div>
                        {/* Source Filters */}
                        <div className="flex flex-wrap gap-2">
                            {sources.map(s => (
                                <button
                                    key={s}
                                    onClick={() => setSourceFilter(s)}
                                    className={cn(
                                        "px-2 py-0.5 text-[9px] uppercase tracking-wider rounded border transition-colors whitespace-nowrap",
                                        sourceFilter === s 
                                            ? "bg-neutral-800 border-white/20 text-white" 
                                            : "bg-transparent border-transparent text-neutral-600 hover:text-neutral-400"
                                    )}
                                >
                                    {s}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* Message List */}
            <div className="flex-1 overflow-y-auto">
                {messages.length === 0 ? (
                    <div className="p-8 text-center opacity-50 flex flex-col items-center gap-2">
                        <Inbox className="w-8 h-8 text-neutral-600" />
                        <OrientingText>No signal found.</OrientingText>
                    </div>
                ) : (
                    messages.map(msg => (
                        <SystemCard
                            key={msg.id}
                            title={msg.client}
                            subtitle={msg.subject}
                            metric={msg.time}
                            status={msg.status === 'unread' ? 'active' : 'settled'}
                            active={selectedId === msg.id}
                            onClick={() => onSelect(msg.id)}
                            icon={
                                msg.source.includes('MAIL') ? Inbox : 
                                msg.source.includes('SLACK') || msg.source.includes('DISCORD') ? MoreVertical : 
                                msg.source === 'SYSTEM' ? Clock : User
                            }
                            className="border-b border-white/5 rounded-none"
                        >
                            <StateText className="line-clamp-1 opacity-50 text-[10px] mt-1">
                                {msg.snippet}
                            </StateText>
                        </SystemCard>
                    ))
                )}
            </div>
        </div>
    );
};

const InboxDetail = ({ selectedMessage, onReply, onDraft, onArchive, onDelete, onClose }) => {
    if (!selectedMessage) {
        return (
            <div className="flex-1 flex flex-col items-center justify-center text-neutral-500 bg-neutral-950/50">
                <div className="text-center opacity-50 space-y-6 max-w-sm mx-auto p-8">
                    <div className="w-20 h-20 rounded-2xl bg-neutral-900/50 flex items-center justify-center mx-auto border border-white/5 rotate-3">
                        <Inbox className="w-10 h-10 stroke-1" />
                    </div>
                    <div className="space-y-2">
                        <OrientingText className="text-base">AWAITING SELECTION</OrientingText>
                        <p className="text-sm text-neutral-600">Select a transmission from the matrix to decrypt its contents.</p>
                    </div>
                    <InsightTip type="observation" title="Silence">
                        Most "urgent" messages resolve themselves if you stare at them long enough.
                    </InsightTip>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full animate-in fade-in duration-300">
            {/* Detail Header */}
            <SystemDetailHeader
                title={selectedMessage.subject || "No Subject"}
                subtitle={`From: ${selectedMessage.client} • ${selectedMessage.time}`}
                category={selectedMessage.source}
                icon={Inbox}
            >
                <div className="flex gap-2 items-center">
                    <Button variant="ghost" size="icon" className="h-6 w-6 lg:hidden" onClick={onClose}>
                        <Inbox className="w-4 h-4" />
                    </Button>
                    <Button onClick={() => { onArchive(selectedMessage.id); onClose(); }} size="icon" variant="ghost" className="h-8 w-8 text-neutral-400 hover:text-white"><Archive className="w-4 h-4" /></Button>
                    <Button onClick={() => { onDelete(selectedMessage.id); onClose(); }} size="icon" variant="ghost" className="h-8 w-8 text-neutral-400 hover:text-red-400"><Trash2 className="w-4 h-4" /></Button>
                    <div className="w-px h-8 bg-white/10 mx-1" />
                    <Button 
                        size="sm" 
                        className="bg-[hsl(var(--color-active))] hover:bg-[hsl(var(--color-active))]/90 text-black font-medium"
                        onClick={() => onReply(selectedMessage)}
                    >
                        <Reply className="w-4 h-4 mr-2" /> Reply
                    </Button>
                </div>
            </SystemDetailHeader>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8">
                <div className="max-w-none">
                    <p className="text-[hsl(var(--fg-intent))] leading-relaxed font-serif text-lg opacity-90 whitespace-pre-wrap selection:bg-[hsl(var(--color-active))]/30">
                        {selectedMessage.full}
                    </p>
                </div>
            </div>

            {/* AI Actions Footer */}
            <div className="p-4 border-t border-white/10 bg-neutral-900/30 shrink-0">
                    <div className="max-w-3xl mx-auto w-full">
                    <div className="flex items-center gap-2 mb-3">
                        <div className="p-1 rounded bg-[hsl(var(--color-active))]/10">
                            <Star className="w-3 h-3 text-[hsl(var(--color-active))]" />
                        </div>
                        <OrientingText className="text-[hsl(var(--color-active))]">INTELLIGENCE LAYER</OrientingText>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        <Button onClick={() => onDraft(selectedMessage, 'professional')} variant="outline" size="sm" className="text-xs border-white/10 bg-neutral-950 hover:bg-neutral-900 text-neutral-400 hover:text-white transition-colors">
                            Draft: Professional Reply
                        </Button>
                        <Button onClick={() => onDraft(selectedMessage, 'ack')} variant="outline" size="sm" className="text-xs border-white/10 bg-neutral-950 hover:bg-neutral-900 text-neutral-400 hover:text-white transition-colors">
                            Draft: Brief Ack
                        </Button>
                        {/* Summary is still simulated for now as it doesn't open composer */}
                        <Button onClick={() => toast.success("Thread summary generated")} variant="outline" size="sm" className="text-xs border-white/10 bg-neutral-950 hover:bg-neutral-900 text-neutral-400 hover:text-white transition-colors">
                            Summarize Thread
                        </Button>
                    </div>
                    </div>
            </div>
        </div>
    );
};

export default function UnifiedInbox({ messages = [], onReply, onDraft, onArchive, onDelete }) {
    const [selectedId, setSelectedId] = useState(null);
    const [searchTerm, setSearchTerm] = useState("");
    const [filter, setFilter] = useState("all"); // all, unread, flagged
    const [sourceFilter, setSourceFilter] = useState("all");

    // Extract unique sources
    const sources = ['all', ...new Set(messages.map(m => m.source))];

    const filteredMessages = messages.filter(msg => {
        const matchesSearch = msg.subject?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              msg.client?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              msg.full?.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesFilter = filter === 'all' ? true : 
                              filter === 'unread' ? msg.status === 'unread' : true;
        const matchesSource = sourceFilter === 'all' ? true : msg.source === sourceFilter;
        
        return matchesSearch && matchesFilter && matchesSource;
    });

    const selectedMessage = messages.find(m => m.id === selectedId);

    return (
        <div className="flex h-full w-full bg-neutral-950">


            {/* List Sidebar - Fixed Width */}
            <div className="w-[350px] shrink-0 border-r border-white/5 flex flex-col bg-neutral-900/30">
                <InboxList 
                    messages={filteredMessages}
                    selectedId={selectedId}
                    onSelect={setSelectedId}
                    searchTerm={searchTerm}
                    setSearchTerm={setSearchTerm}
                    filter={filter}
                    setFilter={setFilter}
                    sourceFilter={sourceFilter}
                    setSourceFilter={setSourceFilter}
                    sources={sources}
                />
            </div>

            {/* Detail View - Flexible */}
            <div className="flex-1 min-w-0 flex flex-col bg-neutral-950 relative">
                <InboxDetail 
                    selectedMessage={selectedMessage}
                    onReply={onReply}
                    onDraft={onDraft}
                    onArchive={onArchive}
                    onDelete={onDelete}
                    onClose={() => setSelectedId(null)}
                />
            </div>
        </div>
    );
}