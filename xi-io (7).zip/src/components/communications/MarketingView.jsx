import React from 'react';
import { 
  BarChart, TrendingUp, Users, Target, Calendar,
  Mail, MessageSquare, ArrowUpRight, Plus, ExternalLink
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';
import { cn } from "@/lib/utils";

export default function MarketingView({ campaigns = [], onNewCampaign }) {
    return (
        <QuadrantGrid className="p-0 h-full gap-0 grid-rows-[auto_1fr]">
             {/* Header */}
             <Quadrant type="orientation" className="border-b">
                 <div className="flex justify-between items-center h-full">
                    <div>
                        <OrientingText className="mb-1">CAMPAIGN OPERATIONS</OrientingText>
                        <IntentText className="text-xl">Active Initiatives</IntentText>
                    </div>
                    <div className="flex gap-4 text-right">
                        <div className="hidden md:block">
                            <StateText className="text-[10px] uppercase tracking-wider opacity-50">Total Reach</StateText>
                            <div className="font-mono text-lg text-white">2.4M</div>
                        </div>
                        <div className="hidden md:block w-px h-8 bg-white/10" />
                        <div className="hidden md:block">
                            <StateText className="text-[10px] uppercase tracking-wider opacity-50">Avg. Conv</StateText>
                            <div className="font-mono text-lg text-[hsl(var(--color-active))]">3.2%</div>
                        </div>
                    </div>
                </div>
            </Quadrant>

            {/* Content */}
            <Quadrant type="intent" dominance="dominant" className="border-t-0 rounded-t-none">
                {campaigns.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center opacity-50 border-2 border-dashed border-white/5 rounded-xl bg-neutral-900/20">
                        <Target className="w-12 h-12 text-neutral-700 mb-4" />
                        <OrientingText className="mb-4">No active campaigns detected.</OrientingText>
                        <Button onClick={onNewCampaign} variant="outline" className="border-[hsl(var(--color-active))] text-[hsl(var(--color-active))] hover:bg-[hsl(var(--color-active))]/10">
                            <Plus className="w-4 h-4 mr-2" /> Initialize Campaign
                        </Button>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-4">
                        {/* New Campaign Card */}
                        <div 
                            onClick={onNewCampaign}
                            className="group flex flex-col items-center justify-center p-6 border border-dashed border-white/10 rounded-xl bg-white/0 hover:bg-white/5 cursor-pointer transition-all min-h-[200px]"
                        >
                            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                <Plus className="w-6 h-6 text-neutral-400 group-hover:text-white" />
                            </div>
                            <IntentText className="text-neutral-400 group-hover:text-white transition-colors">New Campaign</IntentText>
                        </div>

                        {/* Campaign Cards */}
                        {campaigns.map(c => (
                            <Layer key={c.id} level="intent" className="flex flex-col gap-4 group cursor-pointer hover:border-[hsl(var(--color-active))]/50 transition-all hover:-translate-y-1 relative overflow-hidden">
                                {c.status === 'active' && (
                                    <div className="absolute top-0 right-0 p-2">
                                        <span className="relative flex h-2 w-2">
                                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[hsl(var(--color-active))] opacity-75"></span>
                                          <span className="relative inline-flex rounded-full h-2 w-2 bg-[hsl(var(--color-active))]"></span>
                                        </span>
                                    </div>
                                )}
                                
                                <div className="flex items-start justify-between pr-4">
                                    <div className="flex items-center gap-3">
                                        <div className="p-2 rounded bg-neutral-950 border border-white/10">
                                            {c.type === 'email' ? <Mail className="w-4 h-4 text-[hsl(var(--color-intent))]" /> : <MessageSquare className="w-4 h-4 text-[hsl(var(--color-active))]" />}
                                        </div>
                                        <div>
                                            <StateText className="text-[10px] uppercase tracking-wider mb-0.5">{c.type}</StateText>
                                            <IntentText className="font-bold line-clamp-1">{c.name}</IntentText>
                                        </div>
                                    </div>
                                </div>

                                <div className="space-y-3 py-2">
                                    <div className="space-y-1">
                                        <div className="flex justify-between text-xs">
                                            <span className="text-neutral-500">Progress</span>
                                            <span className="text-white font-mono">64%</span>
                                        </div>
                                        <Progress value={64} className="h-1 bg-neutral-950" indicatorClassName="bg-[hsl(var(--color-intent))]" />
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
                                        <div>
                                            <StateText className="text-[9px] uppercase tracking-wider opacity-50">Reach</StateText>
                                            <div className="font-mono text-sm text-white">{c.reach?.toLocaleString()}</div>
                                        </div>
                                        <div>
                                            <StateText className="text-[9px] uppercase tracking-wider opacity-50">Conv.</StateText>
                                            <div className="font-mono text-sm text-[hsl(var(--color-active))]">{c.conversion_rate}%</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div className="flex items-center justify-between pt-2">
                                    <Badge variant="outline" className={cn(
                                        "text-[10px] px-1.5 h-5 border-white/5", 
                                        c.status === 'active' ? "text-[hsl(var(--color-active))]" : "text-neutral-500"
                                    )}>
                                        {c.status}
                                    </Badge>
                                    <Button size="icon" variant="ghost" className="h-6 w-6 text-neutral-500 hover:text-white">
                                        <ArrowUpRight className="w-3 h-3" />
                                    </Button>
                                </div>
                            </Layer>
                        ))}
                    </div>
                )}
            </Quadrant>
        </QuadrantGrid>
    );
}