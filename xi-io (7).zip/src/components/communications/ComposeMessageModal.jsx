import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Send, Mail, MessageSquare, Share2, Loader2, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { SystemCompletion } from '@/components/ui/design-system/SystemDialogs';

export default function ComposeMessageModal({ open, onOpenChange, onSent, initialData = null, type = 'email' }) {
    const [channel, setChannel] = useState(type);
    const [recipient, setRecipient] = useState('');
    const [subject, setSubject] = useState('');
    const [content, setContent] = useState('');
    const [showSuccess, setShowSuccess] = useState(false);
    const queryClient = useQueryClient();

    // Reset or populate form when opening
    useEffect(() => {
        if (open) {
            setShowSuccess(false);
            setChannel(type);
            if (initialData) {
                // Reply mode
                setRecipient(initialData.client || '');
                setSubject(initialData.subject && !initialData.subject.startsWith('Re:') ? `Re: ${initialData.subject}` : (initialData.subject || ''));
                setContent(initialData.content || ''); // Use pre-filled content if available (e.g. AI drafts)
            } else {
                // New message mode
                setRecipient('');
                setSubject('');
                setContent('');
            }
        }
    }, [open, initialData, type]);

    const sendMessageMutation = useMutation({
        mutationFn: async () => {
            // In a real app, this would call an integration
            // For now, we'll create a Log entry to simulate the sent message
            return await base44.entities.Log.create({
                type: channel === 'email' ? 'system' : channel === 'social' ? 'system' : 'system', // Mapping to allowed types
                direction: 'outbound',
                remote_identity: recipient || 'Public',
                content: `[${channel.toUpperCase()}] ${subject ? subject + ': ' : ''}${content}`,
                status: 'completed',
                timestamp: new Date().toISOString()
            });
        },
        onSuccess: (data, variables, context) => {
            queryClient.invalidateQueries(['unified_inbox']); 
            setShowSuccess(true);
            if (onSent) onSent({ channel, recipient, subject, content });
        },
        onError: () => {
            toast.error("Transmission failed");
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        sendMessageMutation.mutate();
    };

    if (showSuccess) {
        return (
            <SystemCompletion 
                open={open}
                onOpenChange={onOpenChange}
                title="Transmission Sent"
                description={`Message successfully delivered via ${channel}.`}
                stats={[
                    { label: "Recipient", value: recipient || "Public" },
                    { label: "Channel", value: channel.toUpperCase() }
                ]}
            />
        );
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-neutral-900 border-white/10 text-white sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Send className="w-4 h-4 text-[hsl(var(--color-active))]" />
                        <span className="font-light tracking-wide">
                            {initialData ? 'REPLY TERMINAL' : 'COMPOSE TRANSMISSION'}
                        </span>
                    </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Channel</Label>
                            <Select value={channel} onValueChange={setChannel} disabled={!!initialData}>
                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="email"><div className="flex items-center gap-2"><Mail className="w-3 h-3"/> Email</div></SelectItem>
                                    <SelectItem value="social"><div className="flex items-center gap-2"><Share2 className="w-3 h-3"/> Social Post</div></SelectItem>
                                    <SelectItem value="sms"><div className="flex items-center gap-2"><MessageSquare className="w-3 h-3"/> SMS</div></SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>{channel === 'social' ? 'Platform' : 'Recipient'}</Label>
                            {channel === 'social' ? (
                                <Select value={recipient} onValueChange={setRecipient}>
                                    <SelectTrigger className="bg-neutral-950 border-white/10">
                                        <SelectValue placeholder="Select Platform" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="twitter">Twitter / X</SelectItem>
                                        <SelectItem value="linkedin">LinkedIn</SelectItem>
                                        <SelectItem value="all">All Channels</SelectItem>
                                    </SelectContent>
                                </Select>
                            ) : (
                                <Input 
                                    value={recipient} 
                                    onChange={(e) => setRecipient(e.target.value)} 
                                    className="bg-neutral-950 border-white/10" 
                                    placeholder="user@example.com"
                                    required
                                />
                            )}
                        </div>
                    </div>

                    {channel !== 'social' && (
                        <div className="space-y-2">
                            <Label>Subject</Label>
                            <Input 
                                value={subject} 
                                onChange={(e) => setSubject(e.target.value)} 
                                className="bg-neutral-950 border-white/10" 
                                placeholder="Subject line..."
                            />
                        </div>
                    )}

                    <div className="space-y-2">
                        <Label>Content</Label>
                        <Textarea 
                            value={content} 
                            onChange={(e) => setContent(e.target.value)} 
                            className="bg-neutral-950 border-white/10 min-h-[200px] font-mono text-sm" 
                            placeholder={channel === 'social' ? "What's happening?" : "Message content..."}
                            required
                        />
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Discard</Button>
                        <Button 
                            type="submit" 
                            className="bg-[hsl(var(--color-active))] text-black font-bold hover:bg-[hsl(var(--color-active))]/90"
                            disabled={sendMessageMutation.isPending}
                        >
                            {sendMessageMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
                            Transmit
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}