import React, { createContext, useContext, useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import { Trophy, Star, Zap } from 'lucide-react';

const GamificationContext = createContext();

export const useGamification = () => useContext(GamificationContext);

export const GamificationProvider = ({ children }) => {
    const queryClient = useQueryClient();
    const [completedTutorials, setCompletedTutorials] = useState([]); // In real app, persist this
    const [currentUser, setCurrentUser] = useState(null);

    // Initial user load
    useEffect(() => {
        base44.auth.me().then(u => setCurrentUser(u)).catch(() => {});
    }, []);

    const { data: userXP } = useQuery({
        queryKey: ['user_xp', currentUser?.email],
        queryFn: async () => {
            if (!currentUser) return null;
            const list = await base44.entities.UserXP.list({ user_email: currentUser.email });
            return list[0] || { xp: 0, level: 1, achievements: [] };
        },
        enabled: !!currentUser
    });

    const addXPMutation = useMutation({
        mutationFn: async ({ amount, action }) => {
            if (!currentUser) return;
            const current = userXP || { xp: 0, level: 1, achievements: [] };
            
            // Calculate new level (simple formula: level * 1000 XP)
            const newXP = (current.xp || 0) + amount;
            const newLevel = Math.floor(newXP / 1000) + 1;
            const levelUp = newLevel > (current.level || 1);

            const data = {
                user_email: currentUser.email,
                xp: newXP,
                level: newLevel,
                achievements: current.achievements || []
            };

            if (current.id) {
                await base44.entities.UserXP.update(current.id, data);
            } else {
                await base44.entities.UserXP.create(data);
            }
            return { levelUp, newLevel, action };
        },
        onSuccess: ({ levelUp, newLevel, action }) => {
            queryClient.invalidateQueries(['user_xp']);
            if (levelUp) {
                const quotes = [
                    "Your power level is over 9000! (Almost)",
                    "System upgrade complete. You are now faster, stronger, better.",
                    "Achievement Unlocked: Sleep Deprivation.",
                    "You're a wizard, Harry! Or... a dev.",
                ];
                toast.success(`LEVEL ${newLevel} REACHED!`, {
                    description: quotes[Math.floor(Math.random() * quotes.length)],
                    icon: <Trophy className="w-5 h-5 text-[hsl(var(--color-review))]" />,
                    className: "border border-[hsl(var(--color-review))]"
                });
            } else {
                 toast(`+${action.amount || 10} XP`, {
                    description: `${action} complete. The machine spirit is pleased.`,
                    icon: <Zap className="w-4 h-4 text-[hsl(var(--color-execution))]" />,
                    duration: 2000,
                    className: "border border-[hsl(var(--color-execution))]"
                });
            }
        }
    });

    const awardXP = (amount, action) => {
        addXPMutation.mutate({ amount, action });
    };

    return (
        <GamificationContext.Provider value={{ userXP, awardXP }}>
            {children}
        </GamificationContext.Provider>
    );
};

export const XPBar = () => {
    const { userXP } = useGamification();
    if (!userXP) return null;

    const currentLevelXP = (userXP.level - 1) * 1000;
    const nextLevelXP = userXP.level * 1000;
    const progress = ((userXP.xp - currentLevelXP) / 1000) * 100;

    // Mock Streak
    const streak = 3;

    return (
        <div className="w-full px-4 py-2">
            <div className="flex justify-between items-center text-[10px] text-[hsl(var(--fg-orientation))] mb-1 font-mono">
                <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1 text-[hsl(var(--color-review))] font-bold">
                        <Trophy className="w-3 h-3" /> LVL {userXP.level}
                    </span>
                    <span className="flex items-center gap-1 text-[hsl(var(--color-execution))] opacity-80" title="Daily Coding Streak">
                        <Zap className="w-3 h-3" /> {streak} DAY STREAK
                    </span>
                </div>
                <span>{Math.floor(userXP.xp)} XP</span>
            </div>
            <div className="h-1.5 w-full bg-[hsl(var(--layer-state))] rounded-full overflow-hidden border border-white/5">
                <div 
                    className="h-full bg-gradient-to-r from-[hsl(var(--color-review))] to-[hsl(var(--color-intent))] transition-all duration-1000 ease-out shadow-[0_0_10px_hsl(var(--color-review))]"
                    style={{ width: `${progress}%` }}
                />
            </div>
        </div>
    );
};