import React, { createContext, useContext, useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import { Bookmark as BookmarkIcon, Tag } from 'lucide-react';
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLocation } from 'react-router-dom';

const BookmarkContext = createContext();

export const useBookmarks = () => useContext(BookmarkContext);

export const BookmarkProvider = ({ children }) => {
    const queryClient = useQueryClient();
    const [currentUser, setCurrentUser] = useState(null);

    useEffect(() => {
        base44.auth.me().then(u => setCurrentUser(u)).catch(() => {});
    }, []);

    const { data: bookmarks = [] } = useQuery({
        queryKey: ['bookmarks', currentUser?.email],
        queryFn: async () => {
            if (!currentUser) return [];
            return base44.entities.Bookmark.list({ user_email: currentUser.email });
        },
        enabled: !!currentUser
    });

    const toggleBookmarkMutation = useMutation({
        mutationFn: async ({ url, title, type, id }) => {
            if (!currentUser) throw new Error("Login required");
            
            const existing = bookmarks.find(b => b.url === url);
            
            if (existing) {
                await base44.entities.Bookmark.delete(existing.id);
                return { action: 'removed' };
            } else {
                await base44.entities.Bookmark.create({
                    user_email: currentUser.email,
                    target_id: id || 'page',
                    target_type: type || 'page',
                    title: title || 'Untitled',
                    url: url,
                    tags: []
                });
                return { action: 'added' };
            }
        },
        onSuccess: ({ action }) => {
            queryClient.invalidateQueries(['bookmarks']);
            toast.success(action === 'added' ? "Bookmarked!" : "Bookmark removed");
        }
    });

    const toggleBookmark = (url, title, type, id) => {
        toggleBookmarkMutation.mutate({ url, title, type, id });
    };

    const isBookmarked = (url) => bookmarks.some(b => b.url === url);

    return (
        <BookmarkContext.Provider value={{ bookmarks, toggleBookmark, isBookmarked }}>
            {children}
        </BookmarkContext.Provider>
    );
};

export const BookmarkToggle = ({ title, type, id, className }) => {
    const location = useLocation();
    const { isBookmarked, toggleBookmark } = useBookmarks();
    const url = location.pathname;
    const active = isBookmarked(url);

    return (
        <Button
            variant="ghost"
            size="icon"
            onClick={() => toggleBookmark(url, title, type, id)}
            className={`transition-all ${active ? 'text-yellow-400 hover:text-yellow-300' : 'text-neutral-500 hover:text-white'} ${className}`}
        >
            <BookmarkIcon className={`w-4 h-4 ${active ? 'fill-current' : ''}`} />
        </Button>
    );
};