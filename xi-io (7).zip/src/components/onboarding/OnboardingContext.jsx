import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const OnboardingContext = createContext();

export const useOnboarding = () => useContext(OnboardingContext);

export const OnboardingProvider = ({ children }) => {
    const [activeTutorial, setActiveTutorial] = useState(null); // 'search', 'semantic', 'roadmap'
    const [completedTutorials, setCompletedTutorials] = useState([]);
    const [userContext, setUserContext] = useState({
        intent: 'unknown', // 'developer', 'business', 'explorer'
        familiarity: 'novice', // 'novice', 'intermediate', 'expert'
    });
    const [isOnboardingVisible, setIsOnboardingVisible] = useState(false);
    const location = useLocation();

    // Load state from local storage on mount
    useEffect(() => {
        const saved = localStorage.getItem('xi_onboarding_state');
        if (saved) {
            try {
                const parsed = JSON.parse(saved);
                setCompletedTutorials(parsed.completedTutorials || []);
                setUserContext(parsed.userContext || { intent: 'unknown', familiarity: 'novice' });
            } catch (e) {
                console.error("Failed to parse onboarding state", e);
            }
        }
    }, []);

    // Save state
    useEffect(() => {
        localStorage.setItem('xi_onboarding_state', JSON.stringify({
            completedTutorials,
            userContext
        }));
    }, [completedTutorials, userContext]);

    // Auto-trigger tutorials based on route if not completed
    useEffect(() => {
        // Example logic: if on SearchResults and haven't done 'search' tutorial, maybe trigger it?
        // For now, we'll let the UI components trigger it via buttons or "first time" checks.
        
        if (location.pathname === '/SearchResults' && !completedTutorials.includes('semantic_stack')) {
            // Optional: Auto-trigger or show a "Start Tour" button
        }
    }, [location.pathname, completedTutorials]);

    const startTutorial = (tutorialId) => {
        setActiveTutorial(tutorialId);
    };

    const endTutorial = () => {
        if (activeTutorial) {
            setCompletedTutorials(prev => [...new Set([...prev, activeTutorial])]);
            setActiveTutorial(null);
        }
    };

    const updateUserContext = (newContext) => {
        setUserContext(prev => ({ ...prev, ...newContext }));
    };

    const startOnboarding = () => setIsOnboardingVisible(true);
    const closeOnboarding = () => setIsOnboardingVisible(false);

    return (
        <OnboardingContext.Provider value={{
            activeTutorial,
            startTutorial,
            endTutorial,
            completedTutorials,
            userContext,
            updateUserContext,
            isOnboardingVisible,
            startOnboarding,
            closeOnboarding
        }}>
            {children}
        </OnboardingContext.Provider>
    );
};