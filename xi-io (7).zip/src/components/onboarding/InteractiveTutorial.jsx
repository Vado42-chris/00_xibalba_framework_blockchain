import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, CheckCircle2, Zap } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useOnboarding } from './OnboardingContext';

// Tutorial definitions
const TUTORIALS = {
    search: {
        title: "Mastering the Index",
        steps: [
            {
                target: "search-input", // ID or selector
                title: "The Omni-Bar",
                content: "This isn't just a keyword search. It accepts natural language, commands, and semantic queries.",
                position: "bottom"
            },
            {
                target: "scope-selector",
                title: "Scope Control",
                content: "Switch between 'Local' (your data) and 'Web' (the global index). Local is private/secure.",
                position: "bottom"
            },
            {
                target: "engine-selector",
                title: "Engine Proxy",
                content: "Route your web queries through different privacy layers or 'Zipper' mode for raw data access.",
                position: "bottom"
            }
        ]
    },
    semantic_stack: {
        title: "The Semantic Stack",
        steps: [
            {
                target: "semantic-view-toggle",
                title: "View Shift",
                content: "Toggle between standard lists and the Semantic Stack to see the 'shape' of your data.",
                position: "bottom"
            },
            {
                target: "stack-column-who",
                title: "Actors (Who)",
                content: "People, organizations, and AI agents involved in the context.",
                position: "right"
            },
            {
                target: "stack-column-what",
                title: "Objects (What)",
                content: "Documents, assets, products, and core entities.",
                position: "right"
            },
            {
                target: "deep-scan-btn",
                title: "Deep Scan",
                content: "Use AI to infer missing connections and hidden relationships between entities.",
                position: "top"
            }
        ]
    }
};

export const TutorialOverlay = () => {
    const { activeTutorial, endTutorial } = useOnboarding();
    const [currentStep, setCurrentStep] = useState(0);
    const [targetRect, setTargetRect] = useState(null);

    const tutorial = TUTORIALS[activeTutorial];

    useEffect(() => {
        if (!tutorial) return;
        
        const updatePosition = () => {
            const step = tutorial.steps[currentStep];
            // We assume elements have id="{target}" or data-tutorial="{target}"
            const element = document.getElementById(step.target) || document.querySelector(`[data-tutorial="${step.target}"]`);
            
            if (element) {
                const rect = element.getBoundingClientRect();
                setTargetRect({
                    top: rect.top,
                    left: rect.left,
                    width: rect.width,
                    height: rect.height,
                    position: step.position
                });
                // Scroll to element if needed
                element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                // Skip step if target not found
                console.warn(`Tutorial target ${step.target} not found`);
                if (currentStep < tutorial.steps.length - 1) {
                    setCurrentStep(prev => prev + 1);
                } else {
                    endTutorial();
                }
            }
        };

        // Small delay to ensure UI renders
        const timer = setTimeout(updatePosition, 500);
        window.addEventListener('resize', updatePosition);
        
        return () => {
            clearTimeout(timer);
            window.removeEventListener('resize', updatePosition);
        };
    }, [activeTutorial, currentStep, tutorial]);

    if (!activeTutorial || !tutorial) return null;

    const step = tutorial.steps[currentStep];
    const isLast = currentStep === tutorial.steps.length - 1;

    const handleNext = () => {
        if (isLast) {
            endTutorial();
            setCurrentStep(0);
        } else {
            setCurrentStep(prev => prev + 1);
        }
    };

    return (
        <AnimatePresence>
            <div className="fixed inset-0 z-[200] pointer-events-none">
                {/* Backdrop with cutout effect approach or just dimming */}
                {/* For simplicity, we just dim the background and highlight the target with a separate ring */}
                <div className="absolute inset-0 bg-neutral-950/50 backdrop-blur-[1px]" />

                {/* Target Highlighter */}
                {targetRect && (
                    <motion.div
                        layoutId="tutorial-highlight"
                        className="absolute border-2 border-[hsl(var(--color-intent))] rounded-lg shadow-[0_0_20px_rgba(var(--color-intent-rgb),0.5)] bg-transparent pointer-events-none"
                        style={{
                            top: targetRect.top - 4,
                            left: targetRect.left - 4,
                            width: targetRect.width + 8,
                            height: targetRect.height + 8,
                        }}
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                )}

                {/* Tooltip Card */}
                {targetRect && (
                    <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        key={currentStep}
                        className={cn(
                            "absolute pointer-events-auto w-80 bg-neutral-900 border border-white/10 rounded-xl p-5 shadow-2xl flex flex-col gap-3",
                            // Simple positioning logic
                            step.position === 'bottom' && "mt-4",
                            step.position === 'top' && "-mt-4 -translate-y-full",
                            step.position === 'right' && "ml-4",
                            step.position === 'left' && "-ml-4 -translate-x-full",
                        )}
                        style={{
                            top: step.position === 'bottom' ? targetRect.top + targetRect.height : 
                                 step.position === 'top' ? targetRect.top : 
                                 targetRect.top,
                            left: step.position === 'right' ? targetRect.left + targetRect.width : 
                                  step.position === 'left' ? targetRect.left :
                                  targetRect.left // Default alignment
                        }}
                    >
                        <div className="flex justify-between items-start">
                            <h3 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
                                <Zap className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                                {step.title}
                            </h3>
                            <button onClick={endTutorial} className="text-neutral-500 hover:text-white">
                                <X className="w-4 h-4" />
                            </button>
                        </div>
                        <p className="text-xs text-neutral-400 leading-relaxed">
                            {step.content}
                        </p>
                        <div className="flex justify-between items-center mt-2 pt-3 border-t border-white/5">
                            <span className="text-[10px] text-neutral-600 font-mono">
                                STEP {currentStep + 1}/{tutorial.steps.length}
                            </span>
                            <Button 
                                size="sm" 
                                onClick={handleNext}
                                className="h-7 text-xs bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90"
                            >
                                {isLast ? 'Complete' : 'Next'} <ChevronRight className="w-3 h-3 ml-1" />
                            </Button>
                        </div>
                    </motion.div>
                )}
            </div>
        </AnimatePresence>
    );
};