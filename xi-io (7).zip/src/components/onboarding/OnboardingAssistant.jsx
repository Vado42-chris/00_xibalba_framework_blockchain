import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronRight, ChevronLeft, Lightbulb, Map, Database, LayoutGrid, CreditCard, Code, Megaphone, Shield, MessageSquare } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useLanguage } from '@/components/identity/LanguageContext';
import { base44 } from '@/api/base44Client';

const DEFAULT_STEPS = [
    {
        title: "Welcome to Seed001",
        content: "System is live. I'll guide you based on where you are and what you need to do.",
        icon: Lightbulb,
        color: "text-yellow-400"
    }
];

export default function OnboardingAssistant() {
    const [isVisible, setIsVisible] = useState(false);
    const [currentStep, setCurrentStep] = useState(0);
    const [dynamicSteps, setDynamicSteps] = useState(DEFAULT_STEPS);
    const { mode } = useLanguage(); 
    const location = useLocation();

    // Proactive Support Monitor
    useEffect(() => {
        const checkInactivity = setTimeout(() => {
            // If user is idle on the page for 10 seconds, offer help
            if (!isVisible) {
                setDynamicSteps(prev => [{
                    title: "Need Help?",
                    content: "I noticed you've been here a while. Can I explain anything about this page?",
                    icon: Lightbulb,
                    color: "text-white"
                }, ...prev]);
                setIsVisible(true);
            }
        }, 10000);

        return () => clearTimeout(checkInactivity);
    }, [location.pathname, isVisible]);

    useEffect(() => {
        // Reset visibility on route change to show relevant tips
        setIsVisible(true);
        setCurrentStep(0);
        
        const customizeFlow = async () => {
            let role = 'guest';
            try {
                const user = await base44.auth.me();
                role = user?.role || 'guest';
            } catch (e) {}

            let steps = [];

            // Context-Aware Steps based on Path
            if (location.pathname === '/Docs') {
                steps.push({
                    title: "SEED001 Protocol",
                    content: "Reviewing the Execution Protocol? Phase Alpha (Deployment) is the most critical step. Ensure your backend is live before validation.",
                    icon: Shield,
                    color: "text-red-500"
                });
            } else if (location.pathname === '/Commerce') {
                steps.push({
                    title: "Setup Revenue",
                    content: "You are in the Commerce module. Use the 'Test Subscription' button to verify the payment circuit.",
                    icon: CreditCard,
                    color: "text-emerald-400"
                });
            } else if (location.pathname === '/SeedJourney') {
                steps.push({
                    title: "The Execution Map",
                    content: "This is your deployment checklist. Follow Phase Alpha to connect your backend.",
                    icon: Map,
                    color: "text-blue-400"
                });
            } else if (location.pathname === '/Dashboard') {
                steps.push({
                    title: "Command Center",
                    content: "Don't miss the 'Execute Sequence' widget. It's your primary action item.",
                    icon: LayoutGrid,
                    color: "text-purple-400"
                });
            }

            // Role-Based Steps
            if (role === 'admin') {
                steps.push({
                    title: "CEO / Admin Mode",
                    content: "As an admin, check '/Settings' to configure RBAC and Data Archiving policies.",
                    icon: Shield,
                    color: "text-red-500"
                });
            } else {
                steps.push({
                    title: "User Mode",
                    content: "Explore the platform features. Your feedback in the 'Support' widget is valuable.",
                    icon: MessageSquare,
                    color: "text-blue-400"
                });
            }

            // Fallback if no specific context
            if (steps.length === 0) {
                steps = [
                    {
                        title: "Explore the System",
                        content: "Navigate to '/SmartStart' for a consolidated view of all tools.",
                        icon: Lightbulb,
                        color: "text-yellow-400"
                    }
                ];
            }

            setDynamicSteps(steps);
        };

        customizeFlow();
    }, [location.pathname, mode]);

    const handleNext = () => {
        if (currentStep < dynamicSteps.length - 1) {
            setCurrentStep(currentStep + 1);
        } else {
            setIsVisible(false);
        }
    };

    const handlePrev = () => {
        if (currentStep > 0) {
            setCurrentStep(currentStep - 1);
        }
    };

    if (!isVisible) return null;

    const currentStepData = dynamicSteps[currentStep] || STEPS[0];
    const StepIcon = currentStepData.icon;

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0, y: 50, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.9 }}
                className="fixed bottom-24 left-6 z-[90] w-80 bg-neutral-900/90 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl overflow-hidden"
            >
                <div className="relative p-6">
                    {/* Close Button */}
                    <button 
                        onClick={() => setIsVisible(false)}
                        className="absolute top-2 right-2 p-1 text-neutral-500 hover:text-white transition-colors"
                    >
                        <X className="w-4 h-4" />
                    </button>

                    {/* Content */}
                    <div className="flex flex-col items-center text-center space-y-4">
                        <div className={cn("w-12 h-12 rounded-full flex items-center justify-center bg-white/5 border border-white/5", currentStepData.color)}>
                            <StepIcon className="w-6 h-6" />
                        </div>
                        
                        <div className="space-y-2">
                            <h3 className="text-lg font-bold text-white">{currentStepData.title}</h3>
                            <p className="text-sm text-neutral-400 leading-relaxed">
                                {currentStepData.content}
                            </p>
                        </div>
                    </div>

                    {/* Progress Dots */}
                    <div className="flex justify-center gap-1.5 mt-6 mb-2">
                        {dynamicSteps.map((_, idx) => (
                            <div 
                                key={idx}
                                className={cn(
                                    "w-1.5 h-1.5 rounded-full transition-colors",
                                    idx === currentStep ? "bg-[hsl(var(--color-intent))]" : "bg-white/10"
                                )}
                            />
                        ))}
                    </div>

                    {/* Navigation */}
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={handlePrev}
                            disabled={currentStep === 0}
                            className="text-neutral-500 hover:text-white disabled:opacity-30"
                        >
                            <ChevronLeft className="w-4 h-4 mr-1" /> Back
                        </Button>
                        <Button 
                            size="sm" 
                            onClick={handleNext}
                            className="bg-white text-black hover:bg-neutral-200"
                        >
                            {currentStep === dynamicSteps.length - 1 ? "Get Started" : "Next"}
                            {currentStep < dynamicSteps.length - 1 && <ChevronRight className="w-4 h-4 ml-1" />}
                        </Button>
                    </div>
                </div>
            </motion.div>
        </AnimatePresence>
    );
}