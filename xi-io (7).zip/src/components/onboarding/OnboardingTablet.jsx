import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    ChevronRight, Globe, Shield, Terminal, 
    CheckCircle2, ArrowRight, Laptop, Server, 
    Smartphone, Lock, Code, Sparkles, Download, 
    Box, Cpu, Zap, ShoppingBag, FileText, Scale, Book, CreditCard
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { BrowserWindow } from "@/components/ui/BrowserWindow";
import { cn } from "@/lib/utils";
import { useOnboarding } from "@/components/onboarding/OnboardingContext";
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useSiteContext } from '@/components/identity/SiteContext';
import { StripeWizard } from '@/components/commerce/StripeWizard';

// Reusable animated step container
const StepContainer = ({ children }) => (
    <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="max-w-4xl mx-auto p-8 h-full flex flex-col justify-center overflow-y-auto scrollbar-none"
    >
        {children}
    </motion.div>
);

const STEPS = [
    {
        id: 'legal',
        title: "System Agreement",
        url: "legal.base44.io/terms",
        component: ({ onNext }) => (
            <StepContainer>
                <div className="text-center mb-8">
                    <div className="inline-flex items-center justify-center p-3 rounded-full bg-white/5 mb-4">
                        <Scale className="w-8 h-8 text-[hsl(var(--color-intent))]" />
                    </div>
                    <h1 className="text-3xl font-bold text-white mb-2">Protocol Access Agreement</h1>
                    <p className="text-neutral-400">Review terms before establishing uplink.</p>
                </div>

                <div className="bg-white/[0.03] border border-white/10 rounded-xl p-6 mb-8 max-h-[300px] overflow-y-auto text-left font-mono text-xs text-neutral-400 space-y-4 shadow-inner relative group">
                    <div className="absolute top-0 right-0 p-4 opacity-50 group-hover:opacity-100 transition-opacity">
                        <Badge variant="outline" className="border-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))] cursor-pointer hover:bg-[hsl(var(--color-intent))] hover:text-black transition-colors" onClick={() => window.open('https://docs.base44.io', '_blank')}>
                            VIEW FULL DOCS <Globe className="w-3 h-3 ml-1" />
                        </Badge>
                    </div>
                    <p><strong className="text-white">1. SOVEREIGNTY CLAUSE</strong><br/>You acknowledge that you are the sole custodian of your private keys. The System cannot recover lost credentials.</p>
                    <p><strong className="text-white">2. DECENTRALIZED LIABILITY</strong><br/>You accept full responsibility for all content and applications deployed on your node.</p>
                    <p><strong className="text-white">3. EVOLUTIONARY COMPLIANCE</strong><br/>The System will evolve. You agree to maintain your node's compatibility with the core protocol updates.</p>
                    <p><strong className="text-white">4. FAIR USE</strong><br/>Network resources must not be used for malicious interference with other Sovereign Nodes.</p>
                    <div className="h-px bg-white/10 my-4" />
                    <div className="flex items-center gap-2 text-[hsl(var(--color-intent))] animate-pulse">
                        <Shield className="w-4 h-4" />
                        <span>SIGNATURE_REQUIRED: _______________________</span>
                    </div>
                </div>

                <div className="flex flex-col items-center gap-4">
                    <Button onClick={onNext} className="w-full max-w-sm h-12 bg-[hsl(var(--color-intent))] text-black font-bold hover:bg-[hsl(var(--color-intent))]/90">
                        ACCEPT & INITIALIZE <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                    <p className="text-[10px] text-neutral-500">
                        By clicking Accept, you cryptographically sign this agreement.
                    </p>
                </div>
            </StepContainer>
        )
    },
    {
        id: 'manifesto',
        title: "Protocol Manifesto",
        url: "manifesto.base44.io",
        component: ({ onNext }) => (
            <StepContainer>
                <div className="text-center space-y-8">
                    <div className="inline-flex items-center justify-center p-1 rounded-full border border-white/10 bg-white/5 backdrop-blur-md mb-4">
                        <div className="px-4 py-1 text-xs font-bold tracking-widest text-neutral-400 uppercase">System Awakening</div>
                    </div>
                    
                    <h1 className="text-6xl md:text-7xl font-bold tracking-tighter text-white">
                        Access <span className="text-transparent bg-clip-text bg-gradient-to-r from-[hsl(var(--color-intent))] to-white">Granted</span>.
                    </h1>
                    
                    <p className="text-xl md:text-2xl text-neutral-400 leading-relaxed max-w-2xl mx-auto">
                        Welcome to the Sovereign Web. You are no longer just a user. 
                        You are an operator with full control over your digital infrastructure.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-12">
                        {[
                            { icon: Shield, title: "Sovereign Identity", desc: "Your keys, your data. Unbreakable privacy." },
                            { icon: Cpu, title: "Local Intelligence", desc: "AI that runs on your metal, serving only you." },
                            { icon: Zap, title: "Instant Scale", desc: "Deploy globally without permission." }
                        ].map((feat, i) => (
                            <div key={i} className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.05] hover:border-white/20 transition-all group text-left">
                                <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                                    <feat.icon className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                                </div>
                                <h3 className="font-bold text-lg text-white mb-2">{feat.title}</h3>
                                <p className="text-sm text-neutral-500 leading-relaxed">{feat.desc}</p>
                            </div>
                        ))}
                    </div>

                    <Button onClick={onNext} className="h-14 px-10 text-lg rounded-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 shadow-[0_0_30px_-5px_hsl(var(--color-intent))] transition-all hover:scale-105">
                        Initialize System <ArrowRight className="ml-2 w-5 h-5" />
                    </Button>
                    
                    <div className="pt-8 text-xs text-neutral-600 font-mono">
                        PROTOCOL V1.0 • EST. 2025 • SECURE CONNECTION
                    </div>
                </div>
            </StepContainer>
        )
    },
    {
        id: 'commerce',
        title: "Monetization Protocol",
        url: "commerce.base44.io/setup",
        component: ({ onNext }) => {
            const [wizardOpen, setWizardOpen] = useState(false);
            const [isConfigured, setIsConfigured] = useState(false);

            return (
                <StepContainer>
                     <div className="text-center mb-12">
                        <div className="w-16 h-16 bg-[hsl(var(--color-intent))]/10 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-[hsl(var(--color-intent))]/20">
                            <CreditCard className="w-8 h-8 text-[hsl(var(--color-intent))]" />
                        </div>
                        <h2 className="text-3xl font-bold tracking-tight mb-4 text-white">Activate Commerce Engine</h2>
                        <p className="text-neutral-400 max-w-lg mx-auto">
                            Configure your sovereign payment gateway to accept subscriptions and transactions immediately upon launch.
                        </p>
                    </div>

                    <div className="max-w-md mx-auto space-y-6">
                        <div className={`p-6 rounded-xl border transition-all ${isConfigured ? 'bg-green-500/10 border-green-500/30' : 'bg-white/5 border-white/10'}`}>
                            <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isConfigured ? 'bg-green-500 text-black' : 'bg-white/10 text-neutral-500'}`}>
                                    {isConfigured ? <CheckCircle2 className="w-6 h-6" /> : <Lock className="w-5 h-5" />}
                                </div>
                                <div className="text-left">
                                    <h3 className="font-bold text-white">Stripe Integration</h3>
                                    <p className="text-xs text-neutral-400">{isConfigured ? "Gateway Active & Verified" : "Keys required for transactions"}</p>
                                </div>
                                {!isConfigured && (
                                    <Button size="sm" onClick={() => setWizardOpen(true)} className="ml-auto bg-[hsl(var(--color-intent))] text-black font-bold">
                                        Setup
                                    </Button>
                                )}
                            </div>
                        </div>

                        <div className="flex flex-col gap-3">
                            <Button 
                                onClick={onNext} 
                                className="w-full h-12"
                                variant={isConfigured ? "default" : "outline"}
                                disabled={!isConfigured} // Require setup to proceed, or allow skip? Let's allow skip for demo but encourage it.
                            >
                                {isConfigured ? "Continue to Initialization" : "Skip Commerce Setup"} <ArrowRight className="ml-2 w-4 h-4" />
                            </Button>
                            {!isConfigured && (
                                <p className="text-[10px] text-neutral-600 text-center">
                                    You can configure this later in the Commerce module.
                                </p>
                            )}
                        </div>
                    </div>

                    <StripeWizard 
                        open={wizardOpen} 
                        onOpenChange={setWizardOpen}
                        onConfigured={() => setIsConfigured(true)}
                    />
                </StepContainer>
            );
        }
    },
    {
        id: 'hosting',
        title: "Infrastructure Selection",
        url: "setup.base44.io/hosting",
        component: ({ onNext }) => (
            <StepContainer>
                <div className="text-center mb-12">
                    <h2 className="text-3xl font-bold tracking-tight mb-4">Choose Your Foundation</h2>
                    <p className="text-neutral-400">Where should your sovereign node reside?</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto w-full">
                    {/* Cloud Option */}
                    <div 
                        onClick={onNext}
                        className="group relative p-8 rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent hover:border-[hsl(var(--color-intent))]/50 hover:from-[hsl(var(--color-intent))]/5 transition-all cursor-pointer flex flex-col h-full"
                    >
                        <div className="absolute top-4 right-4">
                            <Badge className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))] border-none">FASTEST</Badge>
                        </div>
                        
                        <div className="w-16 h-16 rounded-2xl bg-blue-500/10 flex items-center justify-center mb-6 text-blue-400 border border-blue-500/20 group-hover:scale-110 transition-transform">
                            <Server className="w-8 h-8" />
                        </div>
                        
                        <h3 className="text-2xl font-bold mb-2 text-white">Managed Cloud</h3>
                        <p className="text-neutral-400 mb-8 flex-1 leading-relaxed">
                            Deploy instantly on our privacy-first secure cloud. We handle updates and security, you hold the encryption keys.
                        </p>
                        
                        <div className="space-y-3 mb-8">
                            {['Zero-Knowledge Encryption', 'Automated Backups', 'DDoS Shield', 'Global CDN'].map(f => (
                                <div key={f} className="flex items-center gap-2 text-sm text-neutral-300">
                                    <CheckCircle2 className="w-4 h-4 text-blue-500" /> {f}
                                </div>
                            ))}
                        </div>
                        
                        <Button className="w-full bg-white/10 hover:bg-white/20 text-white border border-white/5">
                            Deploy Cloud Node
                        </Button>
                    </div>

                    {/* Local Option */}
                    <div 
                        onClick={onNext}
                        className="group relative p-8 rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.05] to-transparent hover:border-purple-500/50 hover:from-purple-500/5 transition-all cursor-pointer flex flex-col h-full"
                    >
                         <div className="absolute top-4 right-4">
                            <Badge variant="outline" className="border-white/20 text-neutral-400">ADVANCED</Badge>
                        </div>

                        <div className="w-16 h-16 rounded-2xl bg-purple-500/10 flex items-center justify-center mb-6 text-purple-400 border border-purple-500/20 group-hover:scale-110 transition-transform">
                            <Terminal className="w-8 h-8" />
                        </div>
                        
                        <h3 className="text-2xl font-bold mb-2 text-white">Self-Hosted</h3>
                        <p className="text-neutral-400 mb-8 flex-1 leading-relaxed">
                            Run the full stack on your own hardware or VPS. Complete isolation. Docker & Kubernetes ready.
                        </p>
                        
                        <div className="space-y-3 mb-8">
                            {['Air-Gap Capable', 'Full Source Access', 'Custom Hardware', 'Local Network Only'].map(f => (
                                <div key={f} className="flex items-center gap-2 text-sm text-neutral-300">
                                    <CheckCircle2 className="w-4 h-4 text-purple-500" /> {f}
                                </div>
                            ))}
                        </div>
                        
                        <Button variant="outline" className="w-full border-white/10 hover:bg-white/10 text-white">
                            Download Installer
                        </Button>
                    </div>
                </div>
            </StepContainer>
        )
    },
    {
        id: 'initialization',
        title: "Kernel Boot Sequence",
        url: "kernel.base44.io/boot",
        component: ({ onComplete }) => {
            const [logs, setLogs] = useState([]);
            
            useEffect(() => {
                const bootSequence = [
                    { text: "Initializing Core Kernel...", color: "text-white" },
                    { text: "Verifying Cryptographic Signatures...", color: "text-neutral-400" },
                    { text: "Loading Identity Modules...", color: "text-neutral-400" },
                    { text: "Establishing Secure Mesh Link...", color: "text-[hsl(var(--color-intent))]" },
                    { text: "Syncing Neural Weights [4.2GB]...", color: "text-blue-400" },
                    { text: "Optimizing Local Database...", color: "text-neutral-400" },
                    { text: "Mounting UI Subsystems...", color: "text-neutral-400" },
                    { text: "SYSTEM ONLINE.", color: "text-green-500 font-bold" }
                ];
                
                let i = 0;
                const interval = setInterval(() => {
                    if (i >= bootSequence.length) {
                        clearInterval(interval);
                        setTimeout(() => {
                            toast.success("System Online", { description: "Welcome back, Commander." });
                            onComplete();
                        }, 1000);
                        return;
                    }
                    setLogs(prev => [...prev, { ...bootSequence[i], id: i }]);
                    i++;
                }, 600);
                
                return () => clearInterval(interval);
            }, [onComplete]);

            return (
                <StepContainer>
                    <div className="flex flex-col items-center justify-center h-full">
                        <div className="w-full max-w-2xl bg-black rounded-xl border border-white/10 p-8 font-mono text-sm shadow-2xl relative overflow-hidden">
                            {/* CRT Effect Overlay */}
                            <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 pointer-events-none bg-[length:100%_2px,3px_100%]" />
                            
                            <div className="space-y-2 relative z-0">
                                {logs.map((log) => (
                                    <motion.div 
                                        key={log.id}
                                        initial={{ opacity: 0, x: -10 }}
                                        animate={{ opacity: 1, x: 0 }}
                                        className="flex items-center gap-3"
                                    >
                                        <span className="text-neutral-600">[{new Date().toLocaleTimeString()}]</span>
                                        <span className={log.color}>{log.text}</span>
                                    </motion.div>
                                ))}
                                <motion.div 
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    transition={{ repeat: Infinity, duration: 0.8 }}
                                    className="h-4 w-2 bg-[hsl(var(--color-intent))] inline-block"
                                />
                            </div>
                        </div>
                        <p className="mt-8 text-neutral-500 animate-pulse uppercase tracking-widest text-xs">
                            Provisioning Sovereign Environment...
                        </p>
                    </div>
                </StepContainer>
            );
        }
    }
];

export const OnboardingTablet = () => {
    const { isOnboardingActive, currentStep, nextStep, completeOnboarding } = useOnboarding();
    const { systemStage } = useSiteContext(); // Use global evolution stage
    const [browserState, setBrowserState] = useState('windowed'); 

    if (!isOnboardingActive) return null;

    const activeStepIndex = Math.min(currentStep, STEPS.length - 1);
    const activeContent = STEPS[activeStepIndex];

    const handleNext = () => {
        if (activeStepIndex === STEPS.length - 1) {
            completeOnboarding();
        } else {
            nextStep();
        }
    };

    return (
        <BrowserWindow
            isOpen={isOnboardingActive}
            viewState={browserState}
            onViewStateChange={setBrowserState}
            title={activeContent.title}
            defaultUrl={activeContent.url}
            onClose={completeOnboarding}
            variant="browser"
            showUrlBar={true}
            initialStage={systemStage}
        >
            <div className="w-full h-full bg-[#050505] text-white overflow-hidden relative selection:bg-[hsl(var(--color-intent))]/30">
                {/* Background ambient light */}
                <div className="absolute top-[-20%] left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-[hsl(var(--color-intent))]/5 blur-[120px] rounded-full pointer-events-none" />
                <div className="absolute bottom-[-20%] right-[-10%] w-[600px] h-[600px] bg-blue-500/5 blur-[120px] rounded-full pointer-events-none" />
                
                <activeContent.component onNext={handleNext} onComplete={completeOnboarding} />
            </div>
        </BrowserWindow>
    );
};