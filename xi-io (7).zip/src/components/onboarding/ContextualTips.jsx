import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HelpCircle, Sparkles, X } from 'lucide-react';
import { cn } from "@/lib/utils";
import { useLocation } from 'react-router-dom';
import { useOnboarding } from './OnboardingContext';

const TIPS = {
    '/SearchResults': [
        {
            id: 'tip_filters',
            content: "Tip: Use the 'Semantic Stack' toggle to visualize hidden relationships.",
            condition: (ctx) => !ctx.completedTutorials.includes('semantic_stack')
        }
    ],
    '/Home': [
        {
            id: 'tip_zipper',
            content: "Pro Tip: Enable 'Zipper Mode' for unfiltered, raw data access.",
            condition: (ctx) => ctx.userContext.familiarity === 'expert'
        }
    ]
};

export const ContextualTips = () => {
    const [activeTip, setActiveTip] = useState(null);
    const { completedTutorials, userContext } = useOnboarding();
    // Use React Router location for reliable SPA updates
    const { pathname } = useLocation();

    useEffect(() => {
        // Find relevant tips
        const pageTips = TIPS[pathname] || [];
        const validTip = pageTips.find(tip => {
            const notDismissed = !localStorage.getItem(`tip_dismissed_${tip.id}`);
            const conditionMet = tip.condition ? tip.condition({ completedTutorials, userContext }) : true;
            return notDismissed && conditionMet;
        });

        if (validTip) {
            // Delay tip appearance slightly
            const timer = setTimeout(() => setActiveTip(validTip), 2000);
            return () => clearTimeout(timer);
        } else {
            setActiveTip(null);
        }
    }, [pathname, completedTutorials, userContext]);

    const dismissTip = () => {
        if (activeTip) {
            localStorage.setItem(`tip_dismissed_${activeTip.id}`, 'true');
            setActiveTip(null);
        }
    };

    if (!activeTip) return null;

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="z-[1000] bg-neutral-900/90 backdrop-blur-md border border-[hsl(var(--color-intent))]/30 rounded-lg p-4 shadow-[0_0_30px_rgba(0,0,0,0.5)] flex gap-3 relative overflow-hidden group pointer-events-auto"
            >
                <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--color-intent))]/10 to-transparent opacity-50" />
                
                <div className="p-2 bg-[hsl(var(--color-intent))]/20 rounded-full h-fit shrink-0 text-[hsl(var(--color-intent))]">
                    <Sparkles className="w-4 h-4" />
                </div>
                
                <div className="flex-1 relative z-10">
                    <p className="text-xs text-neutral-300 leading-relaxed pr-4">
                        {activeTip.content}
                    </p>
                </div>

                <button 
                    onClick={dismissTip}
                    className="absolute top-2 right-2 text-neutral-600 hover:text-white transition-colors"
                >
                    <X className="w-3 h-3" />
                </button>
            </motion.div>
        </AnimatePresence>
    );
};