import React from 'react';
import { OnboardingTablet } from '@/components/onboarding/OnboardingTablet';
import { useOnboarding } from '@/components/onboarding/OnboardingContext';

export const UserOnboarding = () => {
    // The OnboardingTablet component handles its own visibility via the OnboardingContext
    // and uses BrowserWindow which handles its own portaling/z-index.
    // So this wrapper just needs to mount it.
    return <OnboardingTablet />;
};