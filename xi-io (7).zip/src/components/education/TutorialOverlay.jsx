import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, X, ChevronRight, Trophy, BookOpen } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useGamification } from '@/components/features/GamificationSystem';
import { cn } from "@/lib/utils";

export const TutorialOverlay = ({ tutorialId, steps = [], onClose }) => {
    const { awardXP } = useGamification();
    const [currentStep, setCurrentStep] = useState(0);
    const [isVisible, setIsVisible] = useState(false);
    const [dontShowAgain, setDontShowAgain] = useState(false);

    useEffect(() => {
        const isDismissed = localStorage.getItem(`tutorial_dismissed_${tutorialId}`);
        if (!isDismissed) {
            setIsVisible(true);
        }
    }, [tutorialId]);

    const step = steps[currentStep];

    const handleNext = () => {
        if (currentStep < steps.length - 1) {
            setCurrentStep(c => c + 1);
        } else {
            // Complete
            if (dontShowAgain) {
                localStorage.setItem(`tutorial_dismissed_${tutorialId}`, 'true');
            }
            awardXP(500, `Completed Tutorial: ${tutorialId}`);
            setIsVisible(false);
            if (onClose) onClose();
        }
    };

    const handleClose = () => {
        if (dontShowAgain) {
            localStorage.setItem(`tutorial_dismissed_${tutorialId}`, 'true');
        }
        setIsVisible(false);
        if (onClose) onClose();
    }

    if (!isVisible || !step) return null;

    return createPortal(
        <AnimatePresence>
            <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className={cn(
                    "fixed z-50 p-6 bg-neutral-900/90 backdrop-blur-md border border-[hsl(var(--color-intent))] rounded-xl shadow-2xl max-w-sm",
                    step.position === 'center' && "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2",
                    step.position === 'bottom-right' && "bottom-8 right-8",
                    step.position === 'top-right' && "top-20 right-8",
                    step.position === 'top-left' && "top-20 left-20", // Offset for sidebar
                )}
            >
                <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-full bg-[hsl(var(--color-intent))] flex items-center justify-center text-white font-bold">
                        {currentStep + 1}
                    </div>
                    <div className="flex-1">
                        <h3 className="text-sm font-bold text-white uppercase tracking-wider">{step.title}</h3>
                        <p className="text-[10px] text-neutral-400 font-mono">STEP {currentStep + 1} OF {steps.length}</p>
                    </div>
                    <Button variant="ghost" size="icon" onClick={handleClose} className="h-6 w-6">
                        <X className="w-4 h-4" />
                    </Button>
                </div>

                <div className="mb-6 text-sm text-neutral-300 leading-relaxed">
                    {step.content}
                </div>

                <div className="flex items-center gap-2 mb-4">
                    <input 
                        type="checkbox" 
                        id="dont-show" 
                        checked={dontShowAgain}
                        onChange={(e) => setDontShowAgain(e.target.checked)}
                        className="rounded border-white/20 bg-neutral-800 text-[hsl(var(--color-intent))] focus:ring-[hsl(var(--color-intent))]"
                    />
                    <label htmlFor="dont-show" className="text-[10px] text-neutral-500 cursor-pointer select-none">
                        Don't show again
                    </label>
                </div>

                <div className="flex items-center justify-between">
                    <div className="flex gap-1">
                        {steps.map((_, i) => (
                            <div 
                                key={i} 
                                className={cn(
                                    "w-1.5 h-1.5 rounded-full transition-colors", 
                                    i === currentStep ? "bg-[hsl(var(--color-intent))]" : "bg-neutral-800"
                                )} 
                            />
                        ))}
                    </div>
                    <Button onClick={handleNext} size="sm" className="bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90">
                        {currentStep === steps.length - 1 ? (
                            <>Claim Reward <Trophy className="w-3 h-3 ml-2" /></>
                        ) : (
                            <>Next <ChevronRight className="w-3 h-3 ml-1" /></>
                        )}
                    </Button>
                </div>
            </motion.div>
        </AnimatePresence>,
        document.body
    );
};