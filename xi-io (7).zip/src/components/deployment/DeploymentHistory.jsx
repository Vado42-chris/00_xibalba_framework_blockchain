import React from 'react';
import { History, RotateCcw, CheckCircle2, XCircle, Clock, ArrowRight } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

export const DeploymentHistory = ({ history = [], onRollback }) => {
    return (
        <div className="bg-neutral-900/50 border border-white/10 rounded-xl overflow-hidden flex flex-col h-[500px]">
            <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/5">
                <div className="flex items-center gap-2">
                    <History className="w-4 h-4 text-neutral-400" />
                    <span className="text-sm font-medium text-white">Deployment Log</span>
                </div>
                <div className="text-[10px] text-neutral-500 font-mono">
                    {history.length} RECORDS
                </div>
            </div>

            <ScrollArea className="flex-1 p-4">
                <div className="space-y-3">
                    {history.length === 0 && (
                        <div className="text-center py-12 opacity-50">
                            <Clock className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                            <p className="text-xs text-neutral-500">No deployment history found.</p>
                        </div>
                    )}

                    {history.map((deploy) => (
                        <div key={deploy.id} className="group p-3 rounded-lg border border-white/5 hover:bg-white/5 hover:border-white/10 transition-all">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                    {deploy.status === 'success' ? (
                                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                                    ) : (
                                        <XCircle className="w-4 h-4 text-red-500" />
                                    )}
                                    <span className="text-sm font-bold text-white">{deploy.version}</span>
                                    <span className="text-[10px] text-neutral-500 font-mono bg-neutral-900 px-1.5 py-0.5 rounded">
                                        {deploy.id}
                                    </span>
                                </div>
                                <span className="text-[10px] text-neutral-500">{deploy.timestamp}</span>
                            </div>
                            
                            <p className="text-xs text-neutral-400 mb-3 pl-6">
                                {deploy.description}
                            </p>

                            <div className="flex items-center justify-between pl-6">
                                <span className="text-[10px] text-neutral-600 font-mono">
                                    Duration: {deploy.duration}
                                </span>
                                {deploy.status === 'success' && (
                                    <Button 
                                        size="sm" 
                                        variant="outline" 
                                        className="h-6 text-[10px] opacity-0 group-hover:opacity-100 transition-opacity border-white/10 hover:bg-white/10 hover:text-white"
                                        onClick={() => onRollback(deploy)}
                                    >
                                        <RotateCcw className="w-3 h-3 mr-1.5" /> Rollback
                                    </Button>
                                )}
                            </div>
                        </div>
                    ))}
                </div>
            </ScrollArea>

            <div className="p-3 border-t border-white/5 bg-neutral-950/50 text-center">
                <Button variant="link" className="text-[10px] text-neutral-500 hover:text-white">
                    View Full Audit Trail <ArrowRight className="w-3 h-3 ml-1" />
                </Button>
            </div>
        </div>
    );
};