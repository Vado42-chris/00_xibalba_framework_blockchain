import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileArchive, ArrowRight, Play, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';
import { DeploymentService } from './deploymentService';
import { DeploymentStatus } from './DeploymentStatus';
import { ConfigPreview } from './ConfigPreview';
import { SecurityGate } from '@/components/installer/SecurityGate';
import { LiveAgentConsole } from '@/components/marketplace/LiveAgentConsole';
import { DeploymentHistory } from './DeploymentHistory';
import { History as HistoryIcon } from 'lucide-react';

const DEPLOYMENT_STEPS = [
    { id: 'upload', label: 'Upload & Extract' },
    { id: 'validate', label: 'Validate Manifest' },
    { id: 'configure', label: 'Configure Endpoints' },
    { id: 'integrate', label: 'Integrate Addons' },
    { id: 'deploy', label: 'Finalize Deployment' }
];

export const DeploymentUploader = () => {
    const [status, setStatus] = useState('idle'); // idle, scanning, review, deploying, success, error
    const [currentStep, setCurrentStep] = useState(0);
    const [uploadedFile, setUploadedFile] = useState(null);
    const [jobId, setJobId] = useState(null);
    const [manifest, setManifest] = useState(null);
    const [runtimeConfig, setRuntimeConfig] = useState(null);
    const [error, setError] = useState(null);
    const [consoleLogs, setConsoleLogs] = useState([]);
    const [isConsoleActive, setIsConsoleActive] = useState(false);
    const [showHistory, setShowHistory] = useState(false);
    const [historyData, setHistoryData] = useState([]);

    React.useEffect(() => {
        DeploymentService.getHistory().then(setHistoryData);
    }, []);

    const onDrop = useCallback(async (acceptedFiles) => {
        const file = acceptedFiles[0];
        if (!file) return;

        setStatus('scanning');
        setUploadedFile(file);
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            'application/zip': ['.zip'],
            'application/x-zip-compressed': ['.zip']
        },
        maxFiles: 1,
        disabled: status !== 'idle'
    });

    const handleSecurityVerified = async () => {
        setStatus('uploading_phase');
        try {
            // 1. Upload
            setCurrentStep(0);
            const { jobId: id } = await DeploymentService.uploadZip(uploadedFile);
            setJobId(id);
            
            // Simulate processing delays for the demo
            await new Promise(r => setTimeout(r, 1000));
            
            // 2. Validate
            setCurrentStep(1);
            // In reality, this would come from the backend response
            const mockManifest = {
                name: "Seed001 White-Label Kit",
                ui_version: "1.0.0",
                framework: "react",
                api: { base_url: "${API_BASE}", auth: "/api/auth" },
                permissions: { requires_auth: true }
            };
            setManifest(mockManifest);
            await new Promise(r => setTimeout(r, 800));

            // 3. Configure (Auto-discovery)
            setCurrentStep(2);
            const config = DeploymentService.getMockRuntimeConfig();
            setRuntimeConfig(config);
            await new Promise(r => setTimeout(r, 800));

            setStatus('review');
            toast.success("Package Validated. Ready to Deploy.");

        } catch (err) {
            console.error(err);
            setError(err.message);
            setStatus('error');
        }
    };

    const handleDeploy = async () => {
        setStatus('deploying');
        try {
            // 4. Integrate Addons (with Live Console)
            setCurrentStep(3);
            setIsConsoleActive(true);
            setConsoleLogs([{ message: "Starting addon integration sequence...", type: 'info' }]);
            
            await DeploymentService.integrateAddons(jobId, runtimeConfig?.addons, (log) => {
                setConsoleLogs(prev => [...prev, log]);
            });
            
            setIsConsoleActive(false);

            // 5. Finalize
            setCurrentStep(4);
            await DeploymentService.executeDeployment(jobId, runtimeConfig);
            
            setStatus('success');
            toast.success("Deployment Successful!");
        } catch (err) {
            console.error(err);
            setError(err.message);
            setStatus('error');
            setIsConsoleActive(false);
        }
    };

    const reset = () => {
        setStatus('idle');
        setUploadedFile(null);
        setJobId(null);
        setManifest(null);
        setRuntimeConfig(null);
        setError(null);
        setCurrentStep(0);
        setConsoleLogs([]);
        setIsConsoleActive(false);
    };

    const handleRollback = async (deployment) => {
        if (confirm(`Are you sure you want to rollback to ${deployment.version}?`)) {
            setStatus('deploying');
            setIsConsoleActive(true);
            setConsoleLogs([{ message: `Initiating rollback to ${deployment.version}...`, type: 'warning' }]);
            
            try {
                await DeploymentService.rollback(deployment.id);
                setConsoleLogs(prev => [...prev, { message: "Rollback complete. System restored.", type: 'success' }]);
                setTimeout(() => {
                    setIsConsoleActive(false);
                    setStatus('success');
                    toast.success("Rollback Successful");
                }, 1000);
            } catch (e) {
                setStatus('error');
                setError("Rollback failed");
            }
        }
    };

    return (
        <div className="w-full max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* Left Column: Input & Status */}
            <div className="space-y-6">
                <div className="flex justify-between items-start">
                    <div className="space-y-2">
                        <h2 className="text-2xl font-light text-white">Deploy Package</h2>
                        <p className="text-neutral-500 text-sm">Upload your UI bundle to begin the automated deployment pipeline.</p>
                    </div>
                    <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={() => setShowHistory(!showHistory)}
                        className={cn("text-neutral-500 hover:text-white", showHistory && "bg-white/10 text-white")}
                    >
                        <HistoryIcon className="w-5 h-5" />
                    </Button>
                </div>

                {showHistory ? (
                    <DeploymentHistory history={historyData} onRollback={handleRollback} />
                ) : status === 'idle' ? (
                    <div 
                        {...getRootProps()} 
                        className={cn(
                            "border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all duration-300 group h-64 flex flex-col items-center justify-center",
                            isDragActive 
                                ? "border-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/5 scale-[1.02]" 
                                : "border-white/10 hover:border-white/20 hover:bg-white/5"
                        )}
                    >
                        <input {...getInputProps()} />
                        <div className="w-12 h-12 rounded-full bg-neutral-900 border border-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                            <Upload className="w-5 h-5 text-neutral-400 group-hover:text-white" />
                        </div>
                        <h3 className="text-lg font-medium text-white mb-1">Drag & Drop Bundle</h3>
                        <p className="text-xs text-neutral-500 uppercase tracking-wide">.ZIP • Max 50MB</p>
                    </div>
                ) : status === 'scanning' ? (
                    <SecurityGate 
                        file={uploadedFile} 
                        onVerified={handleSecurityVerified} 
                        onCancel={reset} 
                    />
                ) : (
                    <div className="bg-neutral-900/50 border border-white/10 rounded-xl p-6">
                        <DeploymentStatus steps={DEPLOYMENT_STEPS} currentStep={currentStep} error={error} />
                        
                        {status === 'review' && (
                            <div className="mt-6 pt-6 border-t border-white/5">
                                <Button onClick={handleDeploy} className="w-full bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90">
                                    <Play className="w-4 h-4 mr-2" /> Execute Deployment
                                </Button>
                            </div>
                        )}

                        {status === 'error' && (
                            <Button onClick={reset} variant="outline" className="w-full mt-6">
                                Try Again
                            </Button>
                        )}
                    </div>
                )}
            </div>

            {/* Right Column: Preview & Result */}
            <div className="space-y-6">
                <div className="space-y-2">
                    <h2 className="text-xl font-light text-white">Configuration</h2>
                    <p className="text-neutral-500 text-sm">Runtime injection preview.</p>
                </div>

                <div className="bg-neutral-900/30 border border-white/5 rounded-xl p-0 min-h-[400px] flex flex-col overflow-hidden relative">
                    {(isConsoleActive || consoleLogs.length > 0) ? (
                        <LiveAgentConsole active={isConsoleActive} logs={consoleLogs} />
                    ) : (manifest || runtimeConfig) ? (
                        <div className="p-6">
                            <ConfigPreview manifest={manifest} config={runtimeConfig} />
                        </div>
                    ) : (
                        <div className="flex-1 flex flex-col items-center justify-center text-neutral-600 opacity-50 p-6">
                            <FileArchive className="w-12 h-12 mb-4" />
                            <p className="text-sm">No package loaded</p>
                        </div>
                    )}

                    {status === 'success' && (
                        <div className="mt-auto pt-6 border-t border-white/5 animate-in slide-in-from-bottom-4 fade-in duration-500">
                            <div className="bg-[hsl(var(--color-execution))]/10 border border-[hsl(var(--color-execution))]/20 rounded-lg p-4 text-center">
                                <div className="flex items-center justify-center gap-2 text-[hsl(var(--color-execution))] mb-2">
                                    <CheckCircle2 className="w-5 h-5" />
                                    <span className="font-bold">LIVE</span>
                                </div>
                                <div className="text-white text-lg font-mono mb-4">https://seed001.xi-io.com</div>
                                <Button variant="outline" className="w-full border-[hsl(var(--color-execution))]/30 hover:bg-[hsl(var(--color-execution))]/10">
                                    Visit Site <ArrowRight className="w-4 h-4 ml-2" />
                                </Button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};