import React, { useState, useEffect } from 'react';
import { 
    GitCommit, Package, TestTube, Globe, 
    CheckCircle2, XCircle, Loader2, ArrowRight,
    Play, RotateCcw, Shield
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from 'sonner';

const PipelineStep = ({ icon: Icon, label, status, index, total }) => {
    const statusConfig = {
        pending: { color: "text-neutral-500", bg: "bg-neutral-900", border: "border-neutral-800" },
        running: { color: "text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20" },
        success: { color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20" },
        failed: { color: "text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20" }
    };

    const config = statusConfig[status] || statusConfig.pending;

    return (
        <div className="flex items-center flex-1">
            <div className={cn(
                "relative flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all duration-500",
                config.bg, config.border, config.color,
                status === 'running' && "animate-pulse shadow-[0_0_15px_rgba(59,130,246,0.3)]"
            )}>
                {status === 'running' ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                ) : status === 'success' ? (
                    <CheckCircle2 className="w-6 h-6" />
                ) : status === 'failed' ? (
                    <XCircle className="w-6 h-6" />
                ) : (
                    <Icon className="w-5 h-5" />
                )}
                
                {/* Connector Line */}
                {index < total - 1 && (
                    <div className={cn(
                        "absolute left-full top-1/2 w-[calc(100vw/6)] md:w-32 h-0.5 -translate-y-1/2 transition-colors duration-500",
                        status === 'success' ? "bg-emerald-500/50" : "bg-neutral-800"
                    )} />
                )}
            </div>
            <div className="ml-3 hidden md:block">
                <div className={cn("text-xs font-bold uppercase tracking-wider", config.color)}>
                    {status === 'running' ? 'In Progress' : status}
                </div>
                <div className="text-sm font-medium text-neutral-300">{label}</div>
            </div>
        </div>
    );
};

export const CiCdPipeline = () => {
    const [pipelineStatus, setPipelineStatus] = useState('idle'); // idle, running, success, failed
    const [currentStep, setCurrentStep] = useState(0);
    const [logs, setLogs] = useState([]);

    const steps = [
        { id: 'source', label: 'Source Control', icon: GitCommit },
        { id: 'build', label: 'Build & Bundle', icon: Package },
        { id: 'test', label: 'Automated Tests', icon: TestTube },
        { id: 'deploy', label: 'Production Push', icon: Globe },
    ];

    const addLog = (msg) => setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);

    const runPipeline = async () => {
        setPipelineStatus('running');
        setCurrentStep(0);
        setLogs([]);

        try {
            // Step 1: Source
            addLog("Fetching latest commit from 'main'...");
            await new Promise(r => setTimeout(r, 1500));
            addLog("Verified commit hash: 7f3a2b1");
            setCurrentStep(1);

            // Step 2: Build
            addLog("Starting build process...");
            addLog("Compiling React frontend...");
            await new Promise(r => setTimeout(r, 2000));
            addLog("Build success. Bundle size: 1.2MB");
            setCurrentStep(2);

            // Step 3: Test
            addLog("Running unit tests...");
            await new Promise(r => setTimeout(r, 1500));
            addLog("Running integration tests...");
            await new Promise(r => setTimeout(r, 1500));
            addLog("All tests passed (42/42)");
            setCurrentStep(3);

            // Step 4: Deploy
            addLog("Deploying to production edge...");
            await new Promise(r => setTimeout(r, 2000));
            addLog("Cache invalidated.");
            addLog("Deployment complete.");
            
            setPipelineStatus('success');
            setCurrentStep(4); // All done
            toast.success("Deployment Successful", { description: "Version v2.4.2 is now live." });

        } catch (error) {
            setPipelineStatus('failed');
            addLog(`Error: ${error.message}`);
            toast.error("Pipeline Failed");
        }
    };

    return (
        <Card className="bg-black/40 border-white/10 backdrop-blur-sm overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between border-b border-white/5 pb-6">
                <div>
                    <CardTitle className="text-white flex items-center gap-2">
                        <Shield className="w-5 h-5 text-purple-500" />
                        Automated Deployment Pipeline
                    </CardTitle>
                    <CardDescription>Continuous Integration & Delivery System</CardDescription>
                </div>
                <div className="flex gap-3">
                    {pipelineStatus === 'running' ? (
                         <Button disabled variant="outline" className="border-white/10 text-neutral-400">
                             <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                             Running...
                         </Button>
                    ) : (
                        <Button onClick={runPipeline} className="bg-purple-600 hover:bg-purple-700 text-white">
                            <Play className="w-4 h-4 mr-2" />
                            Trigger Pipeline
                        </Button>
                    )}
                </div>
            </CardHeader>
            <CardContent className="pt-8">
                {/* Pipeline Visual */}
                <div className="flex items-center justify-between mb-12 px-4 relative overflow-x-auto pb-4 md:pb-0">
                    {steps.map((step, idx) => {
                        let status = 'pending';
                        if (pipelineStatus === 'idle') status = 'pending';
                        else if (pipelineStatus === 'failed' && currentStep === idx) status = 'failed';
                        else if (currentStep > idx) status = 'success';
                        else if (currentStep === idx) status = 'running';

                        return (
                            <PipelineStep 
                                key={step.id}
                                {...step}
                                status={status}
                                index={idx}
                                total={steps.length}
                            />
                        );
                    })}
                </div>

                {/* Console Output */}
                <div className="bg-neutral-950 rounded-lg border border-white/10 p-4 font-mono text-xs h-48 overflow-y-auto">
                    <div className="flex items-center justify-between text-neutral-500 mb-2 border-b border-white/5 pb-2">
                        <span>Pipeline Console</span>
                        {pipelineStatus === 'success' && <Badge variant="outline" className="text-emerald-500 border-emerald-500/20">Success</Badge>}
                        {pipelineStatus === 'failed' && <Badge variant="outline" className="text-rose-500 border-rose-500/20">Failed</Badge>}
                    </div>
                    <div className="space-y-1">
                        {logs.length === 0 && <span className="text-neutral-700">Waiting for job...</span>}
                        {logs.map((log, i) => (
                            <div key={i} className="text-neutral-300">
                                <span className="text-purple-500 mr-2">$</span>
                                {log}
                            </div>
                        ))}
                        {pipelineStatus === 'running' && (
                            <div className="animate-pulse text-purple-400">_</div>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};