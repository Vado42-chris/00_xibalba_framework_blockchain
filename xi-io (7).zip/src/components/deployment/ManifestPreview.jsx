import React from 'react';
import { motion } from 'framer-motion';
import { Lock, Eye, AlertTriangle, FileCode, CheckCircle2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export const ManifestPreview = ({ manifest, onAuthorize, onReject }) => {
    if (!manifest) return null;

    return (
        <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-sm"
        >
            <div className="bg-white/5 rounded-lg p-4 border border-white/5 mb-6 text-left relative overflow-hidden">
                {/* Background Glitch Effect */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent pointer-events-none" />
                
                <div className="flex justify-between items-start mb-4 relative z-10">
                    <div>
                        <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider mb-1">Manifest Detected</div>
                        <div className="text-sm font-bold text-white flex items-center gap-2">
                            <FileCode className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                            {manifest.name || "Unknown Bundle"}
                        </div>
                    </div>
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20 text-[10px]">
                        SIGNED
                    </Badge>
                </div>

                <div className="space-y-3 relative z-10">
                    <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">Requested Permissions</div>
                    
                    <div className="space-y-2">
                        {manifest.permissions?.requires_auth && (
                            <div className="flex items-center gap-2 text-xs text-neutral-300">
                                <Lock className="w-3 h-3 text-yellow-500" />
                                <span>Auth Provider Access</span>
                            </div>
                        )}
                        {manifest.permissions?.read_config && (
                            <div className="flex items-center gap-2 text-xs text-neutral-300">
                                <Eye className="w-3 h-3 text-blue-500" />
                                <span>Read System Config</span>
                            </div>
                        )}
                        {manifest.permissions?.provision_addons && (
                            <div className="flex items-center gap-2 text-xs text-neutral-300">
                                <AlertTriangle className="w-3 h-3 text-orange-500" />
                                <span>Provision Addons</span>
                            </div>
                        )}
                        {!manifest.permissions && (
                            <div className="text-xs text-neutral-500 italic">No special permissions requested.</div>
                        )}
                    </div>
                </div>

                <div className="mt-4 pt-4 border-t border-white/5 flex justify-between text-[10px] text-neutral-500 font-mono">
                    <span>v{manifest.ui_version || "1.0.0"}</span>
                    <span>{manifest.framework || "React"}</span>
                </div>
            </div>

            <div className="flex gap-3">
                <Button variant="ghost" onClick={onReject} className="flex-1 text-neutral-400 hover:text-white hover:bg-white/5">
                    Reject
                </Button>
                <Button onClick={onAuthorize} className="flex-1 bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black font-bold tracking-wide shadow-[0_0_15px_rgba(16,185,129,0.2)]">
                    AUTHORIZE DEPLOY
                </Button>
            </div>
        </motion.div>
    );
};