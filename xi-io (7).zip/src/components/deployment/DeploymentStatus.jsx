import React from 'react';
import { CheckCircle2, Circle, Loader2, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { StateText } from '@/components/ui/design-system/System';

export const DeploymentStatus = ({ steps, currentStep, error }) => {
    return (
        <div className="space-y-4 font-mono text-sm">
            {steps.map((step, index) => {
                const isCompleted = index < currentStep;
                const isCurrent = index === currentStep;
                const isPending = index > currentStep;
                const isError = isCurrent && error;

                return (
                    <div key={step.id} className={cn(
                        "flex items-center gap-3 p-3 rounded border transition-all",
                        isCurrent 
                            ? "bg-white/5 border-white/10" 
                            : "bg-transparent border-transparent opacity-50"
                    )}>
                        <div className="shrink-0">
                            {isCompleted ? (
                                <CheckCircle2 className="w-4 h-4 text-green-500" />
                            ) : isError ? (
                                <AlertCircle className="w-4 h-4 text-red-500" />
                            ) : isCurrent ? (
                                <Loader2 className="w-4 h-4 animate-spin text-[hsl(var(--color-execution))]" />
                            ) : (
                                <Circle className="w-4 h-4 text-neutral-600" />
                            )}
                        </div>
                        <div className="flex-1 min-w-0">
                            <div className={cn(
                                "text-xs font-medium uppercase tracking-wider",
                                isCurrent ? "text-white" : "text-neutral-500"
                            )}>
                                {step.label}
                            </div>
                            {isCurrent && !error && (
                                <StateText className="text-[10px] text-[hsl(var(--color-execution))] mt-1">
                                    Processing...
                                </StateText>
                            )}
                            {isError && (
                                <div className="text-[10px] text-red-400 mt-1">
                                    {error}
                                </div>
                            )}
                        </div>
                    </div>
                );
            })}
        </div>
    );
};