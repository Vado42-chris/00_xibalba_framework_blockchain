import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Code, Globe, Shield, Plug } from 'lucide-react';

export const ConfigPreview = ({ manifest, config }) => {
    if (!manifest) return null;

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2 text-neutral-400 text-xs uppercase tracking-wider">
                        <Globe className="w-3 h-3" /> Identity
                    </div>
                    <div className="font-bold text-white text-lg">{manifest.name}</div>
                    <div className="text-xs text-neutral-500">v{manifest.ui_version} • {manifest.framework}</div>
                </div>
                <div className="p-4 rounded bg-white/5 border border-white/10">
                    <div className="flex items-center gap-2 mb-2 text-neutral-400 text-xs uppercase tracking-wider">
                        <Shield className="w-3 h-3" /> Security
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {manifest.permissions?.requires_auth && <Badge variant="outline" className="text-[10px]">Auth Required</Badge>}
                        {config?.vpn?.status === 'active' && <Badge className="bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] text-[10px]">VPN Active</Badge>}
                    </div>
                </div>
            </div>

            <div className="space-y-2">
                <div className="flex items-center gap-2 text-neutral-400 text-xs uppercase tracking-wider mb-2">
                    <Plug className="w-3 h-3" /> Detected Endpoints
                </div>
                <div className="bg-black/40 rounded border border-white/5 p-3 font-mono text-[10px] text-neutral-300 space-y-1">
                    {Object.entries(manifest.api || {}).map(([key, value]) => (
                        <div key={key} className="flex justify-between border-b border-white/5 last:border-0 pb-1 last:pb-0">
                            <span className="text-neutral-500">{key}:</span>
                            <span className="truncate max-w-[200px]">{typeof value === 'string' ? value : JSON.stringify(value)}</span>
                        </div>
                    ))}
                </div>
            </div>

            <div className="space-y-2">
                <div className="flex items-center gap-2 text-neutral-400 text-xs uppercase tracking-wider mb-2">
                    <Code className="w-3 h-3" /> Runtime Injection
                </div>
                <ScrollArea className="h-32 bg-black/40 rounded border border-white/5 p-3">
                    <pre className="text-[10px] text-green-400 font-mono whitespace-pre-wrap">
                        {JSON.stringify(config, null, 2)}
                    </pre>
                </ScrollArea>
            </div>
        </div>
    );
};