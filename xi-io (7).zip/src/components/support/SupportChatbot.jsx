import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send, Bot, User, Loader2, Sparkles } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';

export default function SupportChatbot() {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState([
        { role: 'assistant', content: 'Hello! I am the Seed001 Support AI. How can I help you navigate the platform today?' }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const scrollRef = useRef(null);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
        }
    }, [messages, isOpen]);

    const handleSend = async () => {
        if (!input.trim()) return;
        
        const userMsg = { role: 'user', content: input };
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setLoading(true);

        try {
            // Using InvokeLLM for support responses
            // In a real app, this would use RAG or a trained model
            const res = await base44.integrations.Core.InvokeLLM({
                prompt: `You are the AI Support Agent for the Seed001 Platform. 
                The platform includes modules like Commerce, CRM, Intelligence, and more.
                Help the user with their question: "${input}"
                Keep answers concise, professional, and helpful.`,
                add_context_from_internet: false
            });

            setMessages(prev => [...prev, { role: 'assistant', content: res }]);
        } catch (error) {
            setMessages(prev => [...prev, { role: 'assistant', content: "I apologize, but I'm having trouble connecting to the support brain right now. Please try again later." }]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: 20, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 20, scale: 0.95 }}
                        className="fixed bottom-24 right-6 z-50 w-96 h-[500px] bg-neutral-900 border border-white/10 rounded-xl shadow-2xl flex flex-col overflow-hidden"
                    >
                        {/* Header */}
                        <div className="p-4 bg-neutral-800 border-b border-white/5 flex justify-between items-center">
                            <div className="flex items-center gap-2">
                                <div className="w-8 h-8 rounded-full bg-[hsl(var(--color-intent))] flex items-center justify-center">
                                    <Bot className="w-5 h-5 text-black" />
                                </div>
                                <div>
                                    <h3 className="font-bold text-white text-sm">Seed Support</h3>
                                    <p className="text-[10px] text-green-400 flex items-center gap-1">
                                        <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                                        Online
                                    </p>
                                </div>
                            </div>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-white" onClick={() => setIsOpen(false)}>
                                <X className="w-4 h-4" />
                            </Button>
                        </div>

                        {/* Messages */}
                        <ScrollArea className="flex-1 p-4" viewportRef={scrollRef}>
                            <div className="space-y-4">
                                {messages.map((msg, i) => (
                                    <div key={i} className={cn("flex gap-2 max-w-[85%]", msg.role === 'user' ? "ml-auto flex-row-reverse" : "")}>
                                        <div className={cn(
                                            "w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs",
                                            msg.role === 'user' ? "bg-neutral-700" : "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]"
                                        )}>
                                            {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                                        </div>
                                        <div className={cn(
                                            "p-3 rounded-lg text-sm leading-relaxed",
                                            msg.role === 'user' ? "bg-neutral-800 text-white" : "bg-neutral-800/50 border border-white/5 text-neutral-300"
                                        )}>
                                            {msg.content}
                                        </div>
                                    </div>
                                ))}
                                {loading && (
                                    <div className="flex gap-2 max-w-[85%]">
                                        <div className="w-8 h-8 rounded-full bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))] flex items-center justify-center shrink-0">
                                            <Bot className="w-4 h-4" />
                                        </div>
                                        <div className="p-3 rounded-lg bg-neutral-800/50 border border-white/5 flex items-center gap-2">
                                            <Loader2 className="w-4 h-4 animate-spin text-neutral-500" />
                                            <span className="text-xs text-neutral-500">Thinking...</span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </ScrollArea>

                        {/* Input */}
                        <div className="p-4 bg-neutral-800/50 border-t border-white/5">
                            <form 
                                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                                className="flex gap-2"
                            >
                                <Input 
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    placeholder="Ask a question..."
                                    className="bg-neutral-900 border-white/10 focus-visible:ring-[hsl(var(--color-intent))]"
                                />
                                <Button type="submit" size="icon" disabled={!input.trim() || loading} className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90">
                                    <Send className="w-4 h-4" />
                                </Button>
                            </form>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Toggle Button */}
            {!isOpen && (
                <motion.button
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setIsOpen(true)}
                    className="fixed bottom-24 right-6 z-50 w-12 h-12 rounded-full bg-[hsl(var(--color-intent))] text-black shadow-lg shadow-[hsl(var(--color-intent))]/20 flex items-center justify-center border border-white/10"
                >
                    <MessageSquare className="w-6 h-6" />
                </motion.button>
            )}
        </>
    );
}