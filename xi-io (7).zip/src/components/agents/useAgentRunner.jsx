import { useEffect, useRef } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

export function useAgentRunner(agents) {
    const processingRef = useRef(new Set());
    const queryClient = useQueryClient();

    const logMutation = useMutation({
        mutationFn: (data) => base44.entities.Log.create(data)
    });

    // --- REMEDIATION FLOW SIMULATION ---
    const { data: activeTasks = [] } = useQuery({
        queryKey: ['active_remediation_tasks'],
        queryFn: () => base44.entities.Task.filter({ autoRemediation: true }),
        refetchInterval: 3000
    });

    const updateTaskMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.Task.update(id, data),
        onSuccess: () => queryClient.invalidateQueries(['active_remediation_tasks'])
    });

    const advanceFlowMutation = useMutation({
        mutationFn: ({ task }) => base44.functions.invoke('healer', { action: 'advance', task }),
        onSuccess: () => queryClient.invalidateQueries(['active_remediation_tasks'])
    });

    useEffect(() => {
        if (!activeTasks.length) return;

        activeTasks.forEach(task => {
            // 1. Pick up queued tasks
            if (task.status === 'queued') {
                // Simulate picking up
                if (Math.random() > 0.5) { // Throttling
                     updateTaskMutation.mutate({ id: task.id, data: { status: 'in_progress', start_date: new Date().toISOString() } });
                }
            }
            
            // 2. Complete in_progress tasks
            if (task.status === 'in_progress') {
                const startTime = new Date(task.start_date || task.created_date).getTime();
                const now = new Date().getTime();
                
                // Work for at least 5 seconds
                if (now - startTime > 5000) {
                    let newStatus = 'done';
                    
                    // DEMO LOGIC: Fail "Restart Service" to trigger flow
                    if (task.title.includes('Restart Service')) {
                        newStatus = 'failed';
                    }
                    
                    // Optimistic update locally to prevent double processing? 
                    // No, reliance on mutation is fine for this scale.
                    
                    // Chain: Update Status -> Advance Flow
                    // We can't chain easily in forEach without async, but side effects are ok here
                    base44.entities.Task.update(task.id, { status: newStatus, end_date: new Date().toISOString() })
                        .then((updatedTask) => {
                             advanceFlowMutation.mutate({ task: updatedTask });
                        });
                }
            }
        });
    }, [activeTasks]);
    // -----------------------------------

    const llmMutation = useMutation({
        mutationFn: async ({ agent }) => {
            const res = await base44.integrations.Core.InvokeLLM({
                prompt: `You are ${agent.name}, a specialized AI agent with the role: ${agent.role}. 
                Current status: Active/Executing.
                Generate a single, short, cryptic but technical system log line (under 15 words) describing your current background task. 
                Examples: "Optimizing neural weights for sector 7", "Handshake verified with Node-Alpha", "Anomaly detected in packet header 0x4F".
                Do not prefix with "Log:" or anything. Just the log content.`,
            });
            return res;
        },
        onSuccess: (data, variables) => {
            logMutation.mutate({
                content: data,
                type: 'info',
                remote_identity: variables.agent.name,
                timestamp: new Date().toISOString()
            });
            processingRef.current.delete(variables.agent.id);
        },
        onError: (err, variables) => {
            processingRef.current.delete(variables.agent.id);
        }
    });

    useEffect(() => {
        const interval = setInterval(() => {
            agents.forEach(agent => {
                // Only run if executing/busy and not currently processing a thought
                if ((agent.status === 'executing' || agent.status === 'busy') && !processingRef.current.has(agent.id)) {
                    // 20% chance to generate a thought per 3s tick to avoid spamming
                    if (Math.random() < 0.2) {
                        processingRef.current.add(agent.id);
                        llmMutation.mutate({ agent });
                    }
                }
            });
        }, 3000);

        return () => clearInterval(interval);
    }, [agents]);
}