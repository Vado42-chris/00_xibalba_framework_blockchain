import React, { useState } from 'react';
import { 
    Brain, Database, Cpu, Save, Award, 
    Activity, GitBranch, Layers, Play, 
    CheckCircle2, Lock, FileJson, HardDrive 
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from 'framer-motion';
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/System';

export const ModelForge = () => {
    const [step, setStep] = useState(1);
    const [config, setConfig] = useState({
        name: '',
        baseModel: 'llama-3-8b',
        dataset: '',
        epochs: 3,
        learningRate: 0.0002
    });
    const [isTraining, setIsTraining] = useState(false);
    const [progress, setProgress] = useState(0);
    const [certified, setCertified] = useState(false);

    const handleTrain = () => {
        if (!config.name || !config.dataset) {
            toast.error("Please configure model parameters");
            return;
        }
        setIsTraining(true);
        setStep(3);
        
        // Simulate training
        let p = 0;
        const interval = setInterval(() => {
            p += Math.random() * 5;
            if (p >= 100) {
                p = 100;
                clearInterval(interval);
                setIsTraining(false);
                setCertified(true);
                setStep(4);
                toast.success("Model Training Complete");
            }
            setProgress(p);
        }, 500);
    };

    return (
        <div className="h-full flex flex-col bg-neutral-950/50 relative overflow-hidden">
            {/* Header */}
            <div className="p-6 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <Brain className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                        <OrientingText className="text-[hsl(var(--color-intent))] font-bold">MODEL FORGE</OrientingText>
                    </div>
                    <IntentText className="text-sm opacity-70">Train, Quantize, and Certify Custom AI Models</IntentText>
                </div>
                <div className="flex gap-2">
                    {[1, 2, 3, 4].map(s => (
                        <div 
                            key={s} 
                            className={cn(
                                "w-2 h-2 rounded-full transition-all",
                                step >= s ? "bg-[hsl(var(--color-intent))]" : "bg-neutral-800"
                            )} 
                        />
                    ))}
                </div>
            </div>

            <div className="flex-1 overflow-y-auto p-8">
                <div className="max-w-3xl mx-auto space-y-8">
                    
                    {/* Step 1: Configuration */}
                    <AnimatePresence mode="wait">
                        {step === 1 && (
                            <motion.div 
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-6"
                            >
                                <div className="p-6 rounded-lg border border-white/10 bg-neutral-900/50 space-y-6">
                                    <div className="flex items-center gap-3 mb-4">
                                        <Cpu className="w-5 h-5 text-neutral-400" />
                                        <h3 className="text-lg font-medium text-white">Model Architecture</h3>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-6">
                                        <div className="space-y-2">
                                            <label className="text-xs text-neutral-500 font-mono">MODEL NAME</label>
                                            <Input 
                                                value={config.name}
                                                onChange={e => setConfig({...config, name: e.target.value})}
                                                placeholder="e.g., Sentinel-7B-v1"
                                                className="bg-neutral-950 border-white/10 font-mono"
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-xs text-neutral-500 font-mono">BASE ARCHITECTURE</label>
                                            <select 
                                                className="w-full h-10 bg-neutral-950 border border-white/10 rounded px-3 text-sm text-white"
                                                value={config.baseModel}
                                                onChange={e => setConfig({...config, baseModel: e.target.value})}
                                            >
                                                <option value="llama-3-8b">Llama 3 (8B)</option>
                                                <option value="mistral-7b">Mistral (7B)</option>
                                                <option value="gemma-7b">Gemma (7B)</option>
                                                <option value="phi-3">Phi-3 (Mini)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div className="p-6 rounded-lg border border-white/10 bg-neutral-900/50 space-y-6">
                                    <div className="flex items-center gap-3 mb-4">
                                        <Database className="w-5 h-5 text-neutral-400" />
                                        <h3 className="text-lg font-medium text-white">Training Data</h3>
                                    </div>
                                    
                                    <div className="border-2 border-dashed border-white/10 rounded-lg p-8 text-center hover:border-[hsl(var(--color-intent))] transition-colors cursor-pointer group">
                                        <div className="w-12 h-12 rounded-full bg-neutral-800 mx-auto flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                                            <HardDrive className="w-6 h-6 text-neutral-500 group-hover:text-[hsl(var(--color-intent))]" />
                                        </div>
                                        <p className="text-sm text-neutral-400">Select Dataset from Vault</p>
                                        <p className="text-xs text-neutral-600 mt-1">Supports JSONL, Parquet, or TXT</p>
                                        <Input 
                                            type="file" 
                                            className="hidden" 
                                            onChange={e => setConfig({...config, dataset: e.target.files?.[0]?.name})}
                                        />
                                    </div>
                                    {config.dataset && (
                                        <div className="flex items-center gap-2 text-xs text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10 p-2 rounded">
                                            <CheckCircle2 className="w-4 h-4" />
                                            Selected: {config.dataset}
                                        </div>
                                    )}
                                </div>

                                <div className="flex justify-end">
                                    <Button onClick={() => setStep(2)} className="bg-white text-black hover:bg-neutral-200">
                                        Next: Configuration <Activity className="w-4 h-4 ml-2" />
                                    </Button>
                                </div>
                            </motion.div>
                        )}

                        {/* Step 2: Hyperparameters */}
                        {step === 2 && (
                            <motion.div
                                initial={{ opacity: 0, x: 20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -20 }}
                                className="space-y-6"
                            >
                                <div className="p-6 rounded-lg border border-white/10 bg-neutral-900/50 space-y-6">
                                    <div className="flex items-center gap-3 mb-4">
                                        <Activity className="w-5 h-5 text-neutral-400" />
                                        <h3 className="text-lg font-medium text-white">Hyperparameters</h3>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-6">
                                        <div className="space-y-2">
                                            <label className="text-xs text-neutral-500 font-mono">EPOCHS</label>
                                            <Input 
                                                type="number"
                                                value={config.epochs}
                                                onChange={e => setConfig({...config, epochs: parseInt(e.target.value)})}
                                                className="bg-neutral-950 border-white/10 font-mono"
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-xs text-neutral-500 font-mono">LEARNING RATE</label>
                                            <Input 
                                                value={config.learningRate}
                                                onChange={e => setConfig({...config, learningRate: parseFloat(e.target.value)})}
                                                className="bg-neutral-950 border-white/10 font-mono"
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="flex justify-between">
                                    <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
                                    <Button onClick={handleTrain} className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90">
                                        Initialize Training <Play className="w-4 h-4 ml-2" />
                                    </Button>
                                </div>
                            </motion.div>
                        )}

                        {/* Step 3: Training Progress */}
                        {step === 3 && (
                            <motion.div
                                initial={{ opacity: 0, scale: 0.9 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="flex flex-col items-center justify-center py-12 space-y-8"
                            >
                                <div className="relative w-48 h-48 flex items-center justify-center">
                                    <svg className="w-full h-full transform -rotate-90">
                                        <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="2" fill="none" className="text-neutral-800" />
                                        <circle 
                                            cx="96" cy="96" r="88" 
                                            stroke="currentColor" strokeWidth="2" fill="none" 
                                            className="text-[hsl(var(--color-execution))]"
                                            strokeDasharray={553}
                                            strokeDashoffset={553 - (553 * progress) / 100}
                                        />
                                    </svg>
                                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                                        <span className="text-3xl font-mono font-bold text-white">{Math.round(progress)}%</span>
                                        <span className="text-xs text-neutral-500">LOSS: {(1 / (progress + 1)).toFixed(4)}</span>
                                    </div>
                                </div>
                                
                                <div className="w-full max-w-md space-y-2 font-mono text-xs text-neutral-500">
                                    <div className="flex justify-between">
                                        <span>Current Epoch:</span>
                                        <span className="text-white">2/3</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>GPU Utilization:</span>
                                        <span className="text-white">98%</span>
                                    </div>
                                    <div className="flex justify-between">
                                        <span>VRAM Usage:</span>
                                        <span className="text-white">22.4 GB</span>
                                    </div>
                                </div>
                            </motion.div>
                        )}

                        {/* Step 4: Completion & Certification */}
                        {step === 4 && (
                            <motion.div
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="space-y-6"
                            >
                                <div className="p-8 rounded-lg border border-[hsl(var(--color-execution))]/20 bg-[hsl(var(--color-execution))]/5 flex flex-col items-center text-center space-y-4">
                                    <div className="w-16 h-16 rounded-full bg-[hsl(var(--color-execution))]/20 flex items-center justify-center mb-2">
                                        <CheckCircle2 className="w-8 h-8 text-[hsl(var(--color-execution))]" />
                                    </div>
                                    <h2 className="text-2xl font-bold text-white">Model Training Complete</h2>
                                    <p className="text-neutral-400 max-w-md">
                                        <span className="text-white font-mono">{config.name}</span> has been successfully trained and quantized to GGUF format.
                                    </p>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div className="p-4 rounded border border-white/10 bg-neutral-900/50">
                                        <div className="flex items-center gap-2 mb-2 text-[hsl(var(--color-intent))]">
                                            <FileJson className="w-4 h-4" />
                                            <span className="text-sm font-bold">GGUF Export</span>
                                        </div>
                                        <p className="text-xs text-neutral-500 mb-3">
                                            Ready for local inference via Zed/Ollama.
                                        </p>
                                        <Button size="sm" variant="outline" className="w-full text-xs">
                                            Download .gguf
                                        </Button>
                                    </div>

                                    <div className="p-4 rounded border border-white/10 bg-neutral-900/50">
                                        <div className="flex items-center gap-2 mb-2 text-amber-500">
                                            <Award className="w-4 h-4" />
                                            <span className="text-sm font-bold">Blockchain Certificate</span>
                                        </div>
                                        <p className="text-xs text-neutral-500 mb-3">
                                            Proof of Work & Ownership verified on-chain.
                                        </p>
                                        <Button size="sm" variant="outline" className="w-full text-xs">
                                            View Smart Contract
                                        </Button>
                                    </div>
                                </div>

                                <div className="flex justify-center pt-4">
                                    <Button onClick={() => setStep(1)} variant="ghost">Train Another Model</Button>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
            </div>
        </div>
    );
};