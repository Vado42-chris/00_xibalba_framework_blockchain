import React, { useState, useEffect } from 'react';
import { 
  RadioTower, Play, Users, LayoutDashboard, 
  FileText, Database, Shield, Zap, CheckCircle2,
  Cpu, Terminal, ArrowRight, Minimize2, Maximize2, Plug,
  Share2
  } from 'lucide-react';
  import { motion, AnimatePresence } from 'framer-motion';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot, Quadrant 
} from '@/components/ui/design-system/SystemDesign';
import ProcessCompletion from '@/components/ui/design-system/ProcessCompletion';
import { LoadingLab } from '@/components/ui/design-system/Curiosity';
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";

// Simulated "Thinking" Stream for an Agent
const AgentStream = ({ agent, objective, isRunning, onComplete }) => {
    const [logs, setLogs] = useState([]);
    const [status, setStatus] = useState('idle'); // idle, thinking, working, done
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        if (!isRunning) {
            setLogs([]);
            setStatus('idle');
            setProgress(0);
            return;
        }

        setStatus('thinking');
        let step = 0;
        
        const steps = [
            { msg: "Analyzing objective parameters...", delay: 800 },
            { msg: "Decomposing task into sub-routines...", delay: 1500 },
            { msg: `Context loaded: ${agent.scope?.length || 1} permission sets active.`, delay: 2200 },
            ...(agent.integrations && agent.integrations.length > 0 ? [
                { msg: `Connecting to ${agent.integrations.length} external tools...`, delay: 2800 },
                { msg: `Invoking ${agent.integrations[0]} API...`, delay: 3200 }
            ] : []),
            { msg: "Executing primary logic stream...", delay: 3500 },
            { msg: "Validating output against safety constraints...", delay: 4500 },
            { msg: "Finalizing artifacts...", delay: 5500 },
            { msg: "Task Complete.", delay: 6000 }
        ];

        const interval = setInterval(() => {
            if (step >= steps.length) {
                clearInterval(interval);
                setStatus('done');
                onComplete(agent.id, "Output generated successfully based on objective.");
                return;
            }

            const currentStep = steps[step];
            // Simulate variable timing
            if (Math.random() > 0.3) {
                setLogs(prev => [...prev, { time: new Date().toLocaleTimeString(), text: currentStep.msg }]);
                setProgress(Math.floor(((step + 1) / steps.length) * 100));
                step++;
            }
        }, 800);

        return () => clearInterval(interval);
    }, [isRunning]);

    return (
        <div className={cn(
            "flex flex-col border rounded-md overflow-hidden transition-all duration-500 bg-neutral-900/50",
            status === 'thinking' || status === 'working' ? "border-[hsl(var(--color-active))] shadow-[0_0_15px_-5px_hsl(var(--color-active))]" : 
            status === 'done' ? "border-green-500/30 opacity-80" : "border-white/5 opacity-60"
        )}>
            {/* Header */}
            <div className="p-3 border-b border-white/5 flex items-center justify-between bg-neutral-900">
                <div className="flex items-center gap-2">
                    <div className={cn("w-2 h-2 rounded-full", 
                        status === 'idle' ? "bg-neutral-600" :
                        status === 'done' ? "bg-green-500" : "bg-[hsl(var(--color-active))] animate-pulse"
                    )} />
                    <IntentText className="font-bold text-xs">{agent.name}</IntentText>
                    <Badge variant="outline" className="text-[9px] h-4 px-1 border-white/10 text-neutral-500">{agent.role}</Badge>
                </div>
                <StateText className="font-mono text-[9px]">{progress}%</StateText>
            </div>

            {/* Terminal View */}
            <div className="flex-1 p-3 font-mono text-[10px] text-neutral-400 overflow-y-auto h-48 space-y-1 bg-neutral-950">
                {logs.length === 0 && isRunning && (
                    <div className="text-[hsl(var(--color-active))] animate-pulse">_ Awaiting cycle...</div>
                )}
                {logs.length === 0 && !isRunning && (
                    <div className="opacity-30">Standby...</div>
                )}
                {logs.map((log, i) => (
                    <div key={i} className="flex gap-2 animate-in slide-in-from-left-2 duration-300">
                        <span className="opacity-30">[{log.time}]</span>
                        <span className={cn(
                            i === logs.length - 1 && status !== 'done' ? "text-[hsl(var(--color-active))]" : "text-neutral-300"
                        )}>
                            {log.text}
                        </span>
                    </div>
                ))}
                {status === 'done' && (
                    <div className="text-green-500 mt-2 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> RESULT BUFFERED
                    </div>
                )}
            </div>
        </div>
    );
};

export default function MissionControl({ agents = [] }) {
    const [selectedAgents, setSelectedAgents] = useState([]);
    const [objective, setObjective] = useState("");
    const [isExecuting, setIsExecuting] = useState(false);
    const [results, setResults] = useState({});
    const [mode, setMode] = useState("planning"); // planning, executing, review

    const toggleAgent = (id) => {
        setSelectedAgents(prev => 
            prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
        );
    };

    const handleExecute = () => {
        if (!objective.trim()) {
            toast.error("Mission objective required");
            return;
        }
        if (selectedAgents.length === 0) {
            toast.error("No agents assigned to mission");
            return;
        }
        
        setMode("executing");
        setIsExecuting(true);
        setResults({});
    };

    const handleAgentComplete = (id, result) => {
        setResults(prev => {
            const newResults = { ...prev, [id]: result };
            // Check if all done
            if (Object.keys(newResults).length === selectedAgents.length) {
                setTimeout(() => {
                    setIsExecuting(false);
                    setMode("review");
                    toast.success("Mission Accomplished: All agents reported in.");
                }, 1000);
            }
            return newResults;
        });
    };

    const resetMission = () => {
        setMode("planning");
        setObjective("");
        setResults({});
        setSelectedAgents([]);
    };

    // Calculate Grid Columns based on selection
    const gridCols = selectedAgents.length <= 1 ? "grid-cols-1" : 
                     selectedAgents.length <= 2 ? "grid-cols-2" : 
                     selectedAgents.length <= 4 ? "grid-cols-2" : "grid-cols-3";

    return (
        <div className="h-full flex flex-col bg-neutral-950 overflow-hidden">
            {/* Header: War Room Status */}
            <div className="p-4 border-b border-white/10 bg-neutral-900/50 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-3">
                    <div className={cn("p-2 rounded bg-neutral-900 border border-white/10", mode === 'executing' && "animate-pulse border-[hsl(var(--color-active))]")}>
                        <RadioTower className={cn("w-5 h-5", mode === 'executing' ? "text-[hsl(var(--color-active))]" : "text-neutral-500")} />
                    </div>
                    <div>
                        <OrientingText className="text-[9px] uppercase tracking-widest text-[hsl(var(--color-intent))]">
                            {mode === 'planning' ? 'MISSION CONFIGURATION' : mode === 'executing' ? 'LIVE OPERATIONS' : 'DEBRIEF'}
                        </OrientingText>
                        <IntentText className="font-bold">Swarm Command</IntentText>
                    </div>
                </div>
                
                {mode === 'planning' && (
                    <Button 
                        onClick={handleExecute} 
                        className="bg-[hsl(var(--color-active))] text-black font-bold hover:bg-[hsl(var(--color-active))]/90"
                    >
                        <Zap className="w-4 h-4 mr-2" /> Broadcast Order
                    </Button>
                )}
                {mode === 'review' && (
                    <Button onClick={resetMission} variant="outline" className="border-white/10">
                        New Mission
                    </Button>
                )}
            </div>

            <div className="flex-1 flex overflow-hidden">
                {/* LEFT PANE: Configuration (Visible in Planning/Review) */}
                <div className={cn(
                    "flex flex-col border-r border-white/10 bg-neutral-900 transition-all duration-500 ease-in-out z-10",
                    mode === 'executing' ? "w-0 opacity-0 overflow-hidden" : "w-1/3 min-w-[320px]"
                )}>
                    <div className="p-6 space-y-6 overflow-y-auto">
                        <div className="space-y-3">
                            <OrientingText>1. DEFINE OBJECTIVE</OrientingText>
                            <Textarea 
                                value={objective}
                                onChange={(e) => setObjective(e.target.value)}
                                placeholder="Describe the complex task for the swarm... (e.g. 'Audit the last 100 transactions for fraud patterns, generate a summary report, and draft email alerts for flagged accounts.')"
                                className="h-40 bg-neutral-950 border-white/10 font-mono text-xs leading-relaxed resize-none focus:border-[hsl(var(--color-intent))]"
                            />
                            <div className="flex gap-2">
                                <Button variant="outline" size="sm" className="h-7 text-[10px] border-white/10 text-neutral-500">
                                    <FileText className="w-3 h-3 mr-1" /> Attach Context
                                </Button>
                                <Button variant="outline" size="sm" className="h-7 text-[10px] border-white/10 text-neutral-500">
                                    <Database className="w-3 h-3 mr-1" /> Connect Data Source
                                </Button>
                            </div>
                        </div>

                        <div className="space-y-3">
                             <div className="flex justify-between items-center">
                                <OrientingText>2. ASSEMBLE SQUAD</OrientingText>
                                <StateText>{selectedAgents.length} Selected</StateText>
                             </div>
                             <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                                {agents.map(agent => (
                                    <div 
                                        key={agent.id}
                                        onClick={() => toggleAgent(agent.id)}
                                        className={cn(
                                            "flex items-center gap-3 p-3 rounded border cursor-pointer transition-all",
                                            selectedAgents.includes(agent.id) 
                                                ? "bg-[hsl(var(--color-active))]/10 border-[hsl(var(--color-active))] shadow-[inset_0_0_10px_rgba(0,0,0,0.2)]" 
                                                : "bg-neutral-950 border-white/5 hover:border-white/20"
                                        )}
                                    >
                                        <Checkbox checked={selectedAgents.includes(agent.id)} className="border-white/20 data-[state=checked]:bg-[hsl(var(--color-active))] data-[state=checked]:text-black" />
                                        <div className="flex-1">
                                            <IntentText className="font-bold text-xs">{agent.name}</IntentText>
                                            <StateText className="text-[10px] uppercase opacity-50">{agent.role}</StateText>
                                        </div>
                                        <div className="flex flex-col gap-1 items-end">
                                            <div className="flex gap-1">
                                                {agent.scope?.slice(0,2).map((s, i) => (
                                                    <div key={i} className="w-1.5 h-1.5 rounded-full bg-neutral-700" title={s} />
                                                ))}
                                            </div>
                                            {agent.integrations?.length > 0 && (
                                                <div className="flex items-center gap-0.5 text-[9px] text-[hsl(var(--color-intent))] opacity-70">
                                                    <Plug className="w-2 h-2" />
                                                    <span>{agent.integrations.length}</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                             </div>
                        </div>
                    </div>
                </div>

                {/* RIGHT PANE: Execution Grid */}
                <div className="flex-1 bg-neutral-950 relative overflow-hidden flex flex-col">
                    {/* Background Grid */}
                    <div className="absolute inset-0 pointer-events-none opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#ffffff 1px, transparent 1px), linear-gradient(90deg, #ffffff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />

                    {selectedAgents.length === 0 ? (
                        <div className="flex-1 flex flex-col items-center justify-center opacity-30">
                            <Users className="w-16 h-16 text-neutral-600 mb-4" />
                            <OrientingText>AWAITING SQUAD SELECTION</OrientingText>
                        </div>
                    ) : (
                        <div className="flex-1 p-6 overflow-y-auto z-10">
                            <div className={cn("grid gap-4 h-full content-start transition-all", gridCols)}>
                                {selectedAgents.map(agentId => {
                                    const agent = agents.find(a => a.id === agentId);
                                    if (!agent) return null;
                                    return (
                                        <AgentStream 
                                            key={agent.id} 
                                            agent={agent} 
                                            objective={objective} 
                                            isRunning={mode === 'executing' || mode === 'review'}
                                            onComplete={handleAgentComplete}
                                        />
                                    );
                                })}
                            </div>
                        </div>
                    )}
                    
                    {mode === 'review' && (
                        <div className="h-1/3 border-t border-white/10 bg-neutral-900 z-20 animate-in slide-in-from-bottom-10 flex flex-col">
                            <div className="flex-1 overflow-y-auto">
                                <ProcessCompletion 
                                    title="Mission Accomplished"
                                    subtitle={`Objective "${objective.slice(0, 30)}..." executed successfully.`}
                                    artifacts={[
                                        { name: "intelligence_report.pdf", type: "PDF", size: "2.4mb" },
                                        { name: "agent_logs.json", type: "JSON", size: "156kb" }
                                    ]}
                                    actions={[
                                        { label: "Download Report", icon: FileText, primary: true, onClick: () => toast.success("Download started") },
                                        { label: "Publish to Marketplace", icon: Share2, onClick: () => toast.success("Published to marketplace") }
                                    ]}
                                    onClose={resetMission}
                                />
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}