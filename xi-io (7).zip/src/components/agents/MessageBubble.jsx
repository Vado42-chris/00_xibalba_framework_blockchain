import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Button } from "@/components/ui/button";
import { Copy, Zap, CheckCircle2, AlertCircle, Loader2, ChevronRight, Clock } from 'lucide-react';
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const FunctionDisplay = ({ toolCall }) => {
    const [expanded, setExpanded] = useState(false);
    const name = toolCall?.name || 'Function';
    const status = toolCall?.status || 'pending';
    const results = toolCall?.results;
    
    // Parse and check for errors
    const parsedResults = (() => {
        if (!results) return null;
        try {
            return typeof results === 'string' ? JSON.parse(results) : results;
        } catch {
            return results;
        }
    })();
    
    const isError = results && (
        (typeof results === 'string' && /error|failed/i.test(results)) ||
        (parsedResults?.success === false)
    );
    
    // Status configuration
    const statusConfig = {
        pending: { icon: Clock, color: 'text-slate-400', text: 'Pending' },
        running: { icon: Loader2, color: 'text-slate-500', text: 'Running...', spin: true },
        in_progress: { icon: Loader2, color: 'text-slate-500', text: 'Running...', spin: true },
        completed: isError ? 
            { icon: AlertCircle, color: 'text-red-500', text: 'Failed' } : 
            { icon: CheckCircle2, color: 'text-green-600', text: 'Success' },
        success: { icon: CheckCircle2, color: 'text-green-600', text: 'Success' },
        failed: { icon: AlertCircle, color: 'text-red-500', text: 'Failed' },
        error: { icon: AlertCircle, color: 'text-red-500', text: 'Failed' }
    }[status] || { icon: Zap, color: 'text-slate-500', text: '' };
    
    const Icon = statusConfig.icon;
    const formattedName = name.split('.').reverse().join(' ').toLowerCase();
    
    return (
        <div className="mt-2 text-xs">
            <button
                onClick={() => setExpanded(!expanded)}
                className={cn(
                    "flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-all w-full",
                    "hover:bg-slate-50",
                    expanded ? "bg-slate-50 border-slate-300" : "bg-white border-slate-200"
                )}
            >
                <Icon className={cn("h-3 w-3", statusConfig.color, statusConfig.spin && "animate-spin")} />
                <span className="text-slate-700 font-mono">{formattedName}</span>
                {statusConfig.text && (
                    <span className={cn("text-slate-500 ml-auto", isError && "text-red-600")}>
                        {statusConfig.text}
                    </span>
                )}
                {!statusConfig.spin && (toolCall.arguments_string || results) && (
                    <ChevronRight className={cn("h-3 w-3 text-slate-400 transition-transform ml-2", 
                        expanded && "rotate-90")} />
                )}
            </button>
            
            {expanded && !statusConfig.spin && (
                <div className="mt-1.5 ml-3 pl-3 border-l-2 border-slate-200 space-y-2 animate-in slide-in-from-top-2 duration-200">
                    {toolCall.arguments_string && (
                        <div>
                            <div className="text-[10px] uppercase tracking-wider text-slate-400 mb-1">Input Parameters</div>
                            <pre className="bg-slate-50 rounded-md p-2 text-xs text-slate-600 whitespace-pre-wrap font-mono border border-slate-100">
                                {(() => {
                                    try {
                                        return JSON.stringify(JSON.parse(toolCall.arguments_string), null, 2);
                                    } catch {
                                        return toolCall.arguments_string;
                                    }
                                })()}
                            </pre>
                        </div>
                    )}
                    {parsedResults && (
                        <div>
                            <div className="text-[10px] uppercase tracking-wider text-slate-400 mb-1">Output Result</div>
                            <pre className="bg-slate-50 rounded-md p-2 text-xs text-slate-600 whitespace-pre-wrap max-h-48 overflow-auto font-mono border border-slate-100">
                                {typeof parsedResults === 'object' ? 
                                    JSON.stringify(parsedResults, null, 2) : parsedResults}
                            </pre>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default function MessageBubble({ message }) {
    const isUser = message.role === 'user';
    const hasTools = message.tool_calls?.length > 0;
    
    if (!message.content && !hasTools) return null;

    return (
        <div className={cn("flex gap-3 mb-4", isUser ? "justify-end" : "justify-start")}>
            {!isUser && (
                <div className="h-8 w-8 rounded-lg bg-[hsl(var(--color-intent))]/10 flex items-center justify-center shrink-0 mt-0.5 border border-[hsl(var(--color-intent))]/20">
                    <Zap className="h-4 w-4 text-[hsl(var(--color-intent))]" />
                </div>
            )}
            
            <div className={cn("max-w-[85%] flex flex-col gap-2", isUser && "items-end")}>
                {message.content && (
                    <div className={cn(
                        "rounded-2xl px-4 py-3 shadow-sm",
                        isUser 
                            ? "bg-neutral-800 text-white rounded-br-sm" 
                            : "bg-white text-neutral-800 border border-neutral-200 rounded-bl-sm"
                    )}>
                        {isUser ? (
                            <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                        ) : (
                            <div className="text-sm prose prose-sm max-w-none prose-p:leading-relaxed prose-pre:bg-neutral-900 prose-pre:text-neutral-100">
                                <ReactMarkdown 
                                    components={{
                                        code: ({ inline, className, children, ...props }) => {
                                            const match = /language-(\w+)/.exec(className || '');
                                            return !inline && match ? (
                                                <div className="relative group/code my-4 rounded-lg overflow-hidden">
                                                    <div className="flex items-center justify-between px-3 py-1.5 bg-neutral-950 border-b border-white/10 text-[10px] text-neutral-400">
                                                        <span>{match[1]}</span>
                                                        <button
                                                            onClick={() => {
                                                                navigator.clipboard.writeText(String(children).replace(/\n$/, ''));
                                                                toast.success('Code copied');
                                                            }}
                                                            className="hover:text-white transition-colors"
                                                        >
                                                            <Copy className="h-3 w-3" />
                                                        </button>
                                                    </div>
                                                    <pre className="bg-neutral-900 text-neutral-100 p-4 overflow-x-auto m-0">
                                                        <code className={className} {...props}>{children}</code>
                                                    </pre>
                                                </div>
                                            ) : (
                                                <code className="px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-800 text-xs font-mono font-medium border border-neutral-200">
                                                    {children}
                                                </code>
                                            );
                                        },
                                        a: ({ children, ...props }) => (
                                            <a {...props} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{children}</a>
                                        ),
                                    }}
                                >
                                    {message.content}
                                </ReactMarkdown>
                            </div>
                        )}
                    </div>
                )}
                
                {hasTools && (
                    <div className="space-y-2 w-full min-w-[300px]">
                        {message.tool_calls.map((toolCall, idx) => (
                            <FunctionDisplay key={idx} toolCall={toolCall} />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}