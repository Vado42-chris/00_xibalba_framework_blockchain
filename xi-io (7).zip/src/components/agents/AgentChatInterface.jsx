import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { 
    Send, Bot, Paperclip, Sparkles, 
    ArrowRight, Loader2, StopCircle
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import MessageBubble from './MessageBubble';

export default function AgentChatInterface({ agentName, context = {}, onAgentChange }) {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [conversationId, setConversationId] = useState(null);
    const scrollRef = useRef(null);
    const messagesEndRef = useRef(null);

    // Initialize Conversation
    useEffect(() => {
        const initConversation = async () => {
            if (!agentName) return;

            setMessages([{ 
                role: 'system', 
                content: `Connecting to secure agent channel: **${agentName}**...` 
            }]);
            
            try {
                // Find existing or create new conversation
                const conversations = await base44.agents.listConversations({ 
                    agent_name: agentName 
                });
                
                let convId;
                if (conversations.length > 0) {
                    // Use the most recent one
                    convId = conversations[0].id;
                    const history = await base44.agents.getConversation(convId);
                    setMessages(history.messages || []);
                } else {
                    // Create new
                    const newConv = await base44.agents.createConversation({
                        agent_name: agentName,
                        metadata: {
                            source: 'OmniAssistant',
                            context: JSON.stringify(context)
                        }
                    });
                    convId = newConv.id;
                    setMessages([]); // Start fresh
                }
                
                setConversationId(convId);
            } catch (error) {
                console.error("Agent connection failed:", error);
                setMessages(prev => [...prev, { 
                    role: 'system', 
                    content: `❌ Connection failed: ${error.message}` 
                }]);
            }
        };

        initConversation();
    }, [agentName]);

    // Subscribe to real-time updates
    useEffect(() => {
        if (!conversationId) return;

        const unsubscribe = base44.agents.subscribeToConversation(conversationId, (data) => {
            if (data.messages) {
                setMessages(data.messages);
            }
        });

        return () => {
            unsubscribe();
        };
    }, [conversationId]);

    // Auto-scroll to bottom
    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, isLoading]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!input.trim() || !conversationId) return;

        const content = input;
        setInput('');
        setIsLoading(true);

        try {
            await base44.agents.addMessage({ id: conversationId }, {
                role: "user",
                content: content
            });
            // State update happens via subscription
        } catch (error) {
            toast.error("Failed to send message");
            setInput(content); // Restore input
        } finally {
            // Loading state is tricky with streams, we rely on the stream to update UI
            // But we can unset it after a short delay or when we see a response
            setTimeout(() => setIsLoading(false), 2000); 
        }
    };

    return (
        <div className="flex flex-col h-full bg-neutral-50/50">
            {/* Messages Area */}
            <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                <div className="flex flex-col min-h-0">
                    {messages.length === 0 && !isLoading && (
                        <div className="flex flex-col items-center justify-center h-40 text-neutral-400 space-y-2 mt-10">
                            <div className="w-12 h-12 rounded-full bg-white border border-neutral-200 flex items-center justify-center shadow-sm">
                                <Bot className="w-6 h-6 text-[hsl(var(--color-intent))]" />
                            </div>
                            <p className="text-sm font-medium">Ready to assist.</p>
                            <p className="text-xs text-center max-w-[200px]">
                                I have access to system tools and can perform actions on your behalf.
                            </p>
                        </div>
                    )}
                    
                    {messages.map((msg, i) => (
                        <MessageBubble key={i} message={msg} />
                    ))}
                    
                    {isLoading && messages[messages.length - 1]?.role === 'user' && (
                        <div className="flex items-center gap-2 text-neutral-400 text-xs ml-4 animate-pulse">
                            <Bot className="w-3 h-3" />
                            <span>Thinking...</span>
                        </div>
                    )}
                    
                    <div ref={messagesEndRef} />
                </div>
            </ScrollArea>

            {/* Input Area */}
            <form onSubmit={handleSubmit} className="p-3 bg-white border-t border-neutral-200 shrink-0">
                <div className="relative flex items-end gap-2 p-1">
                    <Button type="button" variant="ghost" size="icon" className="h-9 w-9 text-neutral-400 hover:text-neutral-600 mb-0.5">
                        <Paperclip className="h-4 w-4" />
                    </Button>
                    <div className="flex-1 relative">
                        <Input 
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder={`Message ${agentName}...`}
                            className="w-full bg-neutral-100 border-transparent focus:bg-white focus:border-[hsl(var(--color-intent))] pr-10 min-h-[40px]"
                            autoFocus
                        />
                    </div>
                    <Button 
                        type="submit" 
                        size="icon" 
                        disabled={!input.trim() || !conversationId}
                        className={cn(
                            "h-10 w-10 mb-0.5 transition-all shadow-sm", 
                            input.trim() 
                                ? "bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white" 
                                : "bg-neutral-100 text-neutral-300"
                        )}
                    >
                        {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
                    </Button>
                </div>
                <div className="flex justify-between mt-2 px-2">
                    <div className="flex items-center gap-2">
                         <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                         <span className="text-[10px] text-neutral-400 font-mono">SECURE CHANNEL ACTIVE</span>
                    </div>
                    <span className="text-[10px] text-[hsl(var(--color-execution))] font-mono flex items-center gap-1">
                        <Sparkles className="w-2 h-2" /> AGENT MODE
                    </span>
                </div>
            </form>
        </div>
    );
}