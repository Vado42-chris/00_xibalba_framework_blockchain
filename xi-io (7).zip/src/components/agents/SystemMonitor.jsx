import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Shield, Activity, Zap, Server, Lock, AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';
import { OrientingText, IntentText, StateText, SemanticDot, ChartFrame } from '@/components/ui/design-system/SystemDesign';
import { SystemStats, SystemLog } from '@/components/ui/design-system/SystemContent';
import { TimeGraph } from '@/components/ui/design-system/Infographics';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LoadingLab } from '@/components/ui/design-system/Curiosity';
import { cn } from '@/lib/utils';

export function SystemMonitor({ domainFamily = 'XI-IO' }) {
    const [scanning, setScanning] = useState(false);
    const [healthScore, setHealthScore] = useState(98);
    const [anomalies, setAnomalies] = useState([]);

    const runScan = async () => {
        setScanning(true);
        try {
            // Fetch recent error logs for real analysis
            const recentLogs = await base44.entities.Log.list('-timestamp', 10);
            const errorLogs = recentLogs.filter(l => l.status === 'error' || l.status === 'blocked');
            
            let analysis = null;
            if (errorLogs.length > 0) {
                // AI Analysis of logs
                const prompt = `Analyze these system logs for threats/anomalies: ${JSON.stringify(errorLogs.map(l => l.content))}. Return JSON: { score: number, anomalies: [{ type: 'critical'|'warning'|'nominal', text: string, source: string }] }`;
                const res = await base44.integrations.Core.InvokeLLM({ 
                    prompt,
                    response_json_schema: {
                        type: "object",
                        properties: {
                            score: { type: "number" },
                            anomalies: { 
                                type: "array", 
                                items: { 
                                    type: "object", 
                                    properties: { 
                                        type: { type: "string" }, 
                                        text: { type: "string" }, 
                                        source: { type: "string" } 
                                    } 
                                } 
                            }
                        }
                    }
                });
                analysis = res;

                // TRIGGER HEALER FOR CRITICAL ANOMALIES
                if (analysis && analysis.anomalies) {
                    for (const anomaly of analysis.anomalies) {
                        if (anomaly.type === 'critical' || anomaly.type === 'warning') {
                            await base44.functions.invoke('healer', { 
                                action: 'dispatch', 
                                anomaly: anomaly 
                            });
                        }
                    }
                }
            }

            setTimeout(() => {
                setScanning(false);
                if (analysis) {
                    setHealthScore(analysis.score || 95);
                    setAnomalies(analysis.anomalies || []);
                } else {
                    setHealthScore(99);
                    setAnomalies([]);
                }
            }, 1500); // Keep animation for feel
        } catch (e) {
            setScanning(false);
            // Fallback
            setHealthScore(98);
        }
    };

    return (
        <Card className="bg-neutral-950 border border-white/10 overflow-hidden relative">
            <div className="p-4 border-b border-white/5 flex justify-between items-center bg-neutral-900/50">
                <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[hsl(var(--color-active))]" />
                    <OrientingText className="font-bold tracking-widest">SENTINEL AI</OrientingText>
                </div>
                <div className="flex items-center gap-2">
                    <Badge variant="outline" className={cn(
                        "font-mono text-[9px] h-5",
                        healthScore > 95 ? "border-emerald-500/50 text-emerald-500" : "border-yellow-500/50 text-yellow-500"
                    )}>
                        HEALTH: {healthScore}%
                    </Badge>
                    <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-6 w-6 text-neutral-500 hover:text-white"
                        onClick={runScan}
                        disabled={scanning}
                    >
                        <RefreshCw className={cn("w-3 h-3", scanning && "animate-spin")} />
                    </Button>
                </div>
            </div>

            <div className="p-4 relative min-h-[150px]">
                {scanning ? (
                    <div className="absolute inset-0 bg-neutral-950 z-10">
                        <LoadingLab 
                            active={true} 
                            cause="System Scan" 
                            duration="Analyzing..." 
                            scenarios={[
                                { setup: "Pinging Nodes...", math: "Latency < 20ms", human: "Checking pulse...", resolution: "Nodes Healthy" },
                                { setup: "Verifying Integrity...", math: "Hash match 100%", human: "Checking locks...", resolution: "Secure" }
                            ]}
                            className="h-full"
                        />
                    </div>
                ) : (
                    <div className="space-y-4">
                        <SystemStats 
                            className="grid-cols-2"
                            stats={[
                                { label: "Uptime", value: "99.99%", icon: Activity, color: "text-[hsl(var(--color-execution))]" },
                                { label: "Load", value: "34%", icon: Zap, color: "text-[hsl(var(--color-intent))]" }
                            ]}
                        />

                        <div className="h-32 bg-neutral-900/30 rounded border border-white/5 p-2">
                            <ChartFrame label="NEURAL LOAD" metric="420 t/s" trend="+5%" category="execution">
                                <TimeGraph 
                                    data={[
                                        {t:'00', v:45}, {t:'05', v:60}, {t:'10', v:55}, 
                                        {t:'15', v:80}, {t:'20', v:70}, {t:'25', v:90}
                                    ]} 
                                    dataKey="v" 
                                    category="execution" 
                                    height={100} 
                                />
                            </ChartFrame>
                        </div>

                        <div>
                            <OrientingText className="mb-2 text-[9px]">PREDICTIVE ALERTS</OrientingText>
                            {anomalies.length > 0 ? (
                                <SystemLog 
                                    className="max-h-32"
                                    logs={anomalies.map(a => ({
                                        type: a.source || 'SYSTEM',
                                        status: a.type === 'critical' ? 'error' : a.type === 'warning' ? 'warning' : 'nominal',
                                        content: a.text,
                                        timestamp: new Date().toISOString()
                                    }))}
                                />
                            ) : (
                                <div className="flex items-center gap-2 p-2 bg-emerald-500/5 border border-emerald-500/10 rounded text-emerald-500">
                                    <CheckCircle2 className="w-3 h-3" />
                                    <StateText className="text-emerald-500 text-xs">No imminent threats detected.</StateText>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </Card>
    );
}