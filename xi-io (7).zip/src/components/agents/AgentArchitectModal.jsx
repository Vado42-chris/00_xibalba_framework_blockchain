import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { base44 } from '@/api/base44Client';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { toast } from "sonner";
import { Cpu, Shield, Zap, Database, Globe, Plug } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

const ROLES = [
   { id: 'security', name: 'Security Sentinel', icon: Shield },
   { id: 'dev', name: 'Code Architect', icon: Cpu },
   { id: 'analyst', name: 'Data Analyst', icon: Database },
   { id: 'network', name: 'Network Ghost', icon: Globe },
   { id: 'generic', name: 'General Assistant', icon: Zap },
];

export default function AgentArchitectModal({ open, onOpenChange }) {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
     name: '',
     role: 'generic',
     description: '',
     scope: ['read_only'],
     integrations: [],
     autonomy_level: 50
  });

  // Fetch available integrations to link to agent
  const { data: integrations = [] } = useQuery({
      queryKey: ['integrations_list'],
      queryFn: () => base44.entities.Integration.list(),
      initialData: []
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await base44.entities.Agent.create({
        name: data.name,
        role: ROLES.find(r => r.id === data.role)?.name || data.role,
        version: "v1.0.0",
        scope: data.scope,
        integrations: data.integrations,
        status: "idle",
        last_active: new Date().toISOString()
      });
      await queryClient.invalidateQueries({ queryKey: ['agents'] });
      toast.success("Agent constructed and deployed");
      onOpenChange(false);
    } catch (err) {
      toast.error("Deployment failed");
    } finally {
      setLoading(false);
    }
  };

  const toggleScope = (scope) => {
     setData(prev => ({
        ...prev,
        scope: prev.scope.includes(scope) 
           ? prev.scope.filter(s => s !== scope)
           : [...prev.scope, scope]
     }));
  };

  const toggleIntegration = (id) => {
     setData(prev => ({
        ...prev,
        integrations: prev.integrations.includes(id) 
           ? prev.integrations.filter(i => i !== id)
           : [...prev.integrations, id]
     }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[hsl(var(--layer-orientation))] border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-intent))] sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
             <Cpu className="w-5 h-5 text-[hsl(var(--color-execution))]" />
             Agent Architect Protocol
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
           {/* Identity Matrix */}
           <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                 <Label className="text-xs uppercase text-[hsl(var(--fg-orientation))]">Designation (Name)</Label>
                 <Input 
                   value={data.name}
                   onChange={e => setData({...data, name: e.target.value})}
                   className="bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))] font-mono"
                   placeholder="e.g. OMEGA-7"
                   required
                />
              </div>
              <div className="space-y-2">
                 <Label className="text-xs uppercase text-[hsl(var(--fg-orientation))]">Archetype (Role)</Label>
                 <Select value={data.role} onValueChange={v => setData({...data, role: v})}>
                    <SelectTrigger className="bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))]">
                       <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                       {ROLES.map(role => (
                          <SelectItem key={role.id} value={role.id}>
                             <div className="flex items-center gap-2">
                                <role.icon className="w-3 h-3" /> {role.name}
                             </div>
                          </SelectItem>
                       ))}
                    </SelectContent>
                 </Select>
              </div>
           </div>

           {/* Directives */}
           <div className="space-y-2">
              <Label className="text-xs uppercase text-[hsl(var(--fg-orientation))]">Prime Directive</Label>
              <Textarea 
                 value={data.description}
                 onChange={e => setData({...data, description: e.target.value})}
                 className="bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))] min-h-[80px]"
                 placeholder="Define the primary operational parameters and goals..."
              />
           </div>

           {/* Configuration */}
           <div className="grid grid-cols-2 gap-6">
              <div className="space-y-4">
                 <Label className="text-xs uppercase text-[hsl(var(--fg-orientation))]">Permissions Scope</Label>
                 <div className="flex flex-wrap gap-2">
                    {['read_only', 'write_files', 'execute_code', 'network_access'].map(scope => (
                       <Badge 
                          key={scope}
                          variant={data.scope.includes(scope) ? "default" : "outline"}
                          className={`cursor-pointer ${data.scope.includes(scope) ? 'bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/30' : 'border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-orientation))] hover:border-[hsl(var(--fg-state))]'}`}
                          onClick={() => toggleScope(scope)}
                       >
                          {scope.replace('_', ' ')}
                       </Badge>
                    ))}
                 </div>

                 <div className="pt-2">
                    <Label className="text-xs uppercase text-[hsl(var(--fg-orientation))] block mb-2">Linked Integrations</Label>
                    <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                        {integrations.length === 0 && <span className="text-[10px] text-neutral-500">No active integrations found.</span>}
                        {integrations.map(integration => (
                            <Badge 
                                key={integration.id}
                                variant={data.integrations.includes(integration.id) ? "default" : "outline"}
                                className={`cursor-pointer gap-1 ${data.integrations.includes(integration.id) ? 'bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/30' : 'border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-orientation))] hover:border-[hsl(var(--fg-state))]'}`}
                                onClick={() => toggleIntegration(integration.id)}
                            >
                                <Plug className="w-2 h-2" />
                                {integration.name}
                            </Badge>
                        ))}
                    </div>
                 </div>
              </div>
              
              <div className="space-y-4">
                 <div className="flex justify-between">
                    <Label className="text-xs uppercase text-[hsl(var(--fg-orientation))]">Autonomy Level</Label>
                    <span className="text-xs font-mono text-[hsl(var(--color-execution))]">{data.autonomy_level}%</span>
                 </div>
                 <Slider 
                    value={[data.autonomy_level]} 
                    onValueChange={([v]) => setData({...data, autonomy_level: v})}
                    max={100}
                    step={1}
                    className="py-2"
                 />
                 <p className="text-[10px] text-[hsl(var(--fg-orientation))]">
                    {data.autonomy_level < 30 ? "Strict human oversight required." : 
                     data.autonomy_level < 70 ? "Semi-autonomous execution allowed." : 
                     "Full autonomous decision making enabled."}
                 </p>
              </div>
           </div>

           <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Abort</Button>
              <Button type="submit" className="bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/80 text-black" disabled={loading}>
                 {loading ? "Compiling..." : "Deploy Agent"}
              </Button>
           </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}