import React from 'react';
import { Lightbulb, Sparkles, TrendingUp, Users, ArrowRight } from 'lucide-react';
import { OrientingText, IntentText, StateText } from '@/components/ui/design-system/SystemDesign';
import { cn } from '@/lib/utils';

export function InsightEngine({ context = 'general', data = {} }) {
    // Mock logic to generate insights based on context
    const getInsights = () => {
        switch(context) {
            case 'crm':
                return [
                    { type: 'opportunity', text: '3 High-value leads have been inactive for > 30 days.', action: 'Re-engage' },
                    { type: 'trend', text: 'VIP engagement is up 15% this month.', action: 'View Report' }
                ];
            case 'commerce':
                return [
                    { type: 'optimization', text: 'Inventory low on "Neural Link v2".', action: 'Restock' },
                    { type: 'prediction', text: 'Sales expected to peak this weekend.', action: 'Prepare' }
                ];
            case 'comms':
                return [
                    { type: 'priority', text: 'You have 5 unread messages from key stakeholders.', action: 'Filter Inbox' }
                ];
            default:
                return [
                    { type: 'general', text: 'System resources are optimal for high-load tasks.', action: 'Deploy' }
                ];
        }
    };

    const insights = getInsights();

    return (
        <div className="space-y-3">
            <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                <OrientingText className="font-bold tracking-widest text-[hsl(var(--color-intent))]">AI INSIGHTS</OrientingText>
            </div>
            
            {insights.map((insight, i) => (
                <div key={i} className="group relative p-3 bg-gradient-to-br from-neutral-900 to-neutral-950 border border-white/10 rounded-lg hover:border-[hsl(var(--color-intent))] transition-all">
                    <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <ArrowRight className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                    </div>
                    
                    <div className="flex items-start gap-3">
                        <div className={cn(
                            "mt-0.5 w-1.5 h-1.5 rounded-full shadow-[0_0_8px_currentColor]",
                            insight.type === 'opportunity' ? "bg-emerald-500 text-emerald-500" :
                            insight.type === 'warning' ? "bg-red-500 text-red-500" :
                            "bg-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))]"
                        )} />
                        <div>
                            <p className="text-xs text-neutral-300 leading-relaxed max-w-[90%]">
                                {insight.text}
                            </p>
                            <button className="text-[9px] uppercase tracking-wider font-mono text-[hsl(var(--color-intent))] mt-2 hover:underline">
                                {insight.action}
                            </button>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
}