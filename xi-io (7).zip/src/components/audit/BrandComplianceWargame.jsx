import React, { useState, useEffect } from 'react';
import { 
    Shield, CheckCircle2, AlertTriangle, XCircle, 
    Search, RefreshCw, BarChart2, Lock
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
    OrientingText, IntentText, StateText, 
    QuadrantGrid, Quadrant 
} from '@/components/ui/design-system/System';

export default function BrandComplianceWargame() {
    const [running, setRunning] = useState(false);
    const [progress, setProgress] = useState(0);
    const [results, setResults] = useState(null);

    const runAudit = () => {
        setRunning(true);
        setProgress(0);
        setResults(null);

        // Simulate audit steps
        const interval = setInterval(() => {
            setProgress(prev => {
                if (prev >= 100) {
                    clearInterval(interval);
                    setRunning(false);
                    generateResults();
                    return 100;
                }
                return prev + 5;
            });
        }, 100);
    };

    const generateResults = () => {
        setResults([
            { id: 1, check: "Logo Usage", status: "pass", score: 98, details: "Correct aspect ratios detected across all portals." },
            { id: 2, check: "Color Palette", status: "pass", score: 100, details: "All hex codes match Design System v2.4." },
            { id: 3, check: "Typography", status: "pass", score: 100, details: "Font weights aligned to design system." },
            { id: 4, check: "Tone of Voice", status: "pass", score: 98, details: "Enterprise section standardized to 'Clinical' tone." },
            { id: 5, check: "Iconography", status: "pass", score: 95, details: "Lucide icons correctly implemented." }
        ]);
    };

    return (
        <div className="h-full flex flex-col bg-neutral-950 border border-white/5 rounded-lg overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-white/5 bg-neutral-900/50 flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <Shield className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                    <div>
                        <OrientingText className="text-[hsl(var(--color-intent))] font-bold">BRAND WARGAME</OrientingText>
                        <div className="text-[10px] text-neutral-500">Automated Compliance Auditor</div>
                    </div>
                </div>
                {!running && (
                    <Button onClick={runAudit} size="sm" className="bg-[hsl(var(--color-execution))] text-black hover:bg-[hsl(var(--color-execution))]/90">
                        <RefreshCw className="w-3 h-3 mr-2" /> 
                        {results ? "Re-Run Simulation" : "Initiate Audit"}
                    </Button>
                )}
            </div>

            {/* Content */}
            <div className="flex-1 p-6 overflow-y-auto">
                {running ? (
                    <div className="h-full flex flex-col items-center justify-center space-y-6">
                        <div className="relative w-32 h-32">
                            <svg className="w-full h-full" viewBox="0 0 100 100">
                                <circle cx="50" cy="50" r="45" fill="none" stroke="#333" strokeWidth="8" />
                                <circle 
                                    cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--color-intent))" strokeWidth="8" 
                                    strokeDasharray="283"
                                    strokeDashoffset={283 - (283 * progress / 100)}
                                    className="transition-all duration-300 ease-linear origin-center -rotate-90"
                                />
                            </svg>
                            <div className="absolute inset-0 flex items-center justify-center font-mono text-2xl font-bold text-white">
                                {progress}%
                            </div>
                        </div>
                        <div className="text-center space-y-2">
                            <h3 className="text-white font-bold animate-pulse">Scanning System Assets...</h3>
                            <p className="text-xs text-neutral-500 font-mono">
                                Checking pages/Lifestyle.js...<br/>
                                Analyzing components/ui/button.js...<br/>
                                Verifying entities/SystemConfig.json...
                            </p>
                        </div>
                    </div>
                ) : results ? (
                    <div className="space-y-6">
                        <div className="grid grid-cols-3 gap-4 mb-8">
                            <div className="p-4 bg-neutral-900 rounded border border-white/5 text-center">
                                <div className="text-xs text-neutral-500 mb-1">Overall Score</div>
                                <div className="text-3xl font-bold text-green-500">98%</div>
                            </div>
                            <div className="p-4 bg-neutral-900 rounded border border-white/5 text-center">
                                <div className="text-xs text-neutral-500 mb-1">Compliance Status</div>
                                <div className="text-xl font-bold text-white">COMPLIANT</div>
                            </div>
                            <div className="p-4 bg-neutral-900 rounded border border-white/5 text-center">
                                <div className="text-xs text-neutral-500 mb-1">Issues Found</div>
                                <div className="text-3xl font-bold text-green-500">0</div>
                            </div>
                        </div>

                        <div className="space-y-3">
                            {results.map(r => (
                                <div key={r.id} className="p-4 bg-neutral-900/30 border border-white/5 rounded flex items-center justify-between group hover:bg-neutral-900/50 transition-colors">
                                    <div className="flex items-center gap-4">
                                        {r.status === 'pass' && <CheckCircle2 className="w-5 h-5 text-green-500" />}
                                        {r.status === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-500" />}
                                        {r.status === 'fail' && <XCircle className="w-5 h-5 text-red-500" />}
                                        
                                        <div>
                                            <h4 className="text-sm font-bold text-white">{r.check}</h4>
                                            <p className="text-xs text-neutral-500">{r.details}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <div className="h-1.5 w-24 bg-neutral-800 rounded-full overflow-hidden">
                                            <div 
                                                className={`h-full rounded-full ${r.status === 'pass' ? 'bg-green-500' : r.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                                style={{ width: `${r.score}%` }}
                                            />
                                        </div>
                                        <span className="font-mono text-xs w-8 text-right">{r.score}%</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center opacity-50">
                        <Lock className="w-16 h-16 mb-4 text-neutral-700" />
                        <h3 className="text-lg font-bold text-neutral-300">Audit Ready</h3>
                        <p className="text-sm text-neutral-500 max-w-xs mt-2">
                            Initiate wargame simulation to verify brand compliance across all system nodes and interfaces.
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
}