# ZR1 TECHNICAL ROADMAP: AGENT ORCHESTRATION & MONITORING

**Target Architecture:** Hybrid ZR1 / XI-IO (Web UI + Local AI)
**Scope:** Extension of existing surfaces (Dashboard, WorkRoom, Nodes, Console) via MCP/Uplink.
**Status:** 🟢 BUILD PHASE (Deployment Locked 2025-12-18)

---

## PHASE 1: AI AGENT ORCHESTRATION LAYER
**Goal:** A unified control plane where the Web UI steers all agents (local + remote) and tasks flow cleanly.

### 1.1 Data Model & API
Extend the existing MCP/Agent schema.

**Agent Entity:**
- `id`, `name`, `role`, `capabilities[]`
- `location` (local, remote, cloud)
- `status` (idle, running, error, offline)

**Task Entity:**
- `id`, `type`, `source` (WorkRoom, DistroBuilder, ModelForge, etc.)
- `agentId` (optional for unassigned)
- `state` (queued, in_progress, done, failed)
- `createdAt`, `updatedAt`, `error?`

**API Surface (MCP / HTTP):**
- `GET /api/agents` – List all agents + health.
- `GET /api/tasks?status=` – List tasks by state.
- `POST /api/tasks` – Create new task (from WorkRoom, etc.).
- `POST /api/tasks/:id/assign` – Manual assignment.
- `WS /api/agent-events` – Stream task + agent status updates.

### 1.2 Orchestration Brain
Implement a lightweight **Agent Runner / Scheduler** service (in MCP/Uplink process):
1.  **Watch:** Tasks table / queue.
2.  **Match:** Choose agent based on `capabilities`, `location` (prefer local GPU), and `load`.
3.  **Dispatch:** Send work via MCP call, local CLI, or HTTP.
4.  **Emit:** Update DB (task state) and stream to `WS /agent-events`.

### 1.3 UI Integration
**Dashboard:**
- Extend `SystemStatusHero` input data: `activeAgents`, `activeTasks`, `failedTasksLast24h`.
- Add "Agent Swarm" `SystemStats` card: "X agents monitoring · Y tasks in flight".

**Agents Page:**
- Live list of agents + current tasks.
- Filters: `idle`, `running`, `error`.

**WorkRoom / DistroBuilder / ModelForge:**
- Replace direct actions with "Create Task" → `POST /api/tasks`.
- Show state transitions: `queued` → `in_progress` → `done` using `SystemLog` and `ProcessCompletion`.

---

## PHASE 2: INTELLIGENT DATA INGESTION
**Goal:** Normalize all node/agent emissions into a visible stream (Console, Nodes).

### 2.1 Ingestion Pipeline
**Node/Uplink Emission:**
- `metric`: `{ type: 'metric', nodeId, name, value, unit, timestamp }`
- `log`: `{ type: 'log', nodeId, level, message, context, timestamp }`
- `task_event`: `{ type: 'task_event', taskId, state, error?, timestamp }`

**Central Ingestion Service:**
- Accepts via `HTTP POST /api/events` (or message bus).
- Normalizes and writes to `Metrics`, `Logs`, and `TaskEvents` tables.

### 2.2 Feeding the UI
**Nodes Page:**
- Drive `SystemStats` from Metrics (CPU, RAM, Net, Latency).
- Drive `SystemTerminal` from Logs filtered by node.

**Console Page:**
- Unified `SystemLog` view subscribed to `WS /logs` (aggregated).

**Dashboard:**
- Feed `PerformanceWidget` from recent Metrics.
- Feed `GlobalFeedWidget` from recent Logs + TaskEvents.

---

## PHASE 3: PROACTIVE SYSTEM MONITORING
**Goal:** Real-time health visibility via Hero + Widgets.

### 3.1 Monitoring Rules
**Nominal:**
- Critical nodes online.
- Error rate < threshold.
- No tasks stuck `in_progress` > timeout.

**Degraded:**
- Redundancy active (some nodes offline).
- Error rate > threshold.
- Task backlog high.

**Attention Required:**
- CRITICAL alert from Agent Monitor.
- Primary node offline.
- Repeated task failures.

**Monitor Service:**
- Periodically compute `systemStatus`.
- Emit consolidated status object via `WS /system-status`:
  ```json
  {
    "status": "NOMINAL",
    "uptime": "12d 4h",
    "agentsMonitoring": 4,
    "consensus": "verified",
    "lastAnomaly": "2025-12-15T10:42:00Z"
  }
  ```

### 3.2 UI Updates
**SystemStatusHero:**
- Subscribe to `WS /system-status`.
- Map status to Hero state (NOMINAL/DEGRADED/ATTENTION).
- Display uptime and agent consensus.

**Agents / Monitor UI:**
- Show "Rules Fired" using `SystemLog` to explain Degraded/Attention states.

---

## PHASE 4: DESKTOP EXPERIENCE & DEVELOPER TOOLS (NEW)
**Goal:** Finalize and polish the user-facing OS simulation surfaces.

### 4.1 Desktop Environment (v2)
**Persistence Strategy:**
- Current: `localStorage` (Client-side only).
- Target: `UserXP` entity synchronization.
- **Action:** Create `POST /api/desktop/sync` to save layout JSON to user profile.

**Window Management:**
- Ensure `WindowFrame` state (min/max/focus) persists across reloads.
- Implement "Save Workspace" to DB (not just local).

### 4.2 Widget Ecosystem
**Registry Hardening:**
- Audit `WidgetRegistry.js` for missing error boundaries.
- Ensure all widgets handle "No Auth" states gracefully (e.g., Spotify Widget).

**New Widgets:**
- `DevPadWidget`: Quick access to npm scripts/build logs (from Phase 1).
- `HealthMonitorWidget`: Mini version of SystemStatusHero.

### 4.3 Component Forge
**Marketplace Pipeline:**
- Verify `PublishComponentModal` creates valid `MarketplaceItem` records.
- Implement `POST /api/marketplace/install` to actually "clone" code into user projects (or simulate it).
- Add "Version History" to Forge for local drafts.

---

## CURSOR INTEGRATION STRATEGY
Treat Cursor as the **Orchestrator** between MCP/Uplink and Frontend components.

**Assignments for Cursor:**
1.  **Agent Orchestration:** Implement API endpoints (`/api/agents`, `/api/tasks`) and update WorkRoom/Agents page.
2.  **Ingestion Plumbing:** Implement `/api/events` and wire Nodes/Console to read from it.
3.  **Monitoring Loop:** Implement the Monitor service and wire `SystemStatusHero` to the WebSocket stream.
4.  **Desktop Persistence:** Wire Desktop State to UserXP entity.

**Constraints:**
- "No new UI paradigms; only extend existing `SystemComponents` & `SystemContent`."
- **Stop Condition:** When Hero, Nodes, Console, Agents, AND Desktop are wired to real data and `npm run build` passes.