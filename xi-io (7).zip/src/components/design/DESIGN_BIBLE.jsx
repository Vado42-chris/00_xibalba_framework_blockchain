# XI-IO DESIGN BIBLE

**Version**: 1.0  
**Status**: Locked for v1  
**Audience**: Designers, Engineers, Writers, AI Systems  
**Principle**: Cognitive physics over visual decoration  

---

## PART I — SYSTEM PHILOSOPHY

### 1.1 What XI-IO Is
XI-IO is not a dashboard.  
It is an instrument.  

It does not ask users to interpret data.  
It states truth, provides evidence, and offers context only when invited.

### 1.2 The Prime Directive
**Reduce cognitive drag without reducing system precision.**

Every design decision must satisfy:
- Precision is preserved
- Anxiety is reduced
- Optionality is controlled

If a feature increases ambiguity, it is rejected.

---

## PART II — INFORMATION HIERARCHY

### 2.1 The Three-Layer Model

| Layer | Role | Interaction |
|-------|------|-------------|
| **Truth Layer (Hero)** | One declarative system statement | Calm, authoritative, non-interactive |
| **Evidence Layer (Widgets)** | Supporting metrics | Verifies the truth, never competes with it |
| **Context Layer (Feeds / Logs)** | Exploratory | Never required to understand system state |

This hierarchy is invariant across views.

---

## PART III — THE HERO (TRUTH LAYER)

### 3.1 Definition
The Hero is a statement, not a control.  
It answers: **“What is the system telling me right now?”**

### 3.2 Hero State Formula
Every Hero must express:  
`STATE` + `TIME` + `VERIFICATION`

*Example:*  
> **Empire Nominal**  
> Nominal for 12d 4h  
> 4 agents monitoring · consensus verified

### 3.3 Locked Hero Status Vocabulary (v1)

| Status | Operator | Plain Speak | User Action |
|--------|----------|-------------|-------------|
| **NOMINAL** | Empire Nominal | Everything’s running smoothly | None |
| **DEGRADED** | Degraded (Non-Critical) | Some systems are slowed | None |
| **ATTENTION** | Attention Required | Something needs review | Optional |
| **OFFLINE** | Disconnected | System is offline | Required |
| **INITIALIZING** | Initializing | Getting things ready | None |

**Rule**: No additional Hero statuses are permitted in v1.

### 3.4 Hero Constraints
- Not clickable
- Not configurable
- Not dismissible
- Never scrolls out of view before evidence loads

---

## PART IV — TRUST SIGNALING

### 4.1 Continuity Indicators
Trust is built by time-in-state, not detail.

**Required**:
- “Nominal for X”
- Last sync timestamp

**Optional**:
- “Last anomaly resolved automatically”

### 4.2 Agent Consensus Indicators
Agents are expressed as outcomes, not personalities.

**Allowed**:
- “X agents monitoring”
- “Consensus verified”
- “Alignment stable”

**Disallowed**:
- Agent names
- Agent chatter
- Agent disagreement unless critical

---

## PART V — FAILURE STATES (MANDATORY)

### 5.1 Required Failure Scenarios (v1 only)
1. Partial sync / stale data
2. Agent disagreement
3. Full disconnect

### 5.2 Failure Hero Rules
- Calm language
- Explicit guidance
- Clear agency boundary

*Example:*
> **System Speak**: AGENT DISAGREEMENT DETECTED  
> **Plain Speak**: Some monitors disagree on system status. No action is required yet.

### 5.3 Failure Design Rule
If the Hero can fail gracefully, the system is considered complete.

---

## PART VI — THE TRANSLATOR LAYER (ROSETTA STONE)

### 6.1 Purpose
The Rosetta Stone is a semantic physics engine, not localization.  
It:
- Decodes system language into human meaning
- Encodes human intent back into system logic

It is part of the state layer, not decoration.

---

## APPENDIX E — THE ROSETTA STONE & LANGUAGE LAYER

### E.1 LanguageProvider (LanguageContext.js)

**Modes**:
- System Speak (default)
- Plain Speak
- Gen Z (future)

**Physics**:
- Language changes presentation only
- State is never altered
- Preference stored locally

### E.2 RosettaStone (RosettaStone.js)

**Trigger**: Hover only  
**Interaction**: Never click, Never modal  
**Dismissal**: Auto-dismiss on intent change

**Three-Layer Structure**:
| Layer | Example |
|-------|---------|
| System | DEPLOY |
| Plain | Publish your site |
| Gen Z | Yeet it |

### E.3 Explainable (Explainable.js)
Semantic wrapper for any term.

```jsx
<Explainable technical="DEPLOY" plain="PUBLISH SITE" genz="YEET IT">
  <Button>DEPLOY</Button>
</Explainable>
```

### E.4 Visual Design Rules
- Max width: **300px**
- Soft shadow
- Off-white background
- Fade + 10px rise (200ms, linear)

---

## PART VII — CATEGORY-BASED LANGUAGE

### 7.1 Category Physics
Translations are metaphor-aligned, not stylistic.  
If no category translation exists: → **Fallback to Plain Speak**.

### 7.2 Example Mapping
| Term | Lawyer | Developer | Designer |
|------|--------|-----------|----------|
| **DEPLOY** | Execute Filing | Push to Production | Launch Site |
| **SYNC** | Validate Consistency | Pull Latest | Backup Assets |

---

## PART VIII — AI & CODE ASSISTANCE INTEGRATION

### 8.1 Language-Aware AI Rules
- All AI output must respect `LanguageContext`
- Errors must include Rosetta explanations
- Comments must include human summaries

---

## PART IX — COMPLETION & SUCCESS STATES

### 9.1 Completion Rules
- Plain Speak is default
- System Speak is optional
- Rosetta always available

```jsx
<CompletionState status="success">
  <Explainable technical="DEPLOYED" plain="LIVE">
    <p>Your site is now live.</p>
  </Explainable>
</CompletionState>
```

---

## PART X — ONBOARDING (MANDATORY)

### 10.1 Onboarding Sequence
1. **Language Demo**: DEPLOY → PUBLISH SITE → YEET IT
2. **Category Selection**: Sets translation priority
3. **Rosetta Demo**: Hover to explain (“You never need to memorize jargon.”)

---

## PART XI — MOBILE CONSTRAINT

### 11.1 Mobile Rule (Single Constraint)
On mobile, the Hero is the only guaranteed element above the fold.
- Hero stacks vertically
- Agent line collapses to icon
- Widgets scroll unchanged
- No mobile-specific redesigns permitted.

---

## PART XII — V1 LOCK SPEC

### 12.1 Frozen for v1
- Hero statuses
- Translator mechanics
- Trust signaling patterns
- Language modes (2 only)

### 12.2 Explicitly Deferred
- Gen Z mode
- Additional categories
- Custom Hero configuration
- User-authored translations

---

## FINAL DECLARATION

**XI-IO v1 is complete when:**
1. Truth is immediate
2. Failure is calm
3. Language never blocks understanding

If the system can restart cold, fail cleanly, and explain itself without instruction, it is done.

**END OF DOCUMENT**