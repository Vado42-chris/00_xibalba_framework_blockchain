1: # ZR1 INTERFACE: DEPLOYMENT & INTEGRATION MANUAL
   2: 
   3: **Date:** 2025-12-15
   4: **System Version:** ZR1 (V2.4.1)
   5: **Architecture:** React / Vite / Base44 Hybrid Cloud
   6: **Target:** Local Workstation & Custom Web Server ("Domains at Cost")
   7: 
   8: ---
   9: 
  10: ## 1. MISSION BRIEFING
  11: This manual describes how to pilot the ZR1 Interface—a high-performance "Corvette" UI built on React and Tailwind—and deploy it to a live web server while tethering it to your local high-power AI infrastructure.
  12: 
  13: **Core Objective:** Host the UI on the web ("Spaceship Bridge") but run the heavy compute/AI on your local machines ("Engine Room").
  14: 
  15: ---
  16: 
  17: ## 2. INSTALLATION PROTOCOLS
  18: 
  19: ### A. Local Cockpit Setup (Development)
  20: To run this interface locally for development or as a local control deck:
  21: 
  22: 1.  **Extract:** Unzip the project archive to your local workspace.
  23: 2.  **Initialize:** Open your terminal in the project root.
  24:     ```bash
  25:     npm install
  26:     ```
  27: 3.  **Ignition:** Start the development server.
  28:     ```bash
  29:     npm run dev
  30:     ```
  31: 4.  **Access:** Open `http://localhost:5173` to view the ZR1 Dashboard.
  32: 
  33: ### B. Live Web Server Deployment (Production)
  34: To host the "Spaceship" UI on your domains at cost server:
  35: 
  36: 1.  **Build Sequence:** Compile the static assets.
  37:     ```bash
  38:     npm run build
  39:     ```
  40:     *This creates a `dist/` directory containing the optimized `index.html`, CSS, and JS files.*
  41: 
  42: 2.  **Deploy:** Upload the contents of the `dist/` folder to the `public_html` or root directory of your web server (Apache/Nginx).
  43: 
  44: 3.  **Server Config (Important):** Since this is a Single Page App (SPA) using client-side routing, you must configure your web server to redirect 404s to `index.html`.
  45:     *   **Apache (.htaccess):**
  46:         ```apache
  47:         RewriteEngine On
  48:         RewriteBase /
  49:         RewriteRule ^index\.html$ - [L]
  50:         RewriteCond %{REQUEST_FILENAME} !-f
  51:         RewriteCond %{REQUEST_FILENAME} !-d
  52:         RewriteRule . /index.html [L]
  53:         ```
  54:     *   **Nginx:**
  55:         ```nginx
  56:         location / {
  57:           try_files $uri $uri/ /index.html;
  58:         }
  59:         ```
  60: 
  61: ---
  62: 
  63: ## 3. THE "SPACESHIP" ARCHITECTURE (Hybrid AI Integration)
  64: 
  65: To use your "Incredible" local AI models with the web-hosted UI, we implement a **Telepresence Link**.
  66: 
  67: ### The Concept
  68: *   **The Bridge (Web UI):** Hosting on your domain. Displays status, accepts commands, visualizes data.
  69: *   **The Engine (Your PC):** Runs your local LLMs (Ollama, LM Studio, etc.) and Sprint Systems.
  70: *   **The Uplink (Base44):** The communication layer connecting them.
  71: 
  72: ### Integration Steps
  73: 
  74: #### Step 1: Define Your Nodes
  75: In the ZR1 `Console` or `Nodes` page, verify your local machines are registered as `Node` entities.
  76: *   **Node Type:** `CORE` (Your main PC)
  77: *   **Status:** `CONNECTED` (Managed by the uplink)
  78: 
  79: #### Step 2: The Uplink Script (Running Locally)
  80: On your local machine (The "Corvette"), run a simple script that polls the Base44 backend for new tasks or "Agent" requests.
  81: 
  82: *Example (Node.js script on your local machine):*
  83: ```javascript
  84: // Local Uplink Script
  85: import { createClient } from '@base44/sdk'; 
  86: 
  87: // 1. Listen for new "AgentTask" entities created by the Web UI
  88: // 2. When a task arrives (e.g., "Generate 3D Model"), grab it.
  89: // 3. Pass it to your local Python/AI script.
  90: // 4. Update the "AgentTask" with the result.
  91: ```
  92: 
  93: #### Step 3: Direct API Tunneling (Optional)
  94: If you want the Web UI to talk *directly* to your local AI without polling:
  95: 1.  Run your local AI API (e.g., Ollama on port 11434).
  96: 2.  Use a tunnel like `ngrok` to expose it: `ngrok http 11434`.
  97: 3.  In the ZR1 **Settings > Intelligence**, add a new Model with the ngrok URL as the endpoint.
  98: 4.  The Web UI now sends prompts directly to your local engine.
  99: 
 100: ---
 101: 
 102: ## 4. EXTERNAL INTEGRATIONS (Cloud Layer)
 103: 
 104: This system supports direct integration with cloud providers via Base44 App Connectors.
 105: 
 106: ### Supported Services
 107: *   **Google Calendar & Drive:** For scheduling and file management.
 108: *   **Slack:** For team communication and notifications.
 109: *   **Salesforce:** For CRM and lead management.
 110: 
 111: ### How to Connect
 112: 1.  Navigate to the **Integration Dashboard**.
 113: 2.  Look for the "Active Connectors" panel.
 114: 3.  If a service is offline, you must authorize it.
 115: 4.  **Method:** Ask the AI Assistant: "Connect [Service Name]" (e.g., "Connect Slack").
 116: 5.  Follow the OAuth popup instructions.
 117: 
 118: ### AI Agent Usage
 119: Once connected, the `IntegrationAgent` will automatically gain capabilities to use these services.
 120: *   Example: "Schedule a meeting with John tomorrow at 2pm" -> Calls Google Calendar API.
 121: 
 122: ---
 123: 
 124: ## 5. CURSOR & AI INSTRUCTIONS (Protecting the UI)
 125: 
 126: **CRITICAL INSTRUCTION FOR CURSOR / AI DEV:**
 127: *Copy and paste the following block into your Cursor "Rules for AI" or system prompt to ensure future edits do not degrade the ZR1 Interface.*
 128: 
 129: ***
 130: 
 131: ### 🛑 ZR1 INTERFACE: IMMUTABLE INVARIANTS 🛑
 132: **DO NOT MODIFY THE UI ARCHITECTURE WITHOUT AUTHORIZATION.**
 133: 
 134: This project uses a specialized "Web-Native Operating System" design language. All contributions must adhere to these strict physics:
 135: 
 136: **1. The Rosetta Stone Rule (Accessibility)**
 137: *   **NEVER** use naked text for technical terms.
 138: *   **ALWAYS** use the `Explainable` component.
 139:     *   *Bad:* `<div>System Online</div>`
 140:     *   *Good:* `<Explainable technical="SYSTEM ONLINE" human="All Systems Go" />`
 141: *   **ALWAYS** wrap operational text in `OrientingText` (labels), `IntentText` (headlines), or `StateText` (data).
 142: 
 143: **2. Quadrant Physics (Layout)**
 144: *   The screen is **ALWAYS** divided using `FluidGrid` and `QuadrantGrid`.
 145: *   **Quadrant 1 (Top-Left):** Orientation (Who/Where am I?).
 146: *   **Quadrant 2 (Top-Right):** Intent (What am I doing? Controls).
 147: *   **Quadrant 3 (Bottom-Left):** State (History/Logs).
 148: *   **Quadrant 4 (Bottom-Right):** Outcome (Results/Rewards).
 149: *   *Do not create "standard" scrolling web pages. Create Dashboards.*
 150: 
 151: **3. The Hero Invariant**
 152: *   Every Dashboard **MUST** have a `SystemStatusHero` or equivalent high-level status indicator at the top of the data flow.
 153: 
 154: **4. Component Hierarchy**
 155: *   Use `SystemCard`, `SystemNav`, and `SystemTerminal` from `@/components/ui/design-system/...`.
 156: *   Do not introduce generic Bootstrap/Material UI components.
 157: 
 158: ***
 159: 
 160: ## 6. STATUS REPORT: WORK COMPLETED & ROADMAP
 161: 
 162: ### ✅ Systems Online (Completed)
 163: *   **Core UI Framework:** FluidGrid, Quadrant Physics, DepthBackground installed.
 164: *   **Command Console:** Fully functional CLI with `SystemTerminal`.
 165: *   **WorkRoom:** Integrated IDE-like environment with simulated terminal.
 166: *   **Deployment Systems:** Smart-Ship Modal with `Explainable` integration.
 167: *   **Network Visualization:** Node status monitoring system.
 168: *   **Integrations:** Cloud connectors active for major providers.
 169: 
 170: ### 🛠 Engineering Required (To Do)
 171: 1.  **Local Uplink Script:** Write the Node.js/Python script to run on your local machine that bridges `entities/AgentTask` to your local AI models.
 172: 2.  **Sprint System Sync:** Connect your existing sprint data source to the `Task` entity API to populate the "WorkRoom".
 173: 3.  **Real-Time Sockets:** Upgrade the polling mechanism to WebSockets for instant "Spaceship" response times (requires Base44 Realtime or custom socket server).
 174: 
 175: ---
 176: *End of Report. Proceed with deployment.*