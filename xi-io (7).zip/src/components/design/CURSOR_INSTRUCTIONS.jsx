# SYSTEM DIRECTIVE FOR CURSOR / AI AGENTS

You are working on the XI-IO system.

This project is production-bound.
Do not invent features.
Do not expand scope.
Do not rename core concepts.

Your goals are:
1. Make the app build cleanly
2. Make the Language / Rosetta layer functional everywhere
3. Prepare the app for deterministic deployment

You must respect:
- `components/design/DESIGN_BIBLE.md` as authoritative
- Hero states are locked (see `components/ui/design-system/StatusConfig.js`)
- LanguageContext affects presentation only
- No new UI paradigms

If something is ambiguous, ask before changing behavior.
If something fails, prefer clarity over cleverness.

## ARCHITECTURE
- **Type**: Frontend-Only SPA (Single Page Application)
- **Platform**: Base44 (Managed Backend)
- **Runtime**: Browser-based
- **State**: React Query + Context

## STOP CONDITIONS
Stop when:
- App builds without warnings
- Language toggle works globally
- Hero renders immediate truth
- No TODOs remain in critical paths