# ZR1 SPRINT BLUEPRINT: INTELLIGENCE EXTENSIONS

**Target:** Next Deployment Sprint
**Dependencies:** `TECHNICAL_ROADMAP.md` Phase 1-3
**Executor:** Cursor (via Uplink/Frontend modifications)

---

## EXTENSION 1: AUTOMATED TASK GENERATION
**Objective:** Decouple task creation from user input. Allow the system to self-assign work based on triggers.

### 1. Architecture
- **Entity:** `TriggerRule`
  - `condition`: JSON logic (e.g., `{ "metric": "cpu", "operator": ">", "value": 90 }`)
  - `action`: Task Template (e.g., `{ "type": "scale_nodes", "params": {...} }`)
  - `cooldown`: Minutes between firing.
- **Service:** `TaskGenerator` (Running in Local Uplink)
  - Evaluates `TriggerRules` against incoming `Metrics`.
  - Emits `POST /api/tasks` when conditions are met.

### 2. Implementation Specs

#### Backend (Uplink/MCP)
*Endpoint:* `POST /api/rules` (CRUD for rules)
*Loop:* `evaluateTriggers()` runs every 10s or on Metric ingress.

#### Frontend Components
*Target:* `pages/Automation.js`
*New Component:* `TriggerBuilder`
- **Location:** Quadrant 2 (Intent)
- **UI:** Form to define "If [Metric] [Operator] [Value] Then [Create Task]".
- **Invariant:** Use `<Explainable>` for logic operators (e.g., ">" -> "Exceeds").

#### Cursor Prompt / Assignment
> "Implement the TriggerRule entity and a basic evaluation engine in the local uplink script. Then, create the `TriggerBuilder` component in `pages/Automation.js` allowing users to define simple CPU/Memory thresholds that auto-create 'Analyze Node' tasks."

---

## EXTENSION 2: REAL-TIME SYSTEM HEALTH
**Objective:** Millisecond-latency visibility for the "Spaceship" bridge.

### 1. Architecture
- **Protocol:** WebSocket (`wss://...`) or High-Frequency Polling (Fallback).
- **Stream:** `/telemetry`
- **Payload:**
  ```json
  {
    "t": 17189234,
    "h": "NOMINAL", // Health Status
    "bpm": 120, // Activity Metric
    "agents": { "active": 3, "idle": 1 },
    "alerts": []
  }
  ```

### 2. Implementation Specs

#### Frontend Hook
*File:* `components/nodes/useSystemPulse.js`
- Manages the WS connection.
- **Debounce:** Updates React state max 10 times/sec to prevent render thrashing.
- **Fallback:** Auto-switches to HTTP polling (2s interval) if WS fails.

#### Component Updates
*Target:* `components/dashboards/widgets/SystemStatusHero.js`
- **Refactor:** Remove mock data.
- **Prop:** Accept `telemetry` object from `useSystemPulse`.
- **Visuals:** Pulse animation speed synced to `telemetry.bpm` (activity level).

#### Cursor Prompt / Assignment
> "Create `useSystemPulse` hook that connects to the local uplink's websocket. Refactor `SystemStatusHero` to consume this real-time context instead of static props. Ensure the heartbeat animation CSS duration matches the incoming 'bpm' value."

---

## EXTENSION 3: INTELLIGENT NODE DIAGNOSTICS
**Objective:** Automated root cause analysis displayed in the Console.

### 1. Architecture
- **Analysis Engine:** "Diagnostic Cortex" (Python/Node module in Uplink).
- **Logic:** Statistical Anomaly Detection (Z-Score on simple metrics).
- **Output:** `SystemAlert` entities.

### 2. Implementation Specs

#### Backend (Uplink/MCP)
*Function:* `detectAnomalies(metricHistory)`
- If `cpu_load` > 2 std_dev from moving average → Emit Alert.
- If `task_queue` growing && `completed_tasks` flat → Emit "Stall Detected".

#### Frontend Components
*Target:* `pages/Console.js`
*New Component:* `DiagnosticStream`
- **Location:** Quadrant 3 (State) - Replaces/Augments standard Log.
- **UI:** Filtered view of `SystemLog` showing only `WARN`/`ERROR` with AI-generated "Fix Suggestions".
- **Invariant:** Fix suggestions must be wrapped in `<Explainable human="Try restarting the node">sudo reboot</Explainable>`.

#### Cursor Prompt / Assignment
> "Implement a simple Z-score anomaly detector in the uplink. When an anomaly is found, inject a high-priority log entry. Update `pages/Console.js` to highlight these diagnostic logs in the State quadrant, adding a 'Run Fix' button that maps to a `POST /api/tasks` repair command."