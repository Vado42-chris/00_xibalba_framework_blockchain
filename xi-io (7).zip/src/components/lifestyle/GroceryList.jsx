import React from 'react';
import { 
    ShoppingBag, Check, Plus, Trash2, 
    RefreshCw, Utensils
} from 'lucide-react';
import { IntentText } from '@/components/ui/design-system/SystemDesign';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

export default function GroceryList() {
    const queryClient = useQueryClient();

    const { data: items = [], isLoading } = useQuery({
        queryKey: ['groceries'],
        queryFn: () => base44.entities.Task.list(), // Using Task entity for demo, filtered by category ideally
        select: (data) => data.filter(t => t.category === 'groceries').slice(0, 10)
    });

    const toggleItem = useMutation({
        mutationFn: (item) => base44.entities.Task.update(item.id, { 
            status: item.status === 'completed' ? 'pending' : 'completed' 
        }),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ['groceries'] })
    });

    const addItem = useMutation({
        mutationFn: (text) => base44.entities.Task.create({ 
            title: text, 
            category: 'groceries',
            status: 'pending',
            project_id: 'lifestyle-default' // Required by schema
        }),
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ['groceries'] })
    });

    const [input, setInput] = React.useState('');

    return (
        <div className="h-full flex flex-col">
            <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-[hsl(var(--color-warning))]" />
                    <IntentText className="font-bold">INVENTORY</IntentText>
                </div>
                <div className="text-[10px] text-neutral-500">
                    {items.filter(i => i.status === 'completed').length}/{items.length} Fulfilled
                </div>
            </div>

            <ScrollArea className="flex-1 -mx-2 px-2">
                <div className="space-y-1">
                    {items.map((item) => (
                        <div 
                            key={item.id}
                            onClick={() => toggleItem.mutate(item)}
                            className={cn(
                                "flex items-center gap-3 p-2 rounded cursor-pointer group transition-colors",
                                item.status === 'completed' ? "opacity-50 hover:opacity-80" : "hover:bg-white/5"
                            )}
                        >
                            <div className={cn(
                                "w-4 h-4 rounded-full border flex items-center justify-center transition-colors",
                                item.status === 'completed' 
                                    ? "bg-[hsl(var(--color-execution))] border-transparent text-black" 
                                    : "border-white/20 group-hover:border-white/50"
                            )}>
                                {item.status === 'completed' && <Check className="w-3 h-3" />}
                            </div>
                            <span className={cn(
                                "text-sm flex-1",
                                item.status === 'completed' && "line-through"
                            )}>{item.title}</span>
                        </div>
                    ))}
                    {items.length === 0 && (
                        <div className="text-center py-8 text-neutral-600 text-xs italic">
                            Fridge is fully stocked
                        </div>
                    )}
                </div>
            </ScrollArea>

            <form 
                onSubmit={(e) => {
                    e.preventDefault();
                    if (input.trim()) {
                        addItem.mutate(input);
                        setInput('');
                    }
                }}
                className="mt-4 flex gap-2"
            >
                <input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Add item..." 
                    className="flex-1 bg-neutral-900 border border-white/10 rounded px-3 py-1.5 text-xs text-white focus:border-[hsl(var(--color-warning))] outline-none"
                />
                <Button type="submit" size="sm" variant="ghost" className="h-full bg-white/5 hover:bg-white/10">
                    <Plus className="w-4 h-4" />
                </Button>
            </form>
        </div>
    );
}