import React from 'react';
import { 
    LayoutGrid, Bell, User, Settings, 
    Plus, Search, Menu
} from 'lucide-react';
import { OrientingText, IntentText } from '@/components/ui/design-system/System';
import DailyDeck from '@/components/lifestyle/DailyDeck';
import LevelProgress from '@/components/lifestyle/LevelProgress';
import { Button } from "@/components/ui/button";

export default function MobileCompanion() {
    return (
        <div className="h-full flex flex-col bg-black">
            {/* Mobile Header */}
            <div className="flex justify-between items-center p-4 border-b border-white/10 bg-neutral-900/50 backdrop-blur-md sticky top-0 z-50">
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-gradient-to-br from-[hsl(var(--color-execution))] to-emerald-700 flex items-center justify-center shadow-lg shadow-emerald-900/20">
                        <LayoutGrid className="w-4 h-4 text-white" />
                    </div>
                    <div>
                        <OrientingText className="text-[10px] tracking-widest text-[hsl(var(--color-execution))]">LIFE OS</OrientingText>
                        <IntentText className="font-bold text-white leading-none">Companion</IntentText>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <Button size="icon" variant="ghost" className="w-8 h-8 text-neutral-400">
                        <Bell className="w-4 h-4" />
                    </Button>
                    <div className="w-8 h-8 rounded-full bg-neutral-800 border border-white/10 flex items-center justify-center overflow-hidden">
                        <User className="w-4 h-4 text-neutral-500" />
                    </div>
                </div>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
                
                {/* Gamification Widget */}
                <div className="bg-neutral-900/30 rounded-xl border border-white/5 p-4">
                    <div className="flex justify-between items-start mb-2">
                        <OrientingText>CURRENT STATUS</OrientingText>
                        <div className="px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-[9px] text-amber-500 font-bold uppercase tracking-wider animate-pulse">
                            Active
                        </div>
                    </div>
                    <LevelProgress className="w-full items-start" />
                </div>

                {/* Daily Deck (The Core Action Center) */}
                <div className="min-h-[400px]">
                    <DailyDeck />
                </div>

                {/* Critical Alerts (Simplified) */}
                <div className="space-y-3">
                    <OrientingText>PRIORITY ALERTS</OrientingText>
                    <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                        <span className="text-xs text-red-200">Recovery Score Low (32%) - Take it easy today.</span>
                    </div>
                </div>
            </div>

            {/* Bottom Nav Bar */}
            <div className="h-16 border-t border-white/10 bg-neutral-950 flex items-center justify-around px-2 pb-safe">
                <NavIcon icon={LayoutGrid} label="Home" active />
                <NavIcon icon={Search} label="Find" />
                <div className="w-12 h-12 rounded-full bg-[hsl(var(--color-execution))] flex items-center justify-center -mt-6 shadow-lg shadow-emerald-500/20 border-4 border-black">
                    <Plus className="w-6 h-6 text-black" />
                </div>
                <NavIcon icon={Bell} label="Alerts" />
                <NavIcon icon={Menu} label="Menu" />
            </div>
        </div>
    );
}

const NavIcon = ({ icon: Icon, label, active }) => (
    <div className={`flex flex-col items-center gap-1 p-2 ${active ? 'text-[hsl(var(--color-execution))]' : 'text-neutral-500'}`}>
        <Icon className="w-5 h-5" />
        <span className="text-[9px] font-medium">{label}</span>
    </div>
);