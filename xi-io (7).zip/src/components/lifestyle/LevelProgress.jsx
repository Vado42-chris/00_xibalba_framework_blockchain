import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Trophy, Star, Flame, Crown, 
    ChevronRight, Zap 
} from 'lucide-react';
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

export default function LevelProgress({ className }) {
    const { data: userXP } = useQuery({
        queryKey: ['user_xp'],
        queryFn: async () => {
            const user = await base44.auth.me().catch(() => ({ email: 'demo@user.com' }));
            const records = await base44.entities.UserXP.filter({ user_email: user.email });
            return records[0] || { xp: 0, level: 1, daily_streak: 0 };
        }
    });

    const xp = userXP?.xp || 0;
    const level = Math.floor(xp / 1000) + 1;
    const nextLevelXP = level * 1000;
    const currentLevelXP = (level - 1) * 1000;
    const progress = ((xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100;
    const streak = userXP?.daily_streak || 0;

    return (
        <div className={cn("flex flex-col items-end min-w-[200px]", className)}>
            <div className="flex items-center gap-3 mb-1">
                <div className="flex flex-col items-end">
                    <div className="flex items-center gap-1.5">
                        <Trophy className="w-3 h-3 text-amber-500" />
                        <IntentText className="font-bold text-amber-500 text-sm">LEVEL {level}</IntentText>
                    </div>
                    <StateText className="text-[9px] opacity-50 font-mono">
                        {xp.toLocaleString()} / {nextLevelXP.toLocaleString()} XP
                    </StateText>
                </div>
                
                {/* Avatar / Rank Icon */}
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-500/20 to-amber-900/20 border border-amber-500/30 flex items-center justify-center relative group">
                    <Crown className="w-5 h-5 text-amber-500" />
                    {/* Streak Badge */}
                    {streak > 0 && (
                        <div className="absolute -bottom-1 -right-1 bg-neutral-950 rounded-full p-0.5 border border-neutral-800">
                            <div className="bg-orange-500 text-black text-[8px] font-bold px-1 rounded-full flex items-center gap-0.5">
                                <Flame className="w-2 h-2 fill-current" /> {streak}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* XP Bar */}
            <div className="w-full max-w-[180px] h-1.5 bg-neutral-900 rounded-full overflow-hidden border border-white/5 relative mt-1">
                <div 
                    className="absolute top-0 left-0 h-full bg-gradient-to-r from-amber-600 to-amber-400 transition-all duration-1000 ease-out"
                    style={{ width: `${progress}%` }}
                />
                <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(255,255,255,0.1)_50%,transparent_100%)] w-full h-full animate-[shimmer_2s_infinite]" />
            </div>
            
            <div className="flex justify-between w-full max-w-[180px] mt-1">
                <span className="text-[8px] text-neutral-600 font-mono">NOVICE</span>
                <span className="text-[8px] text-neutral-600 font-mono">MASTER</span>
            </div>
        </div>
    );
}