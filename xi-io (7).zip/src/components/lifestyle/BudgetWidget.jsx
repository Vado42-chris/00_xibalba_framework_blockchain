import React, { useState } from 'react';
import { 
    Wallet, TrendingDown, TrendingUp, PieChart, 
    CreditCard, DollarSign, AlertCircle
} from 'lucide-react';
import { IntentText, StateText, ChartFrame } from '@/components/ui/design-system/SystemDesign';
import { ProgressLattice } from '@/components/ui/design-system/Infographics';
import { Button } from "@/components/ui/button";

export default function BudgetWidget() {
    return (
        <div className="h-full flex flex-col gap-4">
            <div className="flex justify-between items-start">
                <div>
                    <div className="flex items-center gap-2 text-neutral-400 mb-1">
                        <Wallet className="w-4 h-4" />
                        <span className="text-xs uppercase tracking-widest font-bold">Monthly Budget</span>
                    </div>
                    <div className="text-2xl font-light text-white flex items-baseline gap-1">
                        $4,250 <span className="text-xs text-neutral-500">/ $5,000</span>
                    </div>
                </div>
                <div className="flex flex-col items-end">
                    <span className="text-[10px] text-[hsl(var(--color-execution))] flex items-center gap-1 bg-[hsl(var(--color-execution))]/10 px-2 py-0.5 rounded-full">
                        <TrendingDown className="w-3 h-3" /> 12% under
                    </span>
                </div>
            </div>

            <div className="h-2 bg-neutral-900 rounded-full overflow-hidden border border-white/5">
                <div className="h-full bg-[hsl(var(--color-execution))]" style={{ width: '65%' }} />
                <div className="h-full bg-[hsl(var(--color-warning))]" style={{ width: '20%' }} />
            </div>

            <div className="grid grid-cols-2 gap-3 flex-1">
                <div className="bg-neutral-900/50 p-3 rounded border border-white/5 flex flex-col justify-between">
                    <span className="text-[10px] text-neutral-500 uppercase">Groceries</span>
                    <div className="flex justify-between items-end">
                        <span className="text-lg text-white">$650</span>
                        <div className="text-[10px] text-red-400 flex items-center"><AlertCircle className="w-3 h-3 mr-1"/> Over</div>
                    </div>
                </div>
                <div className="bg-neutral-900/50 p-3 rounded border border-white/5 flex flex-col justify-between">
                    <span className="text-[10px] text-neutral-500 uppercase">Utilities</span>
                    <div className="flex justify-between items-end">
                        <span className="text-lg text-white">$240</span>
                        <div className="text-[10px] text-[hsl(var(--color-execution))]">On Track</div>
                    </div>
                </div>
            </div>

            <div className="pt-2 border-t border-white/5 flex gap-2">
                <Button variant="ghost" size="sm" className="flex-1 text-[10px] h-7 bg-white/5">
                    <CreditCard className="w-3 h-3 mr-2" /> Recent Tx
                </Button>
                <Button variant="ghost" size="sm" className="flex-1 text-[10px] h-7 bg-white/5">
                    <PieChart className="w-3 h-3 mr-2" /> Analytics
                </Button>
            </div>
        </div>
    );
}