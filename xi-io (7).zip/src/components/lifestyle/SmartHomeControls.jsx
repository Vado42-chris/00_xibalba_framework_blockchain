import React, { useState } from 'react';
import { 
    Home, Thermometer, Wind, Lock, 
    Lightbulb, Music, Power, Play, Pause,
    SkipForward, Volume2
} from 'lucide-react';
import { IntentText, StateText } from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Slider } from "@/components/ui/slider";

const SceneButton = ({ icon: Icon, label, active, onClick }) => (
    <button 
        onClick={onClick}
        className={cn(
            "flex flex-col items-center justify-center gap-2 p-3 rounded-lg border transition-all",
            active 
                ? "bg-[hsl(var(--color-intent))] border-[hsl(var(--color-intent))] text-white shadow-lg shadow-[hsl(var(--color-intent))]/20" 
                : "bg-neutral-900 border-white/5 text-neutral-400 hover:border-white/20 hover:text-white"
        )}
    >
        <Icon className="w-5 h-5" />
        <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
    </button>
);

export default function SmartHomeControls() {
    const [activeScene, setActiveScene] = useState('evening');
    const [isPlaying, setIsPlaying] = useState(false);

    return (
        <div className="h-full flex flex-col gap-6">
            {/* Header */}
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Home className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <IntentText className="font-bold">HOME AUTOMATION</IntentText>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono text-neutral-400">
                    <span className="flex items-center gap-1"><Thermometer className="w-3 h-3"/> 72°</span>
                    <span className="flex items-center gap-1"><Wind className="w-3 h-3"/> 45%</span>
                    <span className="flex items-center gap-1 text-[hsl(var(--color-execution))]"><Lock className="w-3 h-3"/> SECURE</span>
                </div>
            </div>

            {/* Scenes Grid */}
            <div className="grid grid-cols-4 gap-3">
                <SceneButton icon={Lightbulb} label="Focus" active={activeScene === 'focus'} onClick={() => setActiveScene('focus')} />
                <SceneButton icon={Music} label="Relax" active={activeScene === 'relax'} onClick={() => setActiveScene('relax')} />
                <SceneButton icon={Power} label="Sleep" active={activeScene === 'sleep'} onClick={() => setActiveScene('sleep')} />
                <SceneButton icon={Play} label="Cinema" active={activeScene === 'cinema'} onClick={() => setActiveScene('cinema')} />
            </div>

            {/* Media Player */}
            <div className="bg-neutral-900/50 border border-white/5 rounded-lg p-4 flex items-center gap-4 group hover:border-white/10 transition-colors">
                <div className="w-12 h-12 rounded bg-neutral-800 flex items-center justify-center shrink-0 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 to-purple-500 opacity-50" />
                    <Music className="w-6 h-6 text-white relative z-10" />
                </div>
                
                <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-white truncate">Lo-Fi Coding Beats</div>
                    <div className="text-[10px] text-neutral-500 truncate">Spotify • Kitchen Speaker</div>
                    
                    <div className="mt-2 h-1 bg-neutral-800 rounded-full overflow-hidden w-full">
                        <div className="h-full bg-[hsl(var(--color-intent))]" style={{ width: '45%' }} />
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <Button 
                        size="icon" 
                        variant="ghost" 
                        className="h-8 w-8 hover:bg-white/10"
                        onClick={() => setIsPlaying(!isPlaying)}
                    >
                        {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
                    </Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-white/10">
                        <SkipForward className="w-4 h-4 fill-current" />
                    </Button>
                </div>
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-3 mt-auto">
                <div className="p-3 bg-neutral-900 border border-white/5 rounded flex items-center justify-between">
                    <span className="text-xs text-neutral-300">Living Room Lights</span>
                    <div className="w-8 h-4 bg-[hsl(var(--color-execution))] rounded-full relative cursor-pointer">
                        <div className="absolute right-0.5 top-0.5 w-3 h-3 bg-white rounded-full shadow-sm" />
                    </div>
                </div>
                <div className="p-3 bg-neutral-900 border border-white/5 rounded flex items-center justify-between">
                    <span className="text-xs text-neutral-300">Front Door Lock</span>
                    <Lock className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                </div>
            </div>
        </div>
    );
}