import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    CheckCircle2, Plus, Film, Activity, Home, 
    Trophy, ChevronRight, Sparkles, Loader2 
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
    OrientingText, IntentText, StateText, Layer 
} from '@/components/ui/design-system/SystemDesign';
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// A gamified "Quick Action" card that works great on mobile
const ActionCard = ({ icon: Icon, title, reward, type, color, onAction, isLoading }) => (
    <div className="group relative overflow-hidden rounded-lg bg-neutral-900/50 border border-white/5 hover:border-white/10 transition-all active:scale-[0.98] cursor-pointer" onClick={onAction}>
        {/* Progress/Reward Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-white/5 opacity-0 group-hover:opacity-100 transition-opacity" />
        
        <div className="p-4 flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
                <div className={cn("p-2 rounded-md bg-neutral-950 border border-white/5 transition-colors group-hover:text-white", color)}>
                    {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Icon className="w-4 h-4" />}
                </div>
                <div>
                    <div className="font-bold text-sm text-neutral-200 group-hover:text-white transition-colors">{title}</div>
                    <div className="text-[10px] text-neutral-500 font-mono flex items-center gap-1">
                        <Trophy className="w-3 h-3 text-amber-500" />
                        <span className="text-amber-500">+{reward} XP</span>
                    </div>
                </div>
            </div>
            <div className="flex items-center">
                <ChevronRight className="w-4 h-4 text-neutral-600 group-hover:text-white group-hover:translate-x-1 transition-all" />
            </div>
        </div>
    </div>
);

export default function DailyDeck() {
    const queryClient = useQueryClient();
    const [xpGained, setXpGained] = useState(0);
    const [showCelebration, setShowCelebration] = useState(false);

    // -- Mutations --
    
    // 1. Log Health
    const healthMutation = useMutation({
        mutationFn: (data) => base44.entities.HealthMetric.create(data),
        onSuccess: () => {
            triggerReward(25, "Health Logged");
            queryClient.invalidateQueries(['health_metrics']);
        }
    });

    // 2. Complete Task (Quick Chore)
    const taskMutation = useMutation({
        mutationFn: (data) => base44.entities.HouseholdTask.create(data),
        onSuccess: () => {
            triggerReward(50, "Chore Crushed");
            queryClient.invalidateQueries(['household_tasks']);
        }
    });

    // 3. Log Media
    const mediaMutation = useMutation({
        mutationFn: (data) => base44.entities.EntertainmentItem.create(data),
        onSuccess: () => {
            triggerReward(15, "Media Captured");
            queryClient.invalidateQueries(['entertainment_items']);
        }
    });

    // -- XP Logic --
    const xpMutation = useMutation({
        mutationFn: async (amount) => {
            let user;
            try {
                user = await base44.auth.me();
            } catch (e) {
                // If not logged in, mock it for demo
                console.warn("User not logged in, using mock email");
                user = { email: "demo@user.com" };
            }

            const records = await base44.entities.UserXP.filter({ user_email: user.email });
            const myXP = records[0];
            
            if (myXP) {
                const newXP = (myXP.xp || 0) + amount;
                return base44.entities.UserXP.update(myXP.id, {
                    xp: newXP,
                    level: Math.floor(newXP / 1000) + 1,
                    last_active: new Date().toISOString()
                });
            } else {
                return base44.entities.UserXP.create({
                    user_email: user.email,
                    xp: amount,
                    level: 1,
                    last_active: new Date().toISOString()
                });
            }
        }
    });

    // -- Helper to trigger XP animation --
    const triggerReward = (amount, msg) => {
        setXpGained(amount);
        setShowCelebration(true);
        toast.success(msg, {
            description: `+${amount} XP Gained!`,
            icon: <Trophy className="w-4 h-4 text-amber-500" />
        });
        
        // Reset animation after 2s
        setTimeout(() => setShowCelebration(false), 2000);
        
        // Persist XP
        xpMutation.mutate(amount);
    };

    return (
        <div className="h-full flex flex-col relative overflow-hidden">
            {/* Celebration Overlay */}
            <div className={cn(
                "absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm transition-opacity duration-500 pointer-events-none",
                showCelebration ? "opacity-100" : "opacity-0"
            )}>
                <div className="text-center transform scale-110 animate-in zoom-in duration-300">
                    <Trophy className="w-16 h-16 mx-auto text-amber-500 mb-4 animate-bounce" />
                    <h2 className="text-3xl font-bold text-white mb-2">+{xpGained} XP</h2>
                    <p className="text-neutral-400 font-mono">LEVEL UP PROGRESS</p>
                </div>
            </div>

            <div className="flex justify-between items-center mb-4 px-1">
                <OrientingText>THE DAILY DECK</OrientingText>
                <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20 text-[9px] gap-1">
                    <Sparkles className="w-3 h-3" />
                    GAMIFIED
                </Badge>
            </div>

            <div className="flex-1 overflow-y-auto pr-2 space-y-3">
                {/* Health Actions */}
                <div className="space-y-2">
                    <StateText className="text-[10px] opacity-50 ml-1">HEALTH & BODY</StateText>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        <ActionCard 
                            icon={Activity}
                            title="Log Workout"
                            reward={50}
                            color="text-rose-500"
                            isLoading={healthMutation.isPending}
                            onAction={() => healthMutation.mutate({
                                type: "strain",
                                value: Math.floor(Math.random() * 5) + 12, // Sim value
                                unit: "score",
                                date: new Date().toISOString()
                            })}
                        />
                         <ActionCard 
                            icon={Activity}
                            title="Track Sleep"
                            reward={25}
                            color="text-cyan-500"
                            isLoading={healthMutation.isPending}
                            onAction={() => healthMutation.mutate({
                                type: "sleep_hours",
                                value: 7.5,
                                unit: "hours",
                                date: new Date().toISOString()
                            })}
                        />
                    </div>
                </div>

                {/* Household Actions */}
                <div className="space-y-2">
                    <StateText className="text-[10px] opacity-50 ml-1">SANCTUARY</StateText>
                    <ActionCard 
                        icon={Home}
                        title="Quick Tidy (15m)"
                        reward={35}
                        color="text-emerald-500"
                        isLoading={taskMutation.isPending}
                        onAction={() => taskMutation.mutate({
                            title: "Quick Tidy Session",
                            status: "done",
                            xp_reward: 35,
                            due_date: new Date().toISOString()
                        })}
                    />
                </div>

                {/* Entertainment Actions */}
                <div className="space-y-2">
                    <StateText className="text-[10px] opacity-50 ml-1">LUDIC ENGINE</StateText>
                    <ActionCard 
                        icon={Film}
                        title="Log Movie"
                        reward={15}
                        color="text-purple-500"
                        isLoading={mediaMutation.isPending}
                        onAction={() => mediaMutation.mutate({
                            title: "New Watch Entry",
                            type: "movie",
                            status: "completed",
                            xp_value: 15
                        })}
                    />
                </div>
            </div>
            
            {/* Quick Input Bar */}
            <div className="mt-4 pt-4 border-t border-white/5">
                <div className="relative">
                    <Input 
                        placeholder="Type to quick-log anything..." 
                        className="bg-neutral-900/50 border-white/10 pr-10 text-xs"
                    />
                    <Button size="icon" variant="ghost" className="absolute right-0 top-0 h-full w-10 text-neutral-500 hover:text-white">
                        <Plus className="w-4 h-4" />
                    </Button>
                </div>
            </div>
        </div>
    );
}