import React, { useState } from 'react';
import { 
    MessageSquare, Plus, Bell, Calendar as CalendarIcon, 
    CheckCircle2, User, StickyNote 
} from 'lucide-react';
import { IntentText, StateText } from '@/components/ui/design-system/SystemDesign';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import moment from 'moment';

export default function FamilyBoard() {
    const [messages, setMessages] = useState([
        { id: 1, user: 'Dad', text: 'Late meeting, dinner without me.', time: '17:30', type: 'status' },
        { id: 2, user: 'Mom', text: 'Soccer practice pickup @ 6pm', time: '14:20', type: 'alert' },
        { id: 3, user: 'System', text: 'Groceries delivered.', time: '13:00', type: 'system' }
    ]);
    const [input, setInput] = useState('');

    const handleSend = (e) => {
        e.preventDefault();
        if (!input.trim()) return;
        setMessages(prev => [{
            id: Date.now(),
            user: 'Me',
            text: input,
            time: moment().format('HH:mm'),
            type: 'status'
        }, ...prev]);
        setInput('');
    };

    return (
        <div className="h-full flex flex-col">
            <div className="flex justify-between items-center mb-4 shrink-0">
                <div className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <IntentText className="font-bold">FAMILY COMMS</IntentText>
                </div>
                <Button size="icon" variant="ghost" className="h-6 w-6 rounded-full bg-white/5">
                    <Bell className="w-3 h-3" />
                </Button>
            </div>

            <ScrollArea className="flex-1 -mx-2 px-2">
                <div className="space-y-3">
                    {messages.map((msg) => (
                        <div key={msg.id} className={cn(
                            "p-3 rounded-lg border",
                            msg.type === 'system' ? "bg-neutral-900/50 border-neutral-800" : 
                            msg.type === 'alert' ? "bg-[hsl(var(--color-intent))]/10 border-[hsl(var(--color-intent))]/20" :
                            "bg-neutral-900 border-white/5"
                        )}>
                            <div className="flex justify-between items-start mb-1">
                                <div className="flex items-center gap-2">
                                    <div className="w-5 h-5 rounded-full bg-neutral-800 flex items-center justify-center text-[10px]">
                                        {msg.user[0]}
                                    </div>
                                    <span className={cn(
                                        "text-xs font-bold",
                                        msg.type === 'alert' ? "text-[hsl(var(--color-intent))]" : "text-neutral-300"
                                    )}>{msg.user}</span>
                                </div>
                                <span className="text-[9px] text-neutral-500 font-mono">{msg.time}</span>
                            </div>
                            <p className="text-sm text-neutral-200">{msg.text}</p>
                        </div>
                    ))}
                </div>
            </ScrollArea>

            <form onSubmit={handleSend} className="mt-4 shrink-0 flex gap-2">
                <Input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Leave a note..." 
                    className="h-8 text-xs bg-neutral-900 border-white/10"
                />
                <Button type="submit" size="sm" className="h-8 w-8 p-0 bg-[hsl(var(--color-intent))] text-white hover:bg-[hsl(var(--color-intent))]/90">
                    <Plus className="w-4 h-4" />
                </Button>
            </form>
        </div>
    );
}