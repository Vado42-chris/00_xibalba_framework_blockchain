import React, { useState } from 'react';
import { Terminal as TerminalIcon, X, Maximize2, Minimize2 } from 'lucide-react';
import { cn } from "@/lib/utils";
import { SystemTerminal } from '@/components/ui/design-system/SystemContent';

export default function TerminalWidget({ node, onClose }) {
    const [isMaximized, setIsMaximized] = useState(false);

    return (
        <div className={cn(
            "flex flex-col bg-black border border-white/10 rounded shadow-2xl overflow-hidden transition-all duration-300",
            isMaximized ? "absolute inset-4 z-50" : "h-64 mt-4"
        )}>
            <SystemTerminal
                className="border-none rounded-none h-full"
                prompt={`root@${node.ip_address}:~$`}
                title={`root@${node.ip_address}`}
                initialLines={[
                    { type: 'system', content: `Connecting to ${node.name} (${node.ip_address})...` },
                    { type: 'system', content: `Connection established. Welcome to Base44 Node OS v2.4.` },
                    { type: 'system', content: `Type 'help' for available commands.` }
                ]}
                onCommand={(cmd, cb) => {
                    setTimeout(() => {
                        let response = '';
                        switch (cmd.toLowerCase()) {
                            case 'help': response = 'Available commands: status, logs, clear, reboot, exit, top, whoami'; break;
                            case 'status': response = `Node: ${node.name}\nStatus: ${node.status}\nUptime: 14d 2h 12m\nLoad: 0.45 0.32 0.28`; break;
                            case 'logs': response = 'Fetching system logs...\n[sys] Kernel panic avoided\n[net] Packet loss 0.001%\n[auth] User root logged in'; break;
                            case 'clear': cb(null); return; // SystemTerminal handles clear internally if we returned special signal, but current implementation appends output. 
                            // We need to support 'clear'. SystemTerminal implementation:
                            // onCommand(cmd, (response) => { setLines(prev => [...prev, { type: 'output', content: response }]); });
                            // It doesn't support clearing history.
                            // For now, just print "cleared" mock.
                            case 'exit': onClose(); return;
                            case 'top': response = 'PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND\n123 root      20   0  12.4g 342m  12m S  12.3  2.1   142:12 node_runtime\n456 root      20   0   8.2g 120m  10m S   4.1  0.8    12:44 agent_swarm'; break;
                            case 'whoami': response = 'root'; break;
                            case 'reboot': response = 'Rebooting system... Connection will be lost.'; setTimeout(onClose, 2000); break;
                            default: response = `Command not found: ${cmd}`;
                        }
                        cb(response);
                    }, 200);
                }}
                actions={
                    <div className="flex items-center gap-2">
                        <button onClick={() => setIsMaximized(!isMaximized)} className="text-neutral-500 hover:text-white">
                            {isMaximized ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
                        </button>
                        <button onClick={onClose} className="text-neutral-500 hover:text-red-500">
                            <X className="w-3 h-3" />
                        </button>
                    </div>
                }
            />
        </div>
    );
}