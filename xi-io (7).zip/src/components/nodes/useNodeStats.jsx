import { useState, useEffect } from 'react';

export function useNodeStats(isActive) {
    const [stats, setStats] = useState({
        cpu: 12,
        memory: 24,
        network_in: 0,
        network_out: 0,
        history: Array(20).fill(10) // For sparklines
    });

    useEffect(() => {
        if (!isActive) return;

        const interval = setInterval(() => {
            setStats(prev => {
                // Simulate fluctuation
                const cpuChange = (Math.random() - 0.5) * 10;
                let newCpu = Math.max(5, Math.min(95, prev.cpu + cpuChange));
                
                const memChange = (Math.random() - 0.5) * 5;
                let newMem = Math.max(10, Math.min(90, prev.memory + memChange));

                const newHistory = [...prev.history.slice(1), newCpu];

                return {
                    cpu: Math.round(newCpu),
                    memory: Math.round(newMem),
                    network_in: Math.round(Math.random() * 500), // KB/s
                    network_out: Math.round(Math.random() * 200),
                    history: newHistory
                };
            });
        }, 1000);

        return () => clearInterval(interval);
    }, [isActive]);

    return stats;
}