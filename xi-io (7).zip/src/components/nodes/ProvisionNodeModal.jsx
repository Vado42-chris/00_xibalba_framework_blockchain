import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Server, Cloud, Cpu, Globe, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { toast } from "sonner";
import { StateText, IntentText } from '@/components/ui/design-system/SystemDesign';

export default function ProvisionNodeModal({ open, onOpenChange }) {
    const [step, setStep] = useState(1); // 1: Config, 2: Provisioning, 3: Success
    const [provider, setProvider] = useState('digitalocean');
    const [config, setConfig] = useState({
        name: 'node-01',
        region: 'nyc1',
        size: 's-1vcpu-1gb',
        image: 'ubuntu-20-04-x64'
    });

    const queryClient = useQueryClient();

    const provisionMutation = useMutation({
        mutationFn: async (data) => {
            // Simulate API call to provider
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            // Create Node entity
            const ip = `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
            await base44.entities.Node.create({
                name: data.name,
                type: 'satellite',
                status: 'connected',
                trust_level: 'verified',
                ip_address: ip,
                last_seen: new Date().toISOString()
            });
            
            return { ip };
        },
        onSuccess: (data) => {
            setStep(3);
            queryClient.invalidateQueries(['nodes']);
            toast.success(`Node provisioned at ${data.ip}`);
        },
        onError: () => {
            toast.error("Provisioning failed");
            setStep(1);
        }
    });

    const handleProvision = () => {
        if (!config.name) {
            toast.error("Please name your node");
            return;
        }
        setStep(2);
        provisionMutation.mutate({ ...config, provider });
    };

    const reset = () => {
        setStep(1);
        setConfig({ name: 'node-01', region: 'nyc1', size: 's-1vcpu-1gb', image: 'ubuntu-20-04-x64' });
        onOpenChange(false);
    };

    const PROVIDERS = [
        { id: 'digitalocean', name: 'DigitalOcean', icon: Cloud },
        { id: 'vultr', name: 'Vultr', icon: Server },
        { id: 'linode', name: 'Linode', icon: Globe },
        { id: 'custom', name: 'Manual / Custom', icon: Cpu },
    ];

    return (
        <Dialog open={open} onOpenChange={(val) => !val && reset()}>
            <DialogContent className="bg-neutral-950 border-white/10 text-white sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <Server className="w-5 h-5 text-[hsl(var(--color-system))]" />
                        Provision New Node
                    </DialogTitle>
                    <DialogDescription>
                        Spin up a new server instance or connect an existing one.
                    </DialogDescription>
                </DialogHeader>

                <div className="py-6">
                    {step === 1 && (
                        <div className="space-y-6">
                            {/* Provider Selection */}
                            <div className="grid grid-cols-2 gap-3">
                                {PROVIDERS.map(p => (
                                    <button
                                        key={p.id}
                                        onClick={() => setProvider(p.id)}
                                        className={`flex flex-col items-center justify-center p-4 rounded border transition-all ${
                                            provider === p.id 
                                                ? 'bg-neutral-900 border-[hsl(var(--color-system))] text-white' 
                                                : 'bg-neutral-950 border-white/10 text-neutral-500 hover:border-white/20 hover:bg-neutral-900'
                                        }`}
                                    >
                                        <p.icon className={`w-6 h-6 mb-2 ${provider === p.id ? 'text-[hsl(var(--color-system))]' : 'text-current'}`} />
                                        <span className="text-xs font-medium">{p.name}</span>
                                    </button>
                                ))}
                            </div>

                            {provider !== 'custom' ? (
                                <div className="space-y-4 p-4 bg-neutral-900/30 rounded border border-white/5">
                                    <div className="space-y-2">
                                        <label className="text-xs text-neutral-500 font-bold uppercase">Hostname</label>
                                        <Input 
                                            value={config.name}
                                            onChange={(e) => setConfig({...config, name: e.target.value})}
                                            className="bg-neutral-950 border-white/10"
                                            placeholder="e.g. core-node-02"
                                        />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <label className="text-xs text-neutral-500 font-bold uppercase">Region</label>
                                            <Select value={config.region} onValueChange={(v) => setConfig({...config, region: v})}>
                                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="nyc1">New York (NYC1)</SelectItem>
                                                    <SelectItem value="sfo2">San Francisco (SFO2)</SelectItem>
                                                    <SelectItem value="ams3">Amsterdam (AMS3)</SelectItem>
                                                    <SelectItem value="sgp1">Singapore (SGP1)</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-xs text-neutral-500 font-bold uppercase">Size</label>
                                            <Select value={config.size} onValueChange={(v) => setConfig({...config, size: v})}>
                                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="s-1vcpu-1gb">Basic (1 vCPU / 1GB) - $5</SelectItem>
                                                    <SelectItem value="s-2vcpu-2gb">General (2 vCPU / 2GB) - $15</SelectItem>
                                                    <SelectItem value="c-2">CPU Opt (2 vCPU / 4GB) - $40</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs text-neutral-500 font-bold uppercase">Image</label>
                                        <Select value={config.image} onValueChange={(v) => setConfig({...config, image: v})}>
                                            <SelectTrigger className="bg-neutral-950 border-white/10">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="ubuntu-20-04-x64">Ubuntu 20.04 (LTS) x64</SelectItem>
                                                <SelectItem value="debian-10-x64">Debian 10 x64</SelectItem>
                                                <SelectItem value="fedora-32-x64">Fedora 32 x64</SelectItem>
                                                <SelectItem value="distro-forge">Custom Distro (from Forge)</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                            ) : (
                                <div className="p-4 bg-neutral-900/30 rounded border border-white/5 space-y-4">
                                    <div className="flex items-start gap-3">
                                        <AlertCircle className="w-5 h-5 text-[hsl(var(--color-warning))]" />
                                        <div className="text-xs text-neutral-400">
                                            To connect a manual node, ensure you have SSH access. You will be provided with an install script to run on your server.
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-xs text-neutral-500 font-bold uppercase">Node Name</label>
                                        <Input 
                                            value={config.name}
                                            onChange={(e) => setConfig({...config, name: e.target.value})}
                                            className="bg-neutral-950 border-white/10"
                                        />
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {step === 2 && (
                        <div className="flex flex-col items-center justify-center py-8 space-y-4">
                            <div className="relative">
                                <div className="w-16 h-16 border-4 border-[hsl(var(--color-system))] border-t-transparent rounded-full animate-spin" />
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <Cpu className="w-6 h-6 text-neutral-500" />
                                </div>
                            </div>
                            <div className="text-center space-y-1">
                                <IntentText className="text-lg">Provisioning Infrastructure</IntentText>
                                <StateText className="animate-pulse">Allocating resources on {PROVIDERS.find(p => p.id === provider)?.name}...</StateText>
                            </div>
                            <div className="w-full max-w-xs bg-neutral-900 h-1 rounded-full overflow-hidden mt-4">
                                <div className="h-full bg-[hsl(var(--color-system))] w-2/3 animate-[progress_2s_ease-in-out_infinite]" />
                            </div>
                        </div>
                    )}

                    {step === 3 && (
                        <div className="flex flex-col items-center justify-center py-8 space-y-4">
                            <div className="w-16 h-16 bg-[hsl(var(--color-system))]/10 rounded-full flex items-center justify-center border border-[hsl(var(--color-system))]/20 animate-in zoom-in">
                                <CheckCircle2 className="w-8 h-8 text-[hsl(var(--color-system))]" />
                            </div>
                            <div className="text-center space-y-1">
                                <IntentText className="text-lg text-[hsl(var(--color-system))]">Node Online</IntentText>
                                <StateText>Server is active and connected to the grid.</StateText>
                            </div>
                            <div className="flex gap-4 w-full mt-4">
                                <div className="flex-1 p-2 bg-neutral-900 border border-white/5 rounded text-center">
                                    <div className="text-[10px] text-neutral-500 uppercase tracking-wider">Region</div>
                                    <div className="text-sm font-mono text-white">{config.region.toUpperCase()}</div>
                                </div>
                                <div className="flex-1 p-2 bg-neutral-900 border border-white/5 rounded text-center">
                                    <div className="text-[10px] text-neutral-500 uppercase tracking-wider">IP Address</div>
                                    <div className="text-sm font-mono text-white">192.168.x.x</div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                <DialogFooter>
                    {step === 1 && (
                        <>
                            <Button variant="ghost" onClick={reset}>Cancel</Button>
                            <Button 
                                onClick={handleProvision} 
                                className="bg-[hsl(var(--color-system))] text-black hover:bg-[hsl(var(--color-system))]/90 font-bold"
                            >
                                {provider === 'custom' ? 'Generate Script' : 'Provision Server'}
                            </Button>
                        </>
                    )}
                    {step === 3 && (
                        <Button onClick={reset} variant="outline" className="w-full border-white/10 hover:bg-white/5">Close</Button>
                    )}
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}