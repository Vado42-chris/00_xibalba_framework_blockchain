import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { BrandLogo } from '@/components/brand/BrandLogo';
import { Button } from "@/components/ui/button";
import { base44 } from '@/api/base44Client';
import { ChevronRight, Search, List, Layers, Shield, Zap, Activity } from 'lucide-react';
import { AnimatedSeparator } from '@/components/search/SearchBackground';
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SearchEngineSelector, ZipperTrigger, SEARCH_ENGINES } from '@/components/search/SearchEngineSelector';
import { PersonaCard } from '@/components/identity/PersonaCard';
import { cn } from '@/lib/utils';
import { useQuery } from '@tanstack/react-query';
import { NotificationCenter } from '@/components/notifications/NotificationCenter';

export function SiteHeader({ 
    mode = 'nav', // 'nav' or 'search'
    query, setQuery,
    searchScope, setSearchScope,
    engine, setEngine,
    activeTab, setActiveTab,
    isSemanticMode, setIsSemanticMode,
    results,
    isLoading
}) {
    const { data: user } = useQuery({
        queryKey: ['me'],
        queryFn: () => base44.auth.me().catch(() => null),
        retry: false
    });

    return (
        <header className="fixed top-0 left-0 right-0 z-50 bg-black/40 backdrop-blur-md border-b border-white/5 shadow-2xl transition-all duration-300 hover:bg-black/60">
            <AnimatedSeparator />
            <div className="max-w-[1920px] mx-auto flex items-stretch min-h-[80px]">
                
                {/* Logo Section - Glassmorphic */}
                <div className={cn(
                    "shrink-0 flex items-center justify-center border-r border-white/5 bg-black/20 backdrop-blur-sm transition-colors duration-500 hover:bg-black/40",
                    mode === 'search' ? "lg:w-64 xl:w-80" : "px-8"
                )}>
                    <Link to={createPageUrl('Home')} className="flex items-center gap-3 hover:opacity-100 transition-all duration-300 group">
                        <BrandLogo size={mode === 'search' ? "large" : "medium"} variant={mode === 'search' ? "full" : "icon"} className="group-hover:scale-105 transition-transform duration-500" />
                        {mode === 'nav' && (
                            <span className="font-serif font-bold text-white tracking-tight text-xl hidden md:block group-hover:text-[hsl(var(--color-intent))] transition-colors drop-shadow-md">XI-IO</span>
                        )}
                    </Link>
                </div>

                {/* Content Section */}
                <div className="flex-1 flex items-center px-8 py-2">
                    {mode === 'nav' ? (
                        /* Navigation Mode */
                        <div className="flex-1 flex items-center justify-between">
                            <nav className="hidden lg:flex items-center gap-10">
                                <NavLink to="SovereignCloud">Product</NavLink>
                                <NavLink to="Marketplace">Marketplace</NavLink>
                                <NavLink to="NetworkLanding">Network</NavLink>
                                <NavLink to="EnterpriseLanding">Enterprise</NavLink>
                                <NavLink to="Manifesto">Manifesto</NavLink>
                            </nav>

                            <div className="flex items-center gap-6">
                                <Link to={createPageUrl('Home') + '?scope=web'} className="hidden md:block text-sm font-medium text-neutral-400 hover:text-white transition-colors">
                                    Search Index
                                </Link>
                                <Link to={createPageUrl('WorkRoom') + '?tab=git'} className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" title="Git History">
                                    <div className="w-4 h-4"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-git-branch"><line x1="6" x2="6" y1="3" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg></div>
                                </Link>
                                <button onClick={() => { navigator.clipboard.writeText(window.location.href); import('sonner').then(m => m.toast.success('Project link copied')); }} className="p-2 text-neutral-500 hover:text-white hover:bg-white/5 rounded transition-colors" title="Share Project">
                                    <div className="w-4 h-4"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-share-2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg></div>
                                </button>
                                
                                {user ? (
                                    <>
                                        <div className="h-6 w-px bg-white/10" />
                                        <NotificationCenter />
                                        <Link to={createPageUrl('WorkRoom')}>
                                            <Button 
                                                className="bg-white/10 text-white hover:bg-white/20 font-bold rounded-full h-10 px-6 text-xs tracking-wide border border-white/5"
                                            >
                                                Command Center
                                            </Button>
                                        </Link>
                                    </>
                                ) : (
                                    <Button 
                                        onClick={() => base44.auth.redirectToLogin()}
                                        className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold rounded-full h-10 px-6 text-xs tracking-wide shadow-[0_0_20px_-5px_hsl(var(--color-intent))]"
                                    >
                                        Initialize Node <ChevronRight className="w-3 h-3 ml-1" />
                                    </Button>
                                )}
                            </div>
                        </div>
                    ) : (
                        /* Search Mode */
                        <div className="w-full space-y-6 py-2">
                            {/* Search Inputs */}
                            <div className="flex flex-col gap-4">
                                <div className="flex gap-4">
                                    <div className="relative group flex-1">
                                        <Search className="absolute left-6 top-1/2 -translate-y-1/2 w-6 h-6 text-neutral-500 group-focus-within:text-[hsl(var(--color-intent))] transition-colors" />
                                        <Input 
                                            value={query}
                                            onChange={(e) => setQuery(e.target.value)}
                                            className="h-16 pl-16 pr-4 text-xl font-serif bg-neutral-900/50 hover:bg-neutral-900/80 backdrop-blur-md border-white/10 rounded-md focus-visible:ring-[hsl(var(--color-intent))] transition-all"
                                            placeholder={searchScope === 'web' ? `Scan via ${SEARCH_ENGINES?.find(e => e.id === engine)?.name || 'Web'}...` : "Filter the local noise..."}
                                            autoFocus
                                        />
                                        <div className="absolute right-6 top-1/2 -translate-y-1/2 flex items-center gap-2">
                                            {isLoading && <div className="w-5 h-5 border-2 border-[hsl(var(--color-intent))]/30 border-t-[hsl(var(--color-intent))] rounded-full animate-spin" />}
                                        </div>
                                    </div>
                                    
                                    <div className="flex flex-col bg-neutral-900/50 border border-white/10 rounded-md p-1 h-16 w-24 shrink-0">
                                        <button
                                            onClick={() => setSearchScope('local')}
                                            className={cn(
                                                "flex-1 rounded-sm flex items-center justify-center gap-2 transition-all duration-300 text-[10px] uppercase font-bold tracking-wider",
                                                searchScope === 'local' 
                                                    ? "bg-[hsl(var(--color-intent))]/10 text-[hsl(var(--color-intent))]" 
                                                    : "text-neutral-500 hover:text-white"
                                            )}
                                        >
                                            Local
                                        </button>
                                        <button
                                            onClick={() => setSearchScope('web')}
                                            className={cn(
                                                "flex-1 rounded-sm flex items-center justify-center gap-2 transition-all duration-300 text-[10px] uppercase font-bold tracking-wider",
                                                searchScope === 'web' 
                                                    ? "bg-blue-500/10 text-blue-500" 
                                                    : "text-neutral-500 hover:text-white"
                                            )}
                                        >
                                            Web
                                        </button>
                                    </div>
                                </div>
                                
                                {/* Engine Selector */}
                                {searchScope === 'web' && (
                                    <div className="flex items-center gap-4 animate-in slide-in-from-top-2">
                                        <div className="flex items-center gap-2">
                                            <span className="text-[10px] uppercase tracking-widest text-neutral-500 font-bold ml-1 hidden md:block">Via:</span>
                                            <SearchEngineSelector 
                                                selected={engine} 
                                                onSelect={(e) => {
                                                    if (engine === 'zipper') setEngine(e); 
                                                    else setEngine(e);
                                                }} 
                                            />
                                        </div>
                                        <div className="h-6 w-px bg-white/10 hidden md:block" />
                                        <ZipperTrigger 
                                            isActive={engine === 'zipper'} 
                                            onClick={() => setEngine(engine === 'zipper' ? 'google' : 'zipper')}
                                        />
                                    </div>
                                )}
                            </div>

                            {/* Filters & Semantic Toggle */}
                            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-2 overflow-hidden">
                                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full md:flex-1 min-w-0">
                                    <div className="overflow-x-auto pb-2 -mb-2 scrollbar-none">
                                        <TabsList className="bg-transparent p-0 h-auto flex flex-nowrap gap-4 w-max">
                                            <TabsTrigger value="all" className="data-[state=active]:text-white text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-white transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">
                                                {searchScope === 'web' ? 'All' : 'All Signals'} <span className="ml-2 text-[10px] opacity-50 font-mono">{results?.all?.length || 0}</span>
                                            </TabsTrigger>

                                            {searchScope === 'web' && (
                                                <>
                                                    <TabsTrigger value="images" className="data-[state=active]:text-purple-400 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-purple-400 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Images</TabsTrigger>
                                                    <TabsTrigger value="video" className="data-[state=active]:text-red-400 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-red-400 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Video</TabsTrigger>
                                                    <TabsTrigger value="news" className="data-[state=active]:text-blue-400 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-blue-400 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">News</TabsTrigger>
                                                    <TabsTrigger value="finance" className="data-[state=active]:text-emerald-400 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-emerald-400 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Finance</TabsTrigger>
                                                    <TabsTrigger value="entertainment" className="data-[state=active]:text-pink-400 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-pink-400 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Entertainment</TabsTrigger>
                                                    <TabsTrigger value="employment" className="data-[state=active]:text-cyan-400 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-cyan-400 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Employment</TabsTrigger>
                                                    <TabsTrigger value="education" className="data-[state=active]:text-yellow-400 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-yellow-400 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Education</TabsTrigger>
                                                </>
                                            )}
                                            
                                            {searchScope === 'local' && (
                                                <>
                                                    <TabsTrigger value="marketplace" className="data-[state=active]:text-rose-500 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-rose-500 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Marketplace</TabsTrigger>
                                                    <TabsTrigger value="content" className="data-[state=active]:text-teal-500 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-teal-500 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">Content</TabsTrigger>
                                                    <TabsTrigger value="crm" className="data-[state=active]:text-blue-500 text-neutral-500 bg-transparent data-[state=active]:bg-transparent rounded-none border-b-2 border-transparent data-[state=active]:border-blue-500 transition-all font-medium text-sm px-1 pb-4 tracking-wide uppercase">CRM</TabsTrigger>
                                                </>
                                            )}
                                        </TabsList>
                                    </div>
                                </Tabs>

                                <div className="flex items-center gap-2 p-1 bg-neutral-900/50 rounded-lg border border-white/10">
                                    <button onClick={() => setIsSemanticMode(false)} className={cn("p-2 rounded-md transition-all flex items-center gap-2 text-xs font-medium", !isSemanticMode ? "bg-white/10 text-white shadow-sm" : "text-neutral-500 hover:text-white")}>
                                        <List className="w-4 h-4" />
                                        <span className="hidden sm:inline">List</span>
                                    </button>
                                    <button onClick={() => setIsSemanticMode(true)} className={cn("p-2 rounded-md transition-all flex items-center gap-2 text-xs font-medium", isSemanticMode ? "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))] shadow-sm ring-1 ring-[hsl(var(--color-intent))]/30" : "text-neutral-500 hover:text-white")}>
                                        <Layers className="w-4 h-4" />
                                        <span className="hidden sm:inline">Stack</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Column 3: Persona Card */}
                <div className="hidden 2xl:block w-80 shrink-0 border-l border-white/5 pl-8 py-2 bg-neutral-950/30">
                    <PersonaCard />
                </div>
            </div>
        </header>
    );
}

function NavLink({ to, children }) {
    return (
        <Link 
            to={createPageUrl(to)} 
            className="text-sm font-medium text-neutral-400 hover:text-white transition-colors tracking-wide"
        >
            {children}
        </Link>
    );
}