export const DEFAULT_THEME = {
    // SEMANTIC 7 CATEGORIES (HSL Hues)
    'color-orientation': 250, // Where am I? (Stable, Low Sat)
    'color-intent': 340,      // What am I trying to do? (Primary Accent)
    'color-execution': 160,   // What is happening? (Bright, Active)
    'color-review': 35,       // What needs judgment? (Muted, Distinct)
    'color-settled': 210,     // What is finished? (Desaturated)
    'color-warning': 0,       // What could break flow? (Binary, Rare)
    'color-system': 190,      // What is the system saying? (Quiet, Thin)

    // BACKGROUND / FX
    'bg-pulse-speed': 10,     // Heartbeat speed (0-100)
    'bg-ring-count': 12,      // Number of rings (0-20)
    'bg-ring-width': 2,       // Width of rings (1-10)
    'bg-particle-count': 80,  // Particle density (0-200)
    'bg-grid-opacity': 5,     // Grid opacity (0-100)
    
    // GLASS MORPHISM
    'glass-blur': 10,         // Backdrop blur (px)
    'glass-opacity': 20,      // Background opacity (%)
    'glass-border': 10,       // Border opacity (%)
    'glass-saturation': 100,  // Backdrop saturation (%)
    
    // TYPOGRAPHY
    'font-heading': 'Inter, system-ui, sans-serif',
    'font-body': 'Inter, system-ui, sans-serif',
    'font-scale': 1.0, // Base scale multiplier
};

export const applyTheme = (theme) => {
    if (!theme || typeof document === 'undefined') return;
    
    const root = document.documentElement;
    
    // Apply Glass Variables
    if (theme['glass-blur'] !== undefined) root.style.setProperty('--glass-blur', `${theme['glass-blur']}px`);
    if (theme['glass-opacity'] !== undefined) root.style.setProperty('--glass-bg', `rgba(0, 0, 0, ${theme['glass-opacity'] / 100})`);
    if (theme['glass-border'] !== undefined) root.style.setProperty('--glass-border', `rgba(255, 255, 255, ${theme['glass-border'] / 100})`);
    if (theme['glass-saturation'] !== undefined) root.style.setProperty('--glass-saturation', `${theme['glass-saturation']}%`);

    // Apply Typography
    if (theme['font-heading']) root.style.setProperty('--font-heading', theme['font-heading']);
    if (theme['font-body']) root.style.setProperty('--font-body', theme['font-body']);
    if (theme['font-scale']) root.style.setProperty('--font-scale', theme['font-scale']);

    // Apply Custom CSS
    if (theme['custom-css']) {
        let styleTag = document.getElementById('xi-theme-custom-css');
        if (!styleTag) {
            styleTag = document.createElement('style');
            styleTag.id = 'xi-theme-custom-css';
            document.head.appendChild(styleTag);
        }
        styleTag.innerHTML = theme['custom-css'];
    }

    Object.entries(theme).forEach(([key, value]) => {
        // SECTION 2: BEHAVIOR RULES
        const saturation = {
            'color-orientation': '20%', // "Low saturation"
            'color-intent': '75%',      // "Focused"
            'color-execution': '85%',   // "Slightly brighter"
            'color-review': '45%',      // "Muted"
            'color-settled': '5%',      // "Desaturated"
            'color-warning': '80%',     // "Binary"
            'color-system': '20%',      // "Quiet"
        }[key] || '50%';

        const lightness = {
            'color-orientation': '50%',
            'color-intent': '60%',
            'color-execution': '55%',   // "Brighter" (visually)
            'color-review': '65%',
            'color-settled': '40%',     // "Recedes"
            'color-warning': '50%',
            'color-system': '60%',
        }[key] || '50%';

        root.style.setProperty(`--${key}`, `${value} ${saturation} ${lightness}`);
    });
    
    // BACKWARD COMPATIBILITY / MAPPINGS
    // Map old variable names to new system to prevent breaking existing UI
    if (theme['color-orientation']) root.style.setProperty('--color-identity', `${theme['color-orientation']} 20% 50%`);
    if (theme['color-execution']) root.style.setProperty('--color-active', `${theme['color-execution']} 85% 55%`);
    if (theme['color-review']) root.style.setProperty('--color-pending', `${theme['color-review']} 45% 65%`);
    if (theme['color-warning']) root.style.setProperty('--color-error', `${theme['color-warning']} 80% 50%`);

    // Standard mappings
    if (theme['color-intent']) {
        root.style.setProperty('--primary', `${theme['color-intent']} 75% 60%`);
        root.style.setProperty('--ring', `${theme['color-intent']} 75% 60%`);
    }
};