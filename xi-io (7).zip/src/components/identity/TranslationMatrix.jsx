export const TRANSLATION_MATRIX = {
    // SYSTEM / CORE
    "DEPLOY": {
        technical: "Deploy",
        human: "Publish",
        generational: "Yeet to Prod",
        context: "Transfers local artifacts to the live server environment."
    },
    "SYNC": {
        technical: "Synchronize",
        human: "Refresh",
        generational: "Vibe Check",
        context: "Aligns local state with the source of truth."
    },
    "INITIALIZING": {
        technical: "Initializing",
        human: "Starting Up",
        generational: "Waking Up",
        context: "Boot sequence initiated. Loading core modules."
    },
    "NOMINAL": {
        technical: "Nominal",
        human: "Healthy",
        generational: "Chilling",
        context: "System is operating within expected parameters."
    },
    "CRITICAL": {
        technical: "Critical Failure",
        human: "Failed",
        generational: "Cooked",
        context: "System has encountered an unrecoverable error."
    },
    "BUILD": {
        technical: "Build",
        human: "Prepare",
        generational: "Let Him Cook",
        context: "Compiles source code into executable artifacts."
    },
    "ROLLBACK": {
        technical: "Rollback",
        human: "Undo",
        generational: "Go Back",
        context: "Reverts the system to the previous stable state."
    }
};

export const LOCALE_DICTIONARY = {
    'en-US': {
        "Welcome": "Welcome",
        "Settings": "Settings",
        "Security": "Security",
        "System Status": "System Status",
        "Role Management": "Role Management",
        "Create Role": "Create Role",
        "Language": "Language",
        "Interface Mode": "Interface Mode"
    },
    'es-ES': {
        "Welcome": "Bienvenido",
        "Settings": "Configuración",
        "Security": "Seguridad",
        "System Status": "Estado del Sistema",
        "Role Management": "Gestión de Roles",
        "Create Role": "Crear Rol",
        "Language": "Idioma",
        "Interface Mode": "Modo de Interfaz"
    },
    'fr-FR': {
        "Welcome": "Bienvenue",
        "Settings": "Paramètres",
        "Security": "Sécurité",
        "System Status": "État du Système",
        "Role Management": "Gestion des Rôles",
        "Create Role": "Créer un Rôle",
        "Language": "Langue",
        "Interface Mode": "Mode d'Interface"
    },
    'ja-JP': {
        "Welcome": "ようこそ",
        "Settings": "設定",
        "Security": "セキュリティ",
        "System Status": "システムステータス",
        "Role Management": "ロール管理",
        "Create Role": "ロール作成",
        "Language": "言語",
        "Interface Mode": "インターフェースモード"
    }
};

export const getTranslation = (term, mode = 'human') => {
    if (!term) return term;
    
    const upperTerm = term.toUpperCase();
    const entry = TRANSLATION_MATRIX[upperTerm];
    
    if (!entry) return term; // Fallback to original
    
    // If asking for context, return that.
    if (mode === 'context') return entry.context;
    
    return entry[mode] || term;
};