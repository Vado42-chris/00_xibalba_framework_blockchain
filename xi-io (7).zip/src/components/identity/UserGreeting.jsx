import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Sun, Moon, CloudRain, Clock, Calendar } from 'lucide-react';
import { format } from 'date-fns';

export default function UserGreeting() {
    const [user, setUser] = useState(null);
    const [quote, setQuote] = useState(null);

    useEffect(() => {
        base44.auth.me().then(setUser).catch(() => {});
        
        // Mock "Daily Inspiration"
        const quotes = [
            "The best way to predict the future is to invent it.",
            "Code is poetry written for machines.",
            "Simplicity is the ultimate sophistication.",
            "Make it work, make it right, make it fast.",
            "Digital sovereignty is the new frontier."
        ];
        setQuote(quotes[Math.floor(Math.random() * quotes.length)]);
    }, []);

    const time = new Date();
    const hour = time.getHours();
    let greeting = "Good Evening";
    if (hour < 12) greeting = "Good Morning";
    else if (hour < 18) greeting = "Good Afternoon";

    return (
        <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-4xl mx-auto mb-8 p-6 rounded-2xl bg-gradient-to-r from-neutral-900/50 to-neutral-900/10 border border-white/5 backdrop-blur-sm relative overflow-hidden"
        >
            <div className="absolute top-0 right-0 p-4 opacity-10">
                {hour < 18 ? <Sun className="w-24 h-24" /> : <Moon className="w-24 h-24" />}
            </div>

            <div className="relative z-10">
                <div className="flex items-center gap-2 text-[hsl(var(--color-intent))] text-xs font-bold uppercase tracking-widest mb-2">
                    <Calendar className="w-3 h-3" />
                    {format(time, 'EEEE, MMMM do')}
                </div>
                
                <h1 className="text-3xl md:text-4xl font-light text-white mb-2">
                    {greeting}, <span className="font-bold">{user?.first_name || 'Creator'}</span>.
                </h1>
                
                <p className="text-neutral-400 max-w-lg text-sm md:text-base italic">
                    "{quote}"
                </p>

                {/* Quick Stats or "Home" widgets could go here */}
                <div className="mt-6 flex gap-4">
                    <div className="px-3 py-1.5 rounded-full bg-white/5 border border-white/5 text-xs text-neutral-300 flex items-center gap-2">
                        <Clock className="w-3 h-3 text-[hsl(var(--color-execution))]" />
                        <span>System Uptime: 99.9%</span>
                    </div>
                    <div className="px-3 py-1.5 rounded-full bg-white/5 border border-white/5 text-xs text-neutral-300 flex items-center gap-2">
                        <CloudRain className="w-3 h-3 text-blue-400" />
                        <span>Digital Weather: Clear</span>
                    </div>
                </div>
            </div>
        </motion.div>
    );
}