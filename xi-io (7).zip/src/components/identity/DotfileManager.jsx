import React, { useState } from 'react';
import { FileCode, Upload, Download, RefreshCw, Trash2, Plus } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
    OrientingText, IntentText, StateText, 
    SemanticDot, Layer, AtomicParagraph 
} from '@/components/ui/design-system/System';

export default function DotfileManager({ files, onAddFile }) {
    // Local state fallback if not controlled
    const [localFiles, setLocalFiles] = useState([
        { id: 1, name: '.zshrc', status: 'synced', size: '4.2kb', updated: '2h ago', hash: '0x7f...a1' },
        { id: 2, name: '.vimrc', status: 'synced', size: '12kb', updated: '2d ago', hash: '0x3b...9c' },
        { id: 3, name: '.gitconfig', status: 'local', size: '1kb', updated: '5d ago', hash: 'pending' },
        { id: 4, name: '.ssh/config', status: 'encrypted', size: '2kb', updated: '1w ago', hash: '0x88...2d' },
    ]);

    const activeFiles = files || localFiles;

    const [newFile, setNewFile] = useState('');

    const handleImport = () => {
        if (!newFile) return;
        const file = {
            id: Date.now(),
            name: newFile,
            status: 'pending',
            size: '0kb',
            updated: 'Just now'
        };

        if (onAddFile) {
            onAddFile(file);
        } else {
            setLocalFiles([...localFiles, file]);
        }
        setNewFile('');
    };

    return (
        <Layer level="state" className="h-full flex flex-col border border-white/10 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-white/5 bg-neutral-900/50 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-[hsl(var(--color-orientation))]" />
                    <OrientingText className="font-bold">Environment Sync</OrientingText>
                </div>
                <StateText className="font-mono text-[hsl(var(--color-active))]">ACTIVE</StateText>
            </div>

            <div className="p-4 space-y-4 flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
                <div className="flex gap-2">
                    <Input 
                        placeholder="Import dotfile..." 
                        value={newFile}
                        onChange={(e) => setNewFile(e.target.value)}
                        className="h-8 text-xs bg-neutral-900 border-white/10"
                    />
                    <Button size="sm" className="h-8 px-3 bg-[hsl(var(--color-active))] hover:bg-[hsl(var(--color-active))]/80 text-black" onClick={handleImport}>
                        <Plus className="w-3 h-3" />
                    </Button>
                </div>

                <div className="space-y-2">
                    {activeFiles.map(file => (
                        <div key={file.id} className="group flex items-center justify-between p-2 rounded bg-neutral-950 border border-white/10 hover:border-[hsl(var(--color-intent))] transition-colors">
                            <div className="flex items-center gap-3">
                                <div className={`w-1.5 h-1.5 rounded-full ${
                                    file.status === 'synced' ? 'bg-[hsl(var(--color-execution))]' : 
                                    file.status === 'encrypted' ? 'bg-[hsl(var(--color-orientation))]' : 
                                    'bg-[hsl(var(--color-review))]'
                                }`} />
                                <div>
                                    <IntentText className="font-mono text-xs">{file.name}</IntentText>
                                    <div className="flex items-center gap-2">
                                        <StateText className="text-[9px] uppercase">{file.status} • {file.size}</StateText>
                                        {file.hash && (
                                            <StateText className="text-[8px] font-mono opacity-50 bg-white/5 px-1 rounded">
                                                BLK: {file.hash}
                                            </StateText>
                                        )}
                                    </div>
                                </div>
                            </div>
                            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button size="icon" variant="ghost" className="h-6 w-6 hover:bg-white/5">
                                    <Download className="w-3 h-3 text-neutral-500" />
                                </Button>
                                <Button size="icon" variant="ghost" className="h-6 w-6 hover:bg-white/5">
                                    <Trash2 className="w-3 h-3 text-[hsl(var(--color-error))]" />
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="p-3 border-t border-white/5 bg-neutral-900/30">
                <AtomicParagraph className="text-[9px] opacity-50 mb-0">
                    Encrypted at rest using AES-256-GCM. Keys managed via Orientation Matrix.
                </AtomicParagraph>
            </div>
        </Layer>
    );
}