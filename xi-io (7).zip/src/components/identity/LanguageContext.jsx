import React, { createContext, useContext, useState, useEffect } from 'react';
import { TRANSLATION_MATRIX, LOCALE_DICTIONARY } from './TranslationMatrix';

const LanguageContext = createContext({
    mode: 'technical', // 'technical' | 'human' | 'generational'
    locale: 'en-US',   // 'en-US' | 'es-ES' | 'fr-FR' | 'ja-JP'
    setMode: () => {},
    toggleMode: () => {},
    setLocale: () => {},
    t: (key) => key // Translator function
});

export const LanguageProvider = ({ children }) => {
    const [mode, setMode] = useState(() => {
        if (typeof window !== 'undefined') return localStorage.getItem('xi_lang_mode') || 'technical';
        return 'technical';
    });
    
    const [locale, setLocale] = useState(() => {
        if (typeof window !== 'undefined') return localStorage.getItem('xi_locale') || 'en-US';
        return 'en-US';
    });

    useEffect(() => {
        if (typeof window !== 'undefined') {
            localStorage.setItem('xi_lang_mode', mode);
            localStorage.setItem('xi_locale', locale);
        }
    }, [mode, locale]);

    const toggleMode = () => {
        setMode(prev => prev === 'technical' ? 'human' : 'technical');
    };

    // Translation Hook
    const t = (key, fallback = null) => {
        // 1. Check Locale Dictionary first
        if (LOCALE_DICTIONARY[locale] && LOCALE_DICTIONARY[locale][key]) {
            return LOCALE_DICTIONARY[locale][key];
        }
        
        // 2. Fallback to English/Mode Matrix if enabled and key exists
        if (locale.startsWith('en')) {
             const upperKey = key.toUpperCase();
             if (TRANSLATION_MATRIX[upperKey]) {
                 return TRANSLATION_MATRIX[upperKey][mode] || TRANSLATION_MATRIX[upperKey].technical || key;
             }
        }

        // 3. Fallback text
        return fallback || key;
    };

    return (
        <LanguageContext.Provider value={{ mode, locale, setMode, setLocale, toggleMode, t }}>
            {children}
        </LanguageContext.Provider>
    );
};

export const useLanguage = () => useContext(LanguageContext);