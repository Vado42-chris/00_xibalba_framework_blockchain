import React, { createContext, useContext, useState, useEffect } from 'react';
import { applyTheme, DEFAULT_THEME } from './themeUtils';
import { base44 } from '@/api/base44Client';

const SiteContext = createContext();

export const useSiteContext = () => {
    const context = useContext(SiteContext);
    if (!context) {
        throw new Error('useSiteContext must be used within a SiteContextProvider');
    }
    return context;
};

// ----------------------------------------------------------------------
// DOMAIN ECOSYSTEM MAP (Reconstructed from 42 Categories Report)
// ----------------------------------------------------------------------

export const DOMAIN_ECOSYSTEM = {
    // ------------------- XIBALBA (CREATIVE) -------------------
    // Focus: Design, Art, Media, Identity
    'xibalba.studio': {
        name: 'Xibalba Studio',
        family: 'Xibalba',
        status: 'production',
        intent: 'Dreamcatcher SaaS OS',
        theme: {
            mode: 'dark',
            primary: 'hsl(320, 70%, 60%)', // Pink/Magenta
            secondary: 'hsl(280, 50%, 50%)'
        },
        categories: ['Visual Designer', 'Motion Designer', 'Creative Director'],
        specs: {
            backend: 'LOKI (192.168.4.120)',
            content: 'Primary OS platform for creative professionals.',
            message: 'SYSTEM ACTIVE'
        }
    },
    'xibalba-studio.com': {
        name: 'Xibalba Main',
        family: 'Xibalba',
        status: 'production',
        intent: 'Marketing & Client Portal',
        theme: { mode: 'dark', primary: 'hsl(320, 70%, 60%)', secondary: 'hsl(280, 50%, 50%)' },
        categories: ['Client', 'Lead'],
        specs: { backend: 'LOKI', content: 'Public facing marketing site.', message: 'LIVE' }
    },
    'xibalba.design': {
        name: 'Xibalba Design',
        family: 'Xibalba',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Design Services Portfolio',
        theme: { mode: 'light', primary: 'hsl(0, 0%, 10%)', secondary: 'hsl(0, 0%, 40%)' },
        categories: ['Visual Designer', 'Architect'],
        specs: { backend: 'Planned', content: 'Portfolio showcase.', message: 'PROVISIONING' }
    },
    'xibalba.cloud': {
        name: 'Xibalba Cloud',
        family: 'Xibalba',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Infrastructure & Hosting',
        theme: { mode: 'dark', primary: 'hsl(200, 70%, 50%)', secondary: 'hsl(200, 50%, 30%)' },
        categories: ['DevOps', 'Systems Architect'],
        specs: { backend: 'Planned', content: 'Enterprise cloud solutions.', message: 'OFFLINE' }
    },
    'xibalba.free': {
        name: 'Xibalba Free',
        family: 'Xibalba',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Community Tier',
        theme: { mode: 'dark', primary: 'hsl(150, 60%, 50%)', secondary: 'hsl(150, 40%, 30%)' },
        categories: ['Hobbyist', 'Student'],
        specs: { backend: 'Planned', content: 'Free tier services.', message: 'OFFLINE' }
    },
    'xibalba.my': {
        name: 'Xibalba My',
        family: 'Xibalba',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Personal Workspace',
        theme: { mode: 'dark', primary: 'hsl(300, 50%, 50%)', secondary: 'hsl(300, 30%, 30%)' },
        categories: ['Personal Assistant'],
        specs: { backend: 'Planned', content: 'Personal cloud.', message: 'OFFLINE' }
    },

    // ------------------- VEILRIFT (TECH/GAMING) -------------------
    // Focus: Dev, RPG, Blockchain, Community
    'veilrift.online': {
        name: 'Veilrift Online',
        family: 'Veilrift',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Gaming Platform',
        theme: {
            mode: 'dark',
            primary: 'hsl(180, 80%, 50%)', // Cyan/Teal
            secondary: 'hsl(200, 60%, 40%)'
        },
        categories: ['Game Designer', 'Community Manager'],
        specs: { backend: 'LOKI', content: 'D&D VTT and Community Hub.', message: 'ALPHA BUILD' }
    },
    'veilrift.io': {
        name: 'Veilrift API',
        family: 'Veilrift',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Developer API',
        theme: { mode: 'dark', primary: 'hsl(180, 80%, 50%)', secondary: 'hsl(200, 60%, 40%)' },
        categories: ['Backend Dev', 'Fullstack Dev'],
        specs: { backend: 'Planned', content: 'API Documentation.', message: 'OFFLINE' }
    },
    'veilrift.dev': {
        name: 'Veilrift Dev',
        family: 'Veilrift',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Dev Tools',
        theme: { mode: 'dark', primary: 'hsl(120, 70%, 40%)', secondary: 'hsl(120, 50%, 20%)' },
        categories: ['Frontend Dev', 'DevOps'],
        specs: { backend: 'Planned', content: 'Development environment.', message: 'OFFLINE' }
    },
    'veilrift-saga.com': {
        name: 'Veilrift Saga',
        family: 'Veilrift',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Narrative Hub',
        theme: { mode: 'dark', primary: 'hsl(260, 60%, 60%)', secondary: 'hsl(260, 40%, 40%)' },
        categories: ['Writer', 'Game Designer'],
        specs: { backend: 'LOKI', content: 'Lore and Story.', message: 'OFFLINE' }
    },

    // ------------------- XI-IO (ENTERPRISE/RESEARCH) -------------------
    // Focus: Business, Law, Science, OS
    'xi-io.com': {
        name: 'XI-IO Prime',
        family: 'XI-IO',
        status: 'production',
        intent: 'Marketplace & OS',
        theme: {
            mode: 'dark',
            primary: 'hsl(220, 20%, 90%)', // Slate/White
            secondary: 'hsl(220, 10%, 40%)'
        },
        categories: ['Startup Founder', 'Investor', 'Product Manager'],
        specs: {
            backend: 'Production (162.217.146.98)',
            content: 'Primary OS for the internet. Search & Recovery.',
            message: 'SYSTEM OPTIMAL'
        }
    },
    'xi-io.ca': {
        name: 'XI-IO Canada',
        family: 'XI-IO',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Gov & Research',
        theme: { mode: 'light', primary: 'hsl(0, 70%, 50%)', secondary: 'hsl(0, 0%, 20%)' },
        categories: ['Lawyer', 'Compliance Officer', 'Public Servant'],
        specs: { backend: 'Planned', content: 'Canadian compliance focus.', message: 'OFFLINE' }
    },
    'xi-io.net': {
        name: 'XI-IO Net',
        family: 'XI-IO',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Network Ops',
        theme: { mode: 'dark', primary: 'hsl(210, 80%, 50%)', secondary: 'hsl(210, 60%, 30%)' },
        categories: ['DevOps', 'Security Engineer'],
        specs: { backend: 'Planned', content: 'Network infrastructure.', message: 'OFFLINE' }
    },
    'xi-io.org': {
        name: 'XI-IO Org',
        family: 'XI-IO',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Non-Profit Research',
        theme: { mode: 'light', primary: 'hsl(160, 50%, 40%)', secondary: 'hsl(160, 30%, 30%)' },
        categories: ['Researcher', 'Data Scientist'],
        specs: { backend: 'Planned', content: 'Open source research.', message: 'OFFLINE' }
    },
    'xi.os': {
        name: 'XI OS',
        family: 'XI-IO',
        status: 'planned',
        badge: 'Q1 2026',
        intent: 'Central Hub',
        theme: { mode: 'dark', primary: 'hsl(270, 80%, 60%)', secondary: 'hsl(270, 60%, 40%)' },
        categories: ['Systems Architect'],
        specs: { backend: 'Planned', content: 'Genesis point.', message: 'CONCEPTUAL' }
    },

    // ------------------- NUMERICAL / LEGACY -------------------
    'vado42.com': {
        name: 'Vado42',
        family: 'Numerical',
        status: 'legacy',
        intent: 'Legacy Services',
        theme: { mode: 'dark', primary: 'hsl(30, 70%, 50%)', secondary: 'hsl(30, 50%, 30%)' },
        categories: ['Legacy User'],
        specs: { backend: 'Legacy', content: 'Maintenance mode.', message: 'ARCHIVED' }
    },
    '8-42s.com': {
        name: '8-42s',
        family: 'Numerical',
        status: 'future',
        badge: 'Q1 2026',
        intent: 'Experimental Beta',
        theme: { mode: 'dark', primary: 'hsl(60, 80%, 50%)', secondary: 'hsl(60, 60%, 30%)' },
        categories: ['Tester'],
        specs: { backend: 'Planned', content: 'Public beta tests.', message: 'OFFLINE' }
    }
};

export const SiteContextProvider = ({ children }) => {
    // Default to xi-io.com if no match
    const [currentDomain, setCurrentDomain] = useState(() => {
        if (typeof window !== 'undefined' && window.localStorage) {
            return localStorage.getItem('xi_current_domain') || 'xi-io.com';
        }
        return 'xi-io.com';
    });

    const [domainData, setDomainData] = useState(DOMAIN_ECOSYSTEM[currentDomain] || DOMAIN_ECOSYSTEM['xi-io.com']);
    const [systemConfig, setSystemConfig] = useState(null);

    // Fetch White-Label Config
    useEffect(() => {
        const fetchConfig = async () => {
            try {
                const configs = await base44.entities.SystemConfig.list();
                if (configs.length > 0) {
                    const config = configs[0];
                    setSystemConfig(config);
                    
                    // Override Domain Data if Config Exists
                    if (config.brand_name) {
                        setDomainData(prev => ({
                            ...prev,
                            name: config.brand_name,
                            theme: {
                                ...prev.theme,
                                primary: config.theme_primary || prev.theme.primary,
                                secondary: config.theme_secondary || prev.theme.secondary
                            }
                        }));
                        // Apply config theme immediately
                        applyTheme({
                            ...DEFAULT_THEME,
                            primary: config.theme_primary || DEFAULT_THEME.primary,
                            secondary: config.theme_secondary || DEFAULT_THEME.secondary
                        });
                    }
                }
            } catch (e) {
                console.error("Failed to load SystemConfig", e);
            }
        };
        fetchConfig();
    }, []);

    // USER THEME STATE
    const [userTheme, setUserTheme] = useState(DEFAULT_THEME);
    const [privacyMode, setPrivacyMode] = useState('private'); // public, private, work
    const [systemStage, setSystemStage] = useState(3); // 1: Protocol, 2: Synth, 3: Sovereign, 4: Seed (Active)
    const [reducedMotion, setReducedMotion] = useState(false);

    useEffect(() => {
        // Broadcast system stage changes to body for global CSS hooks
        if (typeof document !== 'undefined') {
            document.body.dataset.stage = systemStage;
        }
    }, [systemStage]);

    // Load User Theme
    useEffect(() => {
        if (typeof window !== 'undefined') {
            const saved = localStorage.getItem('xi_user_theme');
            if (saved) {
                try {
                    const parsed = JSON.parse(saved);
                    setUserTheme({ ...DEFAULT_THEME, ...parsed });
                } catch (e) {
                    console.error('Failed to parse user theme', e);
                }
            }
        }
    }, []);

    useEffect(() => {
        if (typeof window !== 'undefined') {
            // Apply Domain Theme first (Base)
            applyTheme(domainData.theme);
            // Apply User Theme (Overrides)
            applyTheme(userTheme);
            
            document.title = `${domainData.name} | XI-CONTROL`;
            if (window.localStorage) {
                localStorage.setItem('xi_current_domain', currentDomain);
            }
        }
    }, [currentDomain, domainData, userTheme]);

    // Persist Reduced Motion
    useEffect(() => {
        if (typeof window !== 'undefined' && window.localStorage) {
            const saved = localStorage.getItem('xi_reduced_motion');
            if (saved === 'true') setReducedMotion(true);
        }
    }, []);

    useEffect(() => {
        if (typeof window !== 'undefined' && window.localStorage) {
            localStorage.setItem('xi_reduced_motion', reducedMotion);
        }
    }, [reducedMotion]);

    const rotateContext = (domainKey) => {
        if (DOMAIN_ECOSYSTEM[domainKey]) {
            setCurrentDomain(domainKey);
        }
    };

    const updateUserTheme = (newTheme) => {
        setUserTheme(newTheme);
        localStorage.setItem('xi_user_theme', JSON.stringify(newTheme));
    };

    const resetUserTheme = () => {
        setUserTheme(DEFAULT_THEME);
        localStorage.removeItem('xi_user_theme');
    };

    return (
        <SiteContext.Provider value={{ 
            currentDomain, 
            domainData, 
            rotateContext, 
            ecosystem: DOMAIN_ECOSYSTEM,
            userTheme,
            updateUserTheme,
            resetUserTheme,
            privacyMode,
            setPrivacyMode,
            systemStage,
            setSystemStage,
            systemConfig,
            reducedMotion,
            setReducedMotion
        }}>
            {children}
        </SiteContext.Provider>
    );
};