import React, { useState, useRef } from 'react';
import { Palette, RotateCcw, Activity, Download, Upload, FileJson, Type, Image as ImageIcon, Code } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { 
    OrientingText, IntentText, StateText, 
    SemanticDot, Layer 
} from '@/components/ui/design-system/System';
import { useSiteContext } from './SiteContext';

export default function ThemeManager() {
    const { userTheme: theme, updateUserTheme, resetUserTheme } = useSiteContext();

    const fileInputRef = useRef(null);

    const handleReset = () => {
        resetUserTheme();
    };

    const handleExportTheme = () => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(theme, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", `xi_theme_${Date.now()}.json`);
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
        toast.success("Theme config exported successfully");
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedTheme = JSON.parse(e.target.result);
                // Basic validation: check if it looks like a theme object
                if (typeof importedTheme === 'object') {
                    updateUserTheme({ ...theme, ...importedTheme });
                    import('@/components/identity/themeUtils').then(({applyTheme}) => applyTheme({ ...theme, ...importedTheme }));
                    toast.success("Theme imported and applied");
                } else {
                    toast.error("Invalid theme file format");
                }
            } catch (err) {
                console.error("Theme import error", err);
                toast.error("Failed to parse theme file");
            }
        };
        reader.readAsText(file);
        // Reset input value to allow same file selection again
        event.target.value = '';
    };

    const ColorSlider = ({ label, keyName, dotType }) => (
        <div className="space-y-3">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <SemanticDot type={dotType} />
                    <IntentText className="text-xs uppercase tracking-wide">{label}</IntentText>
                </div>
                <StateText className="font-mono text-xs">{theme[keyName]}°</StateText>
            </div>
            <Slider 
                value={[theme[keyName]]} 
                min={0} 
                max={360} 
                step={1}
                onValueChange={([val]) => updateUserTheme({ ...theme, [keyName]: val })}
                className="py-1"
            />
            {/* Spectrum Preview Line */}
            <div 
                className="h-1 w-full rounded-full opacity-50"
                style={{
                    background: `linear-gradient(to right, 
                        hsl(0, 50%, 50%), 
                        hsl(60, 50%, 50%), 
                        hsl(120, 50%, 50%), 
                        hsl(180, 50%, 50%), 
                        hsl(240, 50%, 50%), 
                        hsl(300, 50%, 50%), 
                        hsl(360, 50%, 50%))`
                }}
            />
        </div>
    );

    const FxSlider = ({ label, keyName, min, max, unit = '' }) => (
        <div className="space-y-3">
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Activity className="w-3 h-3 text-neutral-500" />
                    <IntentText className="text-xs uppercase tracking-wide">{label}</IntentText>
                </div>
                <StateText className="font-mono text-xs">{theme[keyName]}{unit}</StateText>
            </div>
            <Slider 
                value={[theme[keyName]] || [0]} 
                min={min} 
                max={max} 
                step={1}
                onValueChange={([val]) => updateUserTheme({ ...theme, [keyName]: val })}
                className="py-1"
            />
        </div>
    );

    const [prompt, setPrompt] = useState("");
    const [isGenerating, setIsGenerating] = useState(false);
    const [lockBrand, setLockBrand] = useState(false);
    const [activeTab, setActiveTab] = useState("colors");
    
    // Fetch installed themes
    const { data: installedThemes = [] } = useQuery({
        queryKey: ['installed_themes'],
        queryFn: async () => {
            const addons = await base44.entities.InstalledAddon.list();
            const items = await base44.entities.MarketplaceItem.list();
            
            return addons
                .map(addon => {
                    const item = items.find(i => i.id === addon.addon_id);
                    return item && item.category === 'theme' ? { ...item, addonId: addon.id } : null;
                })
                .filter(Boolean);
        },
        initialData: []
    });

    // Mock theme data for the Neon Genesis theme if installed
    const applyInstalledTheme = (themeName) => {
        if (themeName === 'Neon Genesis') {
            const neonTheme = {
                "color-intent": 320, // Neon Pink
                "color-execution": 180, // Cyan
                "color-orientation": 260, // Deep Purple
                "glass-blur": 0, // Sharp edges
                "glass-opacity": 90,
                "glass-border": 100,
                "glass-saturation": 150,
                "bg-pulse-speed": 80,
                "bg-grid-opacity": 40
            };
            updateUserTheme({ ...theme, ...neonTheme });
            import('@/components/identity/themeUtils').then(({applyTheme}) => applyTheme({ ...theme, ...neonTheme }));
            toast.success("Theme Loaded: Neon Genesis");
        }
    };

    const handleGenerateTheme = async () => {
        if (!prompt) return;
        setIsGenerating(true);
        try {
            const { base44 } = await import("@/api/base44Client");
            
            // Call the unified backend gateway instead of direct integration
            const { data } = await base44.functions.invoke('aiGenerate', {
                intent: 'generate_theme',
                input: prompt,
                context: { 
                    lockBrand, 
                    currentIntentHue: theme['color-intent'] 
                }
            });

            if (data.success && data.output) {
                const newTheme = { ...theme, ...data.output };
                updateUserTheme(newTheme);
                import('@/components/identity/themeUtils').then(({applyTheme}) => applyTheme(newTheme));
                import('sonner').then(({toast}) => toast.success("Theme DNA Mutated"));
            } else {
                throw new Error("Theme generation failed");
            }
        } catch (e) {
            console.error(e);
            import('sonner').then(({toast}) => toast.error("Theme Mutation Failed"));
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <Layer level="orientation" className="h-full flex flex-col border border-white/10 rounded-xl overflow-hidden bg-black/40 backdrop-blur-xl">
            <div className="p-4 border-b border-white/5 bg-black/20 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <Palette className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <OrientingText className="font-bold">Theme Synthesis</OrientingText>
                </div>
                <div className="flex gap-2">
                    <input 
                        type="file" 
                        ref={fileInputRef}
                        onChange={handleFileChange} 
                        className="hidden" 
                        accept=".json"
                    />
                    <Button size="icon" variant="ghost" className="h-6 w-6 hover:bg-white/5" onClick={handleImportClick} title="Import Theme JSON">
                        <Upload className="w-3 h-3 text-neutral-500" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-6 w-6 hover:bg-white/5" onClick={handleExportTheme} title="Export Theme JSON">
                        <Download className="w-3 h-3 text-neutral-500" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-6 w-6 hover:bg-white/5" onClick={handleReset} title="Reset to Factory">
                        <RotateCcw className="w-3 h-3 text-neutral-500" />
                    </Button>
                </div>
                </div>

                <div className="flex-1 overflow-hidden flex flex-col">
                    <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
                        <div className="px-6 pt-4 border-b border-white/5">
                            <TabsList className="bg-black/20 w-full justify-start gap-2 h-auto p-1">
                                <TabsTrigger value="colors" className="text-[10px] data-[state=active]:bg-white/10">Colors & FX</TabsTrigger>
                                <TabsTrigger value="typography" className="text-[10px] data-[state=active]:bg-white/10">Typography</TabsTrigger>
                                <TabsTrigger value="assets" className="text-[10px] data-[state=active]:bg-white/10">Brand Assets</TabsTrigger>
                                <TabsTrigger value="advanced" className="text-[10px] data-[state=active]:bg-white/10">Advanced</TabsTrigger>
                            </TabsList>
                        </div>

                        <div className="flex-1 overflow-y-auto p-6 scrollbar-thin scrollbar-thumb-white/10">
                            <TabsContent value="colors" className="mt-0 space-y-8">
                                {/* Installed Themes Section */}
                                {installedThemes.length > 0 && (
                                    <div className="space-y-4">
                                        <OrientingText className="opacity-50 text-[10px] uppercase tracking-widest text-[hsl(var(--color-orientation))]">
                                            Installed Themes
                                        </OrientingText>
                        <div className="grid grid-cols-2 gap-2">
                            {installedThemes.map(t => (
                                <div 
                                    key={t.id} 
                                    onClick={() => applyInstalledTheme(t.name)}
                                    className="p-3 rounded border border-white/10 bg-black/40 hover:border-[hsl(var(--color-execution))] cursor-pointer transition-all flex items-center gap-3"
                                >
                                    <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 to-cyan-500" />
                                    <div>
                                        <div className="text-xs font-bold text-white">{t.name}</div>
                                        <div className="text-[10px] text-neutral-500">By {t.author}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="h-px bg-white/5" />
                    </div>
                )}

                <div className="space-y-4 p-4 rounded-lg bg-[hsl(var(--color-intent))]/5 border border-[hsl(var(--color-intent))]/20">
                    <div className="flex justify-between items-center">
                        <OrientingText className="text-[hsl(var(--color-intent))]">AI BRAND GENERATOR</OrientingText>
                        <div className="flex items-center gap-2">
                            <input 
                                type="checkbox" 
                                id="lockBrand"
                                checked={lockBrand}
                                onChange={(e) => setLockBrand(e.target.checked)}
                                className="rounded border-white/20 bg-black/50 text-[hsl(var(--color-intent))]"
                            />
                            <label htmlFor="lockBrand" className="text-[10px] text-neutral-400 font-mono cursor-pointer select-none">
                                HYBRID MODE (LOCK BRAND COLOR)
                            </label>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <input 
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder={lockBrand ? "e.g. Modern, clean, high-contrast..." : "e.g. Cyberpunk Hedge Fund..."}
                            className="flex-1 bg-black/50 border border-white/10 rounded px-3 py-2 text-xs text-white focus:border-[hsl(var(--color-intent))]"
                        />
                        <Button 
                            size="sm" 
                            onClick={handleGenerateTheme}
                            disabled={isGenerating}
                            className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 text-xs font-bold"
                        >
                            {isGenerating ? '...' : 'GENERATE'}
                        </Button>
                    </div>
                </div>

                <div className="h-px bg-white/5" />
                <div className="space-y-6">
                    <OrientingText className="opacity-50 text-[10px] uppercase tracking-widest text-[hsl(var(--color-orientation))]">
                        Glass Physics
                    </OrientingText>
                    <FxSlider label="Blur Strength" keyName="glass-blur" min={0} max={40} unit="px" />
                    <FxSlider label="Transparency" keyName="glass-opacity" min={0} max={100} unit="%" />
                    <FxSlider label="Border Opacity" keyName="glass-border" min={0} max={100} unit="%" />
                    <FxSlider label="Saturation" keyName="glass-saturation" min={0} max={200} unit="%" />
                </div>

                <div className="h-px bg-white/5" />

                <div className="space-y-6">
                    <OrientingText className="opacity-50 text-[10px] uppercase tracking-widest text-[hsl(var(--color-orientation))]">
                        Visual Cortex (FX)
                    </OrientingText>
                    
                    <FxSlider label="Heartbeat Speed" keyName="bg-pulse-speed" min={0} max={100} unit="bpm" />
                    <FxSlider label="Ring Complexity" keyName="bg-ring-count" min={0} max={24} />
                    <FxSlider label="Ring Width" keyName="bg-ring-width" min={1} max={10} unit="px" />
                    <FxSlider label="Particle Density" keyName="bg-particle-count" min={0} max={200} />
                    <FxSlider label="Grid Opacity" keyName="bg-grid-opacity" min={0} max={100} unit="%" />
                </div>

                <div className="h-px bg-white/5" />

                <div className="space-y-6">
                    <OrientingText className="opacity-50 text-[10px] uppercase tracking-widest text-[hsl(var(--color-orientation))]">
                        Semantic 7 Categories
                    </OrientingText>
                    
                    <ColorSlider label="Orientation (Where)" keyName="color-orientation" dotType="orientation" />
                    <ColorSlider label="Intent (Goal)" keyName="color-intent" dotType="intent" />
                    <ColorSlider label="Execution (Active)" keyName="color-execution" dotType="execution" />
                    <ColorSlider label="Review (Judgment)" keyName="color-review" dotType="review" />
                    <ColorSlider label="Settled (History)" keyName="color-settled" dotType="settled" />
                    <ColorSlider label="Warning (Break)" keyName="color-warning" dotType="warning" />
                    <ColorSlider label="System (Meta)" keyName="color-system" dotType="system" />
                </div>
                </TabsContent>

                <TabsContent value="typography" className="mt-0 space-y-6">
                    <div className="space-y-4">
                        <OrientingText className="opacity-50 text-[10px] uppercase tracking-widest text-[hsl(var(--color-orientation))]">
                            Typeface Selection
                        </OrientingText>
                        <div className="space-y-2">
                            <label className="text-xs text-neutral-400">Heading Font</label>
                            <Select 
                                value={theme['font-heading'] || 'Inter, system-ui, sans-serif'} 
                                onValueChange={(val) => updateUserTheme({ ...theme, 'font-heading': val })}
                            >
                                <SelectTrigger className="bg-black/40 border-white/10 h-8 text-xs">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Inter, system-ui, sans-serif">Inter (Default)</SelectItem>
                                    <SelectItem value="'Playfair Display', serif">Playfair Display</SelectItem>
                                    <SelectItem value="'Space Grotesk', monospace">Space Grotesk</SelectItem>
                                    <SelectItem value="'Courier New', monospace">Courier New</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs text-neutral-400">Body Font</label>
                            <Select 
                                value={theme['font-body'] || 'Inter, system-ui, sans-serif'} 
                                onValueChange={(val) => updateUserTheme({ ...theme, 'font-body': val })}
                            >
                                <SelectTrigger className="bg-black/40 border-white/10 h-8 text-xs">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Inter, system-ui, sans-serif">Inter (Default)</SelectItem>
                                    <SelectItem value="system-ui, sans-serif">System UI</SelectItem>
                                    <SelectItem value="'Roboto', sans-serif">Roboto</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <div className="h-px bg-white/5" />

                    <div className="space-y-4">
                        <OrientingText className="opacity-50 text-[10px] uppercase tracking-widest text-[hsl(var(--color-orientation))]">
                            Scale & Rhythm
                        </OrientingText>
                        <div className="space-y-3">
                            <div className="flex justify-between">
                                <span className="text-xs text-neutral-400">Base Scale</span>
                                <span className="text-xs font-mono text-white">{theme['font-scale'] || 1.0}x</span>
                            </div>
                            <Slider 
                                value={[theme['font-scale'] || 1.0]} 
                                min={0.8} 
                                max={1.4} 
                                step={0.05}
                                onValueChange={([val]) => updateUserTheme({ ...theme, 'font-scale': val })}
                            />
                        </div>
                    </div>
                </TabsContent>

                <TabsContent value="assets" className="mt-0 space-y-6">
                     <div className="p-4 rounded border border-dashed border-white/20 bg-white/5 flex flex-col items-center justify-center gap-2 text-center">
                        <div className="w-12 h-12 rounded bg-black/50 flex items-center justify-center">
                            <ImageIcon className="w-6 h-6 text-neutral-500" />
                        </div>
                        <div>
                            <p className="text-xs font-bold text-white">Upload Logo</p>
                            <p className="text-[10px] text-neutral-500">PNG, SVG (Max 2MB)</p>
                        </div>
                        <Button variant="outline" size="sm" className="h-7 text-xs mt-2">Choose File</Button>
                     </div>

                     <div className="p-4 rounded border border-dashed border-white/20 bg-white/5 flex flex-col items-center justify-center gap-2 text-center">
                        <div className="w-12 h-12 rounded bg-black/50 flex items-center justify-center">
                            <Activity className="w-6 h-6 text-neutral-500" />
                        </div>
                        <div>
                            <p className="text-xs font-bold text-white">Upload Favicon</p>
                            <p className="text-[10px] text-neutral-500">ICO, PNG (32x32)</p>
                        </div>
                        <Button variant="outline" size="sm" className="h-7 text-xs mt-2">Choose File</Button>
                     </div>
                </TabsContent>

                <TabsContent value="advanced" className="mt-0 space-y-4 h-full">
                    <div className="space-y-2 h-full flex flex-col">
                        <div className="flex items-center justify-between">
                            <label className="text-xs text-neutral-400 font-mono">Custom CSS Injection</label>
                            <Code className="w-3 h-3 text-neutral-500" />
                        </div>
                        <Textarea 
                            value={theme['custom-css'] || ''}
                            onChange={(e) => updateUserTheme({ ...theme, 'custom-css': e.target.value })}
                            placeholder=":root { --my-var: 10px; } .my-class { color: red; }"
                            className="flex-1 font-mono text-[10px] bg-black/50 border-white/10 leading-relaxed resize-none p-4"
                        />
                        <p className="text-[10px] text-neutral-500">
                            Warning: Styles injected here override all system defaults.
                        </p>
                    </div>
                </TabsContent>
                </div>
            </Tabs>
        </div>
        </Layer>
    );
}