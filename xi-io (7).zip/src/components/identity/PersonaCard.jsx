import React, { useState, useEffect } from 'react';
import { useAuthority } from '@/components/useAuthority';
import { useGamification } from '@/components/features/GamificationSystem';
import { Activity, Shield, Zap, User, LogIn, Terminal, Settings, LogOut, FileText } from 'lucide-react';
import { cn } from '@/lib/utils';
import { base44 } from '@/api/base44Client';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { IntentText, OrientingText, StateText } from '@/components/ui/design-system/SystemDesign';

export function PersonaCard({ className }) {
    const { role } = useAuthority();
    const { level, xp } = useGamification();
    const [user, setUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const checkAuth = async () => {
            try {
                const currentUser = await base44.auth.me();
                setUser(currentUser);
            } catch (e) {
                setUser(null);
            } finally {
                setIsLoading(false);
            }
        };
        checkAuth();
    }, []);

    // Mock session data for "Actively doing right now"
    const sessionStats = {
        uptime: '00:42:18',
        queries: 14,
        focus: 'High'
    };

    if (isLoading) {
        return <div className="h-full w-full flex items-center justify-center text-xs text-neutral-500 font-mono animate-pulse">Scanning Identity...</div>;
    }

    if (!user) {
        return (
            <div className={cn(
                "h-full w-full flex flex-col gap-4 p-4 rounded-xl bg-black/40 border border-white/5 backdrop-blur-md shadow-inner group transition-all hover:bg-black/50 hover:border-white/10 relative overflow-hidden",
                className
            )}>
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none opacity-20" />
                
                <div className="flex items-center gap-3 relative z-10">
                    <div className="w-10 h-10 rounded-full bg-neutral-900/80 border border-white/10 flex items-center justify-center shadow-lg group-hover:border-[hsl(var(--color-intent))]/30 transition-colors">
                         <User className="w-5 h-5 text-neutral-500 group-hover:text-white transition-colors" />
                    </div>
                    <div>
                        <div className="text-sm font-bold text-white uppercase tracking-wide">Guest</div>
                        <div className="text-[10px] text-neutral-500 font-mono uppercase tracking-wider group-hover:text-[hsl(var(--color-intent))] transition-colors">Not Connected</div>
                    </div>
                </div>
                
                <div className="flex-1 flex flex-col justify-center items-center text-center space-y-2 py-4 border-y border-white/5 bg-neutral-900/20 rounded-md relative z-10">
                     <div className="relative">
                        <div className="absolute inset-0 bg-[hsl(var(--color-intent))] blur-xl opacity-0 group-hover:opacity-20 transition-opacity" />
                        <Shield className="w-8 h-8 text-neutral-600 group-hover:text-[hsl(var(--color-intent))] transition-colors relative z-10" />
                     </div>
                     <p className="text-[10px] text-neutral-400 max-w-[180px] leading-relaxed">
                        Establish uplink to access the Control Plane.
                     </p>
                </div>

                <Button 
                    onClick={() => base44.auth.redirectToLogin()}
                    className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold tracking-wide shadow-[0_0_15px_-5px_hsl(var(--color-intent))] transition-all transform group-hover:scale-[1.02] border-none relative z-10"
                    size="sm"
                >
                    <LogIn className="w-4 h-4 mr-2" />
                    INITIALIZE LINK
                </Button>
            </div>
        );
    }

    return (
        <div className={cn(
            "h-full w-full flex flex-col gap-4 relative",
            className
        )}>
            {/* Identity Card - Using System Components Style */}
            <Link to={createPageUrl('UserProfile')}>
                <div className="group relative p-3 rounded-lg border border-white/5 bg-black/20 backdrop-blur-sm transition-all duration-300 hover:bg-black/40 hover:border-white/10 hover:shadow-lg overflow-hidden">
                    <div className="flex items-center gap-3 relative z-10">
                        <div className="relative shrink-0 transition-transform duration-300 group-hover:scale-105">
                            <div className="w-10 h-10 rounded-md bg-neutral-900/80 border border-white/10 flex items-center justify-center overflow-hidden">
                                {user.avatar_url ? (
                                    <img src={user.avatar_url} alt="User" className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                ) : (
                                    <User className="w-5 h-5 text-neutral-400" />
                                )}
                            </div>
                            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[hsl(var(--color-execution))] border-2 border-neutral-950 shadow-[0_0_8px_hsl(var(--color-execution))]" />
                        </div>
                        <div className="min-w-0 space-y-0.5">
                            <IntentText className="text-sm font-bold truncate group-hover:text-[hsl(var(--color-intent))]">
                                {user.full_name || 'Anonymous User'}
                            </IntentText>
                            <div className="flex items-center gap-2 text-[10px] text-neutral-500 font-mono uppercase tracking-wider">
                                <StateText>{role}</StateText>
                                <span className="w-px h-2 bg-neutral-800" />
                                <span className="text-[hsl(var(--color-review))]">LVL {level}</span>
                            </div>
                        </div>
                    </div>
                    {/* XP Bar Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-neutral-800/50">
                        <div 
                            className="h-full bg-[hsl(var(--color-execution))] shadow-[0_0_5px_hsl(var(--color-execution))]" 
                            style={{ width: `${(xp % 1000) / 10}%` }} 
                        />
                    </div>
                    {/* Hover Glint */}
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 pointer-events-none" />
                </div>
            </Link>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-2">
                <Link to={createPageUrl('Audit')} className="p-2 rounded-md bg-neutral-900/40 border border-white/5 hover:border-white/10 transition-colors group relative overflow-hidden cursor-pointer">
                    <div className="relative z-10">
                        <OrientingText className="text-[9px] text-neutral-600 uppercase tracking-wider mb-0.5 group-hover:text-neutral-400">Session</OrientingText>
                        <StateText className="text-xs font-mono group-hover:text-[hsl(var(--color-intent))]">{sessionStats.uptime}</StateText>
                    </div>
                    <div className="absolute inset-0 bg-[hsl(var(--color-intent))]/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                </Link>
                <div className="p-2 rounded-md bg-neutral-900/40 border border-white/5 hover:border-white/10 transition-colors group relative overflow-hidden">
                    <div className="relative z-10">
                        <OrientingText className="text-[9px] text-neutral-600 uppercase tracking-wider mb-0.5 group-hover:text-neutral-400">Queries</OrientingText>
                        <StateText className="text-xs font-mono group-hover:text-[hsl(var(--color-execution))]">{sessionStats.queries}</StateText>
                    </div>
                    <div className="absolute inset-0 bg-[hsl(var(--color-execution))]/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                </div>
            </div>
                
            {/* Quick Actions (The "Intuitive" part) */}
            <div className="flex items-center gap-2">
                <Link to={createPageUrl('Settings')} className="flex-1">
                    <Button variant="ghost" size="sm" className="w-full h-8 text-[10px] bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white border border-transparent hover:border-white/10 transition-all">
                        <Settings className="w-3 h-3 mr-2" /> CONFIG
                    </Button>
                </Link>
                <Link to={createPageUrl('Docs')} className="flex-1">
                    <Button variant="ghost" size="sm" className="w-full h-8 text-[10px] bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white border border-transparent hover:border-white/10 transition-all">
                        <FileText className="w-3 h-3 mr-2" /> MANUAL
                    </Button>
                </Link>
                <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 bg-white/5 hover:bg-[hsl(var(--color-error))]/10 text-neutral-400 hover:text-[hsl(var(--color-error))] border border-transparent hover:border-[hsl(var(--color-error))]/20 transition-all"
                    onClick={() => base44.auth.logout()}
                    title="Disconnect"
                >
                    <LogOut className="w-3 h-3" />
                </Button>
            </div>

            {/* Active Protocol */}
             <div className="flex-1 rounded-lg bg-gradient-to-br from-neutral-900/80 to-neutral-900/40 border border-white/5 p-3 flex flex-col relative overflow-hidden group hover:border-[hsl(var(--color-intent))]/20 transition-all cursor-default shadow-sm">
                {/* Protocol Scan Line */}
                <div className="absolute top-0 left-0 w-full h-[1px] bg-[hsl(var(--color-intent))]/50 shadow-[0_0_10px_hsl(var(--color-intent))] translate-y-[-100%] group-hover:animate-scan-vertical opacity-0 group-hover:opacity-100" />
                
                <div className="absolute top-2 right-2 p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Terminal className="w-3 h-3 text-[hsl(var(--color-intent))]" />
                </div>
                <div className="flex items-center gap-2 mb-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--color-intent))] animate-pulse shadow-[0_0_5px_currentColor]" />
                    <OrientingText className="text-[9px] font-bold text-[hsl(var(--color-intent))] uppercase tracking-widest">Active Protocol</OrientingText>
                </div>
                <StateText className="text-[11px] leading-relaxed text-neutral-400 font-mono group-hover:text-neutral-300 transition-colors">
                    Synthesizing intelligence from vector analysis.
                </StateText>
            </div>
        </div>
    );
}