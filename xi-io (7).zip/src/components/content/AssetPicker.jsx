import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Image as ImageIcon, Box } from 'lucide-react';
import { OrientingText, StateText } from '@/components/ui/design-system/System';

export function AssetPicker({ open, onOpenChange, onSelect }) {
    const [search, setSearch] = useState('');

    const { data: assets = [] } = useQuery({
        queryKey: ['mediaAssets'],
        queryFn: async () => {
            if (!base44.entities.MediaAsset) return [];
            return await base44.entities.MediaAsset.list();
        },
        initialData: []
    });

    const filteredAssets = assets.filter(a => 
        a.name.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="bg-[hsl(var(--layer-state))] border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-intent))] max-w-3xl h-[600px] flex flex-col p-0 gap-0">
                <DialogHeader className="p-4 border-b border-[hsl(var(--layer-orientation))]">
                    <DialogTitle className="flex items-center gap-2">
                        <Box className="w-5 h-5 text-[hsl(var(--color-intent))]" />
                        Asset Matrix
                    </DialogTitle>
                </DialogHeader>
                
                <div className="p-4 border-b border-[hsl(var(--layer-orientation))] bg-[hsl(var(--void))]">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--fg-orientation))]" />
                        <Input 
                            placeholder="Search assets..." 
                            className="pl-9 bg-[hsl(var(--layer-orientation))] border-none h-10"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 bg-[hsl(var(--void))]">
                    <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
                        {filteredAssets.map(asset => (
                            <div 
                                key={asset.id} 
                                className="group relative aspect-square rounded-lg overflow-hidden border border-[hsl(var(--layer-orientation))] hover:border-[hsl(var(--color-intent))] cursor-pointer transition-all"
                                onClick={() => onSelect(asset.url)}
                            >
                                <img src={asset.url} alt={asset.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                                <div className="absolute inset-x-0 bottom-0 bg-black/60 backdrop-blur-sm p-2 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                                    <StateText className="text-white truncate">{asset.name}</StateText>
                                    <div className="text-[9px] text-white/70 uppercase">{asset.type}</div>
                                </div>
                            </div>
                        ))}
                        {filteredAssets.length === 0 && (
                            <div className="col-span-full py-12 flex flex-col items-center justify-center opacity-50">
                                <ImageIcon className="w-12 h-12 mb-4 text-[hsl(var(--fg-orientation))]" />
                                <OrientingText>No assets found</OrientingText>
                            </div>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}