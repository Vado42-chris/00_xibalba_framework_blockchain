import React, { useState, useEffect } from 'react';
import { OrientingText, IntentText, StateText, SemanticDot } from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Shield, Search, Zap, Eye, Split, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { motion } from 'framer-motion';
import HybridizationEngine from './auditor/HybridizationEngine';

export default function XibalbaAuditor({ page, onUpdate, activeVariantId, onSelectVariant }) {
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [score, setScore] = useState(page?.audit_score || 0);
    
    // Xibalba Process Stages (10 Body Audit)
    const stages = [
        { id: 1, name: "Structural Integrity", icon: Shield, score: 85 },
        { id: 2, name: "Semantic Clarity", icon: Search, score: 92 },
        { id: 3, name: "Visual Hierarchy", icon: Eye, score: 78 },
        { id: 4, name: "Performance Impact", icon: Zap, score: 95 },
        { id: 5, name: "Conversion Potential", icon: Split, score: 60 },
        { id: 6, name: "Accessibility Compliance", icon: CheckCircle2, score: 88 },
        { id: 7, name: "SEO Optimization", icon: Search, score: 70 },
        { id: 8, name: "Mobile Responsiveness", icon: Zap, score: 100 },
        { id: 9, name: "Security Posture", icon: Shield, score: 100 },
        { id: 10, name: "Brand Resonance", icon: Eye, score: 82 },
    ];

    const runAudit = () => {
        setIsAnalyzing(true);
        // Simulate "Fractalization" process
        setTimeout(() => {
            const newScore = Math.floor(Math.random() * 20) + 80;
            setScore(newScore);
            onUpdate({
                ...page,
                audit_score: newScore,
                audit_report: {
                    seo_score: 85,
                    readability_score: 92,
                    performance_score: 95,
                    issues: ["Missing meta description on variant B", "H1 hierarchy unclear in mobile view"]
                }
            });
            setIsAnalyzing(false);
        }, 2000);
    };

    return (
        <div className="h-full flex flex-col bg-neutral-950 border-l border-white/5 w-80 shrink-0">
            <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    <OrientingText>XIBALBA AUDIT</OrientingText>
                </div>
                <StateText className="text-xl font-bold">{score}%</StateText>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-6">
                
                {/* Main Action */}
                <Button 
                    onClick={runAudit}
                    disabled={isAnalyzing}
                    className="w-full bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 font-bold"
                >
                    {isAnalyzing ? "FRACTALIZING..." : "INITIATE 10-BODY AUDIT"}
                </Button>

                {/* 10 Body Breakdown */}
                <div className="space-y-3">
                    <OrientingText className="text-[10px] opacity-50 mb-2">FRACTAL ANALYSIS</OrientingText>
                    {stages.map((stage, i) => (
                        <motion.div 
                            key={stage.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.05 }}
                            className="flex items-center gap-3 p-2 rounded bg-neutral-900/50 border border-white/5"
                        >
                            <stage.icon className="w-3 h-3 text-neutral-500" />
                            <div className="flex-1">
                                <div className="flex justify-between mb-1">
                                    <span className="text-[10px] text-neutral-300 font-medium">{stage.name}</span>
                                    <span className="text-[10px] text-neutral-500">{stage.score}%</span>
                                </div>
                                <Progress value={stage.score} className="h-1 bg-neutral-800" indicatorClassName="bg-[hsl(var(--color-execution))]" />
                            </div>
                        </motion.div>
                    ))}
                </div>

                {/* A/B Testing Section (Hybridization) */}
                <div className="pt-4 border-t border-white/5">
                    <HybridizationEngine 
                        page={page} 
                        activeVariantId={activeVariantId} 
                        onSelectVariant={onSelectVariant}
                        onUpdatePage={onUpdate}
                    />
                </div>

                {/* Issues List */}
                {page?.audit_report?.issues?.length > 0 && (
                    <div className="pt-4 border-t border-white/5">
                        <OrientingText className="text-[10px] opacity-50 mb-2">CRITICAL FINDINGS</OrientingText>
                        <div className="space-y-2">
                            {page.audit_report.issues.map((issue, i) => (
                                <div key={i} className="flex gap-2 text-xs text-red-400 bg-red-950/10 p-2 rounded border border-red-500/20">
                                    <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                                    <span>{issue}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

function Badge({ children, className, variant }) {
    return (
        <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${className} ${variant === 'secondary' ? 'bg-neutral-800 text-neutral-400' : ''}`}>
            {children}
        </span>
    );
}