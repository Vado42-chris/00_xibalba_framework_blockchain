import React, { useState } from 'react';
import { ChevronRight, Check, Palette, Type, MousePointer2, Layout, Sliders, ChevronLeft } from 'lucide-react';
import { cn } from "@/lib/utils";
import { OrientingText } from '@/components/ui/design-system/System';

export default function SiteStyles({ onClose, isOpen }) {
    const [view, setView] = useState('main'); // main, colors, fonts, etc.
    const [theme, setTheme] = useState({
        headingFont: 'Heading',
        paragraphFont: 'Paragraph',
        primaryColor: '#00FFFF',
        secondaryColor: '#000000',
        backgroundColor: '#FFFFFF',
    });

    const MenuHeader = ({ title, back }) => (
        <div className="flex items-center gap-2 mb-6 cursor-pointer" onClick={back || onClose}>
            {back ? <ChevronLeft className="w-4 h-4" /> : <div className="w-4 h-4" />}
            <span className="font-bold text-lg">{title}</span>
        </div>
    );

    const MenuItem = ({ label, icon: Icon, onClick, preview }) => (
        <div 
            onClick={onClick}
            className="flex items-center justify-between p-4 bg-neutral-100 hover:bg-neutral-200 rounded-lg cursor-pointer transition-colors mb-2"
        >
            <div className="flex items-center gap-3">
                {Icon && <Icon className="w-4 h-4 text-neutral-500" />}
                <span className="text-sm font-medium">{label}</span>
            </div>
            {preview ? preview : <ChevronRight className="w-4 h-4 text-neutral-400" />}
        </div>
    );

    const ColorPreview = ({ colors }) => (
        <div className="flex rounded overflow-hidden h-6 w-24 border border-neutral-200">
            {colors.map((c, i) => (
                <div key={i} className="flex-1 h-full" style={{ backgroundColor: c }} />
            ))}
        </div>
    );

    return (
        <div className={cn(
            "fixed inset-y-0 left-0 w-80 bg-white text-black shadow-2xl z-50 transform transition-transform duration-300 flex flex-col",
            isOpen ? "translate-x-0" : "-translate-x-full"
        )}>
            <div className="p-6 border-b border-neutral-100 flex justify-between items-center">
                <span className="text-xs font-bold uppercase tracking-widest text-neutral-500">Site Styles</span>
                <button onClick={onClose} className="text-xs font-bold hover:underline">CLOSE</button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 xi-scroll">
                {view === 'main' && (
                    <div className="space-y-6 animate-in slide-in-from-left duration-200">
                        <h2 className="text-2xl font-bold mb-6">Site Styles</h2>
                        
                        <div className="space-y-2">
                            <span className="text-xs font-bold text-neutral-400 uppercase">Themes</span>
                            <div className="bg-neutral-100 p-4 rounded-xl flex items-center justify-between">
                                <span className="text-3xl font-serif">Aa</span>
                                <div className="flex gap-2 items-center">
                                    <div className="flex h-8 w-24 rounded overflow-hidden">
                                        <div className="w-1/4 bg-white"></div>
                                        <div className="w-1/4 bg-neutral-200"></div>
                                        <div className="w-1/4 bg-cyan-400"></div>
                                        <div className="w-1/4 bg-black"></div>
                                    </div>
                                    <div className="bg-black text-white text-[10px] font-bold px-2 py-1 rounded">BUTTON</div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-1">
                            <MenuItem 
                                label="Fonts" 
                                preview={
                                    <div className="text-right">
                                        <div className="text-lg font-serif leading-none">Heading</div>
                                        <div className="text-[10px] text-neutral-500">This is your paragraph.</div>
                                    </div>
                                }
                            />
                            <MenuItem 
                                label="Colors" 
                                onClick={() => setView('colors')}
                                preview={<ColorPreview colors={['#FFFFFF', '#E5E5E5', '#06B6D4', '#333333', '#000000']} />}
                            />
                            <MenuItem 
                                label="Buttons" 
                                preview={<div className="bg-black text-white text-[10px] font-bold px-3 py-1.5 uppercase">BUTTON</div>}
                            />
                            <MenuItem 
                                label="Forms" 
                                preview={
                                    <div className="flex items-center gap-2 bg-neutral-200 px-2 py-1 rounded text-[10px] text-neutral-600 w-24">
                                        Text <div className="ml-auto w-3 h-3 bg-black rounded-sm flex items-center justify-center"><Check className="w-2 h-2 text-white" /></div>
                                    </div>
                                }
                            />
                            
                            <div className="pt-4 mt-4 border-t border-neutral-100">
                                <MenuItem label="Miscellaneous" />
                            </div>
                        </div>
                    </div>
                )}

                {view === 'colors' && (
                    <div className="space-y-6 animate-in slide-in-from-right duration-200">
                        <MenuHeader title="Colors" back={() => setView('main')} />
                        
                        <div className="space-y-6">
                            <div>
                                <h3 className="font-bold text-lg mb-1">Edit Color Theme</h3>
                                <p className="text-xs text-neutral-500 leading-relaxed">Changes you make will affect all sections that use this color theme.</p>
                            </div>

                            <div className="bg-black text-white p-3 rounded flex justify-between items-center">
                                <span className="font-bold text-cyan-400">Aa</span>
                                <span className="text-[10px] font-bold text-cyan-400">CURRENT</span>
                            </div>

                            <div className="space-y-4">
                                <ColorSection title="HEADER">
                                    <ColorRow label="Site Title" color="#06B6D4" />
                                    <ColorRow label="Navigation Links" color="#06B6D4" />
                                </ColorSection>

                                <ColorSection title="SITEWIDE">
                                    <ColorRow label="Section Background" color="#000000" />
                                    <ColorRow label="Background Overlay" color="#000000" />
                                    <ColorRow label="Inset Border" color="#E5E5E5" />
                                    <ColorRow label="Section Divider Stroke" color="#06B6D4" />
                                </ColorSection>

                                <ColorSection title="TEXT">
                                    <ColorRow label="Heading (Extra Large)" color="#06B6D4" />
                                    <ColorRow label="Heading (Large)" color="#06B6D4" />
                                    <ColorRow label="Heading (Medium)" color="#06B6D4" />
                                    <ColorRow label="Heading (Small)" color="#06B6D4" />
                                    <ColorRow label="Paragraph (Large)" color="#FFFFFF" />
                                    <ColorRow label="Paragraph (Medium)" color="#FFFFFF" />
                                    <ColorRow label="Paragraph (Small)" color="#FFFFFF" />
                                    <ColorRow label="Text Highlight" color="#06B6D4" />
                                </ColorSection>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

const ColorSection = ({ title, children }) => (
    <div className="space-y-3">
        <span className="text-[10px] font-bold uppercase text-neutral-400 tracking-wider">{title}</span>
        <div className="space-y-3">
            {children}
        </div>
    </div>
);

const ColorRow = ({ label, color }) => (
    <div className="flex items-center justify-between group cursor-pointer">
        <span className="text-xs font-medium text-neutral-700 group-hover:text-black">{label}</span>
        <div className="w-5 h-5 rounded-full border border-neutral-200 shadow-sm" style={{ backgroundColor: color }} />
    </div>
);