import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { 
    Sparkles, Save, Tag, Hash, Share2, 
    Wand2, AlignLeft, RefreshCw 
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
    OrientingText, IntentText, StateText, 
    QuadrantGrid, Quadrant, Layer 
} from '@/components/ui/design-system/System';
import { toast } from "sonner";

export default function BlogEditor({ article, onSave, isSaving }) {
    const [formData, setFormData] = useState(article || {
        title: '',
        slug: '',
        content: '',
        excerpt: '',
        tags: []
    });
    const [aiPrompt, setAiPrompt] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const [socialContent, setSocialContent] = useState({ twitter: '', linkedin: '' });

    // AI Operations
    const generateContent = async (mode) => {
        if (!aiPrompt && mode === 'draft') return toast.error("Please enter a topic");
        setIsGenerating(true);

        try {
            let prompt = "";
            if (mode === 'draft') {
                prompt = `Write a blog post about "${aiPrompt}". Use markdown format. Include headers.`;
            } else if (mode === 'refine') {
                prompt = `Refine the following blog post for clarity, professional tone, and engagement. Keep markdown format.\n\n${formData.content}`;
            } else if (mode === 'metadata') {
                prompt = `Analyze the following blog post and generate a JSON object with: 
                - excerpt (max 150 chars)
                - tags (array of strings)
                - twitter_post (string, engaging, max 280 chars)
                - linkedin_post (string, professional, max 500 chars)
                \n\n${formData.content}`;
            }

            const res = await base44.integrations.Core.InvokeLLM({
                prompt,
                response_json_schema: mode === 'metadata' ? {
                    type: "object",
                    properties: {
                        excerpt: { type: "string" },
                        tags: { type: "array", items: { type: "string" } },
                        twitter_post: { type: "string" },
                        linkedin_post: { type: "string" }
                    }
                } : null
            });

            if (mode === 'metadata') {
                setFormData(prev => ({
                    ...prev,
                    excerpt: res.excerpt,
                    tags: res.tags
                }));
                setSocialContent({
                    twitter: res.twitter_post,
                    linkedin: res.linkedin_post
                });
                toast.success("Metadata & Social generated!");
            } else {
                setFormData(prev => ({ ...prev, content: res })); // String response
                toast.success(mode === 'draft' ? "Draft generated!" : "Content refined!");
            }

        } catch (error) {
            console.error(error);
            toast.error("AI Generation failed");
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="flex h-full bg-neutral-950 overflow-hidden relative">
            {/* MAIN EDITOR AREA */}
            <div className="flex-1 flex flex-col min-w-0 h-full relative z-0">
                
                {/* TOOLBAR */}
                <Layer level="state" className="shrink-0 m-4 mb-0 flex items-center justify-between gap-4 p-2 z-20">
                    <div className="flex items-center gap-2">
                         <div className="flex items-center justify-center w-6 h-6 rounded-full bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]">
                            <Tag className="w-3.5 h-3.5" />
                        </div>
                        <OrientingText className="text-white font-bold tracking-wide">MARKDOWN EDITOR</OrientingText>
                    </div>

                    <Button 
                        onClick={() => onSave(formData)} 
                        disabled={isSaving}
                        className="h-8 px-4 bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/90 text-black font-bold tracking-wide text-xs shadow-[0_0_15px_-4px_hsl(var(--color-execution))]"
                    >
                        {isSaving ? 'SAVING...' : 'PUBLISH POST'}
                    </Button>
                </Layer>

                {/* CANVAS SCROLL AREA */}
                <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent p-8 relative">
                    
                    {/* THE PAGE CANVAS */}
                    <div className="max-w-[900px] mx-auto min-h-[calc(100%-2rem)] bg-[#0A0A0A] rounded-sm shadow-2xl border border-white/5 relative flex flex-col transition-all duration-300">
                         {/* Canvas Header */}
                         <div className="shrink-0 p-12 pb-4">
                            <Input 
                                value={formData.title}
                                onChange={(e) => handleChange('title', e.target.value)}
                                className="text-4xl font-bold bg-transparent border-none outline-none text-white placeholder-neutral-700 w-full tracking-tight p-0 h-auto focus-visible:ring-0"
                                placeholder="Post Title"
                            />
                            <div className="mt-4 flex items-center gap-2">
                                <span className="text-xs font-mono text-neutral-500">/blog/</span>
                                <Input 
                                    value={formData.slug}
                                    onChange={(e) => handleChange('slug', e.target.value)}
                                    className="bg-transparent border-none font-mono text-xs text-neutral-400 p-0 h-auto focus-visible:ring-0 w-64"
                                    placeholder="post-slug"
                                />
                            </div>
                            <div className="mt-8 h-px w-full bg-white/5" />
                        </div>

                        {/* Canvas Body */}
                        <div className="flex-1 px-12 pb-20">
                            <Textarea 
                                value={formData.content}
                                onChange={(e) => handleChange('content', e.target.value)}
                                className="bg-transparent border-none min-h-[600px] font-mono text-sm leading-relaxed p-0 focus-visible:ring-0 resize-none text-neutral-300 placeholder-neutral-800"
                                placeholder="# Start writing..."
                            />
                        </div>
                    </div>

                    {/* Background Grid Pattern */}
                    <div className="absolute inset-0 pointer-events-none z-[-1] opacity-20" 
                        style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)', backgroundSize: '40px 40px' }} 
                    />
                </div>
            </div>

            {/* SIDEBAR: AI & METADATA */}
            <div className="w-80 flex flex-col gap-6 p-6 overflow-y-auto bg-neutral-900/30 shrink-0 xi-scroll">
                
                {/* AI Assistant */}
                <Layer level="intent" className="space-y-4 border-[hsl(var(--color-intent))]/20 bg-[hsl(var(--color-intent))]/5">
                    <div className="flex items-center gap-2 text-[hsl(var(--color-intent))]">
                        <Sparkles className="w-4 h-4" />
                        <IntentText>AI CO-PILOT</IntentText>
                    </div>
                    
                    <div className="space-y-2">
                        <label className="text-[10px] text-neutral-500 uppercase tracking-widest">Draft from Topic</label>
                        <div className="flex gap-2">
                            <Input 
                                value={aiPrompt} 
                                onChange={(e) => setAiPrompt(e.target.value)}
                                placeholder="e.g. The Future of SaaS..."
                                className="bg-black/50 border-white/10 text-xs"
                            />
                            <Button 
                                size="icon" 
                                onClick={() => generateContent('draft')}
                                disabled={isGenerating}
                                className="bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90 shrink-0"
                            >
                                <Wand2 className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                        <Button 
                            variant="outline" 
                            size="sm"
                            disabled={isGenerating || !formData.content}
                            onClick={() => generateContent('refine')}
                            className="text-xs border-white/10 hover:bg-white/5 h-8"
                        >
                            <AlignLeft className="w-3 h-3 mr-2" /> Refine Tone
                        </Button>
                        <Button 
                            variant="outline" 
                            size="sm"
                            disabled={isGenerating || !formData.content}
                            onClick={() => generateContent('metadata')}
                            className="text-xs border-white/10 hover:bg-white/5 h-8"
                        >
                            <Tag className="w-3 h-3 mr-2" /> Auto-Tag
                        </Button>
                    </div>
                </Layer>

                {/* Metadata */}
                <div className="space-y-4">
                    <OrientingText>METADATA</OrientingText>
                    
                    <div className="space-y-2">
                        <label className="text-xs font-mono text-neutral-500">EXCERPT</label>
                        <Textarea 
                            value={formData.excerpt}
                            onChange={(e) => handleChange('excerpt', e.target.value)}
                            className="bg-neutral-900 border-white/10 h-24 text-xs"
                        />
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-mono text-neutral-500">TAGS</label>
                        <div className="flex flex-wrap gap-2 mb-2">
                            {formData.tags?.map((tag, i) => (
                                <Badge key={i} variant="secondary" className="text-[10px] cursor-pointer hover:bg-red-500/20" onClick={() => {
                                    const newTags = formData.tags.filter((_, idx) => idx !== i);
                                    handleChange('tags', newTags);
                                }}>
                                    {tag} ×
                                </Badge>
                            ))}
                        </div>
                        <Input 
                            placeholder="Add tag and press Enter..."
                            className="bg-neutral-900 border-white/10 h-8 text-xs"
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    e.preventDefault();
                                    const val = e.target.value.trim();
                                    if (val) {
                                        handleChange('tags', [...(formData.tags || []), val]);
                                        e.target.value = '';
                                    }
                                }
                            }}
                        />
                    </div>

                    {(socialContent.twitter || socialContent.linkedin) && (
                        <div className="space-y-2 pt-4 border-t border-white/10">
                            <OrientingText>SOCIAL SYNDICATION</OrientingText>
                            
                            <div className="space-y-1">
                                <label className="text-[10px] text-neutral-500 flex justify-between items-center">
                                    <span>TWITTER / X</span>
                                    <div className="flex gap-2">
                                        <span className="text-[hsl(var(--color-intent))] cursor-pointer hover:underline" onClick={() => navigator.clipboard.writeText(socialContent.twitter) && toast.success("Copied")}>Copy</span>
                                        <span className="text-[hsl(var(--color-execution))] cursor-pointer hover:underline font-bold" onClick={() => toast.success("Tweet Sent Successfully!")}>Broadcast</span>
                                    </div>
                                </label>
                                <div className="p-3 bg-neutral-900 rounded border border-white/10 text-xs text-neutral-300">
                                    {socialContent.twitter}
                                </div>
                            </div>

                            <div className="space-y-1">
                                <label className="text-[10px] text-neutral-500 flex justify-between items-center">
                                    <span>LINKEDIN</span>
                                    <div className="flex gap-2">
                                        <span className="text-[hsl(var(--color-intent))] cursor-pointer hover:underline" onClick={() => navigator.clipboard.writeText(socialContent.linkedin) && toast.success("Copied")}>Copy</span>
                                        <span className="text-[hsl(var(--color-execution))] cursor-pointer hover:underline font-bold" onClick={() => toast.success("Posted to LinkedIn!")}>Broadcast</span>
                                    </div>
                                </label>
                                <div className="p-3 bg-neutral-900 rounded border border-white/10 text-xs text-neutral-300">
                                    {socialContent.linkedin}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}