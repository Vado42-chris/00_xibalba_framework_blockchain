import React, { useState } from 'react';
import { OrientingText, StateText } from '@/components/ui/design-system/System';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Split, Plus, Trash2, Copy, BarChart3, FlaskConical } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from "@/components/ui/input";

export default function HybridizationEngine({ page, activeVariantId, onSelectVariant, onUpdatePage }) {
    const [isCreating, setIsCreating] = useState(false);
    const [newVariantName, setNewVariantName] = useState('');

    const variants = page?.ab_testing?.variants || [];
    const isControl = !activeVariantId;

    const handleCreateVariant = () => {
        const newVariant = {
            id: `var_${Date.now()}`,
            name: newVariantName || `Variant ${variants.length + 1}`,
            traffic_weight: 0,
            content_overrides: {
                content: page.content,
                blocks: page.blocks
            }
        };

        const updatedPage = {
            ...page,
            ab_testing: {
                ...page.ab_testing,
                enabled: true,
                variants: [...variants, newVariant]
            }
        };

        onUpdatePage(updatedPage);
        setNewVariantName('');
        setIsCreating(false);
        onSelectVariant(newVariant.id);
    };

    const handleDeleteVariant = (e, variantId) => {
        e.stopPropagation();
        const updatedPage = {
            ...page,
            ab_testing: {
                ...page.ab_testing,
                variants: variants.filter(v => v.id !== variantId)
            }
        };
        onUpdatePage(updatedPage);
        if (activeVariantId === variantId) {
            onSelectVariant(null);
        }
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <FlaskConical className="w-4 h-4 text-[hsl(var(--color-execution))]" />
                    <OrientingText>HYBRIDIZATION ENGINE</OrientingText>
                </div>
                <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setIsCreating(true)}
                    className="h-6 text-[10px] hover:text-[hsl(var(--color-intent))]"
                >
                    <Plus className="w-3 h-3 mr-1" /> New Vector
                </Button>
            </div>

            <div className="space-y-2">
                {/* Control Group */}
                <div 
                    onClick={() => onSelectVariant(null)}
                    className={`p-3 rounded border transition-all cursor-pointer relative overflow-hidden group ${
                        isControl 
                        ? 'bg-neutral-900 border-[hsl(var(--color-execution))]' 
                        : 'bg-neutral-950 border-white/5 hover:border-white/20'
                    }`}
                >
                    <div className="flex justify-between items-center relative z-10 mb-2">
                        <div className="flex items-center gap-2">
                            <Split className="w-3 h-3 text-neutral-500" />
                            <span className={`text-xs font-bold ${isControl ? 'text-white' : 'text-neutral-400'}`}>
                                Control (Base)
                            </span>
                        </div>
                        {isControl && <Badge variant="outline" className="text-[10px] border-[hsl(var(--color-execution))] text-[hsl(var(--color-execution))]">Active Editing</Badge>}
                    </div>
                    
                    <div className="flex items-center justify-between text-[10px] text-neutral-500 relative z-10">
                        <div className="flex items-center gap-1">
                            <BarChart3 className="w-3 h-3" />
                            <span>Traffic: {100 - variants.reduce((acc, v) => acc + (v.traffic_weight || 0), 0)}%</span>
                        </div>
                        <div className="flex items-center gap-1">
                            <span>Conv: 2.4%</span>
                        </div>
                    </div>
                </div>

                {/* Variants */}
                <AnimatePresence>
                    {variants.map(variant => {
                        const isActive = activeVariantId === variant.id;
                        return (
                            <motion.div
                                key={variant.id}
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                onClick={() => onSelectVariant(variant.id)}
                                className={`p-3 rounded border transition-all cursor-pointer relative overflow-hidden group ${
                                    isActive 
                                    ? 'bg-neutral-900 border-[hsl(var(--color-intent))]' 
                                    : 'bg-neutral-950 border-white/5 hover:border-white/20'
                                }`}
                            >
                                <div className="flex justify-between items-center relative z-10 mb-2">
                                    <div className="flex items-center gap-2">
                                        <Copy className="w-3 h-3 text-neutral-500" />
                                        <span className={`text-xs font-medium ${isActive ? 'text-white' : 'text-neutral-400'}`}>
                                            {variant.name}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                        {isActive && <Badge variant="outline" className="text-[10px] border-[hsl(var(--color-intent))] text-[hsl(var(--color-intent))]">Editing</Badge>}
                                        <Button
                                            size="icon"
                                            variant="ghost"
                                            className="h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity text-neutral-500 hover:text-red-400"
                                            onClick={(e) => handleDeleteVariant(e, variant.id)}
                                        >
                                            <Trash2 className="w-3 h-3" />
                                        </Button>
                                    </div>
                                </div>

                                <div className="space-y-2 relative z-10">
                                    <div className="flex items-center justify-between text-[10px] text-neutral-500">
                                        <span>Traffic Allocation</span>
                                        <span>{variant.traffic_weight || 0}%</span>
                                    </div>
                                    <Slider 
                                        defaultValue={[variant.traffic_weight || 0]} 
                                        max={100} 
                                        step={1}
                                        className="py-1"
                                        onValueChange={(vals) => {
                                            const updated = variants.map(v => v.id === variant.id ? {...v, traffic_weight: vals[0]} : v);
                                            onUpdatePage({...page, ab_testing: {...page.ab_testing, variants: updated}});
                                        }}
                                        onClick={(e) => e.stopPropagation()}
                                    />
                                </div>
                            </motion.div>
                        );
                    })}
                </AnimatePresence>

                {/* New Variant Input */}
                {isCreating && (
                    <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3 rounded bg-neutral-900 border border-white/10 space-y-3"
                    >
                        <Input 
                            value={newVariantName}
                            onChange={(e) => setNewVariantName(e.target.value)}
                            placeholder="Variant Name (e.g. 'Aggressive Hero')"
                            className="h-8 text-xs bg-neutral-950 border-white/10"
                            autoFocus
                        />
                        <div className="flex justify-end gap-2">
                            <Button size="sm" variant="ghost" className="h-6 text-[10px]" onClick={() => setIsCreating(false)}>Cancel</Button>
                            <Button size="sm" className="h-6 text-[10px] bg-[hsl(var(--color-intent))]" onClick={handleCreateVariant}>Create</Button>
                        </div>
                    </motion.div>
                )}
            </div>
        </div>
    );
}