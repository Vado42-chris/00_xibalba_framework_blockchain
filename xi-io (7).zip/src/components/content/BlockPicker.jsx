import React, { useState } from 'react';
import { 
    Type, Image as ImageIcon, MousePointer2, Video, FileInput, Music, Mail, 
    LayoutList, Shapes, MoveVertical, Minus, Quote, MapPin, Download, 
    FileCode, Code, MoreHorizontal, Utensils, Calendar, Share2, BarChart3,
    ShoppingBag, Heart, Clock, Tag, Search, Link, Archive, Layers,
    Instagram, ShoppingCart, Music2, Radio, Rss, Gift
} from 'lucide-react';
import { cn } from "@/lib/utils";
import { OrientingText } from '@/components/ui/design-system/System';

const BLOCK_CATEGORIES = [
    {
        title: "Basic",
        items: [
            { type: 'text', label: 'Text', icon: Type },
            { type: 'image', label: 'Image', icon: ImageIcon },
            { type: 'button', label: 'Button', icon: MousePointer2 },
            { type: 'video', label: 'Video', icon: Video },
            { type: 'form', label: 'Form', icon: FileInput },
            { type: 'audio', label: 'Audio', icon: Music },
            { type: 'newsletter', label: 'Newsletter', icon: Mail },
            { type: 'accordion', label: 'Accordion', icon: LayoutList },
            { type: 'shape', label: 'Shape', icon: Shapes },
            { type: 'scrolling', label: 'Scrolling', icon: MoveVertical },
            { type: 'line', label: 'Line', icon: Minus },
            { type: 'quote', label: 'Quote', icon: Quote },
            { type: 'map', label: 'Map', icon: MapPin },
            { type: 'embed', label: 'Embed', icon: Download },
            { type: 'markdown', label: 'Markdown', icon: FileCode },
            { type: 'code', label: 'Code', icon: Code },
            { type: 'summary', label: 'Summary', icon: MoreHorizontal },
            { type: 'menu', label: 'Menu', icon: Utensils },
            { type: 'calendar', label: 'Calendar', icon: Calendar },
            { type: 'social', label: 'Social Links', icon: Share2 },
            { type: 'chart', label: 'Chart', icon: BarChart3 },
        ]
    },
    {
        title: "Business",
        items: [
            { type: 'product', label: 'Product', icon: ShoppingBag },
            { type: 'donation', label: 'Donation', icon: Heart },
            { type: 'scheduling', label: 'Scheduling', icon: Clock },
            { type: 'digital_product', label: 'Digital Product', icon: Tag },
        ]
    },
    {
        title: "Integrations",
        items: [
            { type: 'instagram', label: 'Instagram', icon: Instagram },
            { type: 'amazon', label: 'Amazon', icon: ShoppingCart },
            { type: 'tock', label: 'Tock', icon: Clock },
            { type: 'opentable', label: 'OpenTable', icon: Utensils },
            { type: 'soundcloud', label: 'SoundCloud', icon: Music2 },
            { type: 'bandsintown', label: 'Bandsintown', icon: Music },
            { type: 'flickr', label: 'Flickr', icon: ImageIcon },
            { type: 'rss', label: 'RSS', icon: Rss },
            { type: 'zola', label: 'Zola', icon: Gift },
        ]
    },
    {
        title: "Filters & Lists",
        items: [
            { type: 'search', label: 'Search', icon: Search },
            { type: 'tag_cloud', label: 'Tag Cloud', icon: Layers },
            { type: 'content_link', label: 'Content Link', icon: Link },
            { type: 'archive', label: 'Archive', icon: Archive },
        ]
    }
];

export default function BlockPicker({ onSelect, className }) {
    return (
        <div className={cn("bg-white text-black rounded-lg shadow-2xl w-full max-w-2xl max-h-[600px] overflow-hidden flex flex-col font-sans", className)}>
            <div className="flex-1 overflow-y-auto p-6 scrollbar-thin scrollbar-thumb-neutral-200">
                {BLOCK_CATEGORIES.map((category, idx) => (
                    <div key={idx} className="mb-8 last:mb-0">
                        <div className="text-sm font-semibold mb-4 text-neutral-900">{category.title}</div>
                        <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                            {category.items.map((item) => (
                                <button
                                    key={item.type}
                                    onClick={() => onSelect(item.type)}
                                    className="flex items-center gap-3 p-2 rounded hover:bg-neutral-100 transition-colors text-left group"
                                >
                                    <item.icon className="w-5 h-5 text-neutral-600 group-hover:text-black" />
                                    <span className="text-sm text-neutral-700 group-hover:text-black">{item.label}</span>
                                </button>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}