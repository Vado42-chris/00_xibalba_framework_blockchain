import React, { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { useInteraction } from '@/components/interaction/InteractionManager';

/**
 * SandboxedRenderer
 * 
 * Safely renders HTML/JS content within an iframe.
 * Supports dynamic height resizing, script execution, and XI Runtime signaling.
 */
export default function SandboxedRenderer({ html, data, type, className, id }) {
    const iframeRef = useRef(null);
    const [height, setHeight] = useState(0);
    // Try to get interaction context, but don't fail if it's not present (e.g. preview mode)
    let interaction = null;
    try {
        interaction = useInteraction();
    } catch (e) {}

    // Register with Interaction Manager on mount
    useEffect(() => {
        if (interaction && id && iframeRef.current) {
            interaction.registerComponent(id, iframeRef.current.contentWindow);
            return () => interaction.unregisterComponent(id);
        }
    }, [id, interaction]);

    // Construct the srcDoc
    // We inject the XI Runtime script for signaling
    const srcDoc = `
        <!DOCTYPE html>
        <html>
        <head>
            <script src="https://cdn.tailwindcss.com"></script>
            <style>
                body { margin: 0; padding: 0; overflow: hidden; transition: opacity 0.3s ease; }
                ::-webkit-scrollbar { display: none; }
                .xi-hidden { opacity: 0; pointer-events: none; }
            </style>
        </head>
        <body>
            <div id="root" class="transition-all duration-300">${html || ''}</div>
            <script>
                const ROOT = document.getElementById('root');
                const ID = "${id}";

                // XI RUNTIME (The Cell Nucleus)
                window.XI = {
                    emit: (eventName, payload) => {
                        window.parent.postMessage({
                            type: 'XI_SIGNAL',
                            sourceId: ID,
                            eventName,
                            payload
                        }, '*');
                    }
                };

                // Listen for Commands from Kernel
                window.addEventListener('message', (e) => {
                    const msg = e.data;
                    if (msg.type === 'XI_COMMAND') {
                        console.log('[Satellite ' + ID + '] Command:', msg.action);
                        switch(msg.action) {
                            case 'hide': ROOT.style.opacity = '0'; break;
                            case 'show': ROOT.style.opacity = '1'; break;
                            case 'toggle': ROOT.style.opacity = ROOT.style.opacity === '0' ? '1' : '0'; break;
                            case 'update_text': 
                                if (ROOT.innerText) ROOT.innerText = msg.payload || 'Updated'; 
                                break;
                            case 'animate':
                                ROOT.style.transform = 'scale(1.05)';
                                setTimeout(() => ROOT.style.transform = 'scale(1)', 200);
                                break;
                        }
                    }
                });

                // Auto-wiring common events
                document.body.addEventListener('click', () => window.XI.emit('click'));
                document.body.addEventListener('mouseenter', () => window.XI.emit('hover'));
                
                // Form Submission
                document.addEventListener('submit', (e) => {
                    e.preventDefault(); // Prevent actual reload
                    const formData = new FormData(e.target);
                    const data = Object.fromEntries(formData.entries());
                    window.XI.emit('submit', data);
                });

                // Auto-resize logic
                const resizeObserver = new ResizeObserver(entries => {
                    const h = document.body.scrollHeight;
                    window.parent.postMessage({ type: 'resize', height: h, sourceId: ID }, '*');
                });
                resizeObserver.observe(document.body);
                window.onload = () => {
                    window.parent.postMessage({ type: 'resize', height: document.body.scrollHeight, sourceId: ID }, '*');
                    window.XI.emit('mount');
                };
            </script>
        </body>
        </html>
    `;

    useEffect(() => {
        const handler = (e) => {
            // Filter messages for this specific component ID to avoid crosstalk
            if (e.data && e.data.type === 'resize' && e.data.sourceId === id) {
                if (Math.abs(height - e.data.height) > 2) {
                    setHeight(e.data.height);
                }
            }
        };
        window.addEventListener('message', handler);
        return () => window.removeEventListener('message', handler);
    }, [height, id]);

    return (
        <div className={`w-full relative ${className || ''}`}>
            <iframe
                ref={iframeRef}
                title={`Sandboxed Component ${id}`}
                srcDoc={srcDoc}
                className="w-full border-none block"
                style={{ height: height || 100, minHeight: '50px', transition: 'height 0.2s ease' }}
                sandbox="allow-scripts allow-same-origin" 
            />
        </div>
    );
}