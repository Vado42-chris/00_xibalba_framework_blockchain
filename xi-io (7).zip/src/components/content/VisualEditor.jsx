import React, { useState, useEffect, useRef } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Button } from "@/components/ui/button";
import { Image as ImageIcon, Save, Undo, Redo, Type, AlignLeft, AlignCenter, AlignRight, List, Bold, Italic, Settings, Globe, Tag, Link as LinkIcon, Calendar, Blocks, FileText, ShieldCheck } from 'lucide-react';
import { AssetPicker } from './AssetPicker';
import { OrientingText, IntentText, StateText, Layer } from '@/components/ui/design-system/System';
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import PageBuilder from './PageBuilder';
import SiteStyles from './SiteStyles';
import XibalbaAuditor from './XibalbaAuditor';

export default function VisualEditor({ page, onSave, isSaving }) {
    const [mode, setMode] = useState(page?.blocks?.length > 0 ? 'blocks' : 'classic');
    const [showAuditor, setShowAuditor] = useState(false);
    const [activeVariantId, setActiveVariantId] = useState(null);

    // Main content state (Control)
    const [content, setContent] = useState(page?.content || '');
    const [blocks, setBlocks] = useState(page?.blocks || []);
    
    // Derived state for current view
    const [title, setTitle] = useState(page?.title || '');
    
    const [metadata, setMetadata] = useState({
        slug: page?.slug || '',
        status: page?.status || 'draft',
        seo_title: page?.seo_title || '',
        seo_description: page?.seo_description || '',
        featured_image: page?.featured_image || '',
        tags: page?.tags || []
    });
    const [isAssetPickerOpen, setIsAssetPickerOpen] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const quillRef = useRef(null);

    // Effect to switch context when variant changes
    useEffect(() => {
        if (activeVariantId) {
            const variant = page?.ab_testing?.variants?.find(v => v.id === activeVariantId);
            if (variant?.content_overrides) {
                setContent(variant.content_overrides.content || '');
                setBlocks(variant.content_overrides.blocks || []);
            }
        } else {
            // Revert to Control
            setContent(page?.content || '');
            setBlocks(page?.blocks || []);
        }
    }, [activeVariantId, page]);

    // Custom Toolbar
    const modules = {
        toolbar: {
            container: "#toolbar",
        }
    };

    const handleImageInsert = (url) => {
        const quill = quillRef.current?.getEditor();
        if (quill) {
            const range = quill.getSelection();
            const position = range ? range.index : 0;
            quill.insertEmbed(position, 'image', url);
        }
        setIsAssetPickerOpen(false);
    };

    const handleSave = () => {
        // Compile content
        let finalContent = content;
        if (mode === 'blocks') {
            finalContent = blocks.map(b => {
                if (b.type === 'text') return b.data.html || '';
                if (b.type === 'image') return `<img src="${b.data.url}" alt="Page Image" />`;
                return '';
            }).join('\n');
        }

        if (activeVariantId) {
            // Saving a specific variant
            const updatedVariants = (page?.ab_testing?.variants || []).map(v => {
                if (v.id === activeVariantId) {
                    return {
                        ...v,
                        content_overrides: {
                            content: finalContent,
                            blocks: mode === 'blocks' ? blocks : []
                        }
                    };
                }
                return v;
            });

            onSave({
                ...page,
                title,
                ab_testing: {
                    ...page.ab_testing,
                    variants: updatedVariants
                },
                ...metadata,
                last_edited: new Date().toISOString()
            });
        } else {
            // Saving Control (Main Page)
            onSave({
                ...page,
                title,
                content: finalContent,
                blocks: mode === 'blocks' ? blocks : [],
                ...metadata,
                last_edited: new Date().toISOString()
            });
        }
    };

    return (
        <div className="flex h-full bg-neutral-950 overflow-hidden relative">
            <div className="flex-1 flex flex-col h-full min-w-0 relative z-0">
                
                {/* SYSTEM TOOLBAR */}
                <Layer level="state" className="shrink-0 m-4 mb-0 flex items-center justify-between gap-4 p-2 z-20">
                    <div id="toolbar" className="flex items-center gap-1 border-none bg-transparent p-0">
                        {mode === 'classic' ? (
                            <>
                                <select className="ql-header bg-transparent text-neutral-300 font-medium border border-white/5 rounded-sm h-8 text-xs w-32 mr-2 px-2 hover:bg-white/5 focus:bg-neutral-900 transition-colors cursor-pointer" defaultValue="">
                                    <option value="1">Header 1</option>
                                    <option value="2">Header 2</option>
                                    <option value="3">Header 3</option>
                                    <option value="">Paragraph</option>
                                </select>
                                
                                <div className="flex items-center bg-black/20 rounded-sm border border-white/5 p-0.5">
                                    <button className="ql-bold p-1.5 rounded-sm hover:bg-white/10 text-neutral-400 hover:text-white transition-colors">
                                        <Bold className="w-3.5 h-3.5" />
                                    </button>
                                    <button className="ql-italic p-1.5 rounded-sm hover:bg-white/10 text-neutral-400 hover:text-white transition-colors">
                                        <Italic className="w-3.5 h-3.5" />
                                    </button>
                                </div>
                                
                                <div className="w-px h-4 bg-white/10 mx-2" />
                                
                                <div className="flex items-center bg-black/20 rounded-sm border border-white/5 p-0.5">
                                    <button className="ql-list p-1.5 rounded-sm hover:bg-white/10 text-neutral-400 hover:text-white transition-colors" value="ordered">
                                        <List className="w-3.5 h-3.5" />
                                    </button>
                                    <button className="ql-align p-1.5 rounded-sm hover:bg-white/10 text-neutral-400 hover:text-white transition-colors" value="">
                                        <AlignLeft className="w-3.5 h-3.5" />
                                    </button>
                                    <button className="ql-align p-1.5 rounded-sm hover:bg-white/10 text-neutral-400 hover:text-white transition-colors" value="center">
                                        <AlignCenter className="w-3.5 h-3.5" />
                                    </button>
                                </div>
                                
                                <div className="w-px h-4 bg-white/10 mx-2" />

                                <Button 
                                    size="sm" 
                                    variant="ghost" 
                                    onClick={() => setIsAssetPickerOpen(true)}
                                    className="h-8 px-3 text-xs text-neutral-400 hover:text-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/5 gap-2"
                                >
                                    <ImageIcon className="w-3.5 h-3.5" /> Media
                                </Button>
                            </>
                        ) : (
                            <div className="flex items-center gap-3 px-2">
                                    <div className="flex items-center justify-center w-6 h-6 rounded-full bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))]">
                                        <Blocks className="w-3.5 h-3.5" />
                                    </div>
                                    <div className="flex flex-col">
                                        <span className="text-xs font-bold text-white tracking-wide">VISUAL BLOCKS</span>
                                        <span className="text-[10px] text-neutral-500">Drag & Drop Mode</span>
                                    </div>
                            </div>
                        )}
                    </div>

                    <div className="flex items-center gap-3">
                        {/* Mode Switcher */}
                        <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
                            <button 
                                onClick={() => setMode('classic')}
                                className={cn(
                                    "px-3 py-1 rounded-md text-[10px] font-bold tracking-wide transition-all flex items-center gap-2",
                                    mode === 'classic' ? "bg-white/10 text-white shadow-sm" : "text-neutral-500 hover:text-white"
                                )}
                            >
                                <FileText className="w-3 h-3" /> DOC
                            </button>
                            <button 
                                onClick={() => setMode('blocks')}
                                className={cn(
                                    "px-3 py-1 rounded-md text-[10px] font-bold tracking-wide transition-all flex items-center gap-2",
                                    mode === 'blocks' ? "bg-[hsl(var(--color-execution))]/20 text-[hsl(var(--color-execution))] shadow-sm" : "text-neutral-500 hover:text-white"
                                )}
                            >
                                <Blocks className="w-3 h-3" /> BLOCKS
                            </button>
                        </div>

                        <div className="w-px h-4 bg-white/10" />

                        <Button 
                            size="sm"
                            variant="ghost"
                            onClick={() => setShowAuditor(!showAuditor)}
                            className={cn(
                                "h-8 px-3 text-xs gap-2 transition-colors",
                                showAuditor ? 'text-[hsl(var(--color-execution))] bg-[hsl(var(--color-execution))]/10' : 'text-neutral-400 hover:text-white'
                            )}
                        >
                            <ShieldCheck className="w-3.5 h-3.5" />
                            {page?.audit_score ? <span className="font-mono font-bold">{page.audit_score}%</span> : 'Audit'}
                        </Button>

                        <Button 
                            size="sm"
                            variant="ghost"
                            onClick={() => setShowSettings(!showSettings)}
                            className={cn(
                                "h-8 px-3 text-xs gap-2 transition-colors",
                                showSettings ? 'text-white bg-white/10' : 'text-neutral-400 hover:text-white'
                            )}
                        >
                            <Settings className="w-4 h-4" /> Styles
                        </Button>

                        <Button 
                            size="sm" 
                            onClick={handleSave} 
                            disabled={isSaving}
                            className="h-8 px-4 bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-black font-bold tracking-wide text-xs shadow-[0_0_15px_-4px_hsl(var(--color-intent))]"
                        >
                            {isSaving ? 'SAVING...' : 'SAVE CHANGES'}
                        </Button>
                    </div>
                </Layer>

                {/* CANVAS SCROLL AREA */}
                <div className="flex-1 overflow-y-auto xi-scroll p-8 relative">
                    
                    {/* THE PAGE CANVAS */}
                    <div className="max-w-[1100px] mx-auto min-h-[calc(100%-2rem)] bg-white dark:bg-[#0A0A0A] rounded-sm shadow-2xl border border-white/5 relative flex flex-col transition-all duration-300">
                        
                        {/* Canvas Header (Title) */}
                        <div className="shrink-0 p-12 pb-4">
                            <input 
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                                className="text-5xl font-bold bg-transparent border-none outline-none text-[hsl(var(--fg-intent))] placeholder-neutral-700 w-full tracking-tight"
                                placeholder="Untitled Page"
                            />
                            <div className="mt-4 flex items-center gap-3 text-xs text-neutral-500 font-mono">
                                <span>/{metadata.slug || 'slug-preview'}</span>
                                <span>•</span>
                                <span className={cn(
                                    metadata.status === 'published' ? "text-[hsl(var(--color-execution))]" : "text-neutral-500"
                                )}>{metadata.status.toUpperCase()}</span>
                                <span>•</span>
                                <span>Last edited {new Date().toLocaleDateString()}</span>
                            </div>
                            <div className="mt-8 h-px w-full bg-neutral-100 dark:bg-white/5" />
                        </div>
                        
                        {/* Canvas Body */}
                        <div className="flex-1 px-12 pb-20">
                            {mode === 'classic' ? (
                                <ReactQuill 
                                    ref={quillRef}
                                    theme="snow"
                                    value={content}
                                    onChange={setContent}
                                    modules={modules}
                                    className="h-full xi-editor border-none"
                                    placeholder="Start writing..."
                                />
                            ) : (
                                <div className="py-4">
                                    <PageBuilder blocks={blocks} onChange={setBlocks} />
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Background Grid Pattern */}
                    <div className="absolute inset-0 pointer-events-none z-[-1] opacity-20" 
                        style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)', backgroundSize: '40px 40px' }} 
                    />
                </div>
            </div>
                
                {showAuditor && (
                    <XibalbaAuditor 
                        page={{...page, title, content, blocks, ...metadata}} 
                        activeVariantId={activeVariantId}
                        onSelectVariant={setActiveVariantId}
                        onUpdate={(updatedPage) => {
                            // Direct update from Auditor (e.g. creating variants)
                            onSave(updatedPage);
                        }}
                    />
                )}

            {/* Settings Sidebar */}
            <SiteStyles isOpen={showSettings} onClose={() => setShowSettings(false)} />
            
            {/* Old Settings (Hidden for now, replaced by SiteStyles) */}
            {false && (
                <div className="w-80 bg-neutral-900 border-l border-white/5 overflow-y-auto animate-in slide-in-from-right duration-200 xi-scroll">
                    <div className="p-4 border-b border-white/5">
                        <OrientingText>PAGE METADATA</OrientingText>
                    </div>
                    <div className="p-4 space-y-6">
                        <div className="space-y-2">
                            <Label className="text-xs text-neutral-400">Publishing Status</Label>
                            <Select 
                                value={metadata.status} 
                                onValueChange={(val) => setMetadata({...metadata, status: val})}
                            >
                                <SelectTrigger className="bg-neutral-950 border-white/10">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-neutral-900 border-white/10 text-white">
                                    <SelectItem value="draft">Draft</SelectItem>
                                    <SelectItem value="published">Published</SelectItem>
                                    <SelectItem value="archived">Archived</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="space-y-2">
                            <Label className="text-xs text-neutral-400">URL Slug</Label>
                            <div className="flex items-center gap-2 bg-neutral-950 border border-white/10 rounded px-2">
                                <LinkIcon className="w-3 h-3 text-neutral-500" />
                                <Input 
                                    value={metadata.slug} 
                                    onChange={(e) => setMetadata({...metadata, slug: e.target.value})}
                                    className="border-none bg-transparent h-8 text-xs focus-visible:ring-0 p-0"
                                    placeholder="page-slug"
                                />
                            </div>
                        </div>

                        <div className="space-y-4 pt-4 border-t border-white/5">
                            <OrientingText>SEO SETTINGS</OrientingText>
                            
                            <div className="space-y-2">
                                <Label className="text-xs text-neutral-400">Meta Title</Label>
                                <Input 
                                    value={metadata.seo_title} 
                                    onChange={(e) => setMetadata({...metadata, seo_title: e.target.value})}
                                    className="bg-neutral-950 border-white/10 text-xs"
                                    placeholder={title || "Page Title"}
                                />
                            </div>

                            <div className="space-y-2">
                                <Label className="text-xs text-neutral-400">Meta Description</Label>
                                <Textarea 
                                    value={metadata.seo_description} 
                                    onChange={(e) => setMetadata({...metadata, seo_description: e.target.value})}
                                    className="bg-neutral-950 border-white/10 text-xs min-h-[80px]"
                                    placeholder="Brief summary for search results..."
                                />
                            </div>

                            <div className="space-y-2">
                                <Label className="text-xs text-neutral-400">Featured Image</Label>
                                <div 
                                    className="aspect-video bg-neutral-950 border border-dashed border-white/10 rounded flex items-center justify-center cursor-pointer hover:bg-neutral-900 transition-colors overflow-hidden"
                                    onClick={() => setIsAssetPickerOpen(true)}
                                >
                                    {metadata.featured_image ? (
                                        <img src={metadata.featured_image} alt="Featured" className="w-full h-full object-cover" />
                                    ) : (
                                        <div className="flex flex-col items-center gap-2 text-neutral-500">
                                            <ImageIcon className="w-6 h-6" />
                                            <span className="text-[10px]">Select Image</span>
                                        </div>
                                    )}
                                </div>
                                {metadata.featured_image && (
                                    <Button 
                                        variant="ghost" 
                                        size="sm" 
                                        className="w-full h-6 text-[10px] text-red-400 hover:text-red-300"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setMetadata({...metadata, featured_image: ''});
                                        }}
                                    >
                                        Remove Image
                                    </Button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <AssetPicker 
                open={isAssetPickerOpen} 
                onOpenChange={setIsAssetPickerOpen} 
                onSelect={(url) => {
                    if (showSettings) {
                        setMetadata({...metadata, featured_image: url});
                        setIsAssetPickerOpen(false);
                    } else {
                        handleImageInsert(url);
                    }
                }} 
            />

            {/* Styles for Quill to match Design System */}
            <style jsx global>{`
                .xi-editor .ql-container {
                    border: none !important;
                    font-family: ui-serif, Georgia, Cambria, "Times New Roman", Times, serif;
                    font-size: 1.125rem;
                }
                .xi-editor .ql-editor {
                    padding: 0 2rem;
                    line-height: 1.8;
                    color: hsl(var(--fg-intent));
                    min-height: 500px;
                }
                .xi-editor .ql-editor h1, .xi-editor .ql-editor h2, .xi-editor .ql-editor h3 {
                    font-family: ui-sans-serif, system-ui, sans-serif;
                    font-weight: 700;
                    margin-top: 2em;
                    margin-bottom: 0.5em;
                    color: hsl(var(--fg-intent));
                }
                .xi-editor .ql-editor p {
                    margin-bottom: 1.5em;
                }
                .xi-editor .ql-editor img {
                    border-radius: 0.5rem;
                    margin: 2rem auto;
                    display: block;
                    max-width: 100%;
                    border: 1px solid hsl(var(--layer-orientation));
                }
                .xi-editor .ql-editor blockquote {
                    border-left: 4px solid hsl(var(--color-intent));
                    padding-left: 1rem;
                    font-style: italic;
                    color: hsl(var(--fg-orientation));
                }
            `}</style>
        </div>
    );
}