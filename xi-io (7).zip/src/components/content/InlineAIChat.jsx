import React, { useState } from 'react';
import { Sparkles, Send, Image as ImageIcon, Wand2, X, Loader2, Bot } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';
import { toast } from "sonner";
import { OrientingText } from '@/components/ui/design-system/System';

export default function InlineAIChat({ onUpdateBlock, selectedBlock, onClose }) {
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [messages, setMessages] = useState([
        { role: 'system', content: selectedBlock 
            ? `I'm here to help with this ${selectedBlock.type} block. Need design tweaks or content?` 
            : "I'm your design assistant. I can help generate images, write copy, or configure components." 
        }
    ]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!input.trim()) return;

        const userMsg = input;
        setInput('');
        setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
        setIsLoading(true);

        try {
            // Check for image generation intent
            if (userMsg.toLowerCase().includes('image') || userMsg.toLowerCase().includes('picture') || userMsg.toLowerCase().includes('photo')) {
                const res = await base44.integrations.Core.GenerateImage({
                    prompt: userMsg,
                });
                
                if (res?.url) {
                    setMessages(prev => [...prev, { 
                        role: 'assistant', 
                        content: "I've generated an image for you. Would you like to use it?",
                        action: 'use_image',
                        data: res.url
                    }]);
                }
            } else {
                // Text/Configuration intent
                const res = await base44.integrations.Core.InvokeLLM({
                    prompt: `User wants help with a website component (Type: ${selectedBlock?.type || 'General'}). 
                    Request: "${userMsg}". 
                    Current Data: ${JSON.stringify(selectedBlock?.data || {})}.
                    
                    If this is a text change, provide the new text. 
                    If this is a configuration change (like colors, alignment), provide a JSON object describing the change.
                    Keep response concise and helpful.`,
                });
                
                setMessages(prev => [...prev, { role: 'assistant', content: res }]);
            }
        } catch (error) {
            console.error(error);
            setMessages(prev => [...prev, { role: 'assistant', content: "Sorry, I encountered an error processing your request." }]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleApplyAction = (msg) => {
        if (msg.action === 'use_image' && onUpdateBlock && selectedBlock) {
            onUpdateBlock(selectedBlock.id, { ...selectedBlock.data, url: msg.data });
            toast.success("Image applied to block");
            onClose();
        }
    };

    return (
        <div className="fixed bottom-8 right-8 w-80 bg-neutral-900 border border-[hsl(var(--color-intent))] rounded-lg shadow-2xl z-50 overflow-hidden flex flex-col animate-in slide-in-from-bottom-5 duration-300">
            {/* Header */}
            <div className="p-3 bg-[hsl(var(--color-intent))]/10 border-b border-[hsl(var(--color-intent))]/20 flex items-center justify-between">
                <div className="flex items-center gap-2 text-[hsl(var(--color-intent))]">
                    <Sparkles className="w-4 h-4" />
                    <span className="text-xs font-bold tracking-wider uppercase">Design Assistant</span>
                </div>
                <button onClick={onClose} className="text-neutral-500 hover:text-white transition-colors">
                    <X className="w-3 h-3" />
                </button>
            </div>

            {/* Messages */}
            <div className="flex-1 p-4 h-64 overflow-y-auto space-y-3 bg-black/40">
                {messages.map((msg, i) => (
                    <div key={i} className={cn("flex gap-2", msg.role === 'user' ? "flex-row-reverse" : "")}>
                        <div className={cn(
                            "w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-1",
                            msg.role === 'user' ? "bg-neutral-700" : "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]"
                        )}>
                            {msg.role === 'user' ? <div className="w-2 h-2 bg-white rounded-full" /> : <Bot className="w-3.5 h-3.5" />}
                        </div>
                        <div className={cn(
                            "rounded-lg p-2 text-xs max-w-[85%]",
                            msg.role === 'user' ? "bg-neutral-800 text-white" : "bg-[hsl(var(--color-intent))]/5 text-neutral-300 border border-[hsl(var(--color-intent))]/10"
                        )}>
                            <p>{msg.content}</p>
                            {msg.action === 'use_image' && (
                                <div className="mt-2 space-y-2">
                                    <img src={msg.data} alt="Generated" className="rounded border border-white/10 w-full" />
                                    <Button size="sm" className="w-full h-6 text-[10px]" onClick={() => handleApplyAction(msg)}>Apply to Block</Button>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
                {isLoading && (
                    <div className="flex gap-2">
                        <div className="w-6 h-6 rounded-full bg-[hsl(var(--color-intent))]/20 flex items-center justify-center">
                            <Loader2 className="w-3.5 h-3.5 text-[hsl(var(--color-intent))] animate-spin" />
                        </div>
                        <div className="bg-[hsl(var(--color-intent))]/5 rounded-lg p-2">
                            <div className="flex gap-1">
                                <div className="w-1 h-1 bg-[hsl(var(--color-intent))] rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                <div className="w-1 h-1 bg-[hsl(var(--color-intent))] rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                <div className="w-1 h-1 bg-[hsl(var(--color-intent))] rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                            </div>
                        </div>
                    </div>
                )}
            </div>

            {/* Input */}
            <form onSubmit={handleSubmit} className="p-3 bg-neutral-900 border-t border-white/5 flex gap-2">
                <Input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={selectedBlock ? `Ask about this ${selectedBlock.type}...` : "Ask AI to generate..."}
                    className="h-8 text-xs bg-black/50 border-white/10 focus-visible:ring-[hsl(var(--color-intent))]"
                />
                <Button size="icon" className="h-8 w-8 bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-black">
                    <Send className="w-3.5 h-3.5" />
                </Button>
            </form>
        </div>
    );
}