import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from "sonner";

export default function NewPageModal({ open, onOpenChange }) {
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
     title: '',
     slug: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await base44.entities.ContentPage.create({
        ...data,
        status: 'draft',
        content: '<h1>New Page</h1><p>Start editing...</p>',
        last_edited: new Date().toISOString()
      });
      await queryClient.invalidateQueries({ queryKey: ['pages'] });
      toast.success("Page created");
      onOpenChange(false);
    } catch (err) {
      toast.error("Failed to create page");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[hsl(var(--layer-orientation))] border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-intent))]">
        <DialogHeader>
          <DialogTitle>Create New Page</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
           <div className="space-y-2">
              <Label className="text-[hsl(var(--fg-orientation))]">Page Title</Label>
              <Input 
                value={data.title}
                onChange={e => setData({...data, title: e.target.value})}
                className="bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))]"
                placeholder="e.g. About Us"
                required
              />
           </div>
           <div className="space-y-2">
              <Label className="text-[hsl(var(--fg-orientation))]">Slug (URL Path)</Label>
              <Input 
                value={data.slug}
                onChange={e => setData({...data, slug: e.target.value})}
                className="bg-[hsl(var(--void))] border-[hsl(var(--layer-orientation))]"
                placeholder="e.g. about-us"
                required
              />
           </div>
           <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>Cancel</Button>
              <Button type="submit" className="bg-[hsl(var(--color-execution))] hover:bg-[hsl(var(--color-execution))]/80 text-black" disabled={loading}>
                 {loading ? "Creating..." : "Create Page"}
              </Button>
           </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}