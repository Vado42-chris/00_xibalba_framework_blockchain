import React from 'react';
import { Draggable, Droppable } from '@hello-pangea/dnd';
import { cn } from "@/lib/utils";
import { Grid, Monitor, Tablet, Smartphone, Info } from 'lucide-react';
import { TextBlock, ImageBlock, PlaceholderBlock } from './blocks/BasicBlocks';

export default function CanvasBoard({ blocks, renderBlockContent, selectedBlockId, onSelectBlock }) {
    return (
        <div className="relative w-full h-full min-h-[600px] bg-[#0F0F0F] overflow-hidden rounded-md border border-white/5 shadow-inner group/canvas">
            
            {/* Grid Background */}
            <div 
                className="absolute inset-0 pointer-events-none opacity-[0.03]"
                style={{ 
                    backgroundImage: 'linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)',
                    backgroundSize: '20px 20px'
                }}
            />

            {/* Breakpoint Guides (Overlay) */}
            <div className="absolute inset-0 pointer-events-none flex justify-center opacity-0 group-hover/canvas:opacity-100 transition-opacity duration-500">
                {/* Mobile Guide (375px) */}
                <div className="h-full w-[375px] border-x border-dashed border-blue-500/20 relative">
                    <div className="absolute top-2 left-2 text-[9px] text-blue-500/50 flex items-center gap-1"><Smartphone className="w-3 h-3" /> Mobile</div>
                </div>
                {/* Tablet Guide (768px) - absolute centered relative to container */}
                <div className="absolute h-full w-[768px] border-x border-dashed border-purple-500/20 pointer-events-none">
                     <div className="absolute top-2 left-2 text-[9px] text-purple-500/50 flex items-center gap-1"><Tablet className="w-3 h-3" /> Tablet</div>
                </div>
                {/* Desktop Guide (1024px) */}
                <div className="absolute h-full w-[1024px] border-x border-dashed border-green-500/20 pointer-events-none">
                     <div className="absolute top-2 left-2 text-[9px] text-green-500/50 flex items-center gap-1"><Monitor className="w-3 h-3" /> Desktop</div>
                </div>
            </div>

            {/* Canvas Info */}
            <div className="absolute bottom-4 right-4 bg-black/50 backdrop-blur text-[10px] text-neutral-500 px-3 py-1 rounded-full border border-white/5 flex items-center gap-2">
                <Grid className="w-3 h-3" />
                CANVAS MODE ACTIVE
            </div>

            {/* Droppable Area (Free-flow Stack for now, but visualized as canvas) */}
            <Droppable droppableId="canvas-area">
                {(provided) => (
                    <div 
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className="relative z-10 p-12 max-w-[1200px] mx-auto min-h-full space-y-8"
                    >
                        {blocks.length === 0 && (
                            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                <div className="text-center space-y-2 opacity-30">
                                    <div className="w-16 h-16 border-2 border-dashed border-white rounded-xl mx-auto flex items-center justify-center">
                                        <Grid className="w-8 h-8 text-white" />
                                    </div>
                                    <p className="text-sm text-white font-mono">DRAG BLOCKS HERE</p>
                                </div>
                            </div>
                        )}
                        
                        {blocks.map((block, index) => (
                            <Draggable key={block.id} draggableId={block.id} index={index}>
                                {(provided, snapshot) => (
                                    <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onSelectBlock(block);
                                        }}
                                        className={cn(
                                            "relative group transition-all duration-200 outline outline-2 outline-transparent rounded-lg",
                                            snapshot.isDragging && "scale-105 z-50 shadow-2xl rotate-1",
                                            selectedBlockId === block.id ? "outline-[hsl(var(--color-intent))]" : "hover:outline-white/10"
                                        )}
                                    >
                                        {/* Block Toolbar (Hover) */}
                                        <div className={cn(
                                            "absolute -top-3 left-4 px-2 py-0.5 bg-[hsl(var(--color-intent))] text-black text-[9px] font-bold rounded-full opacity-0 transition-opacity flex items-center gap-2",
                                            (selectedBlockId === block.id || snapshot.isDragging) && "opacity-100"
                                        )}>
                                            <span>{block.type.toUpperCase()}</span>
                                        </div>

                                        <div className={cn(
                                            "bg-black/40 backdrop-blur-sm border border-white/5 rounded-lg overflow-hidden",
                                            block.type === 'text' ? "p-4" : "p-0"
                                        )}>
                                            {renderBlockContent(block)}
                                        </div>
                                    </div>
                                )}
                            </Draggable>
                        ))}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </div>
    );
}