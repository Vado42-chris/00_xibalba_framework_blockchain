import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Button } from "@/components/ui/button";
import { Plus, GripVertical, Trash2, Layout, Square, Sparkles } from 'lucide-react';
import { TextBlock, ImageBlock, PlaceholderBlock } from './blocks/BasicBlocks';
import UnifiedCanvas from '@/components/studio/UnifiedCanvas';
import VisualPalette from '@/components/studio/VisualPalette';
import StudioToolbar from '@/components/studio/StudioToolbar';
import InlineAIChat from './InlineAIChat';
import { cn } from "@/lib/utils";
import { COMPONENT_LIBRARY } from '@/components/reaper/ComponentLibrary';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

// Convert existing block types to Palette format
const BLOCK_CATEGORIES = [
    {
        category: "Basic",
        items: [
            { id: 't-text', type: 'text', label: 'Text Block', icon: Type },
            { id: 't-image', type: 'image', label: 'Image Block', icon: ImageIcon },
            { id: 't-code', type: 'code', label: 'Code Block', icon: Code },
        ]
    }
];

import { Type, Image as ImageIcon, Code } from 'lucide-react';

export default function PageBuilder({ blocks, onChange }) {
    const [selectedBlockId, setSelectedBlockId] = useState(null);
    const [scale, setScale] = useState(1);
    const [activeTool, setActiveTool] = useState('select');
    const [viewportWidth, setViewportWidth] = useState('100%');
    const [isPaletteOpen, setIsPaletteOpen] = useState(true);
    const [history, setHistory] = useState([]);
    const [historyIndex, setHistoryIndex] = useState(-1);

    // History Helpers
    const updateBlocks = (newBlocks) => {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newBlocks);
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        onChange(newBlocks);
    };

    const handleUndo = () => {
        if (historyIndex > 0) {
            setHistoryIndex(historyIndex - 1);
            onChange(history[historyIndex - 1]);
        }
    };

    const handleRedo = () => {
        if (historyIndex < history.length - 1) {
            setHistoryIndex(historyIndex + 1);
            onChange(history[historyIndex + 1]);
        }
    };

    const handleDragEnd = (result) => {
        if (!result.destination) return;

        const { source, destination } = result;

        // Drop from Palette
        if (source.droppableId === 'palette' && destination.droppableId === 'canvas') {
            // Find item in our block categories or the extended library
            let template = BLOCK_CATEGORIES.flatMap(c => c.items).find(i => i.id === result.draggableId);
            if (!template) {
                // Check component library
                template = COMPONENT_LIBRARY.flatMap(c => c.items).find(i => i.id === result.draggableId);
            }

            if (!template) return;

            const newBlock = {
                id: `block-${Date.now()}`,
                type: template.type,
                data: template.data || {},
                label: template.label,
                html: template.html // if from component library
            };
            
            const newBlocks = [...blocks];
            newBlocks.splice(destination.index, 0, newBlock);
            updateBlocks(newBlocks);
            setSelectedBlockId(newBlock.id);
        }
        // Reorder
        else if (source.droppableId === 'canvas' && destination.droppableId === 'canvas') {
            const items = Array.from(blocks);
            const [reorderedItem] = items.splice(source.index, 1);
            items.splice(destination.index, 0, reorderedItem);
            updateBlocks(items);
        }
    };

    const updateBlock = (id, data) => {
        const newBlocks = blocks.map(b => b.id === id ? { ...b, ...data } : b);
        updateBlocks(newBlocks);
    };

    const removeBlock = (id) => {
        const newBlocks = blocks.filter(b => b.id !== id);
        updateBlocks(newBlocks);
        if (selectedBlockId === id) setSelectedBlockId(null);
    };

    const renderBlockContent = (block) => {
        // If it has HTML content (from Forge), use that
        if (block.html) {
            return <div dangerouslySetInnerHTML={{ __html: block.html }} className="p-4" />;
        }

        switch(block.type) {
            case 'text':
                return <TextBlock data={block.data} onChange={(data) => updateBlock(block.id, { data })} />;
            case 'image':
                return <ImageBlock data={block.data} onChange={(data) => updateBlock(block.id, { data })} />;
            case 'code':
                return <div className="p-4 bg-black border border-white/10 rounded font-mono text-sm text-green-400">Code block placeholder</div>;
            default:
                return <PlaceholderBlock type={block.type} data={block.data} />;
        }
    };

    const selectedBlock = blocks.find(b => b.id === selectedBlockId);

    // Fetch Installed Addons (Supply Chain Integration)
    const { data: installedItems = [] } = useQuery({
        queryKey: ['installed_marketplace_items'],
        queryFn: async () => {
            const installed = await base44.entities.InstalledAddon.list();
            const items = await base44.entities.MarketplaceItem.list();
            
            // Filter only items that are installed AND have a manifest (code)
            const myItems = items.filter(item => 
                installed.some(inst => inst.addon_id === item.id) && item.manifest?.code
            );

            return [{
                category: "Installed Modules",
                items: myItems.map(item => ({
                    id: item.id,
                    type: 'module',
                    label: item.name,
                    icon: 'Box', // We could map category to icon
                    html: item.manifest.code,
                    data: {} 
                }))
            }];
        },
        initialData: []
    });

    // Merge standard blocks, component library, AND installed items
    const mergedLibrary = [
        ...installedItems, // Put user's purchased items first!
        ...BLOCK_CATEGORIES,
        ...COMPONENT_LIBRARY
    ];

    return (
        <div className="flex h-full w-full relative bg-neutral-950 overflow-hidden">
            <DragDropContext onDragEnd={handleDragEnd}>
                
                {/* Unified Toolbar */}
                <StudioToolbar 
                    activeTool={activeTool}
                    onSetTool={setActiveTool}
                    onZoomIn={() => setScale(s => Math.min(2, s + 0.1))}
                    onZoomOut={() => setScale(s => Math.max(0.5, s - 0.1))}
                    onUndo={handleUndo}
                    onRedo={handleRedo}
                    onClear={() => updateBlocks([])}
                    canUndo={historyIndex > 0}
                    canRedo={historyIndex < history.length - 1}
                />

                {/* Viewport Controls */}
                <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1 bg-neutral-900 border border-white/10 p-1 rounded-md shadow-lg">
                     <button onClick={() => setViewportWidth('100%')} className={cn("p-2 rounded hover:bg-white/10", viewportWidth === '100%' && "bg-white/10")} title="Desktop"><Monitor className="w-4 h-4" /></button>
                     <button onClick={() => setViewportWidth('768px')} className={cn("p-2 rounded hover:bg-white/10", viewportWidth === '768px' && "bg-white/10")} title="Tablet"><Tablet className="w-4 h-4" /></button>
                     <button onClick={() => setViewportWidth('375px')} className={cn("p-2 rounded hover:bg-white/10", viewportWidth === '375px' && "bg-white/10")} title="Mobile"><Smartphone className="w-4 h-4" /></button>
                </div>

                {/* Palette */}
                {isPaletteOpen && (
                    <VisualPalette 
                        items={mergedLibrary}
                        onClose={() => setIsPaletteOpen(false)}
                        selectedItem={selectedBlock}
                        onUpdateItem={(id, data) => updateBlock(id, data)}
                        canvasItems={blocks}
                        onSelectItem={(item) => setSelectedBlockId(item.id)}
                    />
                )}

                {/* Main Canvas */}
                <UnifiedCanvas 
                    items={blocks}
                    onItemsChange={updateBlocks}
                    renderItem={renderBlockContent}
                    selectedId={selectedBlockId}
                    onSelect={(item) => setSelectedBlockId(item.id)}
                    scale={scale}
                    viewportWidth={viewportWidth}
                    activeTool={activeTool}
                    onToolReset={() => setActiveTool('select')}
                />

                {/* Toggle Palette Button if closed */}
                {!isPaletteOpen && (
                    <div className="absolute top-4 left-4 z-30">
                        <Button variant="outline" onClick={() => setIsPaletteOpen(true)}>Open Palette</Button>
                    </div>
                )}

            </DragDropContext>

            {/* Old Inline Chat - kept as option or could be merged into toolbar actions */}
            {/* We can trigger this from the selection overlay in UnifiedCanvas or Toolbar */}
        </div>
    );
}