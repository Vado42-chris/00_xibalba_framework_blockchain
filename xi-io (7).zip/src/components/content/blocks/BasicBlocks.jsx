import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Button } from "@/components/ui/button";
import { GripVertical, X, Image as ImageIcon } from 'lucide-react';
import { AssetPicker } from '../AssetPicker';

const modules = {
    toolbar: [
        [{ 'header': [1, 2, 3, false] }],
        ['bold', 'italic', 'underline', 'strike'],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
        ['link', 'clean']
    ]
};

export const TextBlock = ({ data, onChange }) => {
    return (
        <div className="bg-neutral-900 rounded border border-white/5 p-2">
            <ReactQuill 
                theme="snow"
                value={data.html || ''}
                onChange={(html) => onChange({ ...data, html })}
                modules={modules}
                className="xi-block-editor"
            />
        </div>
    );
};

export const ImageBlock = ({ data, onChange }) => {
    const [isPickerOpen, setIsPickerOpen] = useState(false);

    return (
        <div className="bg-neutral-900 rounded border border-white/5 p-4 flex flex-col items-center justify-center min-h-[200px] relative group">
            {data.url ? (
                <div className="relative w-full">
                    <img src={data.url} alt="Block Content" className="w-full h-auto rounded max-h-[500px] object-contain" />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Button variant="secondary" size="sm" onClick={() => setIsPickerOpen(true)}>Change Image</Button>
                    </div>
                </div>
            ) : (
                <div 
                    className="flex flex-col items-center gap-2 cursor-pointer text-neutral-500 hover:text-white transition-colors"
                    onClick={() => setIsPickerOpen(true)}
                >
                    <ImageIcon className="w-10 h-10" />
                    <span className="text-sm">Select Image</span>
                </div>
            )}
            
            <AssetPicker 
                open={isPickerOpen} 
                onOpenChange={setIsPickerOpen} 
                onSelect={(url) => onChange({ ...data, url })} 
            />
        </div>
    );
};

export const PlaceholderBlock = ({ type, data }) => {
    return (
        <div className="bg-neutral-900 border border-white/5 border-dashed rounded p-8 flex flex-col items-center justify-center text-neutral-500 gap-2">
            <span className="font-mono text-xs uppercase tracking-widest">{type} BLOCK</span>
            <span className="text-xs opacity-50">Configuration options for this block are coming soon.</span>
        </div>
    );
};