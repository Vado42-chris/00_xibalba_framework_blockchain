import React, { useState, useEffect, useRef } from 'react';
import { base44 } from "@/api/base44Client";
import { Play, Sparkles, MessageSquare, Code, RefreshCw } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';

export default function CodeEditor({ initialCode = "// Start coding...", language = "javascript", projectId = "current" }) {
    const [code, setCode] = useState(initialCode);
    const [cursors, setCursors] = useState({});
    const [isAiProcessing, setIsAiProcessing] = useState(false);
    const containerRef = useRef(null);

    // Mock User ID for this session
    const myId = useRef('user-' + Math.floor(Math.random() * 1000)).current;

    // Real-time Sync
    useEffect(() => {
        const interval = setInterval(async () => {
            try {
                const { data } = await base44.functions.invoke('collabSync', { projectId }, { method: 'GET', params: { projectId } });
                if (data.cursors) {
                    const others = { ...data.cursors };
                    delete others[myId]; // Remove self
                    setCursors(others);
                }
            } catch (e) {}
        }, 2000);
        return () => clearInterval(interval);
    }, [projectId]);

    const handleMouseMove = async (e) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // Broadcast move (throttled in real app, raw here for demo)
        await base44.functions.invoke('collabSync', {
            project_id: projectId,
            type: 'cursor_move',
            user_id: myId,
            user_name: 'You',
            payload: { x, y }
        });
    };

    const handleAiAction = async (action) => {
        setIsAiProcessing(true);
        try {
            const { data } = await base44.functions.invoke('aiGenerate', {
                intent: action === 'test' ? 'generate_unit_tests' : 'refactor_code',
                input: code,
                context: { 
                    framework: 'Jest',
                    projectStyle: 'Modern React Hooks', 
                    dependencies: ['lodash', 'date-fns', 'framer-motion'],
                    instruction: 'Optimize for readability and performance' 
                }
            });
            if (data.success) {
                if (action === 'test') {
                    toast.success("Unit Tests Generated (Console/Clipboard)");
                    console.log(data.output);
                    navigator.clipboard.writeText(data.output);
                } else {
                    setCode(data.output); // Replace code for refactor
                    toast.success("Code Refactored");
                }
            }
        } catch (e) {
            toast.error("AI Action Failed");
        }
        setIsAiProcessing(false);
    };

    return (
        <div className="flex flex-col h-full bg-[#1e1e1e] rounded-lg overflow-hidden relative border border-white/10" ref={containerRef} onMouseMove={handleMouseMove}>
            {/* Toolbar */}
            <div className="flex items-center justify-between p-2 bg-[#252526] border-b border-white/5">
                <div className="flex items-center gap-2 text-xs text-neutral-400">
                    <Code className="w-4 h-4" />
                    <span>{language}</span>
                </div>
                <div className="flex gap-2">
                    <Button size="sm" variant="ghost" onClick={() => handleAiAction('refactor')} disabled={isAiProcessing} className="h-6 text-[10px] bg-blue-500/10 text-blue-400 hover:bg-blue-500/20">
                        <RefreshCw className={`w-3 h-3 mr-1 ${isAiProcessing ? 'animate-spin' : ''}`} /> Refactor
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleAiAction('test')} disabled={isAiProcessing} className="h-6 text-[10px] bg-green-500/10 text-green-400 hover:bg-green-500/20">
                        <Sparkles className="w-3 h-3 mr-1" /> Gen Tests
                    </Button>
                </div>
            </div>

            {/* Editor Area */}
            <div className="flex-1 relative">
                <textarea 
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full h-full bg-transparent text-neutral-300 font-mono text-sm p-4 resize-none focus:outline-none"
                    spellCheck="false"
                />
                
                {/* Remote Cursors Overlay */}
                {Object.entries(cursors).map(([uid, cursor]) => (
                    <div 
                        key={uid}
                        className="absolute pointer-events-none flex flex-col items-center transition-all duration-300 ease-out z-20"
                        style={{ left: cursor.x, top: cursor.y }}
                    >
                        <div className="w-0.5 h-4 bg-yellow-500 shadow-[0_0_5px_yellow]" />
                        <div className="px-1.5 py-0.5 bg-yellow-500 text-black text-[9px] font-bold rounded mt-1">
                            {cursor.user_name || 'Anon'}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}