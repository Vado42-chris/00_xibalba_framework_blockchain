import { useState, useEffect } from 'react';

export function useSystemZone() {
  const [width, setWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 1440);

  useEffect(() => {
    const handleResize = () => setWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (width >= 1440) return 'A'; // Full Desktop
  if (width >= 1100) return 'B'; // Constrained
  if (width >= 900) return 'C';  // Minimum
  return 'BLOCKED';              // Mobile/Tablet Refusal
}