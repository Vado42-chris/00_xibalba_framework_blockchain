import { base44 } from '@/api/base44Client';

/**
 * Logs a control plane action and updates system memory (Timeline).
 * Enforces the ControlAction schema.
 * 
 * @param {Object} action - The control action payload
 * @param {Object} action.actor - { type: "USER"|"AGENT"|"SYSTEM", id: string }
 * @param {string} action.intent - Description of intent
 * @param {Object} action.scope - { targets: string[], environment: "LOCAL"|"STAGING"|"PRODUCTION" }
 * @param {Object} action.authority - { role: string, policy: string }
 * @param {Object} action.reversibility - { undoable: boolean, undo_window_seconds: number }
 * @param {boolean} action.requires_confirmation
 */
export async function logAction(action) {
  console.log('[ControlPlane] Logging Action:', action);

  try {
    // 1. Create the ControlAction record (The "Log")
    await base44.entities.ControlAction.create(action);

    // 2. Create the TimelineEvent (The "Narrative")
    // Map ControlAction -> TimelineEvent
    const timelineEvent = {
      text: `${action.actor.type === 'USER' ? 'Admin' : action.actor.id} executed: ${action.intent}`,
      type: action.actor.type.toLowerCase(), // user, agent, system
      severity: action.intent.toLowerCase().includes('lockdown') || action.intent.toLowerCase().includes('panic') ? 'critical' : 'nominal',
      verified: true,
      timestamp: new Date().toISOString(),
      metadata: {
        action_id: 'generated-id', // In real app, use response from create
        scope: action.scope
      }
    };

    await base44.entities.TimelineEvent.create(timelineEvent);
    
    return { success: true };
  } catch (error) {
    console.error('[ControlPlane] Action Failed:', error);
    return { success: false, error };
  }
}