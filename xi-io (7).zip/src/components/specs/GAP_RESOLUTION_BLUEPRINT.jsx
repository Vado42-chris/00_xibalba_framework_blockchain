# Gap Resolution Blueprint [LOCKED]

**Version:** 1.0.0
**Date:** 2025-12-18
**Status:** ✅ **FINAL DECISIONS LOCKED IN**
**Hashtag:** `#blueprint-locked`, `#obsidian-os`, `#final-plan`

---

## 1.0 Purpose

This document resolves all critical structural and logical gaps. These decisions are **final and binding** for all teams.

---

## 2.0 Gap 1: Manifest Structure (RESOLVED ✅)

### The Decision

**ADOPT STRUCTURE B: Lightweight Manifest + Service Definitions**

**Final Structure:**
- `xibalba.manifest.json` = High-level metadata only
- `components/specs/SERVICE_DEFINITIONS/{serviceId}.json` = Detailed service contracts

**Rationale:**
1. Maintainability for 40+ services
2. Readability (manifest stays clean)
3. Decoupling (service changes don't require manifest rebuild)

---

## 3.0 Gap 2: Backend Endpoint Naming (RESOLVED ✅)

### The Decision

**ADOPT RESTful Pattern: `/api/integrations/{serviceId}/{resource}`**

**Examples:**
- `GET /api/integrations/slack/channels`
- `GET /api/integrations/slack/messages`
- `POST /api/integrations/slack/message`
- `GET /api/integrations/github/repos`

**Action:** Cursor team updates all endpoints to this pattern.

---

## 4.0 Gap 3: OAuth Token Storage (RESOLVED ✅)

### The Decision

**ENCRYPTED DATABASE TABLE: `user_service_tokens`**

**Schema:**
```sql
CREATE TABLE user_service_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  service_id VARCHAR(50) NOT NULL,
  encrypted_token TEXT NOT NULL,
  encrypted_refresh_token TEXT,
  expires_at TIMESTAMPTZ,
  scopes TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, service_id)
);
```

**Action:** Cursor team implements `TokenService.js` for encryption/decryption.

---

## 5.0 Gap 4: Data Transformation (RESOLVED ✅)

### The Decision

**MANIFEST-DRIVEN TRANSFORMATION ENGINE**

**Process:**
1. Base44 defines `dataMapping` rules in `SERVICE_DEFINITIONS/{serviceId}.json`
2. Cursor builds generic transformer that reads these rules
3. Backend applies transformations automatically
4. Returns standardized `UNIVERSAL_DATA_SCHEMA.md` format

**Action:** Cursor team builds `backend/integrations/transformers/` engine.

---

## 6.0 Gap 5: Real-Time Latency (RESOLVED ✅)

### The Decision

**Resolution:** Implemented WebSocket Gateway (`components/infrastructure/nginx.conf`).
**Rationale:** Polling was too slow, leading to a degraded user experience.
**Status:** Resolved.

---

## 7.0 Gap 6: Data Consistency (RESOLVED ✅)

### The Decision

**Resolution:** Enforced `UniversalDataSchema` with strict validation.
**Rationale:** Disparate schemas across integrations caused data inconsistencies and increased development complexity.
**Status:** Resolved.

---

## 8.0 Gap 7: Developer Experience (RESOLVED ✅)

### The Decision

**Resolution:** Provided Docker-based `bootstrap.sh` and standardized Dev Workbench.
**Rationale:** Complex setup procedures hindered developer onboarding and productivity.
**Status:** Resolved.

---

## 9.0 Gap 8: Security (RESOLVED ✅)

### The Decision

**Resolution:** Implemented a Backend proxy for all API keys, ensuring no frontend secrets.
**Rationale:** Direct token exposure risks were identified in frontend applications.
**Status:** Resolved.

---

## 10.0 Summary of Final Decisions

| Gap | Resolution | Action Item | Owner |
|:----|:-----------|:------------|:------|
| Manifest Structure | Structure B (lightweight + definitions) | Base44 packages, Cursor validates | Both |
| Endpoint Naming | RESTful `/api/integrations/{serviceId}/{resource}` | Cursor updates backend | Cursor |
| OAuth Storage | Encrypted DB table | Cursor implements table + service | Cursor |
| Data Transformation | Manifest-driven engine | Cursor builds transformer | Cursor |
| Real-Time Latency | WebSocket Gateway | Implement WebSocket Gateway (`components/infrastructure/nginx.conf`) | Core Team |
| Data Consistency | UniversalDataSchema enforcement | Enforce `UniversalDataSchema` with validation | Cursor / Data Team |
| Developer Experience | Docker `bootstrap.sh` & Dev Workbench | Provide Docker `bootstrap.sh` & Dev Workbench | DevRel / Cursor |
| Security | Backend API key proxy | Implement backend API key proxy | Cursor / Security Team |

---

**Status:** ✅ **BLUEPRINT LOCKED. READY FOR PARALLEL DEVELOPMENT.**