export const API_CONNECTOR_MANIFEST = [
    {
        id: "slack",
        label: "Slack",
        category: "communication",
        provider: "base44",
        tier: "vanguard",
        description: "Bring team chat, channels, and alerts into your Obsidian desktop.",
        docsUrl: "https://docs.valhalla.dev/integrations/slack",
        icon: "MessageSquare", // Lucide icon name
        defaultModes: {
            aiInsight: true,
            blockchainAudit: true
        },
        marketing: {
            tagline: "Pipe your team’s conversation directly into your operating system.",
            valueProps: [
                "Turn any Slack channel into a live widget on your Obsidian desktop.",
                "Trigger workflows from emojis, mentions, and keywords.",
                "Prove every alert and action with tamper-proof audit trails."
            ]
        }
    },
    {
        id: "google_drive",
        label: "Google Drive",
        category: "storage",
        provider: "base44",
        tier: "vanguard",
        description: "Sync files, docs, and knowledge into your Obsidian workspace.",
        docsUrl: "https://docs.valhalla.dev/integrations/google-drive",
        icon: "HardDrive",
        defaultModes: {
            aiInsight: true,
            blockchainAudit: false
        },
        marketing: {
            tagline: "Turn your scattered documents into a living knowledge graph.",
            valueProps: [
                "Mirror key Google Drive folders into your Obsidian OS.",
                "Use AI to summarize, tag, and surface what matters.",
                "Keep a verifiable record of critical document changes."
            ]
        }
    },
    {
        id: "salesforce",
        label: "Salesforce",
        category: "crm",
        provider: "base44",
        tier: "vanguard",
        description: "Bring pipeline, accounts, and revenue signals into your CEO dashboard.",
        docsUrl: "https://docs.valhalla.dev/integrations/salesforce",
        icon: "Users",
        defaultModes: {
            aiInsight: true,
            blockchainAudit: true
        },
        marketing: {
            tagline: "Give your revenue engine a living, breathing command center.",
            valueProps: [
                "See at-a-glance which deals are at risk across tools.",
                "Pipe deal updates into Slack, email, and dashboards in real time.",
                "Sign every critical change into your tamper-proof ledger."
            ]
        }
    },
    {
        id: "github",
        label: "GitHub",
        category: "productivity",
        provider: "base44",
        tier: "vanguard",
        description: "Track commits, issues, and deployments in your sovereign log.",
        docsUrl: "https://docs.valhalla.dev/integrations/github",
        icon: "GitBranch",
        defaultModes: {
            aiInsight: true,
            blockchainAudit: true
        },
        marketing: {
            tagline: "Code sovereignty for your entire fleet.",
            valueProps: [
                "Audit every commit against Valhalla security policies.",
                "AI-generated changelogs delivered to your Ravens Feed.",
                "Backup critical repos to decentralized storage."
            ]
        }
    },
    {
        id: "notion",
        label: "Notion",
        category: "productivity",
        provider: "base44",
        tier: "beta",
        description: "Turn your wiki into a structured database for your OS.",
        docsUrl: "https://docs.valhalla.dev/integrations/notion",
        icon: "FileText",
        defaultModes: {
            aiInsight: true,
            blockchainAudit: false
        },
        marketing: {
            tagline: "Your second brain, now wired into your primary OS.",
            valueProps: [
                "Sync Notion databases to local JSON for offline access.",
                "Trigger automations when pages change status.",
                "AI analysis of your entire workspace."
            ]
        }
    },
    {
        id: "tiktok",
        label: "TikTok",
        category: "marketing",
        provider: "base44",
        tier: "experimental",
        description: "Monitor trends and engagement from the edge.",
        docsUrl: "https://docs.valhalla.dev/integrations/tiktok",
        icon: "Video",
        defaultModes: {
            aiInsight: true,
            blockchainAudit: false
        },
        marketing: {
            tagline: "Pulse-check the zeitgeist.",
            valueProps: [
                "Track creator stats in real-time widgets.",
                "AI sentiment analysis on comments.",
                "Archive viral content automatically."
            ]
        }
    }
];