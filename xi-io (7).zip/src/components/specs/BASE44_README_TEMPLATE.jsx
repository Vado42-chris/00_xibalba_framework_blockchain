# Base44 Project README

## Getting Started

1. **Install Dependencies**: `npm install`
2. **Environment**: Copy `components/config/.env.example` to `.env`
3. **Run Dev**: `npm run dev`

## Architecture

- **Specs**: See `components/specs/` for "Locked" blueprints.
- **Infrastructure**: See `components/infrastructure/` for Docker/Nginx.
- **Schemas**: See `components/schemas/` for data validation.

## Deployment

Refer to `components/specs/DEPLOYMENT_INSTRUCTIONS.md` for production rollout.