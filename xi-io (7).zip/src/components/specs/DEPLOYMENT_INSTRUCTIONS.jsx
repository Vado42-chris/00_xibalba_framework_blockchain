# Deployment Instructions

1. **Prerequisites**
   - Docker & Docker Compose installed
   - SSL Certificates generated (or Let's Encrypt configured)

2. **Setup**
   ```bash
   chmod +x components/infrastructure/bootstrap.sh
   ./components/infrastructure/bootstrap.sh
   ```

3. **Verify**
   - Check `docker-compose ps` to ensure all services are `Up`.
   - Access `https://localhost` (accept self-signed cert if local).

4. **Rollback**
   - Use `components/infrastructure/cicd/rollback.sh` if critical failures occur.