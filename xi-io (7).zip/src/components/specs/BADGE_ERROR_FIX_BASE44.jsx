# BADGE ERROR FIX (Do This First - 2 Minutes)

**Error:** `ReferenceError: Badge is not defined` in Dashboard component

**Quick Fix in Base44:**
1. Open Dashboard component in Base44
2. Search for "Badge" (Ctrl+F)
3. Find where `<Badge>` is used
4. Add this import at the top of that file:
   ```javascript
   import { Badge } from "@/components/ui/badge";
   ```
5. Save and refresh preview