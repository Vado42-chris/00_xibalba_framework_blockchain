
# Service Endpoint Blueprint [LOCKED]

**Version:** 1.0.0  
**Date:** 2025-12-18  
**Status:** ✅ **ACTIVE BLUEPRINT**  
**Hashtag:** `#endpoint-blueprint`, `#obsidian-os`, `#api-mapping`

---

## Purpose

This document maps frontend requirements to backend implementation for the core suite of integrations.

---

## 1. Authentication
- `POST /auth/login`
- `POST /auth/refresh`
- `GET /auth/me`

## 2. Real-Time
- `WS /ws/connect`
- `POST /api/realtime/broadcast`

## 3. Marketplace
- `GET /api/marketplace/catalog`
- `POST /api/marketplace/install/:id`
- `GET /api/marketplace/installed`

## 4. AI & Analytics
- `POST /api/ai/analyze`
- `GET /api/ai/risks`
- `POST /api/ai/chat`

## 5. System
- `GET /api/system/health`
- `GET /api/system/config`

---

## Endpoint Mapping Table

| Service | Frontend Endpoint | Backend Implementation | Data Contract | Status |
|:--------|:-----------------|:----------------------|:--------------|:-------|
| **Slack** | `GET /api/integrations/slack/channels` | `GET https://slack.com/api/conversations.list` | `ChannelList` | ⏳ Ready |
| **Slack** | `GET /api/integrations/slack/messages?channelId={id}` | `GET https://slack.com/api/conversations.history` | `MessageFeed` | ⏳ Ready |
| **Slack** | `POST /api/integrations/slack/message` | `POST https://slack.com/api/chat.postMessage` | `PostMessageResponse` | ⏳ Ready |
| **GitHub** | `GET /api/integrations/github/repos` | `GET https://api.github.com/user/repos` | `RepoList` | ⏳ Ready |
| **GitHub** | `GET /api/integrations/github/repo/{owner}/{repo}` | `GET https://api.github.com/repos/{owner}/{repo}` | `RepoDetails` | ⏳ Ready |
| **GitHub** | `GET /api/integrations/github/issues?repo={repo}` | `GET https://api.github.com/repos/{owner}/{repo}/issues` | `IssueList` | ⏳ Ready |
| **Notion** | `GET /api/integrations/notion/pages` | `GET https://api.notion.so/v1/search` | `PageList` | ⏳ Ready |
| **Notion** | `GET /api/integrations/notion/databases` | `GET https://api.notion.so/v1/search` (filter: database) | `DatabaseList` | ⏳ Ready |
| **Google Drive** | `GET /api/integrations/google-drive/files` | `GET https://www.googleapis.com/drive/v3/files` | `FileList` | ⏳ Ready |
| **Google Drive** | `GET /api/integrations/google-drive/recent` | `GET https://www.googleapis.com/drive/v3/files` (orderBy: modifiedTime) | `FileList` | ⏳ Ready |
| **Gmail** | `GET /api/integrations/gmail/threads` | `GET https://gmail.googleapis.com/gmail/v1/users/me/threads` | `ThreadList` | ⏳ Ready |
| **Google Calendar** | `GET /api/integrations/google-calendar/events` | `GET https://www.googleapis.com/calendar/v3/calendars/primary/events` | `EventList` | ⏳ Ready |
| **Airtable** | `GET /api/integrations/airtable/bases` | `GET https://api.airtable.com/v0/meta/bases` | `BaseList` | ⏳ Ready |
| **Airtable** | `GET /api/integrations/airtable/records?base={id}&table={id}` | `GET https://api.airtable.com/v0/{baseId}/{tableId}` | `RecordList` | ⏳ Ready |
| **Salesforce** | `GET /api/integrations/salesforce/contacts` | `SOQL SELECT Id, Name, Email FROM Contact` | `ContactList` | ⏳ Ready |
| **Salesforce** | `GET /api/integrations/salesforce/opportunities` | `SOQL SELECT Id, Name, StageName, Amount FROM Opportunity` | `OpportunityList` | ⏳ Ready |
| **HubSpot** | `GET /api/integrations/hubspot/contacts` | `GET https://api.hubapi.com/crm/v3/objects/contacts` | `ContactList` | ⏳ Ready |
| **HubSpot** | `GET /api/integrations/hubspot/deals` | `GET https://api.hubapi.com/crm/v3/objects/deals` | `DealList` | ⏳ Ready |
| **Linear** | `GET /api/integrations/linear/issues` | `GraphQL { issues { nodes { id title state } } }` | `TaskList` | ⏳ Ready |
| **Jira** | `GET /api/integrations/jira/issues` | `GET /rest/api/3/search?jql=assignee=currentUser()` | `TaskList` | ⏳ Ready |
| **Zoom** | `GET /api/integrations/zoom/meetings` | `GET https://api.zoom.us/v2/users/me/meetings` | `MeetingList` | ⏳ Ready |
| **OpenAI** | `POST /api/integrations/openai/chat` | `POST https://api.openai.com/v1/chat/completions` | `ChatResponse` | ⏳ Ready |
| **Anthropic** | `POST /api/integrations/anthropic/chat` | `POST https://api.anthropic.com/v1/messages` | `ChatResponse` | ⏳ Ready |
| **eToro** | `GET /api/integrations/etoro/portfolio` | `GET https://api.etoro.com/portfolios` | `Portfolio` | ⏳ Ready |
| **Stripe** | `GET /api/integrations/stripe/balance` | `GET https://api.stripe.com/v1/balance` | `Balance` | ⏳ Ready |
| **Stripe** | `GET /api/integrations/stripe/transactions` | `GET https://api.stripe.com/v1/balance_transactions` | `TransactionList` | ⏳ Ready |

---

## Authentication Requirements

| Service | Auth Type | Token Storage |
|:--------|:----------|:--------------|
| **Slack** | OAuth2 | Encrypted DB |
| **GitHub** | OAuth2 | Encrypted DB |
| **Notion** | OAuth2 | Encrypted DB |
| **Google** | OAuth2 | Encrypted DB |
| **Airtable** | API Key | Encrypted DB |
| **Salesforce** | OAuth2 | Encrypted DB |
| **HubSpot** | OAuth2 | Encrypted DB |
| **Linear** | OAuth2 | Encrypted DB |
| **Jira** | OAuth2 | Encrypted DB |
| **Zoom** | OAuth2 | Encrypted DB |
| **OpenAI** | API Key | Encrypted DB |
| **Stripe** | API Key | Encrypted DB |

---

## Data Transformation Requirements

| Service | Transformer File |
|:--------|:-----------------|
| **Slack** | `backend/integrations/transformers/slack.js` |
| **GitHub** | `backend/integrations/transformers/github.js` |
| **Notion** | `backend/integrations/transformers/notion.js` |
| **Google** | `backend/integrations/transformers/google.js` |
| **Salesforce** | `backend/integrations/transformers/salesforce.js` |
| **...** | **...** |

---

**Status:** ✅ **READY FOR IMPLEMENTATION**
