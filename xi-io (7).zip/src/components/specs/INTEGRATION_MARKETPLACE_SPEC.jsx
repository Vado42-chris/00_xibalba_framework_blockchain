# Integration Marketplace Specification [LOCKED]

**Version:** 1.0.0
**Date:** 2025-12-18
**Status:** ✅ **ACTIVE SPECIFICATION**
**Hashtag:** `#marketplace`, `#obsidian-os`, `#integration-store`

---

## Components
1.  **Catalog**: Grid view of available integrations (Slack, Jira, etc.)
2.  **Detail View**: Markdown-based description + screenshots.
3.  **Config Flow**: OAuth popup + Field mapping wizard.

## Schema
-   `id`: Unique slug
-   `name`: Display name
-   `type`: `connector` | `widget` | `agent`
-   `auth_flow`: `oauth2` | `apikey` | `basic`
-   `scopes`: Required permissions array

## Installation Process
1.  User clicks "Install"
2.  Backend validates license/tier
3.  OAuth flow triggered
4.  Credentials stored securely (Encrypted)
5.  Default widgets provisioned to dashboard

---

## 1.0 Purpose

Create a marketplace within Obsidian OS where users can browse, discover, and connect new Base44-integrated services with one-click setup.

---

## 2.0 Marketplace UI

### 2.1 Service Discovery

**Component:** `IntegrationMarketplace.tsx`
**Location:** `components/marketplace/IntegrationMarketplace.tsx`

**Features:**
- Browse all available services
- Filter by category (communication, development, productivity, crm, ai, finance)
- Search by name or description
- View service details (auth requirements, capabilities, widgets)
- See installation status (installed/not installed)

### 2.2 Service Details View

**Modal Component:** `ServiceDetailsModal.tsx`

**Shows:**
- Service name, icon, description
- Category and tags
- Authentication requirements
- Available widgets
- Workbench presets
- Installation status
- "Connect" button

---

## 3.0 Backend API

### 3.1 List Available Services

**Endpoint:** `GET /api/marketplace/services`

**Response:**
```json
{
  "data": {
    "services": [
      {
        "serviceId": "slack",
        "name": "Slack",
        "category": "communication",
        "iconUrl": "assets/icons/slack.svg",
        "description": "Team communication and collaboration",
        "authType": "oauth2",
        "installed": false
      }
    ]
  }
}
```

### 3.2 Get Service Details

**Endpoint:** `GET /api/marketplace/service/{serviceId}`

**Response:**
```json
{
  "data": {
    "service": {
      "serviceId": "slack",
      "name": "Slack",
      "category": "communication",
      "description": "Team communication and collaboration",
      "iconUrl": "assets/icons/slack.svg",
      "authConfig": {
        "type": "oauth2",
        "label": "Connect your Slack Workspace",
        "scopes": {
          "channels:history": "Read messages",
          "chat:write": "Post messages"
        }
      },
      "availableWidgets": [
        { "id": "SlackChannelBrowser", "name": "Channel Browser" }
      ],
      "installed": false
    }
  }
}
```

### 3.3 Install Service

**Endpoint:** `POST /api/marketplace/install/{serviceId}`

**Response:**
```json
{
  "data": {
    "serviceId": "slack",
    "installed": true,
    "authUrl": "https://slack.com/oauth/v2/authorize?...",
    "nextStep": "redirect_to_auth"
  }
}
```

### 3.4 Uninstall Service

**Endpoint:** `DELETE /api/marketplace/uninstall/{serviceId}`

---

## 4.0 Service Registry

### 4.1 Database Schema

**Table: `installed_services`**
```sql
CREATE TABLE installed_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  service_id VARCHAR(50) NOT NULL,
  installed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  enabled BOOLEAN NOT NULL DEFAULT true,
  config JSONB,
  UNIQUE(user_id, service_id)
);
```

**Table: `service_registry`**
```sql
CREATE TABLE service_registry (
  service_id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50) NOT NULL,
  description TEXT,
  icon_url VARCHAR(255),
  auth_type VARCHAR(20) NOT NULL,
  service_definition JSONB NOT NULL,
  version VARCHAR(20),
  enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### 4.2 Service Definition Source

**Source:** `components/specs/SERVICE_DEFINITIONS/{serviceId}.json` from Base44 ZIP package

**Process:**
1. Deployment service extracts ZIP
2. Reads definitions
3. Registers services in DB

---

## 5.0 Implementation Requirements

### Backend (Cursor Team)

1.  **Marketplace Endpoints:**
    - Implement `GET /api/marketplace/services`
    - Implement `POST /api/marketplace/install/:serviceId`
    - Implement OAuth flow generation

2.  **Service Registry:**
    - Create tables
    - Implement service registration logic

### Frontend (Base44 Team)

1.  **Marketplace UI:**
    - Create `IntegrationMarketplace` component
    - Fetch services from API
    - Handle install flow (redirects)

---

**Status:** ✅ **READY FOR IMPLEMENTATION**