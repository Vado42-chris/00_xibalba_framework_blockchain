# Universal Data Schema [LOCKED]

## 1. Core Entities
- **User**: Identity, Roles, Preferences
- **Workspace**: Groups of widgets and layouts
- **Widget**: Configuration and state for UI modules

## 2. Integration Entities
- **Integration**: Connection details (Slack, GitHub, etc.)
- **IntegrationMapping**: Data transformation rules
- **IntegrationLog**: Audit trail of sync events

## 3. Intelligence Entities
- **AnalysisResult**: AI-generated insights
- **RiskMetric**: Calculated project risks
- **Suggestion**: Actionable AI recommendations

## 4. API Response Standard
```json
{
  "data": { },
  "meta": {
    "page": 1,
    "total": 100,
    "timestamp": "2024-01-01T00:00:00Z"
  },
  "status": "success"
}
``