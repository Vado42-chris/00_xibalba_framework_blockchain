# Real-Time Data Synchronization Specification

**Version:** 1.0.0  
**Date:** 2025-12-18  
**Status:** ✅ **ACTIVE SPECIFICATION**  
**Hashtag:** `#realtime-sync`, `#websocket`, `#obsidian-os`

---

## 1.0 Purpose

Enable real-time data synchronization for all Base44 services using WebSocket connections. Widgets and workbenches update instantly without manual refresh.

---

## 2.0 Architecture

### 2.1 WebSocket Server (Backend)

**Endpoint:** `WS /ws` or `WSS /ws` (secure)

**Technology:** Socket.io (recommended) or native WebSocket

**Authentication:** JWT token passed in connection handshake

**Connection Flow:**
1. Client connects to `/ws` with JWT token in query string: `?token={jwt}`
2. Server validates token
3. Server subscribes client to service channels based on user's installed services
4. Server sends updates as they occur from webhooks

### 2.2 WebSocket Client (Frontend)

**Component:** `UniversalServiceWidget` includes WebSocket client via `useWebSocket` hook

**Connection Management:**
- Auto-reconnect on disconnect
- Exponential backoff for reconnection (1s, 2s, 4s, 8s, max 30s)
- Connection status indicator in UI
- Graceful degradation (fallback to polling if WebSocket unavailable)

---

## 3.0 Message Protocol

### 3.1 Client → Server Messages

**Subscribe to Service:**
```json
{
  "type": "subscribe",
  "serviceId": "slack",
  "channelId": "C03BG96L1"
}
```

**Unsubscribe from Service:**
```json
{
  "type": "unsubscribe",
  "serviceId": "slack",
  "channelId": "C03BG96L1"
}
```

**Ping (Keep-Alive):**
```json
{
  "type": "ping"
}
```

### 3.2 Server → Client Messages

**Service Update:**
```json
{
  "type": "update",
  "serviceId": "slack",
  "eventType": "message.new",
  "data": {
    "message": {
      "id": "1678886500.789012",
      "user": { "id": "U03BG96L1", "name": "Sarah Chen" },
      "text": "New message!",
      "timestamp": 1678886500
    },
    "channelId": "C03BG96L1"
  },
  "timestamp": "2025-12-17T10:07:00Z"
}
```

**Error Notification:**
```json
{
  "type": "error",
  "serviceId": "slack",
  "error": {
    "code": "RATE_LIMIT",
    "message": "Rate limit exceeded"
  }
}
```

**Pong (Keep-Alive Response):**
```json
{
  "type": "pong"
}
```

---

## 4.0 Service-Specific Webhook Integration

### 4.1 Slack Webhooks

**Backend Endpoint:** `POST /api/hooks/slack`

**Event Types:**
- `message.channels` - New message in channel
- `message.changed` - Message edited
- `message.deleted` - Message deleted
- `channel.created` - New channel created

### 4.2 GitHub Webhooks

**Backend Endpoint:** `POST /api/hooks/github`

**Event Types:**
- `push` - New commit
- `issues` - Issue created/updated
- `pull_request` - PR created/updated
- `release` - New release

### 4.3 Notion Webhooks

**Backend Endpoint:** `POST /api/hooks/notion`

**Event Types:**
- `page.created` - New page
- `page.updated` - Page updated
- `page.deleted` - Page deleted

---

## 5.0 Implementation Requirements

### Backend (Cursor Team)

1. **WebSocket Server Setup:**
   ```javascript
   // Install: npm install socket.io
   const io = require('socket.io')(server);
   
   io.use((socket, next) => {
     // Validate JWT token
     const token = socket.handshake.query.token;
     // Verify token and attach user_id to socket
   });
   
   io.on('connection', (socket) => {
     // Handle subscribe/unsubscribe messages
     // Broadcast updates to subscribed clients
   });
   ```

2. **Webhook Receivers:**
   - Create `/api/hooks/{serviceId}` endpoints
   - Validate webhook signatures (Slack, GitHub, etc.)
   - Process events
   - Broadcast to WebSocket clients via `io.emit()`

### Frontend (Base44 Team)

1. **WebSocket Client:**
   ```typescript
   // Create: components/integrations/hooks/useWebSocket.ts
   export function useWebSocket(serviceId: string, channelId?: string) {
     const [data, setData] = useState(null);
     const [connected, setConnected] = useState(false);
     
     useEffect(() => {
       const socket = io('/ws', {
         query: { token: getJWTToken() }
       });
       
       socket.on('connect', () => setConnected(true));
       socket.on('update', (msg) => {
         if (msg.serviceId === serviceId) {
           setData(msg.data);
         }
       });
       
       socket.emit('subscribe', { serviceId, channelId });
       
       return () => socket.disconnect();
     }, [serviceId, channelId]);
     
     return { data, connected };
   }
   ```

---

**Status:** ✅ **READY FOR IMPLEMENTATION**