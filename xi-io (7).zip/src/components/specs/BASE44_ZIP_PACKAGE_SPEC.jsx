# Base44 ZIP Package Specification

**Version:** 1.0.0  
**Date:** 2025-12-17  
**Status:** ✅ **ACTIVE CONTRACT**  
**Hashtag:** `#base44-zip-spec`, `#obsidian-os`, `#integration-manifest`

---

## Table of Contents

1. [Overview](#overview)
2. [ZIP Package Structure](#zip-package-structure)
3. [xibalba.manifest.json Schema](#xibalba-manifest-json-schema)
4. [Documentation Requirements](#documentation-requirements)
5. [All Integrations Specification](#all-integrations-specification)
6. [Site Configuration](#site-configuration)
7. [Service Registry Schema](#service-registry-schema)
8. [API Integration Specifications](#api-integration-specifications)
9. [Data Contracts](#data-contracts)
10. [Widget Configurations](#widget-configurations)
11. [Workbench Configurations](#workbench-configurations)
12. [Deployment Instructions](#deployment-instructions)
13. [Validation Checklist](#validation-checklist)

---

## Overview

This specification defines the structure and content of ZIP packages delivered by Base44 for Obsidian OS. Each package must be self-contained and include all documentation, configuration, and assets needed for deployment.

### Core Principles

1. Self-contained: All documentation, schemas, and configuration included in the ZIP
2. Machine-readable: `xibalba.manifest.json` provides structured metadata
3. Human-readable: README files provide context and instructions
4. Complete: Covers all integrations, not just one service
5. Versioned: Each package is versioned and immutable

---

## ZIP Package Structure

### Required Structure

```
obsidian-ui-v{version}.zip
├── dist/                              # Built frontend assets (REQUIRED)
│   ├── index.html
│   ├── assets/
│   │   ├── css/
│   │   ├── js/
│   │   ├── fonts/
│   │   └── images/
│   └── ...
├── xibalba.manifest.json              # Master manifest (REQUIRED)
├── README.md                          # Main documentation (REQUIRED)
├── docs/                              # Documentation folder (REQUIRED)
│   ├── API_INTEGRATION.md            # All API endpoints needed
│   ├── DATA_CONTRACT.md              # Standardized data schemas
│   ├── SITE_CONFIGURATION.md         # Nginx, Docker, env vars
│   ├── DEPLOYMENT.md                 # Step-by-step deployment guide
│   ├── INTEGRATIONS/                 # Per-service documentation
│   │   ├── slack.md
│   │   ├── github.md
│   │   ├── notion.md
│   │   ├── airtable.md
│   │   ├── salesforce.md
│   │   ├── google-drive.md
│   │   ├── etoro.md
│   │   ├── gemini.md
│   │   ├── claude.md
│   │   └── ... (all 40+ services)
│   └── WIDGETS/                      # Widget documentation
│       ├── slack-message-feed.md
│       ├── github-repo-overview.md
│       └── ... (all widget types)
├── schemas/                           # JSON schemas (REQUIRED)
│   ├── service-registry.schema.json
│   ├── api-response.schema.json
│   └── widget-config.schema.json
├── config/                            # Configuration templates (REQUIRED)
│   ├── nginx.conf.template
│   ├── docker-compose.yml.template
│   └── .env.example
└── components/                        # UI component files (if applicable)
    ├── SlackChannelBrowser.jsx
    ├── SlackMessageFeed.jsx
    └── ... (all component files)
```

---

## xibalba.manifest.json Schema

### Complete Schema Definition

```json
{
  "xibalbaManifestVersion": "1.0.0",
  "meta": {
    "name": "Obsidian OS UI Bundle",
    "version": "1.2.0",
    "description": "Complete Obsidian OS frontend with all Base44 integrations",
    "author": "Base44 Inc.",
    "buildDate": "2025-12-17T10:00:00Z",
    "framework": "react",
    "buildType": "static",
    "entry": "index.html"
  },
  "integrations": {
    "slack": {
      "serviceId": "slack",
      "name": "Slack",
      "category": "communication",
      "iconUrl": "assets/icons/slack.svg",
      "version": "1.0.0",
      "enabled": true,
      "authConfig": {
        "type": "oauth2",
        "label": "Connect your Slack Workspace",
        "scopes": [
          {
            "scope": "channels:history",
            "reason": "To read messages from public and private channels."
          },
          {
            "scope": "chat:write",
            "reason": "To post messages on your behalf."
          },
          {
            "scope": "users:read",
            "reason": "To resolve user IDs to names and avatars."
          }
        ],
        "urls": {
          "auth": "https://slack.com/oauth/v2/authorize",
          "token": "https://slack.com/api/oauth.v2.access",
          "revoke": "https://slack.com/api/oauth.v2.revoke"
        },
        "tokenResponseKey": "access_token",
        "scopeParam": "scope",
        "clientIdEnvVar": "BASE44_SLACK_CLIENT_ID",
        "clientSecretEnvVar": "BASE44_SLACK_CLIENT_SECRET"
      },
      "apiBlueprint": {
        "baseApiUrl": "https://slack.com/api/",
        "endpoints": {
          "getChannels": {
            "path": "conversations.list",
            "method": "GET",
            "docs": "Retrieves a list of all channels the user is in.",
            "responseSchema": {
              "$ref": "#/components/schemas/ChannelList"
            },
            "cache": {
              "key": "user:channels",
              "ttl": 3600
            }
          },
          "getMessages": {
            "path": "conversations.history",
            "method": "GET",
            "docs": "Retrieves messages from a specific channel.",
            "params": {
              "channel": { "type": "string", "required": true, "description": "The channel ID." },
              "limit": { "type": "number", "required": false, "default": 20, "description": "The number of messages to return." },
              "cursor": { "type": "string", "required": false, "description": "Pagination cursor." }
            },
            "responseSchema": {
              "$ref": "#/components/schemas/MessageFeed"
            }
          },
          "postMessage": {
            "path": "chat.postMessage",
            "method": "POST",
            "docs": "Posts a message to a channel.",
            "body": {
              "channel": { "type": "string", "required": true },
              "text": { "type": "string", "required": true }
            },
            "responseSchema": {
              "$ref": "#/components/schemas/PostMessageResponse"
            }
          }
        }
      },
      "uiBlueprint": {
        "components": {
          "SlackChannelBrowser": {
            "file": "components/SlackChannelBrowser.jsx",
            "props": {
              "onSelectChannel": { "type": "function", "required": true }
            },
            "description": "A searchable list of channels for selection."
          },
          "SlackMessageFeed": {
            "file": "components/SlackMessageFeed.jsx",
            "props": {
              "channelId": { "type": "string", "required": true },
              "onSendMessage": { "type": "function", "required": false }
            },
            "description": "Displays a list of messages from a channel."
          }
        },
        "workbenchPresets": {
          "developer": {
            "name": "Developer Slack Hub",
            "description": "A workspace for developers to track team communication.",
            "defaultLayout": "grid",
            "defaultWidgets": [
              { "component": "SlackChannelBrowser", "size": "medium" },
              { "component": "SlackMessageFeed", "size": "large", "props": { "channelId": "C0123ABC45" } }
            ]
          },
          "project_manager": {
            "name": "Project PM Command Center",
            "description": "Track project updates and team activity in one place.",
            "defaultLayout": "columns",
            "defaultWidgets": [
              { "component": "SlackChannelBrowser", "size": "small" },
              { "component": "SlackMessageFeed", "size": "large", "props": { "channelId": "C024BE91L" } }
            ]
          }
        }
      },
      "dataMapping": {
        "slack_message_to_os_message": {
          "transform": {
            "from": {
              "api": "Message",
              "path": "messages[*]"
            },
            "rules": [
              { "source": "ts", "target": "timestamp", "transform": "formatTimestamp" },
              { "source": "user", "target": "userId" },
              { "source": "text", "target": "body" }
            ]
          },
          "requires": {
            "userLookups": "userId"
          }
        }
      },
      "webhooks": {
        "enabled": true,
        "endpoint": "https://your-obsidian-api.com/api/hooks/slack",
        "eventSubscriptions": ["message.channels"],
        "reconnectionUrl": "https://your-obsidian-api.com/api/hooks/slack/reconnect"
      }
    },
    "github": {
      "serviceId": "github",
      "name": "GitHub",
      "category": "development",
      "iconUrl": "assets/icons/github.svg",
      "version": "1.0.0",
      "enabled": true,
      "authConfig": {
        "type": "oauth2",
        "label": "Connect your GitHub Account",
        "scopes": [
          {
            "scope": "repo",
            "reason": "To access repository information and code."
          },
          {
            "scope": "read:org",
            "reason": "To access organization repositories."
          }
        ],
        "urls": {
          "auth": "https://github.com/login/oauth/authorize",
          "token": "https://github.com/login/oauth/access_token",
          "revoke": "https://api.github.com/applications/{client_id}/token"
        },
        "tokenResponseKey": "access_token",
        "scopeParam": "scope",
        "clientIdEnvVar": "BASE44_GITHUB_CLIENT_ID",
        "clientSecretEnvVar": "BASE44_GITHUB_CLIENT_SECRET"
      },
      "apiBlueprint": {
        "baseApiUrl": "https://api.github.com/",
        "endpoints": {
          "getRepos": {
            "path": "user/repos",
            "method": "GET",
            "docs": "Lists repositories for the authenticated user.",
            "responseSchema": {
              "$ref": "#/components/schemas/RepoList"
            }
          },
          "getRepoDetails": {
            "path": "repos/{owner}/{repo}",
            "method": "GET",
            "docs": "Gets repository details.",
            "params": {
              "owner": { "type": "string", "required": true },
              "repo": { "type": "string", "required": true }
            },
            "responseSchema": {
              "$ref": "#/components/schemas/RepoDetails"
            }
          }
        }
      },
      "uiBlueprint": {
        "components": {
          "GitHubRepoOverview": {
            "file": "components/GitHubRepoOverview.jsx",
            "props": {
              "repoId": { "type": "string", "required": true },
              "showIssues": { "type": "boolean", "default": true }
            },
            "description": "Displays repository statistics and overview."
          }
        },
        "workbenchPresets": {
          "developer": {
            "name": "Developer GitHub Hub",
            "defaultLayout": "grid",
            "defaultWidgets": [
              { "component": "GitHubRepoOverview", "size": "large" }
            ]
          }
        }
      }
    }
  },
  "components": {
    "schemas": {
      "ChannelList": {
        "type": "object",
        "properties": {
          "channels": {
            "type": "array",
            "items": { "$ref": "#/components/schemas/Channel" }
          }
        }
      },
      "Channel": {
        "type": "object",
        "properties": {
          "id": { "type": "string" },
          "name": { "type": "string" },
          "is_private": { "type": "boolean" }
        }
      },
      "MessageFeed": {
        "type": "object",
        "properties": {
          "messages": {
            "type": "array",
            "items": { "$ref": "#/components/schemas/Message" }
          },
          "has_more": { "type": "boolean" }
        }
      },
      "Message": {
        "type": "object",
        "properties": {
          "ts": { "type": "string" },
          "user": { "type": "string" },
          "text": { "type": "string" }
        }
      },
      "RepoList": {
        "type": "object",
        "properties": {
          "repos": {
            "type": "array",
            "items": { "$ref": "#/components/schemas/Repo" }
          }
        }
      },
      "Repo": {
        "type": "object",
        "properties": {
          "id": { "type": "number" },
          "name": { "type": "string" },
          "full_name": { "type": "string" },
          "stars": { "type": "number" },
          "forks": { "type": "number" }
        }
      }
    }
  },
  "uiConfig": {
    "globalStyles": "styles/main.css",
    "theme": {
      "primaryColor": "#4A154B",
      "accentColor": "#FFFFFF",
      "requiresDarkMode": false
    },
    "fonts": [
      { "family": "Inter", "src": "assets/fonts/inter-regular.woff2", "weight": "400" },
      { "family": "Inter", "src": "assets/fonts/inter-bold.woff2", "weight": "700" }
    ]
  },
  "permissions": {
    "required": ["READ_MESSAGES", "CONNECT_ACCOUNT"],
    "dataAccess": {
      "channels": "read",
      "messages": "read",
      "users": "read"
    }
  }
}
```

### Required Fields

- `xibalbaManifestVersion`: Manifest schema version (string, required)
- `meta`: Bundle metadata (object, required)
  - `name`: Bundle name (string, required)
  - `version`: Semantic version (string, required, pattern: `^\d+\.\d+\.\d+$`)
  - `description`: Description (string, required)
  - `author`: Author name (string, required)
  - `buildDate`: ISO 8601 timestamp (string, required)
  - `framework`: Frontend framework (string, required, enum: ["react", "vue", "svelte", "next", "vite"])
  - `buildType`: Build type (string, required, enum: ["static"])
  - `entry`: Entry point file (string, required, default: "index.html")
- `integrations`: All service integrations (object, required)
  - Each service must include: `serviceId`, `name`, `category`, `authConfig`, `apiBlueprint`, `uiBlueprint`
- `components.schemas`: JSON schemas for all data structures (object, required)
- `uiConfig`: UI configuration (object, required)
- `permissions`: Permission requirements (object, required)

---

## Documentation Requirements

### 1. README.md (Required)

Must include:

```markdown
# Obsidian OS UI Bundle v{version}

**Build Date:** {ISO 8601 date}  
**Framework:** {framework name}  
**Design System:** Hallberg Maths (locked)

## Quick Start

1. Extract this zip file
2. Deploy the `dist/` folder to your web server
3. Configure API endpoints (see `docs/API_INTEGRATION.md`)
4. Review `docs/DATA_CONTRACT.md` for data schemas
5. Follow `docs/DEPLOYMENT.md` for complete setup

## What's New in This Version

- [List of new features]
- [List of bug fixes]
- [List of breaking changes]

## Known Issues

- [List any known issues]

## Documentation

This package includes:
- `docs/API_INTEGRATION.md` - All backend API endpoints needed
- `docs/DATA_CONTRACT.md` - Standardized data response schemas
- `docs/SITE_CONFIGURATION.md` - Nginx, Docker, environment variables
- `docs/DEPLOYMENT.md` - Step-by-step deployment instructions
- `docs/INTEGRATIONS/` - Per-service detailed documentation
- `docs/WIDGETS/` - Widget component documentation

## Support

For questions, contact: [Base44 contact info]
```

### 2. docs/API_INTEGRATION.md (Required)

Must document all API endpoints for all integrations. Format:

```markdown
# API Integration Guide

## Base URL
`/api` (relative to deployment domain)

## Authentication
All requests require JWT Bearer token:
```
Authorization: Bearer <token>
```

## Integrations

### Slack

#### GET /api/integrations/slack/channels
**Description:** Fetch list of Slack channels

**Request:**
```json
{
  "limit": 100
}
```

**Response:**
```json
{
  "meta": {
    "serviceId": "slack",
    "templateId": "channelList",
    "timestamp": "2025-12-17T10:00:00Z"
  },
  "data": {
    "channels": [...]
  }
}
```

#### GET /api/integrations/slack/messages
**Description:** Fetch messages from a Slack channel

**Request:**
```json
{
  "channelId": "C03BG96L1",
  "limit": 20
}
```

**Response:**
```json
{
  "meta": {
    "serviceId": "slack",
    "templateId": "messageFeed",
    "timestamp": "2025-12-17T10:00:00Z"
  },
  "data": {
    "messages": [...]
  }
}
```

### GitHub

#### GET /api/integrations/github/repos
**Description:** Fetch list of GitHub repositories

[Continue for all 40+ integrations...]
```

### 3. docs/DATA_CONTRACT.md (Required)

Must define standardized response format for all services:

```markdown
# Data Contract

## Standard Response Format

All API responses MUST follow this structure:

```json
{
  "meta": {
    "serviceId": "string",
    "templateId": "string",
    "requestId": "string",
    "timestamp": "ISO8601",
    "cacheStatus": "HIT|MISS"
  },
  "data": { /* service-specific */ },
  "pagination": { /* optional */ },
  "errors": [] /* optional */
}
```

## Service-Specific Schemas

### Slack Message Feed
```json
{
  "data": {
    "messages": [
      {
        "id": "string",
        "user": { "id": "string", "name": "string" },
        "text": "string",
        "timestamp": "number"
      }
    ]
  }
}
```

### GitHub Repo Overview
```json
{
  "data": {
    "repo": {
      "id": "number",
      "name": "string",
      "stars": "number",
      "forks": "number",
      "issues": "number"
    }
  }
}
```

[Continue for all services...]
```

### 4. docs/SITE_CONFIGURATION.md (Required)

Must include:

```markdown
# Site Configuration

## Environment Variables

### Required Variables

```env
# Odin API
DATABASE_URL=postgresql://user:password@postgres:5432/obsidian_db
JWT_SECRET=your-super-secret-jwt-key
PUBLIC_HTML_PATH=/var/www/html/obsidian

# Deployment Agent
AGENT_API_KEY=your-agent-specific-api-key

# Nginx
SSL_CERT_PATH=/etc/ssl/certs/cert.pem
SSL_KEY_PATH=/etc/ssl/private/key.pem

# Base44 Integration Credentials
BASE44_SLACK_CLIENT_ID=your-slack-client-id
BASE44_SLACK_CLIENT_SECRET=your-slack-client-secret
BASE44_GITHUB_CLIENT_ID=your-github-client-id
BASE44_GITHUB_CLIENT_SECRET=your-github-client-secret
[... for all 40+ integrations ...]
```

## Nginx Configuration

See `config/nginx.conf.template` for complete Nginx configuration.

Key requirements:
- Serve static files from `/var/www/html/obsidian`
- Proxy `/api/*` to `http://odin-api:3001`
- Enable gzip compression
- Set security headers
- Configure SSL (via Certbot)

## Docker Compose

See `config/docker-compose.yml.template` for complete Docker Compose setup.

Required services:
- `odin-api`: Main backend API (port 3001)
- `deployment-agent`: Deployment microservice (internal)
- `nginx`: Web server (ports 80, 443)
- `postgres`: Database (port 5432)
- `redis`: Cache (port 6379, optional)
```

### 5. docs/DEPLOYMENT.md (Required)

Must include step-by-step deployment instructions:

```markdown
# Deployment Guide

## Prerequisites

- Ubuntu Server 22.04 LTS or Debian Stable
- Docker and Docker Compose installed
- Domain name configured (e.g., os.xi-io.com)
- SSL certificate (Let's Encrypt via Certbot)

## Step 1: Extract ZIP

```bash
unzip obsidian-ui-v1.2.0.zip -d /tmp/obsidian-extract
cd /tmp/obsidian-extract
```

## Step 2: Configure Environment

```bash
cp config/.env.example .env
nano .env  # Edit with your values
```

## Step 3: Deploy via Deployment Service

Upload the ZIP file through the Obsidian OS deployment UI at `/api/deploy/upload`

## Step 4: Verify Deployment

Check that:
- [ ] All files extracted to `/var/www/html/obsidian`
- [ ] Nginx serving static files correctly
- [ ] API endpoints responding
- [ ] All integrations accessible

[Continue with detailed steps...]
```

### 6. docs/INTEGRATIONS/{service}.md (Required for each service)

One markdown file per integration. Format:

```markdown
# {Service Name} Integration

## Overview
[Description of the integration]

## Authentication
[OAuth flow, API keys, etc.]

## API Endpoints
[List all endpoints with request/response examples]

## Rate Limits
[Rate limit information]

## Webhooks
[Webhook setup if applicable]

## Troubleshooting
[Common issues and solutions]
```

---

## All Integrations Specification

Base44 must provide complete documentation for all 40+ integrations. Required services include:

### Communication
- Slack
- Microsoft Teams
- Discord
- Zoom
- Google Meet

### Development
- GitHub
- GitLab
- Bitbucket
- Jira
- Linear

### Productivity
- Notion
- Airtable
- Google Drive
- Dropbox
- OneDrive

### CRM & Sales
- Salesforce
- HubSpot
- Pipedrive
- Zoho CRM

### AI & Analytics
- OpenAI (GPT)
- Anthropic (Claude)
- Google Gemini
- Perplexity

### Finance
- eToro
- Stripe
- PayPal
- QuickBooks

### And 20+ more services...

Each integration must have:
- Complete `xibalba.manifest.json` entry
- `docs/INTEGRATIONS/{service}.md` documentation
- API endpoint specifications
- Data contract schemas
- Widget configurations
- Workbench presets (where applicable)

---

## Site Configuration

### Nginx Configuration Template

File: `config/nginx.conf.template`

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name os.xi-io.com;

    root /var/www/html/obsidian;
    index index.html;

    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline' 'unsafe-eval'" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss application/rss+xml font/truetype font/opentype application/vnd.ms-fontobject image/svg+xml;

    # Static file caching
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }

    # API proxy
    location /api/ {
        proxy_pass http://odin-api:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Frontend routing
    location / {
        try_files $uri $uri.html $uri/ /index.html;
    }

    # Deny access to hidden files
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }

    # Error pages
    error_page 404 /404.html;
    error_page 500 502 503 504 /500.html;
}
```

### Docker Compose Template

File: `config/docker-compose.yml.template`

```yaml
version: '3.8'

services:
  odin-api:
    image: xi-io/odin-api:latest
    container_name: odin-api
    ports:
      - "3001:3001"
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - JWT_SECRET=${JWT_SECRET}
      - PUBLIC_HTML_PATH=/var/www/html/obsidian
    volumes:
      - obsidian-content:/var/www/html/obsidian
      - odin-logs:/app/logs
    networks:
      - obsidian-network
    depends_on:
      - postgres

  deployment-agent:
    image: xi-io/deployment-agent:latest
    container_name: deployment-agent
    environment:
      - AGENT_API_KEY=${AGENT_API_KEY}
    volumes:
      - obsidian-content:/var/www/html/obsidian
    networks:
      - obsidian-network
    # Internal only, no ports exposed

  nginx:
    image: nginx:alpine
    container_name: nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - obsidian-content:/var/www/html/obsidian
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ssl-certs:/etc/ssl/certs
      - ssl-keys:/etc/ssl/private
    networks:
      - obsidian-network
    depends_on:
      - odin-api

  postgres:
    image: postgres:15
    container_name: postgres
    environment:
      - POSTGRES_DB=obsidian_db
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
    volumes:
      - postgres-data:/var/lib/postgresql/data
    networks:
      - obsidian-network

  redis:
    image: redis:7-alpine
    container_name: redis
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    networks:
      - obsidian-network

networks:
  obsidian-network:
    driver: bridge

volumes:
  postgres-data:
    driver: local
  redis-data:
    driver: local
  obsidian-content:
    driver: local
  odin-logs:
    driver: local
  ssl-certs:
    driver: local
  ssl-keys:
    driver: local
```

### Environment Variables Template

File: `config/.env.example`

```env
# Odin API Configuration
DATABASE_URL=postgresql://user:password@postgres:5432/obsidian_db
JWT_SECRET=your-super-secret-jwt-key-change-this
PUBLIC_HTML_PATH=/var/www/html/obsidian

# Deployment Agent
AGENT_API_KEY=your-agent-specific-api-key

# Nginx SSL
SSL_CERT_PATH=/etc/ssl/certs/cert.pem
SSL_KEY_PATH=/etc/ssl/private/key.pem

# Base44 Integration Credentials
# Slack
BASE44_SLACK_CLIENT_ID=your-slack-client-id
BASE44_SLACK_CLIENT_SECRET=your-slack-client-secret

# GitHub
BASE44_GITHUB_CLIENT_ID=your-github-client-id
BASE44_GITHUB_CLIENT_SECRET=your-github-client-secret

# Notion
BASE44_NOTION_CLIENT_ID=your-notion-client-id
BASE44_NOTION_CLIENT_SECRET=your-notion-client-secret

# Airtable
BASE44_AIRTABLE_API_KEY=your-airtable-api-key

# Salesforce
BASE44_SALESFORCE_CLIENT_ID=your-salesforce-client-id
BASE44_SALESFORCE_CLIENT_SECRET=your-salesforce-client-secret

# Google Drive
BASE44_GOOGLE_CLIENT_ID=your-google-client-id
BASE44_GOOGLE_CLIENT_SECRET=your-google-client-secret

# eToro
BASE44_ETORO_API_KEY=your-etoro-api-key

# AI Services
BASE44_OPENAI_API_KEY=your-openai-api-key
BASE44_ANTHROPIC_API_KEY=your-anthropic-api-key
BASE44_GOOGLE_GEMINI_API_KEY=your-gemini-api-key

# [... Continue for all 40+ integrations ...]
```

---

## Service Registry Schema

File: `schemas/service-registry.schema.json`

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Service Registry Schema",
  "description": "Schema for registering all Base44 integrations",
  "type": "object",
  "required": ["services"],
  "properties": {
    "services": {
      "type": "array",
      "items": {
        "type": "object",
        "required": ["id", "name", "category", "authType"],
        "properties": {
          "id": {
            "type": "string",
            "description": "Unique service identifier (e.g., 'slack', 'github')"
          },
          "name": {
            "type": "string",
            "description": "Human-readable service name"
          },
          "category": {
            "type": "string",
            "enum": ["communication", "development", "productivity", "crm", "ai", "finance", "other"]
          },
          "authType": {
            "type": "string",
            "enum": ["oauth2", "api_key", "basic", "none"]
          },
          "iconUrl": {
            "type": "string",
            "format": "uri"
          },
          "version": {
            "type": "string",
            "pattern": "^\\d+\\.\\d+\\.\\d+$"
          },
          "enabled": {
            "type": "boolean",
            "default": true
          }
        }
      }
    }
  }
}
```

---

## API Integration Specifications

All API endpoints must be documented in `docs/API_INTEGRATION.md` with:

1. Endpoint path
2. HTTP method
3. Request body schema (if applicable)
4. Response schema
5. Authentication requirements
6. Rate limits
7. Error responses
8. Example requests/responses

Format for each endpoint:

```markdown
### {HTTP Method} /api/integrations/{serviceId}/{endpoint}

**Description:** {What this endpoint does}

**Authentication:** {Required auth method}

**Request:**
```json
{
  "param1": "value1",
  "param2": "value2"
}
```

**Response (200 OK):**
```json
{
  "meta": {
    "serviceId": "{serviceId}",
    "templateId": "{templateId}",
    "timestamp": "2025-12-17T10:00:00Z"
  },
  "data": {
    // Service-specific data
  }
}
```

**Error Responses:**
- `401 Unauthorized`: Invalid or missing authentication
- `404 Not Found`: Resource not found
- `429 Too Many Requests`: Rate limit exceeded
- `500 Internal Server Error`: Server error
```

---

## Data Contracts

All API responses must follow the standardized format defined in `docs/DATA_CONTRACT.md`:

### Standard Response Structure

```json
{
  "meta": {
    "serviceId": "string",
    "templateId": "string",
    "requestId": "string",
    "timestamp": "ISO8601",
    "cacheStatus": "HIT|MISS"
  },
  "data": {
    // Service-specific payload
  },
  "pagination": {
    "hasMore": "boolean",
    "nextCursor": "string",
    "totalCount": "number"
  },
  "errors": [
    {
      "code": "string",
      "message": "string",
      "field": "string"
    }
  ]
}
```

### Service-Specific Data Schemas

Each service must define its data schemas in:
1. `xibalba.manifest.json` → `components.schemas`
2. `docs/DATA_CONTRACT.md` → Service-specific section
3. `schemas/api-response.schema.json` → JSON Schema definitions

---

## Widget Configurations

Each widget must be documented with:

1. Component file path
2. Props schema
3. Data requirements
4. Usage examples
5. Styling guidelines

Format: `docs/WIDGETS/{widget-name}.md`

```markdown
# {Widget Name}

## Component
`components/{WidgetName}.jsx`

## Props

| Prop | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `prop1` | string | Yes | - | Description |
| `prop2` | number | No | 20 | Description |

## Data Requirements

This widget expects data in the following format:

```json
{
  "data": {
    // Widget-specific data structure
  }
}
```

## Usage Example

```jsx
<WidgetName
  prop1="value1"
  prop2={20}
  onAction={handleAction}
/>
```

## Styling

This widget uses the Hallberg Maths design system:
- Colors: [specify]
- Typography: [specify]
- Spacing: [specify]
```

---

## Workbench Configurations

Each workbench preset must be defined in:

1. `xibalba.manifest.json` → `integrations.{serviceId}.uiBlueprint.workbenchPresets`
2. `docs/WORKBENCHES.md` → Human-readable documentation

Format:

```markdown
# Workbench Presets

## Developer Workbench

**Service:** GitHub, Slack  
**Layout:** Grid  
**Widgets:**
- GitHubRepoOverview (large)
- SlackMessageFeed (medium)
- SlackChannelBrowser (small)

## Project Manager Workbench

**Service:** Slack, Notion, Airtable  
**Layout:** Columns  
**Widgets:**
- SlackChannelBrowser (small)
- SlackMessageFeed (large)
- NotionBoard (medium)
- AirtableTable (medium)

[Continue for all workbench presets...]
```

---

## Deployment Instructions

Complete deployment guide must be in `docs/DEPLOYMENT.md`:

### Prerequisites
- Operating system requirements
- Software dependencies
- Network requirements
- Domain configuration

### Step-by-Step Deployment

1. **Extract ZIP Package**
   ```bash
   unzip obsidian-ui-v{version}.zip -d /tmp/obsidian-extract
   ```

2. **Configure Environment**
   ```bash
   cp config/.env.example .env
   # Edit .env with your values
   ```

3. **Deploy via Deployment Service**
   - Upload ZIP through `/api/deploy/upload`
   - Configure via `/api/deploy/configure`
   - Execute via `/api/deploy/execute`

4. **Verify Deployment**
   - Check file locations
   - Test API endpoints
   - Verify integrations
   - Check logs

5. **Post-Deployment**
   - SSL setup (Certbot)
   - Database migrations
   - Service health checks

---

## Validation Checklist

Before delivery, Base44 must verify:

### File Structure
- [ ] `dist/` folder contains built assets
- [ ] `xibalba.manifest.json` exists and is valid JSON
- [ ] `README.md` exists
- [ ] `docs/` folder contains all required documentation
- [ ] `schemas/` folder contains all JSON schemas
- [ ] `config/` folder contains configuration templates

### Manifest Validation
- [ ] `xibalbaManifestVersion` is specified
- [ ] All required `meta` fields present
- [ ] All integrations have complete entries
- [ ] All API endpoints documented
- [ ] All UI components specified
- [ ] All workbench presets defined

### Documentation Validation
- [ ] `docs/API_INTEGRATION.md` documents all endpoints
- [ ] `docs/DATA_CONTRACT.md` defines all schemas
- [ ] `docs/SITE_CONFIGURATION.md` complete
- [ ] `docs/DEPLOYMENT.md` has step-by-step instructions
- [ ] Each integration has `docs/INTEGRATIONS/{service}.md`
- [ ] Each widget has `docs/WIDGETS/{widget}.md`

### Configuration Validation
- [ ] `config/nginx.conf.template` is valid Nginx config
- [ ] `config/docker-compose.yml.template` is valid YAML
- [ ] `config/.env.example` includes all required variables

### Integration Validation
- [ ] All 40+ integrations documented
- [ ] All OAuth flows specified
- [ ] All API endpoints documented
- [ ] All data schemas defined
- [ ] All widgets configured
- [ ] All workbench presets defined

---

## Summary

This specification ensures that every Base44 ZIP package is:
- ✅ Self-contained (all documentation included)
- ✅ Machine-readable (structured JSON manifests)
- ✅ Human-readable (comprehensive README files)
- ✅ Complete (all integrations documented)
- ✅ Deployable (complete configuration included)

**Result:** Zero back-and-forth communication. Base44 delivers everything needed in a single ZIP package, and the deployment system can automatically configure and deploy the entire Obsidian OS frontend.

---

**Status:** ✅ **READY FOR BASE44 IMPLEMENTATION**

**Next Steps:**
1. Base44 reviews this specification
2. Base44 creates ZIP package following this structure
3. Base44 includes all 40+ integrations
4. Base44 delivers complete package
5. Deployment system validates and deploys automatically

---

**Hashtag:** `#base44-zip-spec`, `#obsidian-os`, `#integration-manifest`, `#complete-documentation