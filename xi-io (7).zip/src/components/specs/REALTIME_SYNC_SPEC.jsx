# Real-Time Synchronization Spec [LOCKED]

## Architecture
- **Protocol**: Secure WebSockets (WSS)
- **Gateway**: Nginx -> Node.js WebSocket Server
- **Authentication**: JWT via handshake query param

## Channels
- `system:broadcast`: Global announcements
- `user:{id}:notifications`: Private alerts
- `workspace:{id}:sync`: Collaborative editing

## Client Implementation
- use `useWebSocket` hook in `components/hooks/useWebSocket.js`
- Auto-reconnect with exponential backoff
- Message queue for offline state