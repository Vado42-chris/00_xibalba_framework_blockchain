# Base44 Master Specification [LOCKED]

## 1. Architecture Overview
- **Framework**: React + Vite (Base44 Platform)
- **Styling**: Tailwind CSS + Shadcn UI
- **State Management**: React Query + Context API
- **Routing**: React Router DOM (Flat structure in `pages/`)

## 2. Component Architecture
- **Atomic Design**: Atoms (UI), Molecules (Widgets), Organisms (Dashboards)
- **Lazy Loading**: All major widgets must be lazy loaded
- **Error Boundaries**: `SmartErrorBoundary` wrapping every major section

## 3. Key Systems
- **Identity**: `SiteContext` for theming and domain handling
- **Navigation**: `DesktopEnvironment` for OS-like experience
- **Data**: `UniversalDataSchema` for all entity interactions

## 4. Build Guidelines
- **No Nested Pages**: All pages in `pages/` root
- **Lucide Icons**: Only import known existing icons
- **Responsive**: Mobile-first, desktop-enhanced