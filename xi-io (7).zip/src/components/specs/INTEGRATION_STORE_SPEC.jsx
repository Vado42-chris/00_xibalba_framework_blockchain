// components/specs/INTEGRATION_STORE_SPEC.md
# Integration Store Specification

**Version:** 1.0.0
**Date:** 2025-12-18
**Status:** ✅ **ACTIVE SPECIFICATION**
**Hashtag:** `#integration-store`, `#marketplace`, `#obsidian-os`

---

## 1.0 Overview

The Integration Store is the user-facing catalog for discovering and installing Base44 integrations. It transforms the integration process from a technical configuration task into a "one-click" consumer experience.

---

## 2.0 User Experience (UX)

### 2.1 The Storefront (`/store`)

*   **Layout:** Grid of "Integration Cards," categorised by type (Communication, Dev, CRM, etc.).
*   **Search:** Instant search by name, category, or capability.
*   **Card Content:**
    *   Icon & Name (e.g., Slack, GitHub).
    *   Status Badge (Connected / Not Connected / Update Available).
    *   "Connect" or "Manage" button.

### 2.2 Integration Detail View

*   **Description:** Rich text description from `xibalba.manifest.json`.
*   **Capabilities:** List of features (e.g., "Sync messages," "Update contacts").
*   **Screenshots:** Preview of the widgets included in the bundle.
*   **Permissions:** Clear list of OAuth scopes requested.

### 2.3 The "One-Click" Install Flow

1.  User clicks "Connect" on the Slack card.
2.  **OAuth Popup:** Opens the OAuth provider's auth page.
3.  User authorizes access.
4.  **Success:** Popup closes, store card updates to "Connected".
5.  **Auto-Configuration:**
    *   System automatically provisions the default `workbenchPresets` defined in the manifest.
    *   User is prompted: "Add Slack widgets to your current dashboard?"

---

## 3.0 Technical Architecture

### 3.1 The Registry Service

*   **Source of Truth:** The `docs/SERVICE_DEFINITIONS/` directory in the deployed bundle serves as the database for the store.
*   **Endpoint:** `GET /api/store/catalog`
    *   Scans the definitions directory.
    *   Returns a list of all available integrations with metadata (name, icon, description, category).
    *   Checks `user_service_tokens` table to populate "connected" status for the current user.

### 3.2 Dynamic Asset Loading

*   Icons and screenshots are served directly from the `assets/` folder of the deployed bundle via Nginx.

### 3.3 Dynamic OAuth Handler

*   A generic OAuth handler that reads the `authConfig` from the specific service definition at runtime.
*   **Endpoint:** `GET /api/auth/connect/{serviceId}`
    *   Look up `serviceId` in registry.
    *   Construct OAuth URL based on `authConfig.urls.auth`, `clientId`, and `scopes`.
    *   Redirect user.
*   **Callback:** `GET /api/auth/callback/{serviceId}`
    *   Exchange code for token using `authConfig.urls.token`.
    *   Store token in `user_service_tokens` (encrypted).

---

## 4.0 Component Design

### 4.1 `<IntegrationStore />`

*   **State:** Fetches catalog from `/api/store/catalog`.
*   **Render:** Maps over catalog items to render `<IntegrationCard />` components.

### 4.2 `<IntegrationCard />`

*   **Props:** `integration` object.
*   **Action:** Handles the "Connect" click logic (window.open for OAuth).

---

**Status:** ✅ **READY FOR IMPLEMENTATION**