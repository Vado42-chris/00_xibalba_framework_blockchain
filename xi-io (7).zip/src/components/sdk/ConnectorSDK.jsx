/**
 * Valhalla Connector SDK v1.0
 * 
 * This SDK allows developers to define custom connectors for the Valhalla platform.
 * Implement the ConnectorDefinition interface to create a new integration.
 */

export class ConnectorDefinition {
    constructor(config) {
        this.id = config.id;
        this.name = config.name;
        this.version = config.version || '1.0.0';
        this.authType = config.authType || 'none'; // 'oauth2', 'api_key', 'basic', 'none'
        this.triggers = config.triggers || [];
        this.actions = config.actions || [];
        this.schema = config.schema || {};
    }

    /**
     * Validates the connector configuration
     */
    validate() {
        if (!this.id || !this.name) {
            throw new Error("Connector must have an ID and Name");
        }
        return true;
    }

    /**
     * Defines an action that this connector can perform
     * @param {string} key - Unique key for the action
     * @param {string} name - Human readable name
     * @param {object} inputSchema - JSON Schema for inputs
     * @param {function} handler - Function to execute
     */
    defineAction(key, name, inputSchema, handler) {
        this.actions.push({
            key,
            name,
            inputSchema,
            handler
        });
    }

    /**
     * Defines a trigger that starts a workflow
     * @param {string} key - Unique key for the trigger
     * @param {string} name - Human readable name
     * @param {string} type - 'polling' or 'webhook'
     */
    defineTrigger(key, name, type = 'polling') {
        this.triggers.push({
            key,
            name,
            type
        });
    }

    /**
     * Export the definition JSON
     */
    toJSON() {
        return {
            id: this.id,
            name: this.name,
            version: this.version,
            auth: { type: this.authType },
            capabilities: {
                triggers: this.triggers,
                actions: this.actions.map(a => ({
                    key: a.key,
                    name: a.name,
                    inputs: a.inputSchema
                }))
            }
        };
    }
}

export const createConnector = (config) => new ConnectorDefinition(config);