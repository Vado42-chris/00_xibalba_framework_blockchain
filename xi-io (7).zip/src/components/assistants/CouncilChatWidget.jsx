import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    Users, Target, MapPin, Clock, HelpCircle, 
    ChevronDown, Check, Plus, ArrowRight, Zap, 
    Layers, Copy, FileText, CheckCircle2,
    Calendar, Lightbulb, Map
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import ReactMarkdown from 'react-markdown';
import { toast } from "sonner";
import { base44 } from '@/api/base44Client';

const PERSPECTIVES = {
    WHO: { icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20', label: 'Stakeholders' },
    WHAT: { icon: Target, color: 'text-green-400', bg: 'bg-green-500/10', border: 'border-green-500/20', label: 'Objectives' },
    WHERE: { icon: MapPin, color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/20', label: 'Context' },
    WHEN: { icon: Clock, color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20', label: 'Timeline' },
    WHY: { icon: HelpCircle, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20', label: 'Purpose' }
};

export default function CouncilChatWidget({ data }) {
    const [expandedId, setExpandedId] = useState(null);
    const [actionsTaken, setActionsTaken] = useState({});

    const handleAction = async (action, item, e) => {
        e.stopPropagation();
        const key = `${item.id}-${action}`;
        
        // Simulating action execution
        setActionsTaken(prev => ({ ...prev, [key]: 'loading' }));
        
        try {
            // Here we would call actual base44 APIs
            // For now we simulate specific actions based on role
            await new Promise(r => setTimeout(r, 800));
            
            if (action === 'task' && item.role === 'WHAT') {
                 await base44.entities.Task.create({
                     title: `Execute: ${item.content.substring(0, 50)}...`,
                     description: item.content,
                     project_id: 'default'
                 });
            }

            setActionsTaken(prev => ({ ...prev, [key]: 'success' }));
            toast.success(`${action.toUpperCase()} action executed for ${item.role}`);
        } catch (error) {
            setActionsTaken(prev => ({ ...prev, [key]: 'error' }));
            toast.error("Action failed");
        }
    };

    return (
        <div className="mt-4 space-y-2 w-full max-w-3xl mx-auto">
            <div className="flex items-center gap-2 mb-3 px-1">
                <Layers className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                <span className="text-[10px] font-bold tracking-widest text-neutral-400 uppercase">Council Deliberation Artifacts</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                {data.map((item) => {
                    const style = PERSPECTIVES[item.role] || PERSPECTIVES.WHO;
                    const Icon = style.icon;
                    const isExpanded = expandedId === item.id;

                    return (
                        <motion.div 
                            key={item.id}
                            layout
                            className={cn(
                                "relative rounded-lg border overflow-hidden transition-all duration-300 cursor-pointer",
                                isExpanded ? `md:col-span-5 ${style.bg} ${style.border}` : "bg-neutral-900/50 border-white/5 hover:border-white/10"
                            )}
                            onClick={() => setExpandedId(isExpanded ? null : item.id)}
                        >
                            {/* Card Header */}
                            <div className="p-3 flex flex-col h-full relative z-10">
                                <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2">
                                        <div className={cn("p-1.5 rounded-md bg-black/40", style.color)}>
                                            <Icon className="w-4 h-4" />
                                        </div>
                                        <div className="flex flex-col">
                                            <span className={cn("text-[10px] font-black tracking-wider", style.color)}>{item.role}</span>
                                            <span className="text-[9px] text-neutral-500 font-mono">{style.label}</span>
                                        </div>
                                    </div>
                                    <motion.div 
                                        animate={{ rotate: isExpanded ? 180 : 0 }}
                                        className="text-neutral-500"
                                    >
                                        <ChevronDown className="w-4 h-4" />
                                    </motion.div>
                                </div>

                                {/* Preview Text (Only when collapsed) */}
                                {!isExpanded && (
                                    <p className="text-[10px] text-neutral-400 line-clamp-3 font-mono leading-relaxed opacity-80">
                                        {item.content.replace(/[#*`]/g, '')}
                                    </p>
                                )}
                            </div>

                            {/* Expanded Content */}
                            <AnimatePresence>
                                {isExpanded && (
                                    <motion.div 
                                        initial={{ opacity: 0, height: 0 }}
                                        animate={{ opacity: 1, height: 'auto' }}
                                        exit={{ opacity: 0, height: 0 }}
                                        className="px-4 pb-4"
                                    >
                                        <div className="pt-2 border-t border-black/10 dark:border-white/5 mb-4">
                                            <div className="prose prose-invert prose-sm max-w-none text-xs leading-relaxed text-neutral-300 font-mono">
                                                <ReactMarkdown>{item.content}</ReactMarkdown>
                                            </div>
                                        </div>

                                        {/* Action Bar */}
                                        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-black/10 dark:border-white/5">
                                            <span className="text-[9px] font-bold text-neutral-500 uppercase tracking-wider mr-auto">Available Actions</span>
                                            
                                            <ActionButton 
                                                icon={Copy} 
                                                label="Copy" 
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    navigator.clipboard.writeText(item.content);
                                                    toast.success("Copied to clipboard");
                                                }}
                                            />

                                            {item.role === 'WHAT' && (
                                                <ActionButton 
                                                    icon={CheckCircle2} 
                                                    label="Create Task" 
                                                    status={actionsTaken[`${item.id}-task`]}
                                                    onClick={(e) => handleAction('task', item, e)}
                                                    activeColor="text-green-400"
                                                />
                                            )}

                                            {item.role === 'WHO' && (
                                                <ActionButton 
                                                    icon={Users} 
                                                    label="Map Agents" 
                                                    status={actionsTaken[`${item.id}-map`]}
                                                    onClick={(e) => handleAction('map', item, e)}
                                                    activeColor="text-blue-400"
                                                />
                                            )}

                                            {item.role === 'WHEN' && (
                                                <ActionButton 
                                                    icon={Calendar} 
                                                    label="Schedule" 
                                                    status={actionsTaken[`${item.id}-schedule`]}
                                                    onClick={(e) => handleAction('schedule', item, e)}
                                                    activeColor="text-purple-400"
                                                />
                                            )}
                                             {item.role === 'WHERE' && (
                                                <ActionButton 
                                                    icon={Map} 
                                                    label="Pin Context" 
                                                    status={actionsTaken[`${item.id}-pin`]}
                                                    onClick={(e) => handleAction('pin', item, e)}
                                                    activeColor="text-orange-400"
                                                />
                                            )}
                                             {item.role === 'WHY' && (
                                                <ActionButton 
                                                    icon={Lightbulb} 
                                                    label="Save Insight" 
                                                    status={actionsTaken[`${item.id}-insight`]}
                                                    onClick={(e) => handleAction('insight', item, e)}
                                                    activeColor="text-red-400"
                                                />
                                            )}
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>

                            {/* Decorative Background Element */}
                            {isExpanded && (
                                <div className={cn("absolute top-0 right-0 p-32 opacity-5 blur-3xl pointer-events-none rounded-full transform translate-x-1/2 -translate-y-1/2", style.bg.replace('/10', '/30'))} />
                            )}
                        </motion.div>
                    );
                })}
            </div>
        </div>
    );
}

function ActionButton({ icon: Icon, label, onClick, status, activeColor = "text-[hsl(var(--color-intent))]" }) {
    if (status === 'success') {
        return (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/10 text-green-400 rounded-full border border-green-500/20">
                <Check className="w-3 h-3" />
                <span className="text-[10px] font-bold">Done</span>
            </div>
        );
    }

    return (
        <button 
            onClick={onClick}
            disabled={status === 'loading'}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white rounded-full border border-white/5 transition-all group"
        >
            {status === 'loading' ? (
                <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
                <Icon className={cn("w-3 h-3 group-hover:scale-110 transition-transform", activeColor)} />
            )}
            <span className="text-[10px] font-medium">{label}</span>
        </button>
    );
}