import React, { useState } from 'react';
import { 
    Terminal, FileCode, Shield, Zap, Copy, 
    CheckCircle2, Fingerprint, Lock, Cpu
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';

const MOCK_DOTFILES = [
    { id: 'zshrc', name: '.zshrc', type: 'System', context: 'Shell Configuration' },
    { id: 'vimrc', name: '.vimrc', type: 'Editor', context: 'Editor Preferences' },
    { id: 'git', name: '.gitconfig', type: 'Identity', context: 'Version Control Identity' },
    { id: 'ssh', name: '.ssh/config', type: 'Security', context: 'Key Management' }
];

export default function PromptInjector({ targetUrl, onClose }) {
    const [prompt, setPrompt] = useState('');
    const [selectedContexts, setSelectedContexts] = useState([]);
    const [isSigning, setIsSigning] = useState(false);
    const [lastHash, setLastHash] = useState(null);

    const toggleContext = (id) => {
        if (selectedContexts.includes(id)) {
            setSelectedContexts(prev => prev.filter(c => c !== id));
        } else {
            setSelectedContexts(prev => [...prev, id]);
        }
    };

    const handleForgeAndSign = async () => {
        if (!prompt.trim()) {
            toast.error("Prompt cannot be empty");
            return;
        }

        setIsSigning(true);
        const timestamp = new Date().toISOString();
        // Simulate hashing
        const contentToHash = `${timestamp}-${prompt}-${selectedContexts.join(',')}`;
        const mockHash = '0x' + Array.from(contentToHash).reduce((h, c) => (Math.imul(31, h) + c.charCodeAt(0)) | 0, 0).toString(16) + '...f9';

        try {
            // Record to Immutable Ledger
            await base44.entities.ChainLedger.create({
                hash: mockHash,
                timestamp: timestamp,
                target_ai: targetUrl || 'Unknown Web Source',
                prompt_content: prompt,
                dotfile_context: selectedContexts,
                signature: `SIG-${Date.now()}`
            });

            // Simulate "Injection"
            await navigator.clipboard.writeText(prompt);
            
            setLastHash(mockHash);
            toast.success("Prompt Signed & Copied to Clipboard");
        } catch (error) {
            console.error("Ledger Error", error);
            toast.error("Failed to sign interaction");
        } finally {
            setIsSigning(false);
        }
    };

    return (
        <div className="absolute top-12 right-4 w-80 bg-black/90 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden flex flex-col z-[60]">
            {/* Header */}
            <div className="h-10 bg-neutral-900/50 border-b border-white/5 flex items-center justify-between px-3">
                <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <span className="text-xs font-bold tracking-widest text-white uppercase">Prompt Forge</span>
                </div>
                <div className="flex items-center gap-2">
                    <div className="px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-1">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-[9px] font-mono text-emerald-500">SECURE</span>
                    </div>
                </div>
            </div>

            {/* Content */}
            <div className="p-4 space-y-4">
                {/* Context Selector */}
                <div className="space-y-2">
                    <span className="text-[10px] text-neutral-500 font-mono uppercase">Active Context (Dotfiles)</span>
                    <div className="flex flex-wrap gap-1.5">
                        {MOCK_DOTFILES.map(file => {
                            const active = selectedContexts.includes(file.id);
                            return (
                                <button
                                    key={file.id}
                                    onClick={() => toggleContext(file.id)}
                                    className={cn(
                                        "px-2 py-1 rounded text-[10px] border transition-all flex items-center gap-1.5",
                                        active 
                                            ? "bg-white/10 border-white/20 text-white" 
                                            : "bg-transparent border-white/5 text-neutral-500 hover:border-white/10"
                                    )}
                                >
                                    <FileCode className="w-3 h-3" />
                                    {file.name}
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* Prompt Input */}
                <div className="space-y-2">
                    <div className="flex justify-between items-center">
                        <span className="text-[10px] text-neutral-500 font-mono uppercase">Injection Payload</span>
                        {selectedContexts.length > 0 && (
                            <span className="text-[9px] text-[hsl(var(--color-intent))]">
                                + {selectedContexts.length} Contexts Linked
                            </span>
                        )}
                    </div>
                    <Textarea 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Draft your prompt here..."
                        className="bg-black/50 border-white/10 text-xs font-mono min-h-[100px] resize-none focus:border-[hsl(var(--color-intent))]"
                    />
                </div>

                {/* Ledger Status */}
                <AnimatePresence>
                    {lastHash && (
                        <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="bg-neutral-900 rounded p-2 border border-white/5 flex items-center gap-2 overflow-hidden"
                        >
                            <Fingerprint className="w-4 h-4 text-neutral-500 shrink-0" />
                            <div className="flex flex-col min-w-0">
                                <span className="text-[9px] text-neutral-500 uppercase font-bold">Block Hash Recorded</span>
                                <span className="text-[9px] text-neutral-600 font-mono truncate w-full">{lastHash}</span>
                            </div>
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 ml-auto" />
                        </motion.div>
                    )}
                </AnimatePresence>

                {/* Actions */}
                <Button 
                    onClick={handleForgeAndSign}
                    disabled={isSigning}
                    className="w-full bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-black font-bold h-9 text-xs gap-2"
                >
                    {isSigning ? (
                        <>
                            <div className="w-3 h-3 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                            <span>Signing Block...</span>
                        </>
                    ) : (
                        <>
                            <Zap className="w-3.5 h-3.5" />
                            <span>Sign & Inject</span>
                        </>
                    )}
                </Button>

                <div className="text-[9px] text-neutral-600 text-center font-mono">
                    Interactions are immutably recorded on the XI-Chain.
                </div>
            </div>
        </div>
    );
}