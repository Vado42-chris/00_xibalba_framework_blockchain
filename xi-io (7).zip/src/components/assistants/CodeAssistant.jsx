import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuthority } from '@/components/useAuthority';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import ReactMarkdown from 'react-markdown';
import { 
    Sparkles, Bot, Terminal, X, ArrowRight, Bug, Zap, Code2, 
    Loader2, Check, RefreshCw, Settings, FileText
} from 'lucide-react';
import { 
    OrientingText, IntentText, StateText, AtomicParagraph 
} from '@/components/ui/design-system/System';
import { DeltaDiff } from '@/components/ui/design-system/Infographics';

export default function CodeAssistant({ onClose, mode, contextCode, onApplyCode }) {
    const { role } = useAuthority();
    const [messages, setMessages] = useState([
        { role: 'assistant', content: `Identity verified: **${role || 'GUEST'}**. \n\nI am ready to assist with code generation, debugging, and refactoring tasks.` }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [systemInstructions, setSystemInstructions] = useState(() => localStorage.getItem('xi_system_instructions') || '');
    const scrollRef = useRef(null);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages]);

    const saveInstructions = () => {
        localStorage.setItem('xi_system_instructions', systemInstructions);
        setShowSettings(false);
        setMessages(prev => [...prev, { role: 'assistant', content: 'System instructions updated. I will follow these rules for future responses.' }]);
    };

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        const userMsg = { role: 'user', content: input };
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsLoading(true);

        try {
            // Construct a rich prompt with context
            const systemContext = `
You are an expert AI Code Assistant in the Base44 environment.
Current User Role: ${role || 'user'}.
Current Code Context:
\`\`\`javascript
${contextCode || '// No context provided'}
\`\`\`

System Instructions (ALWAYS FOLLOW):
${systemInstructions}

Standard Instructions:
- Tailor your response to the user's role (Admin: Security/Performance, Developer: Implementation/Clean Code).
- If asked to refactor or fix, provide a clear explanation and then the code block.
- Keep responses concise and actionable.
            `;

            const fullPrompt = `${systemContext}\n\nUser Request: ${input}`;

            // Call LLM Integration
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: fullPrompt,
                add_context_from_internet: false // Focused on internal code
            });

            // Parse response - integration returns a string (unless schema is provided)
            // It might be a JSON string if the LLM decided to be structured, but usually just text.
            let content = response;
            if (typeof response === 'object' && response.text) content = response.text;

            setMessages(prev => [...prev, { role: 'assistant', content }]);

        } catch (error) {
            console.error(error);
            setMessages(prev => [...prev, { role: 'assistant', content: `**Error:** Failed to process request. ${error.message}` }]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleQuickAction = (action) => {
        const prompts = {
            generate: "Generate a function to...",
            debug: "Explain the error in this code and how to fix it:",
            refactor: "Refactor the current code for better readability and performance."
        };
        setInput(prompts[action]);
    };

    return (
        <div className="flex flex-col h-full bg-[hsl(var(--layer-state))]">
            {/* Header */}
            <div className="h-10 border-b border-[hsl(var(--layer-orientation))]/50 flex items-center justify-between px-4 select-none bg-[hsl(var(--layer-state))] shrink-0">
               <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                  <OrientingText className="font-bold tracking-wide">ASSISTANT</OrientingText>
               </div>
               <div className="flex items-center gap-2">
                 <span className="text-[9px] text-[hsl(var(--fg-state))] font-mono px-1.5 py-0.5 border border-[hsl(var(--layer-orientation))] rounded">
                   {mode}
                 </span>
                 <button onClick={() => setShowSettings(!showSettings)} title="System Instructions">
                    <Settings className={`w-4 h-4 ${showSettings ? 'text-[hsl(var(--color-active))]' : 'text-[hsl(var(--fg-orientation))]'} hover:text-[hsl(var(--fg-intent))]`} />
                 </button>
                 <button onClick={onClose}>
                    <X className="w-4 h-4 text-[hsl(var(--fg-orientation))] hover:text-[hsl(var(--fg-intent))]" />
                 </button>
               </div>
            </div>

            {/* Settings Mode */}
            {showSettings && (
                <div className="flex-1 flex flex-col p-4 bg-[hsl(var(--layer-state))] animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center gap-2 mb-4">
                        <FileText className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                        <OrientingText className="font-bold">SYSTEM INSTRUCTIONS</OrientingText>
                    </div>
                    <p className="text-[10px] text-[hsl(var(--fg-state))] mb-2 opacity-70">
                        Define global rules for the AI (e.g., "Always use TypeScript", "Prefer functional components", "Be terse"). These apply to every request.
                    </p>
                    <textarea 
                        className="flex-1 bg-[hsl(var(--void))] border border-[hsl(var(--layer-orientation))] rounded-lg p-3 text-xs text-[hsl(var(--fg-intent))] font-mono resize-none focus:outline-none focus:border-[hsl(var(--color-active))]/50 mb-4"
                        placeholder="e.g. Always use Tailwind CSS, no inline styles..."
                        value={systemInstructions}
                        onChange={(e) => setSystemInstructions(e.target.value)}
                    />
                    <div className="flex justify-end gap-2">
                        <button 
                            onClick={() => setShowSettings(false)}
                            className="px-3 py-1.5 rounded text-xs text-[hsl(var(--fg-state))] hover:bg-[hsl(var(--layer-orientation))]"
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={saveInstructions}
                            className="px-3 py-1.5 rounded text-xs bg-[hsl(var(--color-active))] text-black font-bold hover:bg-[hsl(var(--color-active))]/90"
                        >
                            Save Rules
                        </button>
                    </div>
                </div>
            )}

            {/* Quick Actions */}
            {!showSettings && (
            <div className="p-2 grid grid-cols-3 gap-2 border-b border-[hsl(var(--layer-orientation))]/50 bg-[hsl(var(--layer-orientation))]">
                <button onClick={() => handleQuickAction('generate')} className="flex flex-col items-center gap-1 p-2 rounded hover:bg-[hsl(var(--layer-intent))] transition-colors group">
                    <Code2 className="w-4 h-4 text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--color-active))]" />
                    <span className="text-[9px] font-medium text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--fg-intent))]">Generate</span>
                </button>
                <button onClick={() => handleQuickAction('debug')} className="flex flex-col items-center gap-1 p-2 rounded hover:bg-[hsl(var(--layer-intent))] transition-colors group">
                    <Bug className="w-4 h-4 text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--color-warning))]" />
                    <span className="text-[9px] font-medium text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--fg-intent))]">Debug</span>
                </button>
                <button onClick={() => handleQuickAction('refactor')} className="flex flex-col items-center gap-1 p-2 rounded hover:bg-[hsl(var(--layer-intent))] transition-colors group">
                    <Zap className="w-4 h-4 text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--color-intent))]" />
                    <span className="text-[9px] font-medium text-[hsl(var(--fg-orientation))] group-hover:text-[hsl(var(--fg-intent))]">Refactor</span>
                </button>
            </div>
            )}

            {/* Messages */}
            {!showSettings && (
            <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-[hsl(var(--layer-orientation))]" ref={scrollRef}>
                {messages.map((msg, i) => (
                    <div key={i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'} space-y-1`}>
                        <div className={`
                            px-3 py-2 rounded-lg text-xs max-w-[90%] font-mono shadow-sm
                            ${msg.role === 'user' 
                                ? 'bg-[hsl(var(--layer-intent))] border border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-intent))] rounded-tr-sm' 
                                : 'bg-[hsl(var(--void))] border border-[hsl(var(--layer-orientation))] text-[hsl(var(--fg-state))] rounded-tl-sm'}
                        `}>
                            {msg.role === 'assistant' ? (
                                <ReactMarkdown 
                                    components={{
                                        code: ({node, inline, className, children, ...props}) => {
                                            const codeContent = String(children).replace(/\n$/, '');
                                            return !inline ? (
                                                <div className="my-2 bg-[hsl(var(--layer-orientation))] rounded border border-[hsl(var(--layer-orientation))] overflow-hidden group/code">
                                                    <div className="flex justify-between items-center px-2 py-1 border-b border-white/5 bg-black/20">
                                                        <span className="text-[9px] text-neutral-500">{className?.replace('language-', '') || 'code'}</span>
                                                        <div className="flex gap-1 opacity-0 group-hover/code:opacity-100 transition-opacity">
                                                            <button 
                                                                onClick={() => {
                                                                    navigator.clipboard.writeText(codeContent);
                                                                    toast.success("Copied to clipboard");
                                                                }}
                                                                className="p-1 hover:bg-white/10 rounded"
                                                                title="Copy"
                                                            >
                                                                <Check className="w-3 h-3 text-neutral-400" />
                                                            </button>
                                                            {onApplyCode && (
                                                                <button 
                                                                    onClick={() => onApplyCode(codeContent)}
                                                                    className="p-1 hover:bg-[hsl(var(--color-execution))]/20 rounded text-[hsl(var(--color-execution))]"
                                                                    title="Apply to Editor"
                                                                >
                                                                    <ArrowRight className="w-3 h-3" />
                                                                </button>
                                                            )}
                                                        </div>
                                                    </div>
                                                    <div className="p-2 overflow-x-auto">
                                                        <code className={className} {...props}>{children}</code>
                                                    </div>
                                                </div>
                                            ) : (
                                                <code className="bg-[hsl(var(--layer-orientation))] px-1 py-0.5 rounded text-[hsl(var(--color-active))]" {...props}>{children}</code>
                                            )
                                        }
                                    }}
                                >
                                    {msg.content}
                                </ReactMarkdown>
                            ) : (
                                msg.content
                            )}
                        </div>
                        <StateText className="text-[9px] opacity-50 uppercase tracking-wider">
                            {msg.role === 'user' ? 'YOU' : 'SYSTEM'}
                        </StateText>
                    </div>
                ))}
                
                {isLoading && (
                    <div className="flex items-center gap-2 text-[hsl(var(--fg-state))] text-xs p-2">
                        <Loader2 className="w-3 h-3 animate-spin" />
                        <span className="font-mono">Processing...</span>
                    </div>
                )}
            </div>

            )}

            {/* Input */}
            {!showSettings && (
            <div className="p-3 border-t border-[hsl(var(--layer-orientation))] bg-[hsl(var(--layer-orientation))]">
               <div className="relative group focus-within:ring-1 focus-within:ring-[hsl(var(--color-active))]/50 rounded-lg transition-all">
                  <div className="absolute left-3 top-3 text-[hsl(var(--color-active))]">
                     <Terminal className="w-3 h-3" />
                  </div>
                  <textarea 
                     className="w-full bg-[hsl(var(--void))] border border-[hsl(var(--layer-orientation))] rounded-lg py-2.5 pl-9 pr-10 text-xs text-[hsl(var(--fg-intent))] focus:outline-none focus:border-[hsl(var(--layer-orientation))] min-h-[48px] max-h-[120px] resize-none font-mono placeholder:text-[hsl(var(--fg-state))]"
                     placeholder="Execute command or prompt..."
                     rows={1}
                     value={input}
                     onChange={(e) => setInput(e.target.value)}
                     onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSend();
                        }
                     }}
                  />
                  <div className="absolute bottom-1.5 right-1.5">
                     <Button 
                        size="icon" 
                        onClick={handleSend}
                        disabled={isLoading}
                        className="h-6 w-6 bg-[hsl(var(--layer-state))] hover:bg-[hsl(var(--color-active))] text-[hsl(var(--fg-orientation))] hover:text-white transition-colors rounded-md"
                     >
                        {isLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <ArrowRight className="w-3 h-3" />}
                     </Button>
                  </div>
               </div>
               <div className="flex justify-between items-center mt-2 px-1">
                  <div className="flex gap-2">
                     <button onClick={() => setMessages([])} className="text-[9px] text-[hsl(var(--fg-state))] font-mono hover:text-[hsl(var(--fg-intent))] cursor-pointer hover:underline">/clear</button>
                  </div>
                  <span className="text-[9px] text-[hsl(var(--fg-state))] font-mono">v2.1.0-AI</span>
               </div>
            </div>
            )}
        </div>
    );
}