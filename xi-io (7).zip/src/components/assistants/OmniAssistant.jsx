import React, { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { motion, useDragControls } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import { 
    MessageSquare, X, Send, Bot, Zap, 
    Maximize2, Minimize2, Paperclip, 
    Sparkles, ArrowRight, HelpCircle,
    ChevronDown, Cpu, GripHorizontal, LayoutGrid, Rocket, Code, Terminal, PlayCircle,
    PanelLeft, PanelRight, Globe, Columns, Maximize,
    Users, Target, MapPin, Clock, Laptop, LayoutTemplate,
    Check, RotateCcw, ThumbsUp, ThumbsDown,
    ShieldCheck, RefreshCw, Trash2, Pin, Activity, Info
} from 'lucide-react';
import { useGrid } from '@/components/desktop/DesktopGridSystem'; // Import Grid Hook
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
    DropdownMenu, 
    DropdownMenuContent, 
    DropdownMenuItem, 
    DropdownMenuTrigger, 
    DropdownMenuLabel, 
    DropdownMenuSeparator 
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { base44 } from '@/api/base44Client';
import { 
    OrientingText, IntentText, StateText, 
    Layer, SemanticDot 
} from '@/components/ui/design-system/System';
import { toast } from "sonner";
import AgentChatInterface from '@/components/agents/AgentChatInterface';
import CouncilChatWidget from '@/components/assistants/CouncilChatWidget';
import PromptInjector from '@/components/assistants/PromptInjector';

const DEFAULT_MODELS = [
    { id: 'default', name: 'System Default', provider: 'Base44', type: 'Standard' }
];

export default function OmniAssistant({ constraintsRef }) {
    const [isOpen, setIsOpen] = useState(false);
    const [isExpanded, setIsExpanded] = useState(false);
    const [isFullScreen, setIsFullScreen] = useState(false);
    const [mode, setMode] = useState('chat'); // 'chat' | 'tools'
    const [selectedModel, setSelectedModel] = useState(DEFAULT_MODELS[0]);
    
    // Split Screen State
    const [webSplit, setWebSplit] = useState(null); // null | 'left' | 'right'
    const [splitRatio, setSplitRatio] = useState(50);
    const [browserUrl, setBrowserUrl] = useState('https://www.google.com/search?igu=1'); // igu=1 allows google in iframe usually
    const [urlInput, setUrlInput] = useState('https://www.google.com/search?igu=1');
    
    // Council State
    const [isCouncilActive, setIsCouncilActive] = useState(false);
    const [councilHeight, setCouncilHeight] = useState(400); // Increased default height
    const [councilLogs, setCouncilLogs] = useState({
        who: [], what: [], where: [], when: [], why: []
    });

    const handleKeepInsight = (msg, pId) => {
        setMessages(prev => [...prev, { 
            role: 'system', 
            content: `**INSIGHT SECURED [${pId.toUpperCase()}]**\n> ${msg.content.substring(0, 150)}${msg.content.length > 150 ? '...' : ''}\n\n*Added to session context.*` 
        }]);
        toast.success(`Insight from ${pId.toUpperCase()} secured to context.`);
    };

    const handleRefineInsight = (msg, pId) => {
        toast.promise(
            new Promise(resolve => setTimeout(resolve, 1500)),
            {
                loading: `Refining ${pId.toUpperCase()} vector search...`,
                success: 'Refined context loaded.',
                error: 'Refinement failed'
            }
        );
    };

    const handleDiscardInsight = (msg, pId) => {
        setCouncilLogs(prev => ({
            ...prev,
            [pId]: prev[pId].filter(m => m !== msg)
        }));
        toast('Insight discarded', { icon: <Trash2 className="w-3 h-3" /> });
    };
    
    // Browser Mode (Web vs App)
    const [browserMode, setBrowserMode] = useState('web'); // 'web' | 'app'
    const [selectedAppView, setSelectedAppView] = useState('Dashboard');

    const dragControls = useDragControls();
    
    // Grid Integration
    let addPinnedItem;
    try {
        const grid = useGrid();
        addPinnedItem = grid.addPinnedItem;
    } catch (e) {
        // Fallback if not in GridProvider (e.g. non-desktop pages)
        addPinnedItem = null;
    }

    const handlePinToDesktop = () => {
        if (addPinnedItem) {
            addPinnedItem({
                title: 'Omni Assistant',
                type: 'custom',
                content: <AgentChatInterface agentName={selectedModel.agent_name || 'System'} context={{ path: location.pathname }} />
            });
            setIsOpen(false);
            toast.success("Omni Assistant pinned to Desktop");
        } else {
            toast.error("Pinning only available on Desktop");
        }
    };
    
    // Fetch configured models from Settings
    const { data: configuredModels = [] } = useQuery({
        queryKey: ['integrations', 'intelligence'],
        queryFn: async () => {
            const all = await base44.entities.Integration.list();
            return all
                .filter(i => i.category === 'intelligence' && i.status === 'active')
                .map(i => ({
                    id: i.id,
                    name: i.name,
                    provider: i.provider,
                    type: i.model_id || 'Custom',
                    model_id: i.model_id
                }));
        },
        initialData: []
    });

    // Fetch Agents
    const { data: agents = [] } = useQuery({
        queryKey: ['agents_list'],
        queryFn: () => base44.entities.Agent.list(),
        initialData: []
    });

    const activeModels = [
        ...DEFAULT_MODELS,
        ...configuredModels,
        ...agents.map(a => ({ 
            id: a.id, 
            name: a.name, 
            provider: 'System Agent', 
            type: 'Agent', 
            agent_name: a.name 
        }))
    ];

    const [messages, setMessages] = useState([
        { role: 'system', content: 'Omni-Assistant Online. I am anchored to your current context. How can I assist you with this operation?' }
    ]);
    const [input, setInput] = useState('');
    const [isThinking, setIsThinking] = useState(false);
    const scrollRef = useRef(null);
    const location = useLocation();
    const navigate = useNavigate();

    // Event Listener for Research Stacks
    useEffect(() => {
        const handleCouncilRequest = (e) => {
            const { stack, query } = e.detail;
            setIsOpen(true);
            setIsFullScreen(true);
            setIsCouncilActive(true);
            setWebSplit('right');
            if (stack && stack.length > 0) {
                setBrowserUrl(stack[0].url);
            }
            
            setMessages(prev => [...prev, { 
                role: 'system', 
                content: `RESEARCH STACK INITIALIZED: ${stack.length} Signals Loaded.\n\nSTACK CONTEXT:\n${stack.map(i => `[${i.type.toUpperCase()}] ${i.name}`).join('\n')}\n\nThe Council is assembled and ready to analyze these assets against your query: "${query}".`
            }]);
        };
        
        window.addEventListener('omni-open-council', handleCouncilRequest);
        return () => window.removeEventListener('omni-open-council', handleCouncilRequest);
    }, []);

    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isOpen, mode]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!input.trim()) return;

        const userMsg = { role: 'user', content: input };
        setMessages(prev => [...prev, userMsg]);
        const currentInput = input;
        setInput('');
        setIsThinking(true);

        try {
            const SYSTEM_CONTEXT = `
                SYSTEM DESIGN STANDARDS (STRICT ADHERENCE REQUIRED):
                1. Philosophy: Truth > Evidence > Context. Hero -> Widgets -> Feeds.
                2. Layout: Use 'QuadrantGrid' (4 zones: Orientation, State, Intent, Execution) and 'Quadrant' components. Never use arbitrary divs for primary layout.
                3. Hero: 'SystemStatusHero' must be the first element. Locked statuses: NOMINAL, DEGRADED, CRITICAL, MAINTENANCE, INITIALIZING.
                4. Language: Use 'Explainable' component for technical terms to support System/Plain speak modes.
                5. Colors: Use semantic CSS variables (text-[hsl(var(--color-intent))], --color-execution, --color-orientation).
                6. Icons: Use 'lucide-react'. STRICTLY AVOID duplicates for different interactions.
                   - Nav: Home, Search, Menu, ArrowLeft/Right, Maximize2, Minimize2.
                   - Actions: Plus, Trash2, Edit2, Save, Download, Upload.
                   - Status: Check, AlertCircle, AlertTriangle, Info, Loader2.
                   - Domain: Code, Terminal, Cpu, GitBranch.
                7. Mobile: Hero stacks vertically. No mobile-specific redesigns.
            `;

            const basePrompt = `
                User is currently on page: ${location.pathname}.
                Current Date: ${new Date().toISOString()}.
                Active Model Persona: ${selectedModel.name} (${selectedModel.provider}).
                
                You are the Omni-Assistant for the Base44 Operating System.
                You are the guardian of the XI-IO Design System.
                
                ${SYSTEM_CONTEXT}
            `;

            if (isCouncilActive && isFullScreen) {
                // COUNCIL FLOW
                const perspectives = [
                    { id: 'who', role: 'WHO', icon: Users, focus: 'Stakeholders, Users, Personas, Actors' },
                    { id: 'what', role: 'WHAT', icon: Target, focus: 'Objects, Entities, Products, Goals' },
                    { id: 'where', role: 'WHERE', icon: MapPin, focus: 'Context, Environment, Platform, Location' },
                    { id: 'when', role: 'WHEN', icon: Clock, focus: 'Timeline, Sequence, Events, Triggers' },
                    { id: 'why', role: 'WHY', icon: HelpCircle, focus: 'Purpose, Motivation, Value, Logic' }
                ];

                // Clear previous logs for new run
                setCouncilLogs({ who: [], what: [], where: [], when: [], why: [] });

                // 1. Parallel Analysis
                const analyses = await Promise.all(perspectives.map(async (p) => {
                    // Update log to thinking
                    setCouncilLogs(prev => ({ ...prev, [p.id]: [...prev[p.id], { role: 'system', content: 'Analyzing...' }] }));
                    
                    try {
                        const analysis = await base44.integrations.Core.InvokeLLM({
                            prompt: `${basePrompt}\n\nANALYZE THIS QUERY SOLELY FROM THE PERSPECTIVE OF "${p.role}" (${p.focus}).\nQuery: ${currentInput}\n\nProvide a concise analysis focusing ONLY on your dimension.`,
                            add_context_from_internet: false
                        });
                        
                        setCouncilLogs(prev => ({ ...prev, [p.id]: [...prev[p.id], { role: 'assistant', content: analysis }] }));
                        return { role: p.role, content: analysis, id: p.id };
                    } catch (err) {
                        return { role: p.role, content: "Analysis failed.", id: p.id };
                    }
                }));

                // 2. Synthesis (The HOW)
                const synthesisPrompt = `
                    Based on the following 5-dimensional analysis of the user's query: "${currentInput}"
                    
                    ${analyses.map(a => `[${a.role}]: ${a.content}`).join('\n\n')}
                    
                    SYNTHESIZE THESE PERSPECTIVES INTO "THE HOW".
                    Provide a comprehensive, actionable response that addresses the user's request by integrating these insights.
                    Your response is the final output to the user.
                `;

                const finalResponse = await base44.integrations.Core.InvokeLLM({
                    prompt: `${basePrompt}\n\n${synthesisPrompt}`,
                    add_context_from_internet: false
                });

                setMessages(prev => [...prev, { 
                    role: 'assistant', 
                    content: finalResponse,
                    type: 'council_deliberation',
                    councilData: analyses
                }]);

            } else {
                // STANDARD FLOW
                const response = await base44.integrations.Core.InvokeLLM({
                    prompt: `${basePrompt}\n\nUser Query: ${currentInput}`,
                    add_context_from_internet: false
                });
                setMessages(prev => [...prev, { role: 'assistant', content: response }]);
            }

        } catch (error) {
            setMessages(prev => [...prev, { role: 'system', content: `Error: ${error.message}` }]);
        } finally {
            setIsThinking(false);
        }
    };

    const ToolGrid = () => (
        <div className="grid grid-cols-2 gap-3 p-4">
            <button className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-800/50 border border-white/5 hover:bg-neutral-700/50 hover:border-white/20 transition-all group"
                onClick={() => toast.info("Development Environment Active")}
            >
                <div className="w-10 h-10 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <Code className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-neutral-300">Run Dev</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-800/50 border border-white/5 hover:bg-neutral-700/50 hover:border-white/20 transition-all group"
                onClick={() => toast.success("Build Process Initiated")}
            >
                <div className="w-10 h-10 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <Terminal className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-neutral-300">Build</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-800/50 border border-white/5 hover:bg-neutral-700/50 hover:border-white/20 transition-all group"
                onClick={() => toast.success("Deployment Queued")}
            >
                <div className="w-10 h-10 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <Rocket className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-neutral-300">Deploy</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 rounded-xl bg-neutral-800/50 border border-white/5 hover:bg-neutral-700/50 hover:border-white/20 transition-all group"
                onClick={() => {
                    setMode('chat');
                    setMessages(prev => [...prev, { role: 'assistant', content: "Quick Prompt activated. What do you need?" }]);
                }}
            >
                <div className="w-10 h-10 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <Sparkles className="w-5 h-5" />
                </div>
                <span className="text-xs font-bold text-neutral-300">AI Prompt</span>
            </button>
        </div>
    );

    if (!isOpen) {
        return (
            <motion.div 
                drag
                dragMomentum={false}
                dragConstraints={constraintsRef}
                whileDrag={{ scale: 1.1 }}
                className="fixed bottom-6 right-6 z-[100]"
            >
                <Button 
                    onClick={() => setIsOpen(true)}
                    className="h-14 w-14 rounded-full bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 shadow-2xl border-2 border-white/10 flex items-center justify-center transition-all hover:scale-105"
                >
                    <Bot className="h-8 w-8 text-white" />
                    <span className="absolute -top-1 -right-1 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-green-400"></span>
                    </span>
                </Button>
            </motion.div>
        );
    }

    return (
        <motion.div 
            drag={!isFullScreen}
            dragListener={false}
            dragControls={dragControls}
            dragMomentum={false}
            dragConstraints={constraintsRef}
            className={cn(
            "fixed z-[100] bg-black/10 border border-white/5 shadow-[0_0_50px_-10px_rgba(0,0,0,0.2)] overflow-hidden flex flex-col backdrop-blur-sm",
            isFullScreen 
                ? "inset-0 w-full h-full rounded-none" 
                : cn(
                    "right-6 rounded-xl",
                    isExpanded
                        ? "bottom-6 w-[90vw] sm:w-[600px] h-[80vh] max-h-[85vh]" 
                        : "bottom-24 w-[90vw] sm:w-[380px] h-[500px]"
                )
        )}
            style={{ 
                maxHeight: isFullScreen ? '100vh' : 'calc(100vh - 80px)',
                transition: 'width 0.3s, height 0.3s, bottom 0.3s, right 0.3s, border-radius 0.3s'
            }}
        >
            {/* Header */}
            <div 
                onPointerDown={(e) => dragControls.start(e)}
                className="h-16 bg-black border-b border-white/10 flex items-center justify-between px-4 gap-3 shrink-0 cursor-move relative z-50 shadow-sm"
                style={{ touchAction: "none" }}
            >
                <div className="flex items-center gap-3 min-w-0 flex-1 overflow-hidden">
                    <GripHorizontal className="h-4 w-4 text-neutral-600 shrink-0" />
                    <div className="h-9 w-9 rounded-lg bg-[hsl(var(--color-intent))]/10 flex items-center justify-center border border-[hsl(var(--color-intent))]/30 shrink-0 shadow-[0_0_15px_-5px_hsl(var(--color-intent))]">
                        <Bot className="h-5 w-5 text-[hsl(var(--color-intent))]" />
                    </div>
                    <div className="flex flex-col min-w-0 overflow-hidden">
                        <IntentText className="font-bold text-xs tracking-wider truncate w-full">OMNI-DRAWER</IntentText>
                        <div className="flex items-center gap-1.5 min-w-0 w-full overflow-hidden">
                            <SemanticDot type="active" className="w-1.5 h-1.5 shrink-0" />
                            <StateText className="text-[9px] opacity-60 truncate block w-full">
                                {mode === 'chat' ? `CTX: ${location.pathname}` : 'QUICK LAUNCH'}
                            </StateText>
                        </div>
                    </div>
                </div>

                <div className="flex items-center gap-1 shrink-0 ml-2">
                    {/* Split Screen Controls (Only in Fullscreen) */}
                    {isFullScreen && (
                        <>
                            <div className="flex items-center bg-white/5 rounded-lg p-0.5 border border-white/5 mr-2">
                                <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className={cn("h-7 px-2 text-[9px] gap-2 rounded-md transition-all", webSplit === 'left' ? "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]" : "text-neutral-500 hover:text-white")}
                                    onClick={() => setWebSplit(webSplit === 'left' ? null : 'left')}
                                >
                                    <PanelLeft className="w-3.5 h-3.5" />
                                    <span className="font-bold tracking-wider">LEFT</span>
                                </Button>
                                <div className="w-px h-4 bg-white/10 mx-0.5" />
                                <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className={cn("h-7 px-2 text-[9px] gap-2 rounded-md transition-all", webSplit === 'right' ? "bg-[hsl(var(--color-intent))]/20 text-[hsl(var(--color-intent))]" : "text-neutral-500 hover:text-white")}
                                    onClick={() => setWebSplit(webSplit === 'right' ? null : 'right')}
                                >
                                    <span className="font-bold tracking-wider">RIGHT</span>
                                    <PanelRight className="w-3.5 h-3.5" />
                                </Button>
                            </div>
                            <div className="h-4 w-px bg-white/10 mr-2" />
                            
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => setIsCouncilActive(!isCouncilActive)}
                                className={cn(
                                    "h-7 px-2 text-[9px] gap-1.5 rounded-md mr-2 border transition-all uppercase tracking-wider font-bold",
                                    isCouncilActive 
                                        ? "bg-purple-500/20 text-purple-300 border-purple-500/30" 
                                        : "text-neutral-500 border-transparent hover:text-purple-300 hover:bg-purple-500/10"
                                )}
                            >
                                <Users className="w-3.5 h-3.5" />
                                Council
                            </Button>
                        </>
                    )}

                    <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => setMode(mode === 'chat' ? 'tools' : 'chat')}
                        className={cn("h-8 px-2 text-[10px] gap-2 border border-transparent transition-all", mode === 'tools' ? "bg-white/10 text-white border-white/10" : "text-neutral-400 hover:text-white")}
                    >
                        {mode === 'chat' ? <LayoutGrid className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
                    </Button>

                    <div className="h-4 w-px bg-white/10" />

                    <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-white hover:bg-white/10 rounded-full transition-colors" onClick={() => setIsFullScreen(!isFullScreen)}>
                        {isFullScreen ? <Minimize2 className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-white hover:bg-white/10 rounded-full transition-colors" onClick={() => setIsExpanded(!isExpanded)}>
                        {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                    </Button>
                    {addPinnedItem && (
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/10 rounded-full transition-colors" onClick={handlePinToDesktop} title="Pin to Desktop">
                            <Pin className="h-4 w-4" />
                        </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-red-400 hover:bg-red-500/10 rounded-full transition-colors" onClick={() => setIsOpen(false)}>
                        <X className="h-4 w-4" />
                    </Button>
                </div>
            </div>

            {/* Split Container */}
            <div className="flex-1 flex overflow-hidden relative">
                {/* Browser Pane (Left) */}
                {isFullScreen && webSplit === 'left' && (
                    <div style={{ width: `${splitRatio}%` }} className="flex flex-col border-r border-white/10 relative z-10 h-full">
                        <BrowserPane 
                            url={browserUrl} 
                            setUrl={setBrowserUrl} 
                            input={urlInput} 
                            setInput={setUrlInput}
                            mode={browserMode}
                            setMode={setBrowserMode}
                            appView={selectedAppView}
                            setAppView={setSelectedAppView}
                        />
                        {/* Council Panel (Bottom) */}
                        {isCouncilActive && (
                            <CouncilPanel 
                                logs={councilLogs} 
                                height={councilHeight}
                                setHeight={setCouncilHeight}
                            />
                        )}
                    </div>
                )}

                {/* Resize Handle (Left Split) */}
                {isFullScreen && webSplit === 'left' && (
                    <div className="w-1 bg-black hover:bg-[hsl(var(--color-intent))] cursor-col-resize transition-colors z-50 flex items-center justify-center group"
                         onMouseDown={(e) => {
                             const startX = e.clientX;
                             const startWidth = splitRatio;
                             const onMouseMove = (e) => {
                                 const delta = ((e.clientX - startX) / window.innerWidth) * 100;
                                 setSplitRatio(Math.min(80, Math.max(20, startWidth + delta)));
                             };
                             const onMouseUp = () => {
                                 document.removeEventListener('mousemove', onMouseMove);
                                 document.removeEventListener('mouseup', onMouseUp);
                             };
                             document.addEventListener('mousemove', onMouseMove);
                             document.addEventListener('mouseup', onMouseUp);
                         }}
                    >
                        <div className="h-8 w-1 bg-white/20 rounded-full group-hover:bg-white" />
                    </div>
                )}

                {/* Main Content (Chat/Tools) */}
                <div className="flex-1 flex flex-col min-w-0 bg-[#050505]/80 relative z-0 backdrop-blur-sm">
                    {mode === 'tools' ? (
                        <div className="flex-1 bg-transparent overflow-y-auto">
                            <ToolGrid />
                        </div>
                    ) : (
                        <>
                            {/* Chat Model Selector (Only visible in chat mode) */}
                            <div className="px-4 py-2 border-b border-white/10 bg-black flex justify-between items-center shrink-0">
                                <span className="text-[10px] text-neutral-400 font-mono">NEURAL ENGINE</span>
                                <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <button className="flex items-center gap-2 text-[10px] text-neutral-300 hover:text-white transition-colors">
                                    {selectedModel.name} <ChevronDown className="w-3 h-3" />
                                </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-56 bg-neutral-900 border-white/10 z-[200]">
                                {activeModels.map(model => (
                                    <DropdownMenuItem 
                                        key={model.id}
                                        onClick={() => {
                                            setSelectedModel(model);
                                            toast.success(`Active Model Swapped: ${model.name}`);
                                        }}
                                        className="text-xs flex flex-col items-start gap-1 py-2 focus:bg-white/5 cursor-pointer"
                                    >
                                        <div className="flex items-center justify-between w-full">
                                            <span className={cn(selectedModel.id === model.id ? "text-[hsl(var(--color-intent))]" : "text-neutral-200")}>
                                                {model.name}
                                            </span>
                                            {selectedModel.id === model.id && <SemanticDot type="active" />}
                                        </div>
                                        <span className="text-[9px] text-neutral-500 uppercase">{model.provider} • {model.type}</span>
                                    </DropdownMenuItem>
                                ))}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </div>

                    {selectedModel.type === 'Agent' ? (
                        <div className="flex-1 overflow-hidden">
                            <AgentChatInterface 
                                agentName={selectedModel.agent_name} 
                                context={{ path: location.pathname }} 
                                onAgentChange={() => {}} 
                            />
                        </div>
                    ) : (
                        <>
                            {/* Standard Chat */}
                            <div 
                                ref={scrollRef}
                                className="flex-1 overflow-y-auto p-4 space-y-4 bg-transparent scrollbar-thin scrollbar-thumb-white/10"
                            >
                                {messages.map((msg, i) => (
                                    <div key={i} className={cn("flex gap-3", msg.role === 'user' ? "flex-row-reverse" : "flex-row")}>
                                        <div className={cn(
                                            "w-8 h-8 rounded flex items-center justify-center shrink-0 mt-1 shadow-lg backdrop-blur-sm",
                                            msg.role === 'user' ? "bg-[hsl(var(--color-intent))]/20 border border-[hsl(var(--color-intent))]/30" : 
                                            msg.role === 'system' ? "bg-transparent" : "bg-[hsl(var(--color-intent))]/10 border border-[hsl(var(--color-intent))]/20"
                                            )}>
                                            {msg.role === 'user' ? <Zap className="h-4 w-4 text-[hsl(var(--color-intent))]" /> : 
                                                msg.role === 'system' ? <HelpCircle className="h-4 w-4 text-[hsl(var(--color-execution))]" /> :
                                                <Bot className="h-4 w-4 text-[hsl(var(--color-intent))]" />}
                                            </div>
                                            <div className={cn(
                                            "max-w-[80%] rounded-lg p-3 text-sm break-words backdrop-blur-md shadow-sm overflow-hidden",
                                            msg.role === 'user' ? "bg-[hsl(var(--color-intent))]/10 text-white border border-[hsl(var(--color-intent))]/20" : 
                                            msg.role === 'system' ? "text-neutral-500 text-xs italic bg-transparent whitespace-pre-wrap font-mono" :
                                            "bg-[hsl(var(--color-intent))]/10 text-neutral-200 border border-[hsl(var(--color-intent))]/10"
                                            )}>
                                            {msg.role === 'user' || msg.role === 'system' ? (
                                                <p className="whitespace-pre-wrap">{msg.content}</p>
                                            ) : (
                                                <div className="prose prose-invert prose-sm max-w-none prose-p:leading-relaxed prose-pre:bg-black/50 prose-pre:border prose-pre:border-white/10 prose-code:text-[hsl(var(--color-intent))]">
                                                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                                                </div>
                                            )}

                                            {/* Render Council Widget if available */}
                                            {msg.type === 'council_deliberation' && msg.councilData && (
                                                <CouncilChatWidget data={msg.councilData} />
                                            )}
                                        </div>
                                    </div>
                                ))}
                                {isThinking && (
                                    <div className="flex gap-3">
                                        <div className="w-8 h-8 rounded bg-[hsl(var(--color-intent))]/10 flex items-center justify-center shrink-0">
                                            <Bot className="h-4 w-4 text-[hsl(var(--color-intent))]" />
                                        </div>
                                        <div className="flex items-center gap-1 h-8 px-2">
                                            <span className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                            <span className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                            <span className="w-1.5 h-1.5 bg-neutral-500 rounded-full animate-bounce"></span>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Standard Input */}
                            <form onSubmit={handleSubmit} className="p-3 bg-[#0A0A0A] border-t border-white/10 shrink-0 z-20">
                                <div className="relative flex items-center gap-2">
                                    <Button type="button" variant="ghost" size="icon" className="h-10 w-10 text-neutral-500 hover:text-white shrink-0">
                                        <Paperclip className="h-4 w-4" />
                                    </Button>
                                    <Input 
                                        value={input}
                                        onChange={(e) => setInput(e.target.value)}
                                        placeholder="Type a command or query..."
                                        className="flex-1 bg-neutral-900 border-white/10 focus-visible:ring-[hsl(var(--color-intent))]"
                                    />
                                    <Button type="submit" size="icon" className="h-10 w-10 bg-[hsl(var(--color-intent))] hover:bg-[hsl(var(--color-intent))]/90 text-white shrink-0">
                                        <ArrowRight className="h-4 w-4" />
                                    </Button>
                                </div>
                                <div className="flex justify-between items-center mt-2 px-1 gap-4">
                                    <span className="text-[10px] text-neutral-600 font-mono shrink-0">POWERED BY SYSTEM CORE</span>
                                    <span className="text-[10px] text-[hsl(var(--color-intent))] font-mono flex items-center gap-1 min-w-0">
                                        <Sparkles className="w-2 h-2 shrink-0" /> 
                                        <span className="truncate">{selectedModel.name.toUpperCase()} ACTIVE</span>
                                    </span>
                                </div>
                            </form>
                        </>
                    )}
                    </>
                )}
                </div>

                {/* Resize Handle (Right Split) */}
                {isFullScreen && webSplit === 'right' && (
                    <div className="w-1 bg-black hover:bg-[hsl(var(--color-intent))] cursor-col-resize transition-colors z-50 flex items-center justify-center group"
                         onMouseDown={(e) => {
                             const startX = e.clientX;
                             const startWidth = 100 - splitRatio; // Calculate width from right
                             const onMouseMove = (e) => {
                                 // Delta needs to be inverted for right side resizing logic if we track splitRatio as "left pane width"
                                 // But here splitRatio controls the *browser pane width*.
                                 // If browser is on right, splitRatio is its width.
                                 // Moving mouse left increases width (positive delta X should decrease width).
                                 const delta = ((startX - e.clientX) / window.innerWidth) * 100;
                                 setSplitRatio(Math.min(80, Math.max(20, startWidth + delta)));
                             };
                             const onMouseUp = () => {
                                 document.removeEventListener('mousemove', onMouseMove);
                                 document.removeEventListener('mouseup', onMouseUp);
                             };
                             document.addEventListener('mousemove', onMouseMove);
                             document.addEventListener('mouseup', onMouseUp);
                         }}
                    >
                         <div className="h-8 w-1 bg-white/20 rounded-full group-hover:bg-white" />
                    </div>
                )}

                {/* Browser Pane (Right) */}
                {isFullScreen && webSplit === 'right' && (
                    <div style={{ width: `${splitRatio}%` }} className="flex flex-col border-l border-white/10 relative z-10 h-full">
                        <BrowserPane 
                            url={browserUrl} 
                            setUrl={setBrowserUrl} 
                            input={urlInput} 
                            setInput={setUrlInput}
                            mode={browserMode}
                            setMode={setBrowserMode}
                            appView={selectedAppView}
                            setAppView={setSelectedAppView}
                        />
                        {/* Council Panel (Bottom) */}
                        {isCouncilActive && (
                            <CouncilPanel 
                                logs={councilLogs} 
                                height={councilHeight}
                                setHeight={setCouncilHeight}
                            />
                        )}
                    </div>
                )}
                
                {/* Emergency Browser Toggle (if hidden) */}
                {isFullScreen && isCouncilActive && !webSplit && (
                    <div className="absolute top-2 right-2 z-50">
                        <Button 
                            variant="secondary" 
                            size="sm" 
                            onClick={() => setWebSplit('right')}
                            className="bg-[hsl(var(--color-intent))] text-black shadow-lg"
                        >
                            <PanelRight className="w-4 h-4 mr-2" />
                            Open Research Browser
                        </Button>
                    </div>
                )}
            </div>
        </motion.div>
    );
}

// Sub-component for Browser
const BrowserPane = ({ url, setUrl, input, setInput, mode, setMode, appView, setAppView }) => {
    const APP_VIEWS = ['Dashboard', 'Nodes', 'Console', 'WorkRoom', 'Marketplace', 'Intelligence'];
    const [isForgeOpen, setIsForgeOpen] = useState(false);

    return (
        <div className="bg-black flex-1 flex flex-col min-h-0 relative z-10">
            {isForgeOpen && (
                <PromptInjector 
                    targetUrl={url} 
                    onClose={() => setIsForgeOpen(false)} 
                />
            )}
            {/* Browser Header */}
            <div className="h-10 bg-[#0A0A0A] border-b border-white/10 flex items-center px-2 gap-2 shrink-0">
                <div className="flex gap-1.5 mr-2">
                     <div className="w-2.5 h-2.5 rounded-full bg-red-500/20" />
                     <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/20" />
                     <div className="w-2.5 h-2.5 rounded-full bg-green-500/20" />
                </div>
                
                {/* Mode Toggle */}
                <div className="flex items-center bg-white/5 rounded-md p-0.5 border border-white/5">
                    <button 
                        onClick={() => setMode('web')}
                        className={cn("p-1 rounded text-xs", mode === 'web' ? "bg-white/10 text-white" : "text-neutral-500 hover:text-neutral-300")}
                        title="Web Browser"
                    >
                        <Globe className="w-3.5 h-3.5" />
                    </button>
                    <button 
                        onClick={() => setMode('app')}
                        className={cn("p-1 rounded text-xs", mode === 'app' ? "bg-white/10 text-white" : "text-neutral-500 hover:text-neutral-300")}
                        title="App View"
                    >
                        <LayoutTemplate className="w-3.5 h-3.5" />
                    </button>
                    <div className="w-px h-3 bg-white/10 mx-1" />
                    <button 
                        onClick={() => setIsForgeOpen(!isForgeOpen)}
                        className={cn("p-1 rounded text-xs", isForgeOpen ? "bg-[hsl(var(--color-intent))] text-black" : "text-neutral-500 hover:text-white")}
                        title="Toggle Prompt Forge"
                    >
                        <Terminal className="w-3.5 h-3.5" />
                    </button>
                </div>

                <div className="flex-1 bg-black/50 rounded-md border border-white/5 flex items-center px-2 h-7 min-w-0">
                    {mode === 'web' ? (
                        <>
                            <Globe className="w-3 h-3 text-neutral-500 mr-2 shrink-0" />
                            <input 
                                className="flex-1 bg-transparent border-none text-[10px] text-neutral-300 focus:outline-none font-mono min-w-0"
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        let target = input;
                                        if (!target.startsWith('http')) target = 'https://' + target;
                                        setUrl(target);
                                    }
                                }}
                            />
                        </>
                    ) : (
                        <>
                            <LayoutTemplate className="w-3 h-3 text-[hsl(var(--color-intent))] mr-2 shrink-0" />
                            <select 
                                value={appView}
                                onChange={(e) => setAppView(e.target.value)}
                                className="flex-1 bg-transparent border-none text-[10px] text-neutral-300 focus:outline-none font-mono cursor-pointer"
                            >
                                {APP_VIEWS.map(view => (
                                    <option key={view} value={view} className="bg-neutral-900">{view}</option>
                                ))}
                            </select>
                        </>
                    )}
                </div>
            </div>
            
            {/* Browser Content */}
            <div className="flex-1 bg-white relative min-h-0">
                 <iframe 
                    src={mode === 'web' ? url : `/${appView}?windowed=true`}
                    className="w-full h-full border-none"
                    title="Embedded Browser"
                    sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals allow-presentation"
                 />
                 {/* Loading Overlay */}
                 <div className="absolute inset-0 bg-neutral-900 flex items-center justify-center pointer-events-none opacity-0 transition-opacity duration-500" id="browser-loader">
                    <div className="w-8 h-8 border-2 border-[hsl(var(--color-intent))] border-t-transparent rounded-full animate-spin" />
                 </div>
            </div>
        </div>
    );
};

const CouncilPanel = ({ logs, height, setHeight, onKeep, onRefine, onDiscard }) => {
    const perspectives = [
        { id: 'who', role: 'WHO', icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10' },
        { id: 'what', role: 'WHAT', icon: Target, color: 'text-green-400', bg: 'bg-green-500/10' },
        { id: 'where', role: 'WHERE', icon: MapPin, color: 'text-orange-400', bg: 'bg-orange-500/10' },
        { id: 'when', role: 'WHEN', icon: Clock, color: 'text-purple-400', bg: 'bg-purple-500/10' },
        { id: 'why', role: 'WHY', icon: HelpCircle, color: 'text-red-400', bg: 'bg-red-500/10' },
    ];

    return (
        <div style={{ height }} className="border-t border-white/10 bg-[#050505] shrink-0 flex flex-col relative transition-all duration-75">
            {/* Resize Handle */}
            <div 
                className="absolute -top-1 left-0 right-0 h-2 bg-transparent hover:bg-[hsl(var(--color-intent))]/50 cursor-row-resize z-50 flex justify-center items-center group"
                onMouseDown={(e) => {
                    const startY = e.clientY;
                    const startHeight = height;
                    const onMouseMove = (e) => {
                        const delta = startY - e.clientY;
                        setHeight(Math.max(200, Math.min(800, startHeight + delta)));
                    };
                    const onMouseUp = () => {
                        document.removeEventListener('mousemove', onMouseMove);
                        document.removeEventListener('mouseup', onMouseUp);
                    };
                    document.addEventListener('mousemove', onMouseMove);
                    document.addEventListener('mouseup', onMouseUp);
                }}
            >
                <div className="w-12 h-1 rounded-full bg-white/20 group-hover:bg-white/80 transition-colors" />
            </div>

            <div className="h-9 border-b border-white/5 flex items-center justify-between px-3 gap-2 bg-black/40">
                <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-neutral-400" />
                    <span className="text-xs font-bold text-neutral-300 uppercase tracking-widest">The Council</span>
                    <span className="text-[9px] px-1.5 py-0.5 bg-white/5 rounded text-neutral-500 border border-white/5">5-VECTOR ANALYSIS</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-[9px] text-neutral-600 font-mono hidden sm:inline-block">DRAG EDGE TO RESIZE</span>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-neutral-500 hover:text-white" onClick={() => setHeight(height > 200 ? 0 : 400)}>
                       {height > 50 ? <ChevronDown className="w-4 h-4" /> : <Maximize2 className="w-3 h-3" />}
                    </Button>
                </div>
            </div>
            
            <div className="flex-1 grid grid-cols-5 divide-x divide-white/5 min-h-0 bg-[#080808]">
                {perspectives.map(p => (
                    <div key={p.id} className="flex flex-col min-w-0 group/col relative">
                        {/* Column Header */}
                        <div className={`p-2 border-b border-white/5 ${p.bg}`}>
                            <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-1.5">
                                    <p.icon className={`w-3.5 h-3.5 ${p.color}`} />
                                    <span className={`text-[10px] font-black tracking-widest ${p.color}`}>{p.role}</span>
                                </div>
                                <span className="text-[9px] text-neutral-500 font-mono bg-black/20 px-1 rounded">
                                    {logs[p.id]?.length || 0}
                                </span>
                            </div>
                            {/* Visual Status Bar */}
                            <div className="w-full bg-black/20 h-1 rounded-full overflow-hidden flex">
                                <div className={`h-full ${p.color.replace('text-', 'bg-')} opacity-60`} style={{ width: `${Math.min(100, (logs[p.id]?.length || 0) * 33)}%` }} />
                            </div>
                        </div>

                        {/* Scrollable Content */}
                        <div className="flex-1 overflow-y-auto p-2 space-y-3 scrollbar-thin scrollbar-thumb-white/10 hover:scrollbar-thumb-white/20 pb-12">
                            {logs[p.id]?.map((msg, i) => (
                                <CouncilInsightCard 
                                    key={i} 
                                    msg={msg} 
                                    p={p} 
                                    onKeep={() => onKeep(msg, p.id)}
                                    onRefine={() => onRefine(msg, p.id)}
                                    onDiscard={() => onDiscard(msg, p.id)}
                                />
                            ))}
                            {logs[p.id]?.length === 0 && (
                                <div className="h-full flex flex-col items-center justify-center opacity-10 gap-2 min-h-[100px]">
                                    <p.icon className="w-8 h-8" />
                                    <span className="text-[8px] uppercase tracking-widest font-bold">Awaiting Input</span>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const CouncilInsightCard = ({ msg, p, onKeep, onRefine, onDiscard }) => {
    // Generate a consistent pseudo-random reliability score based on content length
    const reliability = React.useMemo(() => {
        if (!msg.content) return 0;
        const seed = msg.content.length;
        return 75 + (seed % 24); 
    }, [msg.content]);

    const isSystem = msg.role === 'system';
    
    if (msg.content === 'Analyzing...') {
        return (
            <div className="p-3 rounded-lg border border-white/5 bg-white/[0.02] flex items-center gap-2 animate-pulse">
                <Activity className={`w-3 h-3 ${p.color} animate-spin`} />
                <span className="text-[9px] text-neutral-500 font-mono">SCANNING VECTOR...</span>
            </div>
        );
    }

    return (
        <div className="group relative bg-[#0A0A0A] border border-white/10 rounded-lg overflow-hidden hover:border-white/20 transition-all shadow-sm hover:shadow-md hover:bg-[#0F0F0F]">
            {/* Card Header */}
            {!isSystem && (
                <div className="flex items-center justify-between px-2 py-1.5 border-b border-white/5 bg-white/[0.02]">
                    <div className="flex items-center gap-1.5">
                        <ShieldCheck className={`w-3 h-3 ${reliability > 90 ? 'text-emerald-500' : 'text-neutral-500'}`} />
                        <span className={`text-[9px] font-mono font-bold ${reliability > 90 ? 'text-emerald-500' : 'text-neutral-500'}`}>
                            {reliability}% RELIABILITY
                        </span>
                    </div>
                </div>
            )}

            {/* Content */}
            <div className="p-2.5 text-[10px] text-neutral-300 leading-relaxed font-mono prose prose-invert max-w-none prose-p:my-1 prose-headings:text-neutral-200 prose-headings:font-bold prose-headings:text-xs prose-strong:text-white prose-ul:my-1 prose-li:my-0.5">
                 <ReactMarkdown>{msg.content}</ReactMarkdown>
            </div>

            {/* Actions Footer */}
            {!isSystem && (
                <div className="flex items-center border-t border-white/5 divide-x divide-white/5 bg-black">
                    <button 
                        onClick={onKeep} 
                        className="flex-1 py-2 flex items-center justify-center gap-1.5 hover:bg-emerald-900/20 hover:text-emerald-400 text-neutral-500 transition-colors group/btn"
                        title="Secure Insight to Context"
                    >
                        <Pin className="w-3 h-3 group-hover/btn:scale-110 transition-transform" />
                        <span className="text-[8px] font-bold uppercase tracking-wider">Keep</span>
                    </button>
                    <button 
                        onClick={onRefine} 
                        className="flex-1 py-2 flex items-center justify-center gap-1.5 hover:bg-amber-900/20 hover:text-amber-400 text-neutral-500 transition-colors group/btn"
                        title="Refine Search"
                    >
                        <RefreshCw className="w-3 h-3 group-hover/btn:spin-once transition-transform" />
                        <span className="text-[8px] font-bold uppercase tracking-wider">Refine</span>
                    </button>
                     <button 
                        onClick={onDiscard} 
                        className="flex-1 py-2 flex items-center justify-center gap-1.5 hover:bg-red-900/20 hover:text-red-400 text-neutral-500 transition-colors group/btn"
                        title="Discard Insight"
                    >
                        <Trash2 className="w-3 h-3 group-hover/btn:scale-110 transition-transform" />
                        <span className="text-[8px] font-bold uppercase tracking-wider">Toss</span>
                    </button>
                </div>
            )}
        </div>
    );
};