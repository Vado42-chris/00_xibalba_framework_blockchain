import React, { useState, useEffect } from 'react';
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
    Loader2, Sparkles, MessageSquare, Lightbulb, 
    Book, Save, ChevronRight, Play 
} from 'lucide-react';
import { toast } from 'sonner';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const SUGGESTIONS_BY_MODE = {
    '3d': ["Cyberpunk street corner, neon lights, low poly", "Realistic marble statue of a greek god", "Isometric room interior, cozy, warm lighting"],
    'image': ["A futuristic cityscape at sunset, synthwave style", "Oil painting of a cottage in the woods", "Minimalist vector logo for a tech startup"],
    'video': ["Drone shot flying over a mountain range", "Time-lapse of city traffic at night", "Slow motion water splash"],
    'audio': ["Upbeat lofi hip hop beat", "Cinematic orchestral swelling", "8-bit retro game sound effects"],
    'app': ["Dashboard for crypto analytics", "Social media feed with stories", "E-commerce product page"],
    'code': ["React component for a pricing table", "Python script to scrape a website", "SQL query to find top users"]
};

export default function AIAssistant({ mode = 'general', onApplyPrompt }) {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  
  // Prompt Library (Mock)
  const [savedPrompts, setSavedPrompts] = useState([
      { id: 1, title: "Standard Cleanup", content: "Refactor this code to be cleaner and more readable." },
      { id: 2, title: "Debug Mode", content: "Find potential bugs in this logic." }
  ]);

  // State
  const [suggestions, setSuggestions] = useState(SUGGESTIONS_BY_MODE[mode] || []);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  // Load Saved Prompts from Backend
  useEffect(() => {
      const loadLibrary = async () => {
          try {
              const { data } = await base44.functions.invoke('promptLibrary', {}); // GET
              if (data?.prompts) setSavedPrompts(data.prompts);
          } catch (e) { console.error("Failed to load prompt library", e); }
      };
      loadLibrary();
  }, []);

  // Fetch Suggestions from AI
  useEffect(() => {
      const fetchSuggestions = async () => {
          setIsLoadingSuggestions(true);
          try {
              const { data } = await base44.functions.invoke('aiGenerate', {
                  intent: 'suggest_prompts',
                  input: '',
                  context: { mode }
              });
              if (data?.output?.suggestions) {
                  setSuggestions(data.output.suggestions);
              }
          } catch (e) { console.warn("AI Suggestion failed, using fallback", e); }
          setIsLoadingSuggestions(false);
      };
      // Only fetch if not default
      if (mode !== 'general') fetchSuggestions();
  }, [mode]);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    setResponse('');
  
    try {
      // Use the new Backend Function
      const { data } = await base44.functions.invoke('aiGenerate', {
          intent: 'generate_ui_code', // Or generic based on mode
          input: prompt,
          context: { mode }
      });
    
      if (data.success) {
        setResponse(typeof data.output === 'string' ? data.output : JSON.stringify(data.output, null, 2));
        toast.success("AI Generation Complete");
      } else {
         throw new Error("AI Failed");
      }
    } catch (error) {
       // Fallback for demo
       setResponse(`[AI Mock for ${mode}]\nProcessed: ${prompt}`);
       toast.success("AI Generation Simulated (Dev Mode)");
    }
    setIsGenerating(false);
  };

  const savePrompt = async () => {
      if (!prompt) return;
      try {
          const { data } = await base44.functions.invoke('promptLibrary', {
              title: prompt.substring(0, 30) + (prompt.length > 30 ? '...' : ''),
              content: prompt,
              mode: mode,
              tags: [mode, 'user-saved']
          }); // POST
          if (data.success) {
              setSavedPrompts([data.prompt, ...savedPrompts]);
              toast.success("Prompt Saved to Backend Library");
          }
      } catch (e) {
          toast.error("Failed to save prompt");
      }
  };

  return (
    <div className="flex flex-col h-full border border-white/10 rounded-lg bg-black/20 backdrop-blur-sm overflow-hidden">
        {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-white/10 bg-white/5">
        <div className="flex items-center gap-2 text-white">
          <Sparkles className="w-4 h-4 text-[hsl(var(--color-intent))]" />
          <h3 className="font-bold text-xs uppercase tracking-wider">AI Assistant</h3>
        </div>
        <div className="flex gap-1">
             <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setActiveTab('library')}>
                <Book className="w-3 h-3" />
            </Button>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setActiveTab('chat')}>
                <MessageSquare className="w-3 h-3" />
            </Button>
        </div>
      </div>

      <div className="p-3 flex-1 flex flex-col gap-3 min-h-[300px]">
        {activeTab === 'chat' ? (
            <>
                {/* Suggestions */}
                <div className="space-y-2">
                    <div className="flex items-center gap-1 text-[10px] text-[hsl(var(--color-active))] font-mono uppercase">
                        <Lightbulb className="w-3 h-3" />
                        <span>Context Suggestions ({mode})</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {suggestions.map((s, i) => (
                            <button 
                                key={i}
                                onClick={() => { setPrompt(s); if(onApplyPrompt) onApplyPrompt(s); }}
                                className="text-[10px] px-2 py-1 rounded border border-white/10 bg-white/5 hover:bg-white/10 hover:border-[hsl(var(--color-intent))] transition-colors text-left"
                            >
                                {s}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="flex-1 flex flex-col gap-2">
                    <Textarea 
                        rows={4} 
                        value={prompt}
                        onChange={(e) => { setPrompt(e.target.value); if(onApplyPrompt) onApplyPrompt(e.target.value); }}
                        placeholder={`Ask AI to help with ${mode}...`}
                        className="bg-black/40 border-white/10 text-xs text-white placeholder:text-neutral-500 flex-1 resize-none"
                    />
                    <div className="flex gap-2">
                        <Button 
                            onClick={handleGenerate} 
                            disabled={isGenerating}
                            size="sm"
                            className="flex-1 bg-[hsl(var(--color-intent))] text-black hover:bg-[hsl(var(--color-intent))]/90"
                        >
                            {isGenerating ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : <Sparkles className="w-3 h-3 mr-2" />}
                            {isGenerating ? 'Thinking...' : 'Generate'}
                        </Button>
                        <Button onClick={savePrompt} size="icon" variant="outline" className="border-white/10">
                            <Save className="w-4 h-4" />
                        </Button>
                    </div>
                </div>

                {response && (
                    <div className="p-3 rounded bg-white/5 border border-white/10 mt-2 max-h-40 overflow-y-auto custom-scrollbar">
                        <pre className="text-[10px] text-neutral-300 whitespace-pre-wrap font-mono">{response}</pre>
                        <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full mt-2 h-6 text-[10px]"
                            onClick={() => { if(onApplyPrompt) onApplyPrompt(response); }}
                        >
                            Use This Result
                        </Button>
                    </div>
                )}
            </>
        ) : (
            <ScrollArea className="h-full">
                <div className="space-y-2">
                    <h4 className="text-[10px] font-bold text-neutral-500 uppercase mb-2">Saved Prompts</h4>
                    {savedPrompts.map(p => (
                        <div key={p.id} className="p-2 rounded border border-white/10 bg-white/5 hover:border-[hsl(var(--color-intent))] group cursor-pointer" onClick={() => { setPrompt(p.content); setActiveTab('chat'); if(onApplyPrompt) onApplyPrompt(p.content); }}>
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-xs font-bold text-white">{p.title}</span>
                                <ChevronRight className="w-3 h-3 text-neutral-500 opacity-0 group-hover:opacity-100" />
                            </div>
                            <p className="text-[10px] text-neutral-400 line-clamp-2">{p.content}</p>
                        </div>
                    ))}
                </div>
            </ScrollArea>
        )}
      </div>
    </div>
  );
}