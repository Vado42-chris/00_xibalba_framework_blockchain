import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { History, MessageSquare, Users, GitBranch, Clock, User, Circle } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { toast } from 'sonner';
import { base44 } from "@/api/base44Client";

export default function CollabPanel() {
    const [activeTab, setActiveTab] = useState('history');
    const [commentText, setCommentText] = useState('');
    const location = useLocation();
    const projectId = new URLSearchParams(location.search).get('projectId') || 'current';
    
    // Mock Data for MVP
    const [history, setHistory] = useState([
        { id: 1, action: "Updated layout structure", author: "User", time: "2m ago", version: "v1.0.2" },
        { id: 2, action: "Added AI Assistant", author: "User", time: "15m ago", version: "v1.0.1" },
        { id: 3, action: "Initial Commit", author: "System", time: "1h ago", version: "v1.0.0" },
    ]);

    const [comments, setComments] = useState([
        { id: 1, text: "Consider increasing the contrast on the active state.", author: "DesignBot", time: "5m ago", avatar: "DB" },
        { id: 2, text: "Ensure the API endpoint is secure.", author: "SecurityAudit", time: "10m ago", avatar: "SA" },
    ]);

    const [activeUsers, setActiveUsers] = useState([
        { id: 'u1', name: 'You', status: 'active', color: 'bg-green-500' },
        { id: 'u2', name: 'Architect', status: 'idle', color: 'bg-yellow-500' }
    ]);

    // Real-time Collaboration Engine
    useEffect(() => {
        let pollInterval;
        const sync = async () => {
            try {
                // Poll for events (Simulating WS)
                const { data } = await base44.functions.invoke('collabSync', {}); // GET
                if (data?.events) {
                    const newComments = data.events.filter(e => e.type === 'comment').map(e => ({
                        id: e.id,
                        text: e.payload.text,
                        author: e.user_name,
                        time: new Date(e.timestamp).toLocaleTimeString(),
                        avatar: e.user_name.substring(0,2).toUpperCase()
                    }));
                    
                    // Simple dedup based on ID would be needed in prod, here we just replace for MVP sync
                    if (newComments.length > 0) setComments(prev => {
                        // Merge logic... for now just showing latest from server + local
                        // In a real app we'd maintain a proper map
                        return newComments; 
                    });

                    // Presence logic from backend aggregation
                    if (data.presence) {
                        const presenceList = data.presence.map(u => ({
                            id: u.id,
                            name: u.name,
                            status: 'active',
                            color: 'bg-green-500' 
                        }));
                        // Merge with self if needed, or just replace. 
                        // For MVP we just use the server list + fallback for current user if missing (due to latency)
                        if (!presenceList.find(u => u.name === 'You')) {
                             presenceList.push({ id: 'me', name: 'You', status: 'active', color: 'bg-green-500' });
                        }
                        setActiveUsers(presenceList);
                    }
                }
            } catch (e) { console.error("Sync failed", e); }
        };

        // Announce Presence
        const announce = async () => {
            await base44.functions.invoke('collabSync', {
                project_id: projectId,
                type: 'presence',
                payload: { status: 'online' }
            });
        };

        announce();
        pollInterval = setInterval(sync, 3000);
        return () => clearInterval(pollInterval);
    }, []);

    const handleAddComment = async () => {
        if (!commentText.trim()) return;
        
        // Optimistic UI Update
        const tempId = Date.now();
        const newComment = {
            id: tempId,
            text: commentText,
            author: "You",
            time: "Sending...",
            avatar: "ME"
        };
        setComments([newComment, ...comments]);
        setCommentText('');

        try {
            await base44.functions.invoke('collabSync', {
                project_id: projectId,
                type: 'comment',
                payload: { text: commentText }
            });
            // Success - next poll will confirm it
        } catch (e) {
            toast.error("Failed to send comment");
        }
    };

    return (
        <div className="flex flex-col h-full border-l border-white/10 bg-black/20 w-80">
            {/* Presence Header */}
            <div className="p-3 border-b border-white/10 flex items-center justify-between bg-white/5">
                <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-[hsl(var(--color-intent))]" />
                    <span className="text-xs font-bold uppercase tracking-wider">Team</span>
                </div>
                <div className="flex -space-x-2">
                    {activeUsers.map(user => (
                        <div key={user.id} className="relative group cursor-pointer" title={user.name}>
                            <Avatar className="w-6 h-6 border border-black">
                                <AvatarFallback className="text-[8px] bg-neutral-800 text-neutral-300">{user.name.substring(0,2).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className={`absolute bottom-0 right-0 w-2 h-2 rounded-full border border-black ${user.color}`} />
                        </div>
                    ))}
                    <div className="w-6 h-6 rounded-full bg-white/10 border border-black flex items-center justify-center text-[8px] text-neutral-400">
                        +
                    </div>
                </div>
            </div>

            <div className="flex border-b border-white/10">
                <button
                    onClick={() => setActiveTab('history')}
                    className={`flex-1 p-3 text-xs font-medium flex items-center justify-center gap-2 ${activeTab === 'history' ? 'bg-white/5 text-white border-b-2 border-[hsl(var(--color-intent))]' : 'text-neutral-500 hover:text-white'}`}
                >
                    <History className="w-3 h-3" /> History
                </button>
                <button
                    onClick={() => setActiveTab('comments')}
                    className={`flex-1 p-3 text-xs font-medium flex items-center justify-center gap-2 ${activeTab === 'comments' ? 'bg-white/5 text-white border-b-2 border-[hsl(var(--color-intent))]' : 'text-neutral-500 hover:text-white'}`}
                >
                    <MessageSquare className="w-3 h-3" /> Comments
                </button>
            </div>

            <div className="flex-1 overflow-hidden">
                {activeTab === 'history' && (
                    <ScrollArea className="h-full p-4">
                        <div className="space-y-4">
                            {history.map((item) => (
                                <div key={item.id} className="flex gap-3 relative">
                                    <div className="flex flex-col items-center">
                                        <div className="w-2 h-2 rounded-full bg-[hsl(var(--color-execution))]" />
                                        <div className="w-px h-full bg-white/10 my-1" />
                                    </div>
                                    <div className="pb-4">
                                        <p className="text-xs text-white font-medium">{item.action}</p>
                                        <div className="flex items-center gap-2 mt-1">
                                            <span className="text-[10px] text-neutral-500">{item.time}</span>
                                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-neutral-300 font-mono">{item.version}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </ScrollArea>
                )}

                {activeTab === 'comments' && (
                    <div className="flex flex-col h-full">
                        <ScrollArea className="flex-1 p-4">
                            <div className="space-y-4">
                                {comments.map((comment) => (
                                    <div key={comment.id} className="p-3 rounded bg-white/5 border border-white/10">
                                        <p className="text-xs text-neutral-300 leading-relaxed mb-2">{comment.text}</p>
                                        <div className="flex items-center gap-2">
                                            <Avatar className="w-4 h-4">
                                                <AvatarFallback className="text-[8px]">{comment.avatar}</AvatarFallback>
                                            </Avatar>
                                            <span className="text-[10px] text-neutral-500">{comment.author}</span>
                                            <span className="text-[10px] text-neutral-600 ml-auto">{comment.time}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </ScrollArea>
                        <div className="p-3 border-t border-white/10 bg-black/40">
                             <div className="flex gap-2">
                                <Input 
                                    className="h-8 text-xs bg-black/20 border-white/10 focus:border-[hsl(var(--color-intent))]" 
                                    placeholder="Add comment..." 
                                    value={commentText}
                                    onChange={(e) => setCommentText(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                                />
                                <Button size="sm" className="h-8" onClick={handleAddComment}>
                                    <MessageSquare className="w-3 h-3" />
                                </Button>
                             </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}