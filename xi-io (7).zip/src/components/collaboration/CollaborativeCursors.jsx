import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { MousePointer2, Users } from 'lucide-react';

const MOCK_USERS = [
    { id: 'user-1', name: 'Neo', color: '#10b981' }, 
    { id: 'user-2', name: 'Trinity', color: '#8b5cf6' }, 
    { id: 'user-3', name: 'Morpheus', color: '#3b82f6' }, 
    { id: 'user-4', name: 'Cipher', color: '#f43f5e' }, 
];

const Cursor = ({ user }) => {
    const [position, setPosition] = useState({ x: Math.random() * 80 + 10, y: Math.random() * 80 + 10 });
    const [isClicking, setIsClicking] = useState(false);

    useEffect(() => {
        const moveInterval = setInterval(() => {
            setPosition(prev => ({
                x: Math.max(5, Math.min(95, prev.x + (Math.random() - 0.5) * 20)),
                y: Math.max(5, Math.min(95, prev.y + (Math.random() - 0.5) * 20))
            }));
            if (Math.random() > 0.8) {
                setIsClicking(true);
                setTimeout(() => setIsClicking(false), 200);
            }
        }, 2000 + Math.random() * 1000);
        return () => clearInterval(moveInterval);
    }, []);

    return (
        <motion.div
            className="fixed pointer-events-none z-[1] flex items-start gap-1"
            animate={{ left: `${position.x}vw`, top: `${position.y}vh` }}
            transition={{ duration: 2, ease: "easeInOut" }}
        >
            <div className="relative">
                <MousePointer2 
                    className="w-4 h-4 fill-current" 
                    style={{ color: user.color, transform: isClicking ? 'scale(0.8)' : 'scale(1)' }} 
                />
                {isClicking && (
                    <span className="absolute -top-1 -left-1 w-6 h-6 rounded-full border border-current animate-ping opacity-75" style={{ borderColor: user.color }} />
                )}
            </div>
            <span 
                className="px-2 py-0.5 rounded text-[10px] font-bold text-white shadow-sm whitespace-nowrap opacity-50"
                style={{ backgroundColor: user.color }}
            >
                {user.name}
            </span>
        </motion.div>
    );
};

export const CollaborativeCursors = () => {
    const location = useLocation();
    
    // Simulate different users on different pages
    const activeUsers = MOCK_USERS.filter(() => Math.random() > 0.3);

    return (
        <div className="fixed inset-0 pointer-events-none z-[50]">
            {activeUsers.map(user => (
                <Cursor key={user.id} user={user} />
            ))}
            
            {/* Live Presence Indicator */}
            <div className="fixed bottom-6 left-6 pointer-events-auto flex items-center gap-3 bg-black/80 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 text-xs text-white shadow-lg transition-all hover:bg-black/90">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                
                <div className="flex flex-col">
                    <span className="font-bold tracking-wide">LIVE PRESENCE</span>
                    <span className="text-[10px] text-neutral-400 font-mono">
                        {location.pathname} • {activeUsers.length} Active
                    </span>
                </div>

                <div className="h-4 w-px bg-white/10 mx-1" />

                <div className="flex -space-x-2">
                    {activeUsers.map(u => (
                        <div 
                            key={u.id} 
                            className="w-5 h-5 rounded-full border border-black flex items-center justify-center text-[8px] font-bold" 
                            style={{ backgroundColor: u.color }} 
                            title={u.name}
                        >
                            {u.name[0]}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};